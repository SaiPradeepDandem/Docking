package xstr.icap.amp.impl;

import java.text.NumberFormat;

import javax.swing.SwingConstants;

import com.objsys.asn1j.runtime.Asn1Integer;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnFixedReal;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAsnFixedReal extends FormatterFor_default {

   NumberFormat nf = NumberFormat.getNumberInstance();
   @Override
   public String format(Asn1Type asnValue) {
      if (asnValue instanceof AsnFixedReal) {
         AsnFixedReal frValue = (AsnFixedReal)asnValue;
         Asn1Integer decimals = frValue.getDecimals();
         if ( decimals== null) {
            nf.setMaximumFractionDigits(4);
            nf.setMinimumFractionDigits(0);
         }else if(decimals.value==-1L){
            return "null";
         }else{
            nf.setMaximumFractionDigits((int) frValue.getDecimals().value);
            nf.setMinimumFractionDigits((int) frValue.getDecimals().value);
         }
         if(frValue.getValue()==null){
            System.err.println("AsnFixedReal.value is null. decimals is "+decimals);
            return "null";
         }else {
            return nf.format(frValue.getValue().value);
         }
      }
      else if (asnValue == null)
         throw new NullPointerException("AsnFixedRealFormatter: Cannot format null value");
      else
         throw new ClassCastException("AsnFixedRealFormatter: Expected AsnFixedReal, got " + asnValue.getClass().getSimpleName());
   }

   @Override
   public int getAlignment() {
      return SwingConstants.TRAILING;
   }
}
