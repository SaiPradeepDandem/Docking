package xstr.icap.amp.impl;

import com.omxgroup.xstream.amp.AmpExtraFieldsList;
import com.omxgroup.xstream.amp.AmpOrderId;
import com.omxgroup.xstream.amp.AsnFixedReal;
import xstr.amp.impl.MergeHandlerFactory;

public class MergeHandlerFactoryForICAP extends MergeHandlerFactory {

	public MergeHandlerFactoryForICAP() {
		addFactory(AsnFixedReal.class, new MergeHandlerForAsn1FixedReal.Factory());
		addFactory(AmpOrderId.class, new MergeHandlerForAmpOrderId.Factory());
      addFactory(AmpExtraFieldsList.class, new MergeHandlerForAmpExtraFieldsList.Factory());
	}
}
