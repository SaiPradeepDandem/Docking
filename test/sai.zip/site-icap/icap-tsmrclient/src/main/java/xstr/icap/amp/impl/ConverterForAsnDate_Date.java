/**
 *
 */
package xstr.icap.amp.impl;

import java.util.Calendar;
import java.util.Date;

import xstr.util.exception.AsnTypeException;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnDate;

enum  ConverterForAsnDate_Date implements AsnConverter<Date> {
	INSTANCE;

	@Override
	public void setAsn(Asn1Type member, Date value) throws AsnTypeException {
		if (value == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
		if (member instanceof AsnDate) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(value);
			((AsnDate)member).value = (cal.get(Calendar.YEAR)*10000 +
					(cal.get(Calendar.MONTH) + 1)* 100
					+ cal.get(Calendar.DAY_OF_MONTH)) ;
		}
		else
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Date.");
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((Date)obj);
	}

	@Override
	public Asn1Type valueToAsn(Date val) throws AsnTypeException {
		if (val == null)
			return null;
		Asn1Type ret = null;
		try {
			ret = getAsnType().newInstance();
			setAsn(ret, val);
		} catch (InstantiationException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

	@Override
	public Date asnToValue(Asn1Type member) {
                if (member == null) return null;
		if (member instanceof AsnDate) {
			AsnDate asnDate = (AsnDate)member;
			Calendar c = Calendar.getInstance();
			c.set((int) (asnDate.value / 10000) % 10000,
					(int) (asnDate.value / 100) % 100 - 1,
					(int) asnDate.value % 100, 0, 0, 0); // floors time TODO confirm correct behaviour
			c.set(Calendar.MILLISECOND, 0);
			return c.getTime();
		}
		else
			throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Date.");
	}

	@Override
	public Class<Date> getValueType() {
		return Date.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AsnDate.class;
	}
}
