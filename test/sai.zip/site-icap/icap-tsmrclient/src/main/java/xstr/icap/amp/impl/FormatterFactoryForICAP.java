package xstr.icap.amp.impl;

import java.nio.charset.Charset;

import com.omxgroup.xstream.amp.*;
import xstr.amp.impl.FormatterFactory;

public class FormatterFactoryForICAP extends FormatterFactory {

	public FormatterFactoryForICAP(Charset charset) {
		super(charset);
      addFormatter("permissionRep.msgType", new FormatterForAmpPermissionRep_msgType());
		addFormatter(AsnDate.class, new FormatterForAsnDate());
		addFormatter(AsnTime.class, new FormatterForAsnTime());
		addFormatter(AsnDateTime.class, new FormatterForAsnDateTime());
		addFormatter(AmpDateTimeUS.class, new FormatterForAmpDateTimeMS());
		addFormatter(AmpIntervalHMS.class, new FormatterForAmpIntervalHMS());
		addFormatter(AsnFixedReal.class, new FormatterForAsnFixedReal());
		addFormatter(AmpQuantity.class, new FormatterForAmpQuantity());
      addFormatter(AmpPassword.class, new FormatterForAmpPassword());
      addFormatter(AmpBlobData.class, new FormatterForAmpBlobData());
	}

}
