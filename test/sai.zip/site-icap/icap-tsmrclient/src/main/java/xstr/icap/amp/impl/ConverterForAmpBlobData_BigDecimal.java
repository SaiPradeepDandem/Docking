package xstr.icap.amp.impl;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpBlobData;
import xstr.amp.AsnConverter;
import xstr.util.exception.AsnTypeException;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

enum ConverterForAmpBlobData_BigDecimal implements AsnConverter<BigDecimal> {
   INSTANCE;

   @Override
   public BigDecimal asnToValue(Asn1Type member) {
      if (member == null) return null;
      if (member instanceof AmpBlobData) {
         byte[] rawVal = ((AmpBlobData) member).value;
         if (rawVal == null || rawVal.length == 0) return null;

         try {
            String strVal = new String(rawVal, "US-ASCII");
            return new BigDecimal(strVal);
         } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Double.");
         }
      } else
         throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Double.");
   }

   @Override
   public Asn1Type valueToAsn(BigDecimal value) throws AsnTypeException {
      if (value == null)
         return null;
      Asn1Type ret = null;
      try {
         ret = getAsnType().newInstance();
         setAsn(ret, value);
      } catch (InstantiationException | IllegalAccessException e) {
         e.printStackTrace();
      }
      return ret;
   }

   @Override
   public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
      return valueToAsn((BigDecimal)obj);
   }

   @Override
   public void setAsn(Asn1Type member, BigDecimal value) throws AsnTypeException {
      if (value == null)
         throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
      if (member instanceof AmpBlobData) {
         ((AmpBlobData) member).value = value.toString().getBytes();
      }
      else
         throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Double.");
   }

   @Override
   public Class<? extends BigDecimal> getValueType() {
      return BigDecimal.class;
   }

   @Override
   public Class<? extends Asn1Type> getAsnType() {
      return AmpBlobData.class;
   }
}

