package xstr.icap.amp.impl;

import xstr.amp.AsnMergeHandler;
import xstr.amp.AsnAccessor;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnFixedReal;

class MergeHandlerForAsn1FixedReal extends AsnMergeHandler {

	private static final MergeHandlerForAsn1FixedReal INSTANCE = new MergeHandlerForAsn1FixedReal();
	public static class Factory implements AsnMergeHandler.Factory {
		@Override
		public AsnMergeHandler create(Class<? extends Asn1Type> mergeClass) {
			return INSTANCE;
		}
	}

	@Override
	public <T extends Asn1Type> T merge(AsnAccessor parent, T current, T update) {
		AsnFixedReal updateVal = (AsnFixedReal)update;
		if (updateVal.hasDecimals() && updateVal.getDecimals().value == -1)
			return null;
		return update;
	}
}
