package xstr.icap.csdk;

import com.objsys.asn1j.runtime.Asn1Exception;
import com.objsys.asn1j.runtime.Asn1ValueParseException;
import com.omxgroup.xstream.api.*;
import xstr.util.exception.*;

import java.lang.Exception;

public class ExceptionWrapper {
	public static XtrException wrapBest(XStreamException e) {
		return wrapBest(ErrorMessage.getImprovedMessage(e), e);
	}

	public static XtrException wrapBest(String message, XStreamException e) {
		if (e instanceof BadFilter) {
			return wrap(message, (BadFilter)e);
		}

		if (e instanceof BadInsert) {
			return wrap(message, (BadInsert)e);
		}

		if (e instanceof BadParam) {
			return wrap(message, (BadParam)e);
		}

		if (e instanceof BadQuery) {
			return wrap(message, (BadQuery)e);
		}

		if (e instanceof BadTransaction) {
			return wrap(message, (BadTransaction)e);
		}

		if (e instanceof LockedUser) {
			return wrap(message, (LockedUser)e);
		}

		if (e instanceof MarshalError) {
			return wrap(message, (MarshalError)e);
		}

		return wrapInSessionException(message, e);
	}

	public static XtrMessageException wrap(String message, BadFilter e) {
		return wrapInMessageException(message, e);
	}

	public static XtrMessageException wrap(String message, BadInsert e) {
		return wrapInMessageException(message, e);
	}

	public static XtrMessageException wrap(String message, BadParam e) {
		return wrapInMessageException(message, e);
	}

	public static XtrMessageException wrap(String message, BadQuery e) {
		return wrapInMessageException(message, e);
	}

	public static XtrMessageException wrap(String message, BadTransaction e) {
		return wrapInMessageException(message, e);
	}

	public static XtrMessageException wrap(String message, LockedUser e) {
		return wrapInMessageException(message, e);
	}

	public static AsnTypeException wrap(String message, MarshalError e) {
		return wrapInTypeException(message, e);
	}

	public static AsnTypeException wrap(String message, Asn1ValueParseException e) {
		return wrapInTypeException(message, e);
	}

	public static XtrLogonException wrap(String message, LogonError e) {
		if (message == null || message.isEmpty()) {
			return new XtrLogonException(e);
		} else {
			return new XtrLogonException(message, e);
		}
	}

	private static XtrMessageException wrapInMessageException(String message, XStreamException e) {
		if (message == null || message.isEmpty()) {
			return new XtrMessageException(ErrorMessage.getImprovedMessage(e), e);
		} else {
			return new XtrMessageException(message, e);
		}
	}

	public static XtrSessionException wrapInSessionException(String message, Exception e) {
		if (message == null || message.isEmpty())
			message = ErrorMessage.getImprovedMessage(e);

		if (e instanceof CommFailure)
			return wrapInRecoverableException(message, e);

		if (e instanceof InUse)
			return wrapInRecoverableException(message, e);

		return new XtrSessionException(message, e);
	}

	public static XtrSessionException wrapInRecoverableException(String message, Exception e) {
		if (message == null || message.isEmpty())
			message = ErrorMessage.getImprovedMessage(e);
		return new XtrRecoverableException(message, e);
	}

	private static AsnTypeException wrapInTypeException(String message, Asn1Exception e) {
		if (message == null || message.isEmpty()) {
			return new AsnTypeException(ErrorMessage.getImprovedMessage(e), e);
		} else {
			return new AsnTypeException(message, e);
		}
	}

	private static AsnTypeException wrapInTypeException(String message, XStreamException e) {
		if (message == null || message.isEmpty()) {
			return new AsnTypeException(ErrorMessage.getImprovedMessage(e), e);
		} else {
			return new AsnTypeException(message, e);
		}
	}



}
