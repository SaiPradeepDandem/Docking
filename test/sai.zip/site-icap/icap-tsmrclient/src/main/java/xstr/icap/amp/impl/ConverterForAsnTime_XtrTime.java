/**
 *
 */
package xstr.icap.amp.impl;

import xstr.util.exception.AsnTypeException;

import xstr.types.XtrTime;
import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnTime;

enum ConverterForAsnTime_XtrTime implements AsnConverter<XtrTime> {
	INSTANCE;

	@Override
	public void setAsn(Asn1Type member, XtrTime value) throws AsnTypeException {
		if (value == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
		if (member instanceof AsnTime) {
			((AsnTime)member).value =  value.asnTime;
		}
		else
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to StrTime.");
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((XtrTime)obj);
	}

	@Override
	public Asn1Type valueToAsn(XtrTime val) throws AsnTypeException {
		if (val == null)
			return null;
		Asn1Type ret = null;
		try {
			ret = getAsnType().newInstance();
			setAsn(ret, val);
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return ret;
	}

	@Override
	public XtrTime asnToValue(Asn1Type member) {
        if (member == null)
        	return null;
		if (member instanceof AsnTime) {
			AsnTime asnTm = (AsnTime)member;
			return new XtrTime(asnTm.value);
		}
		else
			throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Date.");
	}

	@Override
	public Class<XtrTime> getValueType() {
		return XtrTime.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AsnTime.class;
	}
}
