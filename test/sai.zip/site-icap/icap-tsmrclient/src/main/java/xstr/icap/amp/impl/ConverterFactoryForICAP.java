package xstr.icap.amp.impl;

import com.omxgroup.xstream.amp.AmpBlobData;
import xstr.amp.AsnConverter;
import xstr.amp.impl.ConverterFactory;

public class ConverterFactoryForICAP extends ConverterFactory {
   public ConverterFactoryForICAP() {
      // Default Converters
      add(ConverterForAmpBlobData_XtrBlob.INSTANCE, DEFAULT);
      add(ConverterForAmpBlobData_Date.INSTANCE, DEFAULT);
      add(ConverterForAmpBlobData_Boolean.INSTANCE, DEFAULT);
      add(ConverterForAmpBlobData_Integer.INSTANCE, DEFAULT);
      add(ConverterForAmpBlobData_Double.INSTANCE, DEFAULT);
      add(ConverterForAmpBlobData_BigDecimal.INSTANCE, DEFAULT);
      add(ConverterForAmpBlobData_String.INSTANCE, DEFAULT);
      add(ConverterForAmpDateTimeMS_Date.INSTANCE, DEFAULT);
      add(ConverterForAmpDateTime_Date.INSTANCE, DEFAULT);
      add(ConverterForAmpDateTime_LocalDateTime.INSTANCE,DEFAULT);
      add(ConverterForAmpIntervalHMS_Date.INSTANCE, DEFAULT);
      add(ConverterForAsnDate_Date.INSTANCE, DEFAULT);
      add(ConverterForAsnDateTime_Date.INSTANCE, DEFAULT);
      add(ConverterForAsnFixedReal_BigDecimal.INSTANCE);
      add(ConverterForAsnFixedReal_Double.INSTANCE, DEFAULT);
      add(ConverterForAsnTime_XtrTime.INSTANCE, DEFAULT);
      add(ConverterForAmpSecBoardIdxList_ArrayOfLong.INSTANCE, DEFAULT);
      add(ConverterForAmpSortKey_v1_OrderbookSortKey.INSTANCE, DEFAULT);
      add(ConverterForAmpMMFirmIdList_ArrayOfString.INSTANCE, DEFAULT);
      add(ConverterForAmpClearingHouseIdList_ArrayOfString.INSTANCE, DEFAULT);
      add(ConverterForAmpExtraField_ExtField.INSTANCE, DEFAULT);
   }

   public <T> AsnConverter<T> getBlobDataConverter(Class<T> cls) {
      return getConverter(AmpBlobData.class, cls);
   }
}
