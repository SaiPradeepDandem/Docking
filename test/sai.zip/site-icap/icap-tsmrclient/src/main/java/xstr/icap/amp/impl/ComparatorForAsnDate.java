package xstr.icap.amp.impl;

import java.util.Comparator;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnDate;

enum ComparatorForAsnDate implements Comparator<Asn1Type> {
	INSTANCE;
	@Override
	public int compare(Asn1Type lhs, Asn1Type rhs) {
		if (lhs == rhs)	return 0;
		if (lhs == null) return -1;
		if (rhs == null) return 1;
		if (lhs instanceof AsnDate && rhs instanceof AsnDate) {
         return Long.compare(((AsnDate)lhs).value, ((AsnDate)rhs).value);
		} else
			throw new ClassCastException();
	}
}
