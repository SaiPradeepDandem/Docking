package xstr.icap.amp.impl;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpDateTime;
import com.omxgroup.xstream.amp.AsnDate;
import com.omxgroup.xstream.amp.AsnDateTime;
import com.omxgroup.xstream.amp.AsnTime;
import xstr.amp.AsnPrintFormatter;
import xstr.util.exception.AsnTypeException;

import java.time.LocalDateTime;

enum ConverterForAmpDateTime_LocalDateTime implements AsnConverter<LocalDateTime> {
   INSTANCE;

	@Override
	public void setAsn(Asn1Type member, LocalDateTime localDateTime) throws AsnTypeException {
		if (localDateTime == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
      if (member instanceof AmpDateTime) {
         AsnDate dt = ((AmpDateTime)member).getDate();
         AsnTime tm = ((AmpDateTime)member).getTime();

         if (dt == null) {
            dt = new AsnDate();
            ((AsnDateTime)member).setDate(dt);
         }
         if (tm == null) {
            tm = new AsnTime();
            ((AsnDateTime)member).setTime(tm);
         }
         tm.value =  localDateTime.getHour() * 10000 + localDateTime.getMinute() * 100 + localDateTime.getSecond();
         dt.value = localDateTime.getYear() * 10000 + localDateTime.getMonthValue()  * 100 + localDateTime.getDayOfMonth();
      } else {
         throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Date.");
      }
   }

   @Override
   public Asn1Type valueToAsn(LocalDateTime date) throws AsnTypeException {
      if (date == null) {
         return null;
      }

      Asn1Type ret = null;

      try {
         ret = getAsnType().newInstance();
         setAsn(ret, date);
      } catch (InstantiationException e) {
         //FIXME: Handle this
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (IllegalAccessException e) {
         //FIXME: Handle this
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      return ret;
   }

   @Override
   public LocalDateTime asnToValue(Asn1Type member) {
      if (member == null) {
         return null;
      }

      if (member instanceof AmpDateTime) {
         AmpDateTime asndt = (AmpDateTime)member;
         AsnDate asnDate = asndt.getDate();
		 if (asnDate == null)
		      throw new NullPointerException("ERROR: AmpDateTimeToDate: AmpDateTime.date cannot be null: AmpDateTime: " + AsnPrintFormatter.toShortString(asndt));
         AsnTime asnTime = asndt.getTime();
			if (asnTime == null)
				throw new NullPointerException("ERROR: AmpDateTimeToCalendar: AmpDateTime.time cannot be null");
			//	if asnDate.getvalue()==-1 etc
			if (asnDate.value == -1 && asnTime.value == -1) {
				return null;
			}
         return LocalDateTime.of( (int) ((asnDate.value / 10000) % 10000),(int)( (asnDate.value / 100) % 100),(int) asnDate.value % 100,
            (int) (asnTime.value / 10000) % 100, (int) (asnTime.value / 100) % 100,(int) asnTime.value  % 100);
      } else {
         throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Calendar.");
      }
   }

   @Override
   public Class<LocalDateTime> getValueType() {
      return LocalDateTime.class;
   }

   @Override
   public Class<? extends Asn1Type> getAsnType() {
      return AmpDateTime.class;
   }

   @Override
   public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
      return valueToAsn((LocalDateTime)obj);
   }
}
