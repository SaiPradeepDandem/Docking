package xstr.icap.amp.impl;

import com.omxgroup.xstream.amp.AmpFixedReal;
import xstr.amp.impl.ParserFactory;

public class ParserFactoryForICAP extends ParserFactory {

	public ParserFactoryForICAP() {
		addParser(AmpFixedReal.class, ParserForAmpFixedReal.INSTANCE);
	}
}
