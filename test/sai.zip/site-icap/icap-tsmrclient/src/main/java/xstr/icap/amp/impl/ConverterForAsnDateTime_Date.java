/**
 *
 */
package xstr.icap.amp.impl;

import java.util.Calendar;
import java.util.Date;

import xstr.amp.AsnPrintFormatter;
import xstr.util.exception.AsnTypeException;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnDate;
import com.omxgroup.xstream.amp.AsnDateTime;
import com.omxgroup.xstream.amp.AsnTime;

enum ConverterForAsnDateTime_Date implements AsnConverter<Date> {
	INSTANCE;

	@Override
	public void setAsn(Asn1Type member, Date value) throws AsnTypeException {
		if (value == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
        Calendar cal = Calendar.getInstance();
        cal.setTime(value);
		if (member instanceof AsnDateTime) {
			AsnDate dt = ((AsnDateTime)member).getDate();
			AsnTime tm = ((AsnDateTime)member).getTime();
			if (dt == null) {
				dt = new AsnDate();
				((AsnDateTime)member).setDate(dt);
			}
			if (tm == null) {
				tm = new AsnTime();
				((AsnDateTime)member).setTime(tm);
			}
			tm.value =  cal.get(Calendar.HOUR_OF_DAY) * 10000 + cal.get(Calendar.MINUTE) * 100 + cal.get(Calendar.SECOND);
			dt.value = cal.get(Calendar.YEAR)*10000 + (cal.get(Calendar.MONTH) + 1)* 100 + cal.get(Calendar.DAY_OF_MONTH);
		}
		else
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Date.");
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((Date)obj);
	}

	@Override
	public Asn1Type valueToAsn(Date val) throws AsnTypeException {
		if (val == null)
			return null;
		Asn1Type ret = null;
		try {
			ret = getAsnType().newInstance();
			setAsn(ret, val);
		} catch (InstantiationException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

	@Override
	public Date asnToValue(Asn1Type member) {
        if (member == null) return null;
		if (member instanceof AsnDateTime) {
			AsnDateTime asndt = (AsnDateTime)member;
			AsnDate asnDate = asndt.getDate();
			if (asnDate == null)
				throw new NullPointerException("ERROR: AsnDateTimeToDate: AsnDateTime.date cannot be null: AsnDateTime: " + AsnPrintFormatter.toShortString(asndt));
			AsnTime asnTime = asndt.getTime();
			if (asnTime == null)
				throw new NullPointerException("ERROR: AsnDateTimeToCalendar: AsnDateTime.time cannot be null");
			if (asnDate.value == -1 && asnTime.value == -1) {
				return null;
			}
			Calendar c = Calendar.getInstance();
			c.set(Calendar.YEAR, (int) (asnDate.value / 10000) % 10000);
			c.set(Calendar.MONTH, (int) (asnDate.value / 100) % 100 - 1);
			c.set(Calendar.DAY_OF_MONTH, (int) asnDate.value % 100);
			c.set(Calendar.HOUR_OF_DAY, (int) (asnTime.value / 10000) % 100);
			c.set(Calendar.MINUTE, (int) (asnTime.value / 100) % 100);
			c.set(Calendar.SECOND, (int) asnTime.value  % 100);
			c.set(Calendar.MILLISECOND, 0);
			return c.getTime();
		}
		else
			throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Date.");
	}

	@Override
	public Class<Date> getValueType() {
		return Date.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AsnDateTime.class;
	}
}
