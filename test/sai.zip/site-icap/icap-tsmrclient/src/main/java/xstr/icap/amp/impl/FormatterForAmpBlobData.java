package xstr.icap.amp.impl;

import javax.swing.SwingConstants;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpBlobData;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAmpBlobData extends FormatterFor_default {

   private static final String fmt = "blob[%d]";

   @Override
   public String format(Asn1Type value) {
      if (value instanceof AmpBlobData)
         return String.format(fmt, ((AmpBlobData)value).value.length);
      else if (value == null)
         return "null";
      else
         throw new ClassCastException("FormatterForAmpBlobData: Expected AmpBlobData, got " + value.getClass().getSimpleName());
   }

   @Override
   public int getAlignment() {
      return SwingConstants.LEADING;
   }
}
