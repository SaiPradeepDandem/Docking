package xstr.icap.amp.impl;

import xstr.amp.AsnMergeHandler;
import xstr.amp.AsnAccessor;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderId;

class MergeHandlerForAmpOrderId extends AsnMergeHandler {

	private static final MergeHandlerForAmpOrderId INSTANCE = new MergeHandlerForAmpOrderId();
	public static class Factory implements AsnMergeHandler.Factory {
		@Override
		public AsnMergeHandler create(Class<? extends Asn1Type> mergeClass) {
			return INSTANCE;
		}
	}

	@Override
	public <T extends Asn1Type> T merge(AsnAccessor parent, T current, T update) {
		AmpOrderId updateVal = (AmpOrderId)update;
		if(updateVal.getOrderDate().value == 0 && updateVal.getOrderNo().value == 0)
			return null;
		return update;
	}

}
