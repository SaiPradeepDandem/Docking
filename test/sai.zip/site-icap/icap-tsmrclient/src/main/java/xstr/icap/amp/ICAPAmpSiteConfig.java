package xstr.icap.amp;

import java.nio.charset.Charset;
import java.security.AccessControlException;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.logging.Level;

import xstr.amp.*;
import xstr.amp.acc.AmpAccessor;
import xstr.icap.amp.impl.*;

import xstr.util.concurrent.PlatformExecutor;
import com.omxgroup.xstream.amp.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.bridge.SLF4JBridgeHandler;

import xstr.util.XstrIni.Key;
import xstr.util.exception.AsnTypeException;
import xstr.util.exception.XtrSessionException;

import com.google.common.base.Function;
import xstr.amp.impl.ComparatorFactory;
import xstr.amp.impl.ConverterFactory;
import xstr.amp.impl.FormatterFactory;
import xstr.amp.impl.MergeHandlerFactory;
import xstr.amp.impl.ParserFactory;
import xstr.types.PermissionLevel;
import xstr.amp.AMP.AmpQreq;
import xstr.icap.csdk.ICAPQueryReplyKey;
import xstr.icap.csdk.ICAPSession;
import xstr.session.SessionWrapper;
import xstr.session.XstrClientConfig;
import xstr.session.XstrConnectType;
import xstr.session.XtrKey;
import xstr.session.XtrQueryReply;
import xstr.session.XtrQueryReplyCommand;
import xstr.icap.csdk.ICAPAsnFactories;
import com.objsys.asn1j.runtime.Asn1Choice;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.syssrv.Trace;
import com.omxgroup.xstream.api.cometheader.PrimaryKey;

public class ICAPAmpSiteConfig implements XtrSiteConfig {
   private static final Logger logger = LoggerFactory.getLogger(ICAPAmpSiteConfig.class);

   public ICAPAmpSiteConfig() {
      try {
         SLF4JBridgeHandler.removeHandlersForRootLogger();
         SLF4JBridgeHandler.install();
         Trace.setInstance(new Trace() {
            @Override
            public java.util.logging.Logger getTraceLogger(String name) {
               java.util.logging.Logger logger = java.util.logging.Logger.getLogger(name);

               logger.setLevel(Level.ALL);

               return logger;
            }
         });
      } catch (AccessControlException e) {
          logger.warn("Insufficient permissions to install SLF4J Logger bridge. TSMR Logging will be disabled.");
          Trace.setInstance(new Trace() {
            @Override
            public java.util.logging.Logger getTraceLogger(String name) {
               java.util.logging.Logger l = java.util.logging.Logger.getAnonymousLogger();

               try {
                  l.setLevel(Level.WARNING);
               } catch (AccessControlException ignored) {
               }

               return l;
            }
         });
      }

      // Populate the message ID map
      AmpQueryReqChoice qChoice = new AmpQueryReqChoice();

      for (int idx = 1; idx < Integer.MAX_VALUE; ++idx) {
         qChoice.setElement(idx, null);

         long choiceId = Util.peek(qChoice);

         if (choiceId < 0) {
            break;
         }

         messageIdMap.put(qChoice.getElemName(), choiceId);
      }

      AmpTransReqChoice tChoice = new AmpTransReqChoice();

      for (int idx = 1; idx < Integer.MAX_VALUE; ++idx) {
         tChoice.setElement(idx, null);

         long choiceId = Util.peek(tChoice);

         if (choiceId < 0) {
            break;
         }

         messageIdMap.put(tChoice.getElemName(), choiceId);
      }
   }

   @Override
   public AsnFactories getAsnFactories() {
      return asnFactories;
   }

   @Override
   public ParserFactory getParsers() {
      return asnParsers;
   }

   @Override
   public ConverterFactory getConverters() {
      return asnConverters;
   }

   @Override
   public FormatterFactory getFormatters() {
      return asnFormatters;
   }

   @Override
   public Charset getCharset() {
      return charset;
   }

   @Override
   public MergeHandlerFactory getMergeHandlers() {
      return mergeHandlers;
   }

   @Override
   public ComparatorFactory getComparators() {
      return asnComparators;
   }

   @Override
   public Class<? extends Asn1Choice> getQueryRequestClass() {
      return AmpQueryReqChoice.class;
   }

   @Override
   public Class<? extends Asn1Choice> getTransactionRequestClass() {
      return AmpTransReqChoice.class;
   }

   @Override
   public Class<? extends Asn1Choice> getTransactionReplyClass() {
      return AmpTransRepChoice.class;
   }

   @Override
   public Class<? extends Asn1Choice> getQueryReplyClass() {
      return AmpQueryRepChoice.class;
   }

   @Override
   public String getId() {
      return "ICAP";
   }

   @Override
   public String getVersion() {
      return ReleaseVersion.ID;
   }

   @Override
   public Map<AmpQreq, Function<XtrQueryReply, XtrQueryReply>> getQueryFilters() {
      AmpQreq query = AMP.qREQ("managedOrderReq");
      AsnConversionAccessor<Integer> statusAcc = AmpAccessor.acc(AMP.qREP("managedOrderRep.dynamics.orderStatus"), Integer.class);
      Function<XtrQueryReply, XtrQueryReply> liveOrdersFilter = new Function<XtrQueryReply, XtrQueryReply>() {

         @Override
         public String toString() {
            return "managedOrderReq.liveOrdersFilter";
         }

         @Override
         public XtrQueryReply apply(XtrQueryReply r) {
            synchronized(withdrawnKeys) {
               if (withdrawnKeys.contains(r.getKey()))
                  return null;
               try {
                  Integer status = r.getField(statusAcc);
                  if (status != null && status == AmpOrderStatus_v2.withdrawn) {
                     switch (r.getCommand()) {
                        case CLEAR:
                           return r;
                        case CREATE:
                           return null;
                        default:
                           withdrawnKeys.add(r.getKey());
                           return new XtrQueryReply() {

                              @Override
                              public long getGroupId() {
                                 return r.getGroupId();
                              }

                              @Override
                              public Asn1Choice getData() {
                                 return r.getData();
                              }

                              @Override
                              public <T> T getField(AsnConversionAccessor<T> acc) {
                                 return r.getField(acc);
                              }

                              @Override
                              public XtrQueryReplyCommand getCommand() {
                                 return XtrQueryReplyCommand.DELETE;
                              }

                              @Override
                              public XtrKey getKey() {
                                 return r.getKey();
                              }

                              @Override
                              public Date getTimestamp() {
                                 return r.getTimestamp();
                              }
                           };
                     }
                  }
               } catch (Exception e) {
                  logger.error("Error applying filter:", e);
                  return r;
               }
               return r;
            }
         }
         final Set<XtrKey> withdrawnKeys =  new HashSet<>();
      };
      return Collections.singletonMap(query, liveOrdersFilter);
   }

   public Executor getFGExecutor() {
      return fgExecutor;
   }

   @Override
   public PermissionLevel getPermission(Asn1Type l) {
      if (l instanceof AmpAccessLevel) {
         switch (((AmpAccessLevel) l).value) {
         case AmpAccessLevel.none:
            return PermissionLevel.NONE;
         case 0x1:
            return PermissionLevel.PUBLIC;
         case AmpAccessLevel.user:
            return PermissionLevel.USER;
         case AmpAccessLevel.firm:
            return PermissionLevel.FIRM;
         case AmpAccessLevel.full:
            return PermissionLevel.FULL;
         }
         // logger.error("Unable to determine permission for value: {}",
         // ((AmpAccessLevel) l).value);
         return PermissionLevel.NONE;
      } else
         throw new ClassCastException("Permission: Expected AmpAccessLevel, got " + l.getClass().getSimpleName());
   }

   @Override
   public ResourceBundle getTranslations(Locale loc) {
      return ResourceBundle.getBundle("amp.AmpTranslations_ICAP", loc);
   }

   @Override
   public Long getMessageId(String messageName) {
      return messageIdMap.get(messageName);
   }

   @Override
   public SessionWrapper createSession(XstrClientConfig config) throws XtrSessionException {
      XstrConnectType ct = XstrConnectType.nameOf(config.get(Key.CONN_TYPE));

      switch (ct) {
//      case AUTO:
//         throw new XtrSessionException("Auto connection type not implemented yet.");
      case HTTP:
         throw new XtrSessionException("Http connection type not implemented yet.");
      case TSMR:
         logger.info("Creating TSMR session");
         return new ICAPSession(config);
      case WS:
         throw new XtrSessionException("Http connection type not implemented yet.");
      default:
         throw new XtrSessionException("Invalid Connection Type: " + ct);
      }
   }

   @Override
   public <T> void addConverter(AsnConverter<T> converter) {
      asnConverters.add(converter);
   }

   @Override
   public boolean hasServerStorage() {
      return true;
   }

   @Override
   public <T extends Asn1Type> AsnAccessor getAccessor(Class<T> asnClass, String memberPath) throws AsnTypeException {
      return asnAccessorFactory.getAccessor(asnClass, memberPath);
   }

   @Override
   public <T> AsnConversionAccessor<T> getExtraFieldAccessor(AsnAccessor mapWrapperAcc, String extraField, AsnConverter<T> blobDataConverter) {
      return new ExtraFieldAccessor(mapWrapperAcc, extraField, blobDataConverter);
   }

   @Override
   public XtrKey decodeKey(byte[] bytes) {
      return new ICAPQueryReplyKey(new PrimaryKey(bytes));
   }
   private final Charset charset = Charset.forName("windows-1252");
   private final AsnFactories asnFactories = new ICAPAsnFactories();
   private final AsnAccessorFactory asnAccessorFactory = new AsnAccessorFactory();
   private final ParserFactory asnParsers = new ParserFactoryForICAP();
   private final ConverterFactory asnConverters = new ConverterFactoryForICAP();
   private final FormatterFactory asnFormatters = new FormatterFactoryForICAP(charset);
   private final ComparatorFactory asnComparators = new ComparatorFactoryForICAP();
   private final MergeHandlerFactory mergeHandlers = new MergeHandlerFactoryForICAP();
   private final HashMap<String, Long> messageIdMap = new HashMap<>();
   private final Executor fgExecutor = new PlatformExecutor(logger);

}
