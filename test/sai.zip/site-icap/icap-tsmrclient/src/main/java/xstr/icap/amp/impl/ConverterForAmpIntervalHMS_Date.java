package xstr.icap.amp.impl;

import java.util.concurrent.TimeUnit;

import xstr.util.exception.AsnTypeException;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.syssrv.Duration;
import com.omxgroup.xstream.amp.AmpIntervalHMS;
import com.omxgroup.xstream.amp.AsnTime;

enum ConverterForAmpIntervalHMS_Date implements AsnConverter<Duration> {
	INSTANCE;

	@Override
	public Duration asnToValue(Asn1Type member) {
		if (member == null) {
        	return null;
		}

		if (member instanceof AmpIntervalHMS) {
			AmpIntervalHMS asnIntervalHMS = (AmpIntervalHMS)member;
			long hours = (asnIntervalHMS.value / 10000) % 100;
			long minutes = (asnIntervalHMS.value / 100) % 100;
			long seconds = asnIntervalHMS.value % 100;

			return Duration.of(hours * 3600 + minutes * 60 + seconds, TimeUnit.SECONDS);
		} else {
			throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Duration.");
		}
	}

	@Override
	public Asn1Type valueToAsn(Duration value) throws AsnTypeException {
		if (value == null) {
			return null;
		}

		try {
			Asn1Type asnValue = getAsnType().newInstance();
			setAsn(asnValue, value);
			return asnValue;
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((Duration)obj);
	}

	@Override
	public void setAsn(Asn1Type member, Duration value) throws AsnTypeException {
		if (value == null) {
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
		}

		if (member instanceof AmpIntervalHMS) {
			long totalSecs = value.in(TimeUnit.SECONDS); // Rounding down in case of sub second resolution
			long hours = totalSecs / 3600;
			long minutes = (totalSecs - hours * 3600) / 60;
			long seconds = totalSecs - hours * 3600 - minutes * 60;
			((AsnTime)member).value = hours * 10000 + minutes * 100 + seconds;
		} else {
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Duration.");
		}
	}

	@Override
	public Class<Duration> getValueType() {
		return Duration.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AmpIntervalHMS.class;
	}

}
