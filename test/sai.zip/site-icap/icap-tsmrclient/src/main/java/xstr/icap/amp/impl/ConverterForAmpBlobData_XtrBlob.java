package xstr.icap.amp.impl;

import xstr.util.exception.AsnTypeException;

import xstr.types.XtrBlob;
import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpBlobData;

enum ConverterForAmpBlobData_XtrBlob implements AsnConverter<XtrBlob>{
	INSTANCE;

	@Override
	public void setAsn(Asn1Type member, XtrBlob value) throws AsnTypeException {
		if (value == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
		if (member instanceof AmpBlobData)
			((AmpBlobData) member).value = value.toByteArray();
		else
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Long.");
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((XtrBlob)obj);
	}

	@Override
	public Asn1Type valueToAsn(XtrBlob val) throws AsnTypeException {
		if (val == null)
			return null;
		Asn1Type ret = null;
		try {
			ret = getAsnType().newInstance();
			setAsn(ret, val);
		} catch (InstantiationException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

	@Override
	public XtrBlob asnToValue(Asn1Type member) {
                if (member == null) return null;
		if (member instanceof AmpBlobData)
                    return new XtrBlob(((AmpBlobData) member).value);
		else
                    throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Long.");
	}

	@Override
	public Class<XtrBlob> getValueType() {
		return XtrBlob.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AmpBlobData.class;
	}

}
