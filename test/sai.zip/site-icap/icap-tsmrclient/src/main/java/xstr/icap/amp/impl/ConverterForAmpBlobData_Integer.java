package xstr.icap.amp.impl;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpBlobData;
import xstr.util.exception.AsnTypeException;

import java.io.UnsupportedEncodingException;

/**
 * Created by baasim on 2/03/2016.
 */
enum ConverterForAmpBlobData_Integer implements AsnConverter<Integer> {
   INSTANCE;

   @Override
   public Integer asnToValue(Asn1Type member) {
      if (member == null) return null;
      if (member instanceof AmpBlobData) {
         byte[] rawVal = ((AmpBlobData) member).value;
         if (rawVal == null || rawVal.length == 0) return null;

         try {
            String strVal = new String(rawVal, "US-ASCII");
            return Integer.parseInt(strVal);
         } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Integer.");
         }
      } else
         throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Integer.");
   }

   @Override
   public Asn1Type valueToAsn(Integer value) throws AsnTypeException {
      if (value == null)
         return null;
      Asn1Type ret = null;
      try {
         ret = getAsnType().newInstance();
         setAsn(ret, value);
      } catch (InstantiationException | IllegalAccessException e) {
         e.printStackTrace();
      }
      return ret;
   }

   @Override
   public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
      return valueToAsn((Integer)obj);
   }

   @Override
   public void setAsn(Asn1Type member, Integer value) throws AsnTypeException {
      if (value == null)
         throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
      if (member instanceof AmpBlobData) {
         ((AmpBlobData) member).value = Integer.toString(value).getBytes();
      }
      else
         throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Integer.");
   }

   @Override
   public Class<? extends Integer> getValueType() {
      return Integer.class;
   }

   @Override
   public Class<? extends Asn1Type> getAsnType() {
      return AmpBlobData.class;
   }
}
