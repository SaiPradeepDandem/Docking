package xstr.icap.amp.impl;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnTime;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAsnTime extends FormatterFor_default {

	@Override
	public String format(Asn1Type value) {
      if (value == null)
         throw new NullPointerException("AsnTimeFormatter: Cannot format null value");
      else if (value instanceof AsnTime) {
			return ConverterForAsnTime_XtrTime.INSTANCE.asnToValue(value).toString();
		}
		else
			throw new ClassCastException("AsnTimeFormatter: Expected AsnTime, got " + value.getClass().getSimpleName());
	}

}
