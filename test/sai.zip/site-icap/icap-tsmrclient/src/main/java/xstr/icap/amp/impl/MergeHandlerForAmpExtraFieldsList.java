package xstr.icap.amp.impl;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpExtraField;
import com.omxgroup.xstream.amp.AmpExtraFieldsList;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnMergeHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

class MergeHandlerForAmpExtraFieldsList extends AsnMergeHandler  {
   private static final MergeHandlerForAmpExtraFieldsList INSTANCE = new MergeHandlerForAmpExtraFieldsList();
   public static class Factory implements AsnMergeHandler.Factory {
      @Override
      public AsnMergeHandler create(Class<? extends Asn1Type> mergeClass) {
         return INSTANCE;
      }
   }

   @Override
   public <T extends Asn1Type> T merge(AsnAccessor parent, T current, T update) {
      AmpExtraFieldsList updateVal = (AmpExtraFieldsList)update;
      AmpExtraFieldsList currentVal = (AmpExtraFieldsList)current;

      if (currentVal == null || currentVal.getElements().length == 0)
         return update;

      List<AmpExtraField> currentElements = new ArrayList<>(Arrays.asList(currentVal.getElements()));

      for (AmpExtraField f: updateVal.getElements()) {
         currentElements.removeIf(currElem -> Objects.equals(currElem.getKey(), f.getKey()));
      }
      int remainingItemsLength = currentElements.size();
      if (remainingItemsLength > 0) {
         AmpExtraField[] newUpdateArray = Arrays.copyOf(updateVal.getElements(), updateVal.getElements().length + remainingItemsLength);
         AtomicInteger i = new AtomicInteger(0);
         currentElements.forEach(f -> {
            newUpdateArray[updateVal.getElements().length + i.get()] = new AmpExtraField(f.getKey(), f.getValue());
            i.getAndIncrement();
         });
         ((AmpExtraFieldsList) update).setElements(newUpdateArray);
      }

      return update;
   }
}
