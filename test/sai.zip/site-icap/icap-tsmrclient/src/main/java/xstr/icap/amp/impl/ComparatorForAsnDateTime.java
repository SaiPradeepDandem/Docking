package xstr.icap.amp.impl;

import java.util.Comparator;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnDateTime;

enum ComparatorForAsnDateTime implements Comparator<Asn1Type> {
	INSTANCE;
	@Override
	public int compare(Asn1Type lhs, Asn1Type rhs) {
		if (lhs == rhs)	return 0;
		if (lhs == null) return -1;
		if (rhs == null) return 1;
		if (lhs instanceof AsnDateTime && rhs instanceof AsnDateTime) {
			AsnDateTime ldt = (AsnDateTime)lhs;
			AsnDateTime rdt = (AsnDateTime)rhs;
			int ret = ComparatorForAsnDate.INSTANCE.compare(ldt.getDate(), rdt.getDate());
			if (ret != 0) return ret;
			return ComparatorForAsnTime.INSTANCE.compare(ldt.getTime(), rdt.getTime());
		} else
			throw new ClassCastException();
	}
}
