package xstr.icap.amp.impl;

import java.util.Calendar;
import java.util.Date;

import xstr.amp.AsnPrintFormatter;
import xstr.util.exception.AsnTypeException;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpDateTime;
import com.omxgroup.xstream.amp.AsnDate;
import com.omxgroup.xstream.amp.AsnDateTime;
import com.omxgroup.xstream.amp.AsnTime;

/**
 * Do not use this convert, it uses timezone of local JVM by invoke  {@link Calendar#getInstance()}.
 * There is no guarantee that the default local timezione is same as the time of trading engine.
 */
@Deprecated
enum ConverterForAmpDateTime_Date implements AsnConverter<Date> {
   INSTANCE;

	@Override
	public void setAsn(Asn1Type member, Date value) throws AsnTypeException {
		if (value == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
        Calendar cal = Calendar.getInstance();
        cal.setTime(value);
      if (member instanceof AmpDateTime) {
         AsnDate dt = ((AmpDateTime)member).getDate();
         AsnTime tm = ((AmpDateTime)member).getTime();

         if (dt == null) {
            dt = new AsnDate();
            ((AsnDateTime)member).setDate(dt);
         }
         if (tm == null) {
            tm = new AsnTime();
            ((AsnDateTime)member).setTime(tm);
         }
         tm.value =  cal.get(Calendar.HOUR_OF_DAY) * 10000 + cal.get(Calendar.MINUTE) * 100 + cal.get(Calendar.SECOND);
         dt.value = cal.get(Calendar.YEAR) * 10000 + (cal.get(Calendar.MONTH) + 1) * 100 + cal.get(Calendar.DAY_OF_MONTH);
      } else {
         throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Date.");
      }
   }

   @Override
   public Asn1Type valueToAsn(Date date) throws AsnTypeException {
      if (date == null) {
         return null;
      }

      Asn1Type ret = null;

      try {
         ret = getAsnType().newInstance();
         setAsn(ret, date);
      } catch (InstantiationException e) {
         //FIXME: Handle this
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (IllegalAccessException e) {
         //FIXME: Handle this
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      return ret;
   }

   @Override
   public Date asnToValue(Asn1Type member) {
      if (member == null) {
         return null;
      }

      if (member instanceof AmpDateTime) {
         AmpDateTime asndt = (AmpDateTime)member;
         AsnDate asnDate = asndt.getDate();
		 if (asnDate == null)
		      throw new NullPointerException("ERROR: AmpDateTimeToDate: AmpDateTime.date cannot be null: AmpDateTime: " + AsnPrintFormatter.toShortString(asndt));
         AsnTime asnTime = asndt.getTime();
			if (asnTime == null)
				throw new NullPointerException("ERROR: AmpDateTimeToCalendar: AmpDateTime.time cannot be null");
			//	if asnDate.getvalue()==-1 etc
			if (asnDate.value == -1 && asnTime.value == -1) {
				return null;
			}
         Calendar c = Calendar.getInstance();

         c.set(Calendar.YEAR, (int) (asnDate.value / 10000) % 10000);
         c.set(Calendar.MONTH, (int) (asnDate.value / 100) % 100 - 1);
         c.set(Calendar.DAY_OF_MONTH, (int) asnDate.value % 100);
         c.set(Calendar.HOUR_OF_DAY, (int) (asnTime.value / 10000) % 100);
         c.set(Calendar.MINUTE, (int) (asnTime.value / 100) % 100);
         c.set(Calendar.SECOND, (int) asnTime.value  % 100);
         c.set(Calendar.MILLISECOND, 0);
         return c.getTime();
      } else {
         throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Calendar.");
      }
   }

   @Override
   public Class<Date> getValueType() {
      return Date.class;
   }

   @Override
   public Class<? extends Asn1Type> getAsnType() {
      return AmpDateTime.class;
   }

   @Override
   public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
      return valueToAsn((Date)obj);
   }
}
