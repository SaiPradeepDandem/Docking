package xstr.icap.amp.impl;

import java.text.DateFormat;
import java.util.Date;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnDateTime;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAsnDateTime extends FormatterFor_default {
	DateFormat df = DateFormat.getInstance();

	@Override
	public String format(Asn1Type value) {
		if (value instanceof AsnDateTime) {
			Date date = ConverterForAsnDateTime_Date.INSTANCE.asnToValue(value);
			if (date!=null) {
				return df.format(date);
			} else {
				return "";
			}
		}
		else if (value == null)
			throw new NullPointerException("AsnDateTimeFormatter: Cannot format null value");
		else
			throw new ClassCastException("AsnDateTimeFormatter: Expected AsnDateTime, got " + value.getClass().getSimpleName());
	}

}
