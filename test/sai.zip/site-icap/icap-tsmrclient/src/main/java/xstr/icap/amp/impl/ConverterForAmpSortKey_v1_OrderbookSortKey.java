/**
 *
 */
package xstr.icap.amp.impl;

import xstr.util.exception.AsnTypeException;

import xstr.amp.AsnConverter;
import xstr.types.OrderbookSortKey;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpInteger;
import com.omxgroup.xstream.amp.AmpSortKey_v2;

enum ConverterForAmpSortKey_v1_OrderbookSortKey implements AsnConverter<OrderbookSortKey> {
	INSTANCE;

	@Override
	public void setAsn(Asn1Type member, OrderbookSortKey value) throws AsnTypeException {
		if (value == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
		if (member instanceof AmpSortKey_v2) {
			((AmpSortKey_v2)member).setPrimary(new AmpInteger(value.k1));
			((AmpSortKey_v2)member).setSecondary(new AmpInteger(value.k1));
			((AmpSortKey_v2)member).setTertiary(new AmpInteger(value.k1));
		}
		else
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Double.");
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((OrderbookSortKey)obj);
	}

	@Override
	public Asn1Type valueToAsn(OrderbookSortKey val) throws AsnTypeException {
		if (val == null)
			return null;
		Asn1Type ret = null;
		try {
			ret = getAsnType().newInstance();
			setAsn(ret, val);
		} catch (InstantiationException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

	@Override
	public OrderbookSortKey asnToValue(Asn1Type member) {
		if (member == null)
			return null;
		//System.out.println("AsnFixedRealToBigDecimal.asnToValue: " + ASN.toString(member));
		if (member instanceof AmpSortKey_v2) {
			return new OrderbookSortKey(
					((AmpSortKey_v2)member).getPrimary().value,
					((AmpSortKey_v2)member).getSecondary().value,
					((AmpSortKey_v2)member).getTertiary().value,
					((AmpSortKey_v2)member).getQuaternary().value
					);
		}
		else
			throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Double.");
	}

	@Override
	public Class<OrderbookSortKey> getValueType() {
		return OrderbookSortKey.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AmpSortKey_v2.class;
	}
}
