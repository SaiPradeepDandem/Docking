package xstr.icap.amp.impl;

import java.util.ArrayList;
import java.util.List;

import xstr.util.exception.AsnTypeException;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.objsys.asn1j.runtime.Asn1ValueParseException;
import com.omxgroup.xstream.amp.AmpClearingHouseId;
import com.omxgroup.xstream.amp.AmpClearingHouseIdList;
import com.omxgroup.xstream.amp.AmpClearingHouseIdList_element;

public enum ConverterForAmpClearingHouseIdList_ArrayOfString implements AsnConverter<String[]> {
   INSTANCE;

   @Override
   public String[] asnToValue(Asn1Type member) {
      if (member == null)
         return null;
      if (member instanceof AmpClearingHouseIdList) {
         AmpClearingHouseIdList l = (AmpClearingHouseIdList)member;
         List<String> ret = new ArrayList<String>();
         for (AmpClearingHouseIdList_element i: l.getElements()) {
            ret.add(i.getClearingHouseId().toString());
         }
         String[] r = new String[ret.size()];
         return ret.toArray(r);
      }
      else
         throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to List<String> .");
   }

   @Override
   public Asn1Type valueToAsn(String[] val) throws AsnTypeException {
      if (val == null)
         return null;
      Asn1Type ret = null;
      try {
         ret = getAsnType().newInstance();
         setAsn(ret, val);
      } catch (InstantiationException e) {
         e.printStackTrace();
      } catch (IllegalAccessException e) {
         e.printStackTrace();
      }
      return ret;
   }

   @Override
   public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
      return valueToAsn((String[])obj);
   }

   @Override
   public void setAsn(Asn1Type member, String[] values) throws AsnTypeException {
      if (values == null)
         throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
      if (member instanceof AmpClearingHouseIdList) {
         AmpClearingHouseIdList l = (AmpClearingHouseIdList) member;
         List<AmpClearingHouseIdList_element> elements = new ArrayList<AmpClearingHouseIdList_element>();
         for (String v: values) {
            if (v != null)
               try {
                  elements.add(new AmpClearingHouseIdList_element(new AmpClearingHouseId(v)));
               } catch (Asn1ValueParseException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
               }
         }
         AmpClearingHouseIdList_element[] elemArray = new AmpClearingHouseIdList_element[elements.size()];
         l.setElements(elements.toArray(elemArray));
      }
      else
         throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to list of strings.");
   }

   @Override
   public Class<? extends String[]> getValueType() {
      return String[].class;
   }

   @Override
   public Class<? extends Asn1Type> getAsnType() {
      // TODO Auto-generated method stub
      return AmpClearingHouseIdList.class;
   }

}
