package xstr.icap.amp.impl;

import java.io.UnsupportedEncodingException;
import java.util.*;

import xstr.util.exception.AsnTypeException;

import xstr.types.XtrBlob;
import xstr.amp.AsnConverter;
import xstr.types.MapWrapper;
import com.objsys.asn1j.runtime.Asn1Type;
import com.objsys.asn1j.runtime.Asn1ValueParseException;
import com.omxgroup.xstream.amp.*;

public enum ConverterForAmpExtraField_ExtField implements AsnConverter<MapWrapper> {
   INSTANCE;

   @Override
   public MapWrapper asnToValue(Asn1Type member) {
      if (member == null)
         return null;
      if (member instanceof AmpExtraFieldsList) {
         MapWrapper rtn = new MapWrapper();
         AmpExtraFieldsList extraField = (AmpExtraFieldsList)member;
         for (AmpExtraField i: extraField.getElements()) {
            try {
               rtn.put(new String(i.getKey().value, "US-ASCII"), new XtrBlob(i.getValue().value));
            } catch (UnsupportedEncodingException e) {
               throw new RuntimeException(e.getMessage());
            }
         }
         return rtn;
      }
      else
         throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Map<String,XtrBlob>.");
   }

   @Override
   public Asn1Type valueToAsn(MapWrapper val) throws AsnTypeException {
      if (val == null)
         return null;
      Asn1Type ret = null;
      try {
         ret = getAsnType().newInstance();
         setAsn(ret, val);
      } catch (InstantiationException | IllegalAccessException e) {
         e.printStackTrace();
      }
      return ret;
   }

   @SuppressWarnings("unchecked")
   @Override
   public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
      return valueToAsn((MapWrapper)obj);
   }

   @Override
   public void setAsn(Asn1Type member, MapWrapper values) throws AsnTypeException {
      if (values == null)
         throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
      if (member instanceof AmpExtraFieldsList) {
         AmpExtraFieldsList list = (AmpExtraFieldsList) member;
         Set<String> keys =  values.keySet();

         AmpExtraField[] rtn = new AmpExtraField[keys.size()];
         int index=0;

         for (String k: keys) {
            if (k != null)
               try {
                  AmpExtraField aField = new AmpExtraField();
                  aField.setKey(new AmpExtraFieldKey(k));
                  aField.setValue(new AmpBlobData(values.get(k).toByteArray()));
                  rtn[index++] = aField;
               } catch (Asn1ValueParseException e) {
                  e.printStackTrace();
               }
         }
         list.setElements(rtn);
      }
      else
         throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Map<String,XtrBlob>.");
   }

   @SuppressWarnings("unchecked")
   @Override
   public Class<MapWrapper> getValueType() {
      return MapWrapper.class;
   }

   @Override
   public Class<? extends Asn1Type> getAsnType() {
      return AmpExtraFieldsList.class;
   }
}
