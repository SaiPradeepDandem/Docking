package xstr.icap.amp.impl;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpBlobData;
import xstr.util.exception.AsnTypeException;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by baasim on 2/03/2016.
 */
enum ConverterForAmpBlobData_Date implements AsnConverter<Date> {
   INSTANCE;

   @Override
   public Date asnToValue(Asn1Type member) {
      if (member == null) return null;
      if (member instanceof AmpBlobData) {
         try {
            byte[] rawVal = ((AmpBlobData) member).value;
            if (rawVal == null || rawVal.length == 0) return null;

            String strVal = new String(rawVal, "US-ASCII");
            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
            try {
               return formatter.parse(strVal);
            } catch (ParseException e) {
               e.printStackTrace();
               throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Date.");
            }

         } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Date.");
         }
      } else
         throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Date.");
   }

   @Override
   public Asn1Type valueToAsn(Date value) throws AsnTypeException {
      if (value == null)
         return null;
      Asn1Type ret = null;
      try {
         ret = AmpBlobData.class.newInstance();
         setAsn(ret, value);
      } catch (InstantiationException | IllegalAccessException e) {
         e.printStackTrace();
      }
      return ret;
   }

   @Override
   public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
      return valueToAsn((Date)obj);
   }

   @Override
   public void setAsn(Asn1Type member, Date value) throws AsnTypeException {
      if (value == null)
         throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
      if (member instanceof AmpBlobData) {
         SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
         ((AmpBlobData) member).value = formatter.format(value).getBytes();
      }
      else
         throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Date.");
   }

   @Override
   public Class<? extends Date> getValueType() {
      return Date.class;
   }

   @Override
   public Class<? extends Asn1Type> getAsnType() {
      return AmpBlobData.class;
   }
}
