package xstr.icap.amp.impl;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpIntervalHMS;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAmpIntervalHMS extends FormatterFor_default {

	@Override
	public String format(Asn1Type value) {
		if (value instanceof AmpIntervalHMS) {
			long theValue = ((AmpIntervalHMS) value).value;
			return String.format("%02d:%02d:%02d", theValue / 10000, (theValue % 10000) / 100, theValue % 100);
		}
		else if (value == null)
			throw new NullPointerException("AmpDateTimeMSFormatter: Cannot format null value");
		else
			throw new ClassCastException("AmpDateTimeMSFormatter: Expected AmpDateTimeMS, got " + value.getClass().getSimpleName());
	}

}
