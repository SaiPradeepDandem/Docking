package xstr.icap.amp.impl;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpDateTimeUS;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAmpDateTimeMS extends FormatterFor_default {
	Format df = new SimpleDateFormat("HH:mm:ss");

	@Override
	public String format(Asn1Type value) {
		if (value instanceof AmpDateTimeUS) {
			Date dt = ConverterForAmpDateTimeMS_Date.INSTANCE.asnToValue(value);
			if (dt!=null) {
				return df.format(dt.getTime());
			} else {
				return "";
			}
		}
		else if (value == null)
			throw new NullPointerException("AmpDateTimeMSFormatter: Cannot format null value");
		else
			throw new ClassCastException("AmpDateTimeMSFormatter: Expected AmpDateTimeMS, got " + value.getClass().getSimpleName());
	}

}
