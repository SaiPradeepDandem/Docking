package xstr.icap.amp.impl;

import com.omxgroup.xstream.amp.AmpSortKey_v2;
import com.omxgroup.xstream.amp.AsnDate;
import com.omxgroup.xstream.amp.AsnDateTime;
import com.omxgroup.xstream.amp.AsnFixedReal;
import com.omxgroup.xstream.amp.AsnTime;
import xstr.amp.impl.ComparatorFactory;

public class ComparatorFactoryForICAP extends ComparatorFactory {
	public ComparatorFactoryForICAP() {
		addComparator(AsnFixedReal.class, ComparatorForAsnFixedReal.INSTANCE);
		addComparator(AsnDateTime.class, ComparatorForAsnDateTime.INSTANCE);
		addComparator(AsnDate.class, ComparatorForAsnDate.INSTANCE);
		addComparator(AsnTime.class, ComparatorForAsnTime.INSTANCE);
		addComparator(AmpSortKey_v2.class, ComparatorForAmpSortKey.INSTANCE);
	}
}
