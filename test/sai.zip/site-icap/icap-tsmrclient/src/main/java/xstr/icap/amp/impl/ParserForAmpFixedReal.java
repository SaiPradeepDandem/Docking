package xstr.icap.amp.impl;

import java.text.NumberFormat;
import java.text.ParseException;

import xstr.amp.AsnParser;
import com.objsys.asn1j.runtime.Asn1Real;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpFixedReal;

enum ParserForAmpFixedReal implements AsnParser {
	INSTANCE;
	@Override
	public boolean parse(Asn1Type asn, String value) {
		if (asn instanceof AmpFixedReal) {
		   NumberFormat format = NumberFormat.getInstance();
			try {
            ((AmpFixedReal)asn).setValue(new Asn1Real(format.parse(value).doubleValue()));
         } catch (ParseException e) {
            // TODO Auto-generated catch block
            return false;
         }
			((AmpFixedReal)asn).setDecimals(null);
			return true;
		}
		return false;
	}
}
