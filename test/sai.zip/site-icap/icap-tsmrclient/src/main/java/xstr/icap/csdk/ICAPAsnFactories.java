package xstr.icap.csdk;

import xstr.amp.AsnFactories;
import xstr.amp.AsnFactory;
import com.objsys.asn1j.runtime.Asn1Real;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnFixedReal;

public class ICAPAsnFactories extends AsnFactories {

	private static class AsnFixedRealFactory implements AsnFactory {

		@SuppressWarnings("unchecked")
		@Override
		public <T extends Asn1Type> T newInstance(Class<T> cls) {
			try {
				AsnFixedReal val = (AsnFixedReal) cls.newInstance();
				val.setValue(new Asn1Real(0.0));
				return (T) val;
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
	}


	public ICAPAsnFactories() {
		addFactory(AsnFixedReal.class, new AsnFixedRealFactory());
	}
}
