package xstr.icap.amp.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;

import xstr.util.exception.AsnTypeException;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnFixedReal;

enum ConverterForAsnFixedReal_BigDecimal implements AsnConverter<BigDecimal> {
	INSTANCE;

	@Override
	public void setAsn(Asn1Type member, BigDecimal value) throws AsnTypeException {
		if (value == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
		if (member instanceof AsnFixedReal) {
			((AsnFixedReal)member).setValue(value.doubleValue());
			((AsnFixedReal)member).setDecimals(value.scale());
		}
		else
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Double.");
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((BigDecimal)obj);
	}

	@Override
	public Asn1Type valueToAsn(BigDecimal val) throws AsnTypeException {
		if (val == null)
			return null;
		Asn1Type ret = null;
		try {
			ret = getAsnType().newInstance();
			setAsn(ret, val);
		} catch (InstantiationException | IllegalAccessException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      return ret;
	}

	@Override
	public BigDecimal asnToValue(Asn1Type member) {
		if (member == null)
			return null;
		//System.out.println("AsnFixedRealToBigDecimal.asnToValue: " + ASN.toString(member));
		if (member instanceof AsnFixedReal) {
			int decimals = (int) ((AsnFixedReal)member).getDecimals().value;
			if (decimals < 0)
				return null;
			return BigDecimal.valueOf(((AsnFixedReal)member).getValue().value).setScale(decimals, RoundingMode.HALF_UP);
		}
		else
                    throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to BigDecimal.");
	}

	@Override
	public Class<BigDecimal> getValueType() {
		return BigDecimal.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AsnFixedReal.class;
	}
}
