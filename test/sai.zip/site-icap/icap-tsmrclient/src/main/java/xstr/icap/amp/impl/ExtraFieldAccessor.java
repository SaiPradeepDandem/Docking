package xstr.icap.amp.impl;

import com.objsys.asn1j.runtime.Asn1Type;
import com.objsys.asn1j.runtime.Asn1ValueParseException;
import com.omxgroup.xstream.amp.AmpBlobData;
import com.omxgroup.xstream.amp.AmpExtraField;
import com.omxgroup.xstream.amp.AmpExtraFieldKey;
import com.omxgroup.xstream.amp.AmpExtraFieldsList;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.AsnConverter;
import xstr.util.exception.AsnTypeException;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class ExtraFieldAccessor<T>  implements AsnConversionAccessor<T> {

   public ExtraFieldAccessor(AsnAccessor acc, String key, AsnConverter<T> conv) {
      this.acc = acc;
      this.key = key;
      this.conv = conv;
   }

   @Override
   public T getValueFromBase(Asn1Type root) {
      Asn1Type val = getFromBase(root);
      if(val!=null) {
         return conv.asnToValue(val);
      }
      return null;
   }

   @Override
   public void setValueFromBase(Asn1Type root, T value) throws AsnTypeException {
      setFromBase(root, conv.valueToAsn(value));
   }

   @Override
   public Class<? extends T> getConversionClass() {
      return conv.getValueType();
   }

   @Override
   public Asn1Type getFromBase(Asn1Type base) {
      Asn1Type extraFieldsList = acc.getFromBase(base);
      if (extraFieldsList instanceof AmpExtraFieldsList) {
         for (AmpExtraField f: ((AmpExtraFieldsList) extraFieldsList).getElements()) {
            if (key.equals(f.getKey().toString()))
               return f.getValue();
         }
      }
      return null;
   }

   @Override
   public void setFromBase(Asn1Type base, Asn1Type val) {
      if (val == null || val instanceof AmpBlobData) {
         Asn1Type asn = acc.getFromBase(base);
         if (asn instanceof AmpExtraFieldsList) {
            AmpExtraFieldsList extraFields =  ((AmpExtraFieldsList) asn);
            for (AmpExtraField f : extraFields.getElements()) {
               if (key.equals(f.getKey().toString())) { // If we find the key we set its new value and get out
                  f.setValue((AmpBlobData) val);
                  return;
               }
            }

            // If the key is not in the array of elements we add the extra field to the end of it (by cloning the current array)
            AmpExtraField[] newArray = Arrays.copyOf(extraFields.getElements(), extraFields.getElements().length + 1);
            try {
               newArray[extraFields.getElements().length] = new AmpExtraField(new AmpExtraFieldKey(key), (AmpBlobData) val);
               extraFields.setElements(newArray);
            } catch (Asn1ValueParseException e) {
               e.printStackTrace();
            }
         }
      }
   }

   @Override
   public Asn1Type newInstance() {
      return new AmpBlobData();
   }

   @Override
   public String getQualifiedName() {
      return acc.getQualifiedName() + "." + key;
   }

   @Override
   public Class<? extends Asn1Type> getValueClass() {
      return AmpBlobData.class;
   }

   @Override
   public Class<? extends Asn1Type> getBaseClass() {
      return AmpExtraFieldsList.class;
   }

   @Override
   public AccessSpec<Asn1Type> getAccessSpec() {
      return null;
   }

   @Override
   public String asnToString(Asn1Type asn) {
      if (asn == null) return null;
      if (asn instanceof AmpBlobData) {
         try {
            return new String(((AmpBlobData) asn).value, "US-ASCII");
         } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
         }
      }
      return asn.toString();
   }
   private AsnAccessor acc;
   private String key;
   private AsnConverter<T> conv;
   private final AccessSpec<Asn1Type> accessSpec = new AccessSpec<Asn1Type>() {
      @Override
      public Class<? extends Asn1Type> getBaseType() {
         return acc.getBaseClass();
      }

      @Override
      public String getPath() {
         return getQualifiedName();
      }
   };
}
