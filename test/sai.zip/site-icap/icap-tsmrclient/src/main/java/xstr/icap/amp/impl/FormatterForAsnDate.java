package xstr.icap.amp.impl;

import java.text.DateFormat;
import java.util.Date;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnDate;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAsnDate extends FormatterFor_default {
	DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);

	@Override
	public String format(Asn1Type value) {
		if (value instanceof AsnDate) {
			Date dt = ConverterForAsnDate_Date.INSTANCE.asnToValue(value);
			if (dt!=null) {
				return df.format(dt.getTime());
			} else {
				return "";
			}
		}
		else if (value == null)
			throw new NullPointerException("AsnDateFormatter: Cannot format null value");
		else
			throw new ClassCastException("AsnDateFormatter: Expected AsnDate, got " + value.getClass().getSimpleName());
	}

}
