package xstr.icap.amp.impl;

import javax.swing.SwingConstants;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpPassword;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAmpPassword extends FormatterFor_default {

   @Override
   public String format(Asn1Type value) {
      if (value instanceof AmpPassword)
         return "*****";
      else if (value == null)
         return "null";
      else
         throw new ClassCastException("FormatterForAmpPassword: Expected AmpPassword, got " + value.getClass().getSimpleName());
   }

   @Override
   public int getAlignment() {
      return SwingConstants.LEADING;
   }
}
