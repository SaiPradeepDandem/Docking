package xstr.icap.amp.impl;

import java.util.Comparator;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnFixedReal;
import xstr.amp.impl.ComparatorForAsn1Real;

enum ComparatorForAsnFixedReal implements Comparator<Asn1Type> {
	INSTANCE;
	@Override
	public int compare(Asn1Type lhs, Asn1Type rhs) {
		if (lhs == rhs)	return 0;
		if (lhs == null) return -1;
		if (rhs == null) return 1;
		if (lhs instanceof AsnFixedReal && rhs instanceof AsnFixedReal) {
			return ComparatorForAsn1Real.INSTANCE.compare(((AsnFixedReal)lhs).getValue(), ((AsnFixedReal)rhs).getValue());
		} else
			throw new ClassCastException();
	}
}
