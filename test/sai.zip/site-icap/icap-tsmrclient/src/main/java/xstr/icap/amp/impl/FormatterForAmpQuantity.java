package xstr.icap.amp.impl;

import java.text.NumberFormat;

import javax.swing.SwingConstants;

import com.objsys.asn1j.runtime.Asn1Integer;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpQuantity;
import xstr.amp.impl.FormatterFor_default;

class FormatterForAmpQuantity extends FormatterFor_default {

   NumberFormat nf = NumberFormat.getNumberInstance();
   @Override
   public String format(Asn1Type value) {
      if (value instanceof AmpQuantity) {
         AmpQuantity frValue = (AmpQuantity)value;
         Asn1Integer decimals = frValue.getDecimals();
         if (decimals == null) {
            nf.setMaximumFractionDigits(4);
            nf.setMinimumFractionDigits(0);
         } else {
            nf.setMaximumFractionDigits((int) decimals.value);
            nf.setMinimumFractionDigits(0);
         }
         if (frValue.getValue() == null) {
            System.err.println("AmpQuantity.value is null. decimals is "+decimals);
            return "null";
         } else {
            return nf.format(frValue.getValue().value);
         }
      }
      else if (value == null)
         throw new NullPointerException("AmpQuantityFormatter: Cannot format null value");
      else
         throw new ClassCastException("AmpQuantityFormatter: Expected AsnFixedReal, got " + value.getClass().getSimpleName());
   }

   @Override
   public int getAlignment() {
      return SwingConstants.TRAILING;
   }
}
