package xstr.icap.csdk;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xmp.message.XMP.RowCommand;
import xmp.message.XMP.XmpAmpQReqBer;
import xmp.message.XMP.XmpAmpTReqBer;
import xmp.message.XMP.XmpQueryReply;
import xmp.message.XMP.XmpQueryRequest;
import xmp.message.XMP.XmpSubscriptionReply;
import xmp.message.XMP.XmpTransactionReply;
import xmp.message.XMP.XmpTransactionRequest;
import xmp.message.XMP.XmpTransactionRequest.Builder;
import xstr.amp.ASN;
import xstr.util.exception.AsnTypeException;

import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.Multimaps;
import com.google.protobuf.ByteString;
import xstr.session.XtrTransReply;
import com.omxgroup.xstream.api.CIKey;
import com.omxgroup.xstream.api.QueryReply;
import com.omxgroup.xstream.api.QueryRequest;
import com.omxgroup.xstream.api.TransReply;
import com.omxgroup.xstream.api.TransRequest;
import com.omxgroup.xstream.api.cometheader.UserId;

public class ICAP {
   private static final Logger logger = LoggerFactory.getLogger(ICAP.class);

   private static final AtomicInteger nextQueryId = new AtomicInteger(0);

   public static XmpSubscriptionReply tsmrToXmp(long seqNo, long id, QueryReply[] replies, Map<CIKey, byte[]> cookies) {
      XmpSubscriptionReply.Builder replyBuilder = XmpSubscriptionReply.newBuilder().setSeqNo(seqNo).setId(id);

      // Group all replies by their group_id
      ImmutableListMultimap<Long, QueryReply> groupedReplies = Multimaps.index(Arrays.asList(replies), rep -> rep.group_id().value);

      for (Entry<CIKey, byte[]> entry : cookies.entrySet()) {
         long gid = entry.getKey().group_id();
         try {
            replyBuilder.addReplyGroup(tsmrToXmp(gid, groupedReplies.get(gid), entry.getValue()));
         } catch (AsnTypeException e) {
            logger.error("Error creating reply group:", e);
         }
      }
      return replyBuilder.build();

   }

   public static XmpQueryRequest tsmrToXmp(QueryRequest req, byte[] cookie) throws AsnTypeException {
      try {
         long id = req.group_id();
         if (id <= 0) {
            id = nextQueryId.incrementAndGet();
            req.group_id(id);
         }
         XmpQueryRequest.Builder builder = XmpQueryRequest.newBuilder().setId(id)
               .setRequest(XmpAmpQReqBer.newBuilder().setValue(ByteString.copyFrom(ASN.encode(req.message()))));
         if (cookie != null && cookie.length > 0) {
            builder.setCookie(ByteString.copyFrom(cookie));
         } else {
            builder.setCookie(ByteString.EMPTY);
         }
         if (req.subject_user() != null &&
             req.subject_user().value != null &&
            req.subject_user().value.length > 0) {
            builder.setSubjectUser(new String(req.subject_user().value, "US-ASCII"));
         }
         return builder.build();
      } catch (Exception e) {
         throw new AsnTypeException(e.getMessage(), e);
      }
   }

   public static XmpTransactionReply tsmrToXmp(TransReply rep, long id) throws AsnTypeException {
      try {
         XmpTransactionReply.Builder builder = XmpTransactionReply.newBuilder().setSeqNo(id);
         builder.getReplyBuilder().setValue(ByteString.copyFrom(ASN.encode(rep.message())));
         return builder.build();
      } catch (Exception e) {
         throw new AsnTypeException(e.getMessage(), e);
      }
   }

   private static XmpQueryReply tsmrToXmp(long groupId, List<QueryReply> req, byte[] cookie) throws AsnTypeException {
      try {
         XmpQueryReply.Builder builder = XmpQueryReply.newBuilder().setId(groupId).setCookie(ByteString.copyFrom(cookie));
         for (QueryReply row : req) {
            builder.addRowBuilder().setCmd(RowCommand.valueOf(row.command().value)).setKey(ByteString.copyFrom(row.key().value)).getDataBuilder()
                  .setValue(ByteString.copyFrom(ASN.encode(row.message())));
         }
         return builder.build();
      } catch (Exception e) {
         throw new AsnTypeException(e.getMessage(), e);
      }
   }

   public static XmpTransactionRequest tsmrToXmp(TransRequest req, long id) throws AsnTypeException {
      try {
         Builder builder = XmpTransactionRequest.newBuilder().setSeqNo(id)
               .setRequest(XmpAmpTReqBer.newBuilder().setValue(ByteString.copyFrom(ASN.encode(req.message()))));
         if (req.subject_user() != null &&
            req.subject_user().value != null &&
            req.subject_user().value.length > 0) {
            builder.setSubjectUser(new String(req.subject_user().value, "US-ASCII"));
         }
         return builder.build();
      } catch (Exception e) {
         throw new AsnTypeException(e.getMessage(), e);
      }

   }

   public static QueryRequest xmpToTsmr(XmpQueryRequest xmpReq) throws AsnTypeException {
      try {
         QueryRequest ampReq = new QueryRequest();
         ampReq.group_id(xmpReq.getId());
         if (xmpReq.hasSubjectUser()) {
            ampReq.subject_user(new UserId(xmpReq.getSubjectUser()));
         }
         ASN.decode(ampReq.message(), xmpReq.getRequest().getValue().toByteArray());
         return ampReq;
      } catch (Exception e) {
         throw new AsnTypeException(e.getMessage(), e);
      }
   }

   public static TransRequest xmpToTsmr(XmpTransactionRequest req) throws AsnTypeException {
      try {
         TransRequest transactionRequest = new TransRequest();
         ASN.decode(transactionRequest.message(), req.getRequest().getValue().toByteArray());
         if (req.hasSubjectUser()) {
            transactionRequest.subject_user(new UserId(req.getSubjectUser()));
         }
         return transactionRequest;
      } catch (Exception e) {
         throw new AsnTypeException(e.getMessage(), e);
      }
   }

   public static XtrTransReply xmpToLocal(XmpTransactionReply rep) throws AsnTypeException {
	   byte[] byteArray = rep.getReply().getValue().toByteArray();
	   if (byteArray.length == 0) {
		   return new ICAPTransReply(rep.getErrorMessage());
	   }
      return new ICAPTransReply(byteArray);
   }
}
