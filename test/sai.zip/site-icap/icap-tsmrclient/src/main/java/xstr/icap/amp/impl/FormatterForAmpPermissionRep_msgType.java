package xstr.icap.amp.impl;

import java.util.HashMap;
import java.util.Map.Entry;

import xstr.amp.impl.FormatterFor_default;
import xstr.icap.csdk.SiteInfo;
import com.objsys.asn1j.runtime.Asn1Integer;
import com.objsys.asn1j.runtime.Asn1Type;

class FormatterForAmpPermissionRep_msgType extends FormatterFor_default {

        private static final HashMap<Long, String> idToMsgMap = new HashMap<Long, String>();

        static {
            for (Entry<String, Long> entry: SiteInfo.getMsgIdMap().entrySet()) {
                idToMsgMap.put(entry.getValue(), entry.getKey());
            }
        }

	@Override
	public String format(Asn1Type value) {
		if (value instanceof Asn1Integer)
                    return idToMsgMap.get(((Asn1Integer)value).value);
                else if (value == null)
			throw new NullPointerException("Asn1IntegerFormatter: Cannot format null value");
		else
			throw new ClassCastException("Asn1IntegerFormatter: Expected Asn1Integer, got " + value.getClass().getSimpleName());
	}

}
