package xstr.icap.amp;


import com.omxgroup.xstream.api.QueryRequest;
import com.omxgroup.xstream.api.TransRequest;
import com.omxgroup.xstream.api.cometheader.UserId;

import java.io.UnsupportedEncodingException;

public class XSDK {

   public static String toString(UserId id) {
         if (id != null) {
            try {
               if (id.value == null) return "";
               return new String(id.value, "US-ASCII");
            } catch (UnsupportedEncodingException e) {
               e.printStackTrace();
               return "";
            }
         } else {
            return "";
         }
   }

   public static String getSubjectUser(TransRequest req) {
      return toString(req.subject_user());
   }

   public static String getSubjectUser(QueryRequest req) {
      return toString(req.subject_user());
   }


}
