Maven repository of XFE dependencies
====================================
This archive contains all the dependencies that are required to build XFE.

Content
-------
This archive contains the following:
  * README - This file
  * deployXfeSdk.sh - Script to deploy non-public XFE dependencies to a local Maven mirror (e.g. Nexus)
  * .repository - Local Maven repository cache containing all required dependencies to build XFE

Usage: Building XFE locally
---------------------------
To build locally either copy the repository directory to ~/.m2/repository or set up the appropriate Maven
environment variables to use the repository from its current location.

Usage: Deploy dependencies to Maven mirror server
-------------------------------------------------
To install the dependencies to a Maven mirror server run the deployXfeSdk.sh script with the deployment URL.

E.g.: $> ./deployXfeSdk.sh http://localhost:8044/nexus/content/repositories/releases

NOTE: This will only install the non-public dependencies (i.e. The SDK Jars like Amp, tsmr etc.). The Maven
mirror should be configured to pull all public dependencies from Maven central and/or other public Maven
repositories.
