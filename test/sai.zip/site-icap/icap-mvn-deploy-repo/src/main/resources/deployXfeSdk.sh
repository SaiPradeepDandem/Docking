#!/bin/bash

if [ -z $1 ]
then
	echo "Usage: $0 <Maven_deploy_url>"
	echo "E.g.: $0 http://localhost:8044/nexus/content/repositories/releases"
	exit 1
fi

BASE_DIR=.
DEPLOY_URL=$1

SDK_VER=${project.version}
SDK_DIR=$BASE_DIR/.repository/com/omxgroup/xstream/ICAP-xstream_api/$SDK_VER
SDK_POM=$SDK_DIR/ICAP-xstream_api-$SDK_VER.pom
SDK_JAR=$SDK_DIR/ICAP-xstream_api-$SDK_VER.jar

AMP_VER=`grep -A2 -B2  "<artifactId>ICAP-amp</artifactId>" $SDK_POM \
    | sed -n 's:.*<version>\(.*\)</version>.*:\1:p'`
AMP_DIR=$BASE_DIR/.repository/com/omxgroup/xstream/ICAP-amp/$AMP_VER
AMP_POM=$AMP_DIR/ICAP-amp-$AMP_VER.pom
AMP_JAR=$AMP_DIR/ICAP-amp-$AMP_VER.jar

TSMR_VER=`grep -A2 -B2  "<artifactId>tsmr</artifactId>" $SDK_POM \
    | sed -n 's:.*<version>\(.*\)</version>.*:\1:p'`
TSMR_DIR=$BASE_DIR/.repository/com/omxgroup/xstream/tsmr/$TSMR_VER
TSMR_POM=$TSMR_DIR/tsmr-$TSMR_VER.pom
TSMR_JAR=$TSMR_DIR/tsmr-$TSMR_VER.jar

SYSSRV_VER=`grep -A2 -B2  "<artifactId>syssrv</artifactId>" $TSMR_POM \
    | sed -n 's:.*<version>\(.*\)</version>.*:\1:p'`
SYSSRV_DIR=$BASE_DIR/.repository/com/omxgroup/xstream/syssrv/$SYSSRV_VER
SYSSRV_POM=$SYSSRV_DIR/syssrv-$SYSSRV_VER.pom
SYSSRV_JAR=$SYSSRV_DIR/syssrv-$SYSSRV_VER.jar

echo SDK: $SDK_DIR
echo TSMR: $TSMR_DIR
echo SYSSRV: $SYSSRV_DIR
echo AMP: $AMP_DIR
echo

echo #--------------------  DEPLOY AMP  ------------------------------
mvn deploy:deploy-file \
  -DrepositoryId=Releases \
  -Durl=$DEPLOY_URL \
  -Dfile=$AMP_JAR \
  -DpomFile=$AMP_POM
echo
echo #--------------------  DEPLOY SYSSRV  ------------------------------
mvn deploy:deploy-file \
  -DrepositoryId=Releases \
  -Durl=$DEPLOY_URL \
  -Dfile=$SYSSRV_JAR \
  -DpomFile=$SYSSRV_POM
echo
echo #--------------------  DEPLOY TSMR  ------------------------------
mvn deploy:deploy-file \
  -DrepositoryId=Releases \
  -Durl=$DEPLOY_URL \
  -Dfile=$TSMR_JAR \
  -DpomFile=$TSMR_JAR
echo
echo #--------------------  DEPLOY CLIENT SDK  ------------------------------
mvn deploy:deploy-file \
  -DrepositoryId=Releases \
  -Durl=$DEPLOY_URL \
  -Dfile=$SDK_JAR \
  -DpomFile=$SDK_POM
