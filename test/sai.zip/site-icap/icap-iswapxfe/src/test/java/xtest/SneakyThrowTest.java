package xtest;

public class SneakyThrowTest {
	@SuppressWarnings("serial")
	public static class Ex extends Exception {
	}

	public static RuntimeException sneakyThrow(Throwable t) {
		if (t == null)
			throw new NullPointerException("t");
		sneakyThrow0(t);
		return null;
	}

	@SuppressWarnings("unchecked")
	private static <T extends Throwable> void sneakyThrow0(Throwable t) throws T {
		throw (T) t;
	}

	public static void test() {
		sneakyThrow(new Ex());
	}

	public static void main(String[] args) {
		try {
			test();
		} catch (Throwable t) {
			System.out.println(t);
		}
	}
}
