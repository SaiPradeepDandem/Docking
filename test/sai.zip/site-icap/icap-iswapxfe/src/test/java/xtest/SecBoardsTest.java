package xtest;

import java.util.List;

import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.util.Callback;

import xfe.types.SecBoard;
import xfe.icap.SimpleLogonApplicationModule;
import xfe.icap.XfeSession;

public class SecBoardsTest extends SimpleLogonApplicationModule {
   @Override
   protected void initApp() {
      onLogoff();
   }

//   public static void main(String[] args) {
//      launch(args);
//   }

   @Override
   protected void onLogon(XfeSession session) {

      ListView<SecBoard> lv = new ListView<SecBoard>();

      // lv.setItems(session.getSecBoards().getAll());
      Callback<List<SecBoard>, Void> cb = new Callback<List<SecBoard>, Void>() {
         @Override
         public Void call(List<SecBoard> secboards) {
            lv.getItems().addAll(secboards);
            return null;
         }
      };

      session.secBoards.get().findAll(cb);
      setApplicationRootNode(lv);
   }

   @Override
   protected void onLogoff() {
      setApplicationRootNode(new Label("Table Example - Logged off"));
   }

   public List<Image> getIcons() {
      // TODO Auto-generated method stub
      return null;
   }
}
