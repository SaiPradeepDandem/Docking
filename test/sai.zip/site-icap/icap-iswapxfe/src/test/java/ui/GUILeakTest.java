package ui;


import javafx.scene.layout.VBox;
import xstr.util.Fx;

import javafx.application.*;
import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.*;

public class GUILeakTest extends Application{
   private Stage dialogStage;
   private void buildDialog() {
        dialogStage = new Stage(StageStyle.TRANSPARENT);
//        dialogStage.initModality(Modality.WINDOW_MODAL);
        Button close = new Button("Ok");
        close.setOnAction(new EventHandler<ActionEvent>() {
             @Override
             public void handle(ActionEvent e) {
                  dialogStage.close();
             }
        });
        close.setId("close-dialog-id");
        VBox vb = new VBox();
        vb.getChildren().addAll(new Text("Hi"), close);
        vb.setAlignment(Pos.CENTER);
        vb.setPadding(new Insets(5));
        Scene scene = new Scene(vb);
        dialogStage.setX(100);
        dialogStage.setY(100);
        dialogStage.setWidth(300);
        dialogStage.setHeight(300);
        dialogStage.setScene(scene);
        scene.getRoot().setId("dialog-scene-root");
   }

   @Override
   public void start(Stage primaryStage) throws Exception {
      primaryStage.setTitle("GDI leak test");
      buildDialog();
      Button show = new Button("show");
      show.setOnMouseClicked(new EventHandler<MouseEvent>() {

         @Override
         public void handle(MouseEvent event) {
            dialogStage.show();
         }
      });

      Button hide = new Button("hide");
      hide.setOnMouseClicked(new EventHandler<MouseEvent>() {

         @Override
         public void handle(MouseEvent event) {
            dialogStage.hide();
         }
      });

      Button close = new Button("close");
      close.setOnMouseClicked(new EventHandler<MouseEvent>() {

         @Override
         public void handle(MouseEvent event) {
            dialogStage.close();
         }
      });

      Button showhide = new Button("show/hide forever");
      showhide.setOnMouseClicked(new EventHandler<MouseEvent>() {

         @Override
         public void handle(MouseEvent event) {
            Runnable runnable = new Runnable() {

               @Override
               public void run() {

                        if(dialogStage.isShowing())
                           dialogStage.hide();
                        else
                           dialogStage.show();

                        Fx.delay(1000L,this);
                     }
            };
            Fx.delay(1000L,runnable);
            dialogStage.show();
         }
      });

      VBox vb = new VBox();
      vb.getChildren().addAll(show, hide,close,showhide);
      vb.setAlignment(Pos.CENTER);
      vb.setPadding(new Insets(5));

      Scene mainScene = new Scene(vb);
      mainScene.getRoot().setId("main");
      primaryStage.setWidth(200);
      primaryStage.setHeight(200);
      primaryStage.setScene(mainScene);
      primaryStage.show();
   }

   public static void main(String[] args){
      Application.launch(args);
   }
}
