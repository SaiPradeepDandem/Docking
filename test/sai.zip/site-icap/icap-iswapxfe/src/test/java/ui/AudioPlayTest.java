package ui;


import javafx.scene.layout.VBox;
import xstr.util.Fx;

import javafx.application.*;
import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.AudioClip;
import javafx.stage.*;

public class AudioPlayTest extends Application{
   static AudioClip tradeAlert = new AudioClip(xfe.icap.modules.iswaptrades.TradeNotificationsModule.class.getResource("/css/tradeAlert.wav").toString());
   int time;
   @Override
   public void start(Stage primaryStage) throws Exception {
      primaryStage.setTitle("GDI leak test");
      Button show = new Button("show");
      show.setOnMouseClicked(new EventHandler<MouseEvent>() {

         @Override
         public void handle(MouseEvent event) {
            Thread t = new Thread(){
               public void run() {
                  while(true){
                     Fx.run(new Runnable(){

                        @Override
                        public void run() {
                           tradeAlert.play();
                           time ++;
                           System.out.println("audio played for "+time+" times");
                        }
                     });
                  try {
                     Thread.sleep(1000L);
                  } catch (Exception e) {
                     // TODO: handle exception
                  }
               }
                  }
            };
               t.start();

//            dialogStage.show();
         }
      });

      VBox vb = new VBox();
      vb.getChildren().add(show);
      vb.setAlignment(Pos.CENTER);
      vb.setPadding(new Insets(5));

      Scene mainScene = new Scene(vb);
      mainScene.getRoot().setId("main");
      primaryStage.setWidth(200);
      primaryStage.setHeight(200);
      primaryStage.setScene(mainScene);
      primaryStage.show();
   }

   public static void main(String[] args){
      Application.launch(args);
   }
}
