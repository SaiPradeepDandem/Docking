package ui;

import xfe.icap.modules.dev.LoggerLevelConfigView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * Created by jiadin on 2015-03-25.
 */
public class ClassNameInputTest extends Application{

   @Override
   public void start(Stage primaryStage) throws Exception {
      HBox box = new HBox();
      box.getChildren().add(new LoggerLevelConfigView().getRootElement());
      Scene scene = new Scene(box);
      primaryStage.setScene(scene);
      primaryStage.setHeight(200);
      primaryStage.setWidth(200);
      primaryStage.show();

   }
}
