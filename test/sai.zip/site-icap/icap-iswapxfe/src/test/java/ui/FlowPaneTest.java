package ui;

import static javafx.geometry.Orientation.HORIZONTAL;

import javafx.application.Application;
import javafx.beans.property.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class FlowPaneTest extends Application{


   static int index;
   static Label[] labels = {new Label("first"),new Label("second"),new Label("third"),new Label("forth"),new Label("fifth"),new Label("sixth"),new Label("seventh"),new Label("eighth"),new Label("ninth"),new Label("tenth"),new Label("eleventh"),new Label("first"),new Label("second"),new Label("third"),new Label("forth"),new Label("fifth"),new Label("sixth"),new Label("seventh"),new Label("eighth"),new Label("ninth"),new Label("tenth"),new Label("eleventh"),new Label("first"),new Label("second"),new Label("third"),new Label("forth"),new Label("fifth"),new Label("sixth"),new Label("seventh"),new Label("eighth"),new Label("ninth"),new Label("tenth"),new Label("eleventh")};

   @Override
   public void start(Stage primaryStage) throws Exception {
      IntegerProperty indexp = new SimpleIntegerProperty(0);
      FlowPane flowPane = new FlowPane(HORIZONTAL);
      ScrollPane scrollPane = new ScrollPane(flowPane);
      scrollPane.setHbarPolicy(ScrollBarPolicy.NEVER);
      scrollPane.setHvalue(1);
      flowPane.setAlignment(Pos.CENTER_RIGHT);
      flowPane.setRowValignment(VPos.CENTER);
      flowPane.setColumnHalignment(HPos.LEFT);
      flowPane.setHgap(0);
      flowPane.setPrefWrapLength(500);
      flowPane.setMinWidth(500);
      Scene scene = new Scene(scrollPane);
      primaryStage.setScene(scene);
      primaryStage.setWidth(300);
      primaryStage.setHeight(200);
      primaryStage.show();

//      for(Label l : labels){
//         l.setMaxWidth(0);
//         flowPane.getChildren().add(l);
//      }
//
//      double endWidth = 100;

//      final Timeline animation = new Timeline();
//      animation.getKeyFrames().add(new KeyFrame(Duration.seconds(1), new KeyValue(node.maxWidthProperty(), endWidth)));
//      animation.setOnFinished(new EventHandler<ActionEvent>() {
//
//         @Override
//         public void handle(ActionEvent event) {
//            if(flowPane.getChildren().size()>11){
//               flowPane.getChildren().remove(0);
//            }
//            animation.getKeyFrames().clear();
//         }
//      });
//      animation.play();


//      while(indexp.get()<labels.length){
//         final int i = indexp.get();
//         indexp.set(i+1);
//         Fx.delay(i*6000, new Runnable() {
//
//            @Override
//            public void run() {
//               final Label label = labels[i];
//               label.setEllipsisString("");
//               label.setMaxWidth(0);
//               final double endWidth = 100;
//               System.out.println("endwidth is "+endWidth);
//               flowPane.getChildren().add(label);
//               Timeline animation = new Timeline();
//               animation.getKeyFrames().add(new KeyFrame(Duration.seconds(5), new KeyValue(label.maxWidthProperty(), endWidth)));
//               animation.play();
//               animation.setOnFinished(new EventHandler<ActionEvent>() {
//
//                  @Override
//                  public void handle(ActionEvent event) {
//                     if(flowPane.getChildren().size()>11){
//                        System.out.println("remove the first element");
//                        flowPane.getChildren().remove(0);
//                     }
//                  }
//               });
//            }
//         });
//      };
   }

   public static void main(String[] args){
      Application.launch(args);
   }

}
