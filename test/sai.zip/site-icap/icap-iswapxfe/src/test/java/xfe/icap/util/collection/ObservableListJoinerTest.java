package xfe.icap.util.collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import org.junit.Before;
import org.junit.Test;
import xstr.util.collection.ObservableListJoiner;

public class ObservableListJoinerTest {

	private ObservableList<String> l1;
	private ObservableList<String> l2;
	private ObservableListJoiner<String> lJoin;

	@Before
	public void setUp() {
		l1 = FXCollections.observableArrayList("AAA", "BBB", "CCC", "DDD");
		l2 = FXCollections.observableArrayList("111", "222", "333", "555");
		lJoin = new ObservableListJoiner<String>(l1, l2);

		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
	}

	@Test
	public void testAdd() {
		String a1 = "ZZZ";
		String a2 = "999";
		assertFalse(l1.contains(a1));
		assertFalse(lJoin.getItems().contains(a1));
		assertFalse(l2.contains(a2));
		assertFalse(lJoin.getItems().contains(a2));
		l1.add(a1);
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
		assertTrue(lJoin.getItems().contains(a1));
		l2.add(a2);
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
		assertTrue(lJoin.getItems().contains(a2));
	}

	@Test
	public void testAddAll() {
		List<String> a1 = Arrays.asList("QQQ", "RRR", "SSS");
		List<String> a2 = Arrays.asList("988", "977", "966");
		l1.addAll(a1);
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
		assertTrue(lJoin.getItems().containsAll(a1));
		l2.addAll(a2);
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
		assertTrue(lJoin.getItems().containsAll(a2));
	}

	@Test
	public void testRemove() {
		assertTrue(lJoin.getItems().contains("BBB"));
		l1.remove("BBB");
		assertFalse(lJoin.getItems().contains("BBB"));
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
		assertTrue(lJoin.getItems().contains("222"));
		l2.remove("222");
		assertFalse(lJoin.getItems().contains("222"));
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
	}

	@Test
	public void testClear() {
		l1.clear();
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
		l2.clear();
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
	}

	@Test
	public void testReplace() {
		int i1 = l1.indexOf("BBB");
		assertTrue(i1 >= 0);
		int i2 = l2.indexOf("222");
		assertTrue(i2 >= 0);
		assertTrue(lJoin.getItems().contains("BBB"));
		assertTrue(lJoin.getItems().contains("222"));
		assertFalse(lJoin.getItems().contains("ZZZ"));
		assertFalse(lJoin.getItems().contains("999"));
		l1.set(i1, "ZZZ");
		assertTrue(lJoin.getItems().contains("ZZZ"));
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
		l2.set(i2, "999");
		assertTrue(lJoin.getItems().contains("999"));
		assertEquals(l1.size() + l2.size(), lJoin.getItems().size());
	}

}
