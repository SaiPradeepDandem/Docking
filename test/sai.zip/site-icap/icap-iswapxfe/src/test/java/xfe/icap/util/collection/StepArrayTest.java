package xfe.icap.util.collection;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import xfe.types.StepArray;

public class StepArrayTest {
	final StepArray stepArray = new StepArray() {{
		this.addStep(0.0, 0.3);
		this.addStep(1.0, 1.0);
		this.addStep(10.0, 5.0);
	}};

	public double down(double value) {
		return stepArray.notch(value, -1);
	}

	public double up(double value) {
		return stepArray.notch(value, +1);
	}

	private static final double epsilon = 1.0 / 1000000;

	@Test
	public void testMethod() {
		assertEquals(down(-25.00), -30.00, epsilon); assertEquals(up(-25.00), -20.00, epsilon);
		assertEquals(down(-24.90), -25.00, epsilon); assertEquals(up(-24.90), -20.00, epsilon);

		assertEquals(down(-20.10), -25.00, epsilon); assertEquals(up(-20.10), -20.00, epsilon);
		assertEquals(down(-20.00), -25.00, epsilon); assertEquals(up(-20.00), -15.00, epsilon);
		assertEquals(down(-19.90), -20.00, epsilon); assertEquals(up(-19.90), -15.00, epsilon);

		assertEquals(down(-15.10), -20.00, epsilon); assertEquals(up(-15.10), -15.00, epsilon);
		assertEquals(down(-15.00), -20.00, epsilon); assertEquals(up(-15.00), -10.00, epsilon);
		assertEquals(down(-14.90), -15.00, epsilon); assertEquals(up(-14.90), -10.00, epsilon);

		assertEquals(down(-10.10), -15.00, epsilon); assertEquals(up(-10.10), -10.00, epsilon);
		assertEquals(down(-10.00), -15.00, epsilon); assertEquals(up(-10.00), -09.00, epsilon);
		assertEquals(down(-09.90), -10.00, epsilon); assertEquals(up(-09.90), -09.00, epsilon);

		assertEquals(down(-09.10), -10.00, epsilon); assertEquals(up(-09.10), -09.00, epsilon);
		assertEquals(down(-09.00), -10.00, epsilon); assertEquals(up(-09.00), -08.00, epsilon);
		assertEquals(down(-08.90), -09.00, epsilon); assertEquals(up(-08.90), -08.00, epsilon);

		assertEquals(down(-08.10), -09.00, epsilon); assertEquals(up(-08.10), -08.00, epsilon);
		assertEquals(down(-08.00), -09.00, epsilon); assertEquals(up(-08.00), -07.00, epsilon);
		assertEquals(down(-07.90), -08.00, epsilon); assertEquals(up(-07.90), -07.00, epsilon);

		assertEquals(down(-07.10), -08.00, epsilon); assertEquals(up(-07.10), -07.00, epsilon);
		assertEquals(down(-07.00), -08.00, epsilon); assertEquals(up(-07.00), -06.00, epsilon);
		assertEquals(down(-06.90), -07.00, epsilon); assertEquals(up(-06.90), -06.00, epsilon);

		assertEquals(down(-06.10), -07.00, epsilon); assertEquals(up(-06.10), -06.00, epsilon);
		assertEquals(down(-06.00), -07.00, epsilon); assertEquals(up(-06.00), -05.00, epsilon);
		assertEquals(down(-05.90), -06.00, epsilon); assertEquals(up(-05.90), -05.00, epsilon);

		assertEquals(down(-05.10), -06.00, epsilon); assertEquals(up(-05.10), -05.00, epsilon);
		assertEquals(down(-05.00), -06.00, epsilon); assertEquals(up(-05.00), -04.00, epsilon);
		assertEquals(down(-04.90), -05.00, epsilon); assertEquals(up(-04.90), -04.00, epsilon);

		assertEquals(down(-04.10), -05.00, epsilon); assertEquals(up(-04.10), -04.00, epsilon);
		assertEquals(down(-04.00), -05.00, epsilon); assertEquals(up(-04.00), -03.00, epsilon);
		assertEquals(down(-03.90), -04.00, epsilon); assertEquals(up(-03.90), -03.00, epsilon);

		assertEquals(down(-03.10), -04.00, epsilon); assertEquals(up(-03.10), -03.00, epsilon);
		assertEquals(down(-03.00), -04.00, epsilon); assertEquals(up(-03.00), -02.00, epsilon);
		assertEquals(down(-02.90), -03.00, epsilon); assertEquals(up(-02.90), -02.00, epsilon);

		assertEquals(down(-02.10), -03.00, epsilon); assertEquals(up(-02.10), -02.00, epsilon);
		assertEquals(down(-02.00), -03.00, epsilon); assertEquals(up(-02.00), -01.00, epsilon);
		assertEquals(down(-01.90), -02.00, epsilon); assertEquals(up(-01.90), -01.00, epsilon);

		assertEquals(down(-01.10), -02.00, epsilon); assertEquals(up(-01.10), -01.00, epsilon);
		assertEquals(down(-01.00), -02.00, epsilon); assertEquals(up(-01.00), -00.90, epsilon);
		assertEquals(down(-00.99), -01.00, epsilon); assertEquals(up(-00.99), -00.90, epsilon);

		assertEquals(down(-00.91), -01.00, epsilon); assertEquals(up(-00.91), -00.90, epsilon);
		assertEquals(down(-00.90), -01.00, epsilon); assertEquals(up(-00.90), -00.60, epsilon);
		assertEquals(down(-00.89), -00.90, epsilon); assertEquals(up(-00.89), -00.60, epsilon);

		assertEquals(down(-00.61), -00.90, epsilon); assertEquals(up(-00.61), -00.60, epsilon);
		assertEquals(down(-00.60), -00.90, epsilon); assertEquals(up(-00.60), -00.30, epsilon);
		assertEquals(down(-00.59), -00.60, epsilon); assertEquals(up(-00.59), -00.30, epsilon);

		assertEquals(down(-00.31), -00.60, epsilon); assertEquals(up(-00.31), -00.30, epsilon);
		assertEquals(down(-00.30), -00.60, epsilon); assertEquals(up(-00.30),  00.00, epsilon);
		assertEquals(down(-00.29), -00.30, epsilon); assertEquals(up(-00.29),  00.00, epsilon);

		assertEquals(down(-00.09), -00.30, epsilon); assertEquals(up(-00.01),  00.00, epsilon);
		assertEquals(down( 00.00), -00.30, epsilon); assertEquals(up( 00.00), +00.30, epsilon);
		assertEquals(down(+00.01),  00.00, epsilon); assertEquals(up(+00.01), +00.30, epsilon);

		assertEquals(down(+00.29),  00.00, epsilon); assertEquals(up(+00.29), +00.30, epsilon);
		assertEquals(down(+00.30),  00.00, epsilon); assertEquals(up(+00.30), +00.60, epsilon);
		assertEquals(down(+00.31), +00.30, epsilon); assertEquals(up(+00.31), +00.60, epsilon);

		assertEquals(down(+00.59), +00.30, epsilon); assertEquals(up(+00.59), +00.60, epsilon);
		assertEquals(down(+00.60), +00.30, epsilon); assertEquals(up(+00.60), +00.90, epsilon);
		assertEquals(down(+00.61), +00.60, epsilon); assertEquals(up(+00.61), +00.90, epsilon);

		assertEquals(down(+00.89), +00.60, epsilon); assertEquals(up(+00.89), +00.90, epsilon);
		assertEquals(down(+00.90), +00.60, epsilon); assertEquals(up(+00.90), +01.00, epsilon);
		assertEquals(down(+00.91), +00.90, epsilon); assertEquals(up(+00.91), +01.00, epsilon);

		assertEquals(down(+00.99), +00.90, epsilon); assertEquals(up(+00.99), +01.00, epsilon);
		assertEquals(down(+01.00), +00.90, epsilon); assertEquals(up(+01.00), +02.00, epsilon);
		assertEquals(down(+01.10), +01.00, epsilon); assertEquals(up(+01.10), +02.00, epsilon);

		assertEquals(down(+01.90), +01.00, epsilon); assertEquals(up(+01.90), +02.00, epsilon);
		assertEquals(down(+02.00), +01.00, epsilon); assertEquals(up(+02.00), +03.00, epsilon);
		assertEquals(down(+02.10), +02.00, epsilon); assertEquals(up(+02.10), +03.00, epsilon);

		assertEquals(down(+02.90), +02.00, epsilon); assertEquals(up(+02.90), +03.00, epsilon);
		assertEquals(down(+03.00), +02.00, epsilon); assertEquals(up(+03.00), +04.00, epsilon);
		assertEquals(down(+03.10), +03.00, epsilon); assertEquals(up(+03.10), +04.00, epsilon);

		assertEquals(down(+03.90), +03.00, epsilon); assertEquals(up(+03.90), +04.00, epsilon);
		assertEquals(down(+04.00), +03.00, epsilon); assertEquals(up(+04.00), +05.00, epsilon);
		assertEquals(down(+04.10), +04.00, epsilon); assertEquals(up(+04.10), +05.00, epsilon);

		assertEquals(down(+04.90), +04.00, epsilon); assertEquals(up(+04.90), +05.00, epsilon);
		assertEquals(down(+05.00), +04.00, epsilon); assertEquals(up(+05.00), +06.00, epsilon);
		assertEquals(down(+05.10), +05.00, epsilon); assertEquals(up(+05.10), +06.00, epsilon);

		assertEquals(down(+05.90), +05.00, epsilon); assertEquals(up(+05.90), +06.00, epsilon);
		assertEquals(down(+06.00), +05.00, epsilon); assertEquals(up(+06.00), +07.00, epsilon);
		assertEquals(down(+06.10), +06.00, epsilon); assertEquals(up(+06.10), +07.00, epsilon);

		assertEquals(down(+06.90), +06.00, epsilon); assertEquals(up(+06.90), +07.00, epsilon);
		assertEquals(down(+07.00), +06.00, epsilon); assertEquals(up(+07.00), +08.00, epsilon);
		assertEquals(down(+07.10), +07.00, epsilon); assertEquals(up(+07.10), +08.00, epsilon);

		assertEquals(down(+07.90), +07.00, epsilon); assertEquals(up(+07.90), +08.00, epsilon);
		assertEquals(down(+08.00), +07.00, epsilon); assertEquals(up(+08.00), +09.00, epsilon);
		assertEquals(down(+08.10), +08.00, epsilon); assertEquals(up(+08.10), +09.00, epsilon);

		assertEquals(down(+08.90), +08.00, epsilon); assertEquals(up(+08.90), +09.00, epsilon);
		assertEquals(down(+09.00), +08.00, epsilon); assertEquals(up(+09.00), +10.00, epsilon);
		assertEquals(down(+09.10), +09.00, epsilon); assertEquals(up(+09.10), +10.00, epsilon);

		assertEquals(down(+09.90), +09.00, epsilon); assertEquals(up(+09.90), +10.00, epsilon);
		assertEquals(down(+10.00), +09.00, epsilon); assertEquals(up(+10.00), +15.00, epsilon);
		assertEquals(down(+10.10), +10.00, epsilon); assertEquals(up(+10.10), +15.00, epsilon);

		assertEquals(down(+14.90), +10.00, epsilon); assertEquals(up(+14.90), +15.00, epsilon);
		assertEquals(down(+15.00), +10.00, epsilon); assertEquals(up(+15.00), +20.00, epsilon);
		assertEquals(down(+15.10), +15.00, epsilon); assertEquals(up(+15.10), +20.00, epsilon);

		assertEquals(down(+19.90), +15.00, epsilon); assertEquals(up(+19.90), +20.00, epsilon);
		assertEquals(down(+20.00), +15.00, epsilon); assertEquals(up(+20.00), +25.00, epsilon);
		assertEquals(down(+20.10), +20.00, epsilon); assertEquals(up(+20.10), +25.00, epsilon);

		assertEquals(down(+24.90), +20.00, epsilon); assertEquals(up(+24.90), +25.00, epsilon);
		assertEquals(down(+25.00), +20.00, epsilon); assertEquals(up(+25.00), +30.00, epsilon);
	}
}
