package xfe.icap.query;

import xstr.amp.ASN;
import xstr.amp.Xtr;
import xstr.amp.AsnMergeHandler;
import xstr.session.AbstractQueryReplyRow;
import xstr.amp.AmpService;
import xstr.amp.AsnConversionAccessor;
import xstr.session.XtrKey;
import xstr.session.XtrQueryRequest;
import com.objsys.asn1j.runtime.Asn1Choice;
import xstr.util.Tuple2;
import xstr.util.exception.AsnTypeException;

import java.util.Date;

public class RowFactory {
   private final XtrQueryRequest req;
   private final AsnMergeHandler mergeHandler;
   private static long nextKey;
   private static final long FACTOR = 10;
   private static final long MAX_KEY = Long.MAX_VALUE/FACTOR;

   public RowFactory(XtrQueryRequest req) {
      this.req = req;
      this.mergeHandler = Xtr.getMergeHandler(Xtr.getQueryReplyClass());
   }

   public QueryRow createRow(long key) {
      return createRow(new TestRowKey(key, 0));
   }

   public QueryRow createRow(XtrKey key) {
      try {
         return new QueryRow(key);
      } catch (AsnTypeException e) {
         e.printStackTrace();
      }
      return null;
   }

   public QueryRow createRow() {
      if(nextKey>=MAX_KEY){
         nextKey = 0;
      }
      return createRow(nextKey++ * FACTOR);
   }

   public class QueryRow extends AbstractQueryReplyRow {
      public QueryRow(XtrKey key) throws AsnTypeException {
         super(key, ASN.newChoice(Xtr.getQueryReplyClass(), AmpService.INSTANCE.getAssociatedReply(req.getData().getElemName())));
      }

      private QueryRow(QueryRow row, Asn1Choice data, Date timestamp) {
         super(row.getKey(), mergeHandler.merge(row.getData(), data), timestamp);
      }

      public <T> void setField(AsnConversionAccessor<T> acc, T val) throws AsnTypeException {
         acc.setValueFromBase(getData(), val);
      }

      @Override
      public XtrQueryRequest getRequest() {
         return req;
      }

      @Override
      public <A, B> Tuple2<A, B> getValue(AsnConversionAccessor<A> accA, AsnConversionAccessor<B> accB) {
         return Tuple2.of(getValue(accA), getValue(accB));
      }
   }
}
