package xfe.icap.types;


public class QueryReplyCollatorTest {
/*
    private static final class QueryReplyRowFactory implements RowFactory<QueryReplyRow> {

		@Override
		public QueryReplyRow createRow(QueryReplyRow row) {
			return row;
		}

		@Override
		public QueryReplyRow updateRow(QueryReplyRow current, QueryReplyRow update) {
			return update;
		}

    }

	private static final int INITIAL_ROWS = 20;
	private final ArrayList<QueryReplyRow> changeRows;
	private final QueryFeedCollator collator;
	private final XtrKey keys[];
	private final int keyValues[];
	private final SecBoardRepRowFactory rf;
	private final ArrayList<QueryRowEvent> evts = new ArrayList<QueryRowEvent>();

	private void collate() {
		collator.collate(evts);
	}

	private XtrKey addRowAfter(int idx, int offset) {
		QueryRow row = rf.createRow(keyValues[idx] + offset);
		evts.add(QueryRowEvent.create(row));
		return row.getKey();
	}

	private XtrKey deleteRow(int idx) {
		QueryRow row = rf.createRow(keyValues[idx]);
		evts.add(QueryRowEvent.delete(row));
		if (changeRows.size() - idx < 2)
			return null;
		return changeRows.get(idx + 1).getKey();
	}

	public QueryReplyCollatorTest() {
		changeRows = new ArrayList<QueryReplyRow>();
		collator = new ReplyCollator<QueryReplyRow>(changeRows, new QueryReplyRowFactory(), new SimpleBooleanProperty(), "secBoardRep");
		keys = new XtrKey[INITIAL_ROWS];
		keyValues = new int[INITIAL_ROWS];
		rf = SecBoardRepRowFactory.create();
	}

	@BeforeClass
	public static void initXtr() throws Exception {
		Xtr.init(new ICAPAmpSiteConfig());
	}


	@Before
	public void setUp() throws Exception {
		List<QueryRowEvent> feedEvents = new ArrayList<QueryRowEvent>();
		for (int i = 0; i < INITIAL_ROWS; i++) {
			keyValues[i] = i * 10;
			QueryRow row = rf.createRow(keyValues[i]);
			QueryRowEvent ev = QueryRowEvent.create(row);
			keys[i] = row.getKey();
			feedEvents.add(ev);
		}
		collator.collate(feedEvents);
	}

	@Test
	public void testAdd() throws Asn1ValueParseException {
		QueryRowEvent ev = QueryRowEvent.create(rf.createRow(2));
		assertEquals(INITIAL_ROWS, changeRows.size());
		collator.collate(Collections.singletonList(ev));
		assertEquals(INITIAL_ROWS + 1, changeRows.size());
		assertEquals(ev.getNewRow().getKey(), changeRows.get(1).getKey());
	}

	@Test
	public void testNonContigiousAdd() throws Asn1ValueParseException {
		assertTrue(changeRows.size() > 8);
		int idx1 = changeRows.size() / 3;
		int idx2 = idx1 * 2;
		int idx3 = changeRows.size() - 1;
		XtrKey k1 = addRowAfter(idx1, 1);
		XtrKey k2 = addRowAfter(idx2, 1);
		XtrKey k3 = addRowAfter(idx3, 1);
		assertEquals(INITIAL_ROWS, changeRows.size());
		collate();
		assertEquals(INITIAL_ROWS + 3, changeRows.size());
		assertEquals(changeRows.get(idx1+1).getKey(), k1);
		assertEquals(changeRows.get(idx2+2).getKey(), k2);
		assertEquals(changeRows.get(changeRows.size()-1).getKey(), k3);
}

	@Test
	public void testRemove() {
		int updateIndex = 4;
		XtrKey k1 = keys[updateIndex - 1];
		XtrKey k2 = keys[updateIndex];
		XtrKey k3 = keys[updateIndex + 1];
		QueryRow row = rf.createRow(k2);
		QueryRowEvent ev = QueryRowEvent.delete(row);
		assertEquals(INITIAL_ROWS, changeRows.size());
		assertEquals(changeRows.get(updateIndex).getKey(), k2);
		collator.collate(Collections.singletonList(ev));
		assertEquals(INITIAL_ROWS - 1, changeRows.size());
		assertEquals(changeRows.get(updateIndex - 1).getKey(), k1);
		assertEquals(changeRows.get(updateIndex).getKey(), k3);
	}

	@Test
	public void testNonContigiousRemove() {
		assertTrue(changeRows.size() > 8);
		int idx1 = changeRows.size() / 3;
		int idx2 = idx1 * 2;
		int idx3 = changeRows.size() - 1;
		XtrKey k1 = deleteRow(idx1);
		XtrKey k2 = deleteRow(idx2);
		XtrKey k3 = deleteRow(idx3);
		assertEquals(INITIAL_ROWS, changeRows.size());
		collate();
		assertEquals(INITIAL_ROWS - 3, changeRows.size());
		assertEquals(changeRows.get(idx1).getKey(), k1);
		assertEquals(changeRows.get(idx2-1).getKey(), k2);
	}

	@Test
	public void testUpdate() {
		int updateIndex = 4;
		XtrKey k1 = keys[updateIndex - 1];
		XtrKey k2 = keys[updateIndex];
		XtrKey k3 = keys[updateIndex + 1];
		QueryRow row = rf.createRow(k2);
		QueryRowEvent ev = QueryRowEvent.update(changeRows.get(updateIndex), row, null);
		assertEquals(INITIAL_ROWS, changeRows.size());
		assertTrue(changeRows.get(updateIndex) != row);
		collator.collate(Collections.singletonList(ev));
		assertEquals(INITIAL_ROWS, changeRows.size());
		assertTrue(changeRows.get(updateIndex) == row);
		assertEquals(k1, changeRows.get(updateIndex - 1).getKey());
		assertEquals(k2, changeRows.get(updateIndex).getKey());
		assertEquals(k3, changeRows.get(updateIndex + 1).getKey());
	}

	@Test
	public void testClear() {
		assertEquals(INITIAL_ROWS, changeRows.size());
		collator.collate(Collections.singletonList(QueryRowEvent.clear()));
		assertEquals(0, changeRows.size());
	}

//	@Test
//	public void testIdle() {
//		assertEquals(0, changeRows.size());
//		QueryRowEvent ev = QueryRowEvent.idle();
//		assertEquals(INITIAL_ROWS, changeRows.size());
//		collator.collate(Collections.singletonList(ev));
//		assertEquals(INITIAL_ROWS, changeRows.size());
//	}
*/
}
