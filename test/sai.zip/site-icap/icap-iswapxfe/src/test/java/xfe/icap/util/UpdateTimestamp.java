package xfe.icap.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.HashMap;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import com.nomx.persist.PersistantName;

public class UpdateTimestamp extends Application{
	public static void main(String[] args) {
		launch(args);
	}

	public final HashMap<PersistantName, Object> readData(File file) {
		try {
			FileInputStream inputStream = new FileInputStream(file);
			ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
			Object object = objectInputStream.readObject();
			if (object instanceof HashMap<?, ?>) {
				@SuppressWarnings("unchecked") HashMap<PersistantName, Object> data = (HashMap<PersistantName, Object>)object;
				return data;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	private void writeData(File file, HashMap<PersistantName, Object> data) {
		try {
			FileOutputStream outputStream = new FileOutputStream(file);
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
			objectOutputStream.writeObject(data);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void start(Stage stage) throws Exception {
		stage.setScene(new Scene(new Button("Update timestamp ...") {{
			this.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent actionEvent) {
					FileChooser fileChooser = new FileChooser();
					File file = fileChooser.showOpenDialog(stage);
					HashMap<PersistantName, Object> data = readData(file);
					data.put(PersistantName.TIMESTAMP_KEY, new Date());
					writeData(file, data);
				}
			});
		}}));

		stage.show();
	}
}
