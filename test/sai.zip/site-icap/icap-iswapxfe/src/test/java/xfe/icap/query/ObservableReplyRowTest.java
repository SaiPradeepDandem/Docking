package xfe.icap.query;

import xstr.amp.Xtr;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.amp.AsnConversionAccessor;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableObjectValue;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import xstr.icap.amp.ICAPAmpSiteConfig;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xfe.icap.query.RowFactory.QueryRow;

import java.lang.ref.WeakReference;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotSame;

public class ObservableReplyRowTest {
   static final int gcRunCount = 10;

   final ObservableRowFactory obsRowFactory = new ObservableRowFactory();

   ObservableReplyRow testRow;

   void runGC(int count) {
      while (count-- > 0) {
         System.gc();
      }
   }

   ObservableReplyRow createRow() {
      QueryRow r = TestRowFactory.instance().createRow();
      return obsRowFactory.createRow(r);
   }

   void updateRow(ObservableReplyRow obsRow, QueryReplyRow update) {
      obsRowFactory.updateRow(obsRow, update);

   }

   void updateRow(ObservableReplyRow obsRow) {
      updateRow(obsRow, TestRowFactory.instance().createRow(obsRow.getKey()));
   }

   @BeforeClass
   public static void globalSetup() {
      Xtr.init(new ICAPAmpSiteConfig());
   }

   @Before
   public void setUp() {
      testRow = createRow();
   }

   @After
   public void tearDown() {
   }

   @Test
   public void rowProperty() {
      ObservableReplyRow r1 = testRow;
      WeakReference<ReadOnlyObjectProperty<QueryReplyRow>> rowRef = new WeakReference<>(r1.rowProperty());
      SimpleObjectProperty<QueryReplyRow> rowProp = new SimpleObjectProperty<>();
      rowProp.bind(r1.rowProperty());
      QueryReplyRow oldRow[] = { null };
      QueryReplyRow newRow[] = { null };
      QueryReplyRow currentRow = rowRef.get().get();
      r1.rowProperty().addListener((observable, oldValue, newValue) -> {
         oldRow[0] = oldValue;
         newRow[0] = newValue;
      });
      runGC(gcRunCount);
      assertNotNull(rowRef.get());
      assertEquals(currentRow, rowRef.get().get());
      assertEquals(currentRow, rowProp.get());
      updateRow(r1);
      runGC(gcRunCount);
      assertNotNull(rowRef.get());
      assertNotSame(currentRow, rowProp.get());
      assertNotSame(currentRow, rowRef.get().get());
      assertNotEquals(currentRow, rowProp.get());
      assertNotEquals(currentRow, rowRef.get().get());
      assertEquals(currentRow, oldRow[0]);

   }

   @Test
   public void valueProperty() {
      ObservableReplyRow r1 = testRow;
      AsnConversionAccessor<Double> priceAcc = TestRowFactory.refPrice;
      QueryReplyRow currentRow = r1.getRow();
      WeakReference<ObservableObjectValue<Double>> priceRef = new WeakReference<>(r1.getProperty(priceAcc));
      runGC(gcRunCount);
      assertNotNull(priceRef.get());
      assertEquals(currentRow.getValue(priceAcc), priceRef.get().get());
      updateRow(r1);
      runGC(gcRunCount);
      assertNotEquals(currentRow.getValue(priceAcc), priceRef.get().get());




   }
}
