package xfe.icap.util.collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

import org.junit.Before;
import org.junit.Test;
import xstr.util.collection.ObservableListTransformer;

public class ObservableListTransformerTest {

	private ObservableList<String> srcList;
	private final ObservableList<Integer> tgtList = FXCollections.observableArrayList();
	private ObservableListTransformer<Integer, String> tr;
	private final String[] items = { "123", "456", "789" };
	private final Integer[] values = { 123, 456, 789 };

	@Before
	public void setUp() {
		srcList = FXCollections.observableArrayList();
		tr = new ObservableListTransformer<Integer, String>(srcList, tgtList) {

			@Override
			protected Integer transform(String f) {
				return Integer.valueOf(f);
			}
		};
		assertTrue(tr.getItems().isEmpty());

		srcList.add(items[0]);
		srcList.add(items[1]);
		srcList.add(items[2]);

		assertEquals(srcList.size(), tr.getItems().size());
		assertTrue(tr.getItems().contains(values[0]));
	}

	@Test
	public void testAddItem() {
		Integer addedItem = Integer.valueOf(111);
		tr.getItems().addListener(new ListChangeListener<Integer>(){

			@Override
			public void onChanged(
					Change<? extends Integer> c) {
				assertTrue(c.next());
				assertTrue(c.wasAdded());
				assertFalse(c.wasRemoved());
				assertFalse(c.wasReplaced());
				assertFalse(c.wasPermutated());
				assertEquals(addedItem, c.getAddedSubList().get(0));
				assertFalse(c.next());
			}

		});
		int sz = tr.getItems().size();
		assertEquals(items.length, sz);
		srcList.add(addedItem.toString());
		assertEquals(sz + 1, tr.getItems().size());
		assertEquals(addedItem, tr.getItems().get(sz));
	}

	@Test
	public void testAddItems() {
		Integer addedItems[] = {
				Integer.valueOf(111),
				Integer.valueOf(112),
				Integer.valueOf(113),
		};
		ArrayList<String> strings = new ArrayList<String>();
		for (Integer i: addedItems)
			strings.add(String.valueOf(i));

		tr.getItems().addListener(new ListChangeListener<Integer>(){

			@Override
			public void onChanged(
					Change<? extends Integer> c) {
				assertTrue(c.next());
				assertTrue(c.wasAdded());
				assertEquals(addedItems.length, c.getAddedSize());
				assertFalse(c.wasRemoved());
				assertFalse(c.wasReplaced());
				assertFalse(c.wasPermutated());
				assertEquals(addedItems[0], c.getAddedSubList().get(0));
				assertFalse(c.next());
			}

		});
		int sz = tr.getItems().size();
		srcList.addAll(strings);
		assertEquals(sz + addedItems.length, tr.getItems().size());
		assertEquals(addedItems[0], tr.getItems().get(sz));
	}

	@Test
	public void testRemoveItem() {
		String removedItem = "456";
		tr.getItems().addListener(new ListChangeListener<Integer>(){

			@Override
			public void onChanged(
					Change<? extends Integer> c) {
				assertTrue(c.next());
				assertTrue(c.wasRemoved());
				assertFalse(c.wasAdded());
				assertFalse(c.wasReplaced());
				assertFalse(c.wasPermutated());
				assertEquals(Integer.valueOf(removedItem), c.getRemoved().get(0));
				assertFalse(c.next());
			}

		});
		int sz = tr.getItems().size();
		assertTrue(tr.getItems().contains(Integer.valueOf(removedItem)));
		srcList.remove(removedItem);
		assertEquals(sz - 1, tr.getItems().size());
		assertFalse(tr.getItems().contains(Integer.valueOf(removedItem)));
	}

	@Test
	public void testReplaceItem() {
		String newItem = "321";
		int removeIndex = 1;
		Integer oldItem = tr.getItems().get(removeIndex);

		tr.getItems().addListener(new ListChangeListener<Integer>(){

			@Override
			public void onChanged(
					Change<? extends Integer> c) {
				assertTrue(c.next());
				assertTrue(c.wasRemoved());
				assertTrue(c.wasAdded());
				assertTrue(c.wasReplaced());
				assertFalse(c.wasPermutated());
				assertEquals(Integer.valueOf(newItem), c.getAddedSubList().get(0));
				assertEquals(oldItem, c.getRemoved().get(0));
				assertFalse(c.next());
			}

		});
		int sz = tr.getItems().size();
		assertFalse(tr.getItems().contains(Integer.valueOf(newItem)));
		assertTrue(tr.getItems().contains(oldItem));
		srcList.set(removeIndex, newItem);
		assertEquals(sz, tr.getItems().size());
		assertTrue(tr.getItems().contains(Integer.valueOf(newItem)));
		assertFalse(tr.getItems().contains(oldItem));
	}

	@Test
	public void testClear() {
		assertEquals(items.length, tr.getItems().size());
		srcList.clear();
		assertTrue(tr.getItems().isEmpty());
	}

	@Test
	public void testAddClearAdd() {
		Integer addedItems[] = {
				Integer.valueOf(111),
				Integer.valueOf(112),
				Integer.valueOf(113),
		};
		ArrayList<String> strings = new ArrayList<String>();
		for (Integer i: addedItems)
			strings.add(String.valueOf(i));

		int sz = tr.getItems().size();
		srcList.addAll(strings);
		assertEquals(sz + addedItems.length, tr.getItems().size());
		assertEquals(addedItems[0], tr.getItems().get(sz));
		srcList.clear();
		assertTrue(tr.getItems().isEmpty());

		sz = tr.getItems().size();
		srcList.addAll(strings);
		assertEquals(sz + addedItems.length, tr.getItems().size());
		assertEquals(addedItems[0], tr.getItems().get(sz));
	}

	@Test
	public void testReplaceSource() {
		String[] newItems = { "3010", "3011", "3012", "3013" };
		Integer[] newValues = { 3010, 3011, 3012, 3013 };
		assertFalse(tr.getItems().contains(newValues[0]));
		assertFalse(tr.getItems().contains(newValues[newValues.length-1]));
		assertTrue(tr.getItems().contains(values[0]));
		srcList.setAll(newItems);
		assertEquals(newItems.length, tr.getItems().size());
		assertTrue(tr.getItems().contains(newValues[0]));
		assertTrue(tr.getItems().contains(newValues[newValues.length-1]));
		assertFalse(tr.getItems().contains(values[0]));
		assertEquals(newValues[0], tr.getItems().get(0));
		assertEquals(newValues[newValues.length-1], tr.getItems().get(newValues.length-1));
	}

}
