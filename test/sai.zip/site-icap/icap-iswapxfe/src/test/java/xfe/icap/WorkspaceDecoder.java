package xfe.icap;
import java.io.*;
import java.util.Date;
import java.util.zip.*;

public class WorkspaceDecoder {
   private static final String userDataFilePrefix = "Workspace_";
   static final int HEADER_SIZE = 24;
   static final long JAVA_SERIALIZATION = 1;
   static final long XML = 2;
   static final long JSON = 3;
   static final long CURRENT_PROTOCOL = XML;

   @SuppressWarnings("resource")
   private static void decodeToPlainXML(String username) throws Exception {
      String userDataFileName = userDataFilePrefix + username.replace(" ", "_");
      String dataDir ="C:\\Users\\jiadin\\AppData\\Local\\X-stream\\i-Swap XFE\\data\\";// System.getProperty("user.home") + "\\.xstream\\xfe\\";
      String fullPath = dataDir + userDataFileName;
      DataInputStream dis = new DataInputStream(new FileInputStream(fullPath));
      long type = -1;
      Date timestamp = null;
      long extended = -1;
      try {
         type = dis.readLong();
         timestamp = new Date(dis.readLong());
         extended = dis.readLong();
      } catch (Exception e) {
         throw new Exception("Not valid workspace file. File header is less than " + HEADER_SIZE + " bytes");
      }
      if (type == XML) {
         GZIPInputStream gis = new GZIPInputStream(dis);
         FileOutputStream fos = new FileOutputStream(fullPath + ".xml");
         try {
            byte[] buffer = new byte[2048];
            int readLen = gis.read(buffer);
            while (readLen > 0) {
               fos.write(buffer, 0, readLen);
               readLen = gis.read(buffer);
            }
         } finally {
            if (gis != null)
               gis.close();
            if (fos != null)
               fos.close();
            if (dis != null)
               dis.close();
         }
      }
   }

   private static void codeToWS(String username) throws Exception {
      String userDataFileName = userDataFilePrefix + username.replace(" ", "_");
      String dataDir = System.getProperty("user.home") + "\\Appdata\\local\\X-stream\\i-Swap XFE\\Data\\";
      String fullPath = dataDir + userDataFileName;
      DataOutputStream dos = new DataOutputStream(new FileOutputStream(fullPath, false));
      dos.writeLong(XML);
      dos.writeLong(new Date().getTime());
      dos.writeLong(0);
      GZIPOutputStream gos = new GZIPOutputStream(dos);
      FileInputStream fis = new FileInputStream(fullPath + ".xml");
      try {
         byte[] buffer = new byte[2048];
         int readLen = fis.read(buffer);
         while (readLen > 0) {
            gos.write(buffer, 0, readLen);
            readLen = fis.read(buffer);
         }
      } finally {
         if (gos != null)
            gos.close();
         if (fis != null)
            fis.close();
         if (dos != null)
            dos.close();
      }
   }

   public static void main(String[] args) throws Exception {
      if(args[0].equalsIgnoreCase("WS"))
         codeToWS(args[1]);
      else
         decodeToPlainXML(args[1]);
   }
}
