package xfe.icap.modules.watchlist;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nomx.persist.watchlist.WatchlistSpec_v1;

public class WatchlistSpecTest {

	String[] items1 = {
		"Item 10",
		"Item 11",
		"Item 12",
		"Item 13",
		"Item 14",
		"Item 15",
		"Item 16",
		"Item 17",
		"Item 18",
		"Item 19",
	};

	String[] items2 = {
			"Item 20",
			"Item 21",
			"Item 22",
			"Item 23",
			"Item 24",
			"Item 25",
			"Item 26",
			"Item 27",
			"Item 28",
			"Item 29",
		};

	String[] items3 = {
			"Item 30",
			"Item 31",
			"Item 32",
			"Item 33",
			"Item 34",
			"Item 35",
			"Item 36",
			"Item 37",
			"Item 38",
			"Item 39",
		};

	WatchlistSpec_v1 spec1 = new WatchlistSpec_v1("List1", "testList", items1);
	WatchlistSpec_v1 spec2 = new WatchlistSpec_v1("List2", "testList", items2);
	WatchlistSpec_v1 spec3 = new WatchlistSpec_v1("List3", "testList", items3);

	@BeforeClass
	public static void setUpBeforeClass() {
	}

	@AfterClass
	public static void tearDownAfterClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	@Test
	public void testCopyCtor() {
		WatchlistSpec_v1 copy = new WatchlistSpec_v1(spec1);

		assertEquals(spec1.getTitle(), copy.getTitle());
		assertEquals(spec1.getSubtitle(), copy.getSubtitle());
		assertEquals(spec1.getId(), copy.getId());
		assertEquals(spec1.getUnmodifiableSecCodes(), copy.getUnmodifiableSecCodes());

		copy.getSecCodes().set(3, "New Item");
		assertFalse(copy.getSecCodes().get(3).equals(spec1.getSecCodes().get(3)));
		copy.setTitle("New Title");
		assertFalse(copy.getTitle().equals(spec1.getTitle()));
		copy.setSubtitle("New Subtitle");
		assertFalse(copy.getSubtitle().equals(spec1.getSubtitle()));
	}

//	@Test
//	public void testCopy() {
//		List<WatchlistSpec_v1> specs = Arrays.asList(spec1, spec2, spec3);
//		List<WatchlistSpec_v1> copies =  WatchlistSpec_v1.copy(specs);
//
//		WatchlistSpec_v1 spec = specs.get(1);
//		WatchlistSpec_v1 copy = copies.get(1);
//
//		assertEquals(spec.getTitle(), copy.getTitle());
//		assertEquals(spec.getSubtitle(), copy.getSubtitle());
//		assertEquals(spec.getId(), copy.getId());
//		assertEquals(spec.getUnmodifiableSecCodes(), copy.getUnmodifiableSecCodes());
//
//		copy.getSecCodes().set(3, "New Item");
//		assertFalse(copy.getUnmodifiableSecCodes().get(3).equals(spec.getSecCodes().get(3)));
//		copy.setTitle("New Title");
//		assertFalse(copy.getTitle().equals(spec.getTitle()));
//		copy.setSubtitle("New Subtitle");
//		assertFalse(copy.getSubtitle().equals(spec.getSubtitle()));
//
//	}
}
