package xfe.icap.query;

import xstr.session.XtrKey;

import java.util.Objects;

public class TestRowKey implements XtrKey {
   private final long keyVal;
   private final long subkeyVal;

	TestRowKey(long keyVal, long subkeyVal) {
	   this.keyVal = keyVal;
      this.subkeyVal = subkeyVal;
	}

	@Override
	public int compareTo(XtrKey other) {
		TestRowKey that = (TestRowKey)other;

      if (keyVal != that.keyVal)
         return Long.signum(keyVal - that.keyVal);
      else
         return Long.signum(subkeyVal - that.subkeyVal);
	}

	@Override
	public String toString() {
		return String.valueOf(keyVal);
	}

	@Override
	public boolean equals(Object other) {
		if (other instanceof TestRowKey) {
			TestRowKey that = (TestRowKey)other;

         return keyVal == that.keyVal && subkeyVal == that.subkeyVal;
		} else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return Objects.hash(keyVal, subkeyVal);
	}

   @Override
   public XtrKey genSubKey() {
      return new TestRowKey(this.keyVal, this.subkeyVal + 1);
   }
}
