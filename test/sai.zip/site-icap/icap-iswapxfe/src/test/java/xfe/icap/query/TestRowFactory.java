package xfe.icap.query;

import xstr.session.QueryRequestWrapper;
import xstr.amp.AMP;
import xstr.amp.AmpService;
import xstr.amp.AsnConversionAccessor;
import xstr.session.XtrKey;
import xstr.session.XtrQueryRequest;
import xstr.util.exception.AsnTypeException;

public class TestRowFactory extends RowFactory {
	private static double nextPrice;
	private static TestRowFactory instance;

	public static AsnConversionAccessor<String> secCode;
	public static AsnConversionAccessor<Double> refPrice;

	public static TestRowFactory instance() {
		if (instance == null) {
			try {
				secCode = AmpService.INSTANCE.getValAccessor(AMP.qREP("secBoardRep.secBoardId.secCode"), String.class);
				refPrice = AmpService.INSTANCE.getValAccessor(AMP.qREP("secBoardRep.dynamics.refPrice"), Double.class);
				instance = new TestRowFactory();
			} catch (AsnTypeException e) {
				throw new AssertionError(e);
			}
		}
		return instance;
	}

	private TestRowFactory() throws AsnTypeException {
		super(new XtrQueryRequest(new QueryRequestWrapper(AMP.qREQ("secBoardReq"))));
	}

	@Override
	public QueryRow createRow(XtrKey key) {
		QueryRow row = super.createRow(key);
		try {
			row.setField(secCode, String.format("SEC%05d", Integer.parseInt(key.toString())));
			row.setField(refPrice, 4.0 + nextPrice++ /1000.0);
		} catch (AsnTypeException e) {
			throw new AssertionError(e);
		}
		return row;
	}

}
