package xfe.icap.types;


import org.junit.Ignore;
import xstr.session.*;
import xstr.session.CachedQueryFeed.FeedStateListener;
import xstr.amp.AMP;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import javafx.application.Platform;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static xstr.session.XtrQueryReplyCommand.CLEAR;
import static xstr.session.XtrQueryReplyCommand.CREATE;
import static xstr.session.XtrQueryReplyCommand.NONE;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertNotSame;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
// This unit test needs running engine so only possible for manual test
@Ignore
public class CachedQueryFeedTest extends JfxNonUITest {


   XtrQueryRequest trimReq1;
   XtrQueryRequest trimReq2;
   XtrQueryRequest trimReq3;

   public CachedQueryFeedTest() {
   }

   @BeforeClass
   public static void initXtr() {
      initJFX();

   }

   @Before
   public void setUp() throws Exception {
      logon("A Davies", "linux15.mtech:15170");
      trimReq1 = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req,
         session).set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), new Long[] { 1L }).build();
      trimReq2 = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req,
         session).set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), new Long[] { 2L }).build();
      trimReq3 = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req,
         session).set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), new Long[] { 3L }).build();

   }

   abstract static class FutureListener implements QueryFeedListener {
      public static final String SUCCESS = "SUCCESS";
      private static int nextID;
      final int id = nextID++;
      protected CompletableFuture<String> result = new CompletableFuture<>();

      Future<String> doneFuture() {
         return result;
      }
   }

   static class EventSequenceListener extends FutureListener {
      List<XtrQueryReplyCommand> commands;
      int nextEventIndex;
      EventSequenceListener(List<XtrQueryReplyCommand> commands){
         this.commands = commands;
      }

      void reset() {
         nextEventIndex = 0;
         result = new CompletableFuture<>();
      }

      void onDone() {}

      @Override
      public void handleEvent(List<QueryRowEvent> feedEvents) {
         if (result.isDone()) return;
         List<XtrQueryReplyCommand> testEvents;
         if(feedEvents.isEmpty()){
            testEvents = Collections.singletonList(NONE);
         } else {
            testEvents = feedEvents.stream().map(QueryRowEvent::getEventType).collect(Collectors.toList());
         }
         for (XtrQueryReplyCommand ev: testEvents) {
            XtrQueryReplyCommand expectedEvent = commands.get(nextEventIndex++);
            if (expectedEvent != ev) {
               result.complete("Expected " + expectedEvent + " but received " + ev + "  " + id);
               System.out.println("ERROR: >>>>>>  Expected " + expectedEvent + " but received " + ev + "  " + id);
               break;
            }
            if (nextEventIndex >= commands.size()) {
               result.complete(SUCCESS);
               onDone();
            }
         }
      }
      @Override
      public String toString() {
         return getClass().getName() + "[" + id + "]";
      }

   }
      // A listener that will check that exactly three events are
   // received in order: CLEAR -> ADD -> IDLE, and then set its result.
   static class SingleAddListener extends EventSequenceListener {
      SingleAddListener() {
         super(Arrays.asList(
            CLEAR,
            CREATE,
            NONE
         ));
      }

   }

   SingleAddListener createRecursiveAddListener(QueryFeed feed, ArrayList<SingleAddListener> listeners) {
      return new SingleAddListener(){
         @Override
         void onDone() {
            SingleAddListener l = new SingleAddListener();
            feed.addListener(l);
            if (id % 3 == 0){
               feed.removeListener(this);
            }
            listeners.add(l);
         }
      };
   }

   EventSequenceListener createFeedSwapListener(QueryFeed feed1, QueryFeed feed2) {
      return new EventSequenceListener(Arrays.asList(
         CLEAR,
         CREATE,
         NONE
      )) {
         int iter;
         @Override
         void onDone() {
            if (iter == 0) {
               iter++;
               feed1.removeListener(this);
               System.out.println("" + this + " Before reset");
               reset();
               System.out.println("" + this + " After reset");
               feed2.addListener(this);
            }
         }
      };
   }

   /*
    * Add listeners to a feed, alternating adds between current thread and JavaFX thread.
    * Confirm each listener receives CLEAR, ADD and IDLE
    * After confirming all listeners received their events, remove all listeners
    * Confirm feed is empty
    */
   @Test
   public void testCrossThreadAddRemove() throws InterruptedException, TimeoutException, ExecutionException {
      CachedQueryFeed testFeed = (CachedQueryFeed) session.queries.getFeedSource(trimReq1);

      CountDownLatch lastListener = new CountDownLatch(1);
      testFeed.addStateListener(new FeedStateListener() {
         @Override
         public void onLastListenerRemoved() {
            lastListener.countDown();
         }
      });

      int ITERATIONS = 100;

      ArrayList<SingleAddListener> listeners = new ArrayList<>();
      ArrayList<SingleAddListener> extraListeners = new ArrayList<>();
      for (int i = 0; i < ITERATIONS; i++) {
         SingleAddListener l1 = createRecursiveAddListener(testFeed, extraListeners);
         SingleAddListener l2 = createRecursiveAddListener(testFeed, extraListeners);
         listeners.add(l1);
         listeners.add(l2);
         testFeed.addListener(l1);
         Platform.runLater(() -> testFeed.addListener(l2));
         Thread.sleep(10);
      }
      for (SingleAddListener l: listeners) {
         assertEquals(SingleAddListener.SUCCESS, l.doneFuture().get(5, TimeUnit.SECONDS));
      }
      for (SingleAddListener l: extraListeners) {
         assertEquals(SingleAddListener.SUCCESS, l.doneFuture().get(5, TimeUnit.SECONDS));
      }
      for (int i = 0; i < ITERATIONS * 2; i+=2) {
         QueryFeedListener l1 = listeners.get(i);
         QueryFeedListener l2 = listeners.get(i+1);
         QueryFeedListener l3 = extraListeners.get(i);
         QueryFeedListener l4 = extraListeners.get(i+1);
         testFeed.removeListener(l1);
         testFeed.removeListener(l3);
         Platform.runLater(() -> testFeed.removeListener(l2));
         Platform.runLater(() -> testFeed.removeListener(l4));
      }
      assertTrue(lastListener.await(5, TimeUnit.SECONDS));
   }

   /*
    */
   @Test
   public void testMultiFeedAddRemove() throws InterruptedException, TimeoutException, ExecutionException {
      CachedQueryFeed testFeed1 = (CachedQueryFeed) session.queries.getFeedSource(trimReq1);
      CachedQueryFeed testFeed2 = (CachedQueryFeed) session.queries.getFeedSource(trimReq2);

      CountDownLatch lastListener = new CountDownLatch(2);
      testFeed1.addStateListener(new FeedStateListener() {
         @Override
         public void onLastListenerRemoved() {
            lastListener.countDown();
         }
      });
      testFeed2.addStateListener(new FeedStateListener() {
         @Override
         public void onLastListenerRemoved() {
            lastListener.countDown();
         }
      });
      assertNotSame(testFeed1, testFeed2);

      int ITERATIONS = 5;

      ArrayList<EventSequenceListener> listeners = new ArrayList<>();
      for (int i = 0; i < ITERATIONS; i++) {
         EventSequenceListener l1 = createFeedSwapListener(testFeed1, testFeed2);
         listeners.add(l1);
         testFeed1.addListener(l1);
         Thread.sleep(10);
      }
      // Wait for the first round to complete - all listeners on testFeed1
      for (EventSequenceListener l: listeners) {
         assertEquals(EventSequenceListener.SUCCESS, l.doneFuture().get(5, TimeUnit.SECONDS));
      }
      // Wait for the second round to complete - all listeners on testFeed2
      for (EventSequenceListener l: listeners) {
         assertEquals(EventSequenceListener.SUCCESS, l.doneFuture().get(5, TimeUnit.SECONDS));
      }

      for (EventSequenceListener l: listeners) {
         testFeed2.removeListener(l);
         Thread.sleep(10);
      }
      assertTrue(lastListener.await(5, TimeUnit.SECONDS));
   }

   @Test
   public void testImmediateAddRemove() throws InterruptedException, TimeoutException, ExecutionException {
      CachedQueryFeed testFeed1 = (CachedQueryFeed) session.queries.getFeedSource(trimReq1);
      CountDownLatch lastListener = new CountDownLatch(1);
      testFeed1.addStateListener(new FeedStateListener() {
         @Override
         public void onLastListenerRemoved() {
            lastListener.countDown();
         }
      });

      EventSequenceListener l1 = new SingleAddListener();
      testFeed1.addListener(l1);
      assertEquals(EventSequenceListener.SUCCESS, l1.doneFuture().get(5, TimeUnit.SECONDS));
      System.out.println("" + this + " Before remove 1");
      testFeed1.removeListener(l1);
      l1.reset();
      testFeed1.addListener(l1);
      assertFalse(l1.doneFuture().isDone());
      System.out.println("" + this + " After add 2");
      assertEquals(EventSequenceListener.SUCCESS, l1.doneFuture().get(5, TimeUnit.SECONDS));
      System.out.println("" + this + " Before remove 2");
      testFeed1.removeListener(l1);
      System.out.println("" + this + " After remove 2");
      assertTrue(lastListener.await(5, TimeUnit.SECONDS));
   }
}
