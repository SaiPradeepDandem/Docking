package xfe.icap.util.collection;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import xstr.util.XstrIni.Key;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.FutureListener;

import xfe.icap.types.ConverterForAsnDateTime_Duration;
import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xstr.amp.Xtr;
import xstr.amp.AmpService;
import xstr.session.Credentials;
import xstr.session.ServerSession;
import xstr.session.SessionListener;
import xstr.session.XstrClientConfig;
import xstr.util.Fx;
import xstr.util.Fun0Throws;

public class SecboardsTest extends Application implements SessionListener {
   private final TextArea log = new TextArea();
   private final Button quitButton = new Button("Quit");
   private final ServerSession session = new ServerSession(AmpService.INSTANCE);
   private int rowCount;

   private void log(String msg) {
      Fx.runLater(new Runnable() {
         @Override
         public void run() {
            log.appendText(msg + "\n");
         }
      });
   }


      @Override
      public Future<Void> handleLogon() {
//         SecBoards sb = new SecBoards(session, priceArray, qtyArray);
//         ObservableList<SecBoard> sbs = sb.getAll();
//         sbs.addListener(new ListChangeListener<SecBoard>(){
//
//            @Override
//            public void onChanged(
//                  Change<? extends SecBoard> change) {
//               while (change.next()) {
//                  for (SecBoard s: change.getAddedSubList()) {
////							if (rowCount % 100 == 0) {
//							//log(String.valueOf(rowCount));
////								log(s.toString());
//                     System.out.println(rowCount++ + ". " + s);
////							}
//                  }
//               }
//            }
//         });

         return DONE;
      }

   @Override
   public void start(Stage stage) throws Exception {
//		session.setForegroundExecutor(new Executor(){
//			@Override
//			public void execute(final Runnable command) {
//				Platform.runLater(command);
//			}
//		});
      session.setIgnorePermissions();
      Xtr.addConverter(new ConverterForAsnDateTime_Duration());
      session.addSessionListener(this);

      BorderPane bp = new BorderPane();
      bp.setCenter(log);
      bp.setBottom(quitButton);
      stage.setScene(new Scene(bp));
      stage.show();
      log("Starting...");
      quitButton.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent arg0) {
            session.logoff("User requested logoff");
            Platform.exit();
         }
      });

      Credentials cred = Credentials.create("A Malone");
      XstrClientConfig config = XstrClientConfig.newConfig();
      config.set(Key.TSMR_POSSIBLE_HOSTS, "linux12:15150");

      session.logon(cred, config).addListener(new FutureListener<Void>() {
         @Override
         public void call(Fun0Throws<? extends Void> f) {
            try {
               f.get();
               log("Logged on...");
            } catch (Exception e) {
               log("Logon error: " + e.getMessage());
               Platform.exit();
            }
         }
      });
   }

   public static void main(String[] args) {
      launch(args);
   }
}
