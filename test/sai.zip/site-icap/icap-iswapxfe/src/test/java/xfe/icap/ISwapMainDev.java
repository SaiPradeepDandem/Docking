package xfe.icap;

import javafx.application.Application;
import xfe.icap.ISwapMain;

public class ISwapMainDev {

   public static void main(String[] args) {
      Application.launch(ISwapMain.class, args);
   }

}
