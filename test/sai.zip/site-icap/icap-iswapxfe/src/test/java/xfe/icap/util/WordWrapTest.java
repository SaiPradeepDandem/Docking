package xfe.icap.util;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by soopot on 10/4/2019.
 *
 * @author Sooraj Pottekat
 */
public class WordWrapTest{
  @Test
  public void testWrapEmpty() throws Exception{
     assertEquals("",WordWrap.wrap("",1));
  }
  @Test
  public void testWrapValidInput() throws Exception{
     assertEquals("a\nb",WordWrap.wrap("ab",1));
  }

  @Test
  public void testWrapMultiplePoints() throws Exception{
     assertEquals("a\nb\nc",WordWrap.wrap("abc",1));
  }

  @Test
  public void testErrorMessage() throws Exception{
     String input = "Error in a long string where the values are loraumaad ipsum ipsum loraumaad. kiua  ua ada sdfafa adfaf";
     String expected = "Error in a long string where the values are loraum\naad ipsum ipsum loraumaad. kiua  ua ada sdfafa adf\naf";
     assertEquals(expected,WordWrap.wrap(input,50));
  }
}
