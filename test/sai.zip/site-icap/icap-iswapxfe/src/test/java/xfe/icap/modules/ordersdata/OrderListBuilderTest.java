package xfe.icap.modules.ordersdata;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import mock.objects.MockObservableRow;
import mock.objects.MockQueryRow;
import mock.util.MockHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.function.Predicate;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by soopot on 8/9/2019.
 *
 * @author Sooraj Pottekat
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(OrderFilters.class)
public class OrderListBuilderTest {
  ObservableList<ObservableReplyRow> list;
  private  ObservableReplyRow firstItem;
  private ObservableReplyRow secondItem;
   private ObservableReplyRow thirdItem;

  @Before
  public void setUp() throws Exception {
    mockStatic(OrderFilters.class);
    list = FXCollections.observableArrayList();
  }

  @After
  public void tearDown() throws Exception {}

  @Test
  public void checkOfSecFilterIsSet() throws Exception {
    mockFilter(OrderFilters.matchSecCode(null), matchSecCode(null));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.ofSec(null),createItem(null, "user", "firm", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2));
  }

  private Predicate<ObservableReplyRow> matchSecCode(String match) {
    return observableReplyRow ->
        ((MockQueryRow) (observableReplyRow.getRow())).getSecCode() == match;
  }

  private void mockFilter(
      Predicate<ObservableReplyRow> inputMethod, Predicate<ObservableReplyRow> resultReturn) {
    when(inputMethod).thenReturn(resultReturn);
  }

  private OrderListBuilder initialiseBuilder() {
    return new OrderListBuilder(list, "", "");
  }

  private void checkFilterInitalised(OrderListBuilder orderListBuilder) {
    Predicate<ObservableReplyRow> filterToApply = MockHelper.get(orderListBuilder, "filterToApply");
    assertTrue(filterToApply.test(null));
  }

  private void checkFilterSet(OrderListBuilder orderListBuilder,ObservableReplyRow row) {
    Predicate<ObservableReplyRow> filterToApply = MockHelper.get(orderListBuilder, "filterToApply");
    assertTrue(filterToApply.test(row));
  }

   @Test
   public void checkOwnFilterSet() throws Exception{
      mockFilter(OrderFilters.matchUserID(any(String.class)), matchUserCode("user"));
      OrderListBuilder orderListBuilder = initialiseBuilder();
      checkFilterInitalised(orderListBuilder);
      checkFilterSet(orderListBuilder.own(),createItem("*#$", "user", "firm", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2));
   }

   private Predicate<ObservableReplyRow> matchUserCode(String match) {
      return observableReplyRow ->
         ((MockQueryRow) (observableReplyRow.getRow())).getUserID() == match;
   }

   @Test
   public void checkColleaguesFilterSet() throws Exception{
      mockFilter(OrderFilters.matchFirmID(any(String.class)), matchFirmCode("firm"));
      mockFilter(OrderFilters.matchUserID(any(String.class)), matchUserCode("not user"));
      OrderListBuilder orderListBuilder = initialiseBuilder();
      checkFilterInitalised(orderListBuilder);
      checkFilterSet(orderListBuilder.colleagues(),createItem("*#$", "user", "firm", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2));
   }

   private Predicate<ObservableReplyRow> matchFirmCode(String match) {
      return observableReplyRow ->
         ((MockQueryRow) (observableReplyRow.getRow())).getFirmId() == match;
   }

   @Test
   public void checkFirmFilterSet() throws Exception{
      mockFilter(OrderFilters.matchFirmID(any(String.class)), matchFirmCode("firm"));
      mockFilter(OrderFilters.matchUserID(any(String.class)), matchUserCode("not user"));
      OrderListBuilder orderListBuilder = initialiseBuilder();
      checkFilterInitalised(orderListBuilder);
      checkFilterSet(orderListBuilder.firm(),createItem("*#$", "user", "firm", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2));
   }

   @Test
   public void checkNotOwnFilterSet() throws Exception{
      mockFilter(OrderFilters.notMatchUserID(any(String.class)), matchUserCode("user").negate());
      OrderListBuilder orderListBuilder = initialiseBuilder();
      checkFilterInitalised(orderListBuilder);
      checkFilterSet(orderListBuilder.isNotOwn(),createItem("*#$", "not user", "firm", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2));
   }

  @Test
  public void checkAtCMPriceFilterIsSet() throws Exception{
    mockFilter(OrderFilters.matchIsCMOrder(any(BigDecimal.class)), matchCMPrice(BigDecimal.ZERO));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.atCMPrice(BigDecimal.ZERO),createItem("*#$", "user", "firm", BigDecimal.ZERO, true, OrderSide.BUY, BigDecimal.valueOf(10), 2));
  }

  private Predicate<ObservableReplyRow> matchCMPrice(BigDecimal match) {
    return observableReplyRow ->
        ((MockQueryRow) (observableReplyRow.getRow())).getCmPrice().equals(match) && ((MockQueryRow) (observableReplyRow.getRow())).getDark();
  }

  @Test
  public void checkAtAbsCMMatchPriceFilterIsSet() throws Exception{
    mockFilter(
            OrderFilters.matchIsCMOrderAbs(any(BigDecimal.class)), matchCMPrice(BigDecimal.ZERO));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.atAbsCMPrice(BigDecimal.ZERO),createItem("*#$", "user", "firm", BigDecimal.ZERO, true, OrderSide.BUY, BigDecimal.valueOf(10), 2));
  }

  @Test
  public void checkIsCMFilterIsSet() throws Exception{
    mockFilter(OrderFilters.matchIsDarkOrder(), matchCMOrder(true));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.isCM(),createItem("*#$", "user", "firm", BigDecimal.ZERO, true, OrderSide.BUY, BigDecimal.valueOf(10), 2));
  }

  private Predicate<ObservableReplyRow> matchCMOrder(boolean match) {
    return observableReplyRow -> ((MockQueryRow) (observableReplyRow.getRow())).getDark() == match;
  }

  @Test
  public void checkNotCMFilterSet() throws Exception{
    mockFilter(OrderFilters.matchIsDarkOrder(), matchCMOrder(true));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.notCM(),createItem("*#$", "user", "firm", BigDecimal.ZERO, false, OrderSide.BUY, BigDecimal.valueOf(10), 2));
  }

  private Predicate<ObservableReplyRow> matchNonCM(boolean match) {
    return observableReplyRow -> !((MockQueryRow) (observableReplyRow.getRow())).getDark() == match;
  }

  @Test
  public void checkInSideOrdSideObjectFilterSet() throws Exception{
    mockFilter(OrderFilters.matchSide(any(OrderSide.class)), matchOrderSide(OrderSide.BUY));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.inSide(OrderSide.BUY),createItem("*#$", "user", "firm", BigDecimal.ZERO, true, OrderSide.BUY, BigDecimal.valueOf(10), 2));
  }

  private Predicate<ObservableReplyRow> matchOrderSide(OrderSide match) {
    return observableReplyRow -> ((MockQueryRow) (observableReplyRow.getRow())).getSide() == match;
  }

  @Test
  public void checkInSideOrdSideIntFilterSet() throws Exception{
    mockFilter(OrderFilters.matchBuySell(anyInt()), matchOrderSideInt(0));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.inSide(0),createItem("*#$", "user", "firm", BigDecimal.ZERO, true, OrderSide.BUY, BigDecimal.valueOf(10), 0));
  }

  private Predicate<ObservableReplyRow> matchOrderSideInt(int match) {
    return observableReplyRow ->
        ((MockQueryRow) (observableReplyRow.getRow())).getSideInt() == match;
  }

  @Test
  public void checkInAtPriceFilterSet() throws Exception{
    mockFilter(OrderFilters.matchPrice(any(BigDecimal.class)), matchPrice(BigDecimal.TEN));
    OrderListBuilder orderListBuilder = initialiseBuilder();
    checkFilterInitalised(orderListBuilder);
    checkFilterSet(orderListBuilder.atPrice(BigDecimal.TEN),createItem("*#$", "user", "firm", BigDecimal.ZERO, true, OrderSide.BUY, BigDecimal.TEN, 2));
  }

  private Predicate<ObservableReplyRow> matchPrice(BigDecimal match) {
    return observableReplyRow -> ((MockQueryRow) (observableReplyRow.getRow())).getPrice().equals(match);
  }

  @Test
  public void filterNullSecNames() throws Exception{
    mockFilter(OrderFilters.matchSecCode(anyString()), matchSecCode(null));
    mockFilter(OrderFilters.matchSecCode(null), matchSecCode(null));
    firstItem = createItem(null, null, null, null, null, null, null, 0);
    secondItem = createItem("sec", null, null, null, null, null, null, 0);
    addItemPrimaryList(firstItem, secondItem);
    OrderListBuilder orderListBuilder =
        new OrderListBuilder(list, "", "");
    ObservableList<ObservableReplyRow> actual = orderListBuilder.ofSec(null).build();
    ObservableList<ObservableReplyRow> expected = createExpectedList(firstItem);
    assertEquals(expected, actual);
  }

  private ObservableReplyRow createItem(
      String secCode,
      String userName,
      String firmId,
      BigDecimal cmPrice,
      Boolean isDark,
      OrderSide side,
      BigDecimal price,
      int sideInt) {
    return new MockObservableRow(
        new MockQueryRow(secCode, userName, firmId, cmPrice, isDark, side, price, sideInt), null);
  }

  private void addItemPrimaryList(ObservableReplyRow... items) {
    for (ObservableReplyRow item : items) {
      list.add(item);
    }
  }

  private ObservableList<ObservableReplyRow> createExpectedList(ObservableReplyRow... items) {
    ObservableList<ObservableReplyRow> expected = FXCollections.observableArrayList();
    Collections.addAll(expected, items);
    return expected;
  }

  @Test
  public void validSecCodeFiltering() throws Exception{
     mockFilter(OrderFilters.matchSecCode(anyString()),matchSecCode("*#$"));
     OrderListBuilder orderListBuilder = genericInputForTest();
     ObservableList<ObservableReplyRow> actual = orderListBuilder.ofSec("*#$").build();
     ObservableList<ObservableReplyRow> expected = createExpectedList(firstItem, secondItem);
     assertEquals(expected, actual);
  }

   private OrderListBuilder genericInputForTest() {
      firstItem = createItem("*#$", "user", "firm", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2);
      secondItem = createItem("*#$", "user2", "firm2", BigDecimal.valueOf(98), true, null, BigDecimal.valueOf(25), 0);
      thirdItem = createItem("*#$###", "user3", "firm", BigDecimal.valueOf(97), true, OrderSide.BUY, BigDecimal.valueOf(20), 0);
      addItemPrimaryList(firstItem, secondItem,thirdItem);
      return new OrderListBuilder(list, "user",  "firm");
   }

  @Test
  public void ownOrderFiltering() throws Exception{
    mockFilter(OrderFilters.matchUserID(anyString()), matchUserCode("user"));
    ObservableReplyRow firstItem = createItem("*#$", "user", null, null, null, null, null, 0);
    ObservableReplyRow secondItem = createItem("*#$", "", "user", null, null, null, null, 0);
    addItemPrimaryList(firstItem, secondItem);
    OrderListBuilder orderListBuilder = new OrderListBuilder(list,  "user", "");
    ObservableList<ObservableReplyRow> actual = orderListBuilder.own().build();
    ObservableList<ObservableReplyRow> expected = createExpectedList(firstItem);
    assertEquals(expected, actual);
  }

  @Test
  public void colleaguesOrderFiltering() throws Exception{
    mockFilter(OrderFilters.matchUserID(anyString()), matchUserCode("user"));
    mockFilter(OrderFilters.matchFirmID(anyString()), matchFirmCode("firm"));
    OrderListBuilder orderListBuilder = genericInputForTest();
    ObservableList<ObservableReplyRow> actual = orderListBuilder.colleagues().build();
    ObservableList<ObservableReplyRow> expected = createExpectedList(thirdItem);
    assertEquals(expected, actual);
  }

  @Test
  public void notOwnOrderFiltering() throws Exception{
     mockFilter(OrderFilters.notMatchUserID(anyString()), matchUserCode("user").negate());
     OrderListBuilder orderListBuilder = genericInputForTest();
    ObservableList<ObservableReplyRow> actual = orderListBuilder.isNotOwn().build();
    ObservableList<ObservableReplyRow> expected = createExpectedList(secondItem,thirdItem);
    assertEquals(expected, actual);
  }

   @Test
   public void firmOrderFiltering() throws Exception{
      mockFilter(OrderFilters.matchFirmID(anyString()), matchFirmCode("firm"));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.firm().build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(firstItem,thirdItem);
      assertEquals(expected, actual);
   }

   @Test
   public void atCmPriceFiltering() throws Exception{
      mockFilter(OrderFilters.matchIsCMOrder(any(BigDecimal.class)), matchCMPrice(BigDecimal.valueOf(98)));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.atCMPrice(BigDecimal.valueOf(98)).build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(secondItem);
      assertEquals(expected, actual);
   }

   @Test
   public void atCmAbsPriceFiltering() throws Exception{
      mockFilter(OrderFilters.matchIsCMOrderAbs(any(BigDecimal.class)), matchCMPrice(BigDecimal.valueOf(98)));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.atAbsCMPrice(BigDecimal.valueOf(98)).build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(secondItem);
      assertEquals(expected, actual);
   }
   @Test
   public void isCMFiltering() throws Exception{
      mockFilter(OrderFilters.matchIsDarkOrder(), matchCMOrder(true));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.isCM().build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(secondItem,thirdItem);
      assertEquals(expected, actual);
   }
   @Test
   public void notCMFiltering() throws Exception{
      mockFilter(OrderFilters.matchIsDarkOrder(), matchCMOrder(true));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.notCM().build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(firstItem);
      assertEquals(expected, actual);
   }

   @Test
   public void inOrderSideFiltering() throws Exception{
      mockFilter(OrderFilters.matchSide(any(OrderSide.class)), matchOrderSide(OrderSide.BUY));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.inSide(OrderSide.BUY).build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(firstItem,thirdItem);
      assertEquals(expected, actual);
   }
   @Test
   public void inOrderSideIntFiltering() throws Exception{
      mockFilter(OrderFilters.matchBuySell(anyInt()), matchOrderSideInt(0));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.inSide(0).build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(secondItem,thirdItem);
      assertEquals(expected, actual);
   }

   @Test
   public void atPriceFiltering() throws Exception{
      mockFilter(OrderFilters.matchPrice(any(BigDecimal.class)), matchPrice(BigDecimal.valueOf(20)));
      OrderListBuilder orderListBuilder = genericInputForTest();
      ObservableList<ObservableReplyRow> actual = orderListBuilder.atPrice(BigDecimal.valueOf(20)).build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(thirdItem);
      assertEquals(expected, actual);
   }

   @Test
   public void combinedFiltering() throws Exception{
      mockFilter(OrderFilters.matchPrice(any(BigDecimal.class)), matchPrice(BigDecimal.valueOf(20)));
      mockFilter(OrderFilters.matchBuySell(anyInt()), matchOrderSideInt(0));
      mockFilter(OrderFilters.matchSide(any(OrderSide.class)), matchOrderSide(OrderSide.BUY));
      mockFilter(OrderFilters.matchIsDarkOrder(), matchCMOrder(true));
      mockFilter(OrderFilters.matchUserID(anyString()), matchUserCode("user"));
      mockFilter(OrderFilters.matchFirmID(anyString()), matchFirmCode("firm"));
      mockFilter(OrderFilters.matchSecCode(anyString()),matchSecCode("sec3"));
      mockFilter(OrderFilters.matchIsCMOrder(any(BigDecimal.class)), matchCMPrice(BigDecimal.valueOf(98)));
      ObservableReplyRow item1 = createItem("sec1", "user", "firm", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2);
      ObservableReplyRow item2 = createItem("sec2", "user2", "firm2", BigDecimal.valueOf(98), true, OrderSide.SELL, BigDecimal.valueOf(25), 0);
      ObservableReplyRow item3 = createItem("sec3", "user3", "firm", BigDecimal.valueOf(97), true, OrderSide.SELL, BigDecimal.valueOf(20), 0);
      ObservableReplyRow item4 = createItem("sec4", "user", "firm4", BigDecimal.valueOf(98), false, OrderSide.BUY, BigDecimal.valueOf(10), 2);
      ObservableReplyRow item5 = createItem("sec1", "user2", "firm2", BigDecimal.valueOf(98), true, OrderSide.SELL, BigDecimal.valueOf(25), 0);
      ObservableReplyRow item6 = createItem("sec2", "user3", "firm", BigDecimal.valueOf(97), true, OrderSide.BUY, BigDecimal.valueOf(20), 0);
      ObservableReplyRow item7 = createItem("sec3", "user", "firm4", BigDecimal.valueOf(98), true, OrderSide.BUY, BigDecimal.valueOf(10), 2);
      ObservableReplyRow item8 = createItem("sec4", "user2", "firm2", BigDecimal.valueOf(98), true, OrderSide.SELL, BigDecimal.valueOf(25), 0);
      ObservableReplyRow item9 = createItem("sec1", "user3", "firm", BigDecimal.valueOf(97), true, OrderSide.BUY, BigDecimal.valueOf(20), 0);
      addItemPrimaryList(item1,item2,item3,item4,item5,item6,item7,item8,item9);
      OrderListBuilder orderListBuilder = new OrderListBuilder(list, "user",  "firm");
      ObservableList<ObservableReplyRow> actual = orderListBuilder.ofSec("sec3").own().atCMPrice(BigDecimal.valueOf(98)).inSide(OrderSide.BUY).build();
      ObservableList<ObservableReplyRow> expected = createExpectedList(item7);
      assertEquals(expected, actual);
   }


}
