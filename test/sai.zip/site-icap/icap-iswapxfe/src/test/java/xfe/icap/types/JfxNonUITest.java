package xfe.icap.types;

import xstr.amp.Xtr;
import xstr.amp.AmpService;
import xstr.session.Credentials;
import xstr.session.ServerSession;
import xstr.session.XstrClientConfig;
import javafx.application.Application;
import javafx.stage.Stage;
import org.junit.After;
import xstr.icap.amp.ICAPAmpSiteConfig;
import xstr.util.XstrIni.Key;

public class JfxNonUITest extends Application {
   private static boolean isInitialised;
   protected final ServerSession session = new ServerSession(AmpService.INSTANCE);

   @Override
   public void start(Stage primaryStage) throws Exception {
      // noop
   }

   protected static void initJFX() {
      if (isInitialised) return;
      isInitialised = true;
      Thread t = new Thread("JavaFX Init Thread") {
         public void run() {
            Application.launch(JfxNonUITest.class);
         }
      };
      t.setDaemon(true);
      t.start();
      Xtr.init(new ICAPAmpSiteConfig());
   }

   protected void logon(String user, String address) throws Exception {
      XstrClientConfig config = XstrClientConfig.newConfig();
      config.set(Key.TSMR_POSSIBLE_HOSTS, address);
      session.logon(Credentials.create(user), config).get();
      System.out.println("");
      System.out.println("");
      System.out.println("");
      System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> STARTING TEST <<<<<<<<<<<<<<<<<<<<<<<<<<<<");

   }

   @After
   public void Logout() throws Exception {
      System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> FINISHED TEST <<<<<<<<<<<<<<<<<<<<<<<<<<<<");
      System.out.println("");
      System.out.println("");
      System.out.println("");
      session.logoff("Test concluded.").get();
   }




}
