package xfe.icap.util;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * Created by soopot on 10/1/2019.
 *
 * @author Sooraj Pottekat
 */
public class ToasterDemo extends Application {
   static int i;
  @Override
  public void start(Stage primaryStage) throws Exception {
     primaryStage.setTitle("Demo App");
     Button button = new Button("My Button");
     button.setOnAction((event) -> Toaster.toastError("Header", "Long long motification try to " +
        "fit in to the given width and height like lorum ipsum statements " +
        "to test the word diplay properties of a notification stribnf abs how it display errror" + ++i));
     Scene scene = new Scene(button,200d,200d);
     primaryStage.setScene(scene);
     primaryStage.show();
  }

   public static void main(String[] args) {
      Application.launch(args);
   }
}
