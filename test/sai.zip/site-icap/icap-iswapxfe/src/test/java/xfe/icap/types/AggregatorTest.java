package xfe.icap.types;


import org.junit.Ignore;
import xstr.session.CachedQueryFeed;
import xstr.session.CachedQueryFeed.FeedStateListener;
import xstr.amp.AMP;
import xstr.session.XtrQueryRequest;
import xstr.session.XtrQueryRequestBuilder;
import xstr.util.FeedAggregator;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xstr.session.ObservableReplyRow;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import xstr.session.ObservableReplyRow.ObservableRowFactory;

import java.util.ArrayList;
import java.util.concurrent.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
// This unit test needs running engine so only possible for manual test
@Ignore
public class AggregatorTest extends JfxNonUITest {
   XtrQueryRequest trimReq1;
   XtrQueryRequest trimReq2;
   XtrQueryRequest trimReq3;

   public AggregatorTest() {}

   @BeforeClass
   public static void initXtr() {
      initJFX();
   }

   @Before
   public void setUp() throws Exception {
      logon("A Davies", "linux15.mtech:15170");
      trimReq1 = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req,
         session).set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), new Long[] { 1L }).build();
      trimReq2 = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req,
         session).set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), new Long[] { 2L }).build();
      trimReq3 = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req,
         session).set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), new Long[] { 3L, 4L, 5L }).build();

   }

   abstract static class FutureListener implements ListChangeListener<ObservableReplyRow> {
      public static final String SUCCESS = "SUCCESS";
      private static int nextID;
      final int id = nextID++;
      protected CompletableFuture<String> result = new CompletableFuture<>();

      Future<String> doneFuture() {
         return result;
      }
   }

   static class RowCountListener extends FutureListener {
      int expectedRowCount;
      FeedAggregator<ObservableReplyRow> aggregator;

      RowCountListener(int expectedRowCount, FeedAggregator<ObservableReplyRow> aggregator) {
         this.expectedRowCount = expectedRowCount;
         this.aggregator = aggregator;
         aggregator.busyProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue && aggregator.items.size() == expectedRowCount) {
               result.complete(SUCCESS);
            } else {
               result.complete("Expected " + expectedRowCount + " rows but got " + aggregator.items.size() + "  " + id);
            }
         });
      }

      void reset() {
         result = new CompletableFuture<>();
      }

      void onDone() {}

      @Override
      public void onChanged(Change<? extends ObservableReplyRow> c) {
         if (result.isDone()) return;

         while (c.next()) {
            if (c.wasAdded()) {
               if (c.getList().size() > expectedRowCount) {
                  result.complete("Too many rows: Expected " + expectedRowCount + " rows but got " + aggregator.items.size() + "  " + id);
               }
            } else {
               result.complete("Unexpected change event: " + id);
            }
         }
      }

      @Override
      public String toString() {
         return getClass().getName() + "[" + id + "]";
      }


   }



   FeedAggregator<ObservableReplyRow> createAggregator() {
      return new FeedAggregator<> (
         AmpIcapSecBoardTrim2.rep,
         new ObservableRowFactory());
   }

   @Test
   public void testMultiAggregatorAddRemove() throws InterruptedException, TimeoutException, ExecutionException {
      CachedQueryFeed testFeed = (CachedQueryFeed) session.queries.getFeedSource(trimReq1);

      CountDownLatch lastListener = new CountDownLatch(1);
      testFeed.addStateListener(new FeedStateListener() {
         @Override
         public void onLastListenerRemoved() {
            lastListener.countDown();
         }
      });

      int ITERATIONS = 100;

      ArrayList<FeedAggregator<ObservableReplyRow>> aggregators = new ArrayList<>();
      ArrayList<RowCountListener> listeners = new ArrayList<>();
      for (int i = 0; i < ITERATIONS; i++) {
         FeedAggregator<ObservableReplyRow> agg1 = createAggregator();
         FeedAggregator<ObservableReplyRow> agg2 = createAggregator();
         RowCountListener l1 = new RowCountListener(1, agg1);
         RowCountListener l2 = new RowCountListener(1, agg2);
         listeners.add(l1);
         listeners.add(l2);
         aggregators.add(agg1);
         aggregators.add(agg2);
         testFeed.addListener(agg1);
         Platform.runLater(() -> testFeed.addListener(agg2));
         Thread.sleep(10);
      }
      for (RowCountListener l: listeners) {
         assertEquals(RowCountListener.SUCCESS, l.doneFuture().get(5, TimeUnit.SECONDS));
      }

      for (int i = 0; i < ITERATIONS * 2; i+=2) {
         FeedAggregator<ObservableReplyRow> l1 = aggregators.get(i);
         FeedAggregator<ObservableReplyRow> l2 = aggregators.get(i+1);
         testFeed.removeListener(l1);
         Platform.runLater(() -> testFeed.removeListener(l2));
      }
      assertTrue(lastListener.await(5, TimeUnit.SECONDS));
   }

   @Test
   public void testSingleAggregatorAddRemove() throws InterruptedException {
      CachedQueryFeed testFeed = (CachedQueryFeed) session.queries.getFeedSource(trimReq1);

      CountDownLatch lastListener = new CountDownLatch(1);
      testFeed.addStateListener(new FeedStateListener() {
         @Override
         public void onLastListenerRemoved() {
            lastListener.countDown();
         }
      });

      int ITERATIONS = 100;
      FeedAggregator<ObservableReplyRow> agg1 = createAggregator();
      testFeed.addListener(agg1);
      for (int i = 0; i < ITERATIONS; i++) {
         testFeed.removeListener(agg1);
         testFeed.addListener(agg1);
         Thread.sleep(10);
         testFeed.removeListener(agg1);
         testFeed.addListener(agg1);
         Thread.sleep(10);
      }

      CountDownLatch busyLatch = new CountDownLatch(1);
      agg1.busyProperty().addListener((observable, oldValue, newValue) -> {
         if (!newValue) busyLatch.countDown();
      });
      if (!agg1.isBusy()) {
         busyLatch.countDown();
      }
      assertTrue(busyLatch.await(5, TimeUnit.SECONDS));
      assertEquals(1, agg1.items.size());
      testFeed.removeListener(agg1);

      assertTrue(lastListener.await(5, TimeUnit.SECONDS));
   }


   CountDownLatch waitForFinalRowCount(FeedAggregator<ObservableReplyRow> aggregator, int rowCount) {
      CountDownLatch busyLatch = new CountDownLatch(1);
      ChangeListener<Boolean> busyListener = new ChangeListener<Boolean>() {
         @Override
         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            if (!newValue && aggregator.items.size() == rowCount) {
               busyLatch.countDown();
               aggregator.busyProperty().removeListener(this);
            }
         }
      };
      Platform.runLater(() -> {
         aggregator.busyProperty().addListener(busyListener);
         if (!aggregator.isBusy() && aggregator.items.size() == rowCount) {
            busyLatch.countDown();
         }
      });
      return busyLatch;
   }

   @Test
   public void testSingleAggregatorMultiFeedAddRemove() throws InterruptedException {
      CachedQueryFeed testFeed1 = (CachedQueryFeed) session.queries.getFeedSource(trimReq1);
      CachedQueryFeed testFeed2 = (CachedQueryFeed) session.queries.getFeedSource(trimReq3);


      int ITERATIONS = 100;
      FeedAggregator<ObservableReplyRow> agg1 = createAggregator();
      testFeed1.addListener(agg1);
      for (int i = 0; i < ITERATIONS; i++) {
         testFeed1.removeListener(agg1);
         testFeed2.addListener(agg1);
         Thread.sleep(10);
         assertTrue(waitForFinalRowCount(agg1, 3).await(5, TimeUnit.SECONDS));
         testFeed2.removeListener(agg1);
         testFeed1.addListener(agg1);
         Thread.sleep(10);
      }
      assertTrue(waitForFinalRowCount(agg1, 1).await(5, TimeUnit.SECONDS));
      CountDownLatch lastListener = new CountDownLatch(1);
      testFeed1.addStateListener(new FeedStateListener() {
         @Override
         public void onLastListenerRemoved() {
            lastListener.countDown();
         }
      });

      testFeed1.removeListener(agg1);

      assertTrue(lastListener.await(5, TimeUnit.SECONDS));
   }


}
