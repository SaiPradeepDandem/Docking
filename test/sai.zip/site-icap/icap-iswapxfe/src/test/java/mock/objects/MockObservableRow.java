package mock.objects;

import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;

/**
 * Created by soopot on 8/13/2019.
 *
 * @author Sooraj Pottekat
 */
public class MockObservableRow extends ObservableReplyRow {
   public MockObservableRow(QueryReplyRow row, ObservableRowFactory factory) {
      super(row, factory);
   }
}
