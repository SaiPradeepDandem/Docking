package mock.objects;

import com.objsys.asn1j.runtime.Asn1Choice;
import com.objsys.asn1j.runtime.Asn1Type;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.session.QueryReplyRow;
import xstr.session.XtrKey;
import xstr.session.XtrQueryRequest;
import xstr.session.XtrRow;
import xstr.types.OrderSide;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by soopot on 8/13/2019.
 *
 * @author Sooraj Pottekat
 */
public class MockQueryRow implements QueryReplyRow {

   private final String secCode;
   private final String userID;
   private final BigDecimal cmPrice;
   private final Boolean isDark;
   private final OrderSide side;
   private final BigDecimal price;
   private final String firmId;
   private final int sideInt;

   public MockQueryRow(String secCode, String userID, String firmId, BigDecimal cmPrice, Boolean isDark, OrderSide side, BigDecimal price, int sideInt){
         this.secCode = secCode;
         this.userID = userID;
         this.firmId = firmId;
         this.cmPrice = cmPrice;
         this.isDark = isDark;
         this.side = side;
         this.price = price;
         this.sideInt = sideInt;
   }
   @Override
   public Asn1Type getAsn(AsnAccessor acc) {
      return null;
   }

   @Override
   public Asn1Choice getData() {
      return null;
   }

   @Override
   public <T> T getValue(AsnConversionAccessor<T> acc) {
      return null;
   }

   @Override
   public String getString(AsnAccessor acc) {
      return null;
   }

   @Override
   public Date getTimestamp() {
      return null;
   }

   @Override
   public XtrQueryRequest getRequest() {
      return null;
   }

   @Override
   public XtrKey getKey() {
      return null;
   }

   public String getSecCode(){
      return secCode;
   }
   public String getUserID(){
      return userID;
   }

   public BigDecimal getCmPrice() {
      return cmPrice;
   }

   public Boolean getDark() {
      return isDark;
   }

   public OrderSide getSide() {
      return side;
   }

   public BigDecimal getPrice() {
      return price;
   }

   public String getFirmId() {
      return firmId;
   }

   public int getSideInt() {
      return sideInt;
   }

   @Override
   public String toString() {
      return "[SecCode = " + secCode+ "User =" +userID + "Firm = " + firmId + " CM Price = " + cmPrice + " IsCm = "+ isDark + " Side = " + (OrderSide.BUY == side ? "Buy " : "Sell ") + "Price = " + price + "SideInt  = " +  sideInt + "]" ;
   }
}
