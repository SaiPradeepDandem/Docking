package example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class GiltsWorkupSampleApp extends Application {

   @Override
   public void start(Stage primaryStage) throws Exception {
      Parent root = FXMLLoader.load(getClass().getResource("GiltsWorkupSample.fxml"));
      primaryStage.setTitle("Workup");
//      primaryStage.initStyle(StageStyle.UNIFIED);

      primaryStage.setScene(new Scene(root, 300, 275));
      primaryStage.show();
      primaryStage.setMinWidth(root.minWidth(0));
   }

   public static void main(String[] args) {
      // This is before launch
      launch(args);

   }
}
