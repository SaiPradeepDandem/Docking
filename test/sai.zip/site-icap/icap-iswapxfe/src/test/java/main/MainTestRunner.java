package main;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

/**
 * Created by soopot on 8/14/2019.
 *
 * @author Sooraj Pottekat
 */
// TODO create infrastructure to run all the test cases from IDE/Command line rather than running from maven
// Add all the newly created suites to the this list. selectively we can add remove test suites to the list
public class MainTestRunner {
   public static void main(String[] args) {
      Result result = JUnitCore.runClasses(OrderTestSuite.class);

      for (Failure failure : result.getFailures()) {
         System.out.println(failure.toString());
      }
      System.out.println(result.wasSuccessful());
   }
}
