package main;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import xfe.icap.modules.ordersdata.OrderListBuilderTest;

/**
 * Created by soopot on 8/14/2019.
 *
 * @author Sooraj Pottekat
 */
//TODO created infrastructure for adding all the order related test classes to the suite
   // When developing if the class is related to order class please add to the test suite.
@RunWith(Suite.class)
@Suite.SuiteClasses(OrderListBuilderTest.class)
public class OrderTestSuite {
}
