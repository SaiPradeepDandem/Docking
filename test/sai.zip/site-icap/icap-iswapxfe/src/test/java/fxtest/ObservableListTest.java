package fxtest;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

import java.util.LinkedList;

/**
 * Created by jiadin on 16/08/2016.
 */
public class ObservableListTest {


   public static void main(String[] args) {
      ObservableList<String> list = FXCollections.observableList(new LinkedList<>());
      list.add("a");
      list.add("b");
      list.add("c");
      list.add("d");
      list.add("e");

      list.addListener(new ListChangeListener() {
         @Override
         public void onChanged(Change c) {
            while(c.next()){
               if(c.wasRemoved()){
                  System.out.println("removed");
               }if(c.wasAdded()){
                  System.out.println("added");
               }if(c.wasReplaced()){
                  System.out.println("replace");
               }if(c.wasUpdated()){
                  System.out.println("updated");
               }
            }
         }
      });

      list.set(1,"dhahad");
      System.out.println(list);
   }
}
