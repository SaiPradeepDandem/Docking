package fxtest;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class InvalidationListenerNotCalled {
	public static void main(String[] args) {
		StringProperty value1 = new SimpleStringProperty();
		StringProperty value2 = new SimpleStringProperty();
		StringProperty value3 = new SimpleStringProperty();
		value1.bindBidirectional(value2);
		value2.bindBidirectional(value3);
		value3.addListener(new InvalidationListener() {
			@Override
			public void invalidated(Observable observable) {
				//value3.get();
				System.out.println("--> value");
			}
		});
		value1.setValue("123");
		value1.setValue("456");
	}
}
