package fxtest;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LeakyRunLaterTest extends Application {
	private static final int DEFAULT_ITERATIONS = 100000;
	int count;
	Label countLabel = new Label();
	TextField iterationField = new TextField(String.valueOf(DEFAULT_ITERATIONS));
	class TestRunner implements Runnable {

		@Override
		public void run() {
			count--;
			update();
			System.out.println("Count (After): " + count);
		}

	}

   @Override
	public void start(Stage primaryStage) throws Exception {
		Button button = new Button("Run");
		button.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				int iterations = DEFAULT_ITERATIONS;

				try {
					iterations = Integer.valueOf(iterationField.getText());
				} catch (NumberFormatException e) {
					iterationField.setText(String.valueOf(iterations));
				}
				for (int i = 0; i < iterations; i++) {
					System.out.println("Count (Before): " + count);
					count++;
					Platform.runLater(new TestRunner());
				}
			}
		});

		update();

      HBox hb = new HBox();
      hb.getChildren().addAll(new Label("Iterations:"), iterationField, button);
      hb.setSpacing(10.0);

      VBox vb = new VBox();
      vb.getChildren().addAll(countLabel, hb);
      vb.setSpacing(15);
      vb.setPadding(new Insets(10));

		primaryStage.setScene(new Scene(vb));
		primaryStage.show();
	}

	private void update() {
		countLabel.setText(String.format("Outstanding Runnables: %d", count));
	}

	public static void main(String args[]) {
		launch(args);
	}
}
