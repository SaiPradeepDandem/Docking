package fxtest;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.TilePane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class TiledButtonTest extends Application {

	
	public static void main(String args[]) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
//		Image im = new Image(DIR.url(getClass(), "editIcon.png"));
		int tileCount = 5; 
		TilePane tp = new TilePane(tileCount, 1);
		for (int i = 0; i < tileCount; ++i) {
			Button b = new Button();
			
//			b.setMinSize(40, 40);
			b.setGraphic(new Rectangle(10, 10));
			b.setMinHeight(60);
			b.setMinWidth(80);
			tp.getChildren().add(b);
		}
//		tp.setPrefTileWidth(80);
//		tp.setPrefTileHeight(80);
		stage.setScene(new Scene(tp));
		
		// TODO Auto-generated method stub
		stage.show();
	}

}
