package fxtest;

import java.util.*;

import xfe.ui.splitpane.XfeSplitComponent;
import xfe.ui.splitpane.XfeSplitPane;

import javafx.application.Application;
import javafx.beans.*;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.geometry.Orientation;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class SplitPaneTest extends Application{

	private static final List<CheckBox> vCheckBox = new ArrayList<CheckBox>(10);

	class TestComponent extends AnchorPane implements XfeSplitComponent {

		private final BooleanProperty expandProp = new SimpleBooleanProperty(true);
		private final BooleanProperty fullSize = new SimpleBooleanProperty();
		private final DoubleProperty sizeProperty = new SimpleDoubleProperty();
		private final BooleanProperty visibleProperty = new SimpleBooleanProperty(true);

		private final CheckBox expandCheckBox = new CheckBox("expaned");
		private final CheckBox fullScreenCheckBox = new CheckBox("Full Size");
		private final CheckBox visibleCheckBox = new CheckBox("Hide");
		private final CheckBox allVisible = new CheckBox("all visible");


		public TestComponent(String string, XfeSplitPane parentPane) {
			allVisible.setSelected(true);
			vCheckBox.add(visibleCheckBox);
			expandCheckBox.setSelected(true);
			Label label = new Label(string);
			this.getChildren().addAll(label,expandCheckBox,fullScreenCheckBox, visibleCheckBox,allVisible);
			visibleCheckBox.setSelected(true);
			AnchorPane.setLeftAnchor(expandCheckBox,0D);

			AnchorPane.setLeftAnchor(fullScreenCheckBox,100D);

			AnchorPane.setLeftAnchor(visibleCheckBox,200D);

			AnchorPane.setRightAnchor(label,0D);
			AnchorPane.setRightAnchor(allVisible,100D);

			allVisible.selectedProperty().addListener(new InvalidationListener() {

				@Override
				public void invalidated(Observable observable) {
               for(CheckBox checkbox:vCheckBox){
                   checkbox.setSelected(allVisible.isSelected());
               }
            }
			});
			expandProp.bind(expandCheckBox.selectedProperty());
         expandCheckBox.selectedProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
               parentPane.setComponentChanged();
               parentPane.requestLayout();
            }
         });
         fullScreenCheckBox.selectedProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
               parentPane.setComponentChanged();
               parentPane.requestLayout();
            }
         });
         visibleCheckBox.selectedProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
               parentPane.setComponentChanged();
               parentPane.requestLayout();
            }
         });
			fullSize.bind(fullScreenCheckBox.selectedProperty());
			visibleProperty.bind(visibleCheckBox.selectedProperty());
		}

		@Override
		public BooleanProperty expandProperty() {
			return expandProp;
		}

		@Override
		public BooleanProperty fullSizeProperty() {
			return fullSize;
		}

		@Override
		public Node getNode() {
			return this;
		}

		@Override
		public DoubleProperty sizeProperty() {
			return sizeProperty;
		}

		@Override
		public BooleanProperty displayProperty() {
			return visibleProperty;
		}

	}


	@Override
	public void start(Stage stage) throws Exception {


        XfeSplitPane<XfeSplitComponent> xfePane = new XfeSplitPane<XfeSplitComponent>();
//        HBox.setHgrow(xfePane, Priority.ALWAYS);
        SplitPane splitPane = new SplitPane();
        splitPane.setOrientation(Orientation.VERTICAL);

        Scene scene = new Scene(xfePane, 500, 500);
        stage.setScene(scene);

        scene.getStylesheets().addAll("css/iswap.css");


		TestComponent firstButton = new TestComponent("First",xfePane);
		firstButton.sizeProperty.set(50);
		firstButton.setId("first");

        TestComponent secondButton = new TestComponent("Second",xfePane);
        secondButton.setId("second");
        secondButton.sizeProperty.set(100);

        TestComponent thirdButton = new TestComponent("Third",xfePane);
        thirdButton.setId("third");
        thirdButton.sizeProperty.set(150);

        TestComponent fourButton = new TestComponent("Forth",xfePane);
        fourButton.setId("forth");
        fourButton.sizeProperty.set(70);

        TestComponent fifth = new TestComponent("Fifth",xfePane);
        fifth.sizeProperty.set(130);
        fifth.setId("Fifth");
        xfePane.setItems(firstButton, secondButton, thirdButton, fourButton, fifth);

        stage.show();


	}

    public static void main(String[] args) {
        launch(args);
    }

}
