package fxtest;

import java.util.*;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import com.nomx.persist.Searchable;

public class SearchableTreeTest extends Application{

   @Override
   public void start(Stage primaryStage) throws Exception {
      primaryStage.setScene(createScene());
      primaryStage.setHeight(500);
      primaryStage.setWidth(500);
      primaryStage.show();
   }

   private Scene createScene() {
      VBox root = new VBox();
      Scene scene = new Scene(root);
      SearchableTreeView tree = createTreeView();
      TextField filter = new TextField();
      EventHandler<KeyEvent> enterHandler = new EventHandler<KeyEvent>() {

         @Override
         public void handle(KeyEvent arg0) {
            if(arg0.getCode()==KeyCode.ENTER){
               tree.filte(filter.getText());
            }
         }
      };
      filter.addEventFilter(KeyEvent.KEY_PRESSED,enterHandler);
      root.getChildren().add(tree);
      root.getChildren().add(filter);
//      root.getChildren().add();
      return scene;
   }



   private SearchableTreeView createTreeView() {
      SearchableTreeView<SearchableString> treeView = new SearchableTreeView<SearchableString>();
      treeView.setShowRoot(false);
      treeView.setRoot(new SearchableTreeItem<SearchableString>(new SearchableString("root")));
      treeView.getRoot().getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("child1-1")));
      treeView.getRoot().getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("child1-2")));
      treeView.getRoot().getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("child1-3")));
      treeView.getRoot().getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("child1-4")));
      treeView.getRoot().getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("child1-5")));
      treeView.getRoot().getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("child1-6")));

      treeView.getRoot().getChildren().get(0).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("grandson1-1")));
      treeView.getRoot().getChildren().get(0).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("grandson1-2")));
      treeView.getRoot().getChildren().get(0).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("grandson1-3")));
      treeView.getRoot().getChildren().get(0).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("grandson1-4")));
      treeView.getRoot().getChildren().get(0).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("grandson1-5")));
      treeView.getRoot().getChildren().get(0).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("grandson1-6")));


      treeView.getRoot().getChildren().get(1).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("granddaught2-1")));
      treeView.getRoot().getChildren().get(1).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("granddaught2-2")));
      treeView.getRoot().getChildren().get(1).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("granddaught2-3")));
      treeView.getRoot().getChildren().get(1).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("granddaught2-4")));
      treeView.getRoot().getChildren().get(1).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("granddaught2-5")));
      treeView.getRoot().getChildren().get(1).getChildren().add(new SearchableTreeItem<SearchableString>(new SearchableString("granddaught2-6")));

      return treeView;
   }

   private class SearchableString implements Searchable{
      private final String str;


      public SearchableString(String str) {
         super();
         this.str = str;
      }


      @Override
      public boolean contains(String str) {
         return this.str.toLowerCase().contains(str.toLowerCase());
      }

      @Override
      public String toString() {
         return str;
      }
   }


   class SearchableTreeView<T extends Searchable> extends TreeView<T>{

      public void filte(String filter){
         TreeItem<T> root = this.getRoot();
         if(filter==null || filter.length()==0){
            RemoveFilter((SearchableTreeItem<T>)root);
         }else{
            Filter((SearchableTreeItem<T>)root, filter);
         }
      }

   }
   /**
    *
    * @param treeItem
    * @param filter
    * @return true, if any of the children or the treeitem itself matches the filter. false, if none of the children matches the filter and the treeitem itself does not matches the filter
    */
   private static <T extends Searchable> boolean Filter(SearchableTreeItem<T> treeItem, String filter){
      if(treeItem==null){
         return false;
      }
      boolean rtn = treeItem.getValue().contains(filter);
      List<TreeItem<T>> cloned = treeItem.getClonedOriginalChildren();
      if(cloned!=null){
         Iterator<TreeItem<T>> iterator = cloned.iterator();
         while(iterator.hasNext()){
            boolean match = Filter((SearchableTreeItem<T>)iterator.next(), filter);
            if(!match){
               iterator.remove();
            }
            rtn =  match || rtn;
         }
         treeItem.getChildren().setAll(cloned);
      }
      return rtn;
   }

   private static <T extends Searchable> void RemoveFilter(SearchableTreeItem<T> treeItem){
      if(treeItem==null){
         return ;
      }
      List<TreeItem<T>> children = treeItem.getClonedOriginalChildren();
      if(children!=null){
         for(TreeItem<T> child:children){
            RemoveFilter((SearchableTreeItem<T>)child);
         }
      }
      treeItem.removeFilter();
   }

   class SearchableTreeItem<T extends Searchable> extends TreeItem<T>{

      private List<TreeItem<T>> originalChildren;

      public SearchableTreeItem(T t) {
         super(t);
      }

      public void removeFilter(){
         if(this.getChildren().size()!=originalChildren.size()){
            this.getChildren().setAll(originalChildren);
         }
      }

      public List<TreeItem<T>> getClonedOriginalChildren(){
         if(originalChildren==null) {
            originalChildren = new ArrayList<TreeItem<T>>(this.getChildren());
         }
         if(originalChildren!=null){
            List<TreeItem<T>> cloned = new ArrayList<TreeItem<T>>(originalChildren);
            return cloned;
         }
         return null;
      }

}


   public static void main(String[] args){
      Application.launch(args);
   }
}

