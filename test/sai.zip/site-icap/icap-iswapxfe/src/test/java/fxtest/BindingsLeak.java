package fxtest;

import java.lang.ref.WeakReference;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.binding.NumberBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ObservableIntegerValue;

public class BindingsLeak {
	static int counter1;
	static int counter2;

	public static class MyBindingHelperObserver implements InvalidationListener {
		private final WeakReference<IntegerBinding> ref;
		private final WeakReference<Observable> observable;

		public MyBindingHelperObserver(IntegerBinding paramBinding, Observable observable) {
			this.observable = new WeakReference<Observable>(observable);

			if (paramBinding == null) {
				throw new NullPointerException("Binding has to be specified.");
			}

			this.ref = new WeakReference<IntegerBinding>(paramBinding);
		}

		public void invalidated(Observable paramObservable) {
			IntegerBinding localBinding = this.ref.get();

			if (localBinding == null) {
				paramObservable.removeListener(this);
			} else {
				localBinding.invalidate();
			}
		}

		public void houseKeep() {
			Observable localObservable = observable.get();

			if (localObservable != null) {
				IntegerBinding localBinding = this.ref.get();

				if (localBinding == null) {
					localObservable.removeListener(this);
				}
			}
		}
	}

	public static IntegerBinding weak(ObservableIntegerValue value) {
		if (value == null) {
			throw new NullPointerException("Operands cannot be null.");
		}

		return new IntegerBinding() {
			private MyBindingHelperObserver observer;

			{
				myBind(value);
			}

			public void addListener(InvalidationListener listener) {
				super.addListener(listener);
				if (this.observer != null) {
					this.observer.houseKeep();
				}
			}


			protected final void myBind(Observable observable) {
				if (observable != null) {
					if (this.observer == null) {
						this.observer = new MyBindingHelperObserver(this, observable);
					}
					observable.addListener(this.observer);
				}
			}

			protected final void myUnbind(Observable observable) {
				if (this.observer != null) {
					observable.removeListener(this.observer);
					this.observer = null;
				}
			}

			public void dispose() {
				myUnbind(value);
			}

			protected int computeValue() {
				return value.get();
			}
		};
	}


	public static void main(String[] args) {
		IntegerProperty property1 = new SimpleIntegerProperty(0) {
			@Override
			public void addListener(InvalidationListener listener) {
				counter1 += 1;
				super.addListener(listener);
			}
			@Override
			public void removeListener(InvalidationListener listener) {
				counter1 -= 1;
				super.removeListener(listener);
			}
		};
		IntegerProperty property2 = new SimpleIntegerProperty(1) {
			public void addListener(InvalidationListener listener) {
				counter2 += 1;
				super.addListener(listener);
			}
			public void removeListener(InvalidationListener listener) {
				counter2 -= 1;
				super.removeListener(listener);
			}
		};
		IntegerBinding weak1 = weak(property1);
		IntegerBinding weak2 = weak(property2);

		IntegerProperty observer = new SimpleIntegerProperty();

		NumberBinding binding1 = null;
		NumberBinding binding2 = null;

		for (int j = 0; j < 200; ++j) {
			for (int i = 0; i < 10000; ++i) {
				//property1.set(property1.get() + 1);
				//property2.set(property1.get() + 2);
				if (binding2 != null) {
					//binding2.dispose();
				}
				binding1 = Bindings.add(property1, property1);
				observer.bind(binding1);
				if (binding1 != null) {
					//binding1.dispose();
				}
				binding2 = Bindings.add(property2, property2);
				observer.bind(binding2);
			}

			//System.gc();
			System.out.println("--> iteration " + j + ": " + counter1 + ", " + counter2);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		try {
			Thread.sleep(1000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
