package fxtest;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import org.junit.Test;

public class BindingTestUnbind {

   /**
    * Calling unbind unexpectedly evaluates its dependencies
    */
   @Test
   public void testBindContent() {

      StringProperty s1 = new SimpleStringProperty("");
      StringProperty s2 = new SimpleStringProperty("abc");
      AtomicInteger modCount = new AtomicInteger(0);
      StringBinding b1 = Bindings.createStringBinding(new Callable<String>() {

         @Override
         public String call() {

            return s1.get() + String.valueOf(modCount.incrementAndGet());
         }
      }, s1);

      System.out.println("b1 --> " + b1);
      assertEquals(0, modCount.get());
      s1.set("123");
      System.out.println("b1 --> " + b1);
      assertEquals(0, modCount.get());
      s2.bind(b1);
      System.out.println("b1 --> " + b1);
      assertEquals(1, modCount.get());
      s1.set("456");
      assertEquals(1, modCount.get());
      System.out.println("b1 --> " + b1);
      s2.unbind();
      System.out.println("b1 --> " + b1);
      assertEquals(1, modCount.get());
      assertEquals("456" + "1", s2.get());


   }

}
