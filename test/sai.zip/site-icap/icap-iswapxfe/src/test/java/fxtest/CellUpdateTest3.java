package fxtest;

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import xfe.ui.table.DynamicTableCell;

/**
 * Reproduce cell update bug. Compile and run the class. Press the update button
 * a couple of times and note how the values in the total column update. Press
 * the GC button a couple of times and then press the update button again. Note
 * how the values in the total column do not update anymore.
 *
 * The Value Factory for the total column does not return a property that is
 * held by the Order object, it returns a Binding that is created on the fly.
 * The cell does not hold a strong reference to this object so it can be gc'd
 * Tested in JavaFX 2.0 and 2.1
 */
public class CellUpdateTest3 extends Application {

	static class Order {
		String name;
		DoubleProperty price = new SimpleDoubleProperty();
		DoubleProperty qty = new SimpleDoubleProperty();

		Order(String n, double p) {
			name = n;
			price.set(p);
			qty.set(1);
		}
	}

	final Order items[] = { new Order("Item 0", 4.0), new Order("Item 1", 5.0),
			new Order("Item 2", 6.0), new Order("Item 3", 7.0),
			new Order("Item 4", 8.0), new Order("Item 5", 9.0),
			new Order("Item 6", 10.0), new Order("Item 7", 11.0) };

	@Override
	public void start(Stage primaryStage) throws Exception {

		Button updateButton = new Button("Update Values");
		updateButton.setOnAction(new EventHandler<ActionEvent>() {
			int idx;

			@Override
			public void handle(ActionEvent actionEvent) {
				// for (Order i: items) {
				// i.qty.set(i.qty.get() + 1);
				// }
				idx = (idx + 1) % items.length;
				items[idx].qty.set(items[idx].qty.get() + 1);
			}
		});

		Button gcButton = new Button("System.gc()");
		gcButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				System.gc();
			}
		});

		TableView<Order> tv = new TableView<Order>();
		TableColumn<Order, String> nameCol = new TableColumn<Order, String>(
				"Item");
		TableColumn<Order, Number> priceCol = new TableColumn<Order, Number>(
				"Price");
		TableColumn<Order, Number> qtyCol = new TableColumn<Order, Number>(
				"Quantity");
		TableColumn<Order, Number> totalCol = new TableColumn<Order, Number>(
				"Total");

		nameCol.setCellValueFactory(new Callback<CellDataFeatures<Order, String>, ObservableValue<String>>() {
			@Override
			public ObservableValue<String> call(
					CellDataFeatures<Order, String> d) {
				return new ReadOnlyStringWrapper(d.getValue().name);
			}
		});

		priceCol.setCellValueFactory(new Callback<CellDataFeatures<Order, Number>, ObservableValue<Number>>() {
			@Override
			public ObservableValue<Number> call(
					CellDataFeatures<Order, Number> cellData) {
				return cellData.getValue().price;
			}
      });

		qtyCol.setCellValueFactory(new Callback<CellDataFeatures<Order, Number>, ObservableValue<Number>>() {
			@Override
			public ObservableValue<Number> call(
					CellDataFeatures<Order, Number> cellData) {
				return cellData.getValue().qty;
			}
      });

		totalCol.setCellValueFactory(new Callback<CellDataFeatures<Order, Number>, ObservableValue<Number>>() {
			Order o;
			ObservableValue<Number> n;

			@Override
			public ObservableValue<Number> call(
					CellDataFeatures<Order, Number> cellData) {
				if (o != null && cellData.getValue() == o) {
					System.out.println(">>>>>>>>>>>>>>>> Hit!!!! " + o.price
							+ " - " + cellData.getValue().price);
					return n;
				}
				System.out.println(">>>>>>>>>>>>>>>> Miss!!! "
						+ (o == null ? "null" : o.price) + " - "
						+ cellData.getValue().price);
				o = cellData.getValue();
				n = o.price.multiply(o.qty);

				return n;
			}
      });

		totalCol.setCellFactory(new Callback<TableColumn<Order, Number>, TableCell<Order, Number>>() {
			int count;

			@Override
			public TableCell<Order, Number> call(
					TableColumn<Order, Number> paramP) {
				System.out.println("New Cell.... " + count++);
				DynamicTableCell<Order, Number> cell = new DynamicTableCell<Order, Number>();
				cell.setValueFactory(new Callback<Order, ObservableValue<Number>>() {

					@Override
					public ObservableValue<Number> call(Order o) {
						System.out.println(">>>>>>>>>>>>>>>> New Value: "
								+ o.price);
						return o.price.multiply(o.qty);
					}
				});
				return cell;
			}
		});

		tv.getColumns().addAll(nameCol, priceCol, qtyCol, totalCol);
		tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		tv.getItems().addAll(items);

      HBox hb = new HBox();
      hb.getChildren().addAll(updateButton, gcButton);

      VBox vb = new VBox();
      vb.getChildren().addAll(tv, hb);

		primaryStage.setScene(new Scene(vb));
		primaryStage.setHeight(200.0);
		primaryStage.show();
	}

	public static void main(String args[]) {
		launch(args);
	}
}
