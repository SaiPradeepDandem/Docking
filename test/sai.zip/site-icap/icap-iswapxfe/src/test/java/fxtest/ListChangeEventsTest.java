package fxtest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.stage.Stage;

public class ListChangeEventsTest  extends Application {

	int changeCount;
	@Override
	public void start(Stage arg0) throws Exception {
		ObservableList<String> sl = FXCollections.observableArrayList("A", "B", "C", "D", "E", "F", "G", "H");
		sl.addListener(new ListChangeListener<String>(){

         @Override
         public void onChanged(Change<? extends String> c) {
            System.out.println(">>>>>>> Change #" + ++changeCount);
            int chngNo = 0;
            while (c.next()) {
               System.out.println("Change iteration #" + chngNo++ + " From: " + c.getFrom() + " To: " + c.getTo());

               System.out.println("Removed: " + c.getRemoved());
               System.out.println("Added: " + c.getAddedSubList());
               System.out.println("WasRemoved: " + c.wasRemoved());
               System.out.println("WasAdded: " + c.wasAdded());
               System.out.println("WasReplaced: " + c.wasReplaced());
               System.out.println("WasUpdated: " + c.wasUpdated());
               System.out.println("--------------------------");

            }
            System.out.println(">>>>>>> End Change #" + changeCount);
         }

		});

		System.out.println("Initial List: " + sl);

		sl.addAll("1", "2", "3");

		sl.set(1, "4");

		// Collates removals into 2 iterations of contiguous changes
      sl.removeAll("7", "D", "J", "1");

      ArrayList<String> newList = new ArrayList<String>(sl);
      List<String> subL = newList.subList(2, 6);
      subL.clear();
      subL.addAll(Arrays.asList("10", "11", "12", "13"));
      sl.setAll(newList);

      System.out.println("Final List: " + sl);
	}

	public static void main(String args[]) {
		launch(args);
	}

}
