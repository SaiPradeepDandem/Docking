package fxtest;

import java.lang.ref.WeakReference;

import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class BindingsTest2 {

	/**
	 * Test to see if Bindings.bindContent creates a strong reference to the bound list
	 */
	static void testBindContent() {
		ObservableList<String> list1 = FXCollections.observableArrayList();
		WeakReference<ObservableList<String>> list1Ref = new WeakReference<ObservableList<String>>(list1);
		list1.addAll("aaa", "bbb", "ccc");
		ObservableList<String> list2 = FXCollections.observableArrayList();
		Bindings.bindContent(list2, list1);
		list1 = null;
		System.out.println(list1Ref.get());
		System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();
		System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();
		System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();
		System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();System.gc();
		// if this line prints a non-null list value it means that a strong binding was created
		System.out.println(list1Ref.get());
		// The above line produces 'null' as output
	}


	public static void main(String[] args) {

		testBindContent();
	}
}
