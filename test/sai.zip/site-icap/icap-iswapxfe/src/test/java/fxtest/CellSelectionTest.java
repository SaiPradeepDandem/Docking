package fxtest;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Callback;


public class CellSelectionTest extends Application {
	final SimpleStringProperty testString = new SimpleStringProperty("Initial");
	int selectedIndex;

	static class ValuableItem {
		String name;
		double value;

		ValuableItem(String n, double v) {
			name = n;
			value = v;
		}
	}

   ObservableList<ValuableItem> items = FXCollections.observableArrayList (
      new ValuableItem("Item 0", 4.0),
      new ValuableItem("Item 1", 5.0),
      new ValuableItem("Item 2", 6.0),
      new ValuableItem("Item 3", 7.0),
      new ValuableItem("Item 4", 8.0),
      new ValuableItem("Item 5", 9.0),
      new ValuableItem("Item 6", 10.0),
      new ValuableItem("Item 7", 11.0));

	@Override
	public void start(Stage primaryStage) throws Exception {
		Button button = new Button("Remove selected row");
		button.setOnAction(actionEvent -> {
         items.remove(selectedIndex);
      });

      Button button2 = new Button("Remove prev row");
      button2.setOnAction(actionEvent -> {
         if (selectedIndex > 0) items.remove(selectedIndex - 1);
      });

      Button button3 = new Button("Add New Row");
      button3.setOnAction(actionEvent -> {
         items.add(selectedIndex + 1, new ValuableItem("New Item", 0));
      });

      Button button4 = new Button("Replace selected row");
      button4.setOnAction(actionEvent -> {
         items.set(selectedIndex, new ValuableItem("Subs Item", 100));
      });

		TableView<ValuableItem> tv = new TableView<>();
		TableColumn<ValuableItem, String> nameCol = new TableColumn<>("Item");
		TableColumn<ValuableItem, ObservableValue<String>> valueCol = new TableColumn<>("Value");

		nameCol.setCellValueFactory(d -> new SimpleObjectProperty<>(d.getValue().name));

		valueCol.setCellValueFactory(new Callback<CellDataFeatures<ValuableItem, ObservableValue<String>>, ObservableValue<ObservableValue<String>>>() {
			@Override
			public ObservableValue<ObservableValue<String>> call(CellDataFeatures<ValuableItem, ObservableValue<String>> cellDataFeature) {
				SimpleStringProperty property = new SimpleStringProperty(testString.get()) {
					final SimpleStringProperty self = this;
					final InvalidationListener ll = new InvalidationListener() {
						@Override
						public void invalidated(Observable cellDataFeature) {
							System.out.println("Invalidated: " + getClass().getSimpleName() + " " + hashCode());
							self.set(testString.get());
						}
					};

					{
						testString.addListener(new WeakInvalidationListener(ll));
					}
				};

				return new SimpleObjectProperty<>(property);
			}
      });

		valueCol.setCellFactory(new Callback<TableColumn<ValuableItem, ObservableValue<String>>, TableCell<ValuableItem, ObservableValue<String>>>() {
			@Override
			public TableCell<ValuableItem, ObservableValue<String>> call(TableColumn<ValuableItem, ObservableValue<String>> column) {
				return new TableCell<ValuableItem, ObservableValue<String>>() {
					public void updateItem(ObservableValue<String> observableValue, boolean paramBoolean) {
						super.updateItem(observableValue, paramBoolean);
						if (observableValue != null) {
							observableValue.addListener(new InvalidationListener() {
								{
									this.invalidated(observableValue);
								}

								@Override
								public void invalidated(Observable observable) {
									setText(observableValue.getValue());
									setGraphic(null);
								}
							});
						}
					}
				};
			}
		});

      tv.getColumns().add(nameCol);
      tv.getColumns().add(valueCol);
      tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
      tv.setItems(items);
      tv.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
      tv.getSelectionModel().setCellSelectionEnabled(true);
      tv.getSelectionModel().getSelectedCells().addListener(new ListChangeListener<TablePosition>() {
         @Override
         public void onChanged(Change<? extends TablePosition> c) {
            while (c.next()) {
               if (!c.getList().isEmpty()) {
                  TableColumn<?, ?> column = c.getList().get(0).getTableColumn();
                  int row = c.getList().get(0).getRow();

                  System.out.println(">>>>>>> CELL SELECTION CHANGE: " + column);
                  System.out.println(">>>>>>> column: " + column);
                  System.out.println(">>>>>>> row: " + row);

                  selectedIndex = row;
               }
            }
         }
      });

      HBox hb = new HBox();
      hb.getChildren().addAll(button, button2, button3, button4);

      VBox vb = new VBox();
      vb.getChildren().addAll(tv, hb);

      primaryStage.setScene(new Scene(vb));
      primaryStage.setHeight(200.0);
      primaryStage.show();
	}

	public static void main(String args[]) {
		launch(args);
	}
}
