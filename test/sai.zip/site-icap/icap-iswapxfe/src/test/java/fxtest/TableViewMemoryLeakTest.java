package fxtest;

import java.util.*;
import javafx.application.*;
import javafx.beans.*;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.event.*;
import javafx.geometry.Orientation;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Callback;

public class TableViewMemoryLeakTest extends Application {

   final TableView<List<StringProperty>> view = new TableView<List<StringProperty>>()
//         {
//
//      @Override
//      protected void layoutChildren() {
//         Skin<?> skinModule = viewModule.getSkin();
//         if (skinModule instanceof TableViewSkin) {
//            @SuppressWarnings("unchecked")
//            TableHeaderRow header = ((TableViewSkin) skinModule).getTableHeaderRow();
//            if(header.isVisible()){
//               header.setMaxHeight(0);
//               header.setPrefHeight(0);
//               header.setVisible(false);
//            }
//         }
//         super.layoutChildren();
//      }
//
//   }
   ;

   final int columnCount = 10;
   final int rowCount = 10;

   static int i;
   final Button dummyButton1 = new Button("dummy one"){{
      this.setMinHeight(150);
      this.setOnAction(new EventHandler<ActionEvent>() {

         @Override
         public void handle(ActionEvent event) {
            i++;
            new Thread(){
            @Override
            public void run() {
               List<List<StringProperty>> items = view.getItems();
               items.remove(0);
//               for(List<StringProperty> anItem: items){
//                  for(StringProperty cell:anItem){
//                     cell.set("c-"+i);
//                  }
//               }
            }}.start();
         }
      });
   }};
   final Button dummyButton2 = new Button("dummy two"){{
      this.setMinHeight(150);
   }};
   final Button dummyButton3 = new Button("dummy three"){{
      this.setMinHeight(150);
   }};
   final Button dummyButton4 = new Button("dummy four"){{
      this.setMinHeight(150);
   }};
   final List<Node> dummyNodes = new ArrayList<Node>(4){{
     this.add(dummyButton1);
     this.add(dummyButton2);
     this.add(dummyButton3);
     this.add(dummyButton4);
   }
   };

   @Override
   public void start(Stage paramStage) throws Exception {
      paramStage.setWidth(500);
      paramStage.setHeight(800);
      paramStage.setScene(createScene());
      fillTable();
      initTableView();
      paramStage.show();
   }

   private void initTableView(){
   }

   private void fillTable() {
      for (int row = 1; row <= rowCount; row++) {
         List<StringProperty> data = new ArrayList<StringProperty>(columnCount);
         for(int column = 1; column<=columnCount; column++){
            if(row%2==0){
               data.add(new SimpleStringProperty("even-data-" + row + "-"+column));
            }
            else {
               data.add(new SimpleStringProperty("data-" + row + "-"+column));
            }

         }
         view.getItems().add(data);
      }

   }

   private Scene createScene() {
      view.getItems().addListener(new InvalidationListener() {

         @Override
         public void invalidated(Observable arg0) {
            dummyButton2.setText("viewModule.getItems() "+view.getItems().size());
         }
      });
      for (int i = 0; i < columnCount; i++) {
         view.getColumns().add(createTC(i));
      }

      HBox root = new HBox();
      SplitPane pane = new SplitPane();
      pane.setOrientation(Orientation.VERTICAL);
      pane.getItems().setAll(view, dummyButton1, dummyButton2, dummyButton3, dummyButton4);

      HBox.setHgrow(root, Priority.ALWAYS);
      ToolBar toolbar = new ToolBar();
      root.getChildren().setAll(pane, toolbar);
      toolbar.getItems().add(new Button("FullScreen") {
         {
            this.setOnAction(new EventHandler<ActionEvent>() {

               @Override
               public void handle(ActionEvent arg0) {
                  //pane.getItems().setAll(viewModule);
                  pane.getItems().removeAll(dummyNodes);
                  }
            });
         }
      });
      toolbar.getItems().add(new Button("normal") {
         {
            this.setOnAction(new EventHandler<ActionEvent>() {

               @Override
               public void handle(ActionEvent arg0) {
                  pane.getItems().setAll(view, dummyButton1, dummyButton2, dummyButton3, dummyButton4);
               }
            });
         }
      });

      return new Scene(root);
   }

   private TableColumn<List<StringProperty>,String> createTC(int columnIndex){
      TableColumn<List<StringProperty>,String> column = new TableColumn<List<StringProperty>, String>();
      column.setCellValueFactory(new Callback<CellDataFeatures<List<StringProperty>,String>, ObservableValue<String>>() {

         @Override
         public ObservableValue<String> call(CellDataFeatures<List<StringProperty>, String> param) {
            return param.getValue().get(columnIndex);
         }
      });

      return column;
   }

   public static void main(String[] args){
      Application.launch(args);
   }
}
