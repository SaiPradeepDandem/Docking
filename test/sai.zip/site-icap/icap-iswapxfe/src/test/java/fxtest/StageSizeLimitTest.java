package fxtest;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class StageSizeLimitTest extends Application {

	@Override
	public void start(Stage s) throws Exception {
		VBox vb = new VBox();
		StackPane sp = new StackPane();
		s.setMaxHeight(600);
		s.setMaxWidth(600);
		s.setResizable(false);
		Label l = new Label();
		l.textProperty().bind(Bindings.format("%f x %f", sp.widthProperty(), sp.heightProperty()));
		sp.getChildren().add(l);
		l.setPrefSize(200, 200);
		l.setMinSize(100, 100);
		l.setMaxSize(400, 400);
		Scene sc = new Scene(vb);
		sp.setStyle("-fx-border-color: black;");
		Button minimizeButton = new Button("Minimize");
		minimizeButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent paramT) {
				s.setIconified(true);
			}
		});
		vb.getChildren().addAll(sp, minimizeButton);
		s.setScene(sc);
		s.initStyle(StageStyle.TRANSPARENT);
		s.show();

	}

	public static void main(String[] args) {
		Application.launch(args);
	}


}
