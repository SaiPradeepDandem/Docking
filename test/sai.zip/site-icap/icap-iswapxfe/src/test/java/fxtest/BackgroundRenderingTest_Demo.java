package fxtest;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class BackgroundRenderingTest_Demo extends Application {
    long bgTime;
    long picTime;
    @Override
    public void start(Stage stage) throws Exception {
       String pngPath = "emptyrow-bg.png";
        HBox root = new HBox();
        root.setSpacing(15);
        root.setAlignment(Pos.CENTER);

        Scene scene = new Scene(root, 500, 500);
        stage.setScene(scene);
        stage.show();

       StackPane pane1 = new StackPane();
        pane1.setStyle("-fx-background-color:linear-gradient(from 0px -8px to 0px 8px , repeat, #001E38 49% , #000000 57% , #001E38 12% );");
        HBox.setHgrow(pane1, Priority.ALWAYS);
        pane1.needsLayoutProperty().addListener((obs,old,nl)->{
            if(nl){
                System.out.println("Rendered BG in :: "+(System.currentTimeMillis()-bgTime)+"ms");
            }else{
                bgTime = System.currentTimeMillis();
            }
        });

        StackPane pane2 = new StackPane();
       pane2.setStyle("-fx-background-image: url(\""+pngPath+"\");-fx-background-repeat: repeat;-fx-background-size: auto;");
        HBox.setHgrow(pane2, Priority.ALWAYS);
        pane2.needsLayoutProperty().addListener((obs,old,nl)->{
            if(nl){
                System.out.println("Rendered Pic in :: "+(System.currentTimeMillis()-picTime)+"ms");
            }else{
                picTime = System.currentTimeMillis();
            }
        });

        root.getChildren().addAll(pane1, pane2);

    }
}
