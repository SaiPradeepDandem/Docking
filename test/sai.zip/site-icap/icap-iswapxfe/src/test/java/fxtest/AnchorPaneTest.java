package fxtest;

import xstr.util.Fx;
import javafx.application.Application;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.Date;

public class AnchorPaneTest extends Application{


	@Override
	public void start(Stage stage) throws Exception {
      Fx.runPeriodically(1000, new Runnable() {
         @Override
         public void run() {
            System.out.println(new Date());
         }
      });

      HBox hbox = new HBox();

        AnchorPane anchorPane = new AnchorPane();

        hbox.getChildren().addAll(anchorPane);

        Scene scene = new Scene(hbox, 500, 200);
        stage.setScene(scene);

        anchorPane.setStyle("-fx-border-color:red;-fx-border-width:1");
		TextArea firstButton = new TextArea("First");
		firstButton.setId("first");
        anchorPane.getChildren().add(firstButton);
        AnchorPane.setTopAnchor(firstButton, 0D);
        AnchorPane.setLeftAnchor(firstButton, 0D);
        AnchorPane.setRightAnchor(firstButton, 0D);
        AnchorPane.setBottomAnchor(firstButton, 190D);

        TextArea secondButton = new TextArea("Second");
        secondButton.setId("second");
//        secondButton.setPrefHeight(50);
        anchorPane.getChildren().add(secondButton);
        AnchorPane.setLeftAnchor(secondButton, 0D);
        AnchorPane.setRightAnchor(secondButton, 0D);
        AnchorPane.setTopAnchor(secondButton, 11D);
        AnchorPane.setBottomAnchor(secondButton, 150D);
//        secondButton.setMaxHeight(40D);

        TextArea thirdButton = new TextArea("Third");
        thirdButton.setId("third");
//        thirdButton.setPrefHeight(50);
        anchorPane.getChildren().add(thirdButton);
        AnchorPane.setLeftAnchor(thirdButton, 0D);
        AnchorPane.setRightAnchor(thirdButton, 0D);
        AnchorPane.setTopAnchor(thirdButton, 50D);
        AnchorPane.setBottomAnchor(thirdButton, 120D);
//        thirdButton.setMaxHeight(25D);

        TextArea fourButton = new TextArea("Forth");
        fourButton.setId("forth");
//        fourButton.setPrefHeight(50);
        anchorPane.getChildren().add(fourButton);
        AnchorPane.setLeftAnchor(fourButton, 0D);
        AnchorPane.setRightAnchor(fourButton, 0D);
        AnchorPane.setTopAnchor(fourButton, 80D);
        AnchorPane.setBottomAnchor(fourButton, 200D);
//        fourButton.setMaxHeight(10D);

        Button b = new Button("add ");
        anchorPane.getChildren().add(b);
        AnchorPane.setLeftAnchor(b, 0D);
        AnchorPane.setRightAnchor(b, 500-20D);
        AnchorPane.setTopAnchor(b, 180D);
        AnchorPane.setBottomAnchor(b, 0D);
        b.setOnAction(new EventHandler<ActionEvent>() {

         @Override
         public void handle(ActionEvent event) {
            Button b2 = new Button("add ");
            i++;
            anchorPane.getChildren().add(b2);
            AnchorPane.setLeftAnchor(b2, i*10D);
            AnchorPane.setRightAnchor(b2, 400D-20*i);
            AnchorPane.setTopAnchor(b2, i*10D);
            AnchorPane.setBottomAnchor(b2, 200-20D*i);

         }
      });
        stage.show();


	}

	static int i;
    public static void main(String[] args) {
        launch(args);
    }

}
