package fxtest.preloader;

import javafx.application.Preloader;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ISwapPreloader extends Preloader {

	@Override
	public void start(Stage stage) throws Exception {
		stage.setWidth(600.0);
		stage.setHeight(400.0);
		stage.setResizable(false);
		StackPane rootPane = new StackPane();
		stage.setScene(new Scene(rootPane));
		ProgressBar pb = new ProgressBar();
		AnchorPane ap = new AnchorPane();
		Slider s = new Slider();
		Text t = new Text("i");
		t.setFill(Color.RED);
		AnchorPane.setTopAnchor(pb, 0.0);
		AnchorPane.setLeftAnchor(pb, 0.0);
		AnchorPane.setRightAnchor(pb, 0.0);
		AnchorPane.setTopAnchor(t, 10.0);
		AnchorPane.setRightAnchor(t, 10.0);
		AnchorPane.setBottomAnchor(s, 0.0);
		AnchorPane.setLeftAnchor(s, 0.0);
		AnchorPane.setRightAnchor(s, 0.0);
		ap.getChildren().addAll(s, pb);
		rootPane.getChildren().add(ap);
		s.setMin(0.0);
		s.setMax(1.0);
		pb.progressProperty().bind(s.valueProperty());
		stage.show();

	}

	public static void main(String args[]) {
		launch(args);
	}


}
