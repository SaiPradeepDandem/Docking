package fxtest;

import xstr.util.Fx;

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;


/**
 * When the selected row is removed the selection is rendered on another row but there is no notification
 */
public class TableViewSelectionTest extends Application {
   static class Order {
      public final String name;
      public DoubleProperty price = new SimpleDoubleProperty();
      public DoubleProperty qty = new SimpleDoubleProperty();

      public Order(String n, double p) {
         name = n;
         price.set(p);
         qty.set(1);
      }

      @Override
      public String toString() {
         return name + ": " + qty.get() + " @ " + price.get();
      }
   }

   private static int nextOrderId = 100;

   private static Order nextOrder() {
      return new Order("Order" + nextOrderId++, nextOrderId / 10.0);
   }

   final Order items[] = {
         new Order("Item 0", 4.0), new Order("Item 1", 5.0), new Order("Item 2", 6.0), new Order("Item 3", 7.0), new Order("Item 4", 8.0),
         new Order("Item 5", 9.0), new Order("Item 6", 10.0), new Order("Item 7", 11.0)
   };

   @Override
   public void start(Stage primaryStage) throws Exception {
      TableView<Order> tableView = new TableView<Order>();
      TextArea tableArea = new TextArea();

      Button updateButton = new Button("Replace Row");
      updateButton.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            tableView.getItems().set(tableView.getSelectionModel().getSelectedIndex(), nextOrder());
         }
      });

      Button deleteButton = new Button("Remove Row");
      deleteButton.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            tableView.getItems().remove(tableView.getSelectionModel().getSelectedIndex());
         }
      });
      deleteButton.setOnDragDetected(new EventHandler<MouseEvent>() {


         @Override
         public void handle(MouseEvent ev) {
            System.out.println("Drag started");
            Dragboard db = deleteButton.startDragAndDrop(TransferMode.ANY);
            ClipboardContent content = new ClipboardContent();
            content.putString("zzz");
            db.setContent(content);
            ev.consume();
         }
      });

      deleteButton.setOnDragDone(new EventHandler<DragEvent>() {

         @Override
         public void handle(DragEvent arg0) {
            System.out.println("Drag Done");
         }
      });

      TableColumn<Order, String> nameCol = new TableColumn<Order, String>("Item");
      TableColumn<Order, Number> priceCol = new TableColumn<Order, Number>("Price");
      TableColumn<Order, Number> qtyCol = new TableColumn<Order, Number>("Quantity");

      nameCol.setCellValueFactory(new Callback<CellDataFeatures<Order, String>, ObservableValue<String>>() {
         @Override
         public ObservableValue<String> call(CellDataFeatures<Order, String> cellData) {
            return new ReadOnlyStringWrapper(cellData.getValue().name);
         }
      });

      priceCol.setCellValueFactory(new Callback<CellDataFeatures<Order, Number>, ObservableValue<Number>>() {
         @Override
         public ObservableValue<Number> call(CellDataFeatures<Order, Number> cellData) {
            return cellData.getValue().price;
         }
      });

      qtyCol.setCellValueFactory(new Callback<CellDataFeatures<Order, Number>, ObservableValue<Number>>() {
         @Override
         public ObservableValue<Number> call(CellDataFeatures<Order, Number> cellData) {
            return cellData.getValue().qty;
         }
      });

      tableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Order>() {
         @Override
         public void changed(ObservableValue<? extends Order> _0, Order _1, Order newOrder) {
            tableArea.setText(String.format("Selected Item changed %s -> %s", _1, newOrder));
            System.out.println(String.format("Selected Item changed %s -> %s", _1, newOrder));
         }
      });

      tableView.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
         @Override
         public void changed(ObservableValue<? extends Number> _0, Number _1, Number newIdx) {
            System.out.println(String.format("Selected index changed %d -> %d", _1, newIdx));
         }
      });

//      tableView.getSelectionModel().getSelectedIndices().addListener(new InvalidationListener() {
//         @Override
//         public void invalidated(Observable arg0) {
//            System.out.println("Selected indices changed " + tableView.getSelectionModel().getSelectedIndices());
//         }
//      });


      tableView.setSelectionModel(null);
      tableView.getSelectionModel().getSelectedIndices().addListener(new ListChangeListener<Number>(){

         @Override
         public void onChanged(Change<? extends Number> change) {
//            System.out.println("Selected items changed... ");
            while (change.next()) {
//               System.out.println(String.format("Selected items change from %d to %d", change.getFrom(), change.getTo()));
               if (!change.wasAdded() && !change.wasRemoved())
                  System.out.println(String.format("Selected[%d] items unchanged: %s", tableView.getSelectionModel().getSelectedIndex(), change.getList()));
               if (change.wasAdded())
                  System.out.println(String.format("Selected[%d] items added: %s", tableView.getSelectionModel().getSelectedIndex(), change.getAddedSubList()));
               if (change.wasRemoved()) {
                  System.out.println(String.format("Selected[%d] items removed: %s", tableView.getSelectionModel().getSelectedIndex(), change.getRemoved()));
                  Fx.runLater(new Runnable() {

                     @Override
                     public void run() {
                        System.out.println(String.format("Selected[%d] after removal.", tableView.getSelectionModel().getSelectedIndex()));
                     }
                  });
               }
               if (change.wasPermutated())
                  System.out.println("Selected items was Permutated");
               if (change.wasReplaced())
                  System.out.println("Selected items was Replaced");
               if (change.wasUpdated())
                  System.out.println("Selected items was Updated");
            }
//            System.out.println("End Selected items changed.");
         }

      });
      tableView.getColumns().addAll(nameCol, priceCol, qtyCol);
      tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
      tableView.getItems().addAll(items);

      HBox hb = new HBox();
      hb.getChildren().addAll(updateButton, deleteButton);

      VBox vb = new VBox();
      vb.getChildren().addAll(tableView, tableArea, hb);

      primaryStage.setScene(new Scene(vb));
      primaryStage.setHeight(500.0);
      primaryStage.show();
      primaryStage.getScene().setOnKeyPressed(ev -> {
         if (ev.isControlDown()) {
            System.out.println("Key pressed: " + ev.getCharacter());
            tableView.getItems().set(tableView.getSelectionModel().getSelectedIndex(), nextOrder());
         }
      });
   }

   public static void main(String args[]) {
      launch(args);
   }
}
