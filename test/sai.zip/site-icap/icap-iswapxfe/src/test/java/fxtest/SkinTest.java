package fxtest;

import xfe.util.scene.control.RightAlignedCheckBox;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class SkinTest extends Application{

	@Override
	public void start(Stage primaryStage) throws Exception {
		HBox hbox = new HBox();
		RightAlignedCheckBox chx = new RightAlignedCheckBox("Text");
		chx.getStyleClass().add("xfe-checkbox-right");
		CheckBox checkbox = new CheckBox("normal");
		hbox.getChildren().addAll(chx,checkbox);
		Scene scene = new Scene(hbox);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args){
		SkinTest test = new SkinTest();
		launch(args);

	}
}
