package fxtest;

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * When the selected row is removed the selection is rendered on another
 * row but there is no notification
 */
public class DynamicHeightTableTest extends Application {

	static class Order {
		String name;
		DoubleProperty price = new SimpleDoubleProperty();
		DoubleProperty qty = new SimpleDoubleProperty();

		Order(String n, double p) {
			name = n;
			price.set(p);
			qty.set(1);
		}
		@Override
		public String toString() {
			return name + ": " + qty.get() + " @ " + price.get();
		}
	}

	private static int nextOrderId = 100;
	private static Order nextOrder() {
		return new Order("Order" + nextOrderId++, nextOrderId / 10.0);
	}

	final Order items[] = { new Order("Item 0", 4.0), new Order("Item 1", 5.0),
			new Order("Item 2", 6.0), new Order("Item 3", 7.0),
			new Order("Item 4", 8.0), new Order("Item 5", 9.0),
			new Order("Item 6", 10.0), new Order("Item 7", 11.0) };

	@Override
	public void start(Stage primaryStage) throws Exception {
		TableView<Order> tv = new TableView<Order>();
		TextArea ta = new TextArea();

		Button updateButton = new Button("Replace Row");
		updateButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				tv.getItems().set(tv.getSelectionModel().getSelectedIndex(), nextOrder());
			}
		});

		Button deleteButton = new Button("Remove Row");
		deleteButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				tv.getItems().remove(tv.getSelectionModel().getSelectedIndex());
			}
		});

		TableColumn<Order, String> nameCol = new TableColumn<Order, String>(
				"Item");
		TableColumn<Order, Number> priceCol = new TableColumn<Order, Number>(
				"Price");
		TableColumn<Order, Number> qtyCol = new TableColumn<Order, Number>(
				"Quantity");

		nameCol.setCellValueFactory(new Callback<CellDataFeatures<Order, String>, ObservableValue<String>>() {
			@Override
			public ObservableValue<String> call(
					CellDataFeatures<Order, String> d) {
				return new ReadOnlyStringWrapper(d.getValue().name);
			}
		});

		priceCol.setCellValueFactory(new Callback<CellDataFeatures<Order, Number>, ObservableValue<Number>>() {
			@Override
			public ObservableValue<Number> call(
					CellDataFeatures<Order, Number> cellData) {
				return cellData.getValue().price;
			}
      });

		qtyCol.setCellValueFactory(new Callback<CellDataFeatures<Order, Number>, ObservableValue<Number>>() {
			@Override
			public ObservableValue<Number> call(
					CellDataFeatures<Order, Number> cellData) {
				return cellData.getValue().qty;
			}
      });

		tv.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Order>() {

			@Override
			public void changed(ObservableValue<? extends Order> arg0,
					Order arg1, Order newOrder) {
				ta.setText(String.format("Selected Order %s", newOrder));
			}
		});

		tv.getColumns().addAll(nameCol, priceCol, qtyCol);
		tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		tv.getItems().addAll(items);

      HBox hb = new HBox();
      hb.getChildren().addAll(updateButton, deleteButton);

      VBox vb = new VBox();
      vb.getChildren().addAll(tv, ta, hb);

		VBox.setVgrow(ta, Priority.ALWAYS);
		VBox.setVgrow(tv, Priority.NEVER);
		primaryStage.setScene(new Scene(vb));
		primaryStage.setHeight(500.0);
		primaryStage.show();
	}

	public static void main(String args[]) {
		launch(args);
	}
}
