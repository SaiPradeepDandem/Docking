package fxtest;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class CssLoadTest extends Application {

   @Override
   public void start(Stage stage) throws Exception {
      VBox vb = new VBox();
      HBox hb = new HBox();
      hb.setAlignment(Pos.BASELINE_CENTER);
      Scene scene = new Scene(vb);
      TextField stylesheet = new TextField();
      stylesheet.setText("");
      Button browseButton = new Button("Browse...");
      browseButton.setOnAction(new EventHandler<ActionEvent>() {

         @Override
         public void handle(ActionEvent arg0) {
            FileChooser fc = new FileChooser();
            if (!stylesheet.getText().isEmpty()) {
               File pf = new File(URI.create(stylesheet.getText())).getParentFile();
               fc.setInitialDirectory(pf);
            }
            File f = fc.showOpenDialog(stage);
            if (f != null)
               try {
                  stylesheet.setText(f.toURI().toURL().toExternalForm());
               } catch (MalformedURLException e) {
               }
         }
      });

      hb.getChildren().addAll(

      stylesheet, browseButton);

      Button loadButton = new Button("Load");
      loadButton.setOnAction(new EventHandler<ActionEvent>() {

         @Override
         public void handle(ActionEvent arg0) {
            scene.getStylesheets().setAll(stylesheet.getText());
//            StyleManager.getInstance().updateStylesheets(stage.getScene());
            stage.sizeToScene();
         }
      });
      Button clearButton = new Button("Clear");
      clearButton.setOnAction(new EventHandler<ActionEvent>() {

         @Override
         public void handle(ActionEvent arg0) {
            scene.getStylesheets().clear();
//            StyleManager.getInstance().updateStylesheets(stage.getScene());
            stage.sizeToScene();
         }
      });
      HBox hb2 = new HBox();
      hb2.setAlignment(Pos.BASELINE_RIGHT);
      hb2.getChildren().setAll(clearButton, loadButton);
      vb.getChildren().addAll(new Label("Stylesheet URL: "), hb, hb2);
      stage.setScene(scene);
      stage.show();
   }

   public static void main(String args[]) {
      launch(args);
   }

}
