package fxtest;

import java.util.Arrays;

import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.effect.MotionBlur;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.Duration;

import xfe.util.DIR;
import xfe.layout.AbstractLayout;
import xfe.ui.table.Tables;

public class SharedScrollbarTest2 extends Application {
	static class Row {
		public String text;
		public int value;

		public Row(String text, int value) {
			this.text = text;
			this.value = value;
		}

		public String toString() {
			return text + ":" + value;
		}
	}

	final Row rows1[] = {
			new Row("Item 1", 1),
			new Row("Item 2", 2),
			new Row("Item 3", 3),
			new Row("Item 4", 4),
			new Row("Item 5", 5),
			new Row("Item 6", 6),
			new Row("Item 7", 7),
			new Row("Item 8", 8),
			new Row("Item 8", 9),
			new Row("Item 10", 10),
			new Row("Item 11", 11),
			new Row("Item 12", 12),
			new Row("Item 13", 13),
			new Row("Item 14", 14),
			new Row("Item 15", 15),
			new Row("Item 16", 16),
			new Row("Item 17", 17)
	};

	final Row rows2[] = {
			new Row("Item 1", 1),
			new Row("Item 2", 2),
			new Row("Item 3", 3),
			new Row("Item 4", 4),
			new Row("Item 5", 5),
			new Row("Item 6", 6),
			new Row("Item 7", 7),
			new Row("Item 8", 8),
			new Row("Item 9", 9)
	};

	Tables scrollLink;

	MotionBlur effect = new MotionBlur();
	Transition t = new Transition() {
		{
			setCycleDuration(Duration.millis(200));
			setInterpolator(Interpolator.EASE_BOTH);
		}

		@Override
		protected void interpolate(double arg0) {
			effect.setRadius((0.5 - Math.abs(arg0 - 0.5)) * 120);
		}



	};
	@Override
	public void start(Stage primaryStage) throws Exception {
		HBox hbox = new HBox();

		TableView<Row> tableView1 = new TableView<Row>() {{
			this.getColumns().add(new TableColumn<Row, String>("Item") {{
				this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
					@Override
	            public ObservableValue<String> call(
	                  CellDataFeatures<Row, String> cellDataFeatures) {
						return new SimpleObjectProperty<String>(cellDataFeatures.getValue().text);
	            }
				});
			}});
			this.getColumns().add(new TableColumn<Row, String>("Value") {{
				this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
					@Override
	            public ObservableValue<String> call(
	                  CellDataFeatures<Row, String> cellDataFeatures) {
						return new SimpleObjectProperty<String>(cellDataFeatures.getValue().value + "");
	            }
				});
			}});

			this.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
			this.getItems().addAll(rows1);
		}};

		TableView<Row> tableView2 = new TableView<Row>() {{
			this.getColumns().add(new TableColumn<Row, String>("Item") {{
				this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
					@Override
	            public ObservableValue<String> call(
	                  CellDataFeatures<Row, String> cellDataFeatures) {
						return new SimpleObjectProperty<String>(cellDataFeatures.getValue().text);
	            }

				});
				this.setMinWidth(40);
				this.setResizable(false);
			}});
			this.getColumns().add(new TableColumn<Row, String>("Value") {{
				this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
					@Override
	            public ObservableValue<String> call(
	                  CellDataFeatures<Row, String> cellDataFeatures) {
						return new SimpleObjectProperty<String>(cellDataFeatures.getValue().value + "");
	            }
				});
				this.setMinWidth(40);
				this.setResizable(false);
			}});

			this.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
			this.getItems().addAll(rows2);
		}};

		hbox.getChildren().addAll(Tables.getReplacementScrollBar(tableView1), tableView1, tableView2, Tables.getReplacementScrollBar(tableView2));



		primaryStage.setScene(new Scene(hbox));
		primaryStage.getScene().getStylesheets().addAll(
				Arrays.asList(
						DIR.url(AbstractLayout.class, "base.css"),
                  "/css/iswap.css"));
		primaryStage.setHeight(200.0);
		primaryStage.show();
//		SceneToolPlugin.load(primaryStage);
		tableView2.setEffect(effect);
		t.play();
		t.onFinishedProperty().set(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				t.play();

			}
		});
	}

	public static void main(String args[]) {
		launch(args);
	}
}
