package fxtest;

import static javafx.beans.binding.Bindings.equal;
import static javafx.beans.binding.Bindings.not;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.BooleanExpression;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.binding.IntegerExpression;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ExpressionTest {
	public static <T> IntegerExpression sizeOf(ObservableList<T> observableList) {
		if (observableList == null) {
			throw new NullPointerException("Operand cannot be null.");
		}

		return new IntegerBinding() {
			{
				super.bind(observableList);
			}

			protected int computeValue() {
				return observableList.size();
			}
		};
	}

	public static void main(String[] args) {
		ObservableList<Integer> list = FXCollections.observableArrayList();
		IntegerExpression sizeProperty = sizeOf(list);
		BooleanExpression emptyProperty = not(equal(0, sizeProperty));

		sizeProperty.addListener(new InvalidationListener() {
			public void invalidated(Observable observable) {
				System.out.println("size = " + sizeProperty.get());
			}
		});

		emptyProperty.addListener(new InvalidationListener() {
			public void invalidated(Observable observable) {
				System.out.println("empty = " + emptyProperty.get());
			}
		});

		list.add(1);
		list.addAll(2, 3, 4);
		list.remove(0);
		list.remove(0);
		list.remove(0);
		list.remove(0);
		list.add(2);
		list.remove(0);
	}
}
