package fxtest;

import java.util.List;

import javafx.application.*;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.SplitPane.Divider;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.*;

import xfe.util.scene.control.DecoratedTitledPane;

public class TabPaneSkinTest extends Application{
   int index;



   @Override
   public void start(Stage primaryStage) throws Exception {
      Scene scene = buildScene();
      primaryStage.setScene(scene);
      primaryStage.setWidth(400);
      primaryStage.setHeight(200);
      primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {

         @Override
         public void handle(WindowEvent event) {
            Platform.exit();
            System.exit(0);
         }
      });
      primaryStage.show();
   }

   private Scene buildScene() {
      SplitPane splitPane = new SplitPane();
      ScrollPane sp = new ScrollPane();
      TabPane tabPane = new TabPane();
      tabPane.getTabs().addAll(new Tab("TabA-1"),new Tab("TabB-2"),new Tab("TabC-3"),new Tab("TabD-4"),new Tab("TabE-5"),new Tab("TabF-6"),new Tab("TabG-7"),new Tab("TabH-8"),new Tab("TabI-9"));
      VBox.setVgrow(tabPane,Priority.ALWAYS);

      HBox hbox = new HBox();
      hbox.getChildren().add(new CheckBox("Add"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
                  tabPane.getTabs().add(new Tab("NEW -"+index));
                  index++;
               }
            });
         }
      });

      hbox.getChildren().add(new CheckBox("remove"){
         {
//            this.getStyleClass().add(XfeCheckBoxSkin.STYLE_TEXT_LEFT);
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
                  tabPane.getTabs().remove(tabPane.getSelectionModel().getSelectedIndex());
               }
            });

         }
      });
      hbox.getChildren().add(new Button("setLeftVisible"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
//                  ScrollableTabPaneSkin skin = (ScrollableTabPaneSkin) tabPane.getSkin();
//                  skin.scrollTo(tabPane.getTabs().get(0));
               }
            });
         }
      });
      hbox.getChildren().add(new Button("setRightVisible"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
//                  ScrollableTabPaneSkin skin = (ScrollableTabPaneSkin) tabPane.getSkin();
//                  skin.scrollTo(tabPane.getTabs().get(tabPane.getTabs().size() -1 ));
               }
            });
         }
      });

      hbox.getChildren().add(new Button("setSelectedTabVisible"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
//                  ScrollableTabPaneSkin skin = (ScrollableTabPaneSkin) tabPane.getSkin();
//                  skin.scrollTo(tabPane.getSelectionModel().getSelectedItem());
               }
            });
         }
      });

      hbox.getChildren().add(new Button("1/2"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
//                  ScrollableTabPaneSkin skin = (ScrollableTabPaneSkin) tabPane.getSkin();
//                  skin.scrollTo(1D/2);
               }
            });
         }
      });
      hbox.getChildren().add(new Button("1"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
//                  ScrollableTabPaneSkin skin = (ScrollableTabPaneSkin) tabPane.getSkin();
//                  skin.scrollTo(1);
               }
            });
         }
      });
      hbox.getChildren().add(new Button("1/4"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
//                  ScrollableTabPaneSkin skin = (ScrollableTabPaneSkin) tabPane.getSkin();
//                  skin.scrollTo(1D/4);
               }
            });
         }
      });

      hbox.getChildren().add(new Button("1/3"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
//                  ScrollableTabPaneSkin skin = (ScrollableTabPaneSkin) tabPane.getSkin();
//                  skin.scrollTo(1D/3);
               }
            });
         }
      });

      HBox hbox2 = new HBox();
      hbox2.getChildren().add(new Button("setDividerLocation"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
                  List<Divider> dividers = splitPane.getDividers();
                  double p = 0.1;
                  int i=0;
                  for(Divider d:dividers){
                     d.setPosition(0.1+i*p);
                     i++;
                  }
               }
            });
         }
      });

      hbox2.getChildren().add(new Button("testD"){
         {
            this.setOnMouseClicked(new EventHandler<MouseEvent>() {

               @Override
               public void handle(MouseEvent event) {
                  List<Divider> dividers = splitPane.getDividers();
                  double p = 0.0;
                  dividers.get(dividers.size()-1).setPosition(0.5);
                  dividers.get(dividers.size()-2).setPosition(0.9);
               }
            });
         }
      });


      hbox2.getChildren().add(new Pane(){{
         this.getChildren().add(new CheckBox("right"));
      }});
      hbox2.getChildren().add(new Pane(){{
         this.getChildren().add(new CheckBox("left"));
      }});

      GridPane outerGridPane = new GridPane();
      outerGridPane.getColumnConstraints().addAll(
              new ColumnConstraints() {{ this.setPercentWidth(45.0); }},
              new ColumnConstraints() {{ this.setPercentWidth(55.0); }}
      );

      outerGridPane.getRowConstraints().addAll(
              new RowConstraints(){{this.setMinHeight(20);}},
              new RowConstraints(){{this.setPercentHeight(60);}},
              new RowConstraints(){{this.setMinHeight(20);}},
              new RowConstraints(){{this.setPercentHeight(30);}}
      );

      GridPane gridPane = new GridPane();
      gridPane.setPrefWidth(200);
      gridPane.setStyle("-fx-padding: 15px 15px 15px 15px");
      gridPane.getColumnConstraints().addAll(new ColumnConstraints() {{
         this.setHgrow(Priority.ALWAYS);
      }}, new ColumnConstraints(100));
      ToggleButton tg = new ToggleButton("toggle1");
      ToggleButton tg2 = new ToggleButton("toggle12");
      ToggleGroup toggleGroup = new ToggleGroup();
      tg.setToggleGroup(toggleGroup);
      tg2.setToggleGroup(toggleGroup);
      tg.setUserData("tg");
      tg2.setUserData("tg2");
      tg.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent event) {
            System.out.println("action!");
         }
      });
      toggleGroup.selectedToggleProperty().addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            System.out.println(toggleGroup.getSelectedToggle().getUserData());
         }
      });
      gridPane.add(tg, 0, 0);
      gridPane.add(tg2,0,1);
      gridPane.add(new Button("3"){{this.setMaxWidth(1000);this.setMinHeight(50);}},0,2);
      gridPane.add(new Button("4"){{this.setMaxWidth(1000);this.setMinHeight(50);}},0,3);
      gridPane.add(new Button("5"){{this.setMaxWidth(1000);this.setMinHeight(50);}},0,4);
      gridPane.add(new Button("6"){{this.setMaxWidth(1000);this.setMinHeight(50);}},0,5);
      gridPane.add(new Button("7"){{this.setMaxWidth(1000);this.setMinHeight(50);}},0,6);
      gridPane.add(new Button("8"){{this.setMaxWidth(1000);this.setMinHeight(50);}},0,7);
      gridPane.add(new Button("9"){{this.setMaxWidth(1000);this.setMinHeight(50);}},0,8);
      gridPane.add(new Button("10"){{this.setMaxWidth(1000);this.setMinHeight(50);}}, 0, 9);

      gridPane.add(new Button("1"){{this.setMaxWidth(1000);this.setMinHeight(50);}}, 1, 0);
      gridPane.add(new Button("2"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,1);
      gridPane.add(new Button("3"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,2);
      gridPane.add(new Button("4"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,3);
      gridPane.add(new Button("5"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,4);
      gridPane.add(new Button("6"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,5);
      gridPane.add(new Button("7"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,6);
      gridPane.add(new Button("8"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,7);
      gridPane.add(new Button("9"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,8);
      gridPane.add(new Button("10"){{this.setMaxWidth(1000);this.setMinHeight(50);}},1,9);

      outerGridPane.add(sp,1,1);
      sp.setContent(gridPane);
      DecoratedTitledPane titledPane = new DecoratedTitledPane("History", new TableView());
      splitPane.getItems().addAll(tabPane,hbox,outerGridPane,titledPane,hbox2);
      splitPane.setOrientation(Orientation.VERTICAL);
      splitPane.setDividerPositions(0.3,0.3);
      Scene scene = new Scene(splitPane);
      scene.getStylesheets().add("/iswap-test.css");
      scene.getStylesheets().add("/iswap_classic-test.css");
      List<Divider> dividers = splitPane.getDividers();
      Divider divider = dividers.get(1);
         divider.positionProperty().addListener(new ChangeListener<Number>(){

            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
               double oldPositon = newValue.doubleValue();
               double newPosition = newValue.doubleValue();
               if(newPosition>1 || newPosition<0 || oldPositon>1 || oldPositon<0) return;
               double offset = newPosition - oldValue.doubleValue();
               for(Divider splitDivider:dividers){
                  if(splitDivider!=divider){
                     splitDivider.setPosition(splitDivider.getPosition() + offset);
               }
            }
            }
         });
      return scene;
   }

   public static void main(String[] args){
      Application.launch(args);

   }

}
