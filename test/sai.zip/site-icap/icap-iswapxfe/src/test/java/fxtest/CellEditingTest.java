package fxtest;

import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

public class CellEditingTest extends Application {

   static class RowDataItem {
      String nonEdVal;
      String edValue1 = "";
      String edValue2 = "";

      RowDataItem(String nonEdValue) {
         this.nonEdVal = nonEdValue;
      }
   }

   class EditingCell extends TableCell<RowDataItem, String> {
      private TextField textField;

      EditingCell(boolean isEditable) {
         setEditable(isEditable);
      }

      @Override
      public void startEdit() {
         if (!isEditable() || !getTableView().isEditable() ||
            !getTableColumn().isEditable()) {
            return;
         }
         super.startEdit();

         if (textField == null) {
            createTextField();
         }

         setGraphic(textField);
         setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
         textField.selectAll();
      }

      @Override
      public void cancelEdit() {
         super.cancelEdit();

         setText(String.valueOf(getItem()));
         setContentDisplay(ContentDisplay.TEXT_ONLY);
      }

      private void createTextField() {
         textField = new TextField(getItem() == null ? "" : getItem());
         textField.setMinWidth(this.getWidth() - this.getGraphicTextGap() * 2);
         textField.setOnKeyPressed(t -> {
            if (t.getCode() == KeyCode.ENTER) {
               commitEdit(textField.getText());
            } else if (t.getCode() == KeyCode.ESCAPE) {
               cancelEdit();
            }
         });
      }
   }

   @Override
   public void start(Stage primaryStage) throws Exception {
      TableView<CellEditingTest.RowDataItem> tv = new TableView<>();
      tv.setEditable(true);
      tv.getSelectionModel().cellSelectionEnabledProperty().set(true);

      ObservableList<RowDataItem> items =
         FXCollections.observableArrayList(
            new RowDataItem("non-edit1"),
            new RowDataItem("non-edit2")
         );


            // Non editable column
      TableColumn<RowDataItem, String> nonEdVal = new TableColumn<>("NonEdVal");
      nonEdVal.setCellValueFactory(d -> new SimpleObjectProperty<>(d.getValue().nonEdVal));

      // editable columns
      TableColumn edVal1 = new TableColumn<>("EdVal1");
      TableColumn edVal2 = new TableColumn<>("EdVal2");
      TableColumn edVal3ne = new TableColumn<>("EdVal3ne");

      Callback<TableColumn, TableCell> editableCellFactory =
         p -> new EditingCell(true);

      Callback<TableColumn, TableCell> editableCellFactoryNE =
         p -> new EditingCell(false);

      // Setting cell factories for editable cells
      edVal1.setCellFactory(editableCellFactory);
      edVal2.setCellFactory(editableCellFactory);
      edVal3ne.setCellFactory(editableCellFactoryNE);

      tv.setItems(items);
      tv.getColumns().addAll(nonEdVal, edVal1, edVal2, edVal3ne);

      VBox vb = new VBox();
      vb.setSpacing(10);
      vb.getChildren().add(tv);

      primaryStage.setScene(new Scene(vb));
      primaryStage.setHeight(200.0);
      primaryStage.show();
   }

   public static void main(String args[]) {
      launch(args);
   }
}
