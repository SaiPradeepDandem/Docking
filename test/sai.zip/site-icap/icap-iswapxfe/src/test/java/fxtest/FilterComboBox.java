package fxtest;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilterComboBox extends Application {

   @Override
   public void start(Stage primaryStage) {

      List<String> items = Arrays.asList("Alabama",
         "Alaska", "Arizona", "Arkansas", "California", "Colorado",
         "Connecticut", "Delaware", "Georgia", "Florida", "Hawaii", "Idaho",
         "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana",
         "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota",
         "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada",
         "New Hampshire", "New Jersey", "New Mexico", "New York",
         "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
         "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
         "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
         "West Virginia", "Wisconsin", "Wyoming");
      BorderPane root = new BorderPane();
      ComboBox<String> comboBox = new ComboBox<>(
              FXCollections.observableArrayList(items));
      comboBox.setEditable(true);
      comboBox.setVisibleRowCount(10);
      comboBox.getEditor().textProperty().addListener(new ChangeListener<String>() {
                 @Override
                 public void changed(ObservableValue<? extends String> observable,
                                     String oldValue, String newValue) {
                    TextField editor = comboBox.getEditor();
                    String selected = comboBox.getSelectionModel().getSelectedItem();
                    filterItems(newValue, comboBox, items);
//                       comboBox.show();
//                       if (comboBox.getItems().size() == 1) {
//                          final String onlyOption = comboBox.getItems().get(0);
//                          final String current = editor.getText();
//                          if (onlyOption.length() > current.length()) {
//                             editor.setText(onlyOption);
//                             // Not quite sure why this only works using
//                             // Platform.runLater(...)
//                             Platform.runLater(new Runnable() {
//                                @Override
//                                public void run() {
//                                   editor.selectRange(current.length(), onlyOption.length());
//                                }
//                             });
//                          }
//                       }
                 }
              });
//    comboBox.setOnAction(new EventHandler<ActionEvent>() {
//      @Override
//      public void handle(ActionEvent event) {
//        // Reset so all options are available:
//        Platform.runLater(new Runnable() {
//          @Override
//          public void run() {
//            String selected = comboBox.getSelectionModel().getSelectedItem();
//            if (comboBox.getItems().size() < items.size()) {
//              comboBox.setItems(FXCollections.observableArrayList(items));
//              String newSelected = comboBox.getSelectionModel()
//                  .getSelectedItem();
//              if (newSelected == null || !newSelected.equals(selected)) {
//                comboBox.getSelectionModel().select(selected);
//              }
//            }
//          }
//        });
//      }
//    });

      root.setTop(comboBox);
      Label label = new Label();
      label.textProperty().bind(
              comboBox.getSelectionModel().selectedItemProperty());
      root.setBottom(label);
      Scene scene = new Scene(root, 200, 400);
      primaryStage.setScene(scene);
      primaryStage.show();
   }

   private <T> void filterItems(String filter, ComboBox<T> comboBox,
                                List<T> items) {
      List<T> filteredItems = new ArrayList<>();
      for (T item : items) {
         if (item.toString().toLowerCase().startsWith(filter.toLowerCase())) {
            filteredItems.add(item);
         }
      }
      comboBox.getItems().setAll(filteredItems);
   }

   public static void main(String[] args) {
      launch(args);
   }
}
