package fxtest;

import javafx.application.*;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Callback;

public class LineListTest extends Application{

   static int index;
   @Override
   public void start(Stage primaryStage) throws Exception {
      primaryStage.setScene(createScene());
      primaryStage.setHeight(500);
      primaryStage.setWidth(500);
      primaryStage.show();
   }

   private Scene createScene() {
      VBox root = new VBox();
      Scene scene = new Scene(root);
      HeaderLessTableView<Trader> tableView = new HeaderLessTableView<Trader>(false);
      root.getChildren().add(tableView);
      tableView.getColumns().add(createNameColumn());
      tableView.getColumns().add(createFirmColumn());
      tableView.getColumns().add(createAutoColumn());
      tableView.getColumns().add(createHKColumn());
      tableView.getColumns().add(createIBColumn());

      root.getChildren().add(createALineList("first", createData()));
      root.getChildren().add(createALineList("second", createData()));
      root.getChildren().add(createALineList("third", createData()));

      return scene;
   }

   private Node createALineList(String title, ObservableList<Trader> traders){
      VBox vbox = new VBox();
      VBox.setVgrow(vbox, Priority.NEVER);
      Label label = new Label(title);
      label.setStyle("-fx-border-width:1;");
      label.setStyle("-fx-border-color:red;");
      HeaderLessTableView<Trader> tableView = new HeaderLessTableView<Trader>(true);
      tableView.setId("tableview-"+title);
      vbox.setId("vbox-"+title);
      label.setOnMouseClicked(new EventHandler<MouseEvent>() {

         @Override
         public void handle(MouseEvent arg0) {
            if(vbox.getChildren().size()==2)
               vbox.getChildren().remove(tableView);
            else
               vbox.getChildren().add(tableView);
         }

      });
      VBox.setVgrow(label, Priority.NEVER);
      VBox.setVgrow(tableView, Priority.NEVER);
      vbox.getChildren().addAll(label,tableView);
      tableView.getColumns().add(createNameColumn());
      tableView.getColumns().add(createFirmColumn());
      tableView.getColumns().add(createAutoColumn());
      tableView.getColumns().add(createHKColumn());
      tableView.getColumns().add(createIBColumn());
      tableView.setItems(createData());
      return vbox;
   }

   private TableColumn<Trader, String> createNameColumn() {
      TableColumn<Trader, String> tc = new TableColumn<Trader, String>();
      tc.setCellValueFactory(new Callback<CellDataFeatures<Trader,String>, ObservableValue<String>>() {

         @Override
         public ObservableValue<String> call(CellDataFeatures<Trader, String> arg0) {
            return new SimpleStringProperty(arg0.getValue().name);
         }
      });
      tc.setText("Name");
      tc.setPrefWidth(100);
      return tc;
   }

   private TableColumn<Trader, String> createFirmColumn() {
      TableColumn<Trader, String> tc = new TableColumn<Trader, String>();
      tc.setCellValueFactory(new Callback<CellDataFeatures<Trader,String>, ObservableValue<String>>() {

         @Override
         public ObservableValue<String> call(CellDataFeatures<Trader, String> arg0) {
            return new SimpleStringProperty(arg0.getValue().firm);
         }
      });
      tc.setText("Firm");
      tc.setPrefWidth(100);
      return tc;
   }

   private TableColumn<Trader, Boolean> createAutoColumn() {
      TableColumn<Trader, Boolean> tc = new TableColumn<Trader, Boolean>();
      tc.setCellValueFactory(new Callback<CellDataFeatures<Trader,Boolean>, ObservableValue<Boolean>>() {

         @Override
         public ObservableValue<Boolean> call(CellDataFeatures<Trader, Boolean> arg0) {
            return new SimpleBooleanProperty(arg0.getValue().isAuto);
         }
      });
      tc.setText("Auto");
      tc.setPrefWidth(50);
      return tc;
   }

   private TableColumn<Trader, String> createHKColumn() {
      TableColumn<Trader, String> tc = new TableColumn<Trader, String>();
      tc.setCellValueFactory(new Callback<CellDataFeatures<Trader,String>, ObservableValue<String>>() {

         @Override
         public ObservableValue<String> call(CellDataFeatures<Trader, String> arg0) {
            return new SimpleStringProperty(arg0.getValue().HK);
         }
      });
      tc.setText("HK");
      tc.setPrefWidth(20);
      return tc;
   }

   private TableColumn<Trader, String> createIBColumn() {
      TableColumn<Trader, String> tc = new TableColumn<Trader, String>();
      tc.setCellValueFactory(new Callback<CellDataFeatures<Trader,String>, ObservableValue<String>>() {

         @Override
         public ObservableValue<String> call(CellDataFeatures<Trader, String> arg0) {
            return new SimpleStringProperty(arg0.getValue().IB);
         }
      });
      tc.setText("IB");
      tc.setPrefWidth(100);
      return tc;
   }

   private ObservableList<Trader> createData(){
      ObservableList<Trader> rtn = FXCollections.observableArrayList();
      for(int i=0;i<3;i++){
         Trader t = new Trader();
         t.name = "name-"+index;
         t.firm = "firm-"+index;
         t.isAuto = index % 2==0;
         t.HK = ""+index;
         t.IB = "IB-"+index;
         rtn.add(t);
      }
      return rtn;
   }
   class Trader{
      String name;
      String firm;
      boolean isAuto;
      String HK;
      String IB;
   }


   class HeaderLessTableView<S> extends TableView<S>{

      private boolean isHeaderHide = true;

      public HeaderLessTableView(boolean b) {
         isHeaderHide=b;
         this.setPlaceholder(new Label());
      }

      @Override
      protected double computeMaxHeight(double hintWidth) {
         double totalHeight = getItems().size() * 24;

         System.out.println(this.getId()+" pref height is "+totalHeight);
         return totalHeight;

      }



   }



   public static void main(String[] args){
      Application.launch(args);
   }
}

