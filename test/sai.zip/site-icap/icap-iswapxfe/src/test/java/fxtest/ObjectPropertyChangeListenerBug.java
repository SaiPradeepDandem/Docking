package fxtest;

import java.util.concurrent.atomic.AtomicInteger;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ObjectPropertyChangeListenerBug {
	public static void main(String[] args) {
		ObjectProperty<ObservableList<Integer>> itemsProperty =
				new SimpleObjectProperty<ObservableList<Integer>>(
						FXCollections.observableArrayList());

		AtomicInteger invalidationCount = new AtomicInteger(0);
		AtomicInteger changeCount = new AtomicInteger(0);

		itemsProperty.addListener(new InvalidationListener() {
			@Override
			public void invalidated(Observable paramObservable) {
				invalidationCount.incrementAndGet();
			}
		});

		itemsProperty.addListener(new ChangeListener<ObservableList<Integer>>() {
			@Override
			public void changed(
					ObservableValue<? extends ObservableList<Integer>> observableValue,
					ObservableList<Integer> oldValue,
					ObservableList<Integer> newValue) {
				changeCount.incrementAndGet();
			}
		});

		itemsProperty.set(FXCollections.observableArrayList());

		assert(invalidationCount.get() == 1);
		assert(changeCount.get() == 1);
	}
}
