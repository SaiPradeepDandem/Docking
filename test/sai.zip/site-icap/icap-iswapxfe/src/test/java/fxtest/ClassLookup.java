package fxtest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ClassLookup extends Application {
   public static void lookup(String className) throws SecurityException, IOException, InterruptedException {
      Process process = Runtime.getRuntime().exec(new String[] {"javap.exe", "-classpath", System.getProperty("java.class.path"), "-l", className});
      AtomicBoolean done = new AtomicBoolean(false);

      process.getOutputStream().close();

      Thread thread1 = new Thread() {
         @Override
         public void run() {
            try {
               InputStream es = process.getErrorStream();

               while (!done.get()) {
                  int cerr = es.read();

                  if (cerr != -1) {
                     System.err.write(cerr);
                  }

                  if (cerr == -1) {
                     Thread.sleep(1);
                  }
               }
            } catch (IOException e) {
            } catch (InterruptedException e) {
            }
         }
      };

      Thread thread2 = new Thread() {
         @Override
         public void run() {
            try {
               InputStream is = process.getInputStream();
               ByteArrayOutputStream os = new ByteArrayOutputStream();

               while (!done.get()) {
                  int cout = is.read();

                  if (cout != -1) {
                     os.write(cout);
                  }

                  if (cout == -1) {
                     Thread.sleep(1);
                  }
               }

               String[] lines = os.toString().split("\n");
               Pattern pattern = Pattern.compile("      line (\\d+)");
               Pattern sourcePattern = Pattern.compile("Compiled from \"([^\"]+)\"");
               String firstLine = lines.length > 0 ? lines[0] : "";
               Matcher sourceMatcher = sourcePattern.matcher(firstLine);
               int lineNumber = Integer.MAX_VALUE;

               String sourceName = sourceMatcher.find() ? sourceMatcher.group(1) : "?";

               for (String line: lines) {
                  Matcher matcher = pattern.matcher(line);
                  if (matcher.find()) {
                     String lineString = matcher.group(1);
                     int parsedLineNumber = Integer.parseInt(lineString);

                     if (parsedLineNumber > 1) {
                        lineNumber = Math.min(lineNumber, parsedLineNumber);
                     }
                  }
               }

               System.out.println(className.split("$")[0] + ".<init>(" + sourceName + ":" + lineNumber + ")");
            } catch (Exception e) {
            }
         }
      };

      thread1.start();
      thread2.start();

      process.waitFor();
      done.set(true);

      thread1.join();
      thread2.join();

      System.out.flush();
   }

   public static void main(String[] args) throws SecurityException {

      Application.launch(ClassLookup.class, args);
   }

   @Override
   public void start(Stage stage) throws Exception {
      StringProperty classNamesProperty = new SimpleStringProperty();
      Scene scene = new Scene(new VBox() {{
         this.getChildren().addAll(
               new Label("Class name:"),
               new TextArea() {{
                  VBox.setVgrow(this, Priority.ALWAYS);
                  classNamesProperty.bindBidirectional(this.textProperty());
               }},
               new Button() {{
                  this.setText("Find source");
                  this.setOnAction(new EventHandler<ActionEvent>() {
                     @Override
                     public void handle(ActionEvent actionEvent) {
                        for (String line: classNamesProperty.get().split("\n")) {
                           try {
                              ClassLookup.lookup(line);
                           } catch (Exception e) {
                              e.printStackTrace();
                           }
                        }
                     }
                  });
               }});
      }});

      stage.setTitle("Class lookup");
      stage.setScene(scene);
      stage.show();
   }
}
