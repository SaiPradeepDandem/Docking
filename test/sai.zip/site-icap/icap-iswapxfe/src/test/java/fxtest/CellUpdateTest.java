package fxtest;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;


public class CellUpdateTest extends Application {
	final SimpleStringProperty testString = new SimpleStringProperty("Initial");
	final List<SimpleStringProperty> properties = new ArrayList<SimpleStringProperty>();

	static class ValuableItem {
		String name;
		double value;

		ValuableItem(String n, double v) {
			name = n;
			value = v;
		}
	}

	final ValuableItem items[] = {
			new ValuableItem("Item 0", 4.0),
			new ValuableItem("Item 0", 5.0),
			new ValuableItem("Item 0", 6.0),
			new ValuableItem("Item 0", 7.0),
			new ValuableItem("Item 0", 8.0),
			new ValuableItem("Item 0", 9.0),
			new ValuableItem("Item 0", 10.0),
			new ValuableItem("Item 0", 11.0)
	};

	int count;

	@Override
	public void start(Stage primaryStage) throws Exception {
		Button button = new Button("Update Values");
		button.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				count += 1;
				// updateItems();
				testString.set(String.valueOf(count));
			}
		});

		TableView<ValuableItem> tv = new TableView<ValuableItem>();
		TableColumn<ValuableItem, String> nameCol = new TableColumn<ValuableItem, String>("Item");
		TableColumn<ValuableItem, ObservableValue<String>> valueCol = new TableColumn<ValuableItem, ObservableValue<String>>("Value");

		nameCol.setCellValueFactory(new Callback<CellDataFeatures<ValuableItem, String>, ObservableValue<String>>() {
			@Override
			public ObservableValue<String> call(CellDataFeatures<ValuableItem, String> d) {
				return new SimpleObjectProperty<String>(d.getValue().name);
			}
		});

		valueCol.setCellValueFactory(new Callback<CellDataFeatures<ValuableItem, ObservableValue<String>>, ObservableValue<ObservableValue<String>>>() {
			@Override
			public ObservableValue<ObservableValue<String>> call(CellDataFeatures<ValuableItem, ObservableValue<String>> cellDataFeature) {
				SimpleStringProperty property = new SimpleStringProperty(testString.get()) {
					final SimpleStringProperty self = this;
					final InvalidationListener ll = new InvalidationListener() {
						@Override
						public void invalidated(Observable cellDataFeature) {
							System.out.println("Invalidated: " + getClass().getSimpleName() + " " + hashCode());
							self.set(testString.get());
						}
					};

					{
						testString.addListener(new WeakInvalidationListener(ll));
					}
				};

				return new SimpleObjectProperty<ObservableValue<String>>(property);
			}
      });

		valueCol.setCellFactory(new Callback<TableColumn<ValuableItem, ObservableValue<String>>, TableCell<ValuableItem, ObservableValue<String>>>() {
			@Override
			public TableCell<ValuableItem, ObservableValue<String>> call(TableColumn<ValuableItem, ObservableValue<String>> column) {
				return new TableCell<ValuableItem, ObservableValue<String>>() {
					public void updateItem(ObservableValue<String> observableValue, boolean paramBoolean) {
						super.updateItem(observableValue, paramBoolean);
						if (observableValue != null) {
							observableValue.addListener(new InvalidationListener() {
								{
									this.invalidated(observableValue);
								}

								@Override
								public void invalidated(Observable observable) {
									setText(observableValue.getValue());
									setGraphic(null);
								}
							});
						}
					}
				};
			}
		});

		tv.getColumns().add(nameCol);
		tv.getColumns().add(valueCol);
		tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		//tv.getItems().addAll(items);

		tv.setPlaceholder(new StackPane());
		tv.getPlaceholder().setOpacity(0);
		VBox vb = new VBox();
		vb.getChildren().addAll(tv, button);
		primaryStage.setScene(new Scene(vb));
		primaryStage.setHeight(200.0);
		primaryStage.show();
	}

	public static void main(String args[]) {
		launch(args);
	}
}
