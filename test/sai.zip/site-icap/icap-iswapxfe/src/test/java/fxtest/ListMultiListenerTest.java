package fxtest;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ListMultiListenerTest  extends Application {



	private int changeCount1;
	private int changeCount2;
	private int changeCount3;
	Duration d;
	@Override
	public void start(Stage arg0) throws Exception {
		ObservableList<String> sl = FXCollections.observableArrayList("ABC", "DEF", "GHI", "JKL");
		sl.addListener(new ListChangeListener<String>(){
			@Override
			public void onChanged(Change<? extends String> c) {
				System.out.println("Listener 1 onChanged()");
				while (c.next())
					System.out.println("Listener 1 change count: " + ++changeCount1);
			}

		});

		sl.addListener(new InvalidationListener() {

			@Override
			public void invalidated(Observable paramObservable) {
				System.out.println("Inv Listener change count: " + ++changeCount3);
			}
		});

		sl.addListener(new ListChangeListener<String>(){
			@Override
			public void onChanged(Change<? extends String> c) {
				System.out.println("Listener 2 onChanged()");
				while (c.next())
					System.out.println("Listener 2 change count: " + ++changeCount2);
			}

		});

		sl.addAll("123", "456", "789");
		sl.removeAll("789", "DEF", "JKL", "123");
	}

	public static void main(String args[]) {
		launch(args);
	}

}
