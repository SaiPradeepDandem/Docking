package fxtest;

import javafx.animation.*;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import xfe.util.UiTestApp;

public class StrokeAnimation {

   public static void main(String[] args){
      new UiTestApp(){

         @Override
         protected Node getNodeUnderTest() {
            Rectangle rect = new Rectangle (100, 40, 100, 100);
            rect.setArcHeight(50);
            rect.setArcWidth(50);
//            rect.setFill();

            FillTransition st = new FillTransition(Duration.millis(500), rect, Color.RED, Color.DARKRED);
            st.setCycleCount(400);
            st.setAutoReverse(true);

            st.play();
            return rect;
         }

      }.launchApp(args);
   }
}
