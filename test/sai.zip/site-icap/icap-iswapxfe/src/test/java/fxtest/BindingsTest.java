package fxtest;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class BindingsTest extends Application {

	static class B {
		private final StringProperty c = new SimpleStringProperty();
		public StringProperty cProperty() { return c; }
		public String getC() { return c.get(); }
		public void setC(String c) { this.c.set(c); }
	}
	
	static class A {
		private final ObjectProperty<B> b = new SimpleObjectProperty<B>(new B());
		public ObjectProperty<B> bProperty() { return b; }
		public B getB() { return b.get(); }
		public void setB(B b) { this.b.set(b); }
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	@Override
	public void start(Stage s) throws Exception {
		Label l = new Label();
		l.setId("zero");
		s.setScene(new Scene(l));
		StringBinding val2 = Bindings.selectString(s.sceneProperty(), "root", "id");
		val2.addListener(new ChangeListener<String>() {

			@Override
			public void changed(
					ObservableValue<? extends String> paramObservableValue,
					String paramT1, String paramT2) {
				System.out.println("Before: " + paramT1 + "\tAfter: " + paramT2);
			}
		});
		l.setId("one");
		Label l2 = new Label();
		l2.setId("two");
		s.getScene().setRoot(l2);
		Label l3 = new Label();
		l3.setId("three");
		s.setScene(new Scene(l3));
		
		ObjectProperty<B> b = new SimpleObjectProperty<B>(new B());
		b.get().setC("1111");
		val2 = Bindings.selectString(b, "c");
		b.get().setC("2222");
		
	}

}
