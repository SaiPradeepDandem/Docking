package fxtest;

import javafx.animation.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class RotateTransitionTest extends Application {
    @Override
    public void start(Stage stage) {
        VBox vbox = new VBox();
        Scene scene = new Scene(vbox, 500, 100);
        stage.setScene(scene);

        Rectangle redRect = new Rectangle (100, 40, 100, 100);
        redRect.setArcHeight(50);
        redRect.setArcWidth(50);
        redRect.setFill(Color.RED);
        vbox.getChildren().add(redRect);
        VBox.setVgrow(redRect, Priority.ALWAYS);

        ParallelTransition pt = new ParallelTransition();
        RotateTransition tt = new RotateTransition(Duration.millis(3000), redRect);
//        tt.setAxis(Rotate.Y_AXIS);
        tt.setAxis(Rotate.X_AXIS);
        tt.setByAngle(90);
//        tt.setAutoReverse(true);
        pt.getChildren().add(tt);

        Timeline timeline = new Timeline();
        timeline.getKeyFrames().add(new KeyFrame(Duration.ZERO, new KeyValue(redRect.heightProperty(),100)));
        timeline.getKeyFrames().add(new KeyFrame(Duration.millis(3000), new KeyValue(redRect.heightProperty(),0)));
        pt.getChildren().add(timeline);

        Rectangle greenRect = new Rectangle (100, 40, 100, 100);
        greenRect.setArcHeight(50);
        greenRect.setArcWidth(50);
        greenRect.setFill(Color.GREEN);
        vbox.getChildren().add(greenRect);
        VBox.setVgrow(greenRect, Priority.ALWAYS);

        RotateTransition tt2 = new RotateTransition(Duration.millis(3000), greenRect);
//        tt.setAxis(Rotate.Y_AXIS);
        tt2.setAxis(Rotate.X_AXIS);
        tt2.setFromAngle(90);
        tt2.setToAngle(0);
//        tt.setAutoReverse(true);
        pt.getChildren().add(tt2);

        Timeline timeline2 = new Timeline();
        timeline2.getKeyFrames().add(new KeyFrame(Duration.ZERO, new KeyValue(greenRect.heightProperty(),0)));
        timeline2.getKeyFrames().add(new KeyFrame(Duration.millis(3000), new KeyValue(greenRect.heightProperty(),100)));
        pt.getChildren().add(timeline2);

        pt.setCycleCount(4);
        pt.play();


        stage.show();

    }
    public static void main(String[] args) {
        launch(args);
    }
}
