package fxtest;

import java.util.Arrays;

import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import xfe.util.BoundObservableValue;
import xfe.util.ObservableListOfObservableValueToObservableValue;
import xfe.util.scene.control.EnhancedTableView;

public class SharedScrollbarTest extends Application {
	static class Row {
		public String text;
		public int value;

		public Row(String text, int value) {
			this.text = text;
			this.value = value;
		}

		public String toString() {
			return text + ":" + value;
		}
	}

	final Row rows1[] = {
			new Row("Item 1", 1),
			new Row("Item 2", 2),
			new Row("Item 3", 3),
			new Row("Item 4", 4),
			new Row("Item 5", 5),
			new Row("Item 6", 6),
			new Row("Item 7", 7),
			new Row("Item 8", 8),
			new Row("Item 8", 9),
			new Row("Item 10", 10),
			new Row("Item 11", 11),
			new Row("Item 12", 12),
			new Row("Item 13", 13),
			new Row("Item 14", 14),
			new Row("Item 15", 15),
			new Row("Item 16", 16),
			new Row("Item 17", 17)
	};

	final Row rows2[] = {
			new Row("Item 1", 1),
			new Row("Item 2", 2),
			new Row("Item 3", 3),
			new Row("Item 4", 4),
			new Row("Item 5", 5),
			new Row("Item 6", 6),
			new Row("Item 7", 7),
			new Row("Item 8", 8),
			new Row("Item 9", 9)
	};

	@Override
	public void start(Stage primaryStage) throws Exception {
		HBox hbox = new HBox() {{
			ScrollBar myScrollbar = new ScrollBar() {{
				this.setOrientation(Orientation.VERTICAL);
				this.setBlockIncrement(0.1);
				this.setUnitIncrement(0.01);
				this.setVisibleAmount(0.5);
				this.setMax(1.0);
				this.setMin(0.0);
			}};

			ObservableListOfObservableValueToObservableValue<Integer, Integer> commonItemCount =
					new ObservableListOfObservableValueToObservableValue<Integer, Integer>(0) {
                  @Override
						public Integer calculate() {
							int maxItemCount = 0;

	                  for (ObservableValue<Integer> observableInteger : getValues()) {
	                  	maxItemCount = Math.max(maxItemCount, observableInteger.getValue());
	                  }

	                  return maxItemCount;
                  }
					};

			EnhancedTableView<Row> tableView1 = new EnhancedTableView<Row>() {{
//				this.flowPositionProperty().bindBidirectional(myScrollbar.valueProperty());
//				this.itemScrollCountProperty().bind(commonItemCount);
				this.getColumns().add(new TableColumn<Row, String>("Item") {{
					this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
						@Override
		            public ObservableValue<String> call(
		                  CellDataFeatures<Row, String> cellDataFeatures) {
							return new SimpleObjectProperty<String>(cellDataFeatures.getValue().text);
		            }
					});
				}});
				this.getColumns().add(new TableColumn<Row, String>("Value") {{
					this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
						@Override
		            public ObservableValue<String> call(
		                  CellDataFeatures<Row, String> cellDataFeatures) {
							return new SimpleObjectProperty<String>(cellDataFeatures.getValue().value + "");
		            }
					});
				}});

				this.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
				BoundObservableValue<Integer> observableValue = new BoundObservableValue<Integer>(
						new Callback<Void, Integer>() {
							@Override
	                  public Integer call(Void _x) {
		                  return getItems().size();
	                  }
						});
				itemsProperty().addListener(observableValue.invalidationListener);
				getItems().addListener(observableValue.invalidationListener);
				commonItemCount.getValues().add(observableValue);
				this.getItems().addAll(rows1);
			}};

			EnhancedTableView<Row> tableView2 = new EnhancedTableView<Row>() {{
//				this.flowPositionProperty().bindBidirectional(myScrollbar.valueProperty());
//				this.itemScrollCountProperty().bind(commonItemCount);
				this.getColumns().add(new TableColumn<Row, String>("Item") {{
					this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
						@Override
		            public ObservableValue<String> call(
		                  CellDataFeatures<Row, String> cellDataFeatures) {
							return new SimpleObjectProperty<String>(cellDataFeatures.getValue().text);
		            }
					});
				}});
				this.getColumns().add(new TableColumn<Row, String>("Value") {{
					this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
						@Override
		            public ObservableValue<String> call(
		                  CellDataFeatures<Row, String> cellDataFeatures) {
							return new SimpleObjectProperty<String>(cellDataFeatures.getValue().value + "");
		            }
					});
				}});

				this.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
				BoundObservableValue<Integer> observableValue = new BoundObservableValue<Integer>(
						new Callback<Void, Integer>() {
							@Override
	                  public Integer call(Void _x) {
		                  return getItems().size();
	                  }
						});
				itemsProperty().addListener(observableValue.invalidationListener);
				getItems().addListener(observableValue.invalidationListener);
				commonItemCount.getValues().add(observableValue);
				this.getItems().addAll(rows2);
//				this.setScrollbarsVisible(false);
			}};

			this.getChildren().addAll(tableView1, tableView2, myScrollbar);
		}};

		primaryStage.setScene(new Scene(hbox));
		primaryStage.getScene().getStylesheets().addAll(
				Arrays.asList(
						"/css/base.css",
						"/css/iswap.css"));
		primaryStage.setHeight(200.0);
		primaryStage.show();
	}

	public static void main(String args[]) {
		launch(args);
	}
}
