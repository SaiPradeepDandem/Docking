package fxtest;

import java.util.Arrays;

import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import javafx.util.Callback;

import xfe.util.DIR;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.layout.AbstractLayout;

public class TableColumnResizeTest extends Application {
	static class Row {
		public String text;
		public int value;

		public Row(String text, int value) {
			this.text = text;
			this.value = value;
		}

		public String toString() {
			return text + ":" + value;
		}
	}

	final Row rows1[] = {
			new Row("Item 1", 1),
			new Row("Item 2", 2),
			new Row("Item 3", 3),
			new Row("Item 4", 4),
			new Row("Item 5", 5),
			new Row("Item 6", 6),
			new Row("Item 7", 7),
			new Row("Item 8", 8),
			new Row("Item 8", 9),
			new Row("Item 10", 10),
			new Row("Item 11", 11),
			new Row("Item 12", 12),
			new Row("Item 13", 13),
			new Row("Item 14", 14),
			new Row("Item 15", 15),
			new Row("Item 16", 16),
			new Row("Item 17", 17)
	};


	@Override
	public void start(Stage primaryStage) throws Exception {
		TableView<Row> tableView = new TableViewHeaderUnmovable<Row>() {{
			this.getColumns().add(new TableColumn<Row, String>("Item") {{
				this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
					@Override
	            public ObservableValue<String> call(
	                  CellDataFeatures<Row, String> cellDataFeatures) {
						return new SimpleObjectProperty<String>(cellDataFeatures.getValue().text);
	            }
				});
				this.setResizable(false);
			}});
			this.getColumns().add(new TableColumn<Row, String>("Value") {{
				this.setCellValueFactory(new Callback<CellDataFeatures<Row,String>, ObservableValue<String>>() {
					@Override
	            public ObservableValue<String> call(
	                  CellDataFeatures<Row, String> cellDataFeatures) {
						return new SimpleObjectProperty<String>(cellDataFeatures.getValue().value + "");
	            }

				});
				this.setResizable(false);
			}});

			this.getItems().addAll(rows1);
//			this.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		}};


		primaryStage.setScene(new Scene(tableView));
		primaryStage.getScene().getStylesheets().addAll(
				Arrays.asList(
						DIR.url(AbstractLayout.class, "base.css"),
                  "/css/iswap.css"));
		primaryStage.setHeight(200.0);
		primaryStage.show();
	}

	public static void main(String args[]) {
		launch(args);
	}
}
