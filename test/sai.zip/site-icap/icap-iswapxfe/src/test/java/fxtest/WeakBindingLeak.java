package fxtest;

import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class WeakBindingLeak {


   private static int countCollected(ReferenceQueue<Object> queue) {
      int count = 0;
      while (true) {
         Reference<? extends Object> reference = queue.poll();
         if (reference == null) {
            break;
         }
         count += 1;
      }
      return count;
   }


   public static void main(String args[]) throws InterruptedException {
      IntegerProperty propertyA = new SimpleIntegerProperty(0);
      ReferenceQueue<Object> queue = new ReferenceQueue<Object>();
      List<Object> references = new ArrayList<Object>();

      for (int i = 0; i < 100; ++i) {
         InvalidationListener listener = new InvalidationListener() {
            @Override
            public void invalidated(Observable listener) {
            }
         };

         WeakInvalidationListener weakListener = new WeakInvalidationListener(listener);
         references.add(new WeakReference<Object>(weakListener, queue));
         propertyA.addListener(weakListener);
      }

      System.gc();
      Thread.sleep(10);

      System.out.println("--> collected: " + countCollected(queue));

      propertyA.setValue(100);

      System.gc();
      Thread.sleep(10);

      System.out.println("--> collected: " + countCollected(queue));
   }
}
