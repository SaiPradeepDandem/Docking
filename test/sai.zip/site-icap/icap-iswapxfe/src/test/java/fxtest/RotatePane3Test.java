package fxtest;

import javafx.application.Application;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import xfe.util.scene.control.RotatorPane3;
import xstr.util.Fx;

public class RotatePane3Test extends Application{

   @Override
   public void start(Stage stage) throws Exception {
      VBox vbox = new VBox();
      vbox.setStyle("-fx-border-width:1;-fx-border-color:red");

     StackPane dummy1 = new StackPane();
     StackPane dummy2 = new StackPane();


      RotatorPane3 pane = new RotatorPane3();

      HBox.setHgrow(pane, Priority.NEVER);
      pane.setStyle("-fx-border-width:1;-fx-border-color:green");

      Scene scene = new Scene(vbox, 500, 200);
      stage.setScene(scene);


      VBox.setVgrow(dummy2, Priority.ALWAYS);
      VBox.setVgrow(dummy1, Priority.ALWAYS);
      VBox.setVgrow(pane, Priority.ALWAYS);
      vbox.getChildren().addAll(dummy1,pane,dummy2);

      VBox one = new VBox();
      HBox hbox0 = new HBox();
      hbox0.setStyle("-fx-border-width:1;-fx-border-color:black");
      Button firstButton0 = new Button("First0");
      Label l0 = new Label("First0");
      TextField t0 = new TextField("text field0");
      ToggleButton tg0 = new ToggleButton("toggle0");
      hbox0.getChildren().addAll(firstButton0,l0,t0,tg0);

      HBox hbox1 = new HBox();
      hbox1.setStyle("-fx-border-width:1;-fx-border-color:black");
      Button firstButton = new Button("First");
      Label l1 = new Label("First1");
      TextField t1 = new TextField("text field1");
      ToggleButton tg1 = new ToggleButton("toggle1");
      hbox1.getChildren().addAll(firstButton,l1,t1,tg1);

      one.getChildren().addAll(hbox1,hbox0);


      one.setId("firstNode");
      pane.addNode(one);



      HBox hbox2 = new HBox();
      hbox2.setStyle("-fx-border-width:1;-fx-border-color:yellow");
      Button firstButton2 = new Button("second");
      Label l2 = new Label("second");
      TextField t2 = new TextField("second second second");
      ToggleButton tg2 = new ToggleButton("second");
      hbox2.getChildren().addAll(firstButton2,l2,t2,tg2);
      hbox2.setId("secondNode");
      pane.addNode(hbox2);

      stage.show();



      int startTime = 1000;
      int intervael = 2000;
      for(int i=0;i<100;i++){
         Fx.delay(startTime + i*intervael, new Runnable() {

            @Override
            public void run() {
               pane.rotate();
            }
         });

      }


   }

    public static void main(String[] args) {
        launch(args);
    }



}

