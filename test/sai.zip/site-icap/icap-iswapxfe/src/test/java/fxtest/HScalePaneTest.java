package fxtest;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import xfe.util.scene.layout.HScalePane;

public class HScalePaneTest extends Application {

	@Override
	public void start(Stage stage) throws Exception {

		StackPane root = new StackPane();
		root.setPadding(new Insets(20));
		root.setStyle("-fx-background-color: blue; ");
		VBox vb = new VBox();
		vb.setPadding(new Insets(20));
		Rectangle r1 = new Rectangle(100,100,Color.RED);
		Rectangle r2 = new Rectangle(200,200,Color.GREEN);
		Label l = new Label("This is a scaled label");
		vb.setSpacing(20);
		vb.setStyle("-fx-border-insets: 10; -fx-background-color: grey;");
		HScalePane sp = new HScalePane();
		sp.setStyle("-fx-background-color: yellow; ");
		vb.getChildren().addAll(r1, l, r2);
		sp.setItem(vb);
		root.getChildren().addAll(sp);
		stage.setScene(new Scene(root));
		stage.setWidth(150);
		stage.setHeight(700);
		stage.show();
	}

	public static void main(String args[]) {
		launch(args);
	}


}
