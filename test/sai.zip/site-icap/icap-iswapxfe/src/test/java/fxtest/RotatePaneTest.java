package fxtest;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import xfe.util.scene.control.RotatorPane;
import xstr.util.Fx;

public class RotatePaneTest extends Application{

   @Override
   public void start(Stage stage) throws Exception {
      HBox hbox = new HBox();
      hbox.setStyle("-fx-border-width:1;-fx-border-color:red");

      RotatorPane pane = new RotatorPane();
      pane.setStyle("-fx-border-width:1;-fx-border-color:green");
      pane.setMaxHeight(60);
      hbox.getChildren().add(pane);
      Scene scene = new Scene(hbox, 500, 200);
      stage.setScene(scene);

      HBox hbox1 = new HBox();
      hbox1.setStyle("-fx-border-width:1;-fx-border-color:black");
      hbox1.setPrefHeight(30);
      Button firstButton = new Button("First");
      Label l1 = new Label("First1");
      TextField t1 = new TextField("text field1");
      ToggleButton tg1 = new ToggleButton("toggle1");
      hbox1.getChildren().addAll(firstButton,l1,t1,tg1);
      hbox1.setId("firstNode");
      pane.addNode(hbox1);

      HBox hbox2 = new HBox();
      hbox2.setStyle("-fx-border-width:1;-fx-border-color:yellow");
      hbox2.setPrefHeight(60);
      Button firstButton2 = new Button("second");
      firstButton2.setPrefHeight(60);
      Label l2 = new Label("second");
      TextField t2 = new TextField("second second second");
      t2.setPrefHeight(60);
      ToggleButton tg2 = new ToggleButton("second");
      hbox2.getChildren().addAll(firstButton2,l2,t2,tg2);
      hbox2.setId("secondNode");
      pane.addNode(hbox2);

      stage.show();
//      pane.savePrefHeight();



      int startTime = 2000;
      int intervael = 6000;
      for(int i=0;i<100;i++){
         Fx.delay(startTime + i*intervael, new Runnable() {

            @Override
            public void run() {
               pane.rotateToNext();
            }
         });

      }


   }

    public static void main(String[] args) {
        launch(args);
    }


}

