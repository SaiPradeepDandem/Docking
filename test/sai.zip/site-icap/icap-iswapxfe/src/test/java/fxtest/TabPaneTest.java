package fxtest;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TabPaneTest extends Application {

   private TabPane tp;

   Tab[] nowTabs = {
      new Tab("Now1"),
      new Tab("Now2"),
      new Tab("Now3")
   };

   Tab[] laterTabs = {
      new Tab("Later1"),
      new Tab("Later2"),
      new Tab("Later3")
   };

   Tab[] replaceTabs = {
      new Tab("Replace1"),
      new Tab("Replace2"),
      new Tab("Replace3"),
      new Tab("Replace4"),
      new Tab("Replace5"),
      new Tab("Replace6")
   };

   final StackPane tabPaneContainer = new StackPane();

   public static void main(String args[]) {
      launch(args);
   }

   TabPane createTabPane(Tab[] tabs) {
      TabPane tp = new TabPane();
      tp.getTabs().addAll(tabs);
      tp.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);
      return tp;
   }

   @Override
   public void start(Stage stage) throws Exception {
      VBox vb = new VBox();
      tp = createTabPane(nowTabs);
      tp.getTabs().remove(2);
      tp.getSelectionModel().select(2);
//		tp.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
      Platform.runLater(new Runnable() {
         @Override
         public void run() {
            tp.getTabs().addAll(laterTabs);
         }
      });
      Platform.runLater(new Runnable() {
         @Override
         public void run() {
//				tp.getTabs().clear();

            tp.getTabs().add(new Tab("Later4"));
            tp.getTabs().add(new Tab("Later5"));
            tp.getTabs().add(new Tab("Later6"));
         }
      });
      vb.getChildren().add(tabPaneContainer);
      Tab t = new Tab("Replace All Tabs");
      Button b = new Button("Replace All Tabs");
      b.setOnAction(paramT -> {

         Platform.runLater(() -> tp.getTabs().clear());
         Platform.runLater(() -> tp.getTabs().setAll(replaceTabs));

         tabPaneContainer.getChildren().add(tp);
         stage.setScene(new Scene(vb));
         stage.show();
      });
   }
}
