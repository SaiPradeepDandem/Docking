package fxtest;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * When the selected row is removed the selection is rendered on another row but there is no notification
 */
public class TableVFlowMemLeak extends Application {
   static class RowItem {
      public final String name;
      DoubleProperty val = new SimpleDoubleProperty();

      RowItem(String n, double p) {
         name = n;
         val.set(p);
      }
   }

   private static int nextRowId = 1;

   private static RowItem nextItem() {
      return new RowItem("Row" + ++nextRowId, nextRowId * 10.0);
   }

   @Override
   public void start(Stage primaryStage) throws Exception {
      TableView<RowItem> tableView = new TableView<>();

      Button updateButton = new Button("Set TableView.refresh Property");
      updateButton.setOnAction(actionEvent -> tableView.getProperties().put("TableView.refresh", "true"));

      TableColumn<RowItem, String> nameCol = new TableColumn<>("Item");
      TableColumn<RowItem, Number> valueCol = new TableColumn<>("Value");

      nameCol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().name));

      valueCol.setCellValueFactory(cellData -> cellData.getValue().val);

      tableView.getColumns().addAll(nameCol, valueCol);
      tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
      for (int i = 0; i < 100; i++) {
         tableView.getItems().add(nextItem());
      }

      VBox tb = new VBox();
      tb.getChildren().add(tableView);

      VBox vb = new VBox();
      vb.getChildren().addAll(tb, updateButton);

      VBox.setVgrow(tb, Priority.ALWAYS);
      VBox.setVgrow(tableView, Priority.ALWAYS);

      primaryStage.setScene(new Scene(vb));
      primaryStage.setHeight(500.0);
      primaryStage.show();

//      VirtualFlow flow = (VirtualFlow) tableView.lookup("VirtualFlow");
//      Region clip = (Region) flow.getChildrenUnmodifiable().get(0);
//      System.out.println("ClippedContainer: " + clip.getClass().getName());
//      final Group clipNode = (Group) clip.getChildrenUnmodifiable().get(0);
//      final Group sheet = (Group) clipNode.getChildrenUnmodifiable().get(0);

//      System.out.println("Sheet child count: " + sheet.getChildren().size());
//
//      sheet.getChildren().addListener(new InvalidationListener() {
//
//         @Override
//         public void invalidated(Observable arg0) {
//            System.out.println("Sheet child count: " + sheet.getChildren().size());
//         }
//      });


      Timeline heightAnim = new Timeline();
      heightAnim.setCycleCount(50);
      heightAnim.getKeyFrames().addAll(new KeyFrame(Duration.seconds(0.0), new KeyValue(tableView.maxHeightProperty(), 0.0)),
         new KeyFrame(Duration.seconds(0.5), new KeyValue(tableView.maxHeightProperty(), 0.0)),
         new KeyFrame(Duration.seconds(1.0), new KeyValue(tableView.maxHeightProperty(), 800.0)),
         new KeyFrame(Duration.seconds(1.5), new KeyValue(tableView.maxHeightProperty(), 800.0)));

      heightAnim.play();
   }

   public static void main(String args[]) {
      launch(args);
   }
}
