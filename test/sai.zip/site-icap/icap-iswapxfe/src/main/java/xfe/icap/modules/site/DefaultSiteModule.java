package xfe.icap.modules.site;

import xfe.icap.ISwapMain;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.module.Module;
import xfe.module.SiteModule;
import xfe.ui.CssSkin;
import xfe.util.Constants;

import java.util.Arrays;
import java.util.List;

public class DefaultSiteModule implements SiteModule {
   @Override
   public String getSiteLogoStyle() {
      return ISwapMain.XFE_SITE_GILTS_UK;
   }

   @Override
   public Class<? extends Module> getSiteDefaultLayout() {
      return MidiLayoutModule.class;
   }

   @Override
   public List<CssSkin> getSiteSkins() {
      CssSkin coreBase = new CssSkin("base", "Minimal", "/css/base.css", null);
      CssSkin icapBase = new CssSkin("icap_base", "Minimal", "/css/gilts_base.css", coreBase);
      return Arrays.asList(
         new CssSkin("icap_dark", "ICAP Blue", "/css/themes/gilts_blue.css", icapBase),
         new CssSkin("icap_light", "Light", "/css/themes/gilts_classic.css", icapBase)
      );

   }

   @Override
   public String getHotLine() {
      return Constants.EUR_HOTLINE;
   }

   @Override
   public String getEmailSupport() {
      return Constants.EUR_SUPPORT_EMAIL;
   }

   @Override
   public String getTitle() {
      return "ICAP Gilts";
   }

   @Override
   public String getShortTitle() {
      return "Gilts";
   }

   @Override
   public boolean showSpreadPlus() {
      return true;
   }
}
