package xfe.icap.modules.settingsview;

import com.nomx.domain.types.*;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;
import xfe.icap.modules.settings.SettingsData;
import xfe.icap.util.SoundPlayer;
import xfe.util.Util;
import xfe.util.scene.control.DurationTextField;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.util.scene.layout.FxmlPane;
import xstr.session.ServerSession;
import xstr.util.Fx;

import javax.sound.sampled.*;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Controller for SettingsLayout.fxml
 */
public class SettingsLayout implements FxmlPane {

   @FXML
   public void initialize() {
      initializeExpandedStates();

      // General
      general_choice_actionOnLogoff.getItems().addAll(OnLogoffAction.REFER, OnLogoffAction.NONE, OnLogoffAction.WITHDRAW);
      final BooleanBinding priceTightnessTabUnselected = general_chk_ptTab.selectedProperty().not();
      general_hb_pt_outright.disableProperty().bind(priceTightnessTabUnselected);
      general_hb_pt_strategy.disableProperty().bind(priceTightnessTabUnselected);
      general_hb_pt_butterfly.disableProperty().bind(priceTightnessTabUnselected);

      // Price Settings
      ToggleGroup tbSideToggle = new ToggleGroup();
      tbSideToggle.getToggles().addAll(pricesettings_rb_bidOffer, pricesettings_rb_offerBid);
      pricesettings_chk_priceMerge_watchlist.managedProperty().bind(pricesettings_chk_priceMerge_watchlist.visibleProperty());

      // Order Entry Details
      ordersize_combo_durationType.getItems().addAll(DefaultDurationType.GOOD_TILL_DAY, DefaultDurationType.GOOD_TILL_DURATION, DefaultDurationType.GOOD_TILL_CANCELLED);

      // Trade Alerts
      final BooleanBinding noTradeAlertSoundCheck = tradeAlert_chk_sound.selectedProperty().not();
      tradeAlert_hb_allTradeSound.disableProperty().bind(noTradeAlertSoundCheck);
      tradeAlert_hb_myTradeSound.disableProperty().bind(noTradeAlertSoundCheck);
      tradeAlert_button_myTradeSound.setOnAction(event -> play(tradeAlert_combo_myTradeSound, tradeAlert_button_myTradeSound));
      tradeAlert_button_allTradeSound.setOnAction(event -> play(tradeAlert_combo_allTradeSound, tradeAlert_button_allTradeSound));
      final BooleanBinding noShowTradeAlert = tradeAlert_chk_show.selectedProperty().not();
      tradeAlert_hb_for.disableProperty().bind(noShowTradeAlert);
      tradeAlert_chk_displayLegs.disableProperty().bind(noShowTradeAlert);
      tradeAlert_chk_expire.disableProperty().bind(noShowTradeAlert);
      tradeAlert_hb_expire.disableProperty().bind(noShowTradeAlert.or(tradeAlert_chk_expire.selectedProperty().not()));
      AlertSound.setitems(tradeAlert_combo_allTradeSound);
      AlertSound.setitems(tradeAlert_combo_myTradeSound);
      tradeAlert_button_testAlert.setOnAction(event -> {
         EventHandler<ActionEvent> handler = SettingsData.getOpenTradeNotificationProp();
         if (handler != null) {
            handler.handle(event);
         }
      });

      // RFQ Settings
      rfq_mmPane.disableProperty().bind(rfq_chk_useGroup.selectedProperty());
      rfq_button_mmGroup.disableProperty().bind(rfq_chk_useGroup.selectedProperty().not());
      rfq_button_mmGroup.setOnAction(event -> {
         EventHandler<ActionEvent> handler = SettingsData.getMMOpenAction();
         if (handler != null) {
            handler.handle(event);
         }
      });

      XfeTooltipFactory.setTooltip(this);
   }

   private void initializeExpandedStates() {
      panels.addAll(Arrays.asList(
         settings_general,
         settings_pricesettings,
         settings_orderentrydefaults,
         settings_tradealerts,
         settings_rfqsettings));

      BitSet expandedStates = new BitSet(panels.size());
      expandedStates.set(0, true);
      setExpandedStates(expandedStates);
      expandedSetProperty().setValue(expandedStates);
      panels.forEach(this::addExpandedListener);
   }

   void setExpandedStates(BitSet expandStates) {
      for (int i = 0; i < panels.size(); ++i)
         panels.get(i).setExpanded(expandStates.get(i));
   }

   private void addExpandedListener(TitledPane pane) {
      pane.expandedProperty().addListener((observable, oldValue, newValue) -> {
         int index = panels.indexOf(pane);
         BitSet bs = (BitSet) getExpandedSet().clone();
         if (index != -1)
            bs.set(index, newValue);
         expandedSetProperty().setValue(bs);
      });
   }

   public void bindSettingsData(SettingsData data, ServerSession xfeSession) {
      final boolean isBroker = xfeSession.isLoggedOnUserBroker();
      // General
      bindVariable(data.hiVisProperty(), general_chk_hivis.selectedProperty());
      bindVariable(data.autoSaveWorkspaceProperty(), general_chk_autoSave.selectedProperty());
      bindVariable(data.orderConfirmProperty(), general_chk_orderConfirm.selectedProperty());
      bindVariable(data.displayVolumeTabProperty(), general_chk_volumeTab.selectedProperty());
      bindVariable(data.onLogoffActionProperty(), general_choice_actionOnLogoff.valueProperty());
      bindVariable(data.autoLogonEnabledProperty(), general_chk_autoLogon.selectedProperty());
      bindVariable(data.displayPTTabProperty(), general_chk_ptTab.selectedProperty());
      bindVariable(data.activesTabProperty(), general_chk_activestab.selectedProperty());
      bindVariable(data.unlockOnAutoLogonProperty(), general_chk_unlockOnAutoLogon.selectedProperty());
      bindVariable(data.popupOnWorkupEndingProperty(), ordersize_chk_popup_workup.selectedProperty());
      bindVariable(data.popupOnCMPriceChangeProperty(), ordersize_chk_popup_cm.selectedProperty());

      setupEditControl(data.autoLogonTimeoutProperty(), 0, 999, general_tf_autoLogon_timeout);
      setupEditControl(data.outrightPTForTabProperty(), 0., 100., -1, general_tf_pt_outright);
      setupEditControl(data.strategyPTForTabProperty(), 0., 100., -1, general_tf_pt_strategy);
      setupEditControl(data.butterflyPTForTabProperty(), 0., 100., -1, general_tf_pt_butterfly);

      // Price Settings
      bindVariable(data.bidOnLeftProperty(), pricesettings_rb_bidOffer.selectedProperty());
      pricesettings_chk_priceMerge_watchlist.setVisible(!isBroker);
      bindVariable(data.mergeImpliedMainWatchlistProperty(), pricesettings_chk_priceMerge_watchlist.selectedProperty());
      bindVariable(data.mergeImpliedMiniWatchlistProperty(), pricesettings_chk_priceMerge_mini.selectedProperty());
      bindVariable(data.displayHistoryProperty(), pricesettings_chk_history.selectedProperty());
      bindVariable(data.cellFlashProperty(), pricesettings_chk_flashCell.selectedProperty());
      setupEditControl(data.cellFlashTimeoutProperty(), 0, 999, pricesettings_tf_flashCell_time);
      setupEditControl(data.cellFlashInterval(), 0, 9999, pricesettings_flash_cell_tf_interval);
      setupEditControl(data.priceCellFlashDuration(), 0, 9999, pricesettings_price_cell_flash_duration_tf);
      setupEditControl(data.outrightPriceTight(), 0., 999., -1, pricesettings_tf_outright_HL);
      setupEditControl(data.strategyPriceTight(), 0., 999., -1, pricesettings_tf_strategy_HL);
      setupEditControl(data.historyHeaderNotificationTimeoutProperty(), 0, 999, pricesettings_tf_history_time);

      // Order Entry Details
      setupEditControl(data.outrightDefaultQtyProperty(), 0., 9999., 0, ordersize_tf_outrightQuantity);
      setupEditControl(data.strategyDefaultQtyProperty(), 0., 9999., 0, ordersize_tf_strategyQuantity);
      setupEditControl(data.leftQtyBtnProperty(), 0, 999, ordersize_tf_leftQuantity);
      setupEditControl(data.middleQtyBtnProperty(), 0, 999, ordersize_tf_middleQuantity);
      setupEditControl(data.rightQtyBtnProperty(), 0, 999, ordersize_tf_rightQuantity);
      setupEditControl(data.yoursMineLitDelayProperty(), 0, 999, ordersize_tf_yoursMine_litDelay);
      bindVariable(data.marketSizeOnOrderEnterProperty(), ordersize_chk_marketSize.selectedProperty());
      bindVariable(data.defaultDurationTypeProperty(), ordersize_combo_durationType.valueProperty());
      bindVariable(data.defaultDurationProperty(), ordersize_tf_duration.valueProperty());
      bindVariable(data.anonOrdersProperty(), ordersize_chk_anonymous.selectedProperty());
      bindVariable(data.autoOCOProperty(), ordersize_chk_autoOCO.selectedProperty());
      bindVariable(data.sharedOrdersProperty(), ordersize_chk_shared.selectedProperty());
      bindVariable(data.yoursMineOrderWithdrawProperty(), ordersize_chk_yoursMine_orderWithdraw.selectedProperty());
      bindVariable(data.clone2RFSProperty(), ordersize_chk_cloneToTS.selectedProperty());
      if (isBroker) {
         data.managedOrdersProperty().setValue(false);
         ordersize_chk_managed.setSelected(false);
         ordersize_chk_managed.setDisable(true);
      } else {
         bindVariable(data.managedOrdersProperty(), ordersize_chk_managed.selectedProperty());
      }
      ordersize_chk_yoursMine_defaultSize.setSelected(data.yoursMineDefaultAmountProperty().get().equals(AmountType.DEFAULT));
      ordersize_chk_yoursMine_defaultSize.selectedProperty().addListener(observable -> {
         data.yoursMineDefaultAmountProperty().setValue(ordersize_chk_yoursMine_defaultSize.isSelected() ?
            AmountType.DEFAULT : AmountType.ORDER);
      });
      data.yoursMineDefaultAmountProperty().addListener(observable -> {
         ordersize_chk_yoursMine_defaultSize.setSelected(data.yoursMineDefaultAmountProperty().get().equals(AmountType.DEFAULT));
      });
      bindVariable(data.tradeOneClickProperty(), ordersize_chk_oneclick.selectedProperty());
      bindVariable(data.topCutProperty(), ordersize_chk_topcut.selectedProperty());
      bindVariable(data.oneClickHitTakeProperty(), ordersize_chk_oneclickhittake.selectedProperty());

      // Trade Alerts
      setupEditControl(data.tradeAlertPopupExpiryValueProperty(), 0, 999, tradeAlert_tf_expire);
      bindVariable(data.showBrokerTradeProperty(), tradeAlert_cb_broker.selectedProperty());
      bindVariable(data.tradeAlertPopupExpiryProperty(), tradeAlert_chk_expire.selectedProperty());
      bindVariable(data.tradeSoundProperty(), tradeAlert_chk_sound.selectedProperty());
      bindVariable(data.alertsShowLegsProperty(), tradeAlert_chk_displayLegs.selectedProperty());
      bindVariable(data.alertSoundForMineProperty(), tradeAlert_combo_myTradeSound.valueProperty());
      bindVariable(data.alertSoundForAllProperty(), tradeAlert_combo_allTradeSound.valueProperty());
      bindVariable(data.autoPopupWorkupProperty(), tradeAlert_chk_tradeWorkup.selectedProperty());
      bindVariable(data.tradeAutoPopupProperty(), tradeAlert_chk_popup.selectedProperty());

      if (isBroker) {
         AlertsGroup value = data.tradeAlertsProperty().get();
         tradeAlert_combo_for.setValue(value);
         enableDisableBrokerCB(isBroker, value);
      } else {
         tradeAlert_combo_for.getSelectionModel().select(1);
      }
      tradeAlert_chk_show.setSelected(data.tradeAlertsProperty().getValue() != AlertsGroup.NONE);
      tradeAlert_chk_show.selectedProperty().addListener((obs, oldVal, selected) -> {
         tradeAlert_combo_for.getSelectionModel().select(selected ?
            (data.tradeAlertsProperty().getValue() == AlertsGroup.NONE ? AlertsGroup.MINE : data.tradeAlertsProperty().get())
            : AlertsGroup.NONE);
      });
      data.tradeAlertsProperty().addListener((obs, oldVal, value) -> {
         tradeAlert_chk_show.setSelected(value != AlertsGroup.NONE);
         tradeAlert_combo_for.setValue(value);
         enableDisableBrokerCB(isBroker, value);
      });
      tradeAlert_combo_for.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, value) -> {
         data.tradeAlertsProperty().setValue(value);
         enableDisableBrokerCB(isBroker, value);
      });

      // RFQ Settings
      bindVariable(data.displayRFQTabProperty(), rfq_chk_tab.selectedProperty());
      bindVariable(data.rfqNotificationProperty(), rfq_chk_rfqNotification.selectedProperty());
      bindVariable(data.rfqAnonymousProperty(), rfq_chk_anonymous.selectedProperty());
      bindVariable(data.hideRfqPaneProperty(), rfq_chk_hidePane.selectedProperty());
      bindVariable(data.hideNonAutoAcceptProperty(), rfq_chk_hideLastLookOrders.selectedProperty());
      bindVariable(data.rfqMMAdvSettingAEnabledProperty(), rfq_chk_useGroup.selectedProperty());
      bindVariableOnly(data.rfqInitiatorOrderAon(), Fx.FalseProp);

      final List<String> wholeList = new ArrayList(data.getAllFirms());
      ObjectProperty<List<String>> mmEffectiveListProp = data.selectedMMFirmsProperty();
      List<String> changedMM = new ArrayList(mmEffectiveListProp.get());
      changedMM.retainAll(wholeList);
      wholeList.stream().sorted().forEach(str -> {
         CheckBox checkBox = new CheckBox(str);
         if (changedMM.contains(str)) {
            checkBox.setSelected(true);
         }
         rfq_mmVbox.getChildren().add(checkBox);
         checkBox.selectedProperty().addListener((obs, oldVal, selected) -> {
            if (selected) {
               if (!changedMM.contains(str)) {
                  changedMM.add(str);
                  mmEffectiveListProp.setValue(changedMM.stream().sorted().collect(Collectors.toList()));
               }
            } else {
               changedMM.remove(str);
               mmEffectiveListProp.setValue(changedMM.stream().sorted().collect(Collectors.toList()));
            }
         });
      });


   }

   BitSet getExpandedSet() {
      return this.expandedSetProperty.get();
   }

   ObjectProperty<BitSet> expandedSetProperty() {
      return this.expandedSetProperty;
   }

   void tailorForRole(ServerSession xfeSession) {
      tradeAlert_combo_for.getItems().add(AlertsGroup.ALL);
      if (!xfeSession.isLoggedOnUserBroker()) {
         tradeAlert_combo_for.getItems().add(AlertsGroup.DESK);
      }
      tradeAlert_combo_for.getItems().add(AlertsGroup.MINE);
      tradeAlert_combo_for.setConverter(new StringConverter<AlertsGroup>() {
         @Override
         public String toString(AlertsGroup alertVal) {
            String strVal = "Un Supported";
            switch (alertVal) {
               case ALL:
                  strVal = "ALL";
                  break;
               case MINE:
                  strVal = xfeSession.getLoggedOnUser().getUserId();
                  break;
               case DESK:
                  strVal = "DESK";
                  break;
               case NONE:
                  strVal = "";
                  break;
               default:
                  break;
            }

            return strVal;
         }

         @Override
         public AlertsGroup fromString(String string) {
            return null;
         }
      });
   }

   private void setupEditControl(IntegerProperty dataProperty, Integer minValue, Integer maxValue, TextField control) {
      control.setTextFormatter(Util.getFormatter(dataProperty.getValue(), minValue, maxValue));
      bindVariable(dataProperty, (Property<Number>) control.textFormatterProperty().getValue().valueProperty());
   }

   private void setupEditControl(DoubleProperty dataProperty, Double minValue, Double maxValue, int decimals, TextField control) {
      control.setTextFormatter(Util.getFormatter(dataProperty.getValue(), minValue, maxValue, decimals));
      bindVariable(dataProperty, (Property<Number>) control.textFormatterProperty().getValue().valueProperty());
   }

   private <T> void bindVariable(Property<T> dataProperty, Property<T> nodeProperty) {
      nodeProperty.bindBidirectional(dataProperty);
      // Any generic implementation will come here.
   }

   private <T> void bindVariableOnly(Property<T> dataProperty, Property<T> nodeProperty) {
      nodeProperty.addListener((ob -> dataProperty.setValue(nodeProperty.getValue())));
      dataProperty.addListener(ob -> nodeProperty.setValue(dataProperty.getValue()));
   }

   private void enableDisableBrokerCB(boolean isBroker, AlertsGroup value) {
      if (isBroker || value != AlertsGroup.MINE) {
         tradeAlert_cb_broker.setSelected(false);
         tradeAlert_cb_broker.setVisible(false);
      } else {
         tradeAlert_cb_broker.setVisible(true);
      }
   }

   @FXML
   private void loadDefaultSettings(ActionEvent e) {
      if (loadDefaultSettingsHandler != null) {
         loadDefaultSettingsHandler.run();
      }
   }

   void setLoadDefaultSettingsHandler(Runnable loadDefaultSettingsHandler) {
      this.loadDefaultSettingsHandler = loadDefaultSettingsHandler;
   }

   private void play(ChoiceBox<AlertSound> combo_tradeSound, Button testButton) {
      if (testButton.getText().contains("Test")) {
         AlertSound as = combo_tradeSound.getSelectionModel().getSelectedItem();
         if (as.equals(AlertSound.NONE)) {
            return;
         }

         Clip clip = SoundPlayer.createClip(as);
         if (clip != null) {
            testButton.setUserData(clip);
            testButton.setText("Stop");
            clip.addLineListener(new LineListener() {
               public void update(LineEvent event) {
                  if (event.getType() == LineEvent.Type.STOP) {
                     event.getLine().removeLineListener(this);
                     event.getLine().close();
                     // The call is from the media playback stopped event, which is not a UI thread.
                     // Adding the call to the FX Thread.
                     Fx.runLater(()-> {
                        testButton.setUserData(null);
                        testButton.setText("Test");});
                  }
               }
            });
            clip.start();
         }
      } else {
         testButton.setText("Test");
         Object o = testButton.getUserData();
         if (o != null) {
            ((Clip) o).stop();
         }
      }
   }

   public void reset() {

   }

   private Runnable loadDefaultSettingsHandler;

   // TitledPanes
   @FXML
   private TitledPane settings_general;
   @FXML
   private TitledPane settings_pricesettings;
   @FXML
   private TitledPane settings_orderentrydefaults;
   @FXML
   private TitledPane settings_tradealerts;
   @FXML
   private TitledPane settings_rfqsettings;

   // General
   @FXML
   public Label general_lbl;
   @FXML
   public CheckBox general_chk_hivis;
   @FXML
   public CheckBox general_chk_autoLogon;
   @FXML
   public TextField general_tf_autoLogon_timeout;
   @FXML
   public Label general_lbl_autoLogon_timeout;
   @FXML
   public CheckBox general_chk_autoSave;
   @FXML
   public CheckBox general_chk_orderConfirm;
   @FXML
   public CheckBox general_chk_volumeTab;
   @FXML
   public ChoiceBox<OnLogoffAction> general_choice_actionOnLogoff;
   @FXML
   public Label general_lbl_actionOnLogoff;
   @FXML
   public CheckBox general_chk_ptTab;
   @FXML
   public TextField general_tf_pt_outright;
   @FXML
   public Label general_lbl_pt_outright;
   @FXML
   public HBox general_hb_pt_outright;
   @FXML
   public TextField general_tf_pt_strategy;
   @FXML
   public Label general_lbl_pt_strategy;
   @FXML
   public HBox general_hb_pt_strategy;
   @FXML
   public TextField general_tf_pt_butterfly;
   @FXML
   public Label general_lbl_pt_butterfly;
   @FXML
   public HBox general_hb_pt_butterfly;
   @FXML
   public CheckBox general_chk_activestab;
   @FXML
   public CheckBox general_chk_unlockOnAutoLogon;

   // Price Settings
   @FXML
   public Label pricesettings_lbl;
   @FXML
   public RadioButton pricesettings_rb_bidOffer;
   @FXML
   public RadioButton pricesettings_rb_offerBid;
   @FXML
   public CheckBox pricesettings_chk_priceMerge_watchlist;
   @FXML
   public CheckBox pricesettings_chk_priceMerge_mini;
   @FXML
   public CheckBox pricesettings_chk_history;
   @FXML
   public TextField pricesettings_tf_history_time;
   @FXML
   public Label pricesettings_lbl_history_time;
   @FXML
   public CheckBox pricesettings_chk_flashCell;
   @FXML
   public TextField pricesettings_tf_flashCell_time;
   @FXML
   public Label pricesettings_lbl_flashCell_time;
   @FXML
   public Label pricesettings_flash_cell_lbl_interval;
   @FXML
   public TextField pricesettings_flash_cell_tf_interval;
   @FXML
   public Label pricesettings_price_cell_flash_duration_tf_lbl;
   @FXML
   public TextField pricesettings_price_cell_flash_duration_tf;
   @FXML
   public TextField pricesettings_tf_outright_HL;
   @FXML
   public Label pricesettings_lbl_outright_HL;
   @FXML
   public TextField pricesettings_tf_strategy_HL;
   @FXML
   public Label pricesettings_lbl_strategy_HL;

   // Order Size
   @FXML
   public Label orderentrydefaults_lbl;
   @FXML
   public TextField ordersize_tf_outrightQuantity;
   @FXML
   public TextField ordersize_tf_strategyQuantity;
   @FXML
   public CheckBox ordersize_chk_marketSize;
   @FXML
   public CheckBox ordersize_chk_yoursMine_defaultSize;
   @FXML
   public TextField ordersize_tf_leftQuantity;
   @FXML
   public TextField ordersize_tf_middleQuantity;
   @FXML
   public TextField ordersize_tf_rightQuantity;
   @FXML
   public TextField ordersize_tf_yoursMine_litDelay;
   @FXML
   public ChoiceBox<DefaultDurationType> ordersize_combo_durationType;
   @FXML
   public DurationTextField ordersize_tf_duration;
   @FXML
   public CheckBox ordersize_chk_popup_workup;
   @FXML
   public CheckBox ordersize_chk_popup_cm;
   @FXML
   public Label ordersize_lbl_leftQuantity;
   @FXML
   public Label ordersize_lbl_middleQuantity;
   @FXML
   public Label ordersize_lbl_rightQuantity;
   @FXML
   public Label ordersize_lbl_yoursMine_litDelay;
   @FXML
   public Label ordersize_lbl_durationType;
   @FXML
   public Label ordersize_lbl_duration;
   @FXML
   public Label ordersize_lbl_outrightQuantity;
   @FXML
   public Label ordersize_lbl_strategyQuantity;
   @FXML
   public CheckBox ordersize_chk_anonymous;
   @FXML
   public CheckBox ordersize_chk_autoOCO;
   @FXML
   public CheckBox ordersize_chk_shared;
   @FXML
   public CheckBox ordersize_chk_managed;
   @FXML
   public CheckBox ordersize_chk_yoursMine_orderWithdraw;
   @FXML
   public CheckBox ordersize_chk_cloneToTS;

   // Trade Alert
   @FXML
   public Label tradealerts_lbl;
   @FXML
   public CheckBox tradeAlert_chk_show;
   @FXML
   public CheckBox tradeAlert_chk_displayLegs;
   @FXML
   public CheckBox tradeAlert_chk_expire;
   @FXML
   public CheckBox tradeAlert_chk_sound;
   @FXML
   public HBox tradeAlert_hb_for;
   @FXML
   public Label tradeAlert_lbl_for;
   @FXML
   public ChoiceBox<AlertsGroup> tradeAlert_combo_for;
   @FXML
   public CheckBox tradeAlert_cb_broker;
   @FXML
   public HBox tradeAlert_hb_expire;
   @FXML
   public Label label_after;
   @FXML
   public TextField tradeAlert_tf_expire;
   @FXML
   public Label label_seconds;
   @FXML
   public HBox tradeAlert_hb_myTradeSound;
   @FXML
   public Label tradeAlert_lbl_myTradeSound;
   @FXML
   public ChoiceBox<AlertSound> tradeAlert_combo_myTradeSound;
   @FXML
   public Button tradeAlert_button_myTradeSound;
   @FXML
   public CheckBox tradeAlert_chk_tradeWorkup;
   @FXML
   public Button tradeAlert_button_testAlert;
   @FXML
   public CheckBox ordersize_chk_oneclick;
   @FXML
   public CheckBox ordersize_chk_topcut;
   @FXML
   public CheckBox ordersize_chk_oneclickhittake;
   @FXML
   public HBox tradeAlert_hb_allTradeSound;
   @FXML
   public ChoiceBox<AlertSound> tradeAlert_combo_allTradeSound;
   @FXML
   public Label tradeAlert_lbl_allTradeSound;
   @FXML
   public Button tradeAlert_button_allTradeSound;
   @FXML
   public CheckBox tradeAlert_chk_popup;

   // RFQ Settings
   @FXML
   public Label rfqsettings_lbl;
   @FXML
   public CheckBox rfq_chk_tab;
   @FXML
   public CheckBox rfq_chk_rfqNotification;
   @FXML
   public CheckBox rfq_chk_anonymous;
   @FXML
   public CheckBox rfq_chk_hidePane;
   @FXML
   public CheckBox rfq_chk_hideLastLookOrders;
   @FXML
   public Label rfq_lbl_marketMaker;
   @FXML
   public CheckBox rfq_chk_useGroup;
   @FXML
   public Button rfq_button_mmGroup;
   @FXML
   public ScrollPane rfq_mmPane;
   @FXML
   public VBox rfq_mmVbox;

   private final List<TitledPane> panels = new ArrayList<>();
   private final ObjectProperty<BitSet> expandedSetProperty = new SimpleObjectProperty<>();


}
