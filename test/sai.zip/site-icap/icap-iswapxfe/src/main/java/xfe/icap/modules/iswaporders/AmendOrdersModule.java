package xfe.icap.modules.iswaporders;

import com.nomx.persist.PersistantName;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableObjectValue;
import javafx.collections.ObservableList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpOrderBookByOrder;
import xfe.icap.modules.actionsui.ActionsUIModule;
import xfe.icap.modules.orderentry.BestPriceCheck;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.types.ManagedOrder;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.notifications.ModalAlertModule;
import xfe.util.XfeAction;
import xstr.amp.AsnAccessor;
import xstr.session.ObservableReplyRow;
import xstr.types.User;
import xstr.util.Fun1;
import xstr.util.Fx;
import xstr.util.ListenerTracker;
import xstr.util.collection.FilteredStaticSorter;
import xstr.util.concurrent.Future;
import xstr.util.exception.XtrException;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.RowFilters;

@Module.Autostart
public class AmendOrdersModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(AmendOrdersModule.class);

   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public ModalAlertModule notificationModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public ActionsUIModule actionsModule;
   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @Override
   public Future<Void> startModule() {
      ObservableList<ObservableReplyRow> orders = xfeSessionModule.orders.get().allOrders;

      tracker.registerRollbackAction(() -> {
         selectedAmendableOrders = null;
      });

      FilteredStaticSorter<ObservableReplyRow> listFilter = FilteredStaticSorter.create(orders, RowFilters.alwaysReject,tracker);

      selectedAmendableOrders = listFilter.getItems();

      tracker.addListener(
         selectionContextModule.selectionContextProperty(), (observable, oldValue, newValue) -> {
            logger.trace("selectContext changed {}",selectionContextModule.selectionContextProperty().get());
            switch (newValue.grid) {
               case Watchlist:
                  DynamicFilter<ObservableReplyRow> filter = RowFilters.alwaysReject;
                  ObservableReplyRow row = newValue.row;
                  AsnAccessor field = newValue.field;
                  if(row != null &&  field != null &&  field != AmpIcapSecBoardTrim2.nLevelImpBidPrice_d && field != AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d){
                     boolean isBid = AmpIcapSecBoardTrim2.isBidRelated(field);
                     boolean isOffer = AmpIcapSecBoardTrim2.isOfferRelated(field);
                     if(!isBid && !isOffer){
                        filter = RowFilters.alwaysReject;
                     }else{
                        ObservableObjectValue<Asn1Type> orderId = isBid ? row.getAsnProperty(AmpIcapSecBoardTrim2.bidOrderId) : row.getAsnProperty(AmpIcapSecBoardTrim2.offerOrderId);
                        if (configurationModule.getData().mergeImpliedMainWatchlistProperty().get()) {
                           ObservableObjectValue<Double> nlevelPrice = isBid ? row.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d) : row.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
                           ObservableObjectValue<Double> price = isBid ? row.getProperty(AmpIcapSecBoardTrim2.bidPrice_d) : row.getProperty(AmpIcapSecBoardTrim2.offerPrice_d);
                           filter = amendableOrdersForSecRow(isBid,orderId,nlevelPrice,price);
                        } else {
                           filter = amendableOrdersForSecRow(orderId);
                        }
                     }
                  }
                  listFilter.setFilter(filter);
                  break;
               case OBBO_BUY:
               case OBBO_SELL:
                  listFilter.setFilter(newValue.row == null ? RowFilters.alwaysReject: amendableOrdersForObboRow(newValue.row)  );
                  break;
               case Orders:
                  listFilter.setFilter(newValue.row == null ? RowFilters.alwaysReject : amendableOrdersForOrderRow(newValue.row) );
                  break;
               default:
                  listFilter.setFilter(RowFilters.alwaysReject);
            }
         });

      tracker.bind(canAmend, Bindings.equal(0, Fx.sizeOfList(selectedAmendableOrders)).not());
      addTickUpTickDownActions();

      bidCommand = new BestPriceCheck(notificationModule, selectionContextModule,true);
      offerCommand = new BestPriceCheck(notificationModule,selectionContextModule, false);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      return Future.SUCCESS;
   }

   private void addTickUpTickDownActions() {
      XfeAction tickupAction = new XfeAction();
      XfeAction tickdownAction = new XfeAction();
      tracker.bind(tickdownAction.disableProperty(), canAmend.not());
      tracker.bind(tickupAction.disableProperty(), canAmend.not());

      tickupAction.setOnAction(actionEvent -> tickUp());

      tickupAction.getStyleClass().add("xfe-icon-tickup");
      tickupAction.setText("Tick\nup");
      tickupAction.setActionId("tickUp");


      tickdownAction.setOnAction(actionEvent -> tickDown());

      tickdownAction.getStyleClass().add("xfe-icon-tickdown");
      tickdownAction.setText("Tick\ndown");
      tickdownAction.setActionId("tickDown");
      registerTickUpTickDownActionButtons(tickupAction, tickdownAction);
   }

   private void registerTickUpTickDownActionButtons(
      XfeAction tickupAction, XfeAction tickdownAction) {
      BooleanProperty bidOnLeft = configurationModule.getParametersStorage()
         .get(PersistantName.BidOnLeft, true);

      tracker.registerRollbackAction(new Runnable() {
         @Override
         public void run() {
            actionsModule.removeAction(tickupAction);
            actionsModule.removeAction(tickdownAction);
         }
         @SuppressWarnings("unused")
         final Object[] strongRefs = { bidOnLeft, tickupAction,
            tickdownAction };
      });

      ChangeListener<Boolean> bidOnLeftChangeListener = (observable, oldValue, bidOnLeft1) -> {
         actionsModule.removeAction(tickupAction);
         actionsModule.removeAction(tickdownAction);

         if (bidOnLeft1) {
            actionsModule.addAction(5, tickupAction);
            actionsModule.addAction(6, tickdownAction);
         } else {
            actionsModule.addAction(5, tickdownAction);
            actionsModule.addAction(6, tickupAction);
         }
      };

      bidOnLeft.addListener(bidOnLeftChangeListener);
      bidOnLeftChangeListener.changed(null, null, bidOnLeft.get());
   }

   private void tickUp() {
      if (canAmend.get()) {
         try {
            ticking(true);
         } catch (XtrException e) {
            logger.error("tickup error", e);
         }
      }
   }

   private void ticking(boolean  isUp) throws XtrException {
      for (ObservableReplyRow row : selectedAmendableOrders) {
         ManagedOrder order = new ManagedOrder(row);
         String secCode = order.getSecCode();
         String boardid = order.getBoardId();
         Double price  = order.getPrice();
         if (configurationModule.getData().orderConfirmProperty().get()) {
            try {
               Double newPrice = securitiesDataModule.getStepArrays().get().getNextPrice(boardid,secCode,price,isUp).get();
               boolean isBid = AmpOrderVerb.buy == order.getBuySell();
               BestPriceCheck command = isBid ? bidCommand : offerCommand;
               command.execute(newPrice).onSuccess(new Fun1<Boolean,Void>() {
                  @Override
                  public Void call(Boolean confirmed) {
                     if(confirmed){
                        try {
                           tickOrder(order,isUp);
                        } catch (XtrException e) {
                           logger.error("ticking error", e);
                        }
                     }
                     return null;
                  }
               });
            } catch (Exception e) {
               logger.error("can't get next price for ticking up {}",secCode);
               tickOrder(order,isUp);
            }
         } else {
            tickOrder(order,isUp);
         }
      }
      isTicking.set(true);
   }

   private void tickOrder(ManagedOrder order, boolean isUp) throws XtrException {
      if (isUp) {
         order.tickUp(activeSessionModule.getSession().get(), securitiesDataModule.getStepArrays().get(), null);
      } else {
         order.tickDown(activeSessionModule.getSession().get(), securitiesDataModule.getStepArrays().get(), null);
      }
   }

   private void tickDown() {
      if (canAmend.get()) {
         try {
            ticking(false);
         } catch (XtrException e) {
            logger.error("tickup down", e);
         }
      }
   }

   private DynamicFilter<ObservableReplyRow> amendableOrdersForSecRow(ObservableObjectValue<Asn1Type> orderId) {
      User loggedOnUser = xfeSessionModule.getUnderlyingSession().getLoggedOnUser();
      if (loggedOnUser.isTrader()) {
         DynamicFilter<ObservableReplyRow> traderFilter = OrderFilters.isTraderSubmitOrder(loggedOnUser.getUserId());
         DynamicFilter<ObservableReplyRow> orderIdFilter = xfeSessionModule.getOrderFilters().withOrderId(orderId).and(OrderFilters.clonedOrder.not());
         return orderIdFilter.and(traderFilter);
      } else if (loggedOnUser.isBroker()) {
         return xfeSessionModule.getOrderFilters().withOrderId(orderId).and(xfeSessionModule.getOrderFilters().amendable);
      } else {
         return RowFilters.alwaysReject;
      }
   }

   private DynamicFilter<ObservableReplyRow> amendableOrdersForSecRow(boolean isBid, ObservableObjectValue<Asn1Type> orderId, ObservableObjectValue<Double> nlevelPrice, ObservableObjectValue<Double> price) {
      User loggedOnUser = xfeSessionModule.getUnderlyingSession().getLoggedOnUser();
      if (loggedOnUser.isTrader()) {
         DynamicFilter<ObservableReplyRow> traderFilter = OrderFilters.isTraderSubmitOrder(loggedOnUser.getUserId());
         DynamicFilter<ObservableReplyRow> orderIdFilter = xfeSessionModule.getOrderFilters().withOrderId(orderId);
         DynamicFilter<ObservableReplyRow> betterPriceFilter = xfeSessionModule.getOrderFilters().isPriceBetterThanNlevelPrice(isBid,price,nlevelPrice);
         return orderIdFilter.and(traderFilter).and(betterPriceFilter).and(OrderFilters.clonedOrder.not());
      } else if (loggedOnUser.isBroker()) {
         return xfeSessionModule.getOrderFilters().withOrderId(orderId).and(xfeSessionModule.getOrderFilters().amendable);
      } else {
         return RowFilters.alwaysReject;
      }
   }

   private DynamicFilter<ObservableReplyRow> amendableOrdersForObboRow(ObservableReplyRow row) {
      String orderUser = row.getString(AmpOrderBookByOrder.userId);
      if (orderUser == null || "Clone".equals(row.getValue(AmpOrderBookByOrder.specialOrderType)))
         return RowFilters.alwaysReject;
      return xfeSessionModule.getOrderFilters().amendable.and(Filters.dynamic(OrderFilters.matchObboRow(row)));
   }

   private DynamicFilter<ObservableReplyRow> amendableOrdersForOrderRow(ObservableReplyRow row) {
      User user = xfeSessionModule.getUnderlyingSession().getLoggedOnUser();
      String userId = user.getUserId();
      DynamicFilter<ObservableReplyRow> userEnteredFilter;
      if (user.isTrader()) {
         userEnteredFilter = RowFilters.equals(AmpManagedOrder.userId,userId).and(RowFilters.empty(AmpManagedOrder.operatorId)).and(RowFilters.empty(AmpManagedOrder.introBrokerId)).and(OrderFilters.clonedOrder.not());
      }else if(user.isIB()){
         userEnteredFilter = RowFilters.equals(AmpManagedOrder.introBrokerId,userId).and(RowFilters.empty(AmpManagedOrder.operatorId));
      }else if(user.isBroker()){
         userEnteredFilter = RowFilters.equals(AmpManagedOrder.operatorId,userId);
      }else {
         return RowFilters.alwaysReject;
      }

      Asn1Type orderId = row.getAsn(AmpManagedOrder.managedOrderId);
      if (orderId != null)
         return RowFilters.equalsAsn(AmpManagedOrder.managedOrderId, orderId).and(userEnteredFilter);
      else {
         orderId = row.getAsn(AmpManagedOrder.currentOrderId);
         if (orderId != null)
            return RowFilters.equalsAsn(AmpManagedOrder.currentOrderId, orderId).and(userEnteredFilter);
         else
            return RowFilters.alwaysReject;
      }

   }
   private final BooleanProperty canAmend = new SimpleBooleanProperty(this, "canAmend", false);
   private final ListenerTracker tracker = new ListenerTracker();
   public BooleanProperty isTicking = new SimpleBooleanProperty(this, "isTicking", false);
   private ObservableList<ObservableReplyRow> selectedAmendableOrders;
   private BestPriceCheck bidCommand ;
   private BestPriceCheck offerCommand;


}
