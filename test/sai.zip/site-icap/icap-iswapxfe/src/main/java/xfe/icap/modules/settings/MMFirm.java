package xfe.icap.modules.settings;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class MMFirm {
   private final BooleanProperty isSelected;
   private final StringProperty firmName;

   MMFirm(BooleanProperty isSelected, String firmName) {
      this.isSelected = isSelected;
      this.firmName = new SimpleStringProperty(this, "firmName", firmName);
   }

   public Boolean getIsSelected() {
      return isSelected.get();
   }

   public void setInternational(boolean isSelected) {
      this.isSelected.set(isSelected);
   }

   public BooleanProperty isSelectedProperty() {
      return isSelected;
    }

   public String getFirmName() {
      return firmName.get();
   }

   public void setFirmName(String firmName) {
      this.firmName.set(firmName);
   }

   public StringProperty firmNameProperty() {
      return firmName;
   }

   @Override
   public String toString() {
     return firmName.get() + (isSelected.get() ? "->TRUE" : "->FALSE");
   }
}
