package xfe.icap.modules.tradesworkup;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.sectabsui.SecTable;
import xfe.ui.flasher.PseudoFlasher;
import xfe.ui.window.XfePopupStageScrollPane;
import xfe.ui.window.XfeWindow;
import xfe.util.EasyFXML;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Layout class for showing the multiple Trade Workups in a single panel.
 */
public class TradesWorkupLayout {

   private static final Logger logger = LoggerFactory.getLogger(TradesWorkupLayout.class);

   private static final int WORKUP_ROWS_COUNT = 8;

   @FXML
   private VBox root;

   @FXML
   private XfePopupStageScrollPane workupRowsScrollPane;

   @FXML
   private VBox workupRowsLayoutPane;

   @FXML
   private StackPane workupRowsContainer;

   @FXML
   private TextArea errorMsgField;
   private ObservableList<Node> workupRows = FXCollections.observableArrayList();
   private Consumer<ObservableReplyRow> closeHandler;
   private Consumer<ObservableReplyRow> removeHandler;
   private Supplier<Date> engineTimeHandler;
   private Function<Integer, Double> defaultQuantityHandler;
   private BiConsumer<ObservableReplyRow, OrderSide> withdrawHandler;
   private BiConsumer<ObservableReplyRow, OrderSide> colleagueWithdrawHandler;
   private BiConsumer<ObservableReplyRow, OrderParams> placeOrderHandler;

   private Supplier<Map<String, WorkupDITArgs>> ditArgsMapSupplier;

   private Function<ObservableReplyRow, String> readCurrentOrderTag;


   public static TradesWorkupLayout load() {
      FXMLLoader ldr = new FXMLLoader(TradesWorkupLayout.class.getResource("TradesWorkupLayout.fxml"));
      try {
         ldr.load();
         return ldr.getController();
      } catch (IOException e) {
         throw new RuntimeException(e);
      }
   }

   @FXML
   public void initialize() {
      root.setId(MidiLayoutViews.TRADES_WORKUP);
      errorMsgField.managedProperty().bind(errorMsgField.visibleProperty());

      Bindings.bindContent(workupRowsLayoutPane.getChildren(), workupRows);
      workupRowsScrollPane.managedProperty().bind(workupRowsScrollPane.visibleProperty());
      workupRowsContainer.managedProperty().bind(workupRowsContainer.visibleProperty());
   }

   public void readjustScrollHeight() {
      int count = workupRows.size();
      if (count > WORKUP_ROWS_COUNT) {
         if (workupRowsScrollPane.getContent() == null) {
            workupRowsContainer.getChildren().clear();
            workupRowsScrollPane.setContent(workupRowsLayoutPane);
         }//what happens if its not null???
         double totalHeight = 2;
         for (int i = 0; i < WORKUP_ROWS_COUNT; i++) {
            TradeWorkupRow tradeWorkupRow = (TradeWorkupRow) workupRows.get(i).getUserData();
            totalHeight += tradeWorkupRow.getComputedHeight();
         }
         workupRowsScrollPane.setScrollPaneHeight(totalHeight);
         workupRowsScrollPane.setVisible(true);
         workupRowsContainer.setVisible(false);
         logger.debug("Adjusting workup parent, in a workupRowsScrollPane, (total = {}, with height={}). In parent: {}",  count, totalHeight, workupRowsScrollPane.getBoundsInParent());
      } else {
         if (!workupRowsContainer.getChildren().contains(workupRowsLayoutPane)) {
            workupRowsScrollPane.setContent(null);
            workupRowsContainer.getChildren().add(workupRowsLayoutPane);
            logger.debug("Adjusting workup parent, in a workupRowsContainer. In parent: {}", workupRowsContainer.getBoundsInParent());
         }
         workupRowsScrollPane.setVisible(false);
         workupRowsContainer.setVisible(true);
      }
      resetStage();
   }


   /**
    * Adds the table row to the provided AmpIcapSecBoardTrim2 ObservableReplyRow object.
    *
    * @param row           ObservableReplyRow for AmpIcapSecBoardTrim2.
    * @param formatterFunc
    */
   void addWorkupRow(ObservableReplyRow row, boolean isCM, Function<Number, String> formatterFunc) {
      Optional<TradeWorkupRow> tradeWorkupRow = workupRows.stream().map(r -> (TradeWorkupRow) r.getUserData()).filter(r -> isSecCodeEquals(r.getRow(), row)).findFirst();

      // If the workup is already present, then update the row layout with new instance of ObservableReplyRow.
      if (tradeWorkupRow.isPresent()) {
         logger.debug("Update current present row {}", workupRows.size());
         tradeWorkupRow.get().updateCurrentRow(row, isCM);
      } else {
         final TradeWorkupRow workupRow = EasyFXML.load(TradeWorkupRow.class);
         workupRow.setPriceFormatter(formatterFunc);
         workupRow.update(row, isCM, this);
         workupRows.add(workupRow.getRoot());
         logger.debug("Adding a workup , total of workuprows {}" , workupRows.size());

         // dont flash here - we want to flash only when we match an order
         //addFlash(workupRow);

      }
      readjustScrollHeight();
   }

   // we want access to flasher to set workupRow when an order matches.
   void addFlash(TradeWorkupRow workupRow) {
      PseudoFlasher.addNodeToFlash(workupRow.getWorkupBox());
      Timeline tl = new Timeline(new KeyFrame(Duration.ZERO, null), new KeyFrame(SecTable.TRADE_FLASH_TIME, null));
      tl.setOnFinished(ex -> PseudoFlasher.removeNodeFromFlash(workupRow.getWorkupBox()));
      tl.play();
   }

   /**
    * Returns all the secBoards (AmpIcapSecBoardTrim2) objects associated in this workup layout.
    *
    * @return List of ObservableReplyRow.
    */
   public List<ObservableReplyRow> getSecBoards() {
      return workupRows.stream().map(r -> ((TradeWorkupRow) r.getUserData()).getRow()).collect(Collectors.toList());
   }

   /**
    * Scrolls to the corresponding workup row matching to the provided secCode.
    *
    * @param secCode SecCode of the workup.
    */
   void scrollTo(String secCode) {
      // TODO:
   }

   private boolean isSecCodeEquals(ObservableReplyRow row1, ObservableReplyRow row2) {
      return row1.getProperty(AmpIcapSecBoardTrim2.secCode).get().equals(row2.getProperty(AmpIcapSecBoardTrim2.secCode).get());
   }

   /**
    * Adjusts the stage size to scene and sets the scroll to the bottom.
    */
   private void resetStage() {
      workupRowsScrollPane.setVvalue(1.0);
      sizeToScene();
   }

   void sizeToScene() {
      if (root.getScene() != null) {
         root.getScene().getWindow().sizeToScene();
      }
   }

   /**
    * Closes the row from the layout.
    *
    * @param row TradeWorkupRow to be closed.
    */
   void closeRow(TradeWorkupRow row) {
      if (closeHandler != null) {
         closeHandler.accept(row.getRow());
      }
      removeRowFromLayout(row);
   }

   /**
    * Removes the row from the list.
    *
    * @param row TradeWorkupRow to be removed
    */
   void removeRow(TradeWorkupRow row) {
      if (removeHandler != null) {
         removeHandler.accept(row.getRow());
      }
      removeRowFromLayout(row);
   }

   /**
    * Withdraws the managed order from the provided row object.
    *
    * @param row       ObservableReplyRow for AmpIcapSecBoardTrim2
    * @param orderSide Order side (Buy/Sell)
    */
   void withdrawOrder(ObservableReplyRow row, OrderSide orderSide) {
      if (withdrawHandler != null) {
         withdrawHandler.accept(row, orderSide);
      }
   }

   void withdrawColleagueOrder(ObservableReplyRow row, OrderSide orderSide) {
      if (colleagueWithdrawHandler != null) {
         colleagueWithdrawHandler.accept(row, orderSide);
      }
   }

   /**
    * Places a new order with the provided quantity.
    *
    * @param row       ObservableReplyRow for AmpIcapSecBoardTrim2
    * @param quantity  Quantity of the order
    * @param orderSide Order side (Buy/Sell)
    * @param isCM Check if the order is Cm order or not
    * @param orderTag send the order Tag for the item
    * @param tradeWorkupRow current row
    */
   void placeOrder(ObservableReplyRow row, double quantity, OrderSide orderSide, boolean isCM, String orderTag, TradeWorkupRow tradeWorkupRow) {
      if (placeOrderHandler != null) {
         placeOrderHandler.accept(row, new OrderParams(quantity, orderSide, isCM, orderTag, tradeWorkupRow));
      }
   }

   /**
    * Returns the default quantity for the provided secClassId.
    *
    * @param secClassId Integer value of secClassId
    * @return Default quantity.
    */
   Double getDefaultQuantity(Integer secClassId) {
      if (defaultQuantityHandler != null) {
         return defaultQuantityHandler.apply(secClassId);
      }
      return null;
   }

   /**
    * Returns the engine time.
    *
    * @return Date.
    */
   Date getEngineTime() {
      if (engineTimeHandler != null) {
         return engineTimeHandler.get();
      }
      return null;
   }

   void setEngineTimeHandler(Supplier<Date> engineTimeHandler) {
      this.engineTimeHandler = engineTimeHandler;
   }

   private void removeRowFromLayout(TradeWorkupRow row) {
      row.getRoot().setUserData(null);
      workupRows.remove(row.getRoot());
      readjustScrollHeight();
      logger.debug("removeRowFromLayout {}", workupRows.size());
      if (workupRows.isEmpty()) {
         errorMsgField.setText("");
         errorMsgField.setVisible(false);
         closeWindow();
      }
   }

   private void closeWindow() {
      if(root!=null && root.getScene()!=null && root.getScene().getWindow()!=null && root.isVisible()) {
         ((XfeWindow) root.getScene().getWindow()).closeWindow();
      } else {
         if(root != null){
            logger.info("Not calling the close action");
            logger.info("Not calling close since the visibility? ->  {}  " , root.isVisible());
            logger.info("Check if the scene is present {} ", root.getScene());
         }
      }
   }

   void showErrorMessage(String errorMsg) {
      errorMsgField.setText(errorMsg);
      errorMsgField.setVisible(true);
      sizeToScene();
   }

   void hideErrorMessage() {
      errorMsgField.setText("");
      errorMsgField.setVisible(false);
      sizeToScene();
   }

   /**
    * Specifies whether the workup popup is showing or not.
    *
    * @return {@code true} if the workup popup is showing else returns {@code false}.
    */
   boolean isWorkupShowing() {
      if (root.getScene() != null) {
         return root.getScene().getWindow().isShowing();
      }
      return false;
   }

   /**
    * Updates the workup row quantity field and the corresponding quantity buttons.
    *
    * @param secCode      Sec code.
    * @param buyTrdedQty  Total buy traded quantity in the workup session
    * @param buyBalQty    Total buy balance quantity in the workup session
    * @param sellTrdedQty Total sell traded quantity in the workup session
    * @param sellBalQty   Total sell balance quantity in the workup session
    * @param decimals     Number of decimals supported for this seccode quantity
    */
   void updateWorkupQuantity(String secCode,
                             BigDecimal buyTrdedQty,
                             BigDecimal buyBalQty,
                             BigDecimal sellTrdedQty,
                             BigDecimal sellBalQty,
                             BigDecimal buyColleagueTrdedQty,
                             BigDecimal buyColleagueBalQty,
                             BigDecimal sellColleagueTrdedQty,
                             BigDecimal sellColleagueBalQty,
                             Integer decimals) {
      final Optional<TradeWorkupRow> tradeWorkupRow = workupRows.stream().map(r -> (TradeWorkupRow) r.getUserData())
         .filter(r -> r.getRow().getProperty(AmpIcapSecBoardTrim2.secCode).get().equals(secCode)).findFirst();


      tradeWorkupRow.ifPresent(workupRow -> workupRow.updateQuantity(buyTrdedQty,
         buyBalQty,
         sellTrdedQty,
         sellBalQty,
         buyColleagueTrdedQty,
         buyColleagueBalQty,
         sellColleagueTrdedQty,
         sellColleagueBalQty,
         decimals));

      /*if(buyColleagueTrdedQty.doubleValue() > 0.00 ||
         buyColleagueBalQty.doubleValue() > 0.00 ||
         sellColleagueTrdedQty.doubleValue() > 0.00 ||
         sellColleagueBalQty.doubleValue() > 0.00){

         resetStage();
      }*/
   }


   public VBox getRoot() {
      return root;
   }

   void setCloseHandler(Consumer<ObservableReplyRow> closeHandler) {
      this.closeHandler = closeHandler;
   }

   void setRemoveHandler(Consumer<ObservableReplyRow> removeHandler) {
      this.removeHandler = removeHandler;
   }

   void setDefaultQuantityHandler(Function<Integer, Double> defaultQuantityHandler) {
      this.defaultQuantityHandler = defaultQuantityHandler;
   }

   void setWithdrawHandler(BiConsumer<ObservableReplyRow, OrderSide> withdrawHandler) {
      this.withdrawHandler = withdrawHandler;
   }

   void setColleagueWithdrawHandler(BiConsumer<ObservableReplyRow, OrderSide> colleagueWithdrawHandler) {
      this.colleagueWithdrawHandler = colleagueWithdrawHandler;
   }

   void setPlaceOrderHandler(BiConsumer<ObservableReplyRow, OrderParams> placeOrderHandler) {
      this.placeOrderHandler = placeOrderHandler;
   }

   public void removeAllRow() {
      // in order to avoid concurrency, crating a shallow copy and clearing the
      // data
      List<Node> copyRow = new ArrayList<>(workupRows);
      workupRows.clear();
      copyRow.stream().forEach( row -> {
         TradeWorkupRow tradeWorkupRow = (TradeWorkupRow) row.getUserData();
         tradeWorkupRow.cleanUp();
         removeRow(tradeWorkupRow);
         row.setUserData(null);
      });
   }

   public void setDitArgsMapSupplier(Supplier<Map<String, WorkupDITArgs>> val) {
      ditArgsMapSupplier = val;
   }

   public WorkupDITArgs getDITArgsBySecCode(String secCode){
      return ditArgsMapSupplier.get().get(secCode);
   }

   public Function<ObservableReplyRow, String> getReadCurrentOrderTag() {
      return readCurrentOrderTag;
   }

   public void setReadCurrentOrderTag(Function<ObservableReplyRow, String> readCurrentOrderTag) {
      this.readCurrentOrderTag = readCurrentOrderTag;
   }

   class OrderParams {
      public final double quantity;
      public final OrderSide orderSide;
      boolean isCM;
      public final TradeWorkupRow tradeWorkupRow;
      public final String orderTag;

      OrderParams(double quantity, OrderSide orderSide, boolean isCM, String orderTag, TradeWorkupRow tradeWorkupRow) {
         this.quantity = quantity;
         this.orderSide = orderSide;
         this.isCM = isCM;
         this.orderTag = orderTag;
         this.tradeWorkupRow = tradeWorkupRow;
      }
   }
}
