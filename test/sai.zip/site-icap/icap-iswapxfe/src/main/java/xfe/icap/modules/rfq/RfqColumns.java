package xfe.icap.modules.rfq;

import java.util.Date;

import javafx.util.StringConverter;

import xfe.util.Constants;
import com.omxgroup.xstream.amp.AmpOrderVerb;

public class RfqColumns implements Constants{

   public static final StringConverter<Integer> RfqBuySellConverter = new StringConverter<Integer>(){
      @Override
      public String toString(Integer status) {
         switch (status) {
         case AmpOrderVerb.buy: return "Offer";
         case AmpOrderVerb.sell: return "Bid";
         case AmpOrderVerb.buyorsell: return "Both";
         }
         return "";
      }

      @Override
      public Integer fromString(String sideString) {
         return null;
      }
   };


   public static final StringConverter<Date> RfqBeginTimeConverter = new StringConverter<Date>(){
      @Override
      public String toString(Date date) {
         return timeFormatter.format(date);
      }

      @Override
      public Date fromString(String sideString) {
         return null;
      }
   };


   public static final StringConverter<Date> RfqDateConverter = new StringConverter<Date>(){
      @Override
      public String toString(Date date) {
         return dateFormatter.format(date);
      }

      @Override
      public Date fromString(String sideString) {
         return null;
      }
   };

}
