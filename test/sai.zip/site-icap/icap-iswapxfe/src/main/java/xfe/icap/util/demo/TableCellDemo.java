package xfe.icap.util.demo;
import java.util.Random;
import java.util.function.Function;

import javafx.application.Application;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class TableCellDemo extends Application {

   public static class ChangeAwareCell<S,T> extends TableCell<S,T> {

      private Function<S, ObservableValue<T>> property ;
      private ObservableValue<T> lastObservableValue ;

      private ChangeListener<T> listener = (obs, oldValue, newValue) -> valueChanged(oldValue, newValue);

      public ChangeAwareCell(Function<S, ObservableValue<T>> property) {
         this.property = property ;
      }

      private void valueChanged(T oldValue, T newValue) {
         System.out.printf("Value changed from %s to %s %n", oldValue, newValue);
      }

      @Override
      protected void updateItem(T item, boolean empty) {
         super.updateItem(item, empty);
         if (lastObservableValue != null) {
            lastObservableValue.removeListener(listener);
         }
         if (empty) {
            setText(null);
         } else {
            final Object cell = getTableRow().getItem();
            if(cell != null) {
               lastObservableValue = property.apply((S) cell);
               lastObservableValue.addListener(listener);
               setText(item.toString());
            }
         }
      }
   }

   @Override
   public void start(Stage primaryStage) {

      TableView<Item> table = new TableView<>();
      TableColumn<Item, String> itemCol = column("Item", Item::nameProperty);
      table.getColumns().add(itemCol);

      TableColumn<Item, Number> valueCol = column("Value", Item:: valueProperty);
      table.getColumns().add(valueCol);

      valueCol.setCellFactory(tc -> new ChangeAwareCell<>(Item::valueProperty));

      TableColumn<Item, Void> changeCol = new TableColumn<>();
      changeCol.setCellFactory(tc -> new TableCell<Item, Void>() {
         private Button incButton = new Button("^");
         private Button decButton = new Button("v");
         private HBox graphic = new HBox(2, incButton, decButton);
         {
            incButton.setOnAction(e -> {
               Item item = (Item) getTableRow().getItem();
               item.setValue(((Integer)item.getValue())+1);
            });
            decButton.setOnAction(e -> {
               Item item = (Item) getTableRow().getItem();
               item.setValue((Integer)item.getValue()-1);
            });
         }
         @Override
         protected void updateItem(Void item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
               setGraphic(null);
            } else {
               setGraphic(graphic);
            }
         }
      });
      table.getColumns().add(changeCol);

      Random rng = new Random();
      for (int i = 1 ; i <= 20  ; i++) {
         table.getItems().add(new Item("Item "+i, rng.nextInt(100)));
      }
      final Button refresh = new Button("Refresh");
      refresh.setOnAction(event -> {
         table.refresh();
      });
      final FlowPane flowPane = new FlowPane(10.0, 10.0, table, refresh);
      Scene scene = new Scene(flowPane);
      primaryStage.setScene(scene);
      primaryStage.show();
   }

   private <S,T> TableColumn<S,T> column(String text, Function<S, ObservableValue<T>> property) {
      TableColumn<S,T> col = new TableColumn<>(text);
      col.setCellValueFactory(cellData -> property.apply(cellData.getValue()));
      col.setPrefWidth(150);
      return col ;
   }


   static class Item<T> {
      private final StringProperty name = new SimpleStringProperty();
      private final ObjectProperty<T> value = new SimpleObjectProperty<T>();

      public Item(String name, T value) {
         setName(name);
         setValue(value);
      }

      @Override
      public String toString() {
         return getName();
      }

      public final StringProperty nameProperty() {
         return this.name;
      }


      public final String getName() {
         return this.nameProperty().get();
      }


      public final void setName(final String name) {
         this.nameProperty().set(name);
      }


      public final ObjectProperty<T> valueProperty() {
         return this.value;
      }


      public final T getValue() {
         return this.valueProperty().get();
      }


      public final void setValue(final T value) {
         this.valueProperty().set(value);
      }



   }

   public static void main(String[] args) {
      launch(args);
   }
}
