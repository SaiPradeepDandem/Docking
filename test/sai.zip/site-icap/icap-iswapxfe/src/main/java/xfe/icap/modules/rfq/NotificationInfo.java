package xfe.icap.modules.rfq;

import java.util.function.Consumer;

public class NotificationInfo {

    Long getRfqNumber() {
        return rfqNumber;
    }

    long getExpiryTime() {
        return expiryTime;
    }

    String getRfqInfo() {
        return rfqInfo;
    }

    Consumer<Long> getQuoteClbk() {
        return quoteClbk;
    }

    Consumer<Long> getCancelClbk() {
        return cancelClbk;
    }

    private final Long rfqNumber;
    private final long expiryTime;
    private final String rfqInfo;
    private final Consumer<Long> quoteClbk;
    private final Consumer<Long> cancelClbk;

    NotificationInfo(Long rfqNumber,
                     long expiryTime,
                     String rfqInfo,
                     Consumer<Long> quoteClbk,
                     Consumer<Long> cancelClbk) {
        this.rfqNumber = rfqNumber;
        this.expiryTime = expiryTime;
        this.rfqInfo = rfqInfo;
        this.quoteClbk = quoteClbk;
        this.cancelClbk = cancelClbk;
    }
}
