package xfe.icap.modules.instrumentsettingsview;

import com.nomx.instrumentsettings.InstrumentSettingsSpec;
import com.nomx.persist.ParametersStorage;
import com.nomx.persist.PersistantName;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settingsview.SettingsViewModule;
import xfe.icap.modules.settingsview.SettingsViewTab;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.types.SecBoards;
import xfe.types.SettingsRoot;
import xfe.util.EasyFXML;
import xstr.util.Fun1;
import xstr.util.concurrent.Future;

import java.util.List;
import java.util.stream.Collectors;

@Module.Autostart
public class InstrumentSettingsViewModule extends SessionScopeModule implements SettingsViewTab {
   private static final Logger logger = LoggerFactory.getLogger(InstrumentSettingsViewModule.class);

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public SecTabsUIModule secTabsUIModule;

   @ModuleDependency
   public SettingsViewModule settingsViewModule;

   @ModuleDependency
   public XfeSession xfeSession;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   private InstrumentSettingsViewLayout instrumentSettingsViewLayout;

   private List<InstrumentSettingsSpec> instrumentSettingsSpecs;

   @Override
   public Future<Void> startModule() {
      resetInstrumentSettingsSpecs();

      this.instrumentSettingsViewLayout = EasyFXML.load(InstrumentSettingsViewLayout.class);
      final SecBoards secBoards = xfeSession.secBoards.get();
      // Creating the instrument settings view only when all the SecBoards are loaded.
      secBoards.ready().onSuccess(new Fun1<Boolean, Void>() {
         @Override
         public Void call(Boolean a) {
            instrumentSettingsViewLayout.updateLayout(secBoards, instrumentSettingsSpecs);
            return null;
         }
      });
      settingsViewModule.addView(getRoot(), this);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      settingsViewModule.removeView(getRoot(), this);
      return Future.SUCCESS;
   }

   @Override
   public boolean isModified() {
      return instrumentSettingsViewLayout.isModified();
   }

   @Override
   public Future<Void> save() {
      final ObservableList<InstrumentSettingsSpec> originalInstruSpecs = configurationModule.getData().instrumentSettingsProperty().get();
      originalInstruSpecs.clear();
      originalInstruSpecs.addAll(instrumentSettingsSpecs);
      secTabsUIModule.refreshActives();
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> reset() {
      instrumentSettingsViewLayout.reset();
      resetInstrumentSettingsSpecs();
      instrumentSettingsViewLayout.updateLayout(xfeSession.secBoards.get(), instrumentSettingsSpecs);
      return null;
   }

   @Override
   public void resetForTestFX() {
      if(ParametersStorage.TESTFX_DATA!=null) {
         instrumentSettingsSpecs =
                 (List<InstrumentSettingsSpec>) SettingsRoot.unmarshallJson(ParametersStorage.TESTFX_DATA).get(PersistantName.InstrumentSettings);
         instrumentSettingsViewLayout.updateLayout(xfeSession.secBoards.get(), instrumentSettingsSpecs);
         save();
      }
   }

   @Override
   public void onShown() {
      instrumentSettingsViewLayout.reset();
   }

   private void resetInstrumentSettingsSpecs(){
      final ObservableList<InstrumentSettingsSpec> originalInstruSpecs = configurationModule.getData().instrumentSettingsProperty().get();
      instrumentSettingsSpecs = originalInstruSpecs.stream().map(InstrumentSettingsSpec::new).collect(Collectors.toList());
      if (instrumentSettingsSpecs.isEmpty()) {
         instrumentSettingsSpecs.add(new InstrumentSettingsSpec(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID, null, true, false,true,true));
      }
   }
   public Node getRoot() {
      return this.instrumentSettingsViewLayout.getRoot();
   }
}
