package xfe.icap.modules.iswaptrades;

/**
 * Created by jiadin on 11/04/2017.
 */
public enum SelectedTab {
   BROKER,ALL,TRADER,MARKET,FIRM,ISWAP,VOICE
}
