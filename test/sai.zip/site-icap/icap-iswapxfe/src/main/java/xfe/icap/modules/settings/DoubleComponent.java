package xfe.icap.modules.settings;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import xstr.util.Fun1;
import xstr.util.NoRecurse;

import xstr.util.Fx;
import xfe.util.scene.control.VerifiedTextField;
import xfe.modules.settings.SettingsComponent;
import xfe.modules.settings.SettingsInstance;

public final class DoubleComponent implements SettingsComponent {
   private static final Fun1<String, Verification<Double>> DEFAULT_TEXT_VERIFIER = new Fun1<String, Verification<Double>>() {
      @Override
      public Verification<Double> call(String text) {
         if (text.length() == 0) {
            return Verification.indeterminate();
         }

         if (text.equals("-")) {
            return Verification.indeterminate();
         }

         Character decimalSeparator = DecimalFormatSymbols.getInstance().getDecimalSeparator();

         if (text.matches("\\" + decimalSeparator)) {
            return Verification.of(0.0);
         }

         // At the moment this regular expression prevents blanking out the double settings fields.
         // If we need to support both blanks and negative values then a more complex
         // expression (with two disparate "routes") needs to be devised.
         String matchRegEx = "-?\\d+(\\" + decimalSeparator + "\\d*)?";
         if (!text.matches(matchRegEx)) {
            return Verification.invalid();
         }

         try {
            return Verification.of(NumberFormat.getInstance().parse(text).doubleValue());
         } catch (ParseException e) {
            return Verification.invalid();
         }
      }
   };

   public static final DoubleComponent DEFAULT = new DoubleComponent(
         null,
         0,
         null,
         DEFAULT_TEXT_VERIFIER);

   private final DoubleProperty valueProperty;
   private final int digits;
   private final BooleanProperty disabled;
   private final Fun1<String, Verification<Double>> parser;

   private DoubleComponent(
      DoubleProperty doubleValue,
      int digits,
      BooleanProperty disabled,
      Fun1<String, Verification<Double>> parser) {
      this.valueProperty = doubleValue;
      this.digits = digits;
      this.disabled = disabled;
      this.parser = parser;
   }

   public DoubleComponent value(DoubleProperty haha) {
      return new DoubleComponent(
              haha,
            this.digits,
            this.disabled,
            this.parser);
   }

   public DoubleComponent value(DoubleProperty doubleProp, BooleanProperty disabledProp) {
      return new DoubleComponent(
            doubleProp,
            this.digits,
            disabledProp,
            this.parser);
   }

   DoubleComponent digits(int haha) {
      return new DoubleComponent(
            this.valueProperty,
              haha,
            this.disabled,
            this.parser);
   }

   public DoubleComponent disabled(BooleanProperty haha) {
      return new DoubleComponent(
            this.valueProperty,
            this.digits,
              haha,
            this.parser);
   }

   BooleanProperty disabledProp(){
      return disabled;
   }

   private DoubleComponent parser(Fun1<String, Verification<Double>> haha) {
      return new DoubleComponent(
            this.valueProperty,
            this.digits,
            this.disabled,
              haha);
   }

   DoubleComponent restrictRange(double min, double max) {
      return parser(new Fun1<String, Verification<Double>>() {
         @Override
         public Verification<Double> call(String text) {
            Verification<Double> verification = parser.call(text);

            for (double value: verification) {
               if (min <= value && value <= max) {
                  return verification;
               }

               return Verification.invalid();
            }

            return verification;
         }
      });
   }

   DoubleComponent setDecimals(int decimals) {
      return parser(new Fun1<String, Verification<Double>>() {
         @Override
         public Verification<Double> call(String text) {
            Verification<Double> verification = parser.call(text);

            for (double value: verification) {
               String string_temp = Double.toString(value);
               String string_form = string_temp.substring(string_temp.indexOf('.'), string_temp.length());
               int l = string_form.length();

               if (l <= decimals)
                  return verification;

               return Verification.invalid();

            }

            return verification;
         }
      });
   }

   private static final DecimalFormat decimalFormat = new DecimalFormat("#.######");

   @Override
   public SettingsInstance create(ToggleGroup toggleGroup) {
      Fun1<String, Boolean> verifier = new Fun1<String, Boolean>() {
         @Override
         public Boolean call(String text) {
            return !parser.call(text).isInvalid();
         }
      };

      TextField textField = new VerifiedTextField(verifier) {
         {
            NoRecurse noRecurse = new NoRecurse();

            textProperty().addListener(new InvalidationListener() {
               @Override
               public void invalidated(Observable observable) {
                  if (!textProperty().get().isEmpty()) {
                     noRecurse.run(() -> {
                        for (double value: parser.call(textProperty().get())) {
                           valueProperty.set(value);
                        }
                     });
                  }
               }
            });

            valueProperty.addListener((observableValue, oldValue, newValue) -> noRecurse.run(() -> textProperty().set(decimalFormat.format(newValue))));

            disableProperty().bind(disabled != null ? disabled : Fx.valueOf(false));

            this.setPrefColumnCount(digits);

            focusedProperty().addListener(new ChangeListener<Boolean>() {
               @Override
               public void changed(
                     ObservableValue<? extends Boolean> observableValue,
                     Boolean oldFocused,
                     Boolean newFocused) {
                  if (oldFocused && !newFocused) {
                     noRecurse.run(() -> textProperty().set(decimalFormat.format(valueProperty.get())));
                  }
               }
            });
         }
      };

      return new SettingsInstance() {
         {
            this.reset();
         }

         @Override
         public Node getNode() {
            return textField;
         }

         @Override
         public void reset() {
            textField.setText(decimalFormat.format(valueProperty.getValue()));
         }

         @Override
         public String getInfo() {
        	 return null;
         }

         @Override
         public void internalAddToolTip(GridPane pane, int yIndex) {
         }
      };
   }
}
