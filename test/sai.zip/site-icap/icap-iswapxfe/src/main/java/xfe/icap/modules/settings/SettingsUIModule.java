package xfe.icap.modules.settings;

import com.nomx.persist.ParametersStorage;
import com.nomx.persist.PersistantName;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.ObjectBinding;
import javafx.event.Event;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.Region;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpUserSetAutoOCO;
import xfe.ui.notifications.ModalAlertModule;
import xstr.session.XtrTransReply;
import xstr.session.XtrTransReply.Status;
import xstr.session.XtrTransRequestBuilder;
import xstr.types.User;
import xstr.util.Fun1Throws;
import xstr.util.Fx;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.icap.XfeSession;
import xfe.module.Module;
import xfe.icap.modules.actionsui.ConfigActionsUIModule;
import xfe.icap.modules.prefsview.PrefsViewsModule;
import xfe.icap.modules.orderentry.OrderEntryPrefs;
import xfe.modules.session.SessionModule;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.watchlist.SettingsView;
import xfe.ui.ConfirmView;
import xfe.ui.InitialisableView;
import xfe.ui.PrefsViewFactory;

import java.util.BitSet;
import java.util.HashSet;
import java.util.Set;

@Module.Autostart
public class SettingsUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(SettingsUIModule.class);

   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public PrefsViewsModule prefsViewsModule;
   @ModuleDependency
   public ConfigActionsUIModule configActionsUIModule;
   @ModuleDependency
   public ModalAlertModule notificationModule;

   private static SettingsUIModule INSTANCE;

   public SettingsUIModule(){
      INSTANCE = this;
   }

   public static SettingsUIModule instance(){
      return INSTANCE;
   }

   public SettingsData getData() {
      return configurationModule.getData();
   }

   /* (non-Javadoc)
    * @see com.nomx.libjxapp.session.AmpSessionListener#handleLogon()
    */
   @Override
   public Future<Void> startModule() {
      tracker.bind(XfeTooltipFactory.tooltipOnProp, tooltipToggle.selectedProperty());

      safeModeToggle.setSelected(false);
      safeModeSelectionLis = observable -> {
         if (safeModeToggle.isSelected())
            sessionModule.lock(true);
         else
            sessionModule.unlock(null, true);
      };
      safeModeToggle.selectedProperty().addListener(safeModeSelectionLis);

      safeModeToggle.disableProperty().bind(sessionModule.lockingDisabledProperty().
         or(sessionModule.lockedProperty().and(sessionModule.safeModeProperty().not())));

      settingsPrefsViewFactory = new PrefsViewFactory() {
         @Override
         public InitialisableView create() {

            SettingsData data = configurationModule.getData();
            SettingsData changingData = data.copy();
            Set<PersistantName> relevantItems = new HashSet<>(SettingsData.getNames());
            User currentUser = xfeSessionModule.getUnderlyingSession().getLoggedOnUser();
            if (currentUser.isBroker())
               relevantItems.remove(PersistantName.ManagedOrders);

            return new SettingsView() {
               @Override
               public Region getRootElement() {
                  SettingsPane settingsPane = SettingsPane.load(xfeSessionModule);
                  assert settingsPane != null;
                  settingsPane.tailorForRole();
                  if (expandedStates != null)
                     settingsPane.setExpandedStates(expandedStates);
                  settingsPane.expandedSetProperty().addListener(observable -> {
                     expandedStates = settingsPane.getExpandedSet();
                  });
                  settingsPane.bounds(changingData);
                  settingsPane.btn_load.setOnAction(actionEvent -> loadDefaults());
                  return settingsPane.getRoot();
               }

               @Override
               public Future<Void> applyChanges() {
                  // If changes detected
                  Set<PersistantName> changes = ParametersStorage.changes(data.getStorage(), changingData.getStorage(), relevantItems);
                  if (!changes.isEmpty()) {
                     ParametersStorage.logChanges(logger, data.getStorage(), changingData.getStorage(), changes);
                     // Applying the changes
                     if(changes.contains(PersistantName.HiVis)) {
                        logger.info("Updating Hi-Vis property, Please wait...");
                        notificationModule.showModalView(ConfirmView.
                           create("Updating Hi-Vis property, Please wait", 3000));
                     }
                     logger.info("Updating Hi-Vis property, Please wait2...");
                     Fx.delay(1000L, () -> {
                        logger.info("Updating Hi-Vis property, Please wait3...");
                        data.getStorage().setAll(changingData.getStorage(), SettingsData.getNames());
                     });
                     logger.info("Updating Hi-Vis property, Please wait4...");
                  }

                  boolean currAutoOCO = changingData.autoOCOProperty().get();
                  if (data.autoOCOProperty().get() != currAutoOCO) {
                     // In this case we need to send a TE transaction to change the autoOCO value.
                     data.setAutoOCO(currAutoOCO);
                     SendAutoOCO(currAutoOCO);
                  }

                  settingsBtn.setSelected(false);
                  return Future.SUCCESS;
               }

               @Override
               protected void loadDefaults() {
                  // Loading the defaults and closing the dialog
                  changingData.getStorage().revertToDefaults(PersistantName.settingsItems);
                  changingData.revertAutoOCO();
               }

               @Override
               public void initialise() {
                  changingData.getStorage().setAll(data.getStorage(), SettingsData.getNames());
                  changingData.revertAutoOCO();
               }

               @Override
               public boolean isModified() {
                  return !ParametersStorage.equals(data.getStorage(), changingData.getStorage(), relevantItems);
               }

               @Override
               public void save() {
                  applyChanges();
               }

               private Future<Void> SendAutoOCO(boolean currAutoOCO) {
                  XtrTransRequestBuilder reqBuilder;
                  try {
                     reqBuilder = XtrTransRequestBuilder.create(AmpUserSetAutoOCO.txn, xfeSessionModule.getUnderlyingSession())
                        .set(AmpUserSetAutoOCO.autoOCO, currAutoOCO);

                     logger.debug("Sending Auto OCO of value " + currAutoOCO);
                     return xfeSessionModule.getUnderlyingSession().execute(reqBuilder.build()).onSuccess(new Fun1Throws<XtrTransReply, Void>() {

                        @Override
                        public Void call(XtrTransReply reply) {
                           logger.debug("Received Auto OCO Reply");
                           if (reply.getStatus() != Status.RESULT_OK) {
                              changingData.autoOCOProperty().set(!currAutoOCO);
                           }
                           return null;
                        }
                     }).onError(a -> {
                        logger.error("Auto OCO ERROR: reverting autoOCOproperty to " + !currAutoOCO);
                        changingData.autoOCOProperty().set(!currAutoOCO);
                        a.printStackTrace();
                        return null;
                     });
                  } catch (AsnTypeException e) {
                     changingData.autoOCOProperty().set(!currAutoOCO);
                     return Futures.error(e);
                  } catch (AmpPermissionException e) {
                     changingData.autoOCOProperty().set(!currAutoOCO);
                     return Futures.error(e);
                  }
               }
            };
         }

         @Override
         public String getViewName() {
            return "Settings";
         }

         @Override
         public int getLeftPriority() {
            return 10;
         }
      };

      prefsViewsModule.addView(settingsPrefsViewFactory, settingsBtn);
      configActionsUIModule.addNode(settingsBtn);
      configActionsUIModule.addNode(safeModeToggle);
      configActionsUIModule.addNode(tooltipToggle);

      prefs.bind(configurationModule.getData(), tracker);
      return Future.SUCCESS;
   }

   /* (non-Javadoc)
    * @see com.nomx.libjxapp.session.AmpSessionListener#handleLogoff()
    */
   @Override
   public Future<Void> stopModule() {
      safeModeToggle.selectedProperty().removeListener(safeModeSelectionLis);
      prefsViewsModule.removeView(settingsPrefsViewFactory);
      expandedStates = null;
      tracker.rollback();
      return Future.SUCCESS;
   }

   public final OrderEntryPrefs prefs = new OrderEntryPrefs();
   private final ToggleButton settingsBtn = new ToggleButton() {
      {
         setId("xfe-iswap-settings-btn");
         XfeTooltipFactory.setTooltip(this);
         setText("Settings");
         getStyleClass().add("xfe-icon-settings");
         setMaxSize(35.0, 20.0);
         this.addEventFilter(javafx.scene.input.KeyEvent.KEY_PRESSED, Event::consume);
      }};
   private final ToggleButton tooltipToggle = new ToggleButton() {
      {
         setId("xfe-iswap-settings-tooltip");
         setText("Tooltip");
         Tooltip on = XfeTooltipFactory.createTooltip("Tooltips","Turn tooltips off",true);
         Tooltip off = XfeTooltipFactory.createTooltip("Tooltips","Turn tooltips on",true);
         this.tooltipProperty().bind(new ObjectBinding<Tooltip>() {
            {
               bind(selectedProperty());
            }
            @Override
            protected Tooltip computeValue() {
               return selectedProperty().get() ? on: off;
            }
         });
         getStyleClass().add("xfe-icon-tooltip");
         setMaxSize(35.0, 20.0);
      }};
   private final ToggleButton safeModeToggle = new ToggleButton() {
      {
         setText("Safe Mode");
         setId("xfe-iswap-safemode-btn");
         this.tooltipProperty().bind(new ObjectBinding<Tooltip>() {
            {
               bind(selectedProperty(),tooltipToggle.selectedProperty());
            }
            @Override
            protected Tooltip computeValue() {
               return tooltipToggle.selectedProperty().get() ?
                  (selectedProperty().get() ?
                     XfeTooltipFactory.createTooltip("Safe Mode","Turn Safe Mode off") :
                     XfeTooltipFactory.createTooltip("Safe Mode","Turn Safe Mode on")) :
                  null;
            }
         });
         getStyleClass().add("xfe-icon-safemode");
         setMaxSize(35.0, 20.0);
         setSelected(false);
      }};
   private final ListenerTracker tracker = new ListenerTracker();
   private PrefsViewFactory settingsPrefsViewFactory;
   private BitSet expandedStates;
   private InvalidationListener safeModeSelectionLis;
}
