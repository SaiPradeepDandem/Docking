package xfe.icap.modules.linelist;

import java.io.IOException;
import java.util.*;

import xstr.types.User.Role;
import xfe.ui.XfeItemTreeCell;
import javafx.beans.value.*;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.util.Callback;

import com.nomx.persist.linelist.*;
import xfe.icap.modules.prefsview.*;
import xfe.ui.SearchableTreeItem;

public class LineListEditView extends XfeGroupEditView<LineList,Participant,Participant> {
   final LinelistModule module;

   // TODO: Remove module from ctor
   public LineListEditView(LinelistModule module) {
      FXMLLoader ldr = new FXMLLoader(XfeGroupEditView.class.getResource("GroupEditor.fxml"));
      this.module = module;
      ldr.setController(this);
      try {
         ldr.load();
      } catch (IOException e) {
         e.printStackTrace();
      }
      xfeItemsTreeView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
   }

//   public static XfeGroupEditView<LineList,Participant,Participant> load(LinelistModule module){
//      FXMLLoader ldr = new FXMLLoader(XfeGroupEditView.class.getResource("GroupEditor.fxml"));
//      LineListEditView rtn = new LineListEditView(module);
//      ldr.setController(rtn);
//      try {
//         ldr.load();
//      } catch (IOException e) {
//         e.printStackTrace();
//      }
//      return rtn;
//   }


   public void populate() {
      xfeGroupListView.setItems(module.getLinelistForEditing());
      if(xfeGroupListView.getItems().isEmpty()){
         createNewGroup();
      }
      ChangeListener<Boolean> listener = new ChangeListener<Boolean> () {

         @Override
         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            if (newValue) {
               module.xfeSessionModule.traderFirmMap.readyPropertyRO.removeListener(this);
               Map<String, Participant> firmsMap = module.xfeSessionModule.traderFirmMap.getFirms();
               SearchableTreeItem<Participant> root =
                       new SearchableTreeItem<>(new Participant(null, "root", Role.DUMMYROOT));
               xfeItemsTreeView.setRoot(root);
               establishTreeView(root, firmsMap);
               xfeGroupListView.getSelectionModel().selectFirst();
            }
         }
      };
      module.xfeSessionModule.traderFirmMap.readyPropertyRO.addListener(listener);
      if(module.xfeSessionModule.traderFirmMap.readyPropertyRO.get()){
         listener.changed(null, false, true);
      }
   }

   @Override
   protected void applyChanges() {
      if (isModified())
         module.saveLineList(xfeGroupListView.getItems());
   }

   @Override
   public boolean isModified() {
      return !module.getLinelist().get().equals(xfeGroupListView.getItems());
   }

   @Override
   public void save() {
      applyChanges();
   }

   private final Comparator sorted = new Comparator<TreeItem<Participant>>() {
      @Override
      public int compare(TreeItem<Participant> o1, TreeItem<Participant> o2) {

         return o1.getValue()==null ? -1 : (o2.getValue()==null ? 1 : o1.getValue().getId().compareTo(o2.getValue().getId()));
      }
   };

   private void establishTreeView(SearchableTreeItem<Participant> root, Map<String, Participant> firmsMap) {
      firmsMap.values().stream().sorted((o1, o2) -> o2.getId().compareTo(o1.getId())).forEach(par -> addRecursively(root, par));
      sortNode(root);
   }

   private void sortNode(TreeItem<Participant> node) {
      List<TreeItem<Participant>> children = node.getChildren();
      children.sort(sorted);
      children.stream().filter(child -> child.getChildren().size() > 0).forEach(this::sortNode);
   }

   private void addRecursively(SearchableTreeItem<Participant> treeItem, Participant par) {
      Map<String, Participant> delegates = par.getDelegatees();
      if (!par.isTrader() && (delegates == null || delegates.size() == 0))
         return;

      SearchableTreeItem<Participant> childTreeNode = new SearchableTreeItem<>(par);
      if(par.isTrader()){
         ObservableList<TreeItem<Participant>> existItems = treeItem.getChildren();
         existItems.add(childTreeNode);
      }else{
         treeItem.getChildren().add(0,childTreeNode);
      }
      if (delegates != null) {
         for (Participant delegate : delegates.values())
            addRecursively(childTreeNode, delegate);
      }
   }

   @Override
   protected LineList createXfeGroup(){
      return new LineList("New Custom Tab");
   }

   @Override
   protected void setCellFactory() {
      Callback<ListView<Participant>, ListCell<Participant>> factory =
              arg0 -> new ParticipantListCell(selectedListView, selectedGroupId, selectedGroupProp);

      selectedListView.setCellFactory(factory);

      Callback<ListView<LineList>, ListCell<LineList>> linelistCellFactory =
              arg0 -> new XfeGroupListCell<>(xfeGroupListView, dummy, null);

      xfeGroupListView.setCellFactory(linelistCellFactory);

      xfeItemsTreeView.setShowRoot(false);

      Callback<TreeView<Participant>, TreeCell<Participant>> treeCellFactory =
              arg0 -> new XfeItemTreeCell<>(selectedListView,xfeGroupListView);


      xfeItemsTreeView.setCellFactory(treeCellFactory);
   }
}
