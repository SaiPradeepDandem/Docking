package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnConversionAccessor;

public class AmpRfqAcc extends AmpAccessor {
   public static final AmpTreq txn = AMP.tREQ("rfq");

   public static final AsnConversionAccessor<String> secCode = acc(AMP.tREQ("rfq.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.tREQ("rfq.secBoardId.boardId"), String.class);
   public static final AsnConversionAccessor<Double> maxQuantity = acc(AMP.tREQ("rfq.maxQuantity"), Double.class);
   public static final AsnConversionAccessor<Double> minQuantity = acc(AMP.tREQ("rfq.minQuantity"), Double.class);
   public static final AsnConversionAccessor<Integer> buySell = acc(AMP.tREQ("rfq.buySell"), Integer.class);
   public static final AsnConversionAccessor<Boolean> fullAmount = acc(AMP.tREQ("rfq.fullAmount"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> anonymous = acc(AMP.tREQ("rfq.anonymous"), Boolean.class);
}
