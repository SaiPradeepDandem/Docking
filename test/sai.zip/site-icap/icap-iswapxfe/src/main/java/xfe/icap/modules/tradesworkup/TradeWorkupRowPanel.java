package xfe.icap.modules.tradesworkup;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.ui.PresetSizeButtonsPane;
import xfe.util.Util;
import xfe.util.scene.control.DoubleTextField;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import static xfe.icap.modules.tradesworkup.WorkupConstants.*;

public class TradeWorkupRowPanel {
   private static double WORKUP_ROW_CONTENT_HEIGHT = 25.0;
   static double WORKUP_ROW_HEIGHT = WORKUP_ROW_CONTENT_HEIGHT + 18;
   private static DecimalFormat PRICE_FORMAT = new DecimalFormat(".##");
   private static SimpleDateFormat END_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   private int decimals;

   @FXML
   public void initialize() {
      timeline.setCycleCount(Timeline.INDEFINITE);
      timeline.getKeyFrames().add(
         new KeyFrame(Duration.seconds(1),
            event -> {
               timeSeconds--;
               workupTimerLabel.setText(timeSeconds.toString());

               // update progress bar
               //Platform.runLater(() -> updateProgressBar());
               if(timeSeconds.intValue() > workupSeconds){
                  workupSeconds = timeSeconds.intValue();
               }

               //System.out.println("timer seconds = "+timeSeconds);

               updateProgressBar();

               if (timeSeconds <= 0) {
                  timeline.stop();
               }
            }));

      PRICE_FORMAT.setPositivePrefix("+");
      PRICE_FORMAT.setNegativePrefix("-");
      final EventHandler<KeyEvent> handler = event -> {
         if (event.getCode() == KeyCode.ESCAPE) {
            parent.requestFocus();
         }
      };
      sellTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (!focused) {
            sellTextField.setVisible(false);
         }
      });
      sellTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);
      sellTextField.setOnAction(event -> {
         Optional<Double> quantity = sellTextField.getTextValue();
         quantity.ifPresent(aDouble -> placeOrder(aDouble, tradedSellQuantity.doubleValue(), OrderSide.SELL));
         parent.requestFocus();
      });
      sellLabel.setOnMouseClicked(e -> enableQuantityTextField(sellTextField, tradedSellQuantity.add(balanceSellQuantity).doubleValue()));

      buyTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (!focused) {
            buyTextField.setVisible(false);
         }
      });
      buyTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);
      buyTextField.setOnAction(event -> {
         Optional<Double> quantity = buyTextField.getTextValue();
         quantity.ifPresent(aDouble -> placeOrder(aDouble, tradedBuyQuantity.doubleValue(), OrderSide.BUY));
         parent.requestFocus();
      });
      buyLabel.setOnMouseClicked(e -> enableQuantityTextField(buyTextField, tradedBuyQuantity.add(balanceBuyQuantity).doubleValue()));

      //closeButton.setOnAction(e -> layout.closeRow(this));
      buyCloseButton.setOnAction(e -> layout.withdrawOrder(row, OrderSide.BUY));
      sellCloseButton.setOnAction(e -> layout.withdrawOrder(row, OrderSide.SELL));
   }

   private void updateProgressBar(){
      if(timeSeconds != null && timeSeconds.intValue() > 0){
         if(timeSeconds.doubleValue() > workupSeconds){
            workupSeconds = timeSeconds;
         }
         double progress = timeSeconds / workupSeconds;
         workupProgressBar.setProgress(progress);
         //System.out.println("Progress = " + progress);
      }
      else{
         workupProgressBar.setProgress(0);
      }
   }

   private void enableQuantityTextField(DoubleTextField textField, double quantity) {
      textField.setVisible(true);
      textField.setDecimals(this.decimals);
      textField.setValue(quantity);
      textField.positionCaret(0);
      textField.selectAll();
      textField.requestFocus();
   }

   private void placeOrder(double totalQuantity, double tradedQuantity, OrderSide side) {
      if (totalQuantity > tradedQuantity) {
         layout.hideErrorMessage();
         // This class is no longer used, sending null inorder to avoid compilation errors
         layout.placeOrder(row, (totalQuantity - tradedQuantity), side, isCM, null,null);
      } else {
         layout.showErrorMessage(row.getValue(AmpIcapSecBoardTrim2.secCode) + " : Quantity cannot be less than or equal to the total traded quantity.");
      }
   }

   public void update(ObservableReplyRow row, boolean isCM, TradesWorkupLayout layout) {
      this.isCM = isCM;
      this.row = row;
      this.parent.setUserData(this);
      this.layout = layout;
      workupPhaseLabel.textProperty().addListener(phaseListener);
      secCodeLabel.setText(row.getProperty(AmpIcapSecBoardTrim2.secCode).get());
      addBindings();

      final double defaultQty = getDefaultQuantity();

      final EventHandler<ActionEvent> buyQtyBtnHandler = e -> {
         final double quantity = Double.parseDouble(((Button) e.getTarget()).getId());
         placeOrder(quantity, tradedBuyQuantity.doubleValue(), OrderSide.BUY);
      };
      buyButtons = new PresetSizeButtonsPane(3, defaultQty, buyQtyBtnHandler, true, Color.WHITE, "xfe-custom-button");
      buyButtonsPane.getChildren().add(buyButtons);

      final EventHandler<ActionEvent> sellQtyBtnHandler = e -> {
         final double quantity = Double.parseDouble(((Button) e.getTarget()).getId());
         placeOrder(quantity, tradedSellQuantity.doubleValue(), OrderSide.SELL);
      };
      sellButtons = new PresetSizeButtonsPane(3, defaultQty, sellQtyBtnHandler, false, Color.WHITE, "xfe-custom-button");
      sellButtonsPane.getChildren().add(sellButtons);
   }

   void updateCurrentRow(ObservableReplyRow newRow, boolean isCM) {
      this.isCM = isCM;
      this.row = newRow;
      workupPhaseLabel.textProperty().unbind();
      workupPriceLabel.textProperty().unbind();

      secCodeLabel.setText(row.getProperty(AmpIcapSecBoardTrim2.secCode).get());
      addBindings();
   }

   /**
    * Updates the quantity display values.
    *  @param buyTrdedQty  Total buy traded quantity in the workup session
    * @param buyBalQty     Total buy balance quantity in the workup session
    * @param sellTrdedQty  Total sell traded quantity in the workup session
    * @param sellBalQty    Total sell balance quantity in the workup session
    * @param decimals      quantity decimals for the seccode
    */
   void updateQuantity(BigDecimal buyTrdedQty,
                       BigDecimal buyBalQty,
                       BigDecimal sellTrdedQty,
                       BigDecimal sellBalQty,
                       BigDecimal buyColleagueTrdedQty,
                       BigDecimal buyColleagueBalQty,
                       BigDecimal sellColleagueTrdedQty,
                       BigDecimal sellColleagueBalQty,
                       Integer decimals) {
      this.decimals = decimals == null ? 0 : decimals;
      this.tradedBuyQuantity = buyTrdedQty;
      this.balanceBuyQuantity = buyBalQty;

      if(buyTrdedQty.doubleValue() == 0.00 && buyBalQty.doubleValue() == 0.00){
         buyLabel.setText("");
      }
      else {
         buyLabel.setText(buyTrdedQty.stripTrailingZeros().toPlainString() + " / " + buyTrdedQty.add(buyBalQty).stripTrailingZeros().toPlainString());
      }

      this.tradedSellQuantity = sellTrdedQty;
      this.balanceSellQuantity = sellBalQty;
      if(sellTrdedQty.doubleValue() == 0.00 && sellBalQty.doubleValue() == 0.00){
         buyLabel.setText("");
      }
      else {
         sellLabel.setText(sellTrdedQty.stripTrailingZeros().toPlainString() + " / " + sellTrdedQty.add(sellBalQty).stripTrailingZeros().toPlainString());
      }

      final double defaultQty = getDefaultQuantity();
      buyButtons.updateButtonSizes(buyTrdedQty.add(buyBalQty).doubleValue(), defaultQty);
      sellButtons.updateButtonSizes(sellTrdedQty.add(sellBalQty).doubleValue(), defaultQty);

      // update total buy/sell label
      String totalBuySellStr = " You ";

      if(buyTrdedQty != null && sellTrdedQty != null){
         if(buyTrdedQty.doubleValue() > sellTrdedQty.doubleValue()){
            double totalBuySize = buyTrdedQty.doubleValue() - sellTrdedQty.doubleValue();
            totalBuySellStr += "Buy "+ Util.sizeFormatter.format(totalBuySize);
         }
         else{
            double totalSellSize = sellTrdedQty.doubleValue() - buyTrdedQty.doubleValue();
            totalBuySellStr += "Sell "+ Util.sizeFormatter.format(totalSellSize);
         }
      }
      else if(buyTrdedQty != null){
         totalBuySellStr += "Buy "+ Util.sizeFormatter.format(buyTrdedQty.doubleValue());
      }
      else if(sellTrdedQty != null){
         totalBuySellStr += "Sell "+ Util.sizeFormatter.format(sellTrdedQty.doubleValue());
      }
      else{
         totalBuySellStr = "";
      }

      boughtSoldTotalLabel.setText(totalBuySellStr);
   }

   /**
    * Gets the defualt quantity for the row. If there is not default quantity set then fetches from configuration module.
    *
    * @return Default quantity value.
    */
   private Double getDefaultQuantity() {
      Double defaultQty = row.getValue(AmpIcapSecBoardTrim2.defaultQty_d);
      if (defaultQty == null) {
         final Integer secClassId = row.getValue(AmpIcapSecBoardTrim2.secClassId);
         defaultQty = layout.getDefaultQuantity(secClassId);
      }
      return defaultQty;
   }

   private void addBindings() {
      final StringBinding priceBinding = new StringBinding() {
         {
            super.bind(row.getProperty(AmpIcapSecBoardTrim2.workupPrice));
         }

         @Override
         protected String computeValue() {
            if (isValidPhase()) {
               return PRICE_FORMAT.format(row.getProperty(AmpIcapSecBoardTrim2.workupPrice).get());
            }
            return "";
         }
      };

      final StringBinding phaseBinding = new StringBinding() {
         {
            super.bind(row.getProperty(AmpIcapSecBoardTrim2.sessionName));
         }

         @Override
         protected String computeValue() {
            final String phase = row.getValue(AmpIcapSecBoardTrim2.sessionName);
            //System.out.println("PhaseBinding evaluate called phase = "+phase);
            if (isValidPhase()) {
               return PUBLIC_SESSION.equals(phase) ? "PUB" : PRIVATE_SESSION.equals(phase) ? "PRI" : phase;
            } else {
               //layout.removeRow(TradeWorkupRowPanel.this);
               return phase;
            }
         }
      };

      final StringBinding timerBinding = new StringBinding() {
         {
            super.bind(row.getProperty(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime));
         }

         @Override
         protected String computeValue() {
            final String endTimeStr = row.getProperty(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime).get();
            //System.out.println("TimerBinding evaluate called endTimeStr = "+endTimeStr);
            if (endTimeStr != null && !endTimeStr.isEmpty()) {
               startTimer(endTimeStr);
            }
            return "";
         }
      };

      workupPhaseLabel.textProperty().bind(phaseBinding);
      workupPriceLabel.textProperty().bind(priceBinding);
      workupTimerBindLabel.textProperty().bind(timerBinding);
   }

   private void startTimer(String endTimeString) {
      if(timeline.getStatus() == Animation.Status.RUNNING){
         timeline.stop();
         //System.out.println(" 3* timeline stopped");
      }
      String time = endTimeString.substring(0, endTimeString.indexOf("."));
      try {
         Date endTime = END_TIME_FORMAT.parse(time);
         Date engineTime = layout.getEngineTime();
         timeSeconds = TimeUnit.MILLISECONDS.toSeconds(endTime.getTime() - engineTime.getTime());
         workupTimerLabel.setText(timeSeconds.toString());
         workupSeconds = timeSeconds.doubleValue();
         updateProgressBar();
         //System.out.println(" 3* timeSeconds = "+timeSeconds.toString());
         timeline.playFromStart();
      } catch (ParseException e) {
         e.printStackTrace();
      }
   }

   public ObservableReplyRow getRow() {
      return row;
   }

   public VBox getRoot() {
      return parent;
   }

   private boolean isValidPhase() {
      final String phase = row.getValue(AmpIcapSecBoardTrim2.sessionName);
      //System.out.println(" 2* Phase = "+phase);
      return PUBLIC_SESSION.equals(phase) || PRIVATE_SESSION.equals(phase);
   }

   @FXML
   private VBox parent;

   //@FXML
   //private Button closeButton;

   @FXML
   private Label secCodeLabel;

   //@FXML
   //private StackPane workupPhasePane;

   //@FXML
   private Label workupPhaseLabel = new Label();

   //@FXML
   //private StackPane workupTimerPane;

   @FXML
   private Label workupTimerLabel = new Label();

   @FXML
   private Label workupTimerBindLabel = new Label();

   /*//@FXML
   private Label workupTimerLabel = new Label();

   //@FXML
   private Label workupTimerBindLabel = new Label();
   */


   @FXML
   private Label sellLabel;

   @FXML
   private DoubleTextField sellTextField;

   @FXML
   private Label buyLabel;

   @FXML
   private DoubleTextField buyTextField;

   @FXML
   private StackPane buyButtonsPane;

   @FXML
   private StackPane sellButtonsPane;

   @FXML
   private Label workupPriceLabel;

   @FXML
   private Button buyCloseButton;

   @FXML
   private Button sellCloseButton;

   @FXML
   private Label boughtSoldTotalLabel;

   @FXML
   private ProgressBar workupProgressBar;

   private ObservableReplyRow row;

   private TradesWorkupLayout layout;

   private PresetSizeButtonsPane buyButtons;

   private PresetSizeButtonsPane sellButtons;

   private BigDecimal tradedBuyQuantity = new BigDecimal(BigInteger.ZERO);

   private BigDecimal tradedSellQuantity = new BigDecimal(BigInteger.ZERO);

   private BigDecimal balanceBuyQuantity = new BigDecimal(BigInteger.ZERO);

   private BigDecimal balanceSellQuantity = new BigDecimal(BigInteger.ZERO);

   private Long timeSeconds;
   private boolean isCM;

   private double workupSeconds = 0;

   private Timeline timeline = new Timeline();
   private final ChangeListener<String> phaseListener = (obs, oldVal, phase) -> {
      //System.out.println(" 1* Phase = "+phase);
      if (phase != null && phase.equals("PRI")) {
         workupProgressBar.setStyle("-fx-accent: -xfe-progress-bar-track-red");
         //workupProgressBar.getStyleClass().removeAll("green-bar", "red-bar");
         //workupProgressBar.getStyleClass().add("red-bar");
         //workupPhasePane.getStyleClass().add("xfe-trade-workup-private-phase");
         //workupTimerPane.getStyleClass().add("xfe-trade-workup-private-phase");
      } else {
         workupProgressBar.setStyle("-fx-accent: -xfe-progress-bar-track-green");
         //workupProgressBar.getStyleClass().add("green-bar");
         //workupPhasePane.getStyleClass().remove("xfe-trade-workup-private-phase");
         //workupTimerPane.getStyleClass().remove("xfe-trade-workup-private-phase");
      }
   };
}
