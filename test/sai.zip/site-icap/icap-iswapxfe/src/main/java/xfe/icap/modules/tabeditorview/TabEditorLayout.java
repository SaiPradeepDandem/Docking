package xfe.icap.modules.tabeditorview;

import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ScrollPane;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.types.SecBoards;

import java.util.List;

/**
 * Controller for TabEditorLayout.fxml
 */
public class TabEditorLayout {
   @FXML
   private ScrollPane root;

   @FXML
   public void initialize() {
      root.setId(MidiLayoutViews.TAB_EDITORVIEW);
   }

   public ScrollPane getRoot() {
      return root;
   }

   public void createView(SecBoards secBoards, ObservableList<WatchlistSpec_v2> watchlists) {
      watchlistEditView = new WatchlistEditView(secBoards, this::showError);
      watchlistEditView.populateFrom(watchlists);
      root.setContent(watchlistEditView.getRootElement());
   }

   public void reset(){
      watchlistEditView.reset();
   }

   public boolean isModified() {
      return watchlistEditView.isModified();
   }

   public void save(){
      watchlistEditView.save();
   }

   public List<WatchlistSpec_v2> getTabsListViewItems(){
      return watchlistEditView.getTabsListViewItems();
   }

   public WatchlistEditView getWatchlistEditView() {
      return watchlistEditView;
   }

   private void showError(String message) {
      Alert alert = new Alert(Alert.AlertType.ERROR);
      alert.setHeaderText(message);
      alert.showAndWait();
   }


   private WatchlistEditView watchlistEditView;
}
