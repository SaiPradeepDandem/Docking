package xfe.icap.ui.table;

import java.util.Date;
import java.util.function.Function;

import javafx.beans.binding.BooleanBinding;
import javafx.beans.value.ObservableValue;

import xstr.amp.AsnConversionAccessor;
import xstr.util.TeClock;
import xfe.icap.XfeSession;
import xstr.session.ObservableReplyRow;

public class ColumnsUtil {

   private final XfeSession xfeSession;

   public ColumnsUtil(XfeSession session){
      this.xfeSession = session;
   }

   public Function<ObservableReplyRow, ObservableValue<Boolean>> flashOnLastMinute(AsnConversionAccessor<Date> endTimeAccessor, long remainingTimeToFlash) {
      return (ObservableReplyRow row) -> {
         return new BooleanBinding(){
            final ObservableValue<Date> endTime = row.getProperty(endTimeAccessor);
            final TeClock teClock = xfeSession.getUnderlyingSession().teClock;
            {
               if(endTime!=null || teClock!=null){
                  bind(endTime, teClock);
               }
            }

            @Override
            protected boolean computeValue() {
               if(endTime.getValue()==null) return false;
               long teTimeL = teClock.get().getTime();
               long endTimeL = endTime.getValue().getTime();
               long timeGap = endTimeL - teTimeL;
               return timeGap<=remainingTimeToFlash && timeGap>0;
            }

         };

      };
   }


}
