package xfe.icap.modules.strategy;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import xstr.util.concurrent.Future;

import xfe.types.UiSession;
import xstr.session.SessionListener;
import xfe.util.XfeAction;
import xfe.module.Module;
import xfe.icap.modules.actionsui.ActionsUIModule;

public class StrategyModule implements Module,SessionListener {

	@ModuleDependency
    public UiSession xfeSession;

	@ModuleDependency
	public ActionsUIModule actions;

	@Override
   public Future<Void> handleLogon() {
		XfeAction strategyAction = new XfeAction();
		strategyAction.setDisable(true);
		strategyAction.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				System.out.println("On Create Strategy");
			}
		});
		strategyAction.setText("Create\nStrategy");
		strategyAction.getStyleClass().add("xfe-icon-strategy");
		actions.addAction(1, strategyAction);
      return DONE;
	}

	@Override
   public void handleLogoff() {
		uninitializeContents();
	}

	private void uninitializeContents() {
		// TODO Auto-generated method stub

	}

}
