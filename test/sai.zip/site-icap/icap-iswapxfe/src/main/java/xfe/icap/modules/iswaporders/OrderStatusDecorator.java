package xfe.icap.modules.iswaporders;

import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableStringValue;
import javafx.util.Callback;

import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import com.omxgroup.xstream.amp.AmpOrderStatus_v2;

public abstract class OrderStatusDecorator {
	public static Callback<ObservableReplyRow, ObservableStringValue>	orderStatus(AsnConversionAccessor<Integer> acc) {
		return new Callback<ObservableReplyRow, ObservableStringValue>() {
			@Override
			public ObservableStringValue call(ObservableReplyRow row) {
				return new StringBinding() {
					private final ObservableObjectValue<Integer> prop = row.getProperty(acc);
					{
						super.bind(prop);
					}

					@Override
					protected String computeValue() {
						if (row != null) {
							int value = prop.getValue();
							switch (value) {
							case PRIVATE_ORDER:
								return "Refer";
							case MATCHED:
								return "Accepted";
							case PENDING:
								return "Pending";
							default:
								return row.getString(acc);
							}
						}
						return "";
					}

				};
			}
		};
	}

   public static final int PRIVATE_ORDER  = AmpOrderStatus_v2.privateOrder;
   public static final int WITHDRAWN = AmpOrderStatus_v2.withdrawn;
   public static final int OPEN = AmpOrderStatus_v2.open;
   public static final int EMBARGOED = AmpOrderStatus_v2.embargoed;
   public static final int CLEARING_QUEUED = AmpOrderStatus_v2.clearingqueued;
   public static final int INACTIVE_STOP = AmpOrderStatus_v2.inactiveStop;
   public static final int UNPLACED= AmpOrderStatus_v2.unplaced;
   public static final int UNPLACED_STOP = AmpOrderStatus_v2.unplacedStop;
   public static final int UNAPPROVED = AmpOrderStatus_v2.unapproved;
   public static final int UNCONFIRMED = AmpOrderStatus_v2.unconfirmed;
   public static final int CONDIRMED = AmpOrderStatus_v2.confirmed;
   public static final int PENDING = AmpOrderStatus_v2.pending;
   public static final int AMENDED = AmpOrderStatus_v2.amended;
   public static final int MATCHED = AmpOrderStatus_v2.matched;
   public static final int EXPIRED = AmpOrderStatus_v2.expired;
}
