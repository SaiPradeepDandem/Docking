package xfe.icap.modules.tradesworkup;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.types.Orders;
import xfe.ui.PresetSizeButtonsPane;
import xfe.util.Util;
import xfe.util.scene.control.DoubleTextField;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.Fx;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.Date;
import java.util.Optional;
import java.util.function.Function;

import static xfe.icap.modules.tradesworkup.WorkupConstants.*;

/**
 * Layout for each trade workup row.
 */
public class TradeWorkupRow {
   private static final Logger logger = LoggerFactory.getLogger(TradeWorkupRow.class);

   private static double WORKUP_ROW_CONTENT_HEIGHT = 28.0;
   private static double WORKUP_ROW_HEIGHT = WORKUP_ROW_CONTENT_HEIGHT;// + 18;
   private int decimals;
   private static final int PROGRESS_TRACK_REFRESH_RATE = 100;

   @FXML
   private VBox root;

   @FXML
   private Label secCodeLabel;

   //@FXML
   private Label workupPhaseLabel = new Label();

   @FXML
   private Label workupTimerLabel;

   @FXML
   private Label sessionNameLabel;

   @FXML
   private GridPane workupbox;

   @FXML
   private Label sellLabel;

   @FXML
   private DoubleTextField sellTextField;

   @FXML
   private Label buyLabel;

   @FXML
   private DoubleTextField buyTextField;

   @FXML
   private StackPane buyButtonsPane;

   @FXML
   private StackPane sellButtonsPane;

   @FXML
   private Label workupPriceLabel;

   @FXML
   private Button buyCloseButton;

   @FXML
   private Button sellCloseButton;

   @FXML
   private Label boughtSoldTotalLabel;

   @FXML
   private ProgressBar workupProgressBar;

   @FXML
   private GridPane colleaguePane;

   @FXML
   private Button buyColleagueCloseButton;

   @FXML
   private Button sellColleagueCloseButton;

   @FXML
   private Label buyColleagueLabel;

   @FXML
   private Label sellColleagueLabel;

   @FXML
   private DoubleTextField buyColleagueTextField;

   @FXML
   private DoubleTextField sellColleagueTextField;

   @FXML
   private HBox bidOnPane;

   @FXML
   private CheckBox bidOnCheckBox;

   @FXML
   private HBox bidOnDITPane;

   @FXML
   private CheckBox bidOnDITCheckBox;

   @FXML
   private HBox offerOnPane;

   @FXML
   private CheckBox offerOnCheckBox;

   @FXML
   private HBox offerOnDITPane;

   @FXML
   private CheckBox offerOnDITCheckBox;

   private ObservableReplyRow row;

   private TradesWorkupLayout layout;

   private PresetSizeButtonsPane buyButtons;

   private PresetSizeButtonsPane sellButtons;

   private BigDecimal tradedBuyQuantity = new BigDecimal(BigInteger.ZERO);

   private BigDecimal tradedSellQuantity = new BigDecimal(BigInteger.ZERO);

   private BigDecimal balanceBuyQuantity = new BigDecimal(BigInteger.ZERO);

   private BigDecimal balanceSellQuantity = new BigDecimal(BigInteger.ZERO);

   private Long progressbarPeriod;
   private boolean isCM;

   private double workupSeconds = 0;

   private Function<Number, String> priceFormatter;
   private Timeline timeline = new Timeline();
   private final ChangeListener<String> phaseListener = (obs, oldVal, phase) -> {
      if (phase != null && phase.equals("PRI")) {
         workupProgressBar.setStyle("-fx-accent: -xfe-progress-bar-track-red");
         sessionNameLabel.setText("PRIVATE");
      } else {
         workupProgressBar.setStyle("-fx-accent: -xfe-progress-bar-track-green");
         sessionNameLabel.setText("PUBLIC");
      }
   };


   private ChangeListener<String> endTimeListener = (obs, old, endTimeStr) -> {
      if (endTimeStr != null && !endTimeStr.isEmpty()) {
         startTimer(endTimeStr);
      }
   };


   @FXML
   public void initialize() {
      colleaguePane.managedProperty().bind(colleaguePane.visibleProperty());
      colleaguePane.setVisible(false);

      timeline.setCycleCount(Timeline.INDEFINITE);
      timeline.getKeyFrames().add(
         new KeyFrame(Duration.millis(PROGRESS_TRACK_REFRESH_RATE),
            event -> {
               progressbarPeriod -= PROGRESS_TRACK_REFRESH_RATE;
               workupTimerLabel.setText(progressbarPeriod.toString());

               // update progress bar
               //Platform.runLater(() -> updateProgressBar());
               if (progressbarPeriod.intValue() > workupSeconds) {
                  workupSeconds = progressbarPeriod.intValue();
               }

               updateProgressBar();

               if (progressbarPeriod <= 0) {
                  timeline.stop();
               }
            }));

      final EventHandler<KeyEvent> handler = event -> {
         if (event.getCode() == KeyCode.ESCAPE) {
            root.requestFocus();
         }
      };
      sellTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (!focused) {
            sellTextField.setVisible(false);
         }
      });
      sellTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);
      sellTextField.setOnAction(event -> {
         Optional<Double> quantity = sellTextField.getTextValue();
         quantity.ifPresent(aDouble -> placeOrder(aDouble, tradedSellQuantity.doubleValue(), OrderSide.SELL));
         root.requestFocus();
      });
      sellLabel.setOnMouseClicked(e -> enableQuantityTextField(sellTextField, tradedSellQuantity.add(balanceSellQuantity).doubleValue()));

      buyTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (!focused) {
            buyTextField.setVisible(false);
         }
      });
      buyTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);
      buyTextField.setOnAction(event -> {
         Optional<Double> quantity = buyTextField.getTextValue();
         quantity.ifPresent(aDouble -> placeOrder(aDouble, tradedBuyQuantity.doubleValue(), OrderSide.BUY));
         root.requestFocus();
      });
      buyLabel.setOnMouseClicked(e -> enableQuantityTextField(buyTextField, tradedBuyQuantity.add(balanceBuyQuantity).doubleValue()));

      //closeButton.setOnAction(e -> layout.closeRow(this));
      buyCloseButton.setOnAction(e -> layout.withdrawOrder(row, OrderSide.BUY));
      sellCloseButton.setOnAction(e -> layout.withdrawOrder(row, OrderSide.SELL));

      buyColleagueCloseButton.setOnAction(e -> layout.withdrawColleagueOrder(row, OrderSide.BUY));
      sellColleagueCloseButton.setOnAction(e -> layout.withdrawColleagueOrder(row, OrderSide.SELL));

      secCodeLabel.setStyle("-fx-font-weight: bold;");

      // DIT Implementations
      bidOnCheckBox.selectedProperty().addListener((obs,old,val)->layout.getDITArgsBySecCode(row.getValue(AmpIcapSecBoardTrim2.secCode)).setBidOn(val));
      bidOnDITCheckBox.selectedProperty().addListener((obs,old,val)->layout.getDITArgsBySecCode(row.getValue(AmpIcapSecBoardTrim2.secCode)).setBidOnDIT(val));
      offerOnCheckBox.selectedProperty().addListener((obs,old,val)->layout.getDITArgsBySecCode(row.getValue(AmpIcapSecBoardTrim2.secCode)).setOfferOn(val));
      offerOnDITCheckBox.selectedProperty().addListener((obs,old,val)->layout.getDITArgsBySecCode(row.getValue(AmpIcapSecBoardTrim2.secCode)).setOfferOnDIT(val));
      bidOnDITPane.visibleProperty().addListener((obs,old,visible)->{
         if(!visible){
            bidOnDITCheckBox.setSelected(false);
         }
      });
      offerOnDITPane.visibleProperty().addListener((obs,old,visible)->{
         if(!visible){
            offerOnDITCheckBox.setSelected(false);
         }
      });
      bidOnDITPane.visibleProperty().bind(bidOnCheckBox.selectedProperty());
      offerOnDITPane.visibleProperty().bind(offerOnCheckBox.selectedProperty());
   }

   double getComputedHeight() {
      if (colleaguePane.isVisible())
         return WORKUP_ROW_CONTENT_HEIGHT * 4 - 2;
      else
         return WORKUP_ROW_CONTENT_HEIGHT * 3 - 1;
   }

   private void updateProgressBar() {
      if (progressbarPeriod != null && progressbarPeriod.intValue() > 0) {
         if (progressbarPeriod.doubleValue() > workupSeconds) {
            workupSeconds = progressbarPeriod;
         }
         double progress = progressbarPeriod / workupSeconds;
         Fx.checkRunningThread(this,"Updating the workup progress bar");
         workupProgressBar.setProgress(progress);
      } else {
         workupProgressBar.setProgress(0);
      }
   }

   private void enableQuantityTextField(DoubleTextField textField, double quantity) {
      textField.setVisible(true);
      textField.setDecimals(this.decimals);
      textField.setValue(quantity);
      textField.positionCaret(0);
      textField.selectAll();
      textField.requestFocus();
   }

   private void placeOrder(double totalQuantity, double tradedQuantity, OrderSide side) {
      if (totalQuantity > tradedQuantity) {

         // retrieve current order tag
         String currentOrderTag = isCM ? Orders.CM : layout.getReadCurrentOrderTag().apply(row);
         // withdraw orders on opposite side first
         if (side.equals(OrderSide.BUY)) {
            layout.withdrawOrder(row, OrderSide.SELL);
         } else {
            layout.withdrawOrder(row, OrderSide.BUY);
         }

         layout.hideErrorMessage();
         layout.placeOrder(row, (totalQuantity - tradedQuantity), side, isCM, currentOrderTag,this);
      } else {
         layout.showErrorMessage(row.getValue(AmpIcapSecBoardTrim2.secCode) + " : Quantity cannot be less than or equal to the total traded quantity.");
      }
   }

   public void update(ObservableReplyRow row, boolean isCM, TradesWorkupLayout layout) {
      Fx.checkRunningThread(this, "Update workup method called");
      removeBindings();
      this.isCM = isCM;
      this.row = row;
      this.root.setUserData(this);
      this.layout = layout;
      workupPhaseLabel.textProperty().addListener(phaseListener);
      secCodeLabel.setText(row.getValue(AmpIcapSecBoardTrim2.secCode));
      addBindings();

      final double defaultQty = getDefaultQuantity();

      final EventHandler<ActionEvent> buyQtyBtnHandler = e -> {
         final double quantity = Double.parseDouble(((Button) e.getTarget()).getId());
         placeOrder(quantity, tradedBuyQuantity.doubleValue(), OrderSide.BUY);
      };
      buyButtons = new PresetSizeButtonsPane(3, defaultQty, buyQtyBtnHandler, true, Color.WHITE, "xfe-custom-button");
      buyButtonsPane.getChildren().add(buyButtons);

      final EventHandler<ActionEvent> sellQtyBtnHandler = e -> {
         final double quantity = Double.parseDouble(((Button) e.getTarget()).getId());
         placeOrder(quantity, tradedSellQuantity.doubleValue(), OrderSide.SELL);
      };
      sellButtons = new PresetSizeButtonsPane(3, defaultQty, sellQtyBtnHandler, false, Color.WHITE, "xfe-custom-button");
      sellButtonsPane.getChildren().add(sellButtons);

      if(isCM){
         bidOnPane.setVisible(false);
         offerOnPane.setVisible(false);
      }
   }


   void updateCurrentRow(ObservableReplyRow newRow, boolean isCM) {
      Fx.checkRunningThread(this,"Updating current workup row");
      removeBindings();
      this.isCM = isCM;
      this.row = newRow;
      workupPhaseLabel.textProperty().unbind();
      workupPriceLabel.textProperty().unbind();
      secCodeLabel.setText(row.getValue(AmpIcapSecBoardTrim2.secCode));
      workupPhaseLabel.textProperty().addListener(phaseListener);
      addBindings();
   }

   /**
    * Updates the quantity display values.
    *
    * @param buyTrdedQty  Total buy traded quantity in the workup session
    * @param buyBalQty    Total buy balance quantity in the workup session
    * @param sellTrdedQty Total sell traded quantity in the workup session
    * @param sellBalQty   Total sell balance quantity in the workup session
    * @param decimals     quantity decimals for the seccode
    */


   void updateQuantity(BigDecimal buyTrdedQty,
                       BigDecimal buyBalQty,
                       BigDecimal sellTrdedQty,
                       BigDecimal sellBalQty,
                       BigDecimal buyColleagueTrdedQty,
                       BigDecimal buyColleagueBalQty,
                       BigDecimal sellColleagueTrdedQty,
                       BigDecimal sellColleagueBalQty,
                       Integer decimals) {
      if (buyColleagueTrdedQty.doubleValue() > 0.00 ||
         buyColleagueBalQty.doubleValue() > 0.00 ||
         sellColleagueTrdedQty.doubleValue() > 0.00 ||
         sellColleagueBalQty.doubleValue() > 0.00) {
         if (!colleaguePane.isVisible()) {
            colleaguePane.setVisible(true);
            this.layout.readjustScrollHeight();
         }

         // update field values
         Fx.checkRunningThread(this,"Updating quantity for Workup");
         if (buyColleagueTrdedQty.doubleValue() == 0.00 && buyColleagueBalQty.doubleValue() == 0.00) {
            buyColleagueLabel.setText("");
         } else {
            buyColleagueLabel.setText(buyColleagueTrdedQty.stripTrailingZeros().toPlainString() + " / " + buyColleagueTrdedQty.add(buyColleagueBalQty).stripTrailingZeros().toPlainString());
         }

         if (sellColleagueTrdedQty.doubleValue() == 0.00 && sellColleagueBalQty.doubleValue() == 0.00) {
            sellColleagueLabel.setText("");
         } else {
            sellColleagueLabel.setText(sellColleagueTrdedQty.stripTrailingZeros().toPlainString() + " / " + sellColleagueTrdedQty.add(sellColleagueBalQty).stripTrailingZeros().toPlainString());
         }
      } else {
         buyColleagueLabel.setText("");
         sellColleagueLabel.setText("");
         colleaguePane.setVisible(false);
         this.layout.readjustScrollHeight();
      }

      if (buyTrdedQty.doubleValue() > tradedBuyQuantity.doubleValue() ||
         sellTrdedQty.doubleValue() > tradedSellQuantity.doubleValue()) {
         Platform.runLater(() -> layout.addFlash(this));
      }

      this.decimals = decimals == null ? 0 : decimals;
      this.tradedBuyQuantity = buyTrdedQty;
      this.balanceBuyQuantity = buyBalQty;

      if (buyTrdedQty.doubleValue() == 0.00 && buyBalQty.doubleValue() == 0.00) {
         buyLabel.setText("");
      } else {
         buyLabel.setText(buyTrdedQty.stripTrailingZeros().toPlainString() + " / " + buyTrdedQty.add(buyBalQty).stripTrailingZeros().toPlainString());
      }

      this.tradedSellQuantity = sellTrdedQty;
      this.balanceSellQuantity = sellBalQty;
      if (sellTrdedQty.doubleValue() == 0.00 && sellBalQty.doubleValue() == 0.00) {
         sellLabel.setText("");
      } else {
         sellLabel.setText(sellTrdedQty.stripTrailingZeros().toPlainString() + " / " + sellTrdedQty.add(sellBalQty).stripTrailingZeros().toPlainString());
      }

      final double defaultQty = getDefaultQuantity();
      buyButtons.updateButtonSizes(buyTrdedQty.add(buyBalQty).doubleValue(), defaultQty);
      sellButtons.updateButtonSizes(sellTrdedQty.add(sellBalQty).doubleValue(), defaultQty);

      // update total buy/sell label
      String totalBuySellStr = " You ";

      if (buyTrdedQty != null && sellTrdedQty != null) {
         if (buyTrdedQty.doubleValue() > sellTrdedQty.doubleValue()) {
            double totalBuySize = buyTrdedQty.doubleValue() - sellTrdedQty.doubleValue();
            totalBuySellStr += "Buy " + Util.sizeFormatter.format(totalBuySize);
         } else {
            double totalSellSize = sellTrdedQty.doubleValue() - buyTrdedQty.doubleValue();
            totalBuySellStr += "Sell " + Util.sizeFormatter.format(totalSellSize);
         }
      } else if (buyTrdedQty != null) {
         totalBuySellStr += "Buy " + Util.sizeFormatter.format(buyTrdedQty.doubleValue());
      } else if (sellTrdedQty != null) {
         totalBuySellStr += "Sell " + Util.sizeFormatter.format(sellTrdedQty.doubleValue());
      } else {
         totalBuySellStr = "";
      }

      if(boughtSoldTotalLabel!= null) // This item is not part of FXML. Adding null check to avoid null pointer
         boughtSoldTotalLabel.setText(totalBuySellStr);
   }

   boolean colleaguesDetailsVisible() {
      return colleaguePane.isVisible();
   }

   double getRowHeight() {
      return WORKUP_ROW_HEIGHT;
   }

   /**
    * Gets the defualt quantity for the row. If there is not default quantity set then fetches from configuration module.
    *
    * @return Default quantity value.
    */
   private Double getDefaultQuantity() {
      Double defaultQty = row.getValue(AmpIcapSecBoardTrim2.defaultQty_d);
      if (defaultQty == null) {
         final Integer secClassId = row.getValue(AmpIcapSecBoardTrim2.secClassId);
         defaultQty = layout.getDefaultQuantity(secClassId);
      }
      return defaultQty;
   }

   private void removeBindings(){
      workupPhaseLabel.textProperty().removeListener(phaseListener);
      if(row!=null){
         row.getProperty(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime).removeListener(endTimeListener);
      }
   }
   private void addBindings() {
      final StringBinding priceBinding = new StringBinding() {
         {
            super.bind(row.getProperty(AmpIcapSecBoardTrim2.workupPrice));
         }

         @Override
         protected String computeValue() {
            Fx.checkRunningThread(this, "AmpIcapSecBoardTrim2.workupPrice Binding called");
            if (isValidPhase()) {
               BigDecimal workupPrice = row.getValue(AmpIcapSecBoardTrim2.workupPrice);
               if (priceFormatter != null) {
                  return priceFormatter.apply(workupPrice);
               } else {
                  return xstr.util.Util.getDefaultFormatter().apply(workupPrice);
               }
            }
            return "";
         }
      };

    final StringBinding phaseBinding =
        new StringBinding() {
          {
            super.bind(row.getProperty(AmpIcapSecBoardTrim2.sessionName));
          }

          @Override
          protected String computeValue() {
            final String phase = row.getValue(AmpIcapSecBoardTrim2.sessionName);
            Fx.checkRunningThread(this, "AmpIcapSecBoardTrim2.sessionName Binding called");
            if (isValidPhase()) {
              return PUBLIC_SESSION.equals(phase) ? "PUB" : PRIVATE_SESSION.equals(phase) ? "PRI" : phase;
            } else {
              layout.removeRow(TradeWorkupRow.this);
              removeBindings();
              return phase;
            }
          }
        };
      workupPhaseLabel.textProperty().bind(phaseBinding);
      workupPriceLabel.textProperty().bind(priceBinding);

      // Adding listener and calling by default
      row.getProperty(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime).addListener(endTimeListener);
      if(row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime)!=null) {
         startTimer(row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime));
      }
   }

   private void startTimer(String endTimeString) {
      if (timeline.getStatus() == Animation.Status.RUNNING) {
         timeline.stop();
      }
      String time = endTimeString.substring(0, endTimeString.indexOf("."));
      try {
         Date endTime = END_TIME_FORMAT.parse(time);
         Date engineTime = layout.getEngineTime();
         progressbarPeriod = endTime.getTime() - engineTime.getTime();
         workupTimerLabel.setText(progressbarPeriod.toString());
         workupSeconds = progressbarPeriod.doubleValue();
         updateProgressBar();

         timeline.playFromStart();
      } catch (ParseException e) {
         e.printStackTrace();
      }
   }

   public ObservableReplyRow getRow() {
      return row;
   }

   public VBox getRoot() {
      return root;
   }

   Node getWorkupBox() {
      return workupbox;
   }

   private boolean isValidPhase() {
      final String phase = row.getValue(AmpIcapSecBoardTrim2.sessionName);
      logger.debug("{} row session is {}", row.getKey().toString(), phase);
      return PUBLIC_SESSION.equals(phase) || PRIVATE_SESSION.equals(phase);
   }

   public void setPriceFormatter(Function<Number, String> priceFormatter) {
      this.priceFormatter = priceFormatter;
   }


   public void cleanUp() {
      removeBindings();
      timeline.stop();
   }
}
