package xfe.icap.modules.rfq;

import com.nomx.persist.PersistantName;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import xfe.icap.amp.AmpRfq;
import xstr.session.ObservableReplyRow;
import xstr.util.Fun0;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Future;
import xfe.icap.XfeSession;
import xfe.layout.LayoutManager;
import xfe.icap.modules.settings.ConfigurationModule;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.LongConsumer;

public class RfqNotification extends DisposableBase {

   /*
    * where FFF is the initiator's firm, SSS is the seccode, TTT is buy/sell/buy or sell and SSS is the size of the RFQ.
    * Eg �DEUT: Request for bids on A-AUD 10Y for 10m�. If the RFQ is anonymous then the firm will be blank.
    */
   private static final String INFO_FORMAT_PUBLIC = "%s: Request for %s on %s for %sm";
   private static final String INFO_FORMAT_ANONYMOUS = "Request for %s on %s for %sm";

   {
      listener = new ListChangeListener<ObservableReplyRow>() {

         @Override
         public void onChanged(Change<? extends ObservableReplyRow> change) {
            BooleanProperty notificationProp = configurationModule.getParametersStorage().get(PersistantName.rfqNotification, false);
            while (change.next()) if (change.wasAdded()) {
               List<? extends ObservableReplyRow> added = change.getAddedSubList();
               for (ObservableReplyRow row : added) {
                  long expiryTime = row.getValue(AmpRfq.endTime).getTime();
                  if (!RfqModule.isRfsSession(row)) {
                     startTabFlashClbk.accept(expiryTime);
                  }

                  // The requirement says:
                  // "if the logged-in user belongs to one of the invited marketmaker firms for that RFQ,
                  // then popup the rfqNofication."
                  // The TE does work for the XFE, if the logged-trader receives the RFQ,
                  // which means the trader IS one of the invited marketmaker.

                  if (notificationProp.get()) {
                     String initiator = row.getString(AmpRfq.userId);
                     if (xfeSession.getUnderlyingSession().getLoggedOnUserId().equals(initiator)) {
                        continue;
                     }

                     String info;
                     boolean isAnonymous = row.getValue(AmpRfq.isAnonymous);
                     String secCode = row.getString(AmpRfq.parentSecCode);
                     double quantity = row.getValue(AmpRfq.maxQuantity);
                     int buysellV = row.getValue(AmpRfq.buySell);
                     String buySell;
                     if (buysellV == AmpOrderVerb.buy) {
                        buySell = "Offer";
                     } else if (buysellV == AmpOrderVerb.sell) {
                        buySell = "Bid";
                     } else {
                        buySell = "Offer/Bid";
                     }

                     if (isAnonymous) {
                        info = String.format(INFO_FORMAT_ANONYMOUS, buySell, secCode, quantity);
                     } else {
                        String initiatorFirmId = row.getString(AmpRfq.groupId);
                        info = String.format(INFO_FORMAT_PUBLIC, initiatorFirmId, buySell, secCode, quantity);
                     }

                     myObservableList.add(new NotificationInfo(row.getValue(AmpRfq.rfqNo), expiryTime, info, rfqNumber -> {
                        myObservableList.removeIf(notificationInfo -> Objects.equals(notificationInfo.getRfqNumber(), rfqNumber));

                        if (xfeSession.getEntryModule() != null)
                           xfeSession.getEntryModule().get().rateEditorNeedFocused.set(true);

                        selectRfqClbk.accept(secCode);

                     }, RfqNotification.this::cancelRfq));
                  }
               }
            } else if (change.wasRemoved()) {
               for (ObservableReplyRow row : change.getRemoved()) {
                  Long rfqNumber = row.getValue(AmpRfq.rfqNo);
                  myObservableList.removeIf(notificationInfo -> Objects.equals(notificationInfo.getRfqNumber(), rfqNumber));
               }
            }
         }
      };
   }

   public RfqNotification(XfeSession xfeSession,
                          ConfigurationModule settingsModule,
                          LayoutManager<Node> layoutManager,
                          Consumer<String> selectRfqClbk,
                          LongConsumer startTabFlashClbk,
                          Runnable stopTabFlashClbk) {
      super();
      this.xfeSession = xfeSession;
      this.configurationModule = settingsModule;
      this.selectRfqClbk = selectRfqClbk;
      this.startTabFlashClbk = startTabFlashClbk;
      this.stopTabFlashClbk = stopTabFlashClbk;
      activeRfqs = xfeSession.rfqs.get().activeRfqs.get();
      activeRfqs.addListener(listener);

      myObservableList.addListener((Observable observable) -> {
         if (myObservableList.isEmpty()) {
            if (pane != null) {
               layoutManager.unregister(pane.getStage());
               pane.close();
               pane = null;
            }
         } else {
            if (pane == null) {
               pane = new RfqNotificationPane(myObservableList, () -> {
                  myObservableList.clear();
                  return Future.valueOf(true);
               }, "RFQ Notification");
               pane.setPosition(settingsModule.getData().rfqNotificationPosXProperty().get(),
                  settingsModule.getData().rfqNotificationPosYProperty().get());

               pane.posX().addListener((obs, oldValue, newValue) -> {
                  if (settingsModule.getData() != null) {
                     settingsModule.getData().rfqNotificationPosXProperty().set(newValue.doubleValue());
                  }
               });

               pane.posY().addListener((obs, oldValue, newValue) -> {
                  if (settingsModule.getData() != null) {
                     settingsModule.getData().rfqNotificationPosYProperty().set(newValue.doubleValue());
                  }
               });

               layoutManager.register(pane.getStage(),pane.getAppContainer());
            }
         }
      });
   }

   protected Future<Void> dispose(boolean disposing) {
      myObservableList.clear();
      activeRfqs.removeListener(listener);

      return Future.SUCCESS;
   }

   private void cancelRfq(Long rfqNumber) {
      // We need to remove the notification line for this RFQ and if it
      // is the last one close the dialog.
      myObservableList.removeIf(notificationInfo -> Objects.equals(notificationInfo.getRfqNumber(), rfqNumber));

      // Since the user seems to be aware of having RFQs we can just stop the flashing
      stopTabFlashClbk.run();
   }

   private final XfeSession xfeSession;
   private final ConfigurationModule configurationModule;
   private final ObservableList<ObservableReplyRow> activeRfqs;
   private final Consumer<String> selectRfqClbk;
   private final LongConsumer startTabFlashClbk;
   private final Runnable stopTabFlashClbk;
   private final ObservableList<NotificationInfo> myObservableList = FXCollections.observableArrayList();
   private final ListChangeListener<ObservableReplyRow> listener;
   private RfqNotificationPane pane;
}

