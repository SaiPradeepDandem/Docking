package xfe.icap.modules.hittake;

import org.controlsfx.control.PopOver;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.ordersdata.OrderEntryData;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.types.Orders;
import xfe.module.Module;
import xfe.modules.actions.PopupOrderEntryArgs;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.popover.XfePopOver;
import xfe.util.EasyFXML;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;

@Module.Autostart
public class HitTakeModule extends SessionScopeModule {
   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @ModuleDependency
   public SecTabsUIModule secTabsUIModule;

   @Override
   public Future<Void> startModule() {
      secTabsUIModule.setHitTakeOrderHandler(this::showHitTake);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      secTabsUIModule.setHitTakeOrderHandler(null);
      return Future.SUCCESS;
   }

   private void showHitTake(PopupOrderEntryArgs popupOrderEntryArgs) {
      ObservableReplyRow row = popupOrderEntryArgs.getRow();
      String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);

      // If this is a gilts spread we need to negate the price
      boolean priceReversal = securitiesDataModule.isSpreadForPriceReversal(row);
      BigDecimal price = popupOrderEntryArgs.getSide() == OrderSide.BUY ?
         row.getValue(AmpIcapSecBoardTrim2.bidPrice) :
         row.getValue(AmpIcapSecBoardTrim2.offerPrice);

      if (priceReversal) price = price.negate();

      BigDecimal quantity = row.getValue(AmpIcapSecBoardTrim2.defaultQty);
      if (quantity == null) {
         quantity = BigDecimal.valueOf(getDefaultQtyBySecClassId(row.getValue(AmpIcapSecBoardTrim2.secClassId)));
      }

      OrderEntryData orderEntryData = new OrderEntryData();
      orderEntryData.setSecCode(secCode);
      orderEntryData.setBoardId(boardId);
      orderEntryData.setSide(popupOrderEntryArgs.getSide());
      orderEntryData.setPrice(price);
      orderEntryData.setIsAllOrNone(false);
      orderEntryData.setIsIceberg(false);
      orderEntryData.setBalance(BigDecimal.ZERO);
      orderEntryData.setQty(quantity);
      orderEntryData.setActionOnLogoff(configurationModule.getData().onLogoffActionProperty().get());
      orderEntryData.setIsShared(configurationModule.getData().sharedOrdersProperty().get());
      orderEntryData.setIsTopcut(configurationModule.getData().topCutProperty().get());
      orderEntryData.setIsDark(false);
      orderEntryData.setIsPriceReversal(securitiesDataModule.isSpreadForPriceReversal(row));
      if(configurationModule.getData().yoursMineOrderWithdrawProperty().get()){
         orderEntryData.setOrderTag(Orders.CLOB);
      } else {
         orderEntryData.setOrderTag(Orders.AGGRESSOR);
      }
      HitTakePane pane = EasyFXML.load(HitTakePane.class);
      pane.setup(orderEntryData);
      activeSessionModule.getSession().ifPresent(pane::setSession);
      pane.setCloseHandler(midiLayoutModule::closePopOverWindow);

      final XfePopOver popOver = XfePopOver.instance(midiLayoutModule);
      popOver.setArrowLocation(PopOver.ArrowLocation.TOP_CENTER);
      pane.setPopover(popOver);
      popOver.setHeaderAlwaysVisible(true);
      popOver.setContentNode(pane.getRoot());
      popOver.setTitle(secCode.replaceFirst("(UKT )*", ""));
      midiLayoutModule.closePopOverWindow(XfePopOver.ID_PREFIX + popOver.getTitle());
      popOver.showSafely(popupOrderEntryArgs.getNode());
   }

   private Double getDefaultQtyBySecClassId(Integer secClassId) {
      return midiLayoutModule.getDefaultQuantity(secClassId);
   }
}
