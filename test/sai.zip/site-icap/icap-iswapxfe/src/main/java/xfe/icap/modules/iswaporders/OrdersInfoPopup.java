package xfe.icap.modules.iswaporders;

import xfe.icap.types.ManagedOrder;
import xstr.types.OrderSide;
import xfe.util.Constants;
import xstr.util.ListenerTracker;
import xstr.util.collection.ObservableCollections;
import xfe.util.scene.control.EnhancedTableView;
import xfe.util.scene.control.InfoPopup;
import xfe.icap.amp.AmpManagedOrder;
import xstr.session.ObservableReplyRow;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public final class OrdersInfoPopup extends InfoPopup implements Constants{

	private static final Logger logger = LoggerFactory.getLogger(OrdersInfoPopup.class);


	private ObservableList<ObservableReplyRow> infoRows;

	public OrdersInfoPopup(
			  Node node,
			  ObservableReplyRow row,
			  OrdersColumns columns,
			  ObservableBooleanValue showing, ListenerTracker tracker,
           boolean isBroker) {
		super(node, showing, false);

		contentProperty().bind(new ObjectBinding<Region>() {
			{ bind(detachedProperty()); }
			@Override
			protected Region computeValue() {
				boolean detached = detachedProperty().get();
				TableView<ObservableReplyRow> tableView;
            tableView = createTableView(detached, columns,row,tracker,isBroker);
            VBox vbox = createDecorationPaneAttached(detached, tableView, row);
				vbox.getChildren().add(0, createDraggableHeaderPane("Order Info"));
				return vbox;
			}});
	}

	private static VBox createDecorationPaneAttached(boolean detached, TableView<ObservableReplyRow> asnTableView, ObservableReplyRow row) {
		if (detached)
			asnTableView.getStyleClass().add("detached");

		GridPane gridPane = new GridPane();
      gridPane.getStyleClass().add("xfe-info-grid");
      ColumnConstraints columnOne = new ColumnConstraints();
      columnOne.setHgrow(Priority.ALWAYS);
      ColumnConstraints columnTwo = new ColumnConstraints();
      columnTwo.setPrefWidth(10);
      gridPane.getColumnConstraints().add(columnOne);
      gridPane.getColumnConstraints().add(columnTwo);
		Label infoLabel = new Label();
		if (detached)
			infoLabel.getStyleClass().add("xfe-grid-instrument-label");

		String instrument = "";
		OrderSide orderSide = OrderSide.SELL;
		ObservableObjectValue<String> quantity = null;
		ObservableObjectValue<String> rate = null;

      ManagedOrder order = new ManagedOrder(row);
      instrument = order.getSecCode();
      orderSide = order.isBid() ? OrderSide.BUY : OrderSide.SELL;
      quantity = row.getStringProperty(AmpManagedOrder.quantity_d);
      rate = row.getStringProperty(AmpManagedOrder.price);

      infoLabel.setText(instrument);
		gridPane.add(infoLabel, 0, 0);

		Label rateLabel = createLabel(detached,orderSide);
		if (rate != null)
			rateLabel.textProperty().bind(rate);

		Label qtyLabel = createLabel(detached,orderSide);
		if (quantity != null)
			qtyLabel.textProperty().bind(quantity);
		Label sideLabel = new Label(orderSide == OrderSide.BUY ? "BID " : "OFFER ");
		Label qty = new Label("QTY");
		if (!detached){
		   sideLabel.getStyleClass().add("xfe-label");
		   qty.getStyleClass().add("xfe-label");
		}

		gridPane.add(new Pane(), 1, 0);
      gridPane.add(new HBox(){{this.getChildren().addAll(sideLabel,rateLabel);}}, 2, 0);
      gridPane.setHgap(10);
		gridPane.add(new HBox(){{this.getChildren().addAll(qty,qtyLabel);}}, 3, 0);
		VBox infoContent = new VBox();
		if (!detached) {
			infoContent.getChildren().setAll(gridPane, asnTableView);
			infoContent.getStyleClass().add("xfe-info-content");
		} else {
			infoContent.getStyleClass().add("xfe-info-detached-content");
			infoContent.getChildren().setAll(new StackPane(){{this.getStyleClass().add("detached-grid-wrapper");this.getChildren().add(gridPane);}},
                 new StackPane(){{this.getStyleClass().add("detached-table-wrapper");this.getChildren().add(asnTableView);}});
		}

      VBox rtnVBox = new VBox();
      rtnVBox.getStyleClass().add(!detached ? "xfe-info-decoration" : "xfe-info-detached-decoration");
      rtnVBox.getChildren().add(infoContent);
      return rtnVBox;
	}

	private static Label createLabel(boolean detached, OrderSide orderSide) {
      Label labelData = new Label();
      if (!detached)
         labelData.getStyleClass().add("xfe-label-data");
      else
         labelData.getStyleClass().add(orderSide == OrderSide.BUY ? BUY_STYLE : SELL_STYLE);
      return labelData;
   }

   @SuppressWarnings("unchecked")
	private TableView<ObservableReplyRow> createTableView(boolean detached, OrdersColumns columns, ObservableReplyRow row, ListenerTracker tracker, boolean isBroker) {
		return new EnhancedTableView<ObservableReplyRow>() {{
			List<TableColumn<ObservableReplyRow,?>> cols = new ArrayList<>(6);
         cols.add(columns.createMinFillPopupColumn());
         cols.add(columns.createBrokerAnonPopupColumn());
         if(isBroker){
            cols.add(OrdersColumns.createTraderColumn());
         }
         cols.add(columns.createSharedPopupColumn());
         cols.add(columns.createIcebergPopupColumn());
         cols.add(columns.createEditorPopupColumn());

         infoRows = FXCollections.observableArrayList();
			infoRows.add(row);
			ObservableList<ObservableReplyRow> aliveOrdersView = ObservableCollections.filter(infoRows, OrderFilters.canWithdraw,tracker);
			aliveOrdersView.addListener((InvalidationListener) arg0 -> {
            if (aliveOrdersView.isEmpty())
               hide();
         });

			this.getColumns().setAll(cols);
			this.setItems(aliveOrdersView);
			this.getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
		}};
	}
}
