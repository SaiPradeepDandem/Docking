package xfe.icap.ui;

import xfe.util.Util;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableBooleanValue;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import xstr.util.XfeVersionInfo;
import xfe.util.scene.control.InfoPopup;
import xfe.util.Constants;

public class AboutInfoPopup extends InfoPopup implements Constants{
	private String hotline = EUR_HOTLINE;
	private String email = EUR_SUPPORT_EMAIL;

public AboutInfoPopup(
		 String site,
         Node node,
         ObservableBooleanValue showing) {
      super(node, showing, false);

      if (site != null) {
	      if (site.toLowerCase().endsWith("au")) {
	    	  hotline = AU_HOTLINE;
	    	  email = AU_SUPPORT_EMAIL;
	      } else if (site.toLowerCase().endsWith("eur")) {
	    	  hotline = EUR_HOTLINE;
	    	  email = EUR_SUPPORT_EMAIL;
	      } else if (site.toLowerCase().endsWith("us")) {
	    	  hotline = US_HOTLINE;
	    	  email = US_SUPPORT_EMAIL;
	      }
      }

      contentProperty().bind(new ObjectBinding<Region>() {
         { bind(detachedProperty()); }

         @Override
         protected Region computeValue() {
            boolean detached = detachedProperty().get();
            Pane infoContent = new Pane() {{
               this.getStyleClass().add("xfe-info-content-border");
               this.getChildren().addAll(
                     new VBox() {{
                        this.getStyleClass().add("xfe-info-content");
                        this.getChildren().addAll(
                              new HBox() {{
                                 this.getStyleClass().add("xfe-info-row");
                                 this.getChildren().add(new Label("Version: "));
                                 this.getChildren().add(new TextField(XfeVersionInfo.getProjectVersion()) {{
                                    HBox.setHgrow(this, Priority.ALWAYS);
                                    this.setEditable(false);
                                    this.getStyleClass().add("xfe-info-textfield");
                                 }});
                              }},
                              new HBox() {{
                                 this.getStyleClass().add("xfe-info-row");
                                 this.getChildren().add(new Label("i-Swap hotline: "));
                                 this.getChildren().add(new TextField(hotline) {{
                                    HBox.setHgrow(this, Priority.ALWAYS);
                                    this.setEditable(false);
                                    this.getStyleClass().add("xfe-info-textfield");
                                 }});
                              }},
                              new HBox() {{
                                 this.getStyleClass().add("xfe-info-row");
                                 this.getChildren().add(new Label("Email support: "));
                                 this.getChildren().add(new Label(email) {{
                                    this.getStyleClass().add("xfe-info-link");
                                    this.setCursor(Cursor.HAND);
                                    this.setOnMouseClicked(mouseEvent -> {
                                       String version = "v" + XfeVersionInfo.getProjectVersion();
                                       String subject = "[i-Swap XFE " + version + "] ";
                                       String body = "Dear iSwap support,\n\n";
                                       String mailToString = "mailto:"+ email + uriParam("subject", subject) + uriParam("body", body);
                                       Util.browser(mailToString);
                                    });
                                 }});
                              }});
                     }});
            }};

            VBox retVal = new VBox();
            retVal.getStyleClass().add(!detached ? "xfe-info-decoration" : "xfe-info-detached-decoration");
            retVal.getChildren().addAll(createDraggableHeaderPane("About i-Swap XFE"), infoContent);

            return retVal;
         }
      });
   }

   private static String escapeUri(String text) {
      return text.replaceAll(" ", "%20").replaceAll("\n", "%0a");
   }

   private static String uriParam(String name, String text) {
      return "&" + name + "=" + escapeUri(text);
   }
}
