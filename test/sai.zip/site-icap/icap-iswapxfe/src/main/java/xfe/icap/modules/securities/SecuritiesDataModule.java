package xfe.icap.modules.securities;

import com.omxgroup.xstream.amp.AmpSecClassId;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import xfe.amp.AmpBoard;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.types.StepArrayLoader;
import xfe.icap.types.StepArrays;
import xfe.module.Module;
import xfe.module.ModuleException;
import xfe.module.SiteModule;
import xfe.modules.session.SessionScopeModule;
import xfe.types.SecBoardStaticInfo;
import xfe.types.SecBoards;
import xstr.amp.AMP;
import xstr.session.*;
import xstr.util.FeedAggregator;
import xstr.util.Lazy;
import xstr.util.Resetter;
import xstr.util.concurrent.Future;

import java.text.ParseException;
import java.util.*;
import java.util.function.Function;

import static xfe.icap.modules.tradesworkup.WorkupConstants.*;

@Module.Autostart
public class SecuritiesDataModule extends SessionScopeModule {
   @ModuleDependency
   public SiteModule siteModule;

   private Map<String, WorkupData> secCodeWorkupEndTimeMap;
   private Map<String, ChangeListener<String>> secCodeEndTimeListenerMap;
   private Map<String, ChangeListener<String>> secCodeSessionNameListenerMap;

   private ListChangeListener<ObservableReplyRow> watchListItemsListener = p -> {
      while (p.next()) {
         if (p.wasAdded()) {
            p.getAddedSubList().forEach(this::addWorkupListeners);
         }
      }
   };

   @Override
   public Future<Void> startModule() throws ModuleException {
      if (!activeSessionModule.getSession().isPresent()) {
         throw new ModuleException("Unable to start Instruments Module - No valid session available");
      }

      secCodeWorkupEndTimeMap = new HashMap<>();
      secCodeEndTimeListenerMap = new HashMap<>();
      secCodeSessionNameListenerMap = new HashMap<>();

      FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpBoard.rep, new ObservableReplyRow.ObservableRowFactory());
      activeSessionModule.getSession().ifPresent((session) -> {
         QueryFeed srcFeed = session.getFeedSource(AmpBoard.req);
         srcFeed.addListener(aggregator);
      });
      boards = aggregator.items;

      ServerSession session = activeSessionModule.getSession().get();
      StepArrayLoader loader = new StepArrayLoader(session);
      Function<Integer, Boolean> showSpreadPreFix = new Function<Integer, Boolean>() {
         @Override
         public String toString() {
            return "securitiesDataModule.showSpreadPreFix";
         }

         @Override
         public Boolean apply(Integer secClassId) {
            return (siteModule.showSpreadPlus() && isSpread(secClassId));
         }
      };
      return loader.getPriceArrayMap().flatMap(priceArray -> loader.getQtyArrayMap().flatMap(qtyArray -> {
         this.secboards = new SecBoards(session, priceArray, qtyArray, showSpreadPreFix);
         return secboards.ready().map(r -> null);
      }));
   }

   /**
    * Stops polling and cleans the provided watchList.
    *
    * @param watchList
    */
   public void stopAndCleanWatchList(SecurityWatchlist watchList) {
      watchList.stopPolling();
      final ObservableList<ObservableReplyRow> watchListItems = watchList.getItems();
      watchListItems.removeListener(watchListItemsListener);
      watchListItems.forEach(row -> {
         final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         row.getProperty(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime).removeListener(secCodeEndTimeListenerMap.get(secCode));
         row.getProperty(AmpIcapSecBoardTrim2.sessionName).removeListener(secCodeSessionNameListenerMap.get(secCode));
      });
      watchList.cleanUp();
   }

   @Override
   public Future<Void> stopModule() {
      secCodeWorkupEndTimeMap.clear();
      secCodeWorkupEndTimeMap = null;

      secCodeEndTimeListenerMap.clear();
      secCodeEndTimeListenerMap = null;

      secCodeSessionNameListenerMap.clear();
      secCodeSessionNameListenerMap = null;

      this.secboards.dispose();
      this.secboards = null;
      this.boards = null;
      return Future.SUCCESS;
   }

   public SecurityWatchlist createWatchlist(String parentModule) {
      final SecurityWatchlist watchList = new SecurityWatchlist(secboards, activeSessionModule.getSession().get(), parentModule);
      
      /* Add listeners for tracking the workup endTime of each secCode */
      final ObservableList<ObservableReplyRow> watchListItems = watchList.getItems();
      watchListItems.forEach(this::addWorkupListeners);
      watchListItems.addListener(watchListItemsListener);
      return watchList;
   }

   /**
    * Returns the end time of the workup for the provided secCode.
    *
    * @param secCode
    * @return End time of the workup
    */
   public Date getWorkupEndTime(String secCode) {
      final WorkupData workupData = secCodeWorkupEndTimeMap.get(secCode);
      if (workupData != null && workupData.getPhase() != null && PUBLIC_SESSION.equals(workupData.getPhase())) {
         return workupData.getEndTime();
      }
      return null;
   }

   public Future<SecBoardStaticInfo> getStaticInfo(String secCode, String boardId) {
      return secboards.getStatics(secCode, boardId);
   }

   public SecBoardStaticInfo getStaticInfo(ObservableReplyRow row) {
      return secboards.getStatics(row);
   }

   public SecBoards getSecboards() {
      return secboards;
   }

   public ObservableList<ObservableReplyRow> getBoards() {
      return boards;
   }

   private SecBoards secboards;
   private final Resetter resetter = new Resetter();

   public Lazy<StepArrays> getStepArrays() {
      return stepArrays;
   }

   private final Lazy<StepArrays> stepArrays = resetter.resets(new Lazy<StepArrays>() {
      @Override
      protected StepArrays initialize() {
         return new StepArrays(secboards);
      }
   });

   public boolean isSpreadForPriceReversal(ObservableReplyRow row) {
      return Boolean.TRUE.equals(row.getValue(AmpIcapSecBoardTrim2.doPriceReversal));
   }

   /**
    * Adds listeners to the prvlgdTrdngEndTime & sessionName of AmpIcapSecBoardTrim2, to track the workup end time of each secCode.
    *
    * @param row AmpIcapSecBoardTrim2 row object
    */
   private void addWorkupListeners(ObservableReplyRow row) {
      final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);

      updateWorkupEndTime(secCode, row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime));
      final ChangeListener<String> endTimeListener = (obs, old, endTimeStr) -> updateWorkupEndTime(secCode, endTimeStr);
      row.getProperty(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime).addListener(endTimeListener);
      secCodeEndTimeListenerMap.put(secCode, endTimeListener);

      updateWorkupPhase(secCode, row.getValue(AmpIcapSecBoardTrim2.sessionName));
      final ChangeListener<String> sessionNameListener = (obs, old, sessionName) -> updateWorkupPhase(secCode, sessionName);
      row.getProperty(AmpIcapSecBoardTrim2.sessionName).addListener(sessionNameListener);
      secCodeSessionNameListenerMap.put(secCode, sessionNameListener);
   }

   /**
    * Updates the map with the provided workup endTime of the provided secCode.
    *
    * @param secCode    SecCode
    * @param endTimeStr String value of end time
    */
   private void updateWorkupEndTime(String secCode, String endTimeStr) {
      if (endTimeStr != null && !endTimeStr.isEmpty()) {
         Date endTime = parseDate(endTimeStr);
         if (endTime != null) {
            WorkupData workupData = secCodeWorkupEndTimeMap.get(secCode);
            if (workupData == null) {
               secCodeWorkupEndTimeMap.put(secCode, new WorkupData(endTime));
            } else {
               workupData.setEndTime(endTime);
            }
         }
      }
   }

   /**
    * Updates the map when the provided workup session name is 'Public' for the provided secCode.
    *
    * @param secCode     SecCode
    * @param sessionName String value session name
    */
   private void updateWorkupPhase(String secCode, String sessionName) {
      if (sessionName != null && !sessionName.isEmpty() && PUBLIC_SESSION.equals(sessionName)) {
         WorkupData workupData = secCodeWorkupEndTimeMap.get(secCode);
         if (workupData == null) {
            secCodeWorkupEndTimeMap.put(secCode, new WorkupData(sessionName));
         } else {
            workupData.setPhase(sessionName);
         }
      }
   }

   private Date parseDate(String val) {
      try {
         return END_TIME_FORMAT.parse(val);
      } catch (ParseException e) {
         e.printStackTrace();
      }
      return null;
   }

   // This Method only for external access and getting changeable data in intra-day.
   // Please do not use in SecuritiesDataModule class.
   // If this one needs to use, just implement inside usage class, do not implement new method of SecuritiesDataModule
   public Future<QueryReplyRow> retrieveSecBoardTrim2(String secCode) {
      return getSecboards().getFirstBySecCode(secCode).flatMap(secBoard -> {
         ServerSession session = activeSessionModule.getSession().get();
         Long[] sortedIndexArray = {secBoard.getIndex()};
         XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req, session)
            .set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), sortedIndexArray)
            .build();
         return session.querySingleRow(req);
      });
   }

   private boolean isSpread(Integer secClassId) {
      return secClassId != null && secClassId == AmpSecClassId.strategy;
   }

   private ObservableList<ObservableReplyRow> boards;
}
