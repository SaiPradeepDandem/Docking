package xfe.icap.modules.actionsui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.layout.FxAbstractLayout;
import xfe.module.Module;
import xfe.modules.actionsui.ActionButton;
import xfe.modules.session.SessionScopeModule;
import xfe.types.UiSession;
import xfe.ui.control.IconButton;
import xfe.util.XfeAction;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.Future;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

@Module.Autostart
public class ActionsUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(ActionsUIModule.class);

   @ModuleDependency
   public UiSession xfeSessionModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;

   public static final int MAX_NUM_ACTIONS = 12;
   public static final int BUTTON_WIDTH = 20;
   public static final int BUTTON_HEIGHT = 44;

   private void setBtnProperties(ButtonBase btn) {
      btn.setPrefWidth(BUTTON_WIDTH);
      btn.setPrefHeight(BUTTON_HEIGHT);
      btn.setMaxWidth(1000);
      btn.setMaxHeight(1000);
      btn.setMinWidth(BUTTON_WIDTH);
      btn.setMinHeight(BUTTON_HEIGHT);
      List<String> styles = btn.getStyleClass();
      if(!styles.contains(ActionButton.NORMAL_STYLE)) {
         styles.add(ActionButton.NORMAL_STYLE);
      }
   }

   @Override
   public Future<Void> startModule() {
      actionButtons = FXCollections.observableList(Arrays.asList(new Node[MAX_NUM_ACTIONS]));
      actionsPane = new ToolBar();

      actionsPane.setId("xfe-actions-view");
      actionsPane.getStyleClass().add("xfe-actions-bar");
      actionsPane.setMaxHeight(Region.USE_PREF_SIZE);

      for (int i = 0; i < MAX_NUM_ACTIONS; ++i) {
         if (actionButtons.get(i) == null) {
            actionButtons.set(i, createActionButton());
         }
      }

      actionsPane.getItems().addAll(actionButtons);
      actionButtons = actionsPane.getItems();

      showMyself();

      tracker.addListener(configurationModule.getData().displayActionsProperty(), arg0 -> {
         showMyself();
      });
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();

      if (actionsPane != null) {
         layoutModule.removeView(actionsPane);
         actionButtons.clear();
         actionToBtnIdx.clear();
      }
      actionButtons = null;
      actionsPane = null;
      return Future.SUCCESS;
   }

   public boolean removeAction(XfeAction action) {
      Integer index = actionToBtnIdx.get(action);
      if (index != null) {
         actionToBtnIdx.remove(action);
         actionButtons.set(index, createActionButton());
         return true;
      }
      return false;
   }

   public void addAction(int index, XfeAction action) {

      if (actionToBtnIdx.containsValue(index)) {
         XfeAction oldAction = null;
         for (Entry<XfeAction, Integer> e : actionToBtnIdx.entrySet()) {
            if (index == e.getValue()) {
               oldAction = e.getKey();
               break;
            }}
         logger.error(String.format("Button in index %d is already used for %s", index, oldAction));
      }

      if (index < 0 || index >= MAX_NUM_ACTIONS)
         throw new ArrayIndexOutOfBoundsException(index);

      if (action == null)
         throw new IllegalArgumentException("Action object cannot be null");

      actionToBtnIdx.put(action, index);

      if (actionButtons.get(index) == null) {
         actionButtons.set(index, createActionButton());
      }

      Button button = (Button)actionButtons.get(index);
      action.bindTo(button);
      HBox.setHgrow(button, Priority.ALWAYS);

      tracker.registerRollbackAction(new Runnable() {
         @Override
         public void run() {
            XfeAction action = actionRef.get();
            if (action != null)
               removeAction(action);
         }
         final WeakReference<XfeAction> actionRef = new WeakReference<>(action);
      });
   }

   /**
    * Add any custom button to actions panel
    * @param index between 0 and 11  (11 actions capacity)
    * @param btn the button to add
    */
   public void addCustomButton(int index, ButtonBase btn) {
      if (index < 0 || index >= MAX_NUM_ACTIONS) {
         throw new IndexOutOfBoundsException();
      }
      setBtnProperties(btn);
      actionButtons.set(index, btn);
   }

   private void showMyself() {
      if (actionsPane != null) {
         if (configurationModule.getData().displayActionsProperty().get())
            layoutModule.addView(actionsPane);
         else
            layoutModule.removeView(actionsPane);
      }
   }

   private Button createActionButton() {
      IconButton b = new IconButton();
      setBtnProperties(b);
      return b;
   }
   private final HashMap<XfeAction, Integer> actionToBtnIdx =  new HashMap<>();
   private final ListenerTracker tracker = new ListenerTracker();
   private ObservableList<Node> actionButtons;
   private ToolBar actionsPane;
}
