package xfe.icap.modules.mmgroupview;

import javafx.scene.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.settingsview.SettingsViewTab;
import xfe.icap.modules.settingsview.SettingsViewModule;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.util.EasyFXML;
import xstr.util.concurrent.Future;

@Module.Autostart
public class MMGroupViewModule extends SessionScopeModule implements SettingsViewTab {
   private static final Logger logger = LoggerFactory.getLogger(MMGroupViewModule.class);

   @ModuleDependency
   public SettingsViewModule settingsViewModule;

   @Override
   public Future<Void> startModule() {
      this.mmGroupLayout = EasyFXML.load(MMGroupLayout.class);
      settingsViewModule.addView(getRoot(),this);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      settingsViewModule.removeView(getRoot(), this);
      return Future.SUCCESS;
   }

   public Node getRoot(){
      return this.mmGroupLayout.getRoot();
   }

   private MMGroupLayout mmGroupLayout;

   @Override
   public boolean isModified() {
      return false;
   }

   @Override
   public Future<Void> save() {
      return Future.SUCCESS;
   }

   @Override
   public void resetForTestFX() {
      //TODO: Reset from fx data
      save();
   }

   @Override
   public Future<Void> reset() {
      return Future.SUCCESS;
   }
}
