package xfe.icap.themes;

import java.util.Arrays;
import java.util.List;

/**
 * Enum specifying different style sheets available in Gilts app.
 */
public enum StyleSheet {
   /**
    * Base css styles from the core package which are used for generic controls.
    */
   BASE("Core Base", "/css/base.css"),

   /**
    * Base css styles for Gilts app. Mainly defines the physical aspects of the node like spacing, padding, corners, sizes, etc
    * and the general colour settings that have no impact with theme. Logically this file should not define any theme specific colour settings.
    * These styles will mostly override the JavaFX's modena.css file.
    */
   GILTS_BASE("Gilts Base", "/css/gilts_base.css"),

   /**
    * Blue themed css styles for Gilts app. This file should mainly focus on setting the colours rather than adjusting the shape and look of the nodes.
    * Care should be taken to keep this file in sync with other themed css files.
    */
   GILTS_BLUE("Gilts Blue", "/css/themes/gilts_blue.css"),

   /**
    * Classic themed css styles for Gilts app. This file should mainly focus on setting the colours rather than adjusting the shape and look of the nodes.
    * Care should be taken to keep this file in sync with other themed css files.
    */
   GILTS_CLASSIC("Gilts Classic", "/css/themes/gilts_classic.css");

   /**
    * Returns all the themed StyleSheets.
    *
    * @return List of themed StyleSheets.
    */
   public static List<StyleSheet> getThemedStyleSheets() {
      return Arrays.asList(GILTS_BLUE, GILTS_CLASSIC);
   }

   /**
    * Returns the path for the style sheet.
    *
    * @return String path value.
    */
   public String getPath() {
      return this.path;
   }

   /**
    * Returns the name for the style sheet.
    *
    * @return String name value.
    */
   public String getName() {
      return this.name;
   }

   StyleSheet(String name, String path) {
      this.name = name;
      this.path = path;
   }

   private String path;

   private String name;


}
