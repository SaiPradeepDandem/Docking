package xfe.icap.client;

import xstr.session.Credentials;
import xstr.session.XstrClientConfig;
import xstr.util.concurrent.Future;

public class HttpSessionWrapper extends IcapWebSession {
//   private static final Logger logger = LoggerFactory.getLogger(HttpSessionWrapper.class);

   public HttpSessionWrapper(XstrClientConfig config) {
      super(config);
   }

   @Override
   public boolean isWebConnection() {
      return true;
   }

   @Override
   protected Future<? extends XstrWebConnection> connect(Credentials cred) {
      return XstrHttpConnection.connect(cred, this);
   }

}
