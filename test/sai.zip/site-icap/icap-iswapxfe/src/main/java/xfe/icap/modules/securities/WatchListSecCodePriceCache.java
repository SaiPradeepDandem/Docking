package xfe.icap.modules.securities;

import java.math.BigDecimal;

/**
 * Price cache object.
 */
public class WatchListSecCodePriceCache {

   private BigDecimal bidPrice;
   private BigDecimal matchPrice;
   private BigDecimal offerPrice;
   private boolean isCMWorkupTraded;

   public WatchListSecCodePriceCache(BigDecimal bidPrice, BigDecimal matchPrice, BigDecimal offerPrice, boolean isWorkupTrade) {
      this.bidPrice = bidPrice;
      this.matchPrice = matchPrice;
      this.offerPrice = offerPrice;
      this.isCMWorkupTraded = isCMWorkupTraded;
   }

   public BigDecimal getBidPrice() {
      return bidPrice;
   }

   public void setBidPrice(BigDecimal bidPrice) {
      this.bidPrice = bidPrice;
   }

   public BigDecimal getMatchPrice() {
      return matchPrice;
   }

   public void setMatchPrice(BigDecimal matchPrice) {
      this.matchPrice = matchPrice;
   }

   public BigDecimal getOfferPrice() {
      return offerPrice;
   }

   public void setOfferPrice(BigDecimal offerPrice) {
      this.offerPrice = offerPrice;
   }

   public boolean isCMWorkupTraded() {
      return isCMWorkupTraded;
   }

   public void setIsCMWorkupTraded(boolean isCMWorkupTraded) {
      this.isCMWorkupTraded = isCMWorkupTraded;
   }
}
