package xfe.icap.modules.ordersui;

import com.nomx.persist.watchlist.ColumnsSpec;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpDeal;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.ordersdata.OrdersDataModule;
import xfe.icap.modules.ordersdata.OrderFilters;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.toolbar.actions.ActionToolBarUIModule;
import xfe.icap.modules.tradesworkup.WorkupDITArgs;
import xfe.module.Module;
import xfe.modules.actions.*;
import xfe.modules.session.SessionScopeModule;
import xfe.types.OrdersTrans;
import xfe.util.XfeAction;
import xstr.session.ObservableReplyRow;
import xstr.session.ServerSession;
import xstr.session.XtrTransReply;
import xstr.types.OrderSide;
import xstr.util.TriConsumer;
import xstr.util.Tuple2;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

/**
 * UIModule for the orders view.
 */
@Module.Autostart
public class OrdersViewUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(OrdersViewUIModule.class);

   @ModuleDependency
   public OrdersDataModule ordersDataModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @ModuleDependency
   public SecTabsUIModule secTabsUIModule;

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ActionToolBarUIModule actionToolBarUIModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   public void setAmendOrderHandler(Consumer<PopupOrderEntryArgs> amendOrder) {
      this.amendOrder = amendOrder;
   }

   public void setAmendCMOrdersHandler(Consumer<PopupOrderEntryArgs> amendCMOrder) {
      this.amendCMOrder = amendCMOrder;
   }

   public Pane getRoot() {
      return root;
   }

   @Override
   public Future<Void> startModule() {
      secTabsUIModule.setReferAllOrdersHandler(this::referAllOrders);
      secTabsUIModule.setReferCMOrderHandler(this::referAllOrders);
      secTabsUIModule.setWithdrawOrders(this::withdrawOrder);
      secTabsUIModule.setWithdrawCMOrders(this::withdrawCMOrder);
      activeSessionModule.getSession().ifPresent((session) -> {
         final UnaryOperator<String> productHandler = (secCode) -> {
            try {
               return securitiesDataModule.getSecboards().getFirstBySecCode(secCode).get().getInstrumentId();
            } catch (Exception e) {
               logger.error("Error in fetching the SecBoard from secCode {}", secCode, e);
               return "";
            }
         };
         final Predicate<ObservableReplyRow> managedOrdersFilter =
            OrderFilters.matchOpenOrder().or(OrderFilters.matchReferredOrder()).or(OrderFilters.matchIsDarkOrder().and(OrderFilters.matchOpenOrder()));
         final ObservableList<ObservableReplyRow> managedOrders = this.ordersDataModule.getFilteredOrders(managedOrdersFilter);
         activeSessionModule.getSession().ifPresent(serverSession -> {
            final String loggedUserId = serverSession.getLoggedOnUserId();
            final String loggedFirmId = serverSession.getLoggedOnUserFirmId();
            final Predicate<ObservableReplyRow> referableMineFilter =
               OrderFilters.matchOpenOrder().and(OrderFilters.matchUserID(loggedUserId)).and(OrderFilters.matchOperatorID(null));
            referableMineOrders = this.ordersDataModule.getOpenOrders().filtered(referableMineFilter);
            final Predicate<ObservableReplyRow> referableAllIFilters =
               OrderFilters.matchOpenOrder().and(OrderFilters.matchFirmID(loggedFirmId));
            referableAllOrders = this.ordersDataModule.getOpenOrders().filtered(referableAllIFilters);
            referableAllOrders.addListener(referableListener);
            referableMineOrders.addListener(referableListener);
         });

         referMine.setActionId("referMine");
         setReferAction(referMine, true);
         referMine.getStyleClass().add("xfe-icon-refer-mine");
         referMine.setDisable(true);

         referAll.setActionId("referAll");
         setReferAction(referAll, false);
         referAll.getStyleClass().add("xfe-icon-refer-all");
         referAll.setDisable(true);

         actionToolBarUIModule.addTradeActions(referMine, referAll);
         this.orderViewTable = new OrdersViewTable();
         this.orderViewTable.setOrderActionConsumer(this::invokeAction);
         this.orderViewTable.setOrdersColsSpecificationPropertySupplier(this::getOrdersColsSpecificationProperty);
         this.orderViewTable.setProductHandler(productHandler);
         this.orderViewTable.setSideFactory(this::sideValueFactoryImpl);
         this.orderViewTable.setSecBoardStaticInfoGetter(securitiesDataModule::getStaticInfo);
         this.orderViewTable.setTradesAggregatePopupActionConsumer(this::doTradesAggregatePopupAction);
         this.orderViewTable.setItems(managedOrders);
      });

      this.root = new StackPane();
      this.root.setId(MidiLayoutViews.ORDERSVIEW);
      this.root.getChildren().add(this.orderViewTable);

      ordersAction = new XfeAction();
      ordersAction.setActionId("orders");
      ordersAction.setOnAction(e -> midiLayoutModule.addView(getRoot()));
      ordersAction.getStyleClass().add("xfe-icon-orders");
      actionToolBarUIModule.addViewAction(ordersAction);

      if (configurationModule.getData().ordersViewOpened().get()) {
         midiLayoutModule.addView(getRoot());
      }

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      if (referableAllOrders != null) {
         referableAllOrders.removeListener(referableListener);
      }
      if (referableMineOrders != null) {
         referableMineOrders.removeListener(referableListener);
      }
      referMine.setOnAction(null);
      referAll.setOnAction(null);
      ordersAction.setOnAction(null);
      secTabsUIModule.setReferAllOrdersHandler(null);
      secTabsUIModule.setReferCMOrderHandler(null);
      secTabsUIModule.setWithdrawOrders(null);
      secTabsUIModule.setWithdrawCMOrders(null);

      if (orderViewTable != null) {
         orderViewTable.setOrderActionConsumer(null);
         orderViewTable.setOrdersColsSpecificationPropertySupplier(null);
         orderViewTable.setProductHandler(null);
         this.orderViewTable.setSideFactory(null);
         orderViewTable.setSecBoardStaticInfoGetter(null);
         orderViewTable.setTradesAggregatePopupActionConsumer(null);
         orderViewTable.setItems(null);
         orderViewTable = null;
      }

      midiLayoutModule.removeView(getRoot());
      return Future.SUCCESS;
   }

   private ObjectProperty<ColumnsSpec> getOrdersColsSpecificationProperty() {
      return configurationModule.getData().ordersColsSpecificationProperty();
   }

   private void invokeAction(OrderActionArgs args) {
      Node source = args.getNode();
      ObservableReplyRow row = args.getRow();
      switch (args.getActionName()) {
         case ReferOrder:
            referOrder(row);
            break;
         case RenewOrder:
            renewOrder(row);
            break;
         case WithdrawOrder:
            withdrawOrder(row);
            break;
         case AmendOrder:
            showAmendOrder(source, row, amendOrder);
            break;
         case AmendCMOrder:
            showAmendOrder(source, row, amendCMOrder);
            break;
         default:
            // TODO: Add some Log Message or remove "default"
            break;
      }
   }

   private void showAmendOrder(Node source, ObservableReplyRow row, Consumer<PopupOrderEntryArgs> amend) {
      OrderSide side = getSide(row);
      activeSessionModule.getSession().ifPresent(serverSession -> {
         if (serverSession.getLoggedOnUserId().equals(row.getValue(AmpManagedOrder.userId))) {
            securitiesDataModule.retrieveSecBoardTrim2(row.getValue(AmpManagedOrder.secCode)).map(queryReplyRow -> {
               Platform.runLater(() -> amend.accept(new PopupOrderEntryArgs(row, source, side, queryReplyRow.getValue(AmpIcapSecBoardTrim2.doPriceReversal), PopupOrderEntryArgs.DefaultOn.PRICE)));
               return Future.SUCCESS;
            });
         }
      });
   }

   // PRIVATE METHODS
   private void referOrder(ObservableReplyRow row) {
      activeSessionModule.getSession().ifPresent((session) -> {
         logger.debug("Referring order :: " + row.getProperty(AmpManagedOrder.secCode).get());
         final Asn1Type orderId = row.getAsn(AmpManagedOrder.currentOrderId);
         final String userId = row.getValue(AmpManagedOrder.userId);
         OrdersTrans.deactivate(session, orderId, userId).onDone(x -> {
            XtrTransReply result = x.get();
            if (result.getStatus() != XtrTransReply.Status.RESULT_OK) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setHeaderText(result.getMessage());
               alert.showAndWait();
            }
            return Future.SUCCESS;
         });
      });
   }

   private void setReferAction(XfeAction action, boolean mineOnly) {
      action.setOnAction(e -> {
         activeSessionModule.getSession().ifPresent(serverSession -> {
            OrdersTrans.deactivateAll(serverSession, mineOnly);
            updateReferButtonState();
         });
      });
   }

   private void renewOrder(ObservableReplyRow row) {
      activeSessionModule.getSession().ifPresent((session) -> {
         logger.debug("Renewing/ReInitiating order :: " + row.getProperty(AmpManagedOrder.secCode).get());
         final Asn1Type orderId = row.getAsn(AmpManagedOrder.currentOrderId);
         final String userId = row.getValue(AmpManagedOrder.userId);
         final String operatorId = row.getValue(AmpManagedOrder.operatorId);
         boolean isCurrentOrderDark = Objects.equals(row.getValue(AmpManagedOrder.isDoneIfTouched), Boolean.TRUE);
         final Asn1Type referredOrderID = isCurrentOrderDark ? referOppositeCMOrder(row, session) : null;

         /* If the order is placed by the trader, directly renewing/re-initiating the order */
         if (operatorId == null || operatorId.isEmpty()) {
            Future<XtrTransReply> activateReq = OrdersTrans.activate(session, orderId, userId);
            activateReq.onDone(result -> {
               if (result.get().getStatus() != XtrTransReply.Status.RESULT_OK && referredOrderID != null) {
                  OrdersTrans.activate(session, referredOrderID, userId);
               }
               return Future.SUCCESS;
            });
         }
         /* If the order is placed by the broker, withdrawing the order and placing a new order */
         else {
            if (populateAndPlaceOrderHandler != null) {
               withdrawOrder(row);
               populateAndPlaceOrderHandler.accept(row, null, true);
            }
         }
      });
   }

   private Asn1Type referOppositeCMOrder(ObservableReplyRow row, ServerSession session) {
      OrderSide oppositeSideOfCurrentOrder = (getSide(row) == OrderSide.BUY) ? OrderSide.SELL : OrderSide.BUY;
      final String userId = row.getValue(AmpManagedOrder.userId);
      final String rowSecCode = row.getValue(AmpManagedOrder.secCode);
      final String rowBoardId = row.getValue(AmpManagedOrder.boardId);
      FilteredList<ObservableReplyRow> oppositeSideOrders = ordersDataModule.getOpenOrdersBySec(new Tuple2<>(rowSecCode, rowBoardId))
         .filtered(OrderFilters.matchSide(oppositeSideOfCurrentOrder).and(OrderFilters.matchUserID(userId)));
      for (ObservableReplyRow order : oppositeSideOrders) {
         boolean isDark = Objects.equals(order.getValue(AmpManagedOrder.isDoneIfTouched), Boolean.TRUE);
         if (isDark) { // in case of a dark order is present in the opposite side
            final Asn1Type oppositeOrderID = order.getAsn(AmpManagedOrder.currentOrderId);
            OrdersTrans.deactivate(session, oppositeOrderID, userId);
            return oppositeOrderID;
         }
      }
      return null;
   }

   private void withdrawOrder(ObservableReplyRow row) {
      activeSessionModule.getSession().ifPresent((session) -> {
         logger.debug("Withdrawing order :: " + row.getProperty(AmpManagedOrder.secCode).get());
         final Asn1Type orderId = row.getAsn(AmpManagedOrder.currentOrderId);
         final String userId = row.getValue(AmpManagedOrder.userId);
         final String introBrokerId = row.getValue(AmpManagedOrder.introBrokerId);
         OrdersTrans.withdrawByOrderId(session, orderId, userId, introBrokerId, true);
      });
   }

   private void withdrawOrder(WithdrawArgs withdrawArgs) {
      final String secCode = withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.secCode);
      String specialOrderType = null;
      if (withdrawArgs.getSide() == OrderSide.BUY) {
         specialOrderType = withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.bidSpecialOrderType);
      } else if (withdrawArgs.getSide() == OrderSide.SELL) {
         specialOrderType = withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.offerSpecialOrderType);
      }
      if (specialOrderType != null && !specialOrderType.isEmpty() && specialOrderBlacklist.contains(specialOrderType)) {
         logger.info("Attempting a withdraw for special order type {} of security {}", specialOrderType, secCode);
      }

      activeSessionModule.getSession().ifPresent((session) -> {
         logger.debug("Withdrawing order :: " + withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.secCode));
         Collection<ObservableReplyRow> ordersToWithdraw = ordersDataModule.ordersToWithdraw(secCode, withdrawArgs.getSide());

         // Withdrawing all fetched orders
         ordersToWithdraw.forEach(orderRow -> OrdersTrans.withdrawByOrderId(session, orderRow.getAsn(AmpManagedOrder.currentOrderId)));
      });
   }

   private void withdrawCMOrder(WithdrawArgs withdrawArgs) {
      activeSessionModule.getSession().ifPresent((session) -> {
         logger.debug("Withdrawing CM order :: " + withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.secCode));
         final String secCode = withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.secCode);
         final BigDecimal constantMatchPrice = withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
         if (constantMatchPrice == null) return;
         Collection<ObservableReplyRow> myOpenCMOrders =
            ordersDataModule
               .getOpenOrdersBuilder()
               .ofSec(secCode)
               .own()
               .atAbsCMPrice(constantMatchPrice)
               .inSide(withdrawArgs.getSide())
               .build();
         // if array not empty, these are my orders
         if (!myOpenCMOrders.isEmpty()) {
            for (ObservableReplyRow orderRow : myOpenCMOrders) {
               OrdersTrans.withdrawByOrderId(session, orderRow.getAsn(AmpManagedOrder.currentOrderId));
            }
         } else { // if array is empty, then delete colleagues orders
            Collection<ObservableReplyRow> colleagueOpenOrders
               = ordersDataModule.getOpenOrdersBuilder()
               .ofSec(secCode)
               .colleagues()
               .atAbsCMPrice(constantMatchPrice)
               .inSide(withdrawArgs.getSide())
               .build();
            for (ObservableReplyRow orderRow : colleagueOpenOrders) {
               OrdersTrans.withdrawByOrderId(session, orderRow.getAsn(AmpManagedOrder.currentOrderId));
               break; // If more than one colleague order is present then remove only the first in the queue
            }
         }
      });
   }

   private void referAllOrders(ReferArgs referArgs) {
      final String rowSecCode = referArgs.getRow().getValue(AmpIcapSecBoardTrim2.secCode);
      final String rowBoardId = referArgs.getRow().getValue(AmpIcapSecBoardTrim2.boardId);
      String userId = activeSessionModule.getSession().get().getLoggedOnUser().getUserId();
      Collection<ObservableReplyRow> refList = ordersDataModule.getOpenOrdersBySec(new Tuple2<>(rowSecCode, rowBoardId));
      activeSessionModule.getSession().ifPresent((session) -> {
         final BigDecimal constantMatchPrice = referArgs.getRow().getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
         // We have a list of all our open orders for the designated side and the relevant security code
         // Now we need to see if any of them is a constant match order or not
         // and only refer those that fit the refer args requirement.
         // (an order is CM if constant match price equals order's price and it is a dark order)
         boolean isCM = referArgs.getCM();
         for (ObservableReplyRow order : refList) {
            boolean isDark = Objects.equals(order.getValue(AmpManagedOrder.isDoneIfTouched), Boolean.TRUE);
            BigDecimal price = order.getValue(AmpManagedOrder.price);
            boolean pricesAreEqual = (price == null && constantMatchPrice == null ||
               price != null && constantMatchPrice != null && price.abs().compareTo(constantMatchPrice.abs()) == 0);
            boolean isReallyCM = isDark && pricesAreEqual;

            OrderSide orderSide = getSide(order);

            // A trader cannot refer shared orders
            boolean isMyOrder = userId.equals(order.getValue(AmpManagedOrder.userId));

            // True if the requested order type (isCM) fits order's attributes (really CM or not)
            if (isCM == isReallyCM && referArgs.getSide().equals(orderSide) && isMyOrder)
               referOrder(order);
         }
      });
   }

   private ObservableValue<OrderSide> sideValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getSide(row), row.rowProperty());
   }

   private OrderSide getSide(ObservableReplyRow row) {
      Integer buySell = row.getValue(AmpManagedOrder.buySell);
      if (buySell != null) {
         if (buySell == AmpOrderVerb.buy) {
            return OrderSide.BUY;
         } else if (buySell == AmpOrderVerb.sell) {
            return OrderSide.SELL;
         }
      }
      return null;
   }

   public void setTradesAggregatePopupHandler(Consumer<TradesAggregateArgs> tradesAggregatePopupHandler) {
      this.tradesAggregatePopupHandler = tradesAggregatePopupHandler;
   }

   private void doTradesAggregatePopupAction(TradesAggregateArgs args) {
      if (tradesAggregatePopupHandler != null)
         tradesAggregatePopupHandler.accept(args);
   }

   private void updateReferButtonState() {
      referAll.setDisable(referableAllOrders.isEmpty());
      referMine.setDisable(referableMineOrders.isEmpty());
   }

   public TriConsumer<ObservableReplyRow, WorkupDITArgs, Boolean> getPopulateAndPlaceOrderHandler() {
      return populateAndPlaceOrderHandler;
   }

   public void setPopulateAndPlaceOrderHandler(TriConsumer<ObservableReplyRow, WorkupDITArgs, Boolean> populateAndPlaceOrderHandler) {
      this.populateAndPlaceOrderHandler = populateAndPlaceOrderHandler;
   }

   private OrdersViewTable orderViewTable;
   private Pane root;
   private Consumer<PopupOrderEntryArgs> amendOrder;
   private Consumer<PopupOrderEntryArgs> amendCMOrder;
   private Consumer<TradesAggregateArgs> tradesAggregatePopupHandler;
   private TriConsumer<ObservableReplyRow, WorkupDITArgs, Boolean> populateAndPlaceOrderHandler;
   private final XfeAction referMine = new XfeAction();
   private final XfeAction referAll = new XfeAction();
   private XfeAction ordersAction;
   private final InvalidationListener referableListener = o -> updateReferButtonState();
   private ObservableList<ObservableReplyRow> referableMineOrders = FXCollections.observableArrayList();
   private ObservableList<ObservableReplyRow> referableAllOrders = FXCollections.observableArrayList();
   private final List<String> specialOrderBlacklist = Arrays.asList("Implied", "SpreadoverImplied", "N Implied", "Spreadover N Implied", "Indicative");

}
