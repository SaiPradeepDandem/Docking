package xfe.icap.modules.toolbar.actions;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.layout.StackPane;
import xfe.icap.amp.AmpDeal;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpTrade;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.ui.popover.PopOverOwner;
import xstr.session.ObservableReplyRow;

import java.util.function.Consumer;

public class InstrumentCell extends TableCell<ObservableReplyRow, String> implements PopOverOwner {
   private StackPane container;
   private StackPane notch;
   private Label cellValue;

   @Override
   protected void updateItem(String item, boolean empty) {
      if (container == null) {
         setupContainer();
      }
      super.updateItem(item, empty);

      if (item != null && !empty) {
         cellValue.setText(item);
         setGraphic(container);
      } else {
         setGraphic(null);
      }
   }

   private void setupContainer() {
      notch = new StackPane();
      notch.setVisible(false);
      notch.getStyleClass().add("instrument-cell-notch");
      notch.setMaxSize(10, 10);
      notch.setMinSize(10, 10);
      notch.setOnMouseClicked(e -> {
         ObservableReplyRow row = (ObservableReplyRow) getTableRow().getItem();
         String secCode;
         String boardId;
         if (row.getValue(AmpManagedOrder.secCode) != null) {
            secCode = row.getValue(AmpManagedOrder.secCode);
            boardId = row.getValue(AmpManagedOrder.boardId);
         } else if (row.getValue(AmpDeal.secCode) != null) {
            secCode = row.getValue(AmpDeal.secCode);
            boardId = row.getValue(AmpDeal.boardId);
         } else {
            secCode = row.getValue(AmpTrade.secCode);
            boardId = row.getValue(AmpTrade.boardId);
         }
         final TradesAggregateArgs args = new TradesAggregateArgs(boardId, secCode, container);
         ((TradesAggregatePopupSource)getTableRow().getTableView()).getTradesAggregatePopupActionConsumer().accept(args);
         /* Consume the event to not propagate the event to the table row mouse clicked event handler */
         e.consume();
      });
      setOnMouseEntered(e -> notch.setVisible(true));
      setOnMouseExited(e -> notch.setVisible(false));
      StackPane.setAlignment(notch, Pos.TOP_RIGHT);

      cellValue = new Label();
      container = new StackPane();
      container.getStyleClass().add("instrument-cell-container");
      container.setAlignment(Pos.CENTER_LEFT);
      container.getChildren().addAll(cellValue, notch);
   }
}
