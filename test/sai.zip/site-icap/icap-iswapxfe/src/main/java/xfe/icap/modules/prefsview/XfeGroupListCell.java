package xfe.icap.modules.prefsview;

import xfe.ui.list.ReorderableListCell;
import xfe.ui.list.ReorderableListView;
import xfe.ui.list.XfeGroup;
import xfe.ui.list.XfeItem;
import xfe.util.XfeBooleanBinding;
import xfe.util.scene.control.XfeTooltipFactory;

import javafx.beans.*;
import javafx.beans.property.StringProperty;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;

public class XfeGroupListCell<T extends XfeGroup<? extends XfeItem>> extends ReorderableListCell<T> {

   private final TextField nameEditor = new TextField();
   private final Label nameLabel = new Label();
   private final CheckBox shortlistCheckBox = new CheckBox();
   private final Button delButton = new Button();
   private final HBox cell = new HBox();

   public XfeGroupListCell(ReorderableListView<T> view, StringProperty selectedGroup, XfeBooleanBinding checkBoxDisableValue){
      super(view, selectedGroup);
      cell.getStyleClass().add("xfe-group-list-cell");
      nameLabel.setId("listcell-name-lbl");
      HBox.setHgrow(nameEditor, Priority.ALWAYS);
      HBox.setHgrow(nameLabel, Priority.ALWAYS);
      nameLabel.setMaxWidth(200);
      HBox.setHgrow(shortlistCheckBox, Priority.NEVER);
      HBox.setHgrow(delButton, Priority.NEVER);

      delButton.getStyleClass().add("xfe-grid-tab-close-button");
      delButton.setOnAction(arg0 -> XfeGroupListCell.this.getListView().getItems().remove(getItem()));
      if (checkBoxDisableValue != null) {
         shortlistCheckBox.disableProperty().bind(checkBoxDisableValue.and(shortlistCheckBox.selectedProperty().not()));
      }
      nameEditor.setOnKeyPressed(keyEvt -> {
         KeyCode key = keyEvt.getCode();
         if(key==KeyCode.ESCAPE){
            cancelEdit();
         }else if(key == KeyCode.ENTER){
            T t = getItem();
            t.setId(nameEditor.getText());
            commitEdit(t);
         }
      });

      shortlistCheckBox.selectedProperty().addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            T t = XfeGroupListCell.this.getItem();
            if(t!=null){
               t.setShortListed(shortlistCheckBox.selectedProperty().get());
            }
         }
      });

//      nameLabel.setOnKeyPressed(new EventHandler<KeyEvent>() {
//
//         @Override
//         public void handle(KeyEvent keyEvt) {
//            KeyCode key = keyEvt.getCode();
//            if(key==KeyCode.F2){
//               startEdit();
//            }
//         }
//      });
//      nameLabel.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
//
//         @Override
//         public void handle(KeyEvent paramT) {
//            System.out.println("jajava");
//         }
//
//      });

      nameLabel.setOnMouseClicked(mouseEvent -> {
         getListView().getSelectionModel().select(getIndex());
         if(mouseEvent.getClickCount()==2){
            startEdit();
         }
      });
   }

   private final InvalidationListener editorFocusListener = arg0 -> {
      if(!nameEditor.isFocused()){
         T t = getItem();
         t.setId(nameEditor.getText());
         commitEdit(t);
      }
   };

   @Override
   protected void updateItem(T item, boolean empty) {
      super.updateItem(item, empty);
      if (isEmpty() || item == null) {
         setGraphic(null);
      } else {
         shortlistCheckBox.setSelected(item.getIsShortListed());
         nameLabel.setText(item.getId());
         XfeTooltipFactory.setTooltip(nameLabel);
         cell.setAlignment(Pos.CENTER_LEFT);
         cell.getChildren().setAll(shortlistCheckBox,nameLabel,delButton);
         this.setGraphic(cell);
      }
   }

   @Override
   public void startEdit() {
      nameEditor.setText(getItem().getId());
      nameEditor.focusedProperty().addListener(editorFocusListener);
      cell.getChildren().set(1, nameEditor);
      nameEditor.requestFocus();
   }

   @Override
   public void commitEdit(T newValue) {
      editFinished();
      super.cancelEdit();
   }

   @Override
   public void cancelEdit() {
      super.cancelEdit();
      nameEditor.setText(getItem().getId());
      editFinished();
   }

   private void editFinished() {
      nameEditor.focusedProperty().removeListener(editorFocusListener);
      nameLabel.setText(nameEditor.getText());
      getItem().setId(nameEditor.getText());
      cell.getChildren().set(1, nameLabel);
   }

}
