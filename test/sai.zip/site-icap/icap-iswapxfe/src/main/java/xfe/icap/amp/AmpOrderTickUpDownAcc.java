package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;

/**
 * Accessors for AmpOrderAmend_v5
 * @author absw
 *
 */
public class AmpOrderTickUpDownAcc extends AmpAccessor {
   public static final AmpTreq txn = AMP.tREQ("orderTickUpDown");

   public static final AsnAccessor orderId =  acc(AMP.tREQ("orderTickUpDown.orderId"));
   public static final AsnConversionAccessor<String> introBrokerId = acc(AMP.tREQ("orderTickUpDown.introBrokerId"), String.class);
   /*
    * get error  message:   You do not have permission to specify brokerId
    */
   public static final AsnConversionAccessor<String> brokerId = acc(AMP.tREQ("orderTickUpDown.brokerId"), String.class);
   public static final AsnConversionAccessor<Long> numTicks = acc(AMP.tREQ("orderTickUpDown.numTicks"), Long.class);
}
