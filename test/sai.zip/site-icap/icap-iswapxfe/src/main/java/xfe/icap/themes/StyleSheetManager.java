package xfe.icap.themes;

import com.sun.javafx.css.StyleManager;
import javafx.application.Application;

import java.util.List;

/**
 * Utility class for managing the stylesheets in the application.
 */
public final class StyleSheetManager {
   private static boolean initialized = false;

   private StyleSheetManager() {
      throw new UnsupportedOperationException("Cannot create an instance of StyleSheetManager");
   }

   /**
    * Initializing the StyleManager to load the default style sheets. Cannot call this method twice once it is called.
    */
   public static void init() {
      if (initialized) {
         throw new UnsupportedOperationException("Cannot initialize StyleSheetManager as it is already initialized.");
      }
      Application.setUserAgentStylesheet(null);
      StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.BASE.getPath());
      StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.GILTS_BASE.getPath());
      initialized = true;
   }

   /**
    * Switches the themes of style sheet in the application using StyleManager.
    *
    * @param oldTheme Old theme that need to be removed.
    * @param newTheme New theme that need to set.
    */
   public static void switchTheme(StyleSheet oldTheme, StyleSheet newTheme) {
      if (!initialized) {
         throw new UnsupportedOperationException("Cannot switch the themes as StyleSheetManager is not initialized.");
      }
      final List<StyleSheet> themedStyles = StyleSheet.getThemedStyleSheets();
      if (oldTheme != null && themedStyles.contains(oldTheme)) {
         StyleManager.getInstance().removeUserAgentStylesheet(oldTheme.getPath());
      }
      if (newTheme != null && themedStyles.contains(newTheme)) {
         StyleManager.getInstance().addUserAgentStylesheet(newTheme.getPath());
      }
   }

}
