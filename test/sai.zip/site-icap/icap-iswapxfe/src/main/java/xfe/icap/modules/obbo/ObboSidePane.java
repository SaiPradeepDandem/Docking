package xfe.icap.modules.obbo;

import xfe.util.XfePickupAction;
import xstr.util.Fx;
import xfe.icap.amp.Util;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.layout.HBox;

import xfe.icap.types.OrderBookSide;
import xstr.types.OrderSide;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpOrderBookByOrder;
import xfe.util.XfeAction;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xstr.session.ObservableReplyRow;
import xfe.ui.notifications.ModalAlertModule;
import xfe.ui.table.Tables;
import javafx.scene.layout.Priority;
import org.slf4j.Logger;

import java.util.List;
import java.util.Objects;

public class ObboSidePane extends HBox {
   private final IndependentSideTableView tableView;
   private final OrderBookSide orderBookSide;
   private final ObboModule obboModule;


   private final ObboTableViewSpec spec;
   private final BooleanProperty bidOnLeftProperty;

   private final ChangeListener<Number> listener = new ChangeListener<Number>() {
      @Override
      public void changed(ObservableValue<? extends Number> paramObservableValue, Number paramT1, Number paramT2) {
         if (obboModule.sideProperty.get() == orderBookSide.side) {
            if (!obboModule.loading) {
               obboModule.sideProperty.set(null);
            }
         }
      }
   };

   private final ChangeListener<Boolean> changeLis = new ChangeListener<Boolean>() {
      @Override
      public void changed(ObservableValue<? extends Boolean> _0, Boolean _1, Boolean _2) {
         FXCollections.reverse(tableView.getColumns());
         FXCollections.reverse(getChildren());
         spec.setPlaceholderColumns(tableView);// (as they will have been reversed, which we don't want)
      }
   };



   public ObboSidePane(XfeSession xfeSession,
                       OrderSide orderSide,
                       ObboModule obboModule,
                       ModalAlertModule eventNotification,
                       boolean isBidSide,
                       BooleanProperty bidOnLeftProperty,
                       OrderBookSide orderBookSide,
                       ObjectProperty<XfePickupAction> pickedupActionProp,
                       boolean is4PopupStage) {
      this.obboModule = obboModule;
      this.orderBookSide = orderBookSide;
      this.getStyleClass().add("obbo-side-pane");
      this.bidOnLeftProperty = bidOnLeftProperty;
      this.tableView = new IndependentSideTableView(isBidSide, is4PopupStage,pickedupActionProp,obboModule) {
         @Override
         void obboRowSelectionUpdated(ObservableReplyRow queryReplyRow, TablePosition tablePosition, int rowIndex, boolean forceUpdate) {
            if (queryReplyRow != null && (!is4PopupStage || forceUpdate)) {
            	if (forceUpdate) {
            		String secCode = Util.getSecCodeFromObboReplyRow(queryReplyRow);
                	String boardId = Util.getBoardIdFromObboReplyRow(queryReplyRow);
                	obboModule.setOrderBookAttributes(secCode, boardId, secCode, true);
            	}

            	obboModule.selectionContextModule.setSelectionContext(new SelectionContext(GridType.of(orderSide), queryReplyRow, null, tablePosition, rowIndex));
				if (forceUpdate)
					obboModule.selectRow(orderSide == OrderSide.BUY, rowIndex);
            }
         }

         @Override
         void obboRowPriceUpdated(Double newPrice) {
        	 obboModule.updatedPrice.setValue(newPrice);
         }
      };

      ScrollBar scrollbar = Tables.getReplacementScrollBar(tableView);

      tableView.getStyleClass().add("buy-side-table-view");
      spec = new ObboTableViewSpec(xfeSession,
    		  obboModule,
    		  eventNotification,
    		  isBidSide,
    		  bidOnLeftProperty,
    		  orderBookSide,
    		  pickedupActionProp,
              row -> {
                  tableView.updateObboSelection(isBidSide, row, true);
                  return null;
              },
              is4PopupStage);

      spec.applyTo(tableView);

      HBox.setHgrow(tableView, Priority.ALWAYS);
      if (isBidSide == bidOnLeftProperty.get()) {
         this.getChildren().addAll(scrollbar, tableView);
      } else {
         this.getChildren().addAll(tableView, scrollbar);
      }

      bidOnLeftProperty.addListener(changeLis);
      orderBookSide.availabilityChangedObservable.addListener(listener);
      this.setMinHeight(0);
   }

   public void setActive(boolean active) {
      tableView.setActive(active);
   }

   void highlightTo(int toRow) {
      tableView.highlightTo(toRow);
   }

   void selectRow(int rowIndex) {
	   tableView.getSelectionModel().clearAndSelect(rowIndex);
   }

   /**
      for Mantis0079789: XFE Phase 5: RFS Sessions. trying to select the cloned RFS order in RFS Session
    */
   void selectRow(ObservableReplyRow rfsObboRow, TablePosition tablePosition, Logger logger) {
      logger.trace("obbo RFS select row called");
      Double targetPrice = rfsObboRow.getValue(AmpOrderBookByOrder.price);
      String targetGroupId = rfsObboRow.getValue(AmpOrderBookByOrder.groupId);
      Double targetQty = rfsObboRow.getValue(AmpOrderBookByOrder.quantity);

      List<ObservableReplyRow> obboRows = tableView.getItems();

      logger.trace("obbo ROWS are: {}", obboRows);

      int max = obboRows.size();
      int index = -1;
      ObservableReplyRow obboRow = null;
      for (int i = 0; i < max; i++) {
         obboRow = obboRows.get(i);
         if (Objects.equals(targetPrice, obboRow.getValue(AmpOrderBookByOrder.price))) {
            if (Objects.equals(targetQty, obboRow.getValue(AmpOrderBookByOrder.quantity)) &&
               Objects.equals(targetGroupId, obboRow.getValue(AmpOrderBookByOrder.groupId))) {
               index = i;
               break;
            } else {
               if (index == -1)
                  index = i;
            }
         }
      }

      if (index != -1 && obboRow != null) {
         int finalIndex = index;
         ObservableReplyRow finalObboRow = obboRow;
         Fx.runLater(() -> {
            TableColumn<ObservableReplyRow, ?> tc = tablePosition == null ? null : tablePosition.getTableColumn();
            tableView.getSelectionModel().select(finalIndex, tc);
            tableView.updateObboSelection(ObboSidePane.this.orderBookSide.side == OrderSide.BUY, finalObboRow, false);
            logger.debug("selecting index : {}, row {}. tableposition {}", finalIndex, finalObboRow, tc);
         });
      }
   }

   public void dispose(){
      bidOnLeftProperty.removeListener(changeLis);
      orderBookSide.availabilityChangedObservable.removeListener(listener);
      orderBookSide.availabilityChangedObservable.dispose();
   }
}
