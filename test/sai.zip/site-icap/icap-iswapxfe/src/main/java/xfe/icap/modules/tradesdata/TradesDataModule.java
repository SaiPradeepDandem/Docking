package xfe.icap.modules.tradesdata;

import com.omxgroup.xstream.amp.AmpStrategyTradeType_v2;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import xfe.amp.AmpMarketTrade;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.iswaptrades.MarketTradeFilters;
import xfe.icap.modules.iswaptrades.TradesFeedAdapter;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.session.ObservableReplyRow;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.util.FeedAggregator;
import xstr.util.ListenerTracker;
import xstr.util.Tuple2;
import xstr.util.concurrent.Future;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.RowFilters;

import java.math.BigDecimal;
import java.util.*;

@Module.Autostart
public class TradesDataModule extends SessionScopeModule {
    private final ListenerTracker tracker = new ListenerTracker();
    public DynamicFilter<ObservableReplyRow> isOutrightInMarketTrade = DynamicFilter.of(
            Filters.or(
                    RowFilters.equals(AmpMarketTrade.buyStrategyTradeType, AmpStrategyTradeType_v2.outright),
                    RowFilters.equals(AmpMarketTrade.sellStrategyTradeType, AmpStrategyTradeType_v2.outright)));
    public DynamicFilter<ObservableReplyRow> isStrategyInMarketTrade = DynamicFilter.of(
            Filters.or(
                    RowFilters.equals(AmpMarketTrade.buyStrategyTradeType, AmpStrategyTradeType_v2.strategy),
                    RowFilters.equals(AmpMarketTrade.sellStrategyTradeType, AmpStrategyTradeType_v2.strategy)));
    private ObservableList<ObservableReplyRow> iswapTrades;
    private ObservableList<ObservableReplyRow> trades;
    private ObservableList<ObservableReplyRow> marketTrades;
    private TradesFeedAdapter marketTradesFeed;
    private FeedAggregator<ObservableReplyRow> tradeAggregator;
    private FeedAggregator<ObservableReplyRow> iswapTradeAggregator;
    private FeedAggregator<ObservableReplyRow> marketAggregator;
    private Map<Tuple2<String, String>, Map<BigDecimal, TradesOrDealsPriceAggregateData>> tradesAggregateByPriceBySecBoard = new HashMap<>();
    private TradesFeedAdapter tradesFeed;
    private IswapTradesFeedAdapter iswapTradesFeed;
    private Runnable tradeUpdateNotifier;

    public ObservableList<ObservableReplyRow> getISwapTradeData() {
        return iswapTrades;
    }

    public ObservableList<ObservableReplyRow> getMarketTradeData() {
        return marketTrades;
    }

    public ObservableList<ObservableReplyRow>
    getOutrightsAndStrategyForMarketTrade(ObservableList<ObservableReplyRow> items) {
        return new FilteredList<>(items, MarketTradeFilters.isBuyOutright()
                .or(MarketTradeFilters.isSellOutright())
                .or(MarketTradeFilters.isBuyStrategy())
                .or(MarketTradeFilters.isSellStrategy()));
    }

    public ObservableList<ObservableReplyRow> getTradeData() {
        return trades;
    }

    public Map<Tuple2<String, String>, Map<BigDecimal, TradesOrDealsPriceAggregateData>> getTradesAggregateByPriceBySecBoard() {
        return tradesAggregateByPriceBySecBoard;
    }

    public void setTradeUpdateNotifier(Runnable tradeUpdateNotifier) {
        this.tradeUpdateNotifier = tradeUpdateNotifier;
    }

    @Override
    public Future<Void> startModule() {
        iswapTradeAggregator = new FeedAggregator<>(AmpTrade.rep, new ObservableRowFactory());
        tradeAggregator = new FeedAggregator<>(AmpTrade.rep, new ObservableRowFactory());
        marketAggregator = new FeedAggregator<>(AmpMarketTrade.rep, new ObservableRowFactory());

        Comparator<QueryReplyRow> ampTradeComparator = (row1, row2) -> row2.getValue(AmpTrade.time).compareTo(row1.getValue(AmpTrade.time));
        Comparator<QueryReplyRow> ampTradeLegComparator = (row1, row2) -> {
            Boolean row1IsLeg = IswapTradesFeedAdapter.isLegTrade(row1);
            Boolean row2IsLeg = IswapTradesFeedAdapter.isLegTrade(row2);
            return row1IsLeg.compareTo(row2IsLeg);
        };
        Comparator<QueryReplyRow> ampTradeIdComparator = (row1, row2) -> {
            String tradeId1 = IswapTradesFeedAdapter.getStrategyTradeNo(row1);
            String tradeId2 = IswapTradesFeedAdapter.getStrategyTradeNo(row2);
            return tradeId1.compareTo(tradeId2);
        };
        Comparator<QueryReplyRow> ampMarketTradeComparator = (row1, row2) -> row2.getValue(AmpMarketTrade.tradeTime).compareTo(row1.getValue(AmpMarketTrade.tradeTime));

        activeSessionModule.getSession().ifPresent(session -> {
            tradesFeed = new TradesFeedAdapter(session.getFeedSource(AmpTrade.req), activeSessionModule.getSession().get().getLoggedOnUserId());
            tracker.addFeedListener(tradesFeed, tradeAggregator);
            tradesFeed.startPolling();

            iswapTradesFeed = new IswapTradesFeedAdapter(session.getFeedSource(AmpTrade.req));
            tracker.addFeedListener(iswapTradesFeed, iswapTradeAggregator);
            iswapTradesFeed.startPolling();

            marketTradesFeed = new TradesFeedAdapter(session.getFeedSource(AmpMarketTrade.req), activeSessionModule.getSession().get().getLoggedOnUserId());
            tracker.addFeedListener(marketTradesFeed, marketAggregator);
            marketTradesFeed.startPolling();
        });

        trades = new SortedList<>(tradeAggregator.items, ampTradeComparator);
        trades.addListener(this::handleTradeUpdates);

        marketTrades = new SortedList<>(marketAggregator.items, ampMarketTradeComparator);
        marketTrades.addListener(this::handleMarketTradeUpdates);

        iswapTrades = new SortedList<>(iswapTradeAggregator.items, ampTradeComparator.thenComparing(ampTradeLegComparator).thenComparing(ampTradeIdComparator));

        return Future.SUCCESS;
    }

    @Override
    public Future<Void> stopModule() {
        if (tradesFeed != null) {
            tradesFeed.stopPolling();
            tradesFeed.dispose();
            tradesFeed = null;
        }
        tradeAggregator.reset();
        tradeAggregator = null;

        if (marketTradesFeed != null) {
            marketTradesFeed.stopPolling();
            marketTradesFeed.dispose();
            marketTradesFeed = null;
        }
        if (iswapTradesFeed != null) {
            iswapTradesFeed.stopPolling();
            iswapTradesFeed.dispose();
            iswapTradesFeed = null;
        }
        marketAggregator.reset();
        marketAggregator = null;

        tracker.rollback();
        tradesAggregateByPriceBySecBoard.clear();

        return Future.SUCCESS;
    }

    private void handleTradeUpdates(ListChangeListener.Change<? extends ObservableReplyRow> c) {
        while (c.next()) {
            if (c.wasRemoved()) {
                c.getRemoved().forEach(row -> {
                    String s = row.getValue(AmpTrade.secCode);
                    String b = row.getValue(AmpTrade.boardId);
                    Tuple2<String, String> secBoardKey = new Tuple2<>(s, b);
                    //  updateTradesAggregatePriceMap(secBoardKey, row,false); TODO : Remove
                });
            } else if (c.wasAdded()) {
                c.getAddedSubList().forEach(row -> {
                    String secCode = row.getValue(AmpTrade.secCode);
                    String boardId = row.getValue(AmpTrade.boardId);
                    if (secCode != null && boardId != null) {
                        Tuple2<String, String> secBoardKey = new Tuple2<>(secCode, boardId);
                        updateTradesAggregatePriceMap(secBoardKey, row, false);
                    }
                });
            }
        }
    }

    private void handleMarketTradeUpdates(ListChangeListener.Change<? extends ObservableReplyRow> c) {
        while (c.next()) {
            if (c.wasRemoved()) {
                c.getRemoved().forEach(row -> {
                    String s = row.getValue(AmpMarketTrade.secCode);
                    String b = row.getValue(AmpMarketTrade.boardId);
                    Tuple2<String, String> secBoardKey = new Tuple2<>(s, b);
                    // updateTradesAggregatePriceMap(secBoardKey, row, true); TODO : Remove
                });
            } else if (c.wasAdded()) {
                c.getAddedSubList().forEach(row -> {
                    String secCode = row.getValue(AmpMarketTrade.secCode);
                    String boardId = row.getValue(AmpMarketTrade.boardId);
                    if (secCode != null && boardId != null) {
                        Tuple2<String, String> secBoardKey = new Tuple2<>(secCode, boardId);
                        updateTradesAggregatePriceMap(secBoardKey, row, true);
                    }
                });
            }
        }
    }

    private void updateTradesAggregatePriceMap(Tuple2<String, String> secBoardKey, ObservableReplyRow row, boolean isMarketTrade) {
        Optional<ServerSession> session = activeSessionModule.getSession();
        if (!session.isPresent()) {
            return;
        }
        String userId = session.get().getLoggedOnUserId();
        String firmId = session.get().getLoggedOnUserFirmId();

        BigDecimal price = row.getValue(isMarketTrade ? AmpMarketTrade.price : AmpTrade.price).setScale(2, BigDecimal.ROUND_HALF_UP);

        // Creating the priceMap for the secBoardKey if not present.
        Map<BigDecimal, TradesOrDealsPriceAggregateData> priceMap = tradesAggregateByPriceBySecBoard.computeIfAbsent(secBoardKey, k -> new HashMap<>());

        /* Ensuring to remove the trade in any other previous prices. This is required if a trade is amended with a
          new price value */
        List<BigDecimal> pricesToRemove = new ArrayList<>();
        priceMap.forEach((p, data) -> {
            if (!p.equals(price)) {
                boolean isEmpty = isMarketTrade ? data.removeMarketTrade(row) : data.removeTrade(row);
                if (isEmpty) {
                    pricesToRemove.add(p);
                }
            }
        });
        pricesToRemove.forEach(priceMap::remove);

        TradesOrDealsPriceAggregateData priceAggregateData = priceMap.computeIfAbsent(price, k -> new TradesOrDealsPriceAggregateData(price, userId, firmId));
        if (isMarketTrade) {
            priceAggregateData.addMarketTrade(row);
        } else {
            priceAggregateData.addTrade(row);
        }

        if (tradeUpdateNotifier != null) {
            tradeUpdateNotifier.run();
        }
    }
}
