package xfe.icap.modules.watchlist;

import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ObservableBooleanValue;
import javafx.scene.Node;
import javafx.stage.Window;

import xstr.types.OrderSide;
import xstr.amp.AsnAccessor;
import xfe.icap.XfeSession;
import xfe.layout.LayoutManager;
import xstr.session.ObservableReplyRow;

public class ImpliedInfoPopup extends InstrumentsInfoPopup {
   private final ImpliedQueryStruct query;
   final LayoutManager<Node> layoutManager;
	public ImpliedInfoPopup(
			Node infoShim,
			LayoutManager<Node> layoutManager,
			ImpliedQueryStruct query,
			OrderSide orderSide,
			InstrumentsFilters filters,
			ObservableBooleanValue showing,
         XfeSession session) {
		super(infoShim, layoutManager, query.secCode, orderSide, query.rate, query.quantity, query.getItems(), filters, showing,session);
		this.query = query;
		this.layoutManager = layoutManager;
		Window window = infoShim.getScene().getWindow();

		if (query.dataReady.get()) {
			layoutManager.register(this,null);
			show(window);
		} else {
			query.dataReady.addListener(new InvalidationListener() {
				@Override
				public void invalidated(Observable observable) {
					if (query.dataReady.get()) {
						layoutManager.register(ImpliedInfoPopup.this,null);
						show(window);
						query.dataReady.removeListener(this);
					}
				}
			});
		}
	}


	@Override
   public void dispose() {
      super.dispose();
      if (query != null) {
         query.dispose();
      }
      layoutManager.unregister(this);
   }


   public static void doPopup(
			Node infoShim,
			XfeSession session,
			LayoutManager<Node> layoutManager,
			ObservableReplyRow row,
			OrderSide orderSide,
			int orderImpliedType,
			AsnAccessor priceAcc,
			AsnAccessor qtyAcc,
			InstrumentsFilters tableFilters,
			ObservableBooleanValue showingInfoPopups) {
		try {
			ImpliedQueryStruct query = new ImpliedQueryStruct(
			      session, row, orderSide, orderImpliedType, priceAcc, qtyAcc);
			ImpliedInfoPopup infoPopup = new ImpliedInfoPopup(
					infoShim, layoutManager, query, orderSide, tableFilters, showingInfoPopups,session);

			// Last resort if auto-hide is broken
			infoPopup.setHideOnEscape(true);
		} catch (AmpPermissionException e) {
			e.printStackTrace();
		} catch (AsnTypeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
