package xfe.icap.modules.shortlist;

import javafx.scene.control.Button;
import xfe.ui.popover.PopOverOwner;

/**
 * Short list button which acts as owner for the {@link org.controlsfx.control.PopOver}.
 */
public class ShortlistButton extends Button implements PopOverOwner {
   public ShortlistButton(String name){
      super(name);
   }
}
