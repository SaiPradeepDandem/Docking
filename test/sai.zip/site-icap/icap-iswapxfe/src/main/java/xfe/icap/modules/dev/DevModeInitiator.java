package xfe.icap.modules.dev;

import javafx.scene.control.TextInputDialog;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import xfe.XfeAppModule;
import xfe.module.Module;
import xfe.module.ModuleViewerModule;
import xstr.util.Strings;
import xstr.util.concurrent.Future;

import java.time.LocalDate;

@Module.Autostart
public class DevModeInitiator implements Module {

   @ModuleDependency
   public XfeAppModule appModule;

   @Override
   public Future<Void> startModule() {
      appModule.getStage().addEventFilter(KeyEvent.KEY_PRESSED, ev -> {
         if(ev.getCode() == KeyCode.D && ev.isControlDown() && ev.isShiftDown()) {
            enableDevMode();
         }
      });
      return Future.SUCCESS;
   }

   private void enableDevMode() {

      TextInputDialog dialog = new TextInputDialog("");
      dialog.setTitle("Who goes There?");
      dialog.setHeaderText("Code Please...");
//      dialog.setContentText("Please enter your name:");

      dialog.showAndWait().ifPresent(this::startDevMode);
   }

   private void startDevMode(String code) {
      LocalDate dt = LocalDate.now();
      String a = Strings.reverse(String.format("%02d", dt.getDayOfMonth()));
      String b = Strings.reverse(String.format("%02d", dt.getMonthValue()));

      if (code.length() == 5 && code.startsWith(a) && code.endsWith(b)) {
         int level = Integer.valueOf(code.substring(2, 3));

         appModule.manualStartModule(ModuleViewerModule.class);
         appModule.manualStartModule(DevModule.class);
      }
   }
}
