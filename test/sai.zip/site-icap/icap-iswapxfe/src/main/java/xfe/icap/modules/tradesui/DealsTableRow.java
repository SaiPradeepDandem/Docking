package xfe.icap.modules.tradesui;

import javafx.scene.control.TableRow;
import xstr.session.ObservableReplyRow;

public class DealsTableRow extends TableRow<ObservableReplyRow> {
    DealsTableRow() {
        itemProperty().addListener((obs, previousRow, currentRow) -> {
            if (previousRow != null) {
                /* Setting the information for TestFX test cases */
                DealIdData.clearDealData(getProperties());
            }
            if (currentRow != null) {
                DealIdData.setDealData(getProperties(), currentRow);
            }
        });
    }
}
