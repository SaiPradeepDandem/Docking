package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.acc.AmpAccessor;

public class AmpActives extends AmpAccessor {
   public static final AMP.AmpQreq req = AMP.qREQ("activesReq");
   public static final AMP.AmpQrep rep = AMP.qREP("activesRep");

   public static final AsnConversionAccessor<String> secBoardId = acc(AMP.qREP("activesRep.secBoardId"), String.class);
   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("activesRep.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("activesRep.secBoardId.boardId"), String.class);
}
