package xfe.icap.modules.orderentry;

import com.nomx.persist.PersistantName;
import com.nomx.persist.linelist.Participant;
import com.objsys.asn1j.runtime.Asn1Choice;
import com.objsys.asn1j.runtime.Asn1Type;
import com.objsys.asn1j.runtime.Asn1ValueParseException;
import com.omxgroup.xstream.amp.AmpBoardId;
import com.omxgroup.xstream.amp.AmpSecBoardId;
import com.omxgroup.xstream.amp.AmpSecurityCode;
import com.omxgroup.xstream.amp.AmpStrategyDefinitionReply;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.beans.value.ObservableBooleanValue;
import javafx.scene.Node;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpCreateCustomSecBoard;
import xfe.icap.amp.AmpRfq;
import xstr.session.QueryReplyRow;
import xstr.session.XtrTransRequest;
import xstr.session.XtrTransRequestBuilder;
import xfe.icap.types.IcapSecurity;
import xfe.types.Security;
import xfe.util.Constants;
import xstr.util.Fx;
import xstr.util.Lazy;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.DisposableSlot;
import xstr.util.concurrent.Disposer;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.exception.XtrMessageException;
import xfe.util.scene.control.RotatorPane3;
import xfe.modules.appcontext.FxContext;
import xfe.util.Util;
import xfe.icap.XfeSession;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.layout.FxAbstractLayout;
import xfe.module.Module;
import xfe.modules.actions.ActionsModule;
import xfe.icap.modules.obbo.ObboModule;
import xfe.modules.orderentry.Command;
import xfe.modules.orderentry.Command.ActionType;
import xfe.icap.modules.orderentry.OrderEntryPane.ManagedOrderEntryPresenter;
import xfe.icap.modules.iswaporders.AmendOrdersModule;
import xfe.modules.session.SessionModule;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settings.SettingsUIModule;
import xfe.icap.modules.watchlist.WatchlistModule;
import xfe.ui.AcceleratorsPoint.AcceleratorEntry;
import xfe.ui.KeyboardNavigationModule;
import xfe.ui.notifications.ModalAlertModule;

import java.time.LocalDate;
import java.util.*;

@Module.Autostart
public class EntryModule extends SessionScopeModule implements Constants {
   private static final Logger logger = LoggerFactory.getLogger(EntryModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public FxContext jfxContextModule;
   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public DataContextModule dataContextModule;
   @ModuleDependency
   public ObboModule obboModule;
   @ModuleDependency
   public KeyboardNavigationModule keyboardNavigationModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public SettingsUIModule settingsUIModule;
   @ModuleDependency
   public ModalAlertModule modalAlertModule;
   @ModuleDependency
   public WatchlistModule watchlistModule;
   @ModuleDependency
   public ActionsModule actionsModule;
   @ModuleDependency
   public AmendOrdersModule amendOrdersModule;

   private Double getDefaultSize(){
      return selectionContextModule.secBoardContext.get().isStrategyPropertyRO.get() ? settingsUIModule.prefs.strategyDefaultQty().get() : settingsUIModule.prefs.outrightDefaultQty().get();
   }

   private void setPaneHeader(boolean getSec) {
      if(!xfeSessionModule.getUnderlyingSession().isLoggedOnTrader()) return;
      startTime.setText("");
      maturityTime.setText("");
      rfqPresenter.get().setPendingDates(true);
      orderEntryPane.get().setInfoText("");
      if (getSec) {
         security = dataContextModule.selectedSecurity().getValue();
      }

      if (showOrderPaneProperty.getValue()) { // Order Entry Tab
         // setting static date fields
         startTimeHolder.getChildren().setAll(startTime);
         maturityTimeHolder.getChildren().setAll(maturityTime);


         // If an RFQ instrument is selected, in order entry panel where we used to display the seccode
         // we should instead display “RFQ for <TRADER> at <FIRM>”.
         // If the RFQ is anonymous simply say “RFQ”.
         for (QueryReplyRow activeRfqRow : xfeSessionModule.rfqs.get().activeRfqs.get()) {
            String rfqSecCode = activeRfqRow.getValue(AmpRfq.secCode);
            if (security != null && Objects.equals(security.getSecCode(), rfqSecCode)) {
               Boolean isAnon = activeRfqRow.getValue(AmpRfq.isAnonymous);
               if (isAnon) {
                  orderEntryPane.get().setInfoText("RFQ");
               } else {
                  String traderId = activeRfqRow.getString(AmpRfq.userId);
                  String groupId = activeRfqRow.getString(AmpRfq.groupId);
                  orderEntryPane.get().setInfoText("RFQ for " + traderId + " at " + groupId);
               }
               break;
            }
         }
      } else { // RFQ Tab
         // setting editable date fields
         startTimeHolder.getChildren().setAll(startTimeDatePicker);
         maturityTimeHolder.getChildren().setAll(maturityTimePicker);
      }


      if (security != null) {
         secCode.setText("  " + security.getSecCode());
         xfeSessionModule.secBoards.get().getFirstBySecCode(security.getSecCode()).flatMap(secBoard -> {
            if (secBoard != null) {
               // rfq always needs these values
               rfqStartDate = security.getIssueDate();
               rfqEndDate = secBoard.getMaturityDate();
               rfqPresenter.get().setPendingDates(false);

               if (showOrderPaneProperty.getValue()) { // Order Entry Tab

                  // If the selected instrument has bespoked dates (even if not an RFQ) display above “size” to
                  // the far RHS of the order entry panel the start and maturity dates in the format
                  // “Start: DD/MM/YYYY Maturity: DD/MM/YYYY”. This will be a text label, not a data entry box.
                  // Set up the static date fields
                  if (security.getParentSecCode() != null) {
                     startTime.setText(Util.formatDate(rfqStartDate));
                     maturityTime.setText(Util.formatDate(rfqEndDate) + "  ");
                  }
               } else { // RFQ Tab
                  // In the title bar of the RFQ dialog, next to the instrument Id,
                  // will be two boxes, one for Issue date (labelled ‘Start’), and one for Mat Date (labelled ‘Mat’).
                  // They will initially contain the start and maturity date of the selected secboard respectively.

                  // Set up the editable date controls
                  if (rfqStartDate != null) {
                     calendar.setTime(rfqStartDate);
                     startTimeDatePicker.setValue(LocalDate.of(calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH) + 1,
                        calendar.get(Calendar.DAY_OF_MONTH)));
                  } else
                     startTimeDatePicker.setValue(null);

                  if (rfqEndDate != null) {
                     calendar.setTime(rfqEndDate);
                     maturityTimePicker.setValue(LocalDate.of(calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH) + 1,
                        calendar.get(Calendar.DAY_OF_MONTH)));
                  } else
                     maturityTimePicker.setValue(null);
               }
               return Future.SUCCESS;
            }
            return Future.valueOf(null);
         });
      }
   }

   public void registerActionHandler(ActionType actionType, Command command){
      orderEntryPresenter.get().registerActionHandler(actionType, command);
   }

   public void deregisterActionHandler(ActionType actionType, Command command){
      orderEntryPresenter.get().deregisterActionHandler(actionType, command);
   }

   @Override
   public Future<Void> startModule() {
      selectionContextModule.addOnDoubleClicked(this::setFocusOnRateEdit);
      amendOrdersModule.isTicking.setValue(false);
      showOrderPaneProperty.setValue(true);
      showRfqPaneProperty.setValue(false);
      xfeSessionModule.setEntryModule(this);
      Disposer disposer = disposerSlot.get();
      // Order Entry
//      disposer.disposes(Fx.bindBidirectional(orderEntryPane.get().advSelectedProperty(),xfeSessionModule.getParametersStorage().get(PersistantName.OrderEntryPaneAdvSelect, false)));
      tracker.bindBidirectional(orderEntryPane.get().advSelectedProperty(), configurationModule.getParametersStorage().get(PersistantName.OrderEntryPaneAdvSelect, false));
//      disposer.disposes(Fx.bind(orderEntryPresenter.get().selectionContextProperty(), selectionContextModule.selectionContextProperty()));
      tracker.bind(orderEntryPresenter.get().selectionContextProperty(), selectionContextModule.selectionContextProperty());

      tracker.addListener(selectionContextModule.secBoardContext.get().rowProperty(), (observable, oldValue, newValue) -> {
         if (newValue != null) {
            security = new IcapSecurity(newValue);
            setPaneHeader(false);
         }
      });

      tracker.addListener(showOrderPaneProperty, observable -> {
         setPaneHeader(true);
      });

      if(xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker()) {
         InvalidationListener selectedTraderLis = new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
               Participant participant = xfeSessionModule.onBehalfTrader.get();
               orderEntryPane.get().setInfoText(participant==null ? "": participant.getId());
            }
         };
         tracker.addListener(xfeSessionModule.onBehalfTrader, selectedTraderLis);
         Fx.runLater(()->selectedTraderLis.invalidated(null));
      }

      tracker.addListener(obboModule.readOnlyPickupPrice, observable -> {
         double p = obboModule.readOnlyPickupPrice.get();
         if (Double.MIN_VALUE != p) {
            rateEditProperty.get().set(p);
         }
      });

      tracker.addListener(obboModule.readonlyPriceEntryNeedFocus, observable1 -> {
         Fx.runLater(EntryModule.this::setFocusOnRateEdit);
      });
      tracker.addListener(obboModule.readOnlyPickupQuantity, observable -> {
         if(settingsUIModule.prefs.yoursMineDefaultAmount().get()){
            sizeEditProperty.get().setValue(getDefaultSize());
         }else {
            sizeEditProperty.get().setValue(obboModule.readOnlyPickupQuantity.get());
         }
      });
//      disposer.disposes(Fx.bind(orderEntryPresenter.get().amendableOrderProperty(), Bindings.when(Bindings.isEmpty(dataContextModule.getAmendableOrders())).then((ObservableReplyRow) null).otherwise(Fx.valueAt(dataContextModule.getAmendableOrders(), 0))));

      tracker.addListener(dataContextModule.getAmendableOrders(), (Observable observable) -> {
         if (dataContextModule.getAmendableOrders().isEmpty()) {
            orderEntryPresenter.get().amendableOrderProperty().set(null);
         } else {
            orderEntryPresenter.get().amendableOrderProperty().set(dataContextModule.getAmendableOrders().get(0));
         }
      });

      // Request for quote
//      disposer.disposes(Fx.bind(rfqPresenter.get().selectionContextProperty(), selectionContextModule.selectionContextProperty()));
      tracker.bind(rfqPresenter.get().selectionContextProperty(), selectionContextModule.selectionContextProperty());
//      disposer.disposes(Fx.bind(rfqPresenter.get().amendableOrderProperty(),Bindings.when(Bindings.isEmpty(dataContextModule.getAmendableOrders())).then((ObservableReplyRow) null).otherwise(Fx.valueAt(dataContextModule.getAmendableOrders(), 0))));

      // Entry Pane
      entryPane.get().setId("xfe-managed-order-entry-view");

      actionsModule.addEditOrderListener(action -> setFocusOnRateEdit());
      layoutModule.addView(entryPane.get());
      disposer.runs(() -> layoutModule.removeView(entryPane.get()));
      registerAccelerators();
      InvalidationListener lis = observable -> {
         Double rtn;
         if (obboModule.updatedPrice.get() != null && amendOrdersModule.isTicking.get()) {
            rtn = obboModule.updatedPrice.get();
         } else{
            rtn = null;
         }
         tickUpDownNewVal.setValue(rtn);
      };
      tracker.addListener(amendOrdersModule.isTicking,lis);
      tracker.addListener(obboModule.updatedPrice, lis);

      tracker.addListener(obboModule.rfsPriceOverride,((arg0, arg1, arg2) -> {
         if (arg2 != null) {
            //orderEntryPresenter.get().setPrice(arg2);
            orderEntryPresenter.get().setImmediate(true);
         }
      }));

//      tracker.addListener(obboModule.rfsQtyOverride,((arg0, arg1, arg2) -> {
//         if (arg2 != null) {
//            orderEntryPresenter.get().setSize(arg2);
//         }
//      }));

      tracker.addListener(tickUpDownNewVal,((arg0, arg1, arg2) -> {
         if (arg1 == null)
            return;

         if (arg2 != null) {
            orderEntryPresenter.get().setPrice(arg2);
            amendOrdersModule.isTicking.setValue(false);
         }
      }));

      tracker.addListener(selectionContextModule.secBoardContext.get().bestBidProperty(), (arg0, arg1, arg2) -> {
         if (arg2 != null && amendOrdersModule.isTicking.getValue() && selectionContextModule.gridTypeProperty.get().getValue() == GridType.Watchlist) {
            orderEntryPresenter.get().setPrice(arg2);
            amendOrdersModule.isTicking.setValue(false);
         }
      });


      tracker.addListener(selectionContextModule.secBoardContext.get().bestOfferProperty(), (arg0, arg1, arg2) -> {
         if (arg2 != null && amendOrdersModule.isTicking.getValue() && selectionContextModule.gridTypeProperty.get().getValue() == GridType.Watchlist) {
            orderEntryPresenter.get().setPrice(arg2);
            amendOrdersModule.isTicking.setValue(false);
         }
      });

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      xfeSessionModule.setEntryModule(null);
      secCode.setText("");
      uninitializeContents();
      security = null;
      return Future.SUCCESS;
   }

   void rotateToOrderEntry() {
      showOrderPaneProperty.setValue(true);
   }

   void setFocusOnRateEdit() {
      orderEntryPane.get().requestFocusOnRateEdit();
   }

   Future<AmpSecBoardId> doBespoke(String secCode, String boardId, boolean isRfsSession) {
      if(selectionContextModule.dataContextRfsSec.get() && isRfsSession){
         try {
            return Future.valueOf(new AmpSecBoardId(new AmpSecurityCode(secCode),new AmpBoardId(boardId)));
         } catch (Asn1ValueParseException e) {
            return Future.valueOf(null);
         }
      }
      LocalDate localStartdate = startTimeDatePicker.getValue();
      calendar.clear();
      calendar.set(localStartdate.getYear(), localStartdate.getMonthValue() - 1, localStartdate.getDayOfMonth());
      Date editableStartDate = calendar.getTime();
      LocalDate localEndDate = maturityTimePicker.getValue();
      calendar.clear();
      calendar.set(localEndDate.getYear(), localEndDate.getMonthValue() - 1, localEndDate.getDayOfMonth());
      Date editableEndDate = calendar.getTime();

      try {
         if (security == null || (Objects.equals(rfqStartDate, editableStartDate) && Objects.equals(rfqEndDate, editableEndDate))) {
            AmpSecBoardId defaultSecBoard = new AmpSecBoardId();
            defaultSecBoard.setSecCode(new AmpSecurityCode(secCode));
            defaultSecBoard.setBoardId(new AmpBoardId(boardId));
            return Future.valueOf(defaultSecBoard);
         }

         XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(AmpCreateCustomSecBoard.txn, xfeSessionModule.getUnderlyingSession());
         XtrTransRequest trans = reqBuilder.set(AmpCreateCustomSecBoard.parentSecCode, security.getSecCode())
            .set(AmpCreateCustomSecBoard.parentBoardId, security.getBoardId())
            .set(AmpCreateCustomSecBoard.startDate, editableStartDate)
            .set(AmpCreateCustomSecBoard.endDate, editableEndDate).build();
         return xfeSessionModule.getUnderlyingSession().execute(trans).map(transReply -> {
            Asn1Choice replyChoice = transReply.getReplyChoice();
            Asn1Type replyElement = replyChoice.getElement();

            if (replyElement instanceof AmpStrategyDefinitionReply) {
               AmpStrategyDefinitionReply reply = (AmpStrategyDefinitionReply)replyElement;
               return reply.getSecBoardId();
            } else {
               throw new XtrMessageException("Bespoking failed");
            }
         });
      } catch (Exception e) {
         return Futures.error(e);
      }
   }

   private void uninitializeContents() {
      unregisterAccelerators();
      disposerSlot.disposeAndSet(new Disposer());
   }

   private void registerAccelerators() {
      Map<KeyCombination, AcceleratorEntry> accelerators = jfxContextModule.getAcceleratorsPoint().getAccelerators();

      accelerators.put(new KeyCodeCombination(KeyCode.B, KeyCombination.ALT_DOWN), new AcceleratorEntry(orderEntryPane.get().bidAction.get(), true));
      accelerators.put(new KeyCodeCombination(KeyCode.O, KeyCombination.ALT_DOWN), new AcceleratorEntry(orderEntryPane.get().offerAction.get(), true));
      accelerators.put(new KeyCodeCombination(KeyCode.M, KeyCombination.ALT_DOWN), new AcceleratorEntry(orderEntryPane.get().mineAction.get(), true));
      accelerators.put(new KeyCodeCombination(KeyCode.Y, KeyCombination.ALT_DOWN), new AcceleratorEntry(orderEntryPane.get().yoursAction.get(), true));
   }

   private void unregisterAccelerators() {
      Map<KeyCombination, AcceleratorEntry> accelerators = jfxContextModule.getAcceleratorsPoint().getAccelerators();
      accelerators.remove(new KeyCodeCombination(KeyCode.B, KeyCombination.ALT_DOWN));
      accelerators.remove(new KeyCodeCombination(KeyCode.O, KeyCombination.ALT_DOWN));
      accelerators.remove(new KeyCodeCombination(KeyCode.M, KeyCombination.ALT_DOWN));
      accelerators.remove(new KeyCodeCombination(KeyCode.Y, KeyCombination.ALT_DOWN));
   }
   public final BooleanProperty rateEditorNeedFocused = new SimpleBooleanProperty(); //dealing with rfq table selection.
   final StringProperty validatedSizeProperty = new SimpleStringProperty("");
   final Property<Boolean> showOrderPaneProperty = new SimpleBooleanProperty(true);
   final BooleanProperty showRfqPaneProperty = new SimpleBooleanProperty(false);
   private final ListenerTracker tracker = new ListenerTracker();
   private final Calendar calendar = Calendar.getInstance(Locale.getDefault());
   private final ObjectProperty<Double> tickUpDownNewVal = new SimpleObjectProperty<>();
   private final DisposableSlot<Disposer> disposerSlot = new DisposableSlot<>(new Disposer());
   public final Lazy<ManagedOrderEntryPresenter> orderEntryPresenter = new Lazy<ManagedOrderEntryPresenter>() {
      @Override
      protected ManagedOrderEntryPresenter initialize() {
         disposerSlot.get().resets(this);
         ManagedOrderEntryPresenter presenter = orderEntryPane.get().getPresenter();
         presenter.setSession(xfeSessionModule);
         return presenter;
      }
   };
   private final ObjectProperty<Double> rateProperty = new SimpleObjectProperty<>(0.0);
   public final Lazy<ObjectProperty<Double>> rateEditProperty = new Lazy<ObjectProperty<Double>>() {
      @Override
      protected ObjectProperty<Double> initialize() {
         disposerSlot.get().resets(this);
         return rateProperty;
      }
   };
   private final ObjectProperty<Double> sizeProperty = new SimpleObjectProperty<>(0.0);
   final Lazy<ObjectProperty<Double>> sizeEditProperty = new Lazy<ObjectProperty<Double>>() {
      @Override
      protected ObjectProperty<Double> initialize() {
         disposerSlot.get().resets(this);
         return sizeProperty;
      }
   };
   public final Lazy<OrderEntryPane> orderEntryPane = new Lazy<OrderEntryPane>() {

      @Override
      protected OrderEntryPane initialize() {
         Disposer disposer = disposerSlot.get();
         disposer.resets(this);
         OrderEntryPane oePane = OrderEntryPane.load(configurationModule.getData(), EntryModule.this,
            tracker,
            sessionModule,
            settingsUIModule, modalAlertModule, dataContextModule, selectionContextModule, keyboardNavigationModule);
         oePane.setUnlockHandler((pwd) -> xfeSessionModule.getUnderlyingSession().unlock(pwd));
         return oePane;
      }
   };
   private final ObjectProperty<Double> rfqSizeProperty = new SimpleObjectProperty<>(0.0);
   final Lazy<ObjectProperty<Double>> rfqSizeEditProperty = new Lazy<ObjectProperty<Double>>() {
      @Override
      protected ObjectProperty<Double> initialize() {
         disposerSlot.get().resets(this);
         return rfqSizeProperty;
      }
   };
   private final Lazy<RfqPane> rfqPane = new Lazy<RfqPane>() {
      @Override
      protected RfqPane initialize() {
         Disposer disposer = disposerSlot.get();
         disposer.resets(this);
         RfqPane rp = disposer.disposes(RfqPane.load(configurationModule.getData(), EntryModule.this, selectionContextModule.secBoardContext.get(), xfeSessionModule));
         rp.setUnlockHandler((pwd) -> xfeSessionModule.getUnderlyingSession().unlock(pwd));
         return rp;
      }
   };
   public final Lazy<RfqPresenter> rfqPresenter = new Lazy<RfqPresenter>() {
      @Override
      protected RfqPresenter initialize() {
         disposerSlot.get().resets(this);
         RfqPresenter presenter = new RfqPresenter(xfeSessionModule, sessionModule,EntryModule.this, settingsUIModule, modalAlertModule,selectionContextModule,dataContextModule,rfqPane.get()) {
            @Override
            public ObservableBooleanValue unlockViewVisibleProperty() {
               return sessionModule.lockedProperty().and(sessionModule.safeModeProperty().not());
            }
         };

         presenter.initView();
         return presenter;
      }
   };
   private final StackPane startTimeHolder = new StackPane();
   private final Label startTime = new Label("");
   private final DatePicker startTimeDatePicker = new DatePicker(LocalDate.now());
   private final StackPane maturityTimeHolder = new StackPane();
   private final Label maturityTime = new Label("");
   private final DatePicker maturityTimePicker = new DatePicker() ;
   private final Label secCode = new Label();
   private final Lazy<VBox> entryPane = new Lazy<VBox>() {
      @Override
      protected VBox initialize() {
         /**/
         disposerSlot.get().resets(this);
         Disposer disposer = disposerSlot.get();

         ToggleGroup group = new ToggleGroup();
         ToggleButton showOrderPaneButton = new ToggleButton("Order");
         showOrderPaneButton.getStyleClass().add("xfe-orderentry-tab-button");
         ToggleButton showRFQPaneButton = new ToggleButton("RFQ");
         showOrderPaneButton.setMinWidth(TITLE_BUTTON_WIDTH);
         showRFQPaneButton.setMinWidth(TITLE_BUTTON_WIDTH);
         showRFQPaneButton.getStyleClass().add("xfe-orderentry-tab-button");

         HBox banner = new HBox();
         banner.getStyleClass().add("entry-banner-bg");

         showOrderPaneButton.setToggleGroup(group);
         showRFQPaneButton.setToggleGroup(group);

         showOrderPaneButton.disableProperty().bind(showOrderPaneButton.selectedProperty());
         showOrderPaneButton.selectedProperty().bindBidirectional(showOrderPaneProperty);
         showRFQPaneButton.disableProperty().bind(showRFQPaneButton.selectedProperty());
         showRFQPaneButton.selectedProperty().bindBidirectional(showRfqPaneProperty);
//         disposer.disposes(Fx.bindBidirectional(rfqPane.get().getRootElement().expandedProperty(), showRFQPaneButton.selectedProperty()));
//         disposer.disposes(Fx.bindBidirectional(orderEntryPane.get().getRootElement().expandedProperty(), showOrderPaneButton.selectedProperty()));
         HBox buttonBox = new HBox();

         Label start = new  Label("Start");
         start.setMinWidth(30);
         Pane sprintpane= new Pane();
         HBox.setHgrow(sprintpane, Priority.ALWAYS);
         tracker.bind(start.visibleProperty(), Bindings.or(Bindings.isNotEmpty(startTime.textProperty()), showRfqPaneProperty));
         Label maturity = new Label("Maturity");
         maturity.setMinWidth(50);
         tracker.bind(maturity.visibleProperty(), Bindings.or(Bindings.isNotEmpty(maturityTime.textProperty()), showRfqPaneProperty));
         HBox.setHgrow(banner, Priority.ALWAYS);
         banner.getChildren().addAll(secCode, sprintpane, start, startTimeHolder, maturity, maturityTimeHolder);

         buttonBox.getStyleClass().add("entry-banner");
         buttonBox.getStyleClass().add("xfe-titled-pane");
         showOrderPaneButton.toFront();
         if (configurationModule.getData().hideRfqPaneProperty().get())
            buttonBox.getChildren().addAll(showOrderPaneButton, banner);
         else {
            buttonBox.getChildren().addAll(showOrderPaneButton,showRFQPaneButton, banner);
         }
         startTimeDatePicker.setMinWidth(100);
         startTimeDatePicker.setPrefWidth(100);
         maturityTimePicker.setMinWidth(100);
         maturityTimePicker.setPrefWidth(100);
         disposer.disposes(Fx.addListener(configurationModule.getData().hideRfqPaneProperty(), arg0 -> {
            List<Node> nodes = buttonBox.getChildren();
            if (configurationModule.getData().hideRfqPaneProperty().get()) {
               nodes.remove(showRFQPaneButton);
               showOrderPaneButton.setSelected(true);
            } else {
               if (!nodes.contains(showRFQPaneButton)) {
                  nodes.add(1, showRFQPaneButton);
               }
            }
         }));

         RotatorPane3 contentPane = new RotatorPane3();
         try {
            StackPane orderEntry = orderEntryPane.get().getRootElement();
            StackPane rfq = rfqPane.get().getRootElement();
            contentPane.addNode(orderEntry);
            contentPane.addNode(rfq);
            contentPane.doRotate();
//            contentPane.prefHeightProperty().bind(Bindings.when(showOrderPaneButton.selectedProperty()).then(orderEntry.prefHeightProperty()).otherwise(rfq.prefHeightProperty()));
         } catch (Exception e) {
            logger.error("add order entry pane and rfq pane wrong",e);
         }


         showOrderPaneButton.selectedProperty().addListener(observable -> {
            if(showOrderPaneButton.selectedProperty().get()){
               contentPane.rotate();
            }
         });
         showRFQPaneButton.selectedProperty().addListener(observable -> {
            if (showRFQPaneButton.selectedProperty().get()) {
               contentPane.rotate();
            }
         });
         VBox entryPane = new VBox();

         entryPane.getChildren().addAll(buttonBox, contentPane);

         return entryPane;
      }
   };
   private  Security security;
   private  Date rfqStartDate;
   private  Date rfqEndDate;
}
