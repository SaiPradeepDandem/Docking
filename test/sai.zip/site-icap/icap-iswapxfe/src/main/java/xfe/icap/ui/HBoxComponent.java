package xfe.icap.ui;

import javafx.beans.property.*;
import javafx.scene.Node;
import javafx.scene.layout.*;

import xfe.ui.splitpane.XfeSplitComponent;
import xfe.ui.splitpane.XfeSplitPane;

public class HBoxComponent extends HBox implements XfeSplitComponent {
	Node NOT_READY = new Region();

	private XfeSplitComponent component;

	@Override
	public BooleanProperty expandProperty() {
		if(component==null){
			return TRUE;
		}else{
			return component.expandProperty();
		}
	}

	@Override
	public BooleanProperty fullSizeProperty() {
		if(component==null){
			return FALSE;
		}else{
			return component.fullSizeProperty();
		}
	}

	@Override
	public BooleanProperty displayProperty() {
		if(component==null){
			return TRUE;
		}else{
			return component.displayProperty();
		}
	}

	@Override
	public Node getNode() {
		if(component==null){
			return NOT_READY;
		}else{
			return component.getNode();
		}
	}
	@Override
	public DoubleProperty sizeProperty() {
		if(component==null){
			return FIX_SIZE;
		}else{
			return component.sizeProperty();
		}
	}

	public void setOperatableComponent(XfeSplitComponent com, XfeSplitPane<? extends XfeSplitComponent> splitPane){
		component = com;
		splitPane.componentUpdated();
	}

   public void clearComponent() {
      component = null;
   }

	@Override
	public double resizingMin() {
		if(component==null){
			return -1;
		}else{
			return component.resizingMin();
		}
	}

}
