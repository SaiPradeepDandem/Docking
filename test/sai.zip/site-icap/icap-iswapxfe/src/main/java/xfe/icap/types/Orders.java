package xfe.icap.types;

import com.nomx.domain.types.DefaultDurationType;
import com.nomx.domain.types.OnLogoffAction;
import com.omxgroup.xstream.amp.AmpActionOnLogoff;
import com.omxgroup.xstream.amp.AmpOrderDuration;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpOrderAmendAcc;
import xfe.icap.amp.AmpOrderBookByOrder;
import xfe.icap.modules.iswaporders.OrderFilters;
import xfe.ui.notifications.ModalAlertModule;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.AsnField;
import xstr.session.*;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xstr.util.*;
import xstr.util.collection.ObservableCollections;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.function.Consumer;

import static xstr.util.Fx.emptyNull;

public class Orders {
   private static final Logger logger = LoggerFactory.getLogger(Orders.class);

   private final BooleanProperty readyProperty = new SimpleBooleanProperty(false);
   public final ObservableList<ObservableReplyRow> allOrders;
   private final ObservableList<ObservableReplyRow> openOrders;
   public final ObservableList<ObservableReplyRow> rfqExpiredOrders;
   private final BooleanProperty ordersUpdated = new SimpleBooleanProperty(false);
   private final ObservableMap<Tuple2<String, String>, ObservableList<ObservableReplyRow>> openOrdersBySecBoard;

   public static final String AGGRESSOR = "AGG";
   public static final String CLOB = "CLOB";
   public static final String CM = "CM";
   public static final String ORDER_TAG_KEY = "orderTag";

   /**
    * Map accessors from the ASN field in the amend source to the corresponding field
    * in the order amend transaction. Since Orders can be amended from various sources
    * (e.g AmpOrderRep, AmpManagedOrderRep), this map can contain source accessors
    * from more than one source row type.
    */
   private static final HashMap<AsnConversionAccessor<?>, AsnConversionAccessor<?>> amendMap = new HashMap<>();

   private static <T> void mapAmendField(AsnConversionAccessor<T> from, AsnConversionAccessor<T> to) {
      amendMap.put(from, to);
   }

   @SuppressWarnings("unchecked")
   private static <T> AsnConversionAccessor<T> getAmendAcc(AsnConversionAccessor<T> from) {
      return (AsnConversionAccessor<T>) amendMap.get(from);
   }


   static int durationTypeToAmp(DefaultDurationType dt) {
      switch (dt) {
         case IMMEDIATE:
            return AmpOrderDuration.immediate;
         case GOOD_TILL_CANCELLED:
            return AmpOrderDuration.goodTillCancelled;
         case GOOD_TILL_DAY:
            return AmpOrderDuration.day;
         case GOOD_TILL_DURATION:
            return AmpOrderDuration.goodTillDuration;
         default:
            logger.error("Unable to convert duration type: {}", dt);
            return durationTypeToAmp(DefaultDurationType.Default);
      }
   }

   static DefaultDurationType durationTypeFromAmp(int dt) {
      switch (dt) {
         case AmpOrderDuration.immediate:
            return DefaultDurationType.IMMEDIATE;
         case AmpOrderDuration.goodTillCancelled:
            return DefaultDurationType.GOOD_TILL_CANCELLED;
         case AmpOrderDuration.day:
            return DefaultDurationType.GOOD_TILL_DAY;
         case AmpOrderDuration.goodTillDuration:
            return DefaultDurationType.GOOD_TILL_DURATION;
         default:
            logger.error("Unable to convert duration type: {}", dt);
            return DefaultDurationType.Default;
      }
   }

   static int actionOnLogoffToAmp(OnLogoffAction action) {
      switch (action) {
         case NONE:
            return AmpActionOnLogoff.logoffNone;
         case REFER:
            return AmpActionOnLogoff.logoffPrivateOB;
         case WITHDRAW:
            return AmpActionOnLogoff.logoffWithdraw;
         default:
            logger.error("Unable to convert logoff action: {}", action);
            return actionOnLogoffToAmp(OnLogoffAction.Default);
      }
   }

   static OnLogoffAction actionOnLogoffFromAmp(int logoffAction) {
      switch (logoffAction) {
         case AmpActionOnLogoff.logoffNone:
            return OnLogoffAction.NONE;
         case AmpActionOnLogoff.logoffPrivateOB:
            return OnLogoffAction.REFER;
         case AmpActionOnLogoff.logoffWithdraw:
            return OnLogoffAction.WITHDRAW;
         default:
            logger.error("Unable to convert logoff action: {}", logoffAction);
            return OnLogoffAction.Default;
      }
   }

   static {
      // When Amending from ManagedOrderRep
      mapAmendField(AmpManagedOrder.price_d, AmpOrderAmendAcc.price);
      mapAmendField(AmpManagedOrder.balance_d, AmpOrderAmendAcc.currentBalance);
      mapAmendField(AmpManagedOrder.quantity_d, AmpOrderAmendAcc.quantity);
      mapAmendField(AmpManagedOrder.durationTime, AmpOrderAmendAcc.durationTime);
      mapAmendField(AmpManagedOrder.durationType, AmpOrderAmendAcc.durationType);
      mapAmendField(AmpManagedOrder.shared, AmpOrderAmendAcc.shared);
      mapAmendField(AmpManagedOrder.minFillQuantity, AmpOrderAmendAcc.minFillQuantity);
      mapAmendField(AmpManagedOrder.actionOnLogoff, AmpOrderAmendAcc.actionOnLogoff);
      mapAmendField(AmpManagedOrder.isPublic, AmpOrderAmendAcc.isPublic);
      mapAmendField(AmpManagedOrder.visibleQuantity, AmpOrderAmendAcc.visibleQuantity);

   }

   private static Fun1<ObservableReplyRow, ManagedOrder> managedOrderCallback() {
      return new Fun1<ObservableReplyRow, ManagedOrder>() {
         public ManagedOrder call(ObservableReplyRow row) {
            return new ManagedOrder(row);
         }
      };
   }

   public ObservableList<ObservableReplyRow> getOpenOrdersForSecBoard(Tuple2<String, String> secBoard) {
      return emptyNull(Fx.valueAt(openOrdersBySecBoard, secBoard));
   }

   public ObservableMap<Tuple2<String, String>, ObservableList<ObservableReplyRow>> openOrdersBySecBoard() {
      return openOrdersBySecBoard;
   }

   public Orders(ServerSession session, ListenerTracker tracker) {
      FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpManagedOrder.rep, new ObservableRowFactory());
      QueryFeed feed = session.getFeedSource(AmpManagedOrder.req);
      tracker.addFeedListener(feed, aggregator);
      tracker.bind(readyProperty, aggregator.busyProperty().not());
      tracker.bind(ordersUpdated, aggregator.updateProperty());
      this.allOrders = aggregator.items;
      ObservableList<ManagedOrder> managedOrders = Fx.map(allOrders, managedOrderCallback());
      this.openOrders = ObservableCollections.filter(allOrders, OrderFilters.isOpen, tracker);
      rfqExpiredOrders = ObservableCollections.filter(allOrders, OrderFilters.isRfqExpiredOrder, tracker);
      ObservableList<ManagedOrder> managedOpenOrders = Fx.map(openOrders, managedOrderCallback());
      ordersUpdated.addListener((observable, oldValue, newValue) -> {
         //do nothing here. Since we do not care that's the value it changed to. we need the dummy changelistener
      });

      if (logger.isTraceEnabled()) {

         allOrders.addListener((ListChangeListener<ObservableReplyRow>) c -> {
            while (c.next()) {
               logger.trace("all orders added {}", c.getAddedSubList());
            }
         });

         rfqExpiredOrders.addListener((ListChangeListener<ObservableReplyRow>) c -> {
            while (c.next()) {
               logger.trace("rfq finished orders: {}", c.getAddedSubList());
            }
         });
      }


      this.openOrdersBySecBoard = Fx.unmodifiable(Fx.groupBy(openOrders, new Fun1<ObservableReplyRow, Tuple2<String, String>>() {
         @Override
         public Tuple2<String, String> call(ObservableReplyRow row) {
            return row.getValue(AmpManagedOrder.secCode, AmpManagedOrder.boardId);
         }
      }));
   }

   public void findAllOrdersByFilter(StaticFilter<ObservableReplyRow> filter, Proc1<List<ObservableReplyRow>> replyHandler) {
      if (!readyProperty.get()) {
         readyProperty.addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(
               ObservableValue<? extends Boolean> observableReady,
               Boolean oldReady,
               Boolean newReady) {
               if (newReady) {
                  readyProperty.removeListener(this);
                  replyHandler.call(getAllOrdersByFilter(filter));
               }
            }
         });
      } else {
         replyHandler.call(getAllOrdersByFilter(filter));
      }
   }

   private List<ObservableReplyRow> getAllOrdersByFilter(StaticFilter<ObservableReplyRow> filter) {
      ArrayList<ObservableReplyRow> filteredOrders = new ArrayList<>();

      for (ObservableReplyRow order : allOrders) {
         try {
            if (filter.accept(order)) {
               filteredOrders.add(order);
            }
         } catch (Exception e) {
            e.printStackTrace();
         }
      }

      return filteredOrders;
   }

   public ReadOnlyBooleanProperty dataUpdateProperty() {
      return ordersUpdated;
   }

   private static <T> XtrTransRequestBuilder amend(XtrTransRequestBuilder reqBuilder, AsnField<T> field) throws AsnTypeException {
      AsnConversionAccessor<T> acc = getAmendAcc(field.acc);
      if (acc != null)
         return reqBuilder.set(getAmendAcc(field.acc), field.val);
      else {
         logger.error("Unable to map to orderAmend field from {}", field.acc.getAccessSpec());
         return reqBuilder;
      }
   }

   public static void amend(ServerSession session,
                            Consumer<String> errorHandler,
                            ObservableReplyRow orderRow,
                            Collection<AsnField<?>> fields,
                            ReplyHandler<XtrTransReply> replyHandler) throws AsnTypeException, AmpPermissionException {
      ArrayList<AsnField<?>> changedFields = buildChangedFields(orderRow,fields);
      if (changedFields.isEmpty()) {
         errorHandler.accept("Nothing to amend");
      } else {
         XtrTransRequestBuilder reqBuilder = buildRequestBuilder(orderRow,session);
         for (AsnField<?> field : changedFields) {
            reqBuilder = amend(reqBuilder, field);
         }
         replyHandler.call(session.execute(reqBuilder.build()));
      }
   }

   public static void amend(XfeSession xfeSession,
                            ModalAlertModule notifier,
                            QueryReplyRow orderRow,
                            Collection<AsnField<?>> fields,
                            ReplyHandler<XtrTransReply> replyHandler) throws AsnTypeException, AmpPermissionException {
      ServerSession session = xfeSession.getUnderlyingSession();
      ArrayList<AsnField<?>> changedFields = buildChangedFields(orderRow,fields);
      if (changedFields.isEmpty()) {
         notifier.showError("Nothing to amend");
      } else {
         XtrTransRequestBuilder reqBuilder = buildRequestBuilder(orderRow,session);
         for (AsnField<?> field : changedFields) {
            reqBuilder = amend(reqBuilder, field);
         }
         session.execute(reqBuilder.build(), replyHandler);
      }
   }

   private static ArrayList<AsnField<?>> buildChangedFields(QueryReplyRow orderRow, Collection<AsnField<?>> fields) {
      ArrayList<AsnField<?>> changedFields = new ArrayList<>();
      for (AsnField<?> field : fields) {
         if (field.val == null) {
            if (orderRow.getValue(field.acc) != null) {
               changedFields.add(field);
            }
         } else if (!field.val.equals(orderRow.getValue(field.acc)))
            changedFields.add(field);
      }
      return changedFields;
   }

   private static XtrTransRequestBuilder buildRequestBuilder(QueryReplyRow orderRow, ServerSession session) throws AsnTypeException, AmpPermissionException {
      XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(AmpOrderAmendAcc.txn, session)
         .setAsn(AmpOrderAmendAcc.orderId, orderRow.getAsn(AmpManagedOrder.currentOrderId))
         .set(AmpOrderAmendAcc.price, orderRow.getValue(AmpManagedOrder.price_d))
         .set(AmpOrderAmendAcc.quantity, orderRow.getValue(AmpManagedOrder.quantity_d))
         .set(AmpOrderAmendAcc.minFillQuantity, orderRow.getValue(AmpManagedOrder.minFillQuantity))
         .set(AmpOrderAmendAcc.visibleQuantity, orderRow.getValue(AmpManagedOrder.visibleQuantity))
         .set(AmpOrderAmendAcc.currentBalance, orderRow.getValue(AmpManagedOrder.balance_d))
         .set(AmpOrderAmendAcc.durationType, orderRow.getValue(AmpManagedOrder.durationType))
         .set(AmpOrderAmendAcc.durationTime, orderRow.getValue(AmpManagedOrder.durationTime))
         .set(AmpOrderAmendAcc.expiryTime, orderRow.getValue(AmpManagedOrder.expiryTime))
         .set(AmpOrderAmendAcc.actionOnLogoff, orderRow.getValue(AmpManagedOrder.actionOnLogoff))
         .set(AmpOrderAmendAcc.cloneIntoRFS, orderRow.getValue(AmpManagedOrder.cloneIntoRFS))
         .set(AmpOrderAmendAcc.isPublic, orderRow.getValue(AmpManagedOrder.isPublic))
         .set(AmpOrderAmendAcc.shared, orderRow.getValue(AmpManagedOrder.shared))
         .set(AmpOrderAmendAcc.trackingType, orderRow.getValue(AmpManagedOrder.trackingType))
         .setAsn(AmpOrderAmendAcc.trackedSecBoardId, orderRow.getAsn(AmpManagedOrder.trackedSecBoardId))
         .set(AmpOrderAmendAcc.isTopcut, orderRow.getValue(AmpManagedOrder.isTopcut))
         .setAsn(AmpOrderAmendAcc.clearingMemberFirmTrdAccId, orderRow.getAsn(AmpManagedOrder.clearingMemberFirmTrdAccId))
         .set(AmpOrderAmendAcc.doddFrankMidMkt, orderRow.getValue(AmpManagedOrder.doddFrankMidMkt))
         .set(AmpOrderAmendAcc.allowMultiMinFill, orderRow.getValue(AmpManagedOrder.allowMultiMinFill))
         .set(AmpOrderAmendAcc.introBrokerId, session.onBehalfTraderIB.get())
//	            .set(AmpOderAmendAcc.brokerId, session.getLoggedOnUserId())
         ;
      return reqBuilder;
   }
   public static boolean isAutoAcceptOrder(ObservableReplyRow orderbookByOrderRow) {
      Long lastLookTime = orderbookByOrderRow.getValue(AmpOrderBookByOrder.lastLookTime);
      return lastLookTime == null || lastLookTime.equals(0L);
   }
}

