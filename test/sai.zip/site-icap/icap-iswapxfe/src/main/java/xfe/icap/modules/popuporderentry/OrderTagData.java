package xfe.icap.modules.popuporderentry;

import xstr.types.OrderSide;

import java.math.BigDecimal;

/**
 * Created by soopot on 8/2/2020.
 *
 * @author Sooraj Pottekat
 */
public class OrderTagData {
   private final String secCode;
   private final OrderSide side;
   private final BigDecimal price;

   OrderTagData(String secCode, OrderSide side, BigDecimal price){
      this.secCode = secCode;
      this.side = side;
      this.price = price;
   }

   public String getSecCode() {
      return secCode;
   }

   public OrderSide getSide() {
      return side;
   }

   public BigDecimal getPrice() {
      return price;
   }
}
