package xfe.icap.ui.table;

import java.util.Date;

import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableStringValue;
import javafx.util.Callback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.util.Util;

import xstr.util.TeClock;
import xfe.icap.amp.AmpManagedOrder;
import xstr.session.ObservableReplyRow;
import com.omxgroup.xstream.amp.AmpOrderDuration;

public final class AsnOrdersDurationValueFactory implements Callback<ObservableReplyRow, ObservableStringValue> {
   @SuppressWarnings("unused")
   private static final Logger logger = LoggerFactory.getLogger(AsnOrdersDurationValueFactory.class);
   private final TeClock teClock;
	public AsnOrdersDurationValueFactory(TeClock teClock) {
	   this.teClock = teClock;
	}

   @Override
	public ObservableStringValue call(ObservableReplyRow row) {
		if (row == null)
			return null;
			return new StringBinding() {
				private final ObservableObjectValue<Date> expiredTime = row.getProperty(AmpManagedOrder.expiryTime);
				private final ObservableObjectValue<Integer> dType = row.getProperty(AmpManagedOrder.durationType);
				{
					super.bind(expiredTime, dType,teClock);
				}

				@Override
				protected String computeValue() {
					Integer val = dType.getValue();
					// although we do not use the property (we get the time string directly from ASN) -
					// we still need to forca a recalc or else we might miss future invalidations.
					expiredTime.get();
					if (val == null) {
						return "";
					}
					switch (val) {
					case AmpOrderDuration.goodTillDuration:
					   if(expiredTime.get()!=null){
					      return Util.convertDuration(teClock.get(), expiredTime.get());
					   }
					case AmpOrderDuration.day:
						return "Day";
					case AmpOrderDuration.goodTillCancelled:
						return "GTC";
					case AmpOrderDuration.immediate:
						return "Imm";
					default:
						return "";
				}
			}
		};
	}
}
