package xfe.icap.modules.cmpopuporderentry;

import com.nomx.domain.types.DefaultDurationType;
import com.nomx.domain.types.OnLogoffAction;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.ordersdata.DataMode;
import xfe.icap.modules.ordersdata.OrderEntryData;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.OrderTrans;
import xfe.icap.types.Orders;
import xfe.module.Module;
import xfe.types.OrderType;
import xfe.ui.PresetSizeButtonsPane;
import xfe.ui.popover.XfePopOver;
import xfe.util.scene.control.DoubleTextField;
import xstr.session.XtrTransReply;
import xstr.types.MapWrapper;
import xstr.types.OrderSide;
import xstr.types.XtrBlob;
import xstr.util.concurrent.Future;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

public class CMPopupOrderEntry {
   @Module.ModuleDependency
   public CMPopupOrderEntryModule cmPopupOrderEntryModule;

   private static final Logger logger = LoggerFactory.getLogger(CMPopupOrderEntry.class);

   private boolean isDIT = false;
   private int decimals = 2;

   public Parent getRoot() {
      return root;
   }

   @FXML
   public void initialize(){
      final EventHandler<KeyEvent> handler = event -> {
         if (event.getCode() == KeyCode.ESCAPE) {
            root.requestFocus();
         }
      };

      sellTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (focused == null || !focused) {
            sellTextField.setVisible(false);
         }
      });

      sellTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);
      sellTextField.setOnAction(event -> {
         Optional<Double> quantity = sellTextField.getTextValue();
         quantity.ifPresent(aDouble -> onBidOffer(aDouble, OrderSide.SELL));
         root.requestFocus();
      });

      sellLabel.setOnMouseClicked(e -> enableQuantityTextField(sellTextField, sellQuantity.doubleValue()));

      buyTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (focused == null || !focused) {
            buyTextField.setVisible(false);
         }
      });

      buyTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);

      buyTextField.setOnAction(event -> {
         Optional<Double> quantity = buyTextField.getTextValue();
         quantity.ifPresent(aDouble -> onBidOffer(aDouble, OrderSide.BUY));
         root.requestFocus();
      });

      sellTextField.getStyleClass().add("xfe-custom-textfield");
      buyTextField.getStyleClass().add("xfe-custom-textfield");

      buyLabel.setOnMouseClicked(e -> enableQuantityTextField(buyTextField, buyQuantity.doubleValue()));
      errorMsgField.managedProperty().bind(errorMsgField.visibleProperty());
   }

   private void enableQuantityTextField(DoubleTextField textField, double quantity) {
      textField.setVisible(true);
      textField.setDecimals(this.decimals);
      textField.setValue(quantity);
      textField.positionCaret(0);
      textField.selectAll();
      textField.requestFocus();
   }

   public void setup(OrderEntryData orderEntryData) {
      boolean isEntry = orderEntryData.getDataMode().equals(DataMode.ENTRY);
            if (!isEntry) {
         logger.error("Expecting Entry mode");
         return;
      }

      popupSecCode = orderEntryData.getSecCode();
      popupBoardId = orderEntryData.getBoardId();
      isPriceReversal = orderEntryData.isPriceReversal();
      BigDecimal cmQuantity = orderEntryData.getQty();
      cmPrice = orderEntryData.getPrice();

      final EventHandler<ActionEvent> buyQtyBtnHandler = e -> {
         final double quantity = Double.parseDouble(((Button) e.getTarget()).getId());
         onBidOffer(quantity, OrderSide.BUY);
      };

      PresetSizeButtonsPane buyButtons = new PresetSizeButtonsPane(4,
         cmQuantity.doubleValue(),
         buyQtyBtnHandler,
         false,
         Color.WHITE,
         "xfe-custom-button");
      buyButtonsPane.getChildren().add(buyButtons);

      final EventHandler<ActionEvent> sellQtyBtnHandler = e -> {
         final double quantity = Double.parseDouble(((Button) e.getTarget()).getId());
         onBidOffer(quantity, OrderSide.SELL);
      };

      PresetSizeButtonsPane sellButtons = new PresetSizeButtonsPane(4,
         cmQuantity.doubleValue(),
         sellQtyBtnHandler,
         false,
         Color.WHITE,
         "xfe-custom-button");
      sellButtonsPane.getChildren().add(sellButtons);

      onLogoffAction = orderEntryData.getOnLogoffAction();
      isShared = orderEntryData.isShared();
      isDIT = orderEntryData.isDark();
      isTopcut = orderEntryData.isTopcut();
   }

   private void onBidOffer(double size, OrderSide side) {
      boolean isImmediate = false;
      AbstractOrderTrans orderTrans = isManaged ?
         new ManagedOrderTrans(null) : new OrderTrans(null);
      populateTransactionData(orderTrans, isImmediate, size, side);
      // for all CM orders the order Tag is set as CM
      MapWrapper extField=  new MapWrapper();
      extField.put(Orders.ORDER_TAG_KEY, new XtrBlob(Orders.CM.getBytes()));
      orderTrans.setMapWrapper(extField);
      logger.debug("**** Executing BUY/SELL ****");
      cmOrderHandler.apply(new CMOrderData(orderTrans.getSecCode(),cmPrice, side,orderTrans)).onDone(xtrTransReply -> {
         if (xtrTransReply.get().getStatus() == XtrTransReply.Status.RESULT_OK) {
            onClose();
         }
         else {
            String errorMsg = xtrTransReply.get().getMessage();
            logger.error("onBidOffer: {}", errorMsg);
            showErrorMessage(errorMsg);
         }
         return Future.SUCCESS;
      });
   }

   private void onClose() {
      errorMsgField.setText("");
      errorMsgField.setVisible(false);
      if (popOver != null) {
         if (closeHandler != null) {
            closeHandler.accept(popOver.id());
         }
         popOver.hide();
         popOver = null;
      }
   }

   private void showErrorMessage(String errorMsg) {
      errorMsgField.setText(errorMsg);
      errorMsgField.setVisible(true);
      root.getScene().getWindow().sizeToScene();
   }

   private void populateTransactionData(AbstractOrderTrans orderTrans, boolean isImmediate, double size, OrderSide side) {
      orderTrans.setCloneIntoRFS(false);
      orderTrans.setSecCode(popupSecCode);
      orderTrans.setBoardId(popupBoardId);
      orderTrans.setOrderType(OrderType.REGULAR);
      orderTrans.setVwap(false);
      double negatePrice = side.equals(OrderSide.SELL) && isPriceReversal ? -1.0 : 1.0;
      orderTrans.setPrice(cmPrice.doubleValue() * negatePrice);
      orderTrans.setQuantity(size);
      orderTrans.setDoneIfTouched(isDIT);
      orderTrans.setAnonymous(false);
      orderTrans.setUnderRef(false);

      if (isImmediate) {
         orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
      } else {
         orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DAY);
      }

      orderTrans.setOnLogOffAction(onLogoffAction);
      orderTrans.setShared(isShared);
      orderTrans.setTopCut(isTopcut);
   }

   public void setCloseHandler(Consumer<String> closeHandler) {
      this.closeHandler = closeHandler;
   }

   void setPopover(XfePopOver p) {
      this.popOver = p;
   }

   void setCMOrderHandler(Function<CMOrderData, Future<XtrTransReply>> cmOrderHandler){
      this.cmOrderHandler =cmOrderHandler;
   }

   @FXML
   private Parent root;

   @FXML
   private StackPane buyButtonsPane;

   @FXML
   private StackPane sellButtonsPane;

   @FXML
   private Label sellLabel;

   @FXML
   private DoubleTextField sellTextField;

   @FXML
   private Label buyLabel;

   @FXML
   private DoubleTextField buyTextField;

   @FXML
   private TextArea errorMsgField;

   private BigDecimal buyQuantity = new BigDecimal(BigInteger.ZERO);

   private BigDecimal sellQuantity = new BigDecimal(BigInteger.ZERO);

   private Consumer<String> closeHandler;
   private boolean isManaged = true;
   private boolean isTopcut;
   private String popupSecCode;
   private String popupBoardId;
   private BigDecimal cmPrice;
   private OnLogoffAction onLogoffAction;
   private boolean isShared;
   private XfePopOver popOver;
   private boolean isPriceReversal = false;
   private Function<CMOrderData,Future<XtrTransReply>> cmOrderHandler;
}
