package xfe.icap.modules.watchlist;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;

public class InfoShim extends Pane {
	private final Circle circle = new Circle() {{
		this.getStyleClass().add("xfe-info-shim-circle");
		this.setRadius(8.0);
	}};

	public InfoShim() {
		this.getChildren().add(circle);
		this.setMinWidth(USE_COMPUTED_SIZE);
	}
}
