package xfe.icap.modules.groupdata;

import com.omxgroup.xstream.amp.AmpGroupType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpGroupSecs;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.session.QueryFeed;
import xstr.session.QueryReplyRow;
import xstr.session.XtrQueryRequest;
import xstr.session.XtrQueryRequestBuilder;
import xstr.util.Fx;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.util.HashMap;
import java.util.Map;

@Module.Autostart
public class GroupSecsDataModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(GroupSecsDataModule.class);

   @Override
   public Future<Void> startModule() {
      activeSessionModule.getSession().ifPresent((session) -> {
         try {
            XtrQueryRequest req2 = XtrQueryRequestBuilder.create(AmpGroupSecs.req, session).set(AmpGroupSecs.groupType, AmpGroupType.button).build();
            QueryFeed srcFeed2 = session.queries.getFeedSource(req2);
            srcFeed2.addListener(feedEvents -> Fx.runLater(() -> {
               feedEvents.stream().filter(e -> e.getRow().isPresent()).forEach(e -> {
                  QueryReplyRow row = e.getRow().get();
                  String groupId = row.getValue(AmpGroupSecs.groupId);
                  ObservableList<QueryReplyRow> obsList = allGroupSecsByGroupId.get(groupId);
                  switch (e.getEventType()) {
                     case CREATE:
                     case UPDATE:
                        if (obsList == null) {
                           obsList = FXCollections.observableArrayList();
                           allGroupSecsByGroupId.put(groupId, obsList);
                        }
                        obsList.add(row);
                        break;
                     case DELETE:
                        if (obsList != null) {
                           obsList.remove(row);
                        }
                        break;
                     default:
                  }
               });
            }));
         } catch (AsnTypeException | AmpPermissionException e) {
            e.printStackTrace();
         }
      });
      return Future.SUCCESS;
   }

   public Map<String, ObservableList<QueryReplyRow>> getAllGroupSecsByGroupId() {
      return allGroupSecsByGroupId;
   }

   private final Map<String, ObservableList<QueryReplyRow>> allGroupSecsByGroupId = new HashMap<>();

}
