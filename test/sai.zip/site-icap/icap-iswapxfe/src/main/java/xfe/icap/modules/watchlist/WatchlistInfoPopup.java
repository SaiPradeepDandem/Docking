package xfe.icap.modules.watchlist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableBooleanValue;
import javafx.collections.FXCollections;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.*;
import xfe.icap.types.IcapSecBoardTrim2Watchlist;
import xfe.types.SecBoard;
import xfe.types.Watchlist;
import xstr.util.Fun1;

import xstr.util.Fx;
import xfe.util.scene.control.EnhancedTableView;
import xfe.util.scene.control.InfoPopup;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.settings.SettingsData;
import xstr.session.ObservableReplyRow;

public class WatchlistInfoPopup extends InfoPopup {

   public WatchlistInfoPopup(
         Node node,
         XfeSession session,
         SelectionContextModule selectionContextModule,
         ObservableReplyRow row,
         SettingsData settingsData,
         InstrumentsFilters filters,
         ObservableBooleanValue showing,
         InstrumentsColumns columns) {
      super(node, showing, false);
      contentProperty().bind(new ObjectBinding<Region>() {
         { bind(detachedProperty()); }

         @Override
         protected Region computeValue() {
            boolean detached = detachedProperty().get();
            TableView<ObservableReplyRow> tableView = createTableView(columns, settingsData, filters,session);

            session.secBoards.get().getSecBoard(row.getValue(AmpIcapSecBoardTrim2.secCode),
                  row.getValue(AmpIcapSecBoardTrim2.boardId)).map(new Fun1<SecBoard, Void>() {

                     @Override
                     public Void call(SecBoard secBoard) {
                        Watchlist watchlist = new IcapSecBoardTrim2Watchlist(session);

                        if (secBoard != null) {
                           watchlist.getSpecWatchedSecboards().setAll(secBoard);
                        } else {
                           watchlist.getSpecWatchedSecboards().clear();
                        }

                        tableView.itemsProperty().bind(
                              Bindings.when(WatchlistInfoPopup.this.showingProperty()).then(
                                    Fx.alwaysUnequal(watchlist.getItems())).otherwise(
                                          Fx.alwaysUnequal(FXCollections.emptyObservableList())));


                        return null;
                     }
                  });

            VBox vbox = createDecorationPaneAttached(detached, tableView);
            vbox.getChildren().add(0, createDraggableHeaderPane("Instrument Info"));
            return vbox;
         }
      });
   }

   private VBox createDecorationPaneAttached(boolean detached, TableView<ObservableReplyRow> asnTableView) {
      VBox rtn = new VBox();
      VBox children = new VBox();
      if(detached){
         children.getStyleClass().add("xfe-info-detached-content");
         StackPane stackPane = new StackPane();
         stackPane.getStyleClass().add("detached-instrument-table-wrapper");
         stackPane.getChildren().add(asnTableView);
         children.getChildren().add(stackPane);
         rtn.getStyleClass().add("xfe-info-detached-decoration");
      }else{
         children.getStyleClass().add("xfe-info-content");
         children.getChildren().add(asnTableView);
         rtn.getStyleClass().add("xfe-info-decoration");
      }
      rtn.setOpacity(1D);
      rtn.getChildren().add(children);
      return rtn;
   }

   private static TableView<ObservableReplyRow> createTableView(
           InstrumentsColumns columns,
           SettingsData settingsData,
           InstrumentsFilters filters, XfeSession session) {
      return new EnhancedTableView<ObservableReplyRow>() {
         final InvalidationListener bidOfferSwitchListener = new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
               setColumns();
            }
         };

         final List<TableColumn<ObservableReplyRow,?>> preReverseCols;
         final List<TableColumn<ObservableReplyRow,?>> reverseCols;
         final List<TableColumn<ObservableReplyRow,?>> postReverseCols;

         {
            preReverseCols = Arrays.asList(columns.createPopupInstrumentColumn());
            reverseCols = Arrays.asList(
                  columns.createPopupTypeCol(true),
                  columns.createPopupTotalColumn(true),
                  columns.createPopupImpliedColumn(true, session.secBoards.get().getSecBoardsByKey()),
                  columns.createPopupPriceColumn(true, session.secBoards.get().getSecBoardsByKey()),
                  columns.createPopupPriceColumn(false, session.secBoards.get().getSecBoardsByKey()),
                  columns.createPopupImpliedColumn(false, session.secBoards.get().getSecBoardsByKey()),
                  columns.createPopupTotalColumn(false),
                  columns.createPopupTypeCol(false));

            // No columns here for now.
            postReverseCols = Arrays.asList();

            setColumns();

            // Adding a listener for bid/offer switching
            settingsData.bidOnLeftProperty().addListener(new WeakInvalidationListener(bidOfferSwitchListener));
            getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
         }

         private void setColumns() {
            List<TableColumn<ObservableReplyRow,?>> cols = new ArrayList<TableColumn<ObservableReplyRow,?>>();
            cols.addAll(preReverseCols);

            if (!settingsData.bidOnLeftProperty().get()) {
               List<TableColumn<ObservableReplyRow,?>> reverseColsCopy = new ArrayList<TableColumn<ObservableReplyRow,?>>();
               reverseColsCopy.addAll(reverseCols);
               Collections.reverse(reverseColsCopy);
               cols.addAll(reverseColsCopy);
            } else {
               cols.addAll(reverseCols);
            }

            cols.addAll(postReverseCols);
            this.getColumns().setAll(cols);
         }
      };
   }
}
