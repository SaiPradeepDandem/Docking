package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.acc.AmpAccessor;

/**
 * Accessor for Shortlist group secboards.
 */
public class AmpGroupSecs extends AmpAccessor {
   public static final AMP.AmpQreq req = AMP.qREQ("groupSecsReq");
   public static final AMP.AmpQrep rep = AMP.qREP("groupSecsRep");
   public static final AsnConversionAccessor<Integer> groupType = acc(AMP.qREQ("groupSecsReq.groupType"), Integer.class);

   public static final AsnConversionAccessor<Long> speedIndex = acc(AMP.qREP("groupSecsRep.speedIndex"), Long.class);
   public static final AsnConversionAccessor<String> groupId = acc(AMP.qREP("groupSecsRep.groupId"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("groupSecsRep.boardId"), String.class);
   public static final AsnConversionAccessor<String> instrId = acc(AMP.qREP("groupSecsRep.instrId"), String.class);
   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("groupSecsRep.secCode"), String.class);


}
