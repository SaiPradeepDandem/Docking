package xfe.icap.modules.watchlist;

import com.omxgroup.xstream.amp.AmpSecClassId;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TablePosition;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpPriceTightness;
import xstr.amp.AsnAccessor;
import xstr.session.*;
import xfe.icap.types.PriceTightnessWatchlist;
import xfe.util.Constants;
import xstr.util.Fx;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;
import xstr.util.exception.XtrMessageException;
import xfe.util.scene.control.AsnTableRow;
import xfe.util.scene.control.SimpleSelectionTracker;
import xfe.icap.XfeSession;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.SettingsUIModule;

import java.util.List;
import java.util.Objects;
import java.util.Timer;

@Module.Autostart
public class PriceTightnessModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(PriceTightnessModule.class);

   @ModuleDependency
   public WatchlistModule watchlistModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public SettingsUIModule settingsModule;
   @ModuleDependency
   public SelectionContextModule selectionContextModule;

   private static final WatchlistView PT_WATCHLIST_VIEW = new WatchlistView(Constants.PRICE_TIGHTNESS_LABEL.getKey(),
      Constants.PRICE_TIGHTNESS_LABEL.getValue(),
      Constants.PRICE_TIGHTNESS_ID);
   private static final long interval = 1000000L; //1000000000 is one second

   @Override
   public Future<Void> startModule() {
      try {
         reqBuilder = XtrQueryRequestBuilder.create(AmpPriceTightness.req, xfeSessionModule.getUnderlyingSession());
      } catch (AmpPermissionException e) {
         return Futures.error(new XtrMessageException("No permission for AmpPriceTightnessReq - tab will not be available", e));
      } catch (AsnTypeException e) {
         return Futures.error(e);
      }

      try {
         mainWatchlistView = watchlistModule.createInstrumentTableView(false, true,rowFactory,tracker);
         mainWatchlistView.getStyleClass().add("xfe-pricetightness-tableview");
         miniWatchlistView = watchlistModule.createMiniWatchlistTableViewForPT(tracker);
         miniWatchlistView.getStyleClass().add("xfe-pricetightness-tableview");
      } catch (Exception e) {
         e.printStackTrace();
      }

      // Setting selection for main PT watchlist
      selectionTrackerMain = new SimpleSelectionTracker<>(mainWatchlistView, row -> row.getString(AmpIcapSecBoardTrim2.secCode));

      selectionTrackerMainCellListener = (observableVal, oldVal, newVal) -> {
         if (newVal != null) {
            AsnAccessor colAccessor = watchlistModule.instrumentsPane.getColAccessor(mainWatchlistView, newVal.getTableColumn());
            ObservableReplyRow row = mainWatchlistView.getItems().get(newVal.getRow());
            if (row != null) {
               selectedSecCodeMain.setValue(row.getString(AmpIcapSecBoardTrim2.secCode));
               selectionContextModule.setSelectionContext(new SelectionContext(SelectionContextModule.GridType.Watchlist, row, colAccessor, -1));
            }
         } else {
            selectedSecCodeMain.setValue(null);
         }
      };
      selectionTrackerMain.selectedCellProperty().addListener(selectionTrackerMainCellListener);

      selectionTrackerMainRowListener = (observableVal, oldVal, newVal) -> {
         if (newVal != null) {
            String secCode = newVal.getString(AmpIcapSecBoardTrim2.secCode);
            String boardId = newVal.getString(AmpIcapSecBoardTrim2.boardId);
            watchlistModule.instrumentsPane.getColumns().disableFlash(secCode, boardId);
         }
      };
      selectionTrackerMain.selectedItemProperty().addListener(selectionTrackerMainRowListener);

      // Setting selection for mini PT watchlist
      selectionTrackerMini = new SimpleSelectionTracker<>(miniWatchlistView, row -> row.getString(AmpIcapSecBoardTrim2.secCode));
      miniWatchlistView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

      selectionTrackerMiniListener = (observableVal, oldVal, newVal) -> {
         selectedSecCodeMini.setValue(newVal == null ? null : newVal.getString(AmpIcapSecBoardTrim2.secCode));
      };
      selectionTrackerMini.selectedItemProperty().addListener(selectionTrackerMiniListener);

      priceTightnessTabView = new TabViewPair(tab, mainWatchlistView, 2);
      priceTightnessTabView.getTab().setId(PT_WATCHLIST_VIEW.getId().toString());

      if (settingsModule.getData().displayPTTabProperty().get()) {
         setQueryFeed(true);
         watchlistModule.addTabView(priceTightnessTabView);
      }

      tracker.addListener(settingsModule.getData().displayPTTabProperty(), (_0, _1, newDisplayPTTTab) -> {
         if (newDisplayPTTTab) {
            // Setting up the watchlist
            setQueryFeed(true);
            watchlistModule.addTabView(priceTightnessTabView);
         } else {
            // Stop polling
            if (feedSrc != null) {
               feedSrc.removeListener(feedListener);
               feedSrc = null;
            }
            watchlistModule.removeTabView(priceTightnessTabView);
            // nulling the watchlist
            if (watchlist != null) {
               watchlist.dispose();
               watchlist = null;
            }
         }
      });

      tracker.addListener(miniWatchlistViewVisibleProperty, (observable, oldValue, newValue) -> {
         if (newValue) {
            watchlistModule.setMiniWatchlistPTView(miniWatchlistView);
         }
      });

      mainWatchlistViewVisibleProperty.addListener(mainWatchlistVisibilityLis);
      miniWatchlistViewVisibleProperty.addListener(miniWatchlistVisibilityLis);

      tracker.bind(mainWatchlistViewVisibleProperty,
         Bindings.equal(watchlistModule.instrumentsPane.instrTabPane.getSelectionModel().selectedItemProperty(),
            priceTightnessTabView.getTab()));

      tracker.bind(miniWatchlistViewVisibleProperty,
         Bindings.equal(watchlistModule.watchlistStage.activeViewProperty(), PT_WATCHLIST_VIEW));

      tracker.bind(viewIsVisible, mainWatchlistViewVisibleProperty.or(miniWatchlistViewVisibleProperty));

      tracker.addListener(viewIsVisible, observable -> {
         if (watchlist != null)
            watchlist.setHidden(!viewIsVisible.get());
      });

      // Listening on other grids' selection change
      selectionContextChangeListener = (observableVal, oldVal, newVal) -> {
         if (selectionContextModule.selectionContextProperty().get() != SelectionContextModule.NULL_CONTEXT &&
            newVal.grid != SelectionContextModule.GridType.Watchlist) {
            // We need to reset our selection
            selectionTrackerMain.clearSelection();
            selectedSecCodeMain.setValue(null);
         }
      };
      selectionContextModule.selectionContextProperty().addListener(selectionContextChangeListener);

      // We need to listen on a new query, providing it with 3 Price Tightness parameters.
      // The result of this query is Add and Remove events for secboard indexes.
      tracker.addListener(settingsModule.getData().outrightPTForTabProperty(), PTValListener);
      tracker.addListener(settingsModule.getData().strategyPTForTabProperty(), PTValListener);
      tracker.addListener(settingsModule.getData().butterflyPTForTabProperty(), PTValListener);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      selectionContextModule.selectionContextProperty().removeListener(selectionContextChangeListener);
      selectionTrackerMain.selectedCellProperty().removeListener(selectionTrackerMainCellListener);
      selectionTrackerMain.selectedItemProperty().removeListener(selectionTrackerMainRowListener);
      viewIsVisible = new SimpleBooleanProperty(false);
      if (timer != null) {
         timer.cancel();
         timer = null;
      }
      if (mainWatchlistView != null) {
         mainWatchlistViewVisibleProperty.removeListener(mainWatchlistVisibilityLis);
         mainWatchlistViewVisibleProperty.set(false);
         selectionTrackerMain.dispose();
         selectionTrackerMain = null;
         mainWatchlistView.setItems(null);
         mainWatchlistView = null;
      }
      if (miniWatchlistView != null) {
         miniWatchlistViewVisibleProperty.removeListener(miniWatchlistVisibilityLis);
         miniWatchlistViewVisibleProperty.set(false);
         selectionTrackerMini.dispose();
         selectionTrackerMini = null;
         miniWatchlistView.setItems(null);
         miniWatchlistView = null;
      }
      if (priceTightnessTabView != null) {
         priceTightnessTabView.dispose();
         priceTightnessTabView = null;
      }
      if (watchlist != null) {
         watchlist.dispose();
         watchlist = null;
      }
      return Future.SUCCESS;
   }

   private boolean notPriceTight(Double pt, String secCode, Integer secClass) {
      double threshold;
      if(secClass== AmpSecClassId.strategy){
         if(secCode.endsWith(".bf")){
            threshold = settingsModule.getData().butterflyPTForTabProperty().get();
         }else{
            threshold = settingsModule.getData().strategyPTForTabProperty().get();
         }
      }else{
         threshold = settingsModule.getData().outrightPTForTabProperty().get();
      }
      return pt  > threshold ;
   }

   private void setupWatchlist() {
      if (watchlist != null)
         return;

      watchlist = new PriceTightnessWatchlist(xfeSessionModule, selectedSecCodeMain, selectedSecCodeMini);
      mainWatchlistView.setItems(watchlist.getItems());
      miniWatchlistView.setItems(watchlist.getItems());
      watchlistModule.instrumentsPane.setupPriceTightnessSelector(mainWatchlistView, watchlist.itemsReadyProperty());
      watchlistModule.instrumentsPane.setupPriceTightnessSelector(miniWatchlistView, watchlist.itemsReadyProperty());
      selectionTrackerMain.bindReadyFlag(watchlist.itemsReadyProperty());
      selectionTrackerMini.bindReadyFlag(watchlist.itemsReadyProperty());
   }

   private void setQueryFeed(boolean forceUpdate) {
      long currentTime = System.nanoTime();
      if (!forceUpdate && currentTime - lastupdateTime < interval) {
         return;
      }

      setupWatchlist();

      lastupdateTime = currentTime;
      if (feedSrc != null)
         feedSrc.removeListener(feedListener);
      double outrightPTVal = settingsModule.getData().outrightPTForTabProperty().get();
      double strategyPTVal = settingsModule.getData().strategyPTForTabProperty().get();
      double butterflyPTVal = settingsModule.getData().butterflyPTForTabProperty().get();

      try {
         reqBuilder = reqBuilder
            .set(AmpPriceTightness.reqOutrightLimit, outrightPTVal)
            .set(AmpPriceTightness.reqSpreadLimit, strategyPTVal)
            .set(AmpPriceTightness.reqButterflyLimit, butterflyPTVal);

         XtrQueryRequest req = reqBuilder.build();
         feedSrc = xfeSessionModule.getUnderlyingSession().queries.getFeedSource(req);
         logger.info("Price tightness is set {} for outright; {} for strategy; {} for butterfly.", outrightPTVal, strategyPTVal, butterflyPTVal);
         feedSrc.addListener(feedListener);
      } catch (AsnTypeException e) {
         e.printStackTrace();
      }
   }

   private void handleIndexDelete(long secBoardIndex) {
      if (xfeSessionModule.secBoards == null || watchlist == null) {
         logger.error("Cannot handle AmpPriceTightnessReq addCmd because of xfeSession.secBoards:{} or watchlist:{}", xfeSessionModule.secBoards, watchlist);
         return;
      }

      xfeSessionModule.secBoards.get().getByIndex(secBoardIndex).map(secBoard -> {
         if (secBoard != null) {
            watchlist.removeSecBoard(secBoard);
         }
         else
            logger.error("Cannot handle AmpPriceTightnessReq deleteCmd because secBoard is not existed");
         return Future.SUCCESS;
      });
   }

   private void handleIndexAdd(long secBoardIndex) {
      if (xfeSessionModule.secBoards == null || watchlist == null) {
         logger.error("Cannot handle AmpPriceTightnessReq addCmd because of xfeSession.secBoards:{} or watchlist:{}", xfeSessionModule.secBoards, watchlist);
         return;
      }

      xfeSessionModule.secBoards.get().getByIndex(secBoardIndex).map(secBoard -> {
         if (secBoard != null) {
            watchlist.addSecBoard(secBoard);
         }
         else
            logger.error("Cannot handle AmpPriceTightnessReq addCmd because secBoard is not existed");
         return Future.SUCCESS;
      });
   }

   private void handleClear() {
      if (watchlist != null)
         watchlist.clear();
   }
   private final ListenerTracker tracker = new ListenerTracker();
   private final BooleanProperty miniWatchlistViewVisibleProperty = new SimpleBooleanProperty(false);
   private final BooleanProperty mainWatchlistViewVisibleProperty = new SimpleBooleanProperty(false);
   // TEST
   // private int iteration = 0;
   private final SubtitleTab tab = new SubtitleTab(PT_WATCHLIST_VIEW.getTitle(), PT_WATCHLIST_VIEW.getSubtitle());
   private final Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>> rowFactory = new Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>>() {
      @Override
      public TableRow<ObservableReplyRow> call(TableView<ObservableReplyRow> param) {
         return new AsnTableRow() {
            {
               _this  = this;
            }

            @Override
            protected void updateItem(ObservableReplyRow item, boolean empty) {
               super.updateItem(item, empty);
               List<String> styles = _this.getStyleClass();
               if(!empty){
                  Double pt = item.getValue(AmpIcapSecBoardTrim2.priceTightness);
                  if(pt==null || notPriceTight(pt,item.getValue(AmpIcapSecBoardTrim2.secCode),item.getValue(AmpIcapSecBoardTrim2.secClassId))){
                     if(!styles.contains("xfe-pricetightness-empty")){
                        styles.add("xfe-pricetightness-empty");
                     }
                  }else{
                     styles.remove("xfe-pricetightness-empty");
                  }
               }else{
                  styles.remove("xfe-pricetightness-empty");
               }
            }
            private final TableRow<ObservableReplyRow> _this;
         };
      }
   };
   private StringProperty selectedSecCodeMain = new SimpleStringProperty();
   private StringProperty selectedSecCodeMini = new SimpleStringProperty();
   private PriceTightnessWatchlist watchlist;
   private final QueryFeedListener feedListener = feedEvents -> {
      for (QueryRowEvent event : feedEvents) {
         XtrQueryReplyCommand eventType = event.getEventType();

         switch (eventType) {
            case CLEAR:
               // Resetting view
               handleClear();
               break;
            case CREATE:
               handleIndexAdd(event.getNewRow().getValue(AmpPriceTightness.secBoardIdx));
               break;
            case UPDATE:
               // Do we need to do anything?!
               break;
            case DELETE:
               handleIndexDelete(event.getOldRow().getValue(AmpPriceTightness.secBoardIdx));
               break;
            default:
               logger.error("Unexpected event type: {}", eventType);
         }

      }
   };
   private TableView<ObservableReplyRow> mainWatchlistView;
   private TableView<ObservableReplyRow> miniWatchlistView;
   private TabViewPair priceTightnessTabView;
   private BooleanProperty viewIsVisible = new SimpleBooleanProperty(false);
   // View Updating Timer
   private Timer timer;
   private QueryFeed feedSrc;
   private XtrQueryRequestBuilder reqBuilder;
   private SimpleSelectionTracker<ObservableReplyRow> selectionTrackerMain;
   private final InvalidationListener mainWatchlistVisibilityLis = observable -> {
      boolean isMainPriceTightnessVisible = Objects.equals(
         watchlistModule.instrumentsPane.instrTabPane.getSelectionModel().selectedItemProperty().get(),
         priceTightnessTabView.getTab());
      mainWatchlistView.setVisible(isMainPriceTightnessVisible);
      if (!isMainPriceTightnessVisible)
         selectionTrackerMain.clearSelection();
   };
   private SimpleSelectionTracker<ObservableReplyRow> selectionTrackerMini;
   private final InvalidationListener miniWatchlistVisibilityLis = observable -> {
      if (!miniWatchlistViewVisibleProperty.get())
         selectionTrackerMini.clearSelection();
   };
   private long lastupdateTime = System.nanoTime(); //if three value is updated at the same time, do not bother to update the query three times
   private final InvalidationListener PTValListener = observable -> setQueryFeed(false);

   private ChangeListener<SelectionContext> selectionContextChangeListener;
   private ChangeListener<TablePosition> selectionTrackerMainCellListener;
   private ChangeListener<ObservableReplyRow> selectionTrackerMainRowListener;
   private ChangeListener<ObservableReplyRow> selectionTrackerMiniListener;

}
