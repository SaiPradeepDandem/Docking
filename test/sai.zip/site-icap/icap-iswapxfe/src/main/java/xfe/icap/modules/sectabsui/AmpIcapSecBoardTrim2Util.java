package xfe.icap.modules.sectabsui;

import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;

import java.math.BigDecimal;

public class AmpIcapSecBoardTrim2Util {

   /**
    * Specifies whether the given AmpIcapSecBoardTrim2 is in lit workup state on any OrderSide.
    *
    * @param row ObservableReplyRow of AmpIcapSecBoardTrim2
    * @return {@code true} if the AmpIcapSecBoardTrim2 is in workup state else returns {@code false}
    */
   public static boolean isInLitWorkupState(ObservableReplyRow row) {
      final BigDecimal prvlgdPrice = row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngPrice);
      final BigDecimal cmPrice = row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
      final int prvlgedSide = AmpIcapSecBoardTrim2.getAggressiveSide(row.getValue(AmpIcapSecBoardTrim2.aggressiveSide));
      return prvlgdPrice != null && (OrderSide.SELL.isReverse(prvlgedSide) || OrderSide.BUY.isReverse(prvlgedSide)) &&
         (cmPrice == null || cmPrice.abs().doubleValue() != prvlgdPrice.abs().doubleValue());
   }

   /**
    * Fetches the userId from the given AmpIcapSecBoardTrim2.
    *
    * @param row  ObservableReplyRow of AmpIcapSecBoardTrim2
    * @param side Order side
    * @return User id
    */
   public static String getUserId(ObservableReplyRow row, OrderSide side) {
      String userId = null;
      if (side == OrderSide.BUY) {
         userId = row.getValue(AmpIcapSecBoardTrim2.bidUserId);
      } else if (side == OrderSide.SELL) {
         userId = row.getValue(AmpIcapSecBoardTrim2.offerUserId);
      }
      return userId;
   }
}
