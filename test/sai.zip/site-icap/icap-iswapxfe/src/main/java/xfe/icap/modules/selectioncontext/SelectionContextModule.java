package xfe.icap.modules.selectioncontext;

import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpRfq;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xstr.util.IcapBooleanProperty;
import xstr.util.collection.XstrCollections;
import xstr.session.ObservableReplyRow;
import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.util.concurrent.Future;

import xstr.types.OrderSide;
import xstr.util.Fx;
import xfe.util.scene.control.SelectionTracker;
import xfe.icap.XfeSession;
import xfe.amp.WatchlistAcc;
import xfe.module.Module;
import xfe.icap.modules.orderentry.SecBoardContext;
import xstr.util.Fun1;
import xstr.util.Lazy;
import xstr.util.Tuple;
import xstr.util.Tuple2;

import java.util.List;

import static xfe.util.Constants.RFS_SEC_CODE_PREFIX1;
import static xfe.util.Constants.RFS_SEC_CODE_PREFIX2;

@Module.LazyStart
public class SelectionContextModule implements Module {

   private static final Logger logger = LoggerFactory.getLogger(SelectionContextModule.class);
   private static final Double zero = 0d;

   @ModuleDependency
   public XfeSession xfeSession;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   public enum GridType {
      NONE,
      Watchlist,
      OBBO_BUY,
      OBBO_SELL,
      Orders,
      Trades,
      Rfq,
      MarketTrades;

      public static GridType of(OrderSide orderSide) {
         if (orderSide == OrderSide.BUY) {
            return OBBO_BUY;
         }

         if (orderSide == OrderSide.SELL) {
            return OBBO_SELL;
         }

         return null;
      }
   }

   public static final SelectionContext NULL_CONTEXT = new SelectionContext(GridType.NONE, null, null, -1);

   private final ObjectProperty<SelectionContext> selectionContextProperty = new SimpleObjectProperty<>(this, "selectionContext", NULL_CONTEXT);

   public SelectionContext getSelectionContext() {
      return selectionContextProperty.get();
   }

   private SelectionContext candidateContext = NULL_CONTEXT;

   public final IcapBooleanProperty isLoggedUserMarketMaker = new IcapBooleanProperty(this, "isLoggedUserMM", false);
   public final IcapBooleanProperty dataContextRfqSec = new IcapBooleanProperty(this, "dataContextRfqSec", false); //indicate the selected instrument is an RFQ instruments. It includes noraml RFQ and RFS session
   public final IcapBooleanProperty dataContextRfsSec = new IcapBooleanProperty(this, "dataContextRfsSec", false); //indicate the selected instrument is an RFS instrument
   public final IcapBooleanProperty dataContextRfsSessionSec  = new IcapBooleanProperty(this, "dataContextRfsSessionSec", false); //indicate the selected instrument is an RFS session instrument
   public final IcapBooleanProperty dataContextRfqSessionSec  = new IcapBooleanProperty(this, "dataContextRfqSessionSec", false); //indicate the selected instrument is an RFQ session instrument, but not rfs session.
   private final ObjectProperty<ObservableReplyRow> selectedRfq = new SimpleObjectProperty<>();

   public SelectionContextModule() {
   }

   public void setSelectionContext(SelectionContext ctx) {
      candidateContext = ctx;
      boolean restorationDriven = SelectionTracker.breadcrumbs.getTrail().contains(SelectionTracker.RESTORING_SELECTION);

      // When scrolling with the keyboard (by holding in the up or down key) the
      // selection context changes on each key repeat event. This causes a flood
      // of unnecessary selection change events to propagate through the application.
      // To reduce these events we add a small delay and only update the selection
      // context once the selection has settled.
      Fx.delay(180, new Runnable() {
         @Override
         public void run() {
            SelectionTracker.breadcrumbs.run(restorationDriven ? SelectionTracker.RESTORING_SELECTION : this, () -> {
               if (ctx != candidateContext)
                  return; // candidate changed in the mean time - it will be updated later

               candidateContext = NULL_CONTEXT;
               if (selectionContextProperty.get().equals(ctx)) {
                  logger.warn("Ignoring identical context: {}", ctx);
                  return;
               }

               String secCode  = null;
               String boardId = null ;
               String parentSecCode = null;
               String parentBoard = null;
               switch (ctx.grid) {
                  case Watchlist:
                     xfeSession.rfsPickup.set(false);
                     xfeSession.pickedUpRow.setValue(null);
                     if (ctx.row != null) {
                        secCode = ctx.row.getString(AmpIcapSecBoardTrim2.secCode);
                        boardId = ctx.row.getString(AmpIcapSecBoardTrim2.boardId);
                     }
                     break;
                  case Orders:
                     xfeSession.rfsPickup.set(false);
                     xfeSession.pickedUpRow.setValue(null);
                     if (ctx.row != null) {
                        secCode = ctx.row.getString(AmpManagedOrder.secCode);
                        boardId = ctx.row.getString(AmpManagedOrder.boardId);
                     }
                     break;
                  case Rfq:
                     xfeSession.rfsPickup.set(false);
                     xfeSession.pickedUpRow.setValue(null);
                     if (ctx.row != null) {
                        secCode = ctx.row.getString(AmpRfq.secCode);
                        boardId = ctx.row.getString(AmpRfq.boardId);
                        parentSecCode = ctx.row.getString(AmpRfq.parentSecCode);
                        parentBoard = ctx.row.getString(AmpRfq.parentBoardId);
                     }
                     break;
                  case NONE:
                     xfeSession.rfsPickup.set(false);
                     xfeSession.pickedUpRow.setValue(null);
                     break;
                  case MarketTrades:
                     xfeSession.rfsPickup.set(false);
                     xfeSession.pickedUpRow.setValue(null);
                     break;
                  case Trades:
                     xfeSession.rfsPickup.set(false);
                     xfeSession.pickedUpRow.setValue(null);
                     break;
                  default:
                     break;
               }

               if (secCode != null) {
                  boolean isRfs = isRfsInstrument(secCode);
                  boolean isRFQ = false;
                  boolean isRfsSessionInstrumentSelected = false;
                  ObservableReplyRow linkedRfqRow = null;
                  List<ObservableReplyRow> rfqs = xfeSession.rfqs.get().activeRfqs.get();
                  for (ObservableReplyRow rfqRow : rfqs) {
                     String rfqSecCode = rfqRow.getString(AmpRfq.secCode);
                     if (secCode.equals(rfqSecCode)) {//current selected instrument is an active RFQ
                        isRfs = false;
                        isRFQ = true;
                        Double maxQ = rfqRow.getValue(AmpRfq.maxQuantity);
                        if (maxQ == null || zero.equals(maxQ)) { //current selected instrument is an RFS Session
                           isRfsSessionInstrumentSelected = true;
                        }
                        linkedRfqRow = rfqRow;
                        break;
                     }
                  }
                  dataContextRfsSec.setValue(isRfs);
                  dataContextRfsSessionSec.setValue(isRfsSessionInstrumentSelected);
                  dataContextRfqSec.setValue(isRFQ);
                  selectedRfq.setValue(linkedRfqRow);
                  dataContextRfqSessionSec.setValue(isRFQ && !isRfsSessionInstrumentSelected);
                  Tuple2<String,String> board = parentBoard==null ? Tuple.of(secCode, boardId) : Tuple.of(parentSecCode, parentBoard);
                  String instrumentId = xfeSession.secBoards.get().getSecBoardsByKey().get(board).getInstrumentId();
                  List<String> mmOfInstrument = xfeSession.mmFirms.get().firmsByInstrument.get().get(instrumentId);
                  if (xfeSession.traderFirmMap != null) {
                     isLoggedUserMarketMaker.set(XstrCollections.anyIntersection(mmOfInstrument, xfeSession.traderFirmMap.getGroup()));
                  } else {
                     isLoggedUserMarketMaker.set(false);
                  }
               }

               logger.info("New Context: {}", ctx);

               selectionContextProperty.set(ctx);
               resetSelectionsExceptFor(ctx.grid);

               switch (ctx.grid) {
                  case Watchlist:
                     if (selectedSecurityRow.get() == null || selectedSecurityRow.get().selectedRow != ctx.row) {
                        selectedSecurityRow.set(ctx.row == null ? null : new SelectedRowCellContext(ctx.row, ctx.field));
                     } else {
                        selectedSecurityRow.get().setSelectedField(ctx.field);
                     }
                     break;
                  case OBBO_BUY:
                  case OBBO_SELL:
                     selectedObboRow.set(ctx.row == null ? null : new SelectedRowCellContext(ctx.row, ctx.field));
                     break;
                  case Orders:
                     selectedOrderRow.set(ctx.row == null ? null : new SelectedRowCellContext(ctx.row, ctx.field));
                     break;
                  case Rfq:
                     selectedRfqRow.set(ctx.row == null ? null : new SelectedRowCellContext(ctx.row, null));
                     break;
                  default:
                     break;
               }
            });
         }
      });
   }

   private String getBoardId(SelectionContext ctx) {
      if(GridType.Watchlist.equals(ctx.grid))
         return ctx.row.getString(AmpIcapSecBoardTrim2.boardId);
      else if(GridType.Rfq.equals(ctx.grid))
         return ctx.row.getString(AmpRfq.parentBoardId);
      else
         return null;
   }

   public ObjectProperty<SelectionContext> selectionContextProperty() {
      return selectionContextProperty;
   }

   /*
    * The selected security context
    */
   private final ObjectProperty<SelectedRowCellContext> selectedSecurityRow = new SimpleObjectProperty<>(null);

   /*
    * The selected order context
    */
   private final ObjectProperty<SelectedRowCellContext> selectedOrderRow = new SimpleObjectProperty<>(null);

   /*
    * The selected order book order context
    */
   private final ObjectProperty<SelectedRowCellContext> selectedObboRow = new SimpleObjectProperty<>(null);

   /*
    * Selected Security Row methods
    */

   private final ObjectProperty<SelectedRowCellContext> selectedRfqRow = new SimpleObjectProperty<>(null);

   public ObservableValue<SelectedRowCellContext> selectedSecurityRowProperty() {
      return selectedSecurityRow;
   }

   public ObservableValue<SelectedRowCellContext> selectedOrderRowProperty() {
      return selectedOrderRow;
   }

   public ObjectProperty<SelectedRowCellContext> getSelectedRfqRow(){return selectedRfqRow;}

   /*
    * Selected Obbo Row methods
    */
   public SelectedRowCellContext getSelectedObboRow() {
      return selectedObboRowProperty().getValue();
   }

   public boolean isSecSelected(String secCode, String boardId) {
      return !(secCode == null || boardId == null) &&
         (selectedSecurityRow.get() != null) &&
         (selectedSecurityRow.get().selectedRow != null) &&
         secCode.equals(selectedSecurityRow.get().selectedRow.getString(WatchlistAcc.secCode)) &&
         boardId.equals(selectedSecurityRow.get().selectedRow.getString(WatchlistAcc.boardId));

   }

   public ObservableValue<SelectedRowCellContext> selectedObboRowProperty() {
      return selectedObboRow;
   }

   private void resetSelectionsExceptFor(GridType exemption) {
      if (exemption != GridType.Watchlist) {
         this.selectedSecurityRow.set(null);
      }

      if (exemption != GridType.Orders) {
         this.selectedOrderRow.set(null);
      }

      if (exemption != GridType.OBBO_BUY && exemption != GridType.OBBO_SELL) {
         this.selectedObboRow.set(null);
      }
   }

   @Override
   public Future<Void> startModule() {
      xfeSession.getUnderlyingSession().addPostLogoffTask(() -> {
         selectionContextProperty.set(NULL_CONTEXT);
         selectedSecurityRow.set(null);
         selectedOrderRow.set(null);
         selectedObboRow.set(null);
         secBoardContext.reset();
         return Future.SUCCESS;
      });
      return Future.SUCCESS;
   }

   public final Lazy<ObservableValue<GridType>> gridTypeProperty = new Lazy<ObservableValue<GridType>>() {
      @Override
      protected ObservableValue<GridType> initialize() {
         return Fx.map(selectionContextProperty, new Fun1<SelectionContext, GridType>() {
            @Override
            public GridType call(SelectionContext selectionContext) {
               return selectionContext.grid;
            }
         });
      }
   };

   public final Lazy<SecBoardContext> secBoardContext = new Lazy<SecBoardContext>() {
      @Override
      protected SecBoardContext initialize() {
         SecBoardContext secBoardContext = new SecBoardContext(securitiesDataModule, xfeSession.getUnderlyingSession());
         secBoardContext.selectionContextProperty().bind(selectionContextProperty);
         return secBoardContext;
      }

      @Override
      public void reset() {
         if (isInitialized()) {
            get().selectionContextProperty().unbind();
            get().selectionContextProperty().set(null);
         }
         super.reset();
      }
   };


   private Runnable onDoubleClicked = () -> {
   };

   public final Runnable getOnDoubleClicked() {
      return onDoubleClicked;
   }

   public final void addOnDoubleClicked(Runnable runnable) {
      Runnable lastOnDoubleClicked = onDoubleClicked;

      onDoubleClicked = () -> {
         runnable.run();
         lastOnDoubleClicked.run();
      };
   }

   private static boolean isRfsInstrument(String secCode) {
      return secCode.startsWith(RFS_SEC_CODE_PREFIX1) ||
         secCode.startsWith(RFS_SEC_CODE_PREFIX2);
   }

}
