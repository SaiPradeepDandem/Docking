package xfe.icap.modules.obbo;

import javafx.scene.layout.Pane;
import xfe.icap.types.ObboFilters;
import xfe.icap.types.OrderBookOrder;
import xfe.icap.types.OrderBookSide;
import xfe.util.Constants;
import xfe.util.XfePickupAction;
import xstr.util.Fx;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpOrderBookByOrder;
import xfe.util.XfeAction;
import xfe.icap.modules.watchlist.OrderSpecialTypeDecorator;
import xstr.session.ObservableReplyRow;
import xfe.ui.ConfirmView;
import xfe.ui.notifications.ModalAlertModule;
import xfe.ui.table.DynamicTableCell;
import xfe.ui.table.TableCellFactory;
import xfe.ui.table.TableCellFactory.Me;
import xfe.ui.table.Tables;
import xfe.ui.table.XfeDynamicActionCell;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.ListView;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.*;
import javafx.scene.layout.HBox;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.Fun1;
import xstr.util.Proc2;
import xstr.util.exception.XtrException;

import java.text.DecimalFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static xfe.ui.table.Cells.*;

class ObboTableViewSpec implements Constants {
   private static final String COL_NAME_PICKUP = "Pickup";
   private static final String COL_NAME_REFER = "Refer";
   private static final String COL_NAME_LL = "LL";
   private static final String COL_NAME_MIN = "Min";
   private static final String COL_NAME_TYPE = "Type";
   private static final String COL_NAME_FIRM = "Firm";
   private static final String COL_NAME_TOTAL = "Total";
   private static final String COL_NAME_QTY = "Qty";
   private static final String COL_NAME_PRICE = "Price";

   private static final Map<String, Integer> WIDTHS_NORMAL_SEC_NORMAL_VIEW = new HashMap<>();
   private static final Map<String, Integer> WIDTHS_RFS_SEC_NORMAL_VIEW = new HashMap<>();
   private static final Map<String, Integer> WIDTHS_NORMAL_SEC_POPUP_VIEW = new HashMap<>();
   private static final Map<String, Integer> WIDTHS_RFS_SEC_POPUP_VIEW = new HashMap<>();
   static {
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_PICKUP, 0);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_REFER, 20);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_LL, 0);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_MIN, 38);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_TYPE, 65);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_FIRM, 74);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_TOTAL, 74);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_QTY, 67);
      WIDTHS_NORMAL_SEC_NORMAL_VIEW.put(COL_NAME_PRICE, 67);

      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_PICKUP, 15);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_REFER, 0);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_LL, 54);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_MIN, 38);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_TYPE, 0);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_FIRM, 54);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_TOTAL, 60);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_QTY, 55);
      WIDTHS_RFS_SEC_NORMAL_VIEW.put(COL_NAME_PRICE, 55);

      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_PICKUP, 0);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_REFER, 0);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_LL, 0);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_MIN, 38);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_TYPE, 68);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_FIRM, 81);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_TOTAL, 81);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_QTY, 72);
      WIDTHS_NORMAL_SEC_POPUP_VIEW.put(COL_NAME_PRICE, 72);

      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_PICKUP, 0);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_REFER, 0);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_LL, 55);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_MIN, 38);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_TYPE, 0);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_FIRM, 55);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_TOTAL, 63);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_QTY, 60);
      WIDTHS_RFS_SEC_POPUP_VIEW.put(COL_NAME_PRICE, 60);
   }

   private final XfeSession xfeSession;
   private final String loggedOnuserId;
   private final boolean isBidSide;
   private final BooleanProperty bidOnLeftProperty;
   private final ObboFilters filters;
   private final OrderBookSide orderBookSide;

   private static final Logger logger = LoggerFactory.getLogger(ObboTableViewSpec.class);


   private final EventHandler<MouseEvent> mouseClickedHandler;
   private final Map<String, Integer> normalWidths;
   private final Map<String, Integer> rfsWidths;

   private int startIndex;
   private final EventHandler<MouseEvent> dragDetectedHandler = new EventHandler<MouseEvent>() {
	   @Override
	   public void handle(MouseEvent mouseEvent) {

		   @SuppressWarnings("unchecked") TableCell<ObservableReplyRow, String> tableCell = (TableCell<ObservableReplyRow, String>)mouseEvent.getSource();

		   if (!tableCell.isEmpty()) {
			   Dragboard dragBoard = tableCell.startDragAndDrop(TransferMode.LINK);
			   ClipboardContent content = new ClipboardContent();
			   ObservableReplyRow row = tableCell.getTableView().getItems().get(tableCell.getIndex());
			   content.put(DataFormat.PLAIN_TEXT, row.toString());
			   dragBoard.setContent(content);

			   Fx.runLater(() -> startIndex = tableCell.getIndex());
		   }

		   mouseEvent.consume();
	   }
   };

   private final EventHandler<DragEvent> dragOverHandler = new EventHandler<DragEvent>() {
      @Override
      public void handle(DragEvent dragEvent) {

         Object gestureSource = dragEvent.getGestureSource();

         if (gestureSource instanceof TableCell) {
            TableCell<?, ?> sourceTableCell = (TableCell<?, ?>)gestureSource;

            @SuppressWarnings("unchecked") TableCell<ObservableReplyRow, String> tableCell = (TableCell<ObservableReplyRow, String>)dragEvent.getSource();
            if (!sourceTableCell.isEmpty() && !tableCell.isEmpty()) {
               @SuppressWarnings("unused") ObservableReplyRow row = tableCell.getTableView().getItems().get(tableCell.getIndex());

               if (!tableCell.isEmpty()) {
                  if (sourceTableCell.getTableView() == tableCell.getTableView()) {
                     dragEvent.acceptTransferModes(TransferMode.LINK);

                     int currentIndex = tableCell.getIndex();
                     if (currentIndex != startIndex) {
                    	 obboModule.dragObboRows(orderBookSide.isBuy(), currentIndex + 1);
                    	 startIndex = currentIndex;
                     }

                     obboModule.sideProperty.set(orderBookSide.side);
                  }
               }
            }
         }

         dragEvent.consume();
      }
   };

   private final EventHandler<DragEvent> dragDroppedHandler = dragEvent -> {
       dragEvent.setDropCompleted(true);
       dragEvent.consume();
   };

   private final EventHandler<DragEvent> dragDoneHandler = dragEvent -> {
       Fx.runLater(() -> {
       //obboModule.dragObboRows(null, null);
       });

       dragEvent.consume();
   };

   private final ObboModule obboModule;
   private final ModalAlertModule eventNotification;

   private final ObjectProperty<XfePickupAction> pickedupActionProp;
   private final boolean is4PopupStage;
   private final Callback<ObservableReplyRow, Void> updateObboSelection;
   private final Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> dClickHandler = new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow,?>>() {
	   @Override
	   public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
		   updateObboSelection.call(row);
	   }
   };

   ObboTableViewSpec(
         XfeSession session,
         ObboModule obboModule,
         ModalAlertModule eventNotification,
         boolean isBidside,
         BooleanProperty bidOnLeftProperty,
         OrderBookSide orderBookSide,
         ObjectProperty<XfePickupAction> pickedupActionProp,
         Callback<ObservableReplyRow, Void> updateObboSelection,
         boolean is4PopupStage) {
      this.obboModule = obboModule;
      this.eventNotification = eventNotification;
      this.bidOnLeftProperty = bidOnLeftProperty;
      this.xfeSession = session;
      loggedOnuserId = session.getUnderlyingSession().getLoggedOnUserId();
      this.isBidSide = isBidside;
      this.orderBookSide = orderBookSide;
      this.filters = session.getObboFilters();
      this.pickedupActionProp = pickedupActionProp;
      this.updateObboSelection = updateObboSelection;
      boolean isBroker = xfeSession.getUnderlyingSession().isLoggedOnUserBroker();
      mouseClickedHandler = mouseEvent -> {

          if (is4PopupStage) return;

         @SuppressWarnings("unchecked") TableCell<ObservableReplyRow, String> tableCell = (TableCell<ObservableReplyRow, String>)mouseEvent.getSource();

         if (!tableCell.isEmpty()) {
            obboModule.clickObboRow(orderBookSide.isBuy(), tableCell.getIndex());
            if(xfeSession.rfsPickup.get()){
               ObservableReplyRow row = tableCell.getTableView().getSelectionModel().getSelectedItem();
               obboModule.setPickupPrice(row.getValue(AmpOrderBookByOrder.price));
               obboModule.setPickupQuantity(row.getValue(AmpOrderBookByOrder.quantity));
            }
         }

         mouseEvent.consume();
      };

      this.is4PopupStage = is4PopupStage;

      if (is4PopupStage) {
         normalWidths = WIDTHS_NORMAL_SEC_POPUP_VIEW;
         rfsWidths = WIDTHS_RFS_SEC_POPUP_VIEW;
         createPopupCols(isBroker);
      }
      else {
         normalWidths = WIDTHS_NORMAL_SEC_NORMAL_VIEW;
         rfsWidths = WIDTHS_RFS_SEC_NORMAL_VIEW;
         createNormalCols(isBroker);
      }
   }

   private TableColumn<ObservableReplyRow, XfeAction> createReferColumn() {
      TableColumn<ObservableReplyRow, XfeAction> col = new TableColumn<ObservableReplyRow, XfeAction>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_REFER : COLUMN_ID_OBBO_OFFER_REFER;
         }
      };

      /**
       * Can't define rfq Filter in ObboFilters, since ObboFilters is in "core" while Rfqs is defined in "APP"
       */
      if (!is4PopupStage) {
         col.setCellFactory(
                 XfeDynamicActionCell.factory(actionCell())
                         .overlay("xfe-sweep-selection"));
//                         .sweep(sweepToIndex));
      }

      col.setResizable(false);
      return col;
   }

   private TableColumn<ObservableReplyRow, XfeAction> createPickupColumn() {
      TableColumn<ObservableReplyRow, XfeAction> col = new TableColumn<ObservableReplyRow, XfeAction>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_REFER : COLUMN_ID_OBBO_OFFER_REFER;
         }
      };

      /**
       * Can't define rfq Filter in ObboFilters, since ObboFilters is in "core" while Rfqs is defined in "APP"
       */
      col.setCellFactory(
              XfeDynamicActionCell.factory(pickupActionCell(obboModule, eventNotification))
                 .overlay("xfe-sweep-selection"));
//                      .sweep(sweepToIndex));

      col.setResizable(false);
      return col;
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> minFillColFactory() {
      return TableCellFactory.of(asnEmptyZeroNumberCell(AmpOrderBookByOrder.minTradeSize)
              .textTooltip()
              .basic());
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> typeColFactory() {
      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cellFactory =
              DynamicTableCell.defaultCell(OrderSpecialTypeDecorator.orderSpecialTypeObs(AmpOrderBookByOrder.specialOrderType));

      return TableCellFactory.of(cellFactory
         .style(CELL_STYLE_OBBO_TYPE)
         .style(isBidSide ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
         .textTooltip());
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> lastLookTimeColFactory() {
      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cellFactory =
              TableCellFactory.of(asnStringCell(AmpOrderBookByOrder.lastLookTime));

      return TableCellFactory.of(cellFactory
              .style(CELL_STYLE_INSTR_TYPE)
              .textTooltip()
              .basic());
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> firmColFactory() {
      return TableCellFactory.of(
              asnStringCell(AmpOrderBookByOrder.firmId)
                      .style(CELL_STYLE_INSTR_TYPE)
                 .textTooltip()
                 .basic());
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>>
   totalColFactory(Fun1<ObservableReplyRow, ? extends ObservableValue<Double>> getter) {
      return TableCellFactory.of(
              asnEmptyZeroNumberCell(getter, new DecimalFormat("#.#"))
                      .textTooltip()
                      .basic());
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> qtyColFactory() {
      return TableCellFactory.of(
         asnEmptyZeroNumberCell(AmpOrderBookByOrder.quantity)
            .style(CELL_STYLE_OBBO_QTY)
            .style(isBidSide ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
            .textTooltip()
            .basic());
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> priceColFactory() {
      return TableCellFactory.of(fingerPrint(
         asnNumberCell(AmpOrderBookByOrder.price)
            .toggleStyle(CLEARING_STYLE, ObboFilters.isClearing)
            .toggleStyle(CLEARINGTOYOU_STYLE, ObboFilters.isClearingToYou)
            .textTooltip()
            .strong()
            .style(CELL_STYLE_OBBO_PRICE)
            .style(isBidSide ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
            .style("cell-number-padding")));
   }

   private Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>>
   sweepColFactory(Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> colFactory) {
      return TableCellFactory.of(colFactory.overlay("xfe-sweep-selection")
//              .sweep(sweepToIndex)
              .onMouseClicked(mouseClickedHandler)
              .onDragDetected(dragDetectedHandler)
              .onDragOver(dragOverHandler)
              .onDragDropped(dragDroppedHandler)
              .onDragDone(dragDoneHandler));
   }

   private TableColumn<ObservableReplyRow, String> createMinFillColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<ObservableReplyRow, String>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_MINFILL : COLUMN_ID_OBBO_OFFER_MINFILL;
         }
      };

      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cf = minFillColFactory();
      if (!is4PopupStage) cf = sweepColFactory(cf);
      cf.setCellFactoryIn(col);

      col.setText(COL_NAME_MIN);
      col.setResizable(false);
      col.setSortable(false);

      return col;
   }

   private TableColumn<ObservableReplyRow, String> createTypeColumn() {

      TableColumn<ObservableReplyRow, String> col = new TableColumn<ObservableReplyRow, String>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_TYPE : COLUMN_ID_OBBO_OFFER_TYPE;
         }
      };

      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cf = typeColFactory();
      if (!is4PopupStage) cf = sweepColFactory(cf);
      cf.setCellFactoryIn(col);

      col.setText(COL_NAME_TYPE);
      col.setResizable(false);
      col.setSortable(false);

      return col;
   }

   private TableColumn<ObservableReplyRow, String> createLastLookTimeColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<ObservableReplyRow, String>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_LASTLOOKTIME : COLUMN_ID_OBBO_OFFER_LASTLOOKTIME;
         }
      };

      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cf = lastLookTimeColFactory();
      if (!is4PopupStage) cf = sweepColFactory(cf);
      cf.setCellFactoryIn(col);

      col.setText(COL_NAME_LL);
      col.setResizable(false);
      col.setSortable(false);

      return col;
   }

   private TableColumn<ObservableReplyRow, String> createFirmColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<ObservableReplyRow, String>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_FIRM : COLUMN_ID_OBBO_OFFER_FIRM;
         }
      };

      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cf = firmColFactory();
      if (!is4PopupStage) cf = sweepColFactory(cf);
      cf.setCellFactoryIn(col);

      col.setText(COL_NAME_FIRM);
      col.setResizable(false);
      col.setSortable(false);

      return col;
   }

   private TableColumn<ObservableReplyRow, String> createTotalColumn(Fun1<ObservableReplyRow, ? extends ObservableValue<Double>> getter) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<ObservableReplyRow, String>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_TOTAL : COLUMN_ID_OBBO_OFFER_TOTAL;
         }
      };

      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cf = totalColFactory(getter);
      if (!is4PopupStage) cf = sweepColFactory(cf);
      cf.setCellFactoryIn(col);

      col.setText(COL_NAME_TOTAL);
      col.setResizable(false);
      col.setSortable(false);

      return col;
   }



   private TableColumn<ObservableReplyRow, String> createQtyColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<ObservableReplyRow, String>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_QTY : COLUMN_ID_OBBO_OFFER_QTY;
         }
      };

      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cf = qtyColFactory();
      if (!is4PopupStage) cf = sweepColFactory(cf);
      cf.setCellFactoryIn(col);

      col.setText(COL_NAME_QTY);
      col.setResizable(false);
      col.setSortable(false);

      return col;
   }

   private TableColumn<ObservableReplyRow, String> createPriceColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<ObservableReplyRow, String>(){
         @Override
         public String toString() {
            return isBidSide ? COLUMN_ID_OBBO_BID_PRICE : COLUMN_ID_OBBO_OFFER_PRICE;
         }
      };


      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> cf = priceColFactory();
      if (!is4PopupStage) {
         cf = sweepColFactory(cf);
      } else {
         cf = TableCellFactory.of(cf.doubleClickHandler(dClickHandler));
      }
      cf.setCellFactoryIn(col);

      col.setText(isBidSide ? Constants.COLUMN_NAME_BID : Constants.COLUMN_NAME_OFFER);
      col.setResizable(false);
      col.setSortable(false);

      return col;
   }

   private <S extends TableCellFactory<S, ObservableReplyRow, T, U>, T, U extends TableCell<ObservableReplyRow, T>> TableCellFactory<S, ObservableReplyRow, T, U> fingerPrint(TableCellFactory<S, ObservableReplyRow, T, U> wrappedCellFactory) {
      return wrappedCellFactory
      .toggleStyle(STALE_STYLE, filters.isStaleStyle.get())
      .toggleStyle(SHARED_STYLE, filters.isOursStyle.get())
      .toggleStyle(MINE_BROKER_STYLE, filters.isMineBrokerStyle.get())
      .toggleStyle(CREDIT_BAD_STYLE, filters.isCreditUnavailableStyle.get())
      .toggleStyle(CREDIT_GOOD_STYLE, filters.isCreditAvailableStyle.get())
      .toggleStyle(MINE_STYLE, filters.isMineStyle.get())
      .toggleStyle(CLEARING_STYLE, filters.isClearingStyle.get())
      .toggleStyle(CLEARING_STYLE, filters.isClearingToYouStyle.get())
      ;
   }


   private Callback<? super ObservableReplyRow, ? extends ObservableValue<? extends XfeAction>> actionCell() {
      return row -> {
         XfeAction action = new XfeAction();
         return populateReferAction(row, action);
      };
   }

   private ObservableValue<? extends XfeAction> populateReferAction(ObservableReplyRow row, XfeAction action) {
      boolean isClone = "Clone".equals(row.getProperty(AmpOrderBookByOrder.specialOrderType).get());
      if (!isClone) {
         ObservableBooleanValue isAmendableBooelanV = filters.isAmendable.accept(row);
         if (logger.isTraceEnabled()) {
            isAmendableBooelanV.addListener(paramObservable -> {
               logger.debug("isAmendableBooelanV is changed to {}" ,isAmendableBooelanV.get());
            });
         }
         action.availableProperty().bind(isAmendableBooelanV);
         action.getStyleClass().add(CELL_STYLE_REFER);
         action.setText("R");
         action.setOnAction(actionEvent -> {
            OrderBookOrder obbo = null;

            obbo = new OrderBookOrder(row);

            if (obbo != null) {
               try {
                  obbo.refer(xfeSession, null);
               } catch (XtrException e) {
                  e.printStackTrace();
               }
            }
         });
      }
      return Fx.constOf(action);
   }

   private Callback<? super ObservableReplyRow, ? extends ObservableValue<? extends XfeAction>> pickupActionCell(ObboModule obboModule, ModalAlertModule eventNotification) {
      return row -> {
         Long orderId = row.getValue(AmpOrderBookByOrder.orderNo);
         XfePickupAction existAction = pickedupActionProp.get();
         if(existAction!=null && existAction.getId()==orderId){
            return Fx.constOf(existAction);
         }
         XfePickupAction action = new XfePickupAction();
         String userId = row.getValue(AmpOrderBookByOrder.userId);
         boolean isMyOrder = loggedOnuserId.equals(userId);
         Boolean isSharedObj = row.getValue(AmpOrderBookByOrder.shared);
         Boolean isShared = !isMyOrder && (isSharedObj != null && isSharedObj);
         boolean isAllowRefer = isMyOrder || isShared ;
         String groupId = row.getValue(AmpOrderBookByOrder.groupId);
         boolean isDeskOrder = false;
         if (xfeSession.traderFirmMap != null)
            isDeskOrder = !isAllowRefer && xfeSession.traderFirmMap.isInSameDesk(loggedOnuserId, groupId);
         if (isDeskOrder) {
            return Fx.constOf((XfeAction)null);
         }
         if(!isAllowRefer) {
            if (orderId != null) {
               action.setId(orderId);
            } else {
               action.setId(Long.MIN_VALUE);
            }
         }
         String orderType = row.getValue(AmpOrderBookByOrder.specialOrderType);
         boolean isIndicative = Constants.PRICE_TYPE_INDICATIVE.equalsIgnoreCase(orderType);
         try {
            action.availableProperty().set(!isIndicative || isAllowRefer);
            action.setText("P");

            if(isAllowRefer){
               populateReferAction(row, action);
            }/*end of refer action*/else if (!isIndicative) {
               action.getStyleClass().add(PICKUP_ACTION_STYLE);
               action.availableProperty().bind(obboModule.dataContextModule.getPickableBinding());
//                  System.out.println("action.availableProperty() is "+action.availableProperty().get());
               action.setOnAction(actionEvent -> {
                  if (obboModule.selectionContextModule.dataContextRfsSec.get() || obboModule.selectionContextModule.dataContextRfqSec.get()) {
                     if (pickedupActionProp.get() == action) {
                        xfeSession.rfsPickup.set(false);
                        pickedupActionProp.set(null);
                        return;
                     }
                     xfeSession.rfsPickup.set(true);
                     xfeSession.pickedUpRow.set(row);
                     pickedupActionProp.set(action);
                     // tocheck restroe
                     double quantity = row.getValue(AmpOrderBookByOrder.quantity);
                     obboModule.setPickupQuantity(quantity);
                  } else {
                     eventNotification.showModalView(ConfirmView.create("Do you wish to trade " +
                             row.getString(AmpOrderBookByOrder.quantityAsString) +
                             " at "
                             + row.getString(AmpOrderBookByOrder.priceAsString) +
                             " with " +
                             row.getString(AmpOrderBookByOrder.firmId) +
                             "?", () -> {
                                try {
                                   try {
                                      OrderBookOrder obboOrder = new OrderBookOrder(row);
                                      String secCode = obboModule.getCurrentSecCode();
                                      if(secCode!=null){
                                         String boardId = obboModule.getCurrentBoardId();
                                         obboOrder.pickedup(xfeSession, secCode, boardId);
                                      }
                                   } catch (Exception e) {
                                      if (eventNotification != null)
                                         eventNotification.showError("Sending trades to TE failed due to exception " + e);
                                      logger.error("Sending trades to TE failed due to exception ", e);
                                   }

                                } catch (Exception e) {
                                   e.printStackTrace();
                                }
                             }));
                  }
               });
            }//end of pickup action.

         } catch (Exception e) {
            logger.info(e.toString(), e);
         }
         return Fx.constOf(action);
      };
   }

   private TableColumn<ObservableReplyRow, String> totalColumn;
   private TableColumn<ObservableReplyRow, String> qtyColumn;
   private TableColumn<ObservableReplyRow, String> priceColumn;
   private TableColumn<ObservableReplyRow, String> llColumn;
   private TableColumn<ObservableReplyRow, String> minFillColumn;
   private TableColumn<ObservableReplyRow, XfeAction> pickupColumn;
   private TableColumn<ObservableReplyRow, XfeAction> referColumn;
   private TableColumn<ObservableReplyRow, String> typeColumn;
   private TableColumn<ObservableReplyRow, String> firmColumn;

   private final java.util.List<TableColumn<ObservableReplyRow, ?>> columns_RFS_bidLeft = new java.util.ArrayList<>(10);
   private final java.util.List<TableColumn<ObservableReplyRow, ?>> columns_RFS_bidRight = new java.util.ArrayList<>(10);
   private final java.util.List<TableColumn<ObservableReplyRow, ?>> columns_bidLeft = new java.util.ArrayList<>(10);
   private final java.util.List<TableColumn<ObservableReplyRow, ?>> columns_bidRight = new java.util.ArrayList<>(10);

   private void createPopupCols(boolean isBroker) {
      createAllCols();

      columns_RFS_bidLeft.add(llColumn);
      columns_RFS_bidLeft.add(minFillColumn);
      columns_RFS_bidLeft.add(firmColumn);
      columns_RFS_bidLeft.add(totalColumn);
      columns_RFS_bidLeft.add(qtyColumn);
      columns_RFS_bidLeft.add(priceColumn);
      columns_RFS_bidRight.addAll(columns_RFS_bidLeft);
      Collections.reverse(columns_RFS_bidRight);

      columns_bidRight.add(priceColumn);
      columns_bidRight.add(qtyColumn);
      if(isBroker){
         columns_bidRight.add(firmColumn);
      }else {
         columns_bidRight.add(totalColumn);
      }
      columns_bidRight.add(typeColumn);
      columns_bidRight.add(minFillColumn);
      columns_bidLeft.addAll(columns_bidRight);
      Collections.reverse(columns_bidLeft);
   }

   private void createNormalCols(boolean isBroker) {
      createAllCols();

      columns_RFS_bidLeft.add(pickupColumn);
      columns_RFS_bidLeft.add(llColumn);
      columns_RFS_bidLeft.add(minFillColumn);
      columns_RFS_bidLeft.add(firmColumn);
      columns_RFS_bidLeft.add(totalColumn);
      columns_RFS_bidLeft.add(qtyColumn);
      columns_RFS_bidLeft.add(priceColumn);
      columns_RFS_bidRight.addAll(columns_RFS_bidLeft);
      Collections.reverse(columns_RFS_bidRight);

      columns_bidRight.add(priceColumn);
      columns_bidRight.add(qtyColumn);
      if(isBroker){
         columns_bidRight.add(firmColumn);
      }else {
         columns_bidRight.add(totalColumn);
      }
      columns_bidRight.add(typeColumn);
      columns_bidRight.add(minFillColumn);
      columns_bidRight.add(referColumn);
      columns_bidLeft.addAll(columns_bidRight);
      Collections.reverse(columns_bidLeft);
   }

   private void createAllCols() {
      minFillColumn = createMinFillColumn();
      llColumn = createLastLookTimeColumn();
      pickupColumn = createPickupColumn();
      firmColumn = createFirmColumn();
      totalColumn= createTotalColumn(orderBookSide.totalAvailableQuantityGetter);
      qtyColumn= createQtyColumn();
      priceColumn = createPriceColumn();
      typeColumn = createTypeColumn();
      referColumn = createReferColumn();
   }

   @SuppressWarnings("deprecation")
   void applyTo(TableView<ObservableReplyRow> tableView) {
      ChangeListener<Boolean> showRfqListener = (_0, _1, newShowRfq) -> {

         ObservableList<TableColumn<ObservableReplyRow, ?>> columns = tableView.getColumns();
         boolean isRFSorRFQ = obboModule.dataContextModule.dataContextIsNeedPickupColumn.get();

         Map<String, Integer> colWidths = normalWidths;
         if (isRFSorRFQ) {
            colWidths = rfsWidths;
         }

         minFillColumn.setPrefWidth(colWidths.get(COL_NAME_MIN));
         llColumn.setPrefWidth(colWidths.get(COL_NAME_LL));
         pickupColumn.setPrefWidth(colWidths.get(COL_NAME_PICKUP));
         firmColumn.setPrefWidth(colWidths.get(COL_NAME_FIRM));
         typeColumn.setPrefWidth(colWidths.get(COL_NAME_TYPE));
         referColumn.setPrefWidth(colWidths.get(COL_NAME_REFER));
         totalColumn.setPrefWidth(colWidths.get(COL_NAME_TOTAL));
         qtyColumn.setPrefWidth(colWidths.get(COL_NAME_QTY));
         priceColumn.setPrefWidth(colWidths.get(COL_NAME_PRICE));

         if (isRFSorRFQ) {
            if (isBidSide == bidOnLeftProperty.get()) {
               columns.setAll(columns_RFS_bidLeft);
            } else {
               columns.setAll(columns_RFS_bidRight);
            }
         } else {
            if (isBidSide != bidOnLeftProperty.get()) {
               columns.setAll(columns_bidRight);
            } else {
               columns.setAll(columns_bidLeft);
            }
         }
      };

      obboModule.dataContextModule.dataContextIsNeedPickupColumn.removeListener(showRfqListener);
      if (!is4PopupStage) {
         obboModule.dataContextModule.dataContextIsNeedPickupColumn.addListener(showRfqListener);
      }

      showRfqListener.changed(null, false, false);

      tableView.setItems(orderBookSide.orders);

      setPlaceholderColumns(tableView);
   }

   void setPlaceholderColumns(TableView<ObservableReplyRow> tableView) {
      HBox placeholder = new HBox();

      double tableWidth = 0.0;
      for (TableColumn col : tableView.getColumns()) {
         tableWidth += col.getWidth();
      }

      final double mainPartWidth = tableWidth - priceColumn.getWidth();
      final Pane mainPartPane = (Pane) Tables.stripedRowCSSPlaceholder();
      mainPartPane.setPrefWidth(mainPartWidth);
      final Pane bidOfferPartPane = (Pane) Tables.stripedRowCSSPlaceholder();
      bidOfferPartPane.setPrefWidth(priceColumn.getWidth());

      //	need to listen to change in settings (BID/OFFER -> OFFER/BID)
      if (isBidSide == bidOnLeftProperty.get()) {
         placeholder.getChildren().addAll(mainPartPane, bidOfferPartPane);
         mainPartPane.getStyleClass().add("xfe-right-border");
         bidOfferPartPane.getStyleClass().add("xfe-left-border");
      } else {
         placeholder.getChildren().addAll(bidOfferPartPane, mainPartPane);
         bidOfferPartPane.getStyleClass().add("xfe-right-border");
         mainPartPane.getStyleClass().add("xfe-left-border");
      }

	   tableView.setPlaceholder(placeholder);
   }

   public void dispose() {
      obboModule.dataContextModule.dataContextRfsOrRfqSec.clearListeners();
   }

}
