package xfe.icap.types;

import xstr.util.Fun0;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableStringValue;
import javafx.util.Callback;

import xstr.types.TradeSide;
import xstr.session.QueryReplyRow;
import xstr.amp.AsnConversionAccessor;
import xstr.util.Fx;
import xfe.icap.amp.AmpTrade;
import xstr.session.ObservableReplyRow;

public class TradesFactory {
   private static Callback<QueryReplyRow, ObservableStringValue> traderValueFactory;
   private static Callback<QueryReplyRow, ObservableStringValue> traderValueFactory_buy;
   private static Callback<QueryReplyRow, ObservableStringValue> traderValueFactory_sell;

   public static Callback<QueryReplyRow, ObservableStringValue> traderValueFactory() {
      if (traderValueFactory == null) {
         traderValueFactory = r -> {
            String buyId = r.getValue(AmpTrade.buyTraderId);
            String sellId = r.getValue(AmpTrade.sellTraderId);

            String trader;

            if (buyId != null && sellId != null)
               trader = String.format("%s/%s", sellId, buyId);
            else
               trader = buyId == null ? sellId : buyId;

            return Fx.constOf(trader);
         };
      }

      return traderValueFactory;
   }

   public static Callback<QueryReplyRow, ObservableStringValue> traderValueFactory(TradeSide side) {
      Callback<QueryReplyRow, ObservableStringValue> valueFac = side ==TradeSide.BUY ? traderValueFactory_buy : traderValueFactory_sell;
      if (valueFac == null) {
         valueFac = r -> {
            String traderId = (side==TradeSide.BUY ?  r.getValue(AmpTrade.buyTraderId) : r.getValue(AmpTrade.sellTraderId));
            return Fx.constOf(traderId);
         };
      }
      if(side==TradeSide.BUY){
         traderValueFactory_buy = valueFac;
      }else{
         traderValueFactory_sell = valueFac;
      }
      return valueFac;
   }

   public static Callback<ObservableReplyRow, ObservableStringValue> stpStatusFactory(boolean isBuy) {
      AsnConversionAccessor<String> acc = isBuy ? AmpTrade.buySTPStatusAsString : AmpTrade.sellSTPStatusAsString;

      return r -> {
         ObservableObjectValue<String> stpStatus = r.getProperty(acc);

         return Bindings.createStringBinding(new Fun0<String>() {
            @Override
            public String call() {
               return stpStatus.get().replaceFirst("Stp Status ", "");
            }
         }, stpStatus);
      };
   }

   public static Callback<ObservableReplyRow, ObservableStringValue> buyStpStatusFactory() {
      return stpStatusFactory(true);
   }

   public static Callback<ObservableReplyRow, ObservableStringValue> sellStpStatusFactory() {
      return stpStatusFactory(false);
   }
}
