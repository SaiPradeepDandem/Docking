package xfe.icap.modules.iswaporders;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import xfe.ui.control.IconButton;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.modules.actionsui.ActionButton;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.*;
import xfe.modules.ordersui.GlobalReferBtnsView;

public class GlobalReferBtnsPane implements GlobalReferBtnsView<Node> {
	private Presenter<Node> presenter;
	private HBox rootNode;

   public Node getRootElement() {
      if (rootNode == null) {
         rootNode = new HBox();
         rootNode.setSpacing(15);
         rootNode.setPadding(new Insets(1,15,1,1));
         rootNode.setAlignment(Pos.CENTER_RIGHT);
         final Button referMine = createButton("xfe-iswap-settings-btn-referMine");
         final Button referAll = createButton("xfe-iswap-settings-btn-referAll");
         presenter.referMineAction().bindTo(referMine);
         presenter.referAllAction().bindTo(referAll);
         rootNode.getChildren().addAll(referMine, referAll);
      }
      return rootNode;
   }

	private Button createButton(String id) {
      IconButton button = new IconButton();
      button.setId(id);
      button.setPrefWidth(20);
      button.setMaxWidth(20);
      button.setPrefHeight(30);
      XfeTooltipFactory.setTooltip(button);
      return button;
   }

   @Override
   public void setPresenter(Presenter<Node> presenter) {
		this.presenter = presenter;
	}

	@Override
	public void requestFocus() {
		// TODO Auto-generated method stub
	}
}
