package xfe.icap.modules.sectabsui;

import javafx.animation.Animation;
import javafx.animation.Timeline;
import javafx.util.Duration;
import xfe.ui.flasher.PseudoFlasher;

import java.math.BigDecimal;

/**
 * Abstract class of all the price cells.
 */
public abstract class WatchlistPriceCell extends WatchlistCell<PriceCellValue<BigDecimal>> {
   /**
    * Timeline for the price flash when price is changed.
    */
   private Timeline priceChangeFlashTimeline;

   @Override
   protected void updateDataItem(PriceCellValue<BigDecimal> item) {
      /* Update the styles*/
      updateStyle();

      /* When the item is in workup state... */
      if (item.isCLOBWorkup() || item.isCMWorkup()) {
         /* And if the cell is not flashing, then add the flasher to the cell */
         if(!PseudoFlasher.isFlashing(this)) {
            setText(getItem().getFlashOffValue());
            PseudoFlasher.addNodeToFlash(this, () -> setText(getItem().getFlashOffValue()), () -> setText(getItem().getFlashOnValue()));
         }
      } else {
         setValue(item);
         /* When the item is NOT in workup state, and also does not have price flash, then ensure to remove the cell from flashing */
         if(!item.hasPriceFlash()){
            PseudoFlasher.removeNodeFromFlash(this);
         }
      }
   }

   @Override
   protected void resetDataItem() {
      super.resetDataItem();
      PseudoFlasher.removeNodeFromFlash(this);
      stopPriceChangeFlash();
   }

   @Override
   protected void resetStyles() {
      super.resetStyles();
      getStyleClass().removeAll(WatchListCellState.getAllStyles());
   }

   /**
    * Sets the value in the cell.
    *
    * @param value Cell item
    */
   protected void setValue(PriceCellValue<BigDecimal> value) {
      if (value == null) {
         setText(null);
      } else {
         setText(value.getFlashOffValue());
      }
   }

   /**
    * Updates the style of the cell based on the state of the item.
    */
   private void updateStyle() {
      /* If cell has not state and has no price flash, reset the styles and stop price flashing */
      if ((getItem().getState() == null || getItem().getState() == WatchListCellState.NONE) && !getItem().hasPriceFlash()) {
         stopPriceChangeFlash();
         resetStyles();
         return;
      }

      final WatchListCellState state = getItem().getState();
      /* If the item has priceFlash, reset the styles -> add price flash style -> start the price flashing if not started */
      if (getItem().hasPriceFlash()) {
         resetStyles();
         getStyleClass().add(getItem().getPriceFlashState().getStyle());
         if (getSecTable().getPriceCellFlashDuration() != null && !isPriceChangeFlashRunning()) {
            this.priceChangeFlashTimeline =
               PseudoFlasher.addNodeToFlashForDuration(
                  this,
                  Duration.seconds(getSecTable().getPriceCellFlashDuration().get()),
                  () -> {
                     PseudoFlasher.removeNodeFromFlash(this);
                     getStyleClass().remove(getItem().getPriceFlashState().getStyle());
                     getStyleClass().add(state.getStyle());
                     return null;
                  });
         }
      } else {
         /* When the item has no priceFlash, first stop price flashing if running */
         stopPriceChangeFlash();
         /* If the cell does not have the current state style, then reset the styles and add the current state style */
         if (!getStyleClass().contains(state.getStyle())) {
            resetStyles();
            getStyleClass().add(state.getStyle());
         }
      }
   }

   /**
    * Stops the price change flash timeLine if running and nullifies the timeLine.
    */
   private void stopPriceChangeFlash() {
      if (isPriceChangeFlashRunning()) {
         priceChangeFlashTimeline.stop();
      }
      priceChangeFlashTimeline = null;
   }

   /**
    * Specifies whether the price change flash timeLine is running or not.
    *
    * @return {@code true} if the price change flash timeLine is running
    */
   private boolean isPriceChangeFlashRunning() {
      return this.priceChangeFlashTimeline != null && this.priceChangeFlashTimeline.getStatus() == Animation.Status.RUNNING;
   }
}
