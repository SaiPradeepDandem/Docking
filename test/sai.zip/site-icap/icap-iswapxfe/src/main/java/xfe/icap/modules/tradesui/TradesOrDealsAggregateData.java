package xfe.icap.modules.tradesui;

import java.math.BigDecimal;

public class TradesOrDealsAggregateData {
   private String secCode;
   private BigDecimal price;
   private BigDecimal myQty;
   private BigDecimal myFirmQty;
   private BigDecimal marketQty;

   public TradesOrDealsAggregateData(String secCode, BigDecimal price, BigDecimal myQty, BigDecimal myFirmQty) {
      this.secCode = secCode;
      this.price = price;
      this.myQty = myQty;
      this.myFirmQty = myFirmQty;
   }

   public TradesOrDealsAggregateData(String secCode, BigDecimal price, BigDecimal myQty, BigDecimal myFirmQty, BigDecimal marketQty) {
      this.secCode = secCode;
      this.price = price;
      this.myQty = myQty;
      this.myFirmQty = myFirmQty;
      this.marketQty = marketQty;
   }

   public String getSecCode() {
      return secCode;
   }

   public BigDecimal getPrice() {
      return price;
   }

   public void setPrice(BigDecimal price) {
      this.price = price;
   }

   public BigDecimal getMyQty() {
      return myQty;
   }

   public void setMyQty(BigDecimal myQty) {
      this.myQty = myQty;
   }

   public BigDecimal getMyFirmQty() {
      return myFirmQty;
   }

   public void setMyFirmQty(BigDecimal myFirmQty) {
      this.myFirmQty = myFirmQty;
   }

   public BigDecimal getMarketQty() {
      return marketQty;
   }

   public void setMarketQty(BigDecimal marketQty) {
      this.marketQty = marketQty;
   }
}
