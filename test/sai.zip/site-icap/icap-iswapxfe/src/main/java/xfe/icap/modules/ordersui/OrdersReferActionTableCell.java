package xfe.icap.modules.ordersui;

import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TableCell;
import xfe.icap.amp.AmpManagedOrder;
import xfe.modules.actions.OrderActionArgs;
import xfe.ui.control.SvgButton;
import xstr.session.ObservableReplyRow;
import xfe.modules.actions.ActionName;
import xfe.ui.control.IconButton;

/**
 * Custom action table cell of Orders to refer/renew the corresponding order.
 */
public class OrdersReferActionTableCell extends TableCell<ObservableReplyRow, Integer> {
   private IconButton referButton;
   private IconButton renewButton;

   @Override
   protected void updateItem(Integer item, boolean empty) {
      super.updateItem(item, empty);
      if (!empty && getTableRow() != null && getTableRow().getItem() != null) {
         // Only showing the icon if the order status is either Open or Refer.
         if (item == null || !(item.equals(AmpManagedOrder.OPENED) || item.equals(AmpManagedOrder.REFERRED))) {
            setGraphic(null);
         } else {
            setGraphic(item.equals(AmpManagedOrder.OPENED) ? getReferButton() : getRenewButton());
         }
      } else {
         setGraphic(null);
      }
   }

   /**
    * Lazy getter of the refer button.
    *
    * @return IconButton
    */
   private IconButton getReferButton() {
      if (this.referButton == null) {
         this.referButton = createButton("xfe-icon-refer-txt", ActionName.ReferOrder);
      }
      return this.referButton;
   }

   /**
    * Lazy getter of renew button.
    *
    * @return IconButton
    */
   private IconButton getRenewButton() {
      if (this.renewButton == null) {
         this.renewButton = createButton("xfe-icon-renew-txt", ActionName.RenewOrder);
      }
      return this.renewButton;
   }

   private IconButton createButton(String iconClass, ActionName actionName) {
      // final SvgButton button = new SvgButton("xfe-svg-bg", iconClass);
      final IconButton button = new IconButton(iconClass);
      button.setText(actionName == ActionName.ReferOrder ? "Refer" : "Reinstate");
      // button.setPrefSize(16,16);
      button.setOnAction(e -> {
         final ObservableReplyRow row = (ObservableReplyRow) getTableRow().getItem();
         getTableView().getSelectionModel().select(row);
         ((OrdersViewTable) getTableView()).getOrderActionConsumer().accept(new OrderActionArgs(actionName, row, this));
      });
      button.setContentDisplay(ContentDisplay.TEXT_ONLY);
      return button;
   }
}
