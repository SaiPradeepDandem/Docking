package xfe.icap.modules.watchlist;

import com.nomx.persist.watchlist.WatchlistSpec_v2;

import java.util.UUID;

/**
 * Created by baasim on 13/07/2016.
 */
class WatchlistView {
   private WatchlistSpec_v2 spec;
   private String title = "";
   private String subtitle = "";
   private final UUID id;

   WatchlistView(String title, String subtitle, UUID id) {
      this.title = title;
      this.subtitle = subtitle;
      this.id = id;
   }

   WatchlistView(WatchlistSpec_v2 spec) {
      this(spec.getTitle(), spec.getSubtitle(), spec.getId());
      this.spec = spec;
   }

   @Override
   public int hashCode() {
      return id.hashCode();
   }

   @Override
   public boolean equals(Object obj) {
      if (obj instanceof WatchlistView) {
         WatchlistView other = (WatchlistView) obj;
         return id.equals(other.id);
      }

      return false;
   }

   public WatchlistSpec_v2 getSpec() {
      return spec;
   }

   public String getTitle() {
      return title;
   }

   public String getSubtitle() {
      return subtitle;
   }

   public UUID getId() {
      return id;
   }
}
