package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;

public class AmpTradeWorkup extends AmpAccessor {
   public static final  AmpTreq txn = AMP.tREQ("tradeWorkup");

   public static final AsnAccessor tradeId = acc(AMP.tREQ("tradeWorkup.tradeId"));

   public static final AsnConversionAccessor<Integer> buySell = acc(AMP.tREQ("tradeWorkup.buySell"), Integer.class);
   public static final AsnConversionAccessor<Double> workupQuantity = acc(AMP.tREQ("tradeWorkup.workUpQuantity"), Double.class);
   public static final AsnConversionAccessor<Double> currentTradePrice = acc(AMP.tREQ("tradeWorkup.currentTradePrice"), Double.class);
}

