package xfe.icap.amp;

import java.util.*;

import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.acc.AmpAccessor;
import xstr.types.*;
import xstr.amp.AMP;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;

public class AmpOrderBookByOrder extends AmpAccessor {
   public static final  AmpQreq req = AMP.qREQ("orderbookByOrderReq");
   public static final  AmpQrep rep = AMP.qREP("orderbookByOrderRep");

   // req
   public static final AsnAccessor reqSecBoardId = acc(AMP.qREQ("orderbookByOrderReq.secBoardId"));
   public static final AsnConversionAccessor<String> reqSecCode = acc(AMP.qREQ("orderbookByOrderReq.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> reqBoardId = acc(AMP.qREQ("orderbookByOrderReq.secBoardId.boardId"), String.class);

   // rep
   public static final AsnConversionAccessor<OrderbookSortKey> sortKey = acc(AMP.qREP("orderbookByOrderRep.sortKey"), OrderbookSortKey.class);
   public static final AsnAccessor orderId = acc(AMP.qREP("orderbookByOrderRep.order.orderId"));
   public static final AsnAccessor managedOrderIdAcc = acc(AMP.qREP("orderbookByOrderRep.order.managedOrderId"));
   public static final AsnConversionAccessor<Long> managedOrderId = acc(AMP.qREP("orderbookByOrderRep.order.managedOrderId"), Long.class);
   public static final AsnConversionAccessor<String> userId = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.details.userId"), String.class);
   public static final AsnConversionAccessor<String> operatorId = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.details.operatorId"), String.class);
   public static final AsnConversionAccessor<String> introBrokerId = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.details.introBrokerId"), String.class);
   public static final AsnConversionAccessor<String> firmId = acc(AMP.qREP("orderbookByOrderRep.order.firmId"), String.class);
   public static final AsnConversionAccessor<String> groupId = acc(AMP.qREP("orderbookByOrderRep.order.groupId"), String.class);
   public static final AsnConversionAccessor<Boolean> shared = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.shared"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> managedOrder = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.managedOrder"), Boolean.class);
   public static final AsnConversionAccessor<Integer> orderTradability = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.orderTradability"), Integer.class);
   public static final AsnConversionAccessor<String> specialOrderType = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.specialOrderType"), String.class);
   public static final AsnConversionAccessor<Double> price = acc(AMP.qREP("orderbookByOrderRep.order.price"), Double.class);
   public static final AsnConversionAccessor<String> priceAsString = acc(AMP.qREP("orderbookByOrderRep.order.price"), String.class);
   public static final AsnConversionAccessor<Double> quantity = acc(AMP.qREP("orderbookByOrderRep.order.quantity"), Double.class);
   public static final AsnConversionAccessor<String> quantityAsString = acc(AMP.qREP("orderbookByOrderRep.order.quantity"), String.class);
   public static final AsnConversionAccessor<Long> orderNo = acc(AMP.qREP("orderbookByOrderRep.order.orderId.orderNo"),Long.class);
   public static final AsnConversionAccessor<Long> orderNoSuffix = acc(AMP.qREP("orderbookByOrderRep.order.orderId.orderNoSuffix"),Long.class);
   public static final AsnConversionAccessor<Date> orderDate = acc(AMP.qREP("orderbookByOrderRep.order.orderId.orderDate"), Date.class);
   public static final AsnConversionAccessor<Integer> buySell = acc(AMP.qREP("orderbookByOrderRep.order.buySell"), Integer.class);
   public static final AsnConversionAccessor<Double> restrictedDepth = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.restrictedDepth"), Double.class);
   public static final AsnConversionAccessor<String> restrictedDepthAsString = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.restrictedDepth"), String.class);
   public static final AsnConversionAccessor<Long> orderBookId = acc(AMP.qREP("orderbookByOrderRep.orderBookId"), Long.class);
   public static final AsnConversionAccessor<Double> minTradeSize = acc(AMP.qREP("orderbookByOrderRep.order.minTradeSize"), Double.class);
   public static final AsnConversionAccessor<Boolean> stale = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.stale"), Boolean.class);
   public static final AsnConversionAccessor<Integer> clearingStatus = acc(AMP.qREP("orderbookByOrderRep.orderSite.icap.clearingStatus"), Integer.class);
   // Need to change accessor type to XtrTime once AMP changes the AmpInteger to AsnTime.
   public static final AsnConversionAccessor<Long> lastLookTime = acc(AMP.qREP("orderbookByOrderRep.order.lastLookTime"), Long.class);
}
