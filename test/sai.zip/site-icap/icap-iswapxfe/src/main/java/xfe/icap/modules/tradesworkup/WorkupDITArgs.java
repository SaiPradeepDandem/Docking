package xfe.icap.modules.tradesworkup;

public class WorkupDITArgs {
   private boolean bidOn;
   private boolean bidOnDIT;
   private boolean offerOn;
   private boolean offerOnDIT;

   public boolean isBidOn() {
      return bidOn;
   }

   public void setBidOn(boolean bidOn) {
      this.bidOn = bidOn;
   }

   public boolean isBidOnDIT() {
      return bidOnDIT;
   }

   public void setBidOnDIT(boolean bidOnDIT) {
      this.bidOnDIT = bidOnDIT;
   }

   public boolean isOfferOn() {
      return offerOn;
   }

   public void setOfferOn(boolean offerOn) {
      this.offerOn = offerOn;
   }

   public boolean isOfferOnDIT() {
      return offerOnDIT;
   }

   public void setOfferOnDIT(boolean offerOnDIT) {
      this.offerOnDIT = offerOnDIT;
   }
}
