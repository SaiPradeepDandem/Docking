package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnConversionAccessor;

public class AmpRfqMarketMaker extends AmpAccessor {
   public static final  AmpQreq req = AMP.qREQ("rfqMarketMakerReq");
   public static final  AmpQrep rep = AMP.qREP("rfqMarketMakerRep");

   public static final AsnConversionAccessor<String>  firmId   = acc(AMP.qREP("rfqMarketMakerRep.mmGroupInstr.groupId" ), String.class);
   public static final AsnConversionAccessor<String>  instrId  = acc(AMP.qREP("rfqMarketMakerRep.mmGroupInstr.instrId"), String.class);
}
