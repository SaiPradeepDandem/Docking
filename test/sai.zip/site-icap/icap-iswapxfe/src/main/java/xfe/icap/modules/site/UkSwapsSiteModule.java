package xfe.icap.modules.site;

import xfe.ui.CssSkin;
import xfe.util.Constants;
import xfe.icap.ISwapLayoutMedium;
import xfe.icap.ISwapMain;
import xfe.module.Module;
import xfe.module.SiteModule;

import java.util.Arrays;
import java.util.List;

public class UkSwapsSiteModule implements SiteModule {

   @Override
   public String getSiteLogoStyle() {
      return ISwapMain.XFE_SITE_SWAPS_UK;
   }

   @Override
   public Class<? extends Module> getSiteDefaultLayout() {
      return ISwapLayoutMedium.class;
   }

   @Override
   public List<CssSkin> getSiteSkins() {
      CssSkin base = new CssSkin("base", "Minimal", "/css/base.css", null);
      return Arrays.asList(
         new CssSkin("iswap_blue", "i-Swap Blue", "/css/iswap_blue.css", base)
      );
   }

   @Override
   public String getHotLine() {
      return Constants.EUR_HOTLINE;
   }

   @Override
   public String getEmailSupport() {
      return Constants.EUR_SUPPORT_EMAIL;
   }

   @Override
   public String getTitle() {
      return "i-Swap";
   }

   @Override
   public String getShortTitle() {
      return "UK Swaps";
   }

   @Override
   public boolean showSpreadPlus() {
      return false;
   }
}
