package xfe.icap.amp;

import java.util.Date;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP.AmpTreq;
import xstr.types.MapWrapper;
import xstr.amp.AMP;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import com.omxgroup.syssrv.Duration;

/**
 * Accessors for AmpOrderAmend_v5
 * @author absw
 *
 */
public class AmpOrderTAcc extends AmpAccessor {
   public static final AmpTreq txn = AMP.tREQ("order");

   public static final AsnAccessor orderId =  acc(AMP.tREQ("orderAmend.orderId"));

   public static final AsnConversionAccessor<String> secCode = acc(AMP.tREQ("order.order.fixed.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.tREQ("order.order.fixed.secBoardId.boardId"), String.class);
   public static final AsnConversionAccessor<Integer> type = acc(AMP.tREQ("order.order.fixed.type"), Integer.class);
   public static final AsnConversionAccessor<Boolean> isPrivate = acc(AMP.tREQ("order.order.fixed.isPrivate"), Boolean.class);
   public static final AsnConversionAccessor<Date> pickOrderDate = acc(AMP.tREQ("order.order.fixed.pickOrderId.orderDate"), Date.class);
   public static final AsnConversionAccessor<Long> pickOrderNo = acc(AMP.tREQ("order.order.fixed.pickOrderId.orderNo"), Long.class);
   public static final AsnConversionAccessor<Long> pickOrderNoSuffix = acc(AMP.tREQ("order.order.fixed.pickOrderId.orderNoSuffix"), Long.class);
   public static final AsnConversionAccessor<Date> crossLinkedOrderDate = acc(AMP.tREQ("order.order.fixed.crossLinkedOrderId.orderDate"), Date.class);
   public static final AsnConversionAccessor<Long> crossLinkedOrderNo = acc(AMP.tREQ("order.order.fixed.crossLinkedOrderId.orderNo"), Long.class);
   public static final AsnConversionAccessor<Long> crossLinkedOrderNoSuffix = acc(AMP.tREQ("order.order.fixed.crossLinkedOrderId.orderNoSuffix"), Long.class);
   public static final AsnConversionAccessor<Boolean> isDoneIfTouched = acc(AMP.tREQ("order.order.fixed.isDoneIfTouched"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> isTopCut = acc(AMP.tREQ("order.order.amendable.isTopcut"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> isPublic = acc(AMP.tREQ("order.order.siteSpecific.icap.isPublic"), Boolean.class);
   public static final AsnConversionAccessor<Double> price = acc(AMP.tREQ("order.order.amendable.price"), Double.class);
   public static final AsnConversionAccessor<Double> quantity = acc(AMP.tREQ("order.order.amendable.quantity"), Double.class);
   public static final AsnConversionAccessor<Duration> durationTime = acc(AMP.tREQ("order.order.amendable.durationTime"), Duration.class);
   public static final AsnConversionAccessor<Integer> durationType = acc(AMP.tREQ("order.order.amendable.duration"), Integer.class);
   public static final AsnConversionAccessor<Double> visibleQuantity = acc(AMP.tREQ("order.order.amendable.visibleQuantity"), Double.class);
   public static final AsnConversionAccessor<Double> minFillQuantity = acc(AMP.tREQ("order.order.amendable.minFillQuantity"), Double.class);
   public static final AsnConversionAccessor<Integer> buySell = acc(AMP.tREQ("order.order.fixed.buySell"), Integer.class);
   public static final AsnConversionAccessor<Boolean> shared = acc(AMP.tREQ("order.order.amendable.shared"), Boolean.class);
   public static final AsnConversionAccessor<Integer> actionOnLogoff = acc(AMP.tREQ("order.order.amendable.actionOnLogoff"), Integer.class);
   public static final AsnConversionAccessor<Boolean> allowMultiMinFill = acc(AMP.tREQ("order.order.amendable.allowMultiMinFill"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> cloneIntoRFS = acc(AMP.tREQ("order.order.amendable.cloneIntoRFS"), Boolean.class);
   public static final AsnConversionAccessor<String> introBrokerId = acc(AMP.tREQ("order.introBrokerId"), String.class);
   public static final AsnConversionAccessor<MapWrapper> extrafields = acc(AMP.tREQ("order.order.amendable.extraFieldsList"), MapWrapper.class);
}
