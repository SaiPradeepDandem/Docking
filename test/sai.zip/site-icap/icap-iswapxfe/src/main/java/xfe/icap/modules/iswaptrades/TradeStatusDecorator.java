package xfe.icap.modules.iswaptrades;

import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.util.Callback;

import xstr.session.QueryReplyRow;
import xstr.amp.AsnConversionAccessor;
import xstr.util.Fx;
import xstr.session.ObservableReplyRow;
import com.omxgroup.xstream.amp.AmpTradeStatus_v2;

public abstract class TradeStatusDecorator {
   static class TradeStatus {
      static final ObservableValue<String> Unknown = Fx.constOf("");
      static final ObservableValue<String> Matched = Fx.constOf("Accepted");
   }

   public static Callback<CellDataFeatures<QueryReplyRow, String>, ObservableValue<String>> orderStatus(AsnConversionAccessor<Integer> acc) {
      return new Callback<CellDataFeatures<QueryReplyRow, String>, ObservableValue<String>>() {
         @Override
         public ObservableValue<String> call(CellDataFeatures<QueryReplyRow, String> cellDataFeatures) {
            QueryReplyRow row = cellDataFeatures.getValue();

            if (row != null) {
               int value = row.getValue(acc);

               switch (value) {
               case AmpTradeStatus_v2.matched:
                  return TradeStatus.Matched;
               default:
                  return Fx.constOf(row.getString(acc));
               }
            }

            return TradeStatus.Unknown;
         }
      };
   }

   public static Callback<ObservableReplyRow, ObservableValue<String>> obsOrderStatus(AsnConversionAccessor<Integer> acc) {
      return new Callback<ObservableReplyRow, ObservableValue<String>>() {
         @Override
         public ObservableValue<String> call(ObservableReplyRow row) {
            if (row != null) {
               ObservableObjectValue<Integer> value = row.getProperty(acc);

               return new ObjectBinding<String>() {
                  {
                     super.bind(value);
                  }

                  @Override
                  protected String computeValue() {
                     switch (value.get()) {
                     case AmpTradeStatus_v2.matched:
                        return "Accepted";
                     default:
                        return (row.getString(acc));
                     }
                  }
               };
            }

            return TradeStatus.Unknown;
         }
      };
   }
}
