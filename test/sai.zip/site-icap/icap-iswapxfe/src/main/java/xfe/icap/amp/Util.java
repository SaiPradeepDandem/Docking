package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;

import static xfe.icap.amp.AmpOrderBookByOrder.reqBoardId;
import static xfe.icap.amp.AmpOrderBookByOrder.reqSecCode;

/**
 * Created by jiadin on 16/08/2016.
 */
public class Util {
   public static String getSecCodeFromObboReplyRow(QueryReplyRow row){
      if(row==null || row.getRequest()==null || row.getRequest().getData()==null){
         return "";
      }
      return reqSecCode.getValueFromBase(row.getRequest().getData());
   }

   public static String getBoardIdFromObboReplyRow(QueryReplyRow row){
      if(row==null || row.getRequest()==null || row.getRequest().getData()==null){
         return "";
      }
      return reqBoardId.getValueFromBase(row.getRequest().getData());
   }

   public static boolean canHandle(AMP.AmpQreq req, ObservableReplyRow row) {
      return req.equals(row.getRequest().getType());
   }
}
