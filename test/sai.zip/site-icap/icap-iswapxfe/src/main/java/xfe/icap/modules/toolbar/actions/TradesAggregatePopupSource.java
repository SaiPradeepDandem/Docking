package xfe.icap.modules.toolbar.actions;

import xfe.modules.actions.TradesAggregateArgs;

import java.util.function.Consumer;

public interface TradesAggregatePopupSource {
   void setTradesAggregatePopupActionConsumer(Consumer<TradesAggregateArgs> tradesAggregatePopupActionConsumer);

   Consumer<TradesAggregateArgs> getTradesAggregatePopupActionConsumer();
}
