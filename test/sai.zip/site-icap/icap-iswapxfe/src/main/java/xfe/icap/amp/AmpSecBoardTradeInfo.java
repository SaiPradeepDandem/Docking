package xfe.icap.amp;

import java.util.Date;

import javafx.beans.value.ObservableValue;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.util.Fun1;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import xfe.ui.table.AsnValueFactory;

public class AmpSecBoardTradeInfo extends AmpAccessor {
   public static final AmpQreq req = AMP.qREQ("secBoardTradeInfoReq");
   public static final AmpQrep rep = AMP.qREP("secBoardTradeInfoRep");

   public static final AsnAccessor secBoardId = acc(AMP.qREP("secBoardTradeInfoRep.secBoardId"));

   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("secBoardTradeInfoRep.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("secBoardTradeInfoRep.secBoardId.boardId"), String.class);
   public static final AsnConversionAccessor<Double> volumeToday = acc(AMP.qREP("secBoardTradeInfoRep.volumeToday"), Double.class);
   public static final AsnConversionAccessor<Double> lastPrice = acc(AMP.qREP("secBoardTradeInfoRep.lastPrice"), Double.class);
   public static final AsnConversionAccessor<Date> lastTime = acc(AMP.qREP("secBoardTradeInfoRep.lastTime"), Date.class);
   public static final AsnConversionAccessor<Double> lastQuantity = acc(AMP.qREP("secBoardTradeInfoRep.lastQuantity"), Double.class);
   public static final AsnConversionAccessor<Double> changeLTP = acc(AMP.qREP("secBoardTradeInfoRep.changeLTP"), Double.class);
   public static final AsnConversionAccessor<Double> highPrice = acc(AMP.qREP("secBoardTradeInfoRep.highPrice"), Double.class);
   public static final AsnConversionAccessor<Double> lowPrice = acc(AMP.qREP("secBoardTradeInfoRep.lowPrice"), Double.class);

   public static final Fun1<ObservableReplyRow, ObservableValue<String>> secCodeGetter = AsnValueFactory.asXfeValue(secCode);
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> boardIdGetter = AsnValueFactory.asXfeValue(boardId);
   public static final Fun1<ObservableReplyRow, ObservableValue<Double>> volumeTodayGetter = AsnValueFactory.asXfeValue(volumeToday);
   public static final Fun1<ObservableReplyRow, ObservableValue<Double>> lastPriceGetter = AsnValueFactory.asXfeValue(lastPrice);
   public static final Fun1<ObservableReplyRow, ObservableValue<Date>> lastTimeGetter = AsnValueFactory.asXfeValue(lastTime);
   public static final Fun1<ObservableReplyRow, ObservableValue<Double>> lastQuantityGetter = AsnValueFactory.asXfeValue(lastQuantity);
   public static final Fun1<ObservableReplyRow, ObservableValue<Double>> changeLTPGetter = AsnValueFactory.asXfeValue(changeLTP);
   public static final Fun1<ObservableReplyRow, ObservableValue<Double>> highPriceGetter = AsnValueFactory.asXfeValue(highPrice);
   public static final Fun1<ObservableReplyRow, ObservableValue<Double>> lowPriceGetter = AsnValueFactory.asXfeValue(lowPrice);
}
