package xfe.icap.modules.instrumentsettingsview;

import com.nomx.instrumentsettings.InstrumentSettingsSpec;
import xfe.types.SecBoard;

import java.util.List;

public class InstrumentSettingsTreeData {
   private String instrumentId;

   private String secCode;

   private List<SecBoard> secBoards;

   private boolean dirty = false;

   public String getDisplayValue() {
      if (instrumentId.equalsIgnoreCase(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID)) {
         return "All";
      } else if (secCode != null) {
         return secCode;
      } else {
         return instrumentId;
      }
   }

   public String getInstrumentId() {
      return instrumentId;
   }

   public void setInstrumentId(String instrumentId) {
      this.instrumentId = instrumentId;
   }

   public String getSecCode() {
      return secCode;
   }

   public void setSecCode(String secCode) {
      this.secCode = secCode;
   }

   public List<SecBoard> getSecBoards() {
      return secBoards;
   }

   public void setSecBoards(List<SecBoard> secBoards) {
      this.secBoards = secBoards;
   }

   public void setDirty(boolean dirty) {
      this.dirty = dirty;
   }

   public boolean isDirty() {
      return dirty;
   }
}
