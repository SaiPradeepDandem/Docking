package xfe.icap.modules.iswaptrades;

import xfe.icap.types.Trade;
import xfe.types.SecBoard;
import xstr.types.TradeSide;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.util.Fx;
import xstr.util.StaticFilter;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.ObservableRowFilter;
import xstr.util.filter.RowFilters;
import xfe.icap.XfeSession;
import xfe.amp.AmpMarketTrade;
import xfe.icap.amp.AmpTrade;
import xstr.session.ObservableReplyRow;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableStringValue;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Comparator;
import java.util.Objects;
import java.util.function.Predicate;

public class TradesFilters {
   private static final Logger logger = LoggerFactory.getLogger(TradesFilters.class);

   private Callback<QueryReplyRow, ObservableObjectValue<TradeSide>> tradeSideValueFactory;
   private Callback<QueryReplyRow, ObservableStringValue> statusFactory;
   private Callback<QueryReplyRow, ObservableStringValue> firmValueFactory;

   private static String loggedOnUserId;
   private static StringProperty loggedOnFirmId;  //following three variable should not be static.  However too many code involved.
   private static XfeSession xfeSession;
   private static ServerSession session;
   private static TradesModule tradesModule;
   final ObservableRowFilter isLegForBroker;

   public TradesFilters(XfeSession session, TradesModule tradesModule) {
      loggedOnUserId = session.getUnderlyingSession().getLoggedOnUserId();
      loggedOnFirmId = new SimpleStringProperty(session.getUnderlyingSession().getStats().getFirmId());
      xfeSession = session;
      TradesFilters.session = xfeSession.getUnderlyingSession();
      TradesFilters.tradesModule = tradesModule;
      isLegForBroker = createFilter(tradesModule);
   }

   private ObservableRowFilter createFilter(TradesModule tradesModule) {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               {
                  if(tradesModule!=null) {
                     bind(tradesModule.selectedTab,session.onBehalfTraderId);
                  }
               }
               @Override
               protected boolean computeValue() {
                  if(SelectedTab.TRADER.equals(tradesModule.selectedTab.get())) {
                     return isLegToTrader(row);
                  }else if(SelectedTab.BROKER.equals(tradesModule.selectedTab.get())){
                     return isLegToBroker(row);
                  }
                  return false;
               }
            };
         }
      };

   }

   private boolean isLegToTrader(ObservableReplyRow row) {
      Trade currTrade = new Trade(row);
      String onBehalfTradeId = session.onBehalfTraderId.get();
      if (Objects.equals(onBehalfTradeId, row.getString(AmpTrade.buyTraderId))) {
         return currTrade.isBuyLegType();
      } else if (Objects.equals(onBehalfTradeId, row.getString(AmpTrade.sellTraderId))) {
         return currTrade.isSellLegType();
      }
      return false;
   }

   public TradesFilters(XfeSession session) {
      this(session,null);
   }


   final Callback<ObservableReplyRow, String> accessTradeNumber = row -> row.getValue(AmpTrade.tradeNo);

   final Comparator<String> stringComparator = (value1, value2) -> {
      if (value1 == null) {
         return -1;
      }

      if (value2 == null) {
         return 1;
      }

      return value1.compareTo(value2);
   };

   public static TradeSide getTradeSide(QueryReplyRow row) {
      if (session == null) return null;
      if (session.isLoggedOnTrader()) {
         String ownFirmId = loggedOnFirmId.get();
         Trade trade = new Trade(row);
         if (trade.isCross())
            return TradeSide.CROSS;
         else if (ownFirmId.equals(trade.getSellFirmId()))
            return TradeSide.SELL;
         else
            return TradeSide.BUY;
      } else if (session.isLoggedOnUserIB()) {
         boolean isBuy = Objects.equals(loggedOnUserId,row.getString(AmpTrade.buyIntroBrokerId));
         boolean isSell = Objects.equals(loggedOnUserId,row.getString(AmpTrade.sellIntroBrokerId));
         if (isBuy && isSell) {
            return TradeSide.CROSS;
         } else if (isBuy) {
            return TradeSide.BUY;
         } else if(isSell) {
            return TradeSide.SELL;
         } else {
            String ownFirmId = loggedOnFirmId.get();
            isBuy = Objects.equals(ownFirmId,row.getString(AmpTrade.buyIntroBrokerFirmId));
            isSell = Objects.equals(loggedOnUserId,row.getString(AmpTrade.sellIntroBrokerFirmId));
            if (isBuy && isSell) {
               return TradeSide.CROSS;
            } else if (isBuy) {
               return TradeSide.BUY;
            } else if (isSell) {
               return TradeSide.SELL;
            } else {
               String aggressiveSide = AmpTrade.getAggressiveSide(row);
               return TradeSide.of(aggressiveSide);
            }
         }
      } else if (session.isLoggedOnUserBroker()) {
         boolean isBuy = Objects.equals(loggedOnUserId,row.getString(AmpTrade.buyOperatorId));
         boolean isSell = Objects.equals(loggedOnUserId,row.getString(AmpTrade.sellOperatorId));
         if (isBuy && isSell) {
            return TradeSide.CROSS;
         } else if (isBuy) {
            return TradeSide.BUY;
         } else if (isSell){
            return TradeSide.SELL;
         } else {
            String aggressiveSide = AmpTrade.getAggressiveSide(row);
            return TradeSide.of(aggressiveSide);
         }
      }
      return TradeSide.CROSS;
   }

   static String getStatus(QueryReplyRow row) {
      Trade trade = new Trade(row);
      return TradesColumns.tradeStatusConverter.toString(trade.getStatus());
   }

   final Callback<QueryReplyRow, ObservableObjectValue<TradeSide>> tradeSideValueFactory() {
      if (tradeSideValueFactory == null) {
         tradeSideValueFactory = row -> Fx.constOf(getTradeSide(row));
      }
      return tradeSideValueFactory;
   }

   final Callback<QueryReplyRow, ObservableStringValue> statusFactory() {
      if (statusFactory == null) {
         statusFactory = row -> Fx.constOf(getStatus(row));
      }
      return statusFactory;
   }

   public final Callback<QueryReplyRow, ObservableStringValue> firmValueFactory() {
      if (firmValueFactory == null) {
         firmValueFactory = row -> {
            if (row == null) {
               return Fx.constOf("");
            }
            String buyFirmId = row.getValue(AmpTrade.buyFirmId);
            String sellFirmId = row.getValue(AmpTrade.sellFirmId);
            return Bindings.when(Bindings.equal(loggedOnFirmId, sellFirmId)).then(buyFirmId).otherwise(
               Bindings.when(Bindings.equal(loggedOnFirmId, buyFirmId)).then(sellFirmId).otherwise(String.format("%s/%s", buyFirmId, sellFirmId)));
         };
      }

      return firmValueFactory;
   }

   final ObservableRowFilter isTraderTrade = new ObservableRowFilter() {
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         String buyTraderId = row.getValue(AmpTrade.buyTraderId);
         String sellTraderId = row.getValue(AmpTrade.sellTraderId);
         return Fx.valueOf( loggedOnUserId.equals(buyTraderId) || loggedOnUserId.equals(sellTraderId));
      }

      @Override
      public String toString() { return "istrader"; }
   };

   final ObservableRowFilter isBrokerTrade = new ObservableRowFilter() { //Containing all trades involving orders entered by the logged-in broker
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         return new fxext.BooleanBinding(){
            @Override
            protected boolean computeValue() {
               String buyOpId = row.getValue(AmpTrade.buyOperatorId);
               String sellOpId = row.getValue(AmpTrade.sellOperatorId);
               return loggedOnUserId.equals(buyOpId) || loggedOnUserId.equals(sellOpId);
            }
         };
      }

      @Override
      public String toString() { return "is Introbroker"; }
   };

   final ObservableRowFilter isIBTrades = new ObservableRowFilter() { //Containing all trades involving orders entered by (or on-behalf-of) the logged-in Introducing broker
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         return new fxext.BooleanBinding(){
            @Override
            protected boolean computeValue() {
               String buyIbId = row.getValue(AmpTrade.buyIntroBrokerId);
               String sellIbId = row.getValue(AmpTrade.sellIntroBrokerId);
               return (loggedOnUserId.equals(buyIbId) || loggedOnUserId.equals(sellIbId)) ;
            }
         };
      }

      @Override
      public String toString() { return "is trader involves IB"; }
   };

   /*
    *  Containing all trades involving orders (broker & trader entered) entered by the selected trader or on his behalf
    */
   final ObservableRowFilter isOnbehalftraderUnderBroker = new ObservableRowFilter() {
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         return new fxext.BooleanBinding(){
            {
               bind(xfeSession.getUnderlyingSession().onBehalfTraderId);
            }
            @Override
            protected boolean computeValue() {
               String buyTraderId = row.getValue(AmpTrade.buyTraderId);
               String sellTraderId = row.getValue(AmpTrade.sellTraderId);
               String onbehalfTraderId = xfeSession.getUnderlyingSession().onBehalfTraderId.get();
               return Objects.equals(onbehalfTraderId, buyTraderId) || Objects.equals(onbehalfTraderId, sellTraderId);
            }
         };
      }

      @Override
      public String toString() { return "is onbehalf trader under IB"; }
   };

   final ObservableRowFilter isIBFirmTrade = new ObservableRowFilter() {
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         return new fxext.BooleanBinding(){
            @Override
            protected boolean computeValue() {
               String buyIBFirmId = row.getString(AmpTrade.buyIntroBrokerFirmId);
               String sellIBFirmId = row.getString(AmpTrade.sellIntroBrokerFirmId);
               String targetFirm = loggedOnFirmId.get();
               return targetFirm.equals(buyIBFirmId) || targetFirm.equals(sellIBFirmId);
            }

         };
      }

      @Override
      public String toString() { return "is IBFirm"; }
   };

   final ObservableRowFilter isOpertator(BooleanProperty showLeg) {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            String buyOperatorId = row.getValue(AmpTrade.buyOperatorId);
            String sellOperatorId = row.getValue(AmpTrade.sellOperatorId);

            return new fxext.BooleanBinding(){
               {
                  bind(showLeg);
               }
               @Override
               protected boolean computeValue() {
                  boolean isOwn =  loggedOnUserId.equals(buyOperatorId) || loggedOnUserId.equals(sellOperatorId);
                  if (showLeg.get() ) {
                     return isOwn;
                  }else{
                     return isOwn && !isLegToBroker(row);
                  }
               }

            };

         }

         @Override
         public String toString() { return "isOpertator"; }
      };
   }

   private boolean isLegToBroker(ObservableReplyRow row) {
      Trade currTrade = new Trade(row);
      boolean isSellerOp = loggedOnUserId.equals(row.getString(AmpTrade.sellOperatorId));
      boolean isBuyerOp = loggedOnUserId.equals(row.getString(AmpTrade.buyOperatorId));
      boolean isBuyLeg = currTrade.isBuyLegType();
      boolean isSellLeg = currTrade.isSellLegType();
      return (isSellerOp && isSellLeg) || (isBuyerOp && isBuyLeg);
   }

   final ObservableRowFilter isOpertatorOnlyLeg() {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            String buyOperatorId = row.getValue(AmpTrade.buyOperatorId);
            String sellOperatorId = row.getValue(AmpTrade.sellOperatorId);

            return new fxext.BooleanBinding(){
               @Override
               protected boolean computeValue() {
                  return isLeg.accept(row) &&
                     (loggedOnUserId.equals(buyOperatorId) ||
                        loggedOnUserId.equals(sellOperatorId));
               }
            };
         }

         @Override
         public String toString() { return "isOpertator"; }
      };
   }

   final ObservableRowFilter isIntroBroker(BooleanProperty showLeg, BooleanProperty traderSelected) {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            String buyIntroBrokerId = row.getValue(AmpTrade.buyIntroBrokerId);
            String sellIntroBrokerId = row.getValue(AmpTrade.sellIntroBrokerId);

            return new fxext.BooleanBinding(){
               {
                  bind(showLeg, session.onBehalfTraderId,traderSelected);
               }
               @Override
               protected boolean computeValue() {
                  if( !showLeg.get() && isLeg.accept(row)){
                     return false;
                  }
                  if(traderSelected!=null && traderSelected.get()){
                     String buyTraderId = row.getString(AmpTrade.buyTraderId);
                     String sellTraderId = row.getString(AmpTrade.sellTraderId);
                     String onBehalfOftraderId = session.onBehalfTraderId.get();
                     boolean isOnhalfOntraders = onBehalfOftraderId.equals(buyTraderId) || onBehalfOftraderId.equals(sellTraderId);
                     if(!isOnhalfOntraders) {
                        return false;
                     }
                  }
                  return loggedOnUserId.equals(buyIntroBrokerId) || loggedOnUserId.equals(sellIntroBrokerId);
               }

            };

         }

         @Override
         public String toString() { return "isIntroBrokerId"; }
      };
   }

   DynamicFilter<ObservableReplyRow> isOnbehalfTrade4IB(BooleanProperty showLeg) {
      return new DynamicFilter<ObservableReplyRow>() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            String buyTraderId = row.getString(AmpTrade.buyTraderId);
            String sellTraderId = row.getString(AmpTrade.sellTraderId);
            String buyIBId = row.getString(AmpTrade.buyIntroBrokerId);
            String sellIBId = row.getString(AmpTrade.sellIntroBrokerId);
            return new fxext.BooleanBinding() {
               {
                  bind(session.onBehalfTraderId,showLeg);
               }
               @Override
               protected boolean computeValue() {
                  if (!showLeg.get() && isLeg.accept(row)) return false;
                  String traderId = session.onBehalfTraderId.get();
                  boolean rtn = (Objects.equals(buyTraderId, traderId) ||
                     Objects.equals(sellTraderId, traderId)) &&
                     (Objects.equals(buyIBId, session.getLoggedOnUserId()) ||
                        Objects.equals(sellIBId, session.getLoggedOnUserId()));
                  return rtn;
               }
            };
         }
      };
   }

   DynamicFilter<ObservableReplyRow> isOnbehalfTrade4Broker(BooleanProperty showLeg) {
      return new DynamicFilter<ObservableReplyRow>() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            String buyTraderId = row.getString(AmpTrade.buyTraderId);
            String sellTraderId = row.getString(AmpTrade.sellTraderId);
            return new fxext.BooleanBinding() {
               {
                  bind(session.onBehalfTraderId,showLeg);
               }
               @Override
               protected boolean computeValue() {
                  String traderId = session.onBehalfTraderId.get();
                  boolean rtn = (Objects.equals(buyTraderId, traderId) || Objects.equals(sellTraderId, traderId));
                  if (showLeg.get()) {
                     return rtn;
                  } else{
                     return rtn && !isLegToTrader(row);
                  }
               }
            };
         }
      };
   }

   DynamicFilter<ObservableReplyRow> isOnbehalfTrade4BrokerOnlyLeg() {
      return new DynamicFilter<ObservableReplyRow>() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               {
                  bind(session.onBehalfTraderId);
               }
               @Override
               protected boolean computeValue() {
                  return isLegToTrader(row);
               }
            };
         }
      };
   }

   DynamicFilter<ObservableReplyRow> brokerDesk(BooleanProperty isMyTraders, BooleanProperty showLeg) {
      if (xfeSession.traderFirmMap == null) {
         return new DynamicFilter<ObservableReplyRow>() {
            @Override
            public ObservableBooleanValue accept(ObservableReplyRow row) {
               return new fxext.BooleanBinding() {
                  {
                     bind(isMyTraders, showLeg);
                  }

                  @Override
                  protected boolean computeValue() {
                     return !isLeg.accept(row) && !isMyTraders.get();
                  }
               };
            }
         };
      } else {
         return new DynamicFilter<ObservableReplyRow>() {
            @Override
            public ObservableBooleanValue accept(ObservableReplyRow row) {
               String buyTraderId = row.getString(AmpTrade.buyTraderId);
               String sellTraderId = row.getString(AmpTrade.sellTraderId);

               return new fxext.BooleanBinding() {
                  {
                     bind(isMyTraders, showLeg, xfeSession.traderFirmMap.readyPropertyRO);
                  }

                  @Override
                  protected boolean computeValue() {
                     if (isLeg.accept(row)) {
                        return false;
                     }
                     boolean isTraderCanOnBehalfof = xfeSession.traderFirmMap.isTraderCanOnBehalfof(buyTraderId) ||
                        xfeSession.traderFirmMap.isTraderCanOnBehalfof(sellTraderId);
                     return !isMyTraders.get() || isTraderCanOnBehalfof;
                  }
               };
            }
         };
      }
   }

   static final DynamicFilter<ObservableReplyRow> isStrategy = DynamicFilter.of(Filters.and(RowFilters.notNull(AmpTrade.numLegTrades), RowFilters.greaterThan(AmpTrade.numLegTrades, 0)));

   static StaticFilter<QueryReplyRow> isBuyerOrSeller() {
      return new StaticFilter<QueryReplyRow>() {
         @Override
         public boolean accept(QueryReplyRow row) {
            Trade currTrade = new Trade(row);
            return loggedOnUserId!=null && (loggedOnUserId.equals(currTrade.getBuyTraderId()) || loggedOnUserId.equals(currTrade.getSellTraderId()) );
         }
      };

   }

   public static final StaticFilter<QueryReplyRow> isLeg = new StaticFilter<QueryReplyRow>() {

      @Override
      public boolean accept(QueryReplyRow row) {
         TradeSide side = getTradeSide(row);
         Trade currTrade = new Trade(row);
         //System.out.println(String.format("User: %s; Side: %s; isBuyLeg: %s; isSellLeg: %s", loggedOnUserId, side, currTrade.isBuyLegType(), currTrade.isSellLegType()));
         if (side == TradeSide.BUY)
            return currTrade.isBuyLegType();
         else if (side == TradeSide.SELL)
            return currTrade.isSellLegType();
         else
            return side == TradeSide.CROSS &&
               (currTrade.isBuyLegType() || currTrade.isSellLegType());
      }
   };

   public static final StaticFilter<QueryReplyRow> isAuto = RowFilters.valueOfStatic(AmpTrade.isAutoTrade);

   DynamicFilter<ObservableReplyRow> legFilter4Broker(DynamicFilter<ObservableReplyRow> brokerFilter, DynamicFilter<ObservableReplyRow> onBehalfTraderFilter, BooleanProperty traderButtonSelectedProp, BooleanProperty brokerButtonSelectedProp) {
      return new DynamicFilter<ObservableReplyRow>() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               {
                  bind(traderButtonSelectedProp,brokerButtonSelectedProp,session.onBehalfTraderId);
               }
               @Override
               protected boolean computeValue() {
                  boolean isleg = isLeg.accept(row);
                  if(!isleg) return false;
                  boolean rtn  = false;
                  if(traderButtonSelectedProp.get()){
                     rtn =  onBehalfTraderFilter.accept(row).get();
                  }else if(brokerButtonSelectedProp.get()){
                     rtn =  brokerFilter.accept(row).get();
                  }
                  return rtn;
               }

            };
         }
      };
   }


   DynamicFilter<ObservableReplyRow> legFilter4IB(DynamicFilter<ObservableReplyRow> ibFilterHasLeg, DynamicFilter<ObservableReplyRow> onBehalfTraderFilterHasLeg, BooleanProperty isTraderSelected) {
      return new DynamicFilter<ObservableReplyRow>() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               {
                  bind(isTraderSelected,session.onBehalfTraderId);
               }

               @Override
               protected boolean computeValue() {
                  boolean isleg = isLeg.accept(row);
                  if(!isleg) {
                     return false;
                  }
                  boolean isIbAccepted = ibFilterHasLeg.accept(row).get();
                  boolean isTrader = isTraderSelected.get();
                  boolean isTraderAccepted = onBehalfTraderFilterHasLeg.accept(row).get();
                  return isTrader ? isTraderAccepted : isIbAccepted;
               }

            };
         }
      };
   }

   public static void dispose(){
      session = null;
      xfeSession = null;
      loggedOnFirmId = null;
   }

   public static boolean isMyTrade(String userId, QueryReplyRow r) {
      if (session.isLoggedOnTrader())
         return userId.equals(r.getValue(AmpTrade.buyTraderId)) || userId.equals(r.getValue(AmpTrade.sellTraderId));
      else if (session.isLoggedOnUserIB()){
         return userId.equals(r.getValue(AmpTrade.buyIntroBrokerId)) || userId.equals(r.getValue(AmpTrade.sellIntroBrokerId));
      }
      else if (session.isLoggedOnUserBroker()){
         return userId.equals(r.getValue(AmpTrade.buyOperatorId)) || userId.equals(r.getValue(AmpTrade.sellOperatorId));
      }
      return false;
   }

   static boolean isMyFirmTrade(String firmId, QueryReplyRow r) {
      if (session.isLoggedOnTrader()) {
         return firmId.equals(r.getValue(AmpTrade.buyFirmId)) || firmId.equals(r.getValue(AmpTrade.sellFirmId));
      }

      return false;
   }

   // This is not a proper implementation since for broker's market trades we cannot rely on firmId to give us
   // desk information
   public static boolean isMyFirmMarketTrade(String firmId, QueryReplyRow r) {
      if (session.isLoggedOnTrader()) {
         return firmId.equals(r.getValue(AmpMarketTrade.buyFirmId)) || firmId.equals(r.getValue(AmpMarketTrade.sellFirmId));
      }

      return false;
   }

   public static Predicate<ObservableReplyRow> isGiltsTrade(){
      return (row) -> SecBoard.isGilt(row.getValue(AmpTrade.boardId));
   }
}
