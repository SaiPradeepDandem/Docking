package xfe.icap.client;

import io.netty.channel.*;
import io.netty.channel.ChannelHandler.Sharable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xmp.message.XMP.XmpLogoffReply;
import xmp.message.XMP.XmpLogoffRequest;
import xstr.util.concurrent.DisposedException;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;
import xstr.util.exception.XtrSessionException;

@Sharable
public class LogoffHandler extends SimpleChannelInboundHandler<XmpLogoffReply> {
   private static final Logger logger = LoggerFactory.getLogger(LogoffHandler.class);

   private final Promise<XmpLogoffReply> logoffReply = Futures.newPromise("logoff-reply");

   private final XstrWebConnection connetcion;

   public LogoffHandler(XstrWebConnection connetcion) {
      this.connetcion = connetcion;
   }

   @Override
   public void channelRead0(ChannelHandlerContext ctx, XmpLogoffReply msg) {
      logger.debug("Logoff reply received");
      logoffReply.trySetSuccess(msg);
      ctx.close();
   }

   public Future<XmpLogoffReply> logoff() {
      return connetcion.channel().flatMap(channel -> {
         channel.closeFuture().addListener( future ->
            logoffReply.trySetFailure(new XtrSessionException("Connection closed before logoff reply was received."))
         );
         try {
            XmpLogoffRequest reqMsg = XmpLogoffRequest.newBuilder().build();
            channel.writeAndFlush(reqMsg);
            logger.info("Logoff requested {}");
         } catch (DisposedException e) {
            logger.error("Disposed exception in transaction:", e);
            logoffReply.setFailure(e);
         } catch (Exception e) {
            logger.error("Error in transaction:", e);
            logoffReply.setFailure(e);
         }
         return logoffReply;
      });

   }

}
