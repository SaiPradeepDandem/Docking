package xfe.icap.modules.iswaptrades;

import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;

import javafx.beans.*;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import org.slf4j.*;

import xfe.util.Constants;
import xfe.util.CountDownTask;
import xfe.util.scene.control.DoubleTextField;
import xfe.util.scene.control.SpinBox;
import xfe.util.scene.control.SpinEvent;
import xstr.util.concurrent.*;

import xfe.types.StepArray;
import xstr.types.TradeSide;
import xstr.session.XtrTransRequestBuilder;
import xstr.util.*;
import xfe.icap.amp.AmpTradeWorkup;
import com.omxgroup.xstream.amp.AmpOrderVerb;

public class TradeWorkupPane extends DisposableBase{

   public static final double PREFWIDTH = 400;
   public static final double PREFHEIGHT = 230;
   private static final Object SPIN_CHANGE = new Object();
   private static final Logger logger = LoggerFactory.getLogger(TradeWorkupPane.class);

   @FXML GridPane rootNode;
   @FXML Label status_label;
   @FXML Label workup_side_value;
   @FXML Label code_value;
   @FXML Label tradesize_my_value;
   @FXML Label counterparty_value;
   @FXML Label tradesize_counterparty_value;
   @FXML Label rate_value;
   @FXML Label exprirytime_value;

   @FXML HBox hbox_size;
   @FXML
   SpinBox spin_size ;

   @FXML Button button_send;
   @FXML Button button_end;

   final LongProperty timerProp = new SimpleLongProperty(){{
     this.addListener(new InvalidationListener(){

      @Override
      public void invalidated(Observable observable) {
         exprirytime_value.setText(String.valueOf(timerProp.getValue()));
      }
     });
   }};

   private final DoubleTextField sizeEdit = new DoubleTextField(){
      {
         this.textProperty().addListener(new InvalidationListener() {

            @Override
            public void invalidated(Observable arg0) {
               try {
                  String newValue = sizeEdit.textProperty().get();
                  if (newValue != null && newValue.length() > 0)
                     checkMin(Double.parseDouble(newValue));
               } catch (NumberFormatException e) {
                  e.printStackTrace();
               }
            }
         });
      }



      @Override
      public void step(int steps) {
         StepArray quantityStepArray = TradeWorkupStageFactory.spinQtySteps.get();

         if (quantityStepArray != null) {
            changeTrail.run(SPIN_CHANGE, new Runnable() {
               @Override
               public void run() {
                  double newValue = quantityStepArray.notch(getValue(), steps);
                  checkMin(newValue);
                  selectAll();
                  requestFocus();
               }
            });
         }
      }

      private void checkMin(double newValue) {
         try {
            if (tradesize_my_value.getText() == null || tradesize_my_value.getText().length() == 0)
               return;
            if (newValue >= NumberFormat.getInstance().parse(tradesize_my_value.getText()).doubleValue()) {
               setValue(newValue);
               status_label.setText("");
               button_send.setDisable(false);
            } else {
               status_label.setText("The volume can't be less than original volume: " + tradesize_my_value.getText());
               button_send.setDisable(true);
            }
         } catch (ParseException e) {
            return;
         }
      }

   };


   private final TradeAlert trade;
   private final ListenerTracker track;
   private final SimpleBooleanProperty endProperty = new SimpleBooleanProperty(false) {
      {
         this.addListener(new InvalidationListener() {

            @Override
            public void invalidated(Observable paramObservable) {
               if (endProperty.get()) { // to end the process of workup
                  endWorkup();
               }
            }
         });
      }
   };

   static TradeWorkupPane load(ListenerTracker tracker, TradeAlert tradeAlert){
      FXMLLoader ldr = new FXMLLoader(TradeWorkupPane.class.getResource("TradeWorkup.fxml"));

      Disposer disposer = new Disposer();

      try {
         TradeWorkupPane pane = disposer.disposes(new TradeWorkupPane(tracker, tradeAlert));
         ldr.setController(pane);

         try {
            ldr.load();
            return disposer.cancelThenYield(pane);
         } catch (IOException e) {
            return null;
         }
      } finally {
         disposer.dispose();
      }
   }


   @FXML
   private void initialize() {
      HBox.setHgrow(sizeEdit, Priority.ALWAYS);
      hbox_size.getChildren().add(0,sizeEdit);
      spin_size.setOnSpin(new EventHandler<SpinEvent>() {
         @Override
         public void handle(SpinEvent event) {
            sizeEdit.step(event.amount);
         }
      });

      sizeEdit.getStyleClass().add("xfe-orderentry-rateedit");
      sizeEdit.decimalsProperty().set(2);   }

   private TradeWorkupPane(ListenerTracker tracker, TradeAlert tradeAlert) {
      this.trade = tradeAlert;
      this.track = tracker;
   }

   public Node getRootNode() {
      return rootNode;
   }

   boolean isInterruptOnPurpose;
   private CountDownTask counterDownTask;

   void displayTrade(Date engineTime) {
      if (trade != null) {
         String sideStyle = trade.side == TradeSide.BUY ? TradeWorkupStage.BID_CONTENT_STYLE : TradeWorkupStage.ASK_CONTENT_STYLE;
         double origSizeValue = trade.amount.get();
//         sizeEdit.getStyleClass().add(sideStyle);
//         spin_size.getStyleClass().add(sideStyle);
         sizeEdit.setValue(origSizeValue);
         sizeEdit.setMinimumValue(origSizeValue);

         int duration = (int) (trade.workupExpTime.getTime() - engineTime.getTime()) / 1000;

         counterDownTask = new CountDownTask("Workup_timer_" + trade.secCode + "_" + trade.key, duration, endProperty,
               timerProp);
         counterDownTask.start();
         boolean isBuy = trade.side == TradeSide.BUY;
         workup_side_value.setText(isBuy ? Constants.LABEL_PAY : Constants.LABEL_REC);
         code_value.setText(trade.secCode);
         tradesize_my_value.textProperty().bind(Fx.asDecimalString(trade.amount,2));
         // broker_value.setText(isBuy ? trade.buyBrokerId : trade.sellBrokerId);
         // trader_value.setText(isBuy ? trade.buyTraderId : trade.sellTraderId);
         // firm_value.setText(isBuy ? trade.buyFirmId : trade.sellFirmId);

         String counterPartyStr = isBuy ? trade.sellAccount : trade.buyAccount;
         // final Font originalFont = counterparty_value.getFont();
         // double fontSize = FontUtil.calculateFontSize(counterPartyStr, originalFont, counterparty_value.getWidth());
         // if (fontSize != originalFont.getSize()) {
         // counterparty_value.setStyle("-fx-font-size:"+fontSize+";");
         // }
         counterparty_value.setText(counterPartyStr);
         // counterparty_value.gets

         rate_value.setText(trade.rate);
         tradesize_counterparty_value.textProperty().bind(isBuy ? Fx.asDecimalString(trade.sellWorkupAmountProperty,2) : Fx.asDecimalString(trade.buyWorkupAmountProperty,2));
//         button_end.getStyleClass().add(sideStyle);
         button_end.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent paramT) {
               sendWorkupTrade(trade.amount.get());
               endProperty.setValue(true);
            }
         });
//         button_send.getStyleClass().add(sideStyle);
         button_send.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
               sendWorkupTrade(sizeEdit.getValue());
            }
         });
      }
   }

   /*
    * send quantity request or end the work up process if quantity is 0;
    */
   private void sendWorkupTrade(double quantity) {
      try {
         XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(AmpTradeWorkup.txn, TradeWorkupStageFactory.xfeSession.getUnderlyingSession())
               .setAsn(AmpTradeWorkup.tradeId, trade.tradeId).set(AmpTradeWorkup.buySell, trade.side == TradeSide.BUY ? AmpOrderVerb.buy : AmpOrderVerb.sell)
               .set(AmpTradeWorkup.workupQuantity, quantity);
         if (quantity != 0)
            reqBuilder = reqBuilder.set(AmpTradeWorkup.currentTradePrice, NumberFormat.getInstance().parse(trade.rate).doubleValue());
         TradeWorkupStageFactory.xfeSession.getUnderlyingSession().execute(reqBuilder.build());
      } catch (Exception e) {
         if (TradeWorkupStageFactory.notifier != null)
            TradeWorkupStageFactory.notifier.showError("Sending trades to TE failed due to exception " + e);
         logger.error("Sending trades to TE failed due to exception ", e);
      }

   }

   protected void endWorkup() {
      isInterruptOnPurpose = true;
      counterDownTask.cancel();
      TradeWorkupStageFactory.workupStageClosed(trade);
   }

   public void disableInputAndShowFinalSize() {

      status_label.textProperty().bind(Bindings.format("Workup Complete!. The final size is %s", trade.amount));
      button_end.setDisable(true);
      button_send.setDisable(true);
      sizeEdit.setDisable(true);
      spin_size.setDisable(true);
      Fx.runLater(new Runnable() {

         @Override
         public void run() {
            if (counterDownTask != null)
               counterDownTask.cancel();
         }
      });
   }

}
