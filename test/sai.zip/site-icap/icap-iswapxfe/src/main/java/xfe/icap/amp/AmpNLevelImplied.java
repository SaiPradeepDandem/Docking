package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;

public class AmpNLevelImplied extends AmpAccessor {
	public static final  AmpQreq req = AMP.qREQ("nLevelImpliedReq");
	public static final  AmpQrep rep = AMP.qREP("nLevelImpliedRep");

	// req
	public static final AsnAccessor secBoardId = acc(AMP.qREQ("nLevelImpliedReq.secBoardId"));
	public static final AsnConversionAccessor<Integer> buySell = acc(AMP.qREQ("nLevelImpliedReq.buySell"), Integer.class);
	public static final AsnConversionAccessor<Integer> orderImpliedType = acc(AMP.qREQ("nLevelImpliedReq.orderImpliedType"), Integer.class);
	public static final AsnConversionAccessor<String> reqSecCode = acc(AMP.qREQ("nLevelImpliedReq.secBoardId.secCode"), String.class);
	public static final AsnConversionAccessor<String> reqBoardId = acc(AMP.qREQ("nLevelImpliedReq.secBoardId.boardId"), String.class);

	//rep
	public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("nLevelImpliedRep.secBoardId.secCode"), String.class);
	public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("nLevelImpliedRep.secBoardId.boardId"), String.class);
	public static final AsnConversionAccessor<Integer> impliedBuySell = AmpAccessor.acc(AMP.qREP("nLevelImpliedRep.buySell"), Integer.class);
	public static final AsnConversionAccessor<Double> price = AmpAccessor.acc(AMP.qREP("nLevelImpliedRep.price"), Double.class);
	public static final AsnConversionAccessor<Double> orderQty = AmpAccessor.acc(AMP.qREP("nLevelImpliedRep.orderQty"), Double.class);
	public static final AsnConversionAccessor<Double> implyQty = AmpAccessor.acc(AMP.qREP("nLevelImpliedRep.implyQty"), Double.class);

}
