package xfe.icap.modules.rfq;

import java.util.*;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import org.slf4j.*;

import javafx.beans.property.*;
import javafx.collections.ListChangeListener;
import javafx.scene.control.*;

import com.nomx.domain.types.InstrumentKey;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import xfe.icap.amp.AmpRfq;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.watchlist.InstrumentsColumns;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xstr.session.ObservableReplyRow;
import xfe.ui.TriStateButton;
import xfe.ui.TriStateButton.State;
import xstr.util.Functions;

public class RfqTableView extends TableViewHeaderUnmovable<ObservableReplyRow>{
   private static final Logger logger = LoggerFactory.getLogger(RfqTableView.class);

   @SuppressWarnings("rawtypes")
   public RfqTableView(InstrumentsColumns columns,
                       ReadOnlyObjectProperty<WatchlistSpec_v2> activeSpec,
                       TriStateButton buttonWatchHighlight,
                       ObjectProperty<SelectionContext> gridContext) {
      Property<Runnable> interrogationActionProperty = new SimpleObjectProperty<>(Functions.NOOP_RUNNABLE);
      TableColumn<ObservableReplyRow, String> instrumentCol = columns.createRfqInstrumentColumn();
      TableColumn<ObservableReplyRow, String> intiatorCol = columns.createRfqInitiatorCol();
      TableColumn<ObservableReplyRow, String> intiatorFirm = columns.createRfqInitiatorFirmCol();
      TableColumn<ObservableReplyRow, Integer> requestCol = columns.createRfqRequestCol();
      TableColumn<ObservableReplyRow, String> fullCol = columns.createColumn(AmpRfq.fullAmount, "Full", "boolean");
      TableColumn<ObservableReplyRow, String> sizeCol = columns.createColumn(AmpRfq.maxQuantity, "Size", "number");
      TableColumn<ObservableReplyRow, Date> startBespokedCol = columns.createRfqStartBespokedCol();
      TableColumn<ObservableReplyRow, Date> matBespokedCol = columns.createRfqMatBespokedCol();
      TableColumn<ObservableReplyRow, Date> startCol = columns.createRfqStartTimeCol();
      TableColumn<ObservableReplyRow, String> remainingCol = columns.createRfqRemainingtimeCol();
      fullCol.setPrefWidth(35);
      sizeCol.setPrefWidth(50);
      List<TableColumn<ObservableReplyRow,?>> columnList = getColumns();
      columnList.add(instrumentCol);
      columnList.add(intiatorCol);
      columnList.add(intiatorFirm);
      columnList.add(requestCol);
      columnList.add(sizeCol);
      columnList.add(fullCol);
      columnList.add(startBespokedCol);
      columnList.add(matBespokedCol);
      columnList.add(startCol);
      columnList.add(remainingCol);

      getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
      ListChangeListener<TablePosition> selectedCellListener = new ListChangeListener<TablePosition>() {
         @Override
         public void onChanged(Change<? extends TablePosition> tp) {
            logger.info("rfq tableview selected cell changed.");
            if (!RfqTableView.this.isVisible()) {
               return;
            }
            while (tp.next()) {
               if (!tp.getList().isEmpty()) {
                  List<ObservableReplyRow> items = RfqTableView.this.getItems();
                  int currentRow = tp.getList().get(0).getRow();
                  ObservableReplyRow row = items.get(currentRow);

                  if (currentRow >= 0 &&
                     currentRow < items.size() &&
                     activeSpec.get() != null) {
                     InstrumentKey key = columns.createKey(activeSpec.get().getId(), row, true);
                     buttonWatchHighlight.setState(columns.rowHighlightValue(key));
                  } else {
                     buttonWatchHighlight.setState(State.INIT);
                  }

                  logger.debug("Selected cell at (row,col)=({}, {})", currentRow, (tp.getList().size() > 0 ? tp.getList().get(0).getColumn() : "null"));

                  if (currentRow >= 0 && currentRow < items.size()) {
                     gridContext.set(new SelectionContext(GridType.Rfq, items.get(currentRow), null, currentRow));
                  }
               } else {
                  gridContext.set(new SelectionContext(GridType.Rfq, null, null, -1));
               }

            }
         }
      };
      getSelectionModel().getSelectedCells().addListener(selectedCellListener);
      this.visibleProperty().addListener(new ChangeListener<Boolean>() {
         @Override
         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            if(!newValue){
               RfqTableView.this.getSelectionModel().clearSelection();
            }
         }
      });
   }
}
