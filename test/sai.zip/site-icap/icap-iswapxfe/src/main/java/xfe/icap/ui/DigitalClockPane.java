package xfe.icap.ui;

import xstr.types.Stats;
import xstr.util.Fx;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

import java.time.LocalDateTime;

/**
 * Created by jiadin on 2/05/2016.
 */
public class DigitalClockPane extends HBox {
   private final Label hour = new Label();
   private final Label sepataor = new Label(":");
   private final Label minute = new Label();
   private final Label sepataor2 = new Label(":");
   private final Label second = new Label();
//   private final Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));

   private Timeline tl;
   private LocalDateTime dt;
   public DigitalClockPane(){
      this.getStyleClass().addAll("xfe-clock-style");
      this.getChildren().addAll(hour,sepataor,minute,sepataor2,second);
   }

   public void init(Stats stats){
      this.dt = stats.teTime;
      showtime();
      tl = Fx.runPeriodically(1000D, new Runnable() {
         @Override
         public void run() {
            showtime();
         }
      });
      tl.play();
   }

   private void showtime() {
      int v = dt.getHour();
      hour.setText(v<10 ? "0"+v : String.valueOf(v));
      v = dt.getMinute();
      minute.setText(v<10 ? "0"+v : String.valueOf(v));
      v = dt.getSecond();
      second.setText(v<10 ? "0"+v : String.valueOf(v));
      dt = dt.plusSeconds(1);
   }

 public void dispose(){
    if(tl!=null) {
       tl.stop();
    }
 }

}
