package xfe.icap.modules.settings;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.Property;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import xfe.modules.settings.SettingsComponent;
import xfe.modules.settings.SettingsInstance;
import xfe.util.scene.control.VerifiedTextField;
import xstr.util.Fun1;
import xstr.util.Fx;
import xstr.util.NoRecurse;
import xstr.util.Util;

import java.text.DecimalFormat;

public final class IntegerComponent implements SettingsComponent {
	private static final Fun1<String, Verification<Integer>> DEFAULT_TEXT_VERIFIER = new Fun1<String, Verification<Integer>>() {
		@Override
		public Verification<Integer> call(String text) {
			if (text.length() == 0) {
				return Verification.indeterminate();
			}

			if (text.equals("-")) {
				return Verification.indeterminate();
			}

			for (int value: Util.parseInt(text)) {
				return Verification.of(value);
			}

			return Verification.invalid();
		}
	};

	public static final IntegerComponent DEFAULT = new IntegerComponent(
			null,
			0,
			null,
			DEFAULT_TEXT_VERIFIER);

	private final Property<Number> valueProperty;
	private final int digits;
	private final ObservableBooleanValue disabled;
	private final Fun1<String, Verification<Integer>> parser;

	public IntegerComponent(
			Property<Number> valueProperty,
			int digits,
			ObservableBooleanValue disabled,
			Fun1<String, Verification<Integer>> parser) {
		this.valueProperty = valueProperty;
		this.digits = digits;
		this.disabled = disabled;
		this.parser = parser;
	}

	public IntegerComponent value(Property<Number> number) {
		return new IntegerComponent(
				number,
				this.digits,
				this.disabled,
				this.parser);
	}

   public IntegerComponent value(Property<Number> number, ObservableBooleanValue disabled) {
      return new IntegerComponent(
         number,
         this.digits,
         disabled,
         this.parser);
   }

	IntegerComponent digits(int i) {
		return new IntegerComponent(
				this.valueProperty,
				i,
				this.disabled,
				this.parser);
	}

	public IntegerComponent disabled(ObservableBooleanValue ob) {
		return new IntegerComponent(
				this.valueProperty,
				this.digits,
				ob,
				this.parser);
	}

	private IntegerComponent parser(Fun1<String, Verification<Integer>> fun1) {
		return new IntegerComponent(
				this.valueProperty,
				this.digits,
				this.disabled,
				fun1);
	}

	IntegerComponent restrictRange(int min, int max) {
		return parser(new Fun1<String, Verification<Integer>>() {
			@Override
			public Verification<Integer> call(String text) {
				Verification<Integer> verification = parser.call(text);

				for (int value: verification) {
					if (min <= value && value <= max) {
						return verification;
					}

					return Verification.invalid();
				}

				return verification;
			}
		});
	}

	private static final DecimalFormat decimalFormat = new DecimalFormat("#.######");

	@Override
	public SettingsInstance create(ToggleGroup toggleGroup) {
		Fun1<String, Boolean> verifier = new Fun1<String, Boolean>() {
			@Override
			public Boolean call(String text) {
				return !parser.call(text).isInvalid();
			}
		};

		TextField textField = new VerifiedTextField(verifier) {
			{
				NoRecurse noRecurse = new NoRecurse();

				textProperty().addListener(new InvalidationListener() {
					@Override
					public void invalidated(Observable observable) {
						if (!textProperty().get().isEmpty()) {
							noRecurse.run(() -> {
                        for (int value: parser.call(textProperty().get())) {
                           valueProperty.setValue(value);
                        }
                     });
						}
					}
				});

				valueProperty.addListener((observableValue, oldValue, newValue) -> textProperty().set(decimalFormat.format(newValue)));

				disableProperty().bind(disabled != null ? disabled : Fx.valueOf(false));

				this.setPrefColumnCount(digits);

				focusedProperty().addListener(new ChangeListener<Boolean>() {
					@Override
					public void changed(
							ObservableValue<? extends Boolean> observableValue,
							Boolean oldFocused,
							Boolean newFocused) {
						if (oldFocused && !newFocused) {
							noRecurse.run(() -> textProperty().set(decimalFormat.format(valueProperty.getValue())));
						}
					}
				});
			}
		};

		return new SettingsInstance() {
			{
				this.reset();
			}

			@Override
			public Node getNode() {
				return textField;
			}

			@Override
			public void reset() {
				textField.setText(decimalFormat.format(valueProperty.getValue()));
			}

			@Override
			public String getInfo() {
				return null;
			}

			@Override
			public void internalAddToolTip(GridPane pane, int yIndex) {
			}
		};
	}

   public ObservableBooleanValue disabledProp() {
	   return disabled;
   }
}
