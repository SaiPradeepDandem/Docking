package xfe.icap.modules.watchlist;

import xstr.session.ObservableReplyRow;
import javafx.collections.FXCollections;
import javafx.scene.control.Tab;
import javafx.scene.control.TableView;

import java.util.Comparator;
import java.util.UUID;

/**
 * Created by baasim on 16/05/2016.
 */
public class TabViewPair {

   public static final Comparator<TabViewPair> comparator = (o1, o2) -> o1.getPos() - o2.getPos();
   public static final String EXTERNAL_TAB = "external";

   private final Tab tab;
   private final TableView view;
   private final int pos;
   private final UUID tabId;

   public TabViewPair(Tab tab, TableView view, int pos) {
      tab.setUserData(EXTERNAL_TAB);
      this.tab = tab;
      this.view = view;
      this.pos = pos;
      this.tabId = UUID.randomUUID();
   }

   public Tab getTab() {
      return tab;
   }

   public TableView getView() {
      return view;
   }

   public int getPos() {
      return pos;
   }

   public UUID getTabId() {
      return tabId;
   }

   public void dispose() {
      view.getColumns().clear();
      view.setItems(FXCollections.<ObservableReplyRow>emptyObservableList());
   }

}
