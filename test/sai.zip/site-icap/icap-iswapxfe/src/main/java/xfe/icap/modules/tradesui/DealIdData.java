package xfe.icap.modules.tradesui;

import javafx.collections.ObservableMap;
import xfe.icap.amp.AmpDeal;
import xstr.session.ObservableReplyRow;

import java.util.Date;

public class DealIdData {
    private String instrument;
    private long dealNo;
    private long dealNoSuffix;
    private Date dealTime;
    private String traderId;
    private String operatorId;

    public DealIdData(ObservableReplyRow row) {
        this.instrument = row.getValue(AmpDeal.secCode);
        this.dealNo = row.getValue(AmpDeal.dealNo);
        this.dealNoSuffix = row.getValue(AmpDeal.dealNoSuffix);
        this.dealTime = row.getValue(AmpDeal.dealTime);
        this.traderId = row.getValue(AmpDeal.traderId);
        this.operatorId = row.getValue(AmpDeal.operatorId);
    }

    public static void clearDealData(ObservableMap<Object, Object> properties) {
        properties.remove("instrument");
        properties.remove("dealNo");
        properties.remove("dealNoSuffix");
        properties.remove("dealTime");
        properties.remove("operatorId");
        properties.remove("traderId");
    }

    public static void setDealData(ObservableMap<Object, Object> properties, ObservableReplyRow row) {
        properties.put("instrument", row.getValue(AmpDeal.secCode));
        properties.put("dealNo", row.getValue(AmpDeal.dealNo));
        properties.put("dealNoSuffix", row.getValue(AmpDeal.dealNoSuffix));
        properties.put("dealTime", row.getValue(AmpDeal.dealTime));
        properties.put("operatorId", row.getValue(AmpDeal.operatorId));
        properties.put("traderId", row.getValue(AmpDeal.traderId));
    }

    public String getInstrument() {
        return instrument;
    }

    public long getDealNo() {
        return dealNo;
    }

    public long getDealNoSuffix() {
        return dealNoSuffix;
    }

    public Date getDealTime() {
        return dealTime;
    }

    public String getTraderId() {
        return traderId;
    }

    public String getOperatorId() {
        return operatorId;
    }
}
