package xfe.icap.modules.watchlist;

import static xfe.ui.table.Cells.asnNumberCell;
import static xfe.ui.table.Cells.asnUsdBondPriceNumberCell;
import static xfe.ui.table.Cells.asnStringCell;

import xfe.util.Constants;
import xfe.icap.XfeSession;
import javafx.beans.value.ObservableBooleanValue;
import javafx.scene.control.TableColumn;
import xstr.util.Fun1;

import xstr.util.Fx;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.icap.amp.AmpSecBoardTradeInfo;
import xstr.session.ObservableReplyRow;
import xfe.ui.table.TableCellFactory;

public class TradeInfoColumns {
   public final Fun1<ObservableReplyRow, ObservableBooleanValue> rowAvailableAccessor = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
      @Override
      public ObservableBooleanValue call(ObservableReplyRow row) {
         return Fx.valueOf(row != null);
      }
   };

   private static final double totalAvailWidth =  FxApplicationModule.MAIN_STAGE_WIDTH - 12*2 - 3;
   private static final double scale = 1;//totalAvailWidth/(WatchlistModule.isDemo  ? 658- 48*2 : 658);

//   private static final double totalWidth = 622;
//   private static final double scale = (WatchlistModule.isDemo) ? 512/totalWidth : 637/totalWidth;
   public static TableColumn<ObservableReplyRow, String> createInstrumentColumn() {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnStringCell(AmpSecBoardTradeInfo.secCode)
            .strong()
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText(Constants.COLUMN_NAME_INSTR);
      column.setPrefWidth(105*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createBoardIdColumn() {
	TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnStringCell(AmpSecBoardTradeInfo.boardId)
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("Board ID");
      column.setPrefWidth(60*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createVolumeTodayColumn() {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnNumberCell(AmpSecBoardTradeInfo.volumeToday)
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("Volume");
      column.setPrefWidth(55*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createLastPriceColumn(XfeSession session) {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnUsdBondPriceNumberCell(AmpSecBoardTradeInfo.lastPrice, AmpSecBoardTradeInfo.secCode, AmpSecBoardTradeInfo.boardId,session.secBoards.get().getSecBoardsByKey())
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("Last price");
      column.setPrefWidth(70*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createLastTimeColumn() {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
    		asnStringCell(AmpSecBoardTradeInfo.lastTime)
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("Last time");
      column.setPrefWidth(105*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createLastQuantityColumn() {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnNumberCell(AmpSecBoardTradeInfo.lastQuantity)
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("Last Qty");
      column.setPrefWidth(60*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createChangeLTPColumn() {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnNumberCell(AmpSecBoardTradeInfo.changeLTP)
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("Change LTP");
      column.setPrefWidth(80*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createHighPriceColumn(XfeSession session) {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnUsdBondPriceNumberCell(AmpSecBoardTradeInfo.highPrice, AmpSecBoardTradeInfo.secCode, AmpSecBoardTradeInfo.boardId, session.secBoards.get().getSecBoardsByKey())
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("High Price");
      column.setPrefWidth(75*scale);
      column.setResizable(false);

      return column;
   }

   public static TableColumn<ObservableReplyRow, String> createLowPriceColumn(XfeSession session) {
      TableColumn<ObservableReplyRow, String> column = new TableColumn<>();

      TableCellFactory.of(
            asnUsdBondPriceNumberCell(AmpSecBoardTradeInfo.lowPrice, AmpSecBoardTradeInfo.secCode, AmpSecBoardTradeInfo.boardId, session.secBoards.get().getSecBoardsByKey())
            .textTooltip()
            .basic()).setCellFactoryIn(column);
      column.setText("Low Price");
      column.setPrefWidth(70*scale);
      column.setResizable(false);

      return column;
   }
}
