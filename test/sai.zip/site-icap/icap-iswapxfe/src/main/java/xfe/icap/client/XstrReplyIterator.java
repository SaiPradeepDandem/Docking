package xfe.icap.client;

import com.omxgroup.xstream.api.QueryRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xmp.message.XMP.XmpQueryReply;
import xmp.message.XMP.XmpQueryRequest;
import xmp.message.XMP.XmpQueryRequest.Builder;
import xstr.util.concurrent.Future;
import xstr.util.exception.AsnTypeException;
import xstr.icap.csdk.ICAP;

public class XstrReplyIterator {
   private static final Logger logger = LoggerFactory.getLogger(XstrReplyIterator.class);

   private final Builder reqBuilder;
   private final QueryRequest req;
   private final XstrWebConnection connection;

   XstrReplyIterator(QueryRequest req, byte[] cookie, XstrWebConnection connection) throws AsnTypeException {
      this.req = req;
      this.connection = connection;
      XmpQueryRequest xmpQueryRequest = ICAP.tsmrToXmp(req, cookie);
      this.reqBuilder = XmpQueryRequest.newBuilder(xmpQueryRequest);
   }

   public Future<XmpQueryReply> next() {
      logger.debug("next for newIterator Id: {}; name: {}", reqBuilder.getId(), req.message().getElemName());
      return connection.queryHandler.request(reqBuilder.build()).map(reply -> {
         reqBuilder.setCookie(reply.getCookie());
         return reply;
      });
   }

}
