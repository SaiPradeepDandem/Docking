package xfe.icap.modules.obbo;


import javafx.event.*;
import javafx.scene.Cursor;
import javafx.scene.input.*;
import javafx.scene.layout.StackPane;

public class DragAndPopupHBox extends StackPane {
   private final ObboModule module;
   private ObboStage createdStage;


   private final EventHandler<MouseEvent> mouseDragged = new EventHandler<MouseEvent>(){

      @Override
      public void handle(MouseEvent mouseEvent) {
//         System.out.println("mouse dragged in DragAndPopupHBox "+ mouseEvent.getSource());
         mouseEvent.consume();
         if(createdStage!=null){
            createdStage.mouseDragged(mouseEvent);
         }
      }

   };

   private final EventHandler<MouseEvent> mousePressed = new EventHandler<MouseEvent>() {

      @Override
      public void handle(MouseEvent mouseEvent) {
//         System.out.println("mouse pressed in DragAndPopupHBox "+ mouseEvent.getSource());
         mouseEvent.consume();
         if(module.isAllowNewDepthPopup()){
            isMousePressed = true;
            DragAndPopupHBox.this.setCursor(Cursor.HAND);
         }
      }
   };

   private final EventHandler<MouseEvent> mouseReleased = new EventHandler<MouseEvent>() {

      @Override
      public void handle(MouseEvent mouseEvent) {
//         System.out.println("mouse released in DragAndPopupHBox "+ mouseEvent.getSource());
         mouseEvent.consume();
         createdStage = null;
         isMousePressed = false;
         DragAndPopupHBox.this.setCursor(Cursor.DEFAULT);
      }
   };

   private final EventHandler<MouseEvent> mouseExit = new EventHandler<MouseEvent>() {

      @Override
      public void handle(MouseEvent mouseEvent) {
//         System.out.println("mouse exit in DragAndPopupHBox "+ mouseEvent.getSource());
         mouseEvent.consume();
         if(isMousePressed && module.isAllowNewDepthPopup() ){
            createdStage = module.createPopupStage(mouseEvent);
         }
      }
   };

   private boolean isMousePressed;
   public DragAndPopupHBox(ObboModule module) {
      this.module = module;
      this.addEventFilter(MouseEvent.MOUSE_PRESSED, mousePressed);
      this.addEventFilter(MouseEvent.MOUSE_RELEASED, mouseReleased);
      this.addEventFilter(MouseEvent.MOUSE_EXITED, mouseExit);
      this.addEventFilter(MouseEvent.MOUSE_DRAGGED, mouseDragged);
   }


   public void dispose(){
      this.setOnDragExited(null);
      this.setOnMousePressed(null);
      this.setOnMouseReleased(null);
      this.setOnMouseDragged(null);
   }

}
