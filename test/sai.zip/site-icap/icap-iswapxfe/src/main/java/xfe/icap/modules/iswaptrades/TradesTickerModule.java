package xfe.icap.modules.iswaptrades;

import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.amp.AMP;
import xfe.amp.AmpMarketTrade;
import xstr.session.QueryFeed;
import xstr.session.QueryFeedListener;
import xstr.session.QueryReplyRow;
import xstr.session.QueryRowEvent;
import xstr.util.Fx;
import xstr.util.ListenerTracker;
import xstr.util.Util;
import xstr.util.concurrent.Future;
import xfe.util.scene.control.TickerPane;
import xfe.icap.XfeSession;
import xfe.layout.FxAbstractLayout;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.ConfigurationModule;

import java.text.ParseException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

@Module.Autostart
public class TradesTickerModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradesTickerModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;

   public TradesTickerModule() {
      logger.debug("Default constructing");
   }

   @Override
   public Future<Void> startModule() {
      tradesFeed = xfeSessionModule.getUnderlyingSession().queries.getFeedSource(AMP.qREQ("marketTradeReq"));

      Date engineTime = xfeSessionModule.getUnderlyingSession().getStats().getEngineTime();

      queryFeedListener = new QueryFeedListener() {
         @Override
         public void handleEvent(List<QueryRowEvent> feedEvents) {
            if (feedEvents.isEmpty()) {
               upToDate = true;
            }

            List<Region> toBeAdded  = new LinkedList<>();
            for (QueryRowEvent feedEvent: feedEvents) {
               switch (feedEvent.getEventType()) {
                  case CREATE:
                     QueryReplyRow row = feedEvent.getNewRow();
                     Date tradeTime = row.getValue(AmpMarketTrade.tradeTime);
                     Boolean isBrokerCrossing = row.getValue(AmpMarketTrade.isBrokerCrossing);

                     if ((isBrokerCrossing == null || !isBrokerCrossing) &&
                        (upToDate || Util.safeCompare(engineTime, tradeTime) < 0)) {
                        Label instrumentLabel = new Label();
                        instrumentLabel.getStyleClass().add("xfe-ticker-instrument");
                        instrumentLabel.setEllipsisString("");
                        String secCode = row.getString(AmpMarketTrade.secCode);
                        String boardId = row.getString(AmpMarketTrade.boardId);
                        String rate = row.getString(AmpMarketTrade.price);
                        if (rate != null && xfeSessionModule.secBoards.get().isUsBond(secCode, boardId)) {
                           try {
                              rate = Util.convertToUsBondPrice(Double.parseDouble(rate));
                           } catch (NumberFormatException e) {
                              rate = "N/A";
                              logger.error("can't parse rate from {}", rate);
                           }
                        }
                        instrumentLabel.setText(secCode);
                        Label rateLabel = new Label();
                        rateLabel.setText(String.valueOf(rate));
                        rateLabel.getStyleClass().add("xfe-ticker-rate");
                        rateLabel.setEllipsisString("");
                        Label amountLabel = new Label();
                        amountLabel.getStyleClass().add("xfe-ticker-amount");
                        amountLabel.setEllipsisString("");
                        amountLabel.setText(row.getString(AmpMarketTrade.quantity));
                        Fx.run(() -> {
                           tickerView.addNode(instrumentLabel);
                           tickerView.addNode(rateLabel);
                           tickerView.addNode(amountLabel);
                        });
                     }

                     break;
                  default:
                     // NOOP
                     break;
               }
            }
            Fx.run(() -> tickerView.addNodes(toBeAdded));
         }
         boolean upToDate;
      };

      // if Settings/ShowTicker is set, we should poll, else don't
      ChangeListener<Boolean> showTradesTickerListener = (observable, oldValue, visible) -> {
         if (visible != null) {
            if (visible) {
               startPolling();
            } else {
               stopPolling();
            }
         }
      };
      tracker.addListenerAndTriggerChange(configurationModule.getData().displayTickerProperty(), showTradesTickerListener);

      tickerView.setPrefHeight(24);
      tickerView.setMaxHeight(24);
      tickerView.setMinHeight(24);
      HBox.setHgrow(tickerView, Priority.ALWAYS);

      HBox tickerPane = new HBox();
      tickerPane.getStyleClass().addAll("xfe-title-button", "xfe-ticker-pane");
      tickerPane.setMaxHeight(28);
      tickerPane.setMinHeight(28);
      tickerPane.setId("xfe-trades-ticker-view");
      tickerPane.getChildren().add(tickerView);
      TradesTickerModule.this.uiRoot = tickerPane;
      tracker.registerRollbackAction(() -> {
         TradesTickerModule.this.uiRoot = null;
         layoutModule.removeView(tickerPane);
      });

      ChangeListener<Boolean> showTradesPaneListener = (observable, oldShowTradeTickerPane, newShowTradeTickerPane) -> {
         if (newShowTradeTickerPane) {
            layoutModule.addView(tickerPane);
         } else {
            layoutModule.removeView(tickerPane);
         }
      };

      BooleanProperty displayTickerProperty = configurationModule.getData().displayTickerProperty();

      tracker.addListener(displayTickerProperty, showTradesPaneListener);
      if (displayTickerProperty.getValue())
         layoutModule.addView(tickerPane);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      tradesFeed.dispose();
      tradesFeed = null;
      tickerView.clear();
      return Future.SUCCESS;
   }

   private void startPolling() {
      tradesFeed.addListener(queryFeedListener);
   }

   private void stopPolling() {
      tradesFeed.removeListener(queryFeedListener);
   }

   public void jumpToTradeById(Object tradeId) {
      System.out.println(String.format("TradesModule.jumpToTradeById %s", tradeId));
   }


   private final ListenerTracker tracker = new ListenerTracker();
   private final TickerPane tickerView = new TickerPane(70);
   private Node uiRoot;
   private QueryFeed tradesFeed;
   private QueryFeedListener queryFeedListener;
}
