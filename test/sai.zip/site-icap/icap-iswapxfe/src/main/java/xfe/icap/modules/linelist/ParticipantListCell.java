package xfe.icap.modules.linelist;

import com.nomx.persist.linelist.Participant;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.ui.list.ReorderableListCell;
import xfe.ui.list.ReorderableListView;
import xfe.ui.list.XfeGroup;
import xfe.ui.list.XfeItem;

import java.util.*;

//import org.slf4j.*;

public class ParticipantListCell extends ReorderableListCell<Participant>{

   private static final KeyCode ACTIVE_KEY=KeyCode.F;
   private static final List<String> funkeys = Arrays.asList("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12");

   public ParticipantListCell(ReorderableListView<Participant> selectedListView, StringProperty selectedGroupId, ObjectProperty<? extends XfeGroup<? extends XfeItem>> selectedGroupProp){
      super(selectedListView,selectedGroupId);
      this.selectedGroupProp = selectedGroupProp;
//      this.view = view;
      name.setId("linelist-name-lbl");
      name.setMaxWidth(100);
      name.setEditable(false);
      name.setOnDragDetected(this.getOnDragDetected());
      XfeTooltipFactory.setTooltip(name);
      name.getStyleClass().add("xfe-hotkey-text");
      StackPane.setAlignment(name, Pos.CENTER_LEFT);
      StackPane.setAlignment(ib, Pos.TOP_RIGHT);
      namePane.getChildren().addAll(ib, name);
      ib.setEditable(false);
      ib.getStyleClass().addAll("xfe-hotkey-text", "xfe-ib-text");

      hotkeyComboBox.setId("linelist-hk-lbl");
      hotkeyComboBox.setMaxWidth(75);
      hotkeyComboBox.setMinWidth(75);
      hotkeyComboBox.setEditable(false);
      hotkeyComboBox.getStyleClass().add("xfe-hotkey-text");
      XfeTooltipFactory.setTooltip(hotkeyComboBox);

      hotkeyComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
         if (Objects.equals(newValue, "")) {
            XfeTooltipFactory.setToolTipDisplay(hotkeyComboBox, false);
         } else {
            XfeTooltipFactory.setToolTipDisplay(hotkeyComboBox, true);
         }
      });

      hotkeyComboBox.setOnShowing(new EventHandler<Event>() {
         @Override
         public void handle(Event event) {
            hotkeyComboBox.getItems().setAll(getAvailHotkey());
         }
      });

      hotkeyComboBox.getSelectionModel().selectedItemProperty().addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            String hotKey = hotkeyComboBox.getSelectionModel().selectedItemProperty().get();
            ParticipantListCell.this.getItem().setHK(hotKey);
         }
      });
      InvalidationListener focusLis = paramObservable -> {
         if (name.isFocused() || hotkeyComboBox.isFocused()) {
            ParticipantListCell.this.getListView().getSelectionModel().select(ParticipantListCell.this.getItem());
         }
      };
      name.focusedProperty().addListener(focusLis);
      hotkeyComboBox.focusedProperty().addListener(focusLis);

      ColumnConstraints nameColumn = new ColumnConstraints();
      nameColumn.setHgrow(Priority.ALWAYS);
      cell.getColumnConstraints().add(nameColumn);
      cell.getColumnConstraints().add(new ColumnConstraints());
      cell.getColumnConstraints().add(new ColumnConstraints());
      cell.getColumnConstraints().add(new ColumnConstraints());
      cell.getColumnConstraints().add(new ColumnConstraints());

      delButton.getStyleClass().addAll("xfe-grid-tab-close-button","xfe-button-del-participant");
      delButton.setOnAction(arg0 -> {
         Participant par = getItem();
         if (par != null) {
            if(par.getGroup()!=null) {
               par.removeFromGroup();
            }else{
               selectedListView.getItems().remove(par);
            }
         }
      });


   }

   private List<String> getAvailHotkey(){
      List<String> availKey = new LinkedList<>(funkeys);
      if(selectedGroupProp.get()!= null)
         selectedGroupProp.get().getItems().stream().filter(par -> par.getHK() != null).forEach(par -> availKey.remove(par.getHK()));
      return availKey;
   }

   @Override
   protected Comparator<Participant> getComparator() {
      return new Comparator<Participant>() {
         @Override
         public int compare(Participant p1, Participant p2) {
            if (p1 == null || p2 == null) return 1;
            return Objects.equals(p1.getId(), p2.getId()) && Objects.equals(p1.getSubTitle(), p2.getSubTitle()) && Objects.equals(p1.getParentfirmId(), p2.getParentfirmId()) ? 0 : 1;
         }
      };
   }

   @Override
   protected void updateItem(Participant item, boolean empty) {
      super.updateItem(item, empty);
      if(isEmpty() || item==null) {
         setGraphic(null);
      } else {
         hotkeyComboBox.getSelectionModel().select(item.getHK());
         cell.getChildren().clear();
         cell.add(namePane, 0, 0);
         cell.add(hotkeyComboBox, 1, 0);
         cell.add(delButton, 2, 0);
//         hkComboBox.getItems().setAll(item.getAvailHotkey());
//         hkComboBox.getSelectionModel().select(item.getHK());
         name.setText(item.displayName);
         XfeTooltipFactory.setTooltip(name);
         ib.setText(item.getSubTitle()==null?"":item.getSubTitle());
         this.setGraphic(cell);
      }
   }
// private static final Logger logger =LoggerFactory.getLogger(ParticipantListCell.class);
   private final ObjectProperty<? extends XfeGroup<? extends XfeItem>> selectedGroupProp;
   private final GridPane cell = new GridPane();
   private final Button delButton = new Button();


//   private final ComboBox<String> hkComboBox = new ComboBox<String>(availHotkeys);

//   private ReorderableListView<Participant> view;
   private final StackPane namePane = new StackPane();
   private final TextField name = new TextField();
   private final TextField ib = new TextField();
   private final ComboBox<String> hotkeyComboBox = new ComboBox<>();
   private final ContextMenu hkList = new ContextMenu();
}
