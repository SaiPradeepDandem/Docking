package xfe.icap.modules.securities;

import java.util.Date;

/**
 * Data object holding the workup information.
 */
class WorkupData {
   private String phase;
   private Date endTime;

   public WorkupData(String phase) {
      this.phase = phase;
   }

   public WorkupData(Date endTime) {
      this.endTime = endTime;
   }

   public String getPhase() {
      return phase;
   }

   public void setPhase(String phase) {
      this.phase = phase;
   }

   public Date getEndTime() {
      return endTime;
   }

   public void setEndTime(Date endTime) {
      this.endTime = endTime;
   }
}
