package xfe.icap.modules.watchlist;

import com.nomx.domain.types.InstrumentKey;
import com.omxgroup.xstream.amp.AmpOrderImpliedType;
import com.omxgroup.xstream.amp.AmpSecClassId;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.IntegerExpression;
import javafx.beans.property.*;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.*;
import javafx.scene.Node;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpRfq;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.icap.modules.iswaporders.OrderFilters;
import xfe.icap.modules.iswaporders.OrdersColumns;
import xfe.icap.modules.rfq.RfqColumns;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.settings.SettingsData;
import xfe.icap.types.InstrumentFactory;
import xfe.layout.LayoutManager;
import xfe.types.OrdersTrans;
import xfe.types.SecBoard;
import xfe.ui.TriStateButton.State;
import xfe.ui.table.AsnValueFactory;
import xfe.ui.table.DynamicTableCell;
import xfe.ui.table.TableCellFactory;
import xfe.ui.table.XfeDynamicActionCell;
import xfe.util.*;
import xfe.util.scene.control.NodeFlashDecorator;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.*;
import xstr.util.Util;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.RowFilters;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static xfe.ui.table.Cells.*;

public class InstrumentsColumns implements Constants {
   private static final Logger logger = LoggerFactory.getLogger(InstrumentsColumns.class);

   private static final long REMAINING_TIME_TO_FLASH = 1000 * 15; //15 seconds

   final XfeSession xfeSession;
   final SettingsData settingsData;
   final ListenerTracker tracker;
   private final SelectionContextModule selectionContextModule;
   private final InstrumentsFilters filters;
   final ObservableMap<InstrumentKey, State> toggledRowsHeight = FXCollections.observableMap(new HashMap<>(100));
   final ObservableSet<String> priceTightnessGhosts = FXCollections.observableSet();

   private final ReadOnlyBooleanProperty priceTightnessProperty4MiniWatchlist;
   /**
    * The rfq instrument only need to flash once during its lifetime. After flashed, the rfq need to is excluded from flashing list
    */
   private final ObservableSet<String> flashDisabledSet = FXCollections.observableSet(new HashSet<>());

   private final ValueOnNode<TableCell<?, ?>, BooleanProperty> cellSelectedPropertyOnNode = new ValueOnNode<TableCell<?, ?>, BooleanProperty>() {
      @Override
      protected BooleanProperty initialise(TableCell<?, ?> cell) {
         return new SimpleBooleanProperty(false);
      }
   };

   private Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> clickHandler;

   private final LayoutManager<Node> layoutManager;

   private final Fun1<ObservableReplyRow, ObservableBooleanValue> rowAvailableAccessor = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
      @Override
      public ObservableBooleanValue call(ObservableReplyRow row) {
         return Fx.valueOf(row != null);
      }
   };


   private Function<ObservableReplyRow, ObservableValue<Boolean>> flashOnRfq() {
      return row -> new BooleanBinding(){
         final ObservableValue<String> instrCodeProp = row.getProperty(AmpIcapSecBoardTrim2.secCode);
         final ObservableValue<String> boardIdProp = row.getProperty(AmpIcapSecBoardTrim2.boardId);
         final String strSecCode = row.getString(AmpIcapSecBoardTrim2.secCode);
         final String strBoardId = row.getString(AmpIcapSecBoardTrim2.boardId);

         final ObservableValue<Boolean> isDisabled = isSecFlashDisabled(strSecCode);
         final ObservableValue<Boolean> isFinalPhase = xfeSession.rfqs.get().liveBooleanisRfqFinalPhase(strSecCode, strBoardId);

         {
            bind(instrCodeProp,boardIdProp,isDisabled,isFinalPhase);
         }

         @Override
         protected boolean computeValue() {
            if(!xfeSession.rfqs.isInitialized()) return false;
            if(instrCodeProp.getValue()==null || boardIdProp.getValue()==null) return false;
            boolean isFlashDisabled = isDisabled.getValue();
            if(isFlashDisabled) return false;
            if(selectionContextModule.isSecSelected(instrCodeProp.getValue(), boardIdProp.getValue())){
               disableFlash(strSecCode, strBoardId);
               return false;
            }
            return isFinalPhase.getValue();
         }

      };
   }

   private Function<ObservableReplyRow, ObservableValue<Boolean>> isBlink(AsnConversionAccessor<Double> accessor, boolean isBid, boolean orImplied, AsnConversionAccessor<Double> impliedAccessor) {
      if(!orImplied){
         return isBlink(accessor);
      }else{
         return row -> new AutoTurnOffBooleanBinding(settingsData.cellFlashTimeoutProperty()) {
            private Double value;
            private final ObservableObjectValue<Double> prop1 = row.getProperty(accessor);
            private final ObservableObjectValue<Double> prop2 = row.getProperty(impliedAccessor);
            {
               bind(prop1, prop2, settingsData.cellFlashProperty());
            }

            @Override
            protected boolean myComputeValue() {
               Double currentV = isBid ? Ops.safeMax(prop1.getValue(), prop2.getValue()) : Ops.safeMin(prop1.getValue(), prop2.getValue());
               boolean isEqual = Objects.equals(value, currentV);
               if(!isEqual){
                  value = currentV;
                  return settingsData.cellFlashProperty().get();
               }else{
                  return  false;
               }
            }
         };
      }
   }


   private Function<ObservableReplyRow, ObservableValue<Boolean>> isBlink(FlashTradeSide tradeSide, TradeBlinkObservableObject tradeSideProp, ObservableBooleanValue enabledProp, AsnConversionAccessor<String> secCodeAccessor) {
      return row -> new BooleanBinding() {

         private final ObservableObjectValue<String> liveSecCode = row.getProperty(secCodeAccessor);

         {
            bind(liveSecCode, tradeSideProp);
         }

         @Override
         protected boolean computeValue() {
            if(enabledProp.get()) {
               String tradeSecCode = tradeSideProp.getSecCode();
               boolean rtn =  tradeSecCode != null &&tradeSecCode.equals(liveSecCode.get()) && tradeSide.equals(tradeSideProp.get());
               logger.debug("{} is blinking {}.  tradeSecCode is {}, tradeSide is  {}; tradeSideProp is {}.",liveSecCode.get(),rtn,tradeSecCode,tradeSide,tradeSideProp.get());
               return rtn;
            } else {
               return false;
            }
         }
      };
   }

   private <T> Function<ObservableReplyRow, ObservableValue<Boolean>> isBlink(AsnConversionAccessor<T> accessor) {
      return row -> new AutoTurnOffBooleanBinding(settingsData.cellFlashTimeoutProperty()) {
         private T value;
         private final ObservableObjectValue<T> prop = row.getProperty(accessor);
         {
            bind(prop, settingsData.cellFlashProperty());
         }

         @Override
         protected boolean myComputeValue() {
            T currentV = prop.get();
            boolean isEqual = Objects.equals(value, currentV);
            logger.debug("previous value is {} current value is {} isEquals: {} accesssor is {}",value, currentV, isEqual, accessor);
            if(!isEqual){
               value = currentV;
               return settingsData.cellFlashProperty().get();
            }else{
               return  false;
            }
         }
      };
   }


   private Fun1<ObservableReplyRow, ObservableValue<Boolean>> priceTight(ReadOnlyBooleanProperty priceTightnessProperty){
      return new Fun1<ObservableReplyRow, ObservableValue<Boolean>>(){
         @Override
         public ObservableValue<Boolean> call(ObservableReplyRow row) {
            ObservableValue<Double> bidPrice = row.getProperty(AmpIcapSecBoardTrim2.bidPrice_d);
            ObservableValue<Double> offerPrice = row.getProperty(AmpIcapSecBoardTrim2.offerPrice_d);
            ObservableValue<Double> nLevelImpOfferPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
            ObservableValue<Double> nLevelImpBidPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d);
            ObservableValue<String> bidPriceType = row.getProperty(AmpIcapSecBoardTrim2.bidSpecialOrderType);
            ObservableValue<String> offerPriceType = row.getProperty(AmpIcapSecBoardTrim2.offerSpecialOrderType);

            return new BooleanBinding() {
               {
                  bind(offerPrice,bidPrice,bidPriceType,offerPriceType,nLevelImpBidPrice,nLevelImpOfferPrice,priceTightnessProperty,settingsData.strategyPriceTight(),settingsData.outrightPriceTight());
               }
               @Override
               protected boolean computeValue() {
                  return isPriceTight(row,priceTightnessProperty);
               }
            };
         }
      };
   }

   boolean isPriceTight(ObservableReplyRow row, ReadOnlyBooleanProperty priceTightnessProperty) {
      try {
         ObservableValue<Double> bidPrice = row.getProperty(AmpIcapSecBoardTrim2.bidPrice_d);
         ObservableValue<String> bidPriceType = row.getProperty(AmpIcapSecBoardTrim2.bidSpecialOrderType);
         ObservableValue<Double> offerPrice = row.getProperty(AmpIcapSecBoardTrim2.offerPrice_d);
         ObservableValue<String> offerPriceType = row.getProperty(AmpIcapSecBoardTrim2.offerSpecialOrderType);
         ObservableValue<Double> nLevelImpOfferPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
         ObservableValue<Double> nLevelImpBidPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d);
         ObservableValue<Integer> classId = row.getProperty(AmpIcapSecBoardTrim2.secClassId);
         if (!xfeSession.loggedOnProperty().get()|| !priceTightnessProperty.getValue()) {
            return false;
         }
         double threshold = (classId != null && classId.getValue() == AmpSecClassId.strategy) ?
            (settingsData.strategyPriceTight() == null ? 0.5 : settingsData.strategyPriceTight().getValue()) :
            (settingsData.outrightPriceTight() == null ? 50 : settingsData.outrightPriceTight().getValue() / 100);
         double tolerent = threshold / 100;
         Double bid = Constants.PRICE_TYPE_INDICATIVE.equals(bidPriceType.getValue()) ? null :  bidPrice.getValue();
         Double offer = Constants.PRICE_TYPE_INDICATIVE.equals(offerPriceType.getValue()) ? null : offerPrice.getValue();

         Double betterBid = Util.getBetterPrice(true,bid,nLevelImpBidPrice.getValue());
         Double betterOffer = Util.getBetterPrice(false,offer,nLevelImpOfferPrice.getValue());
         boolean rtn = betterBid != null && betterOffer != null && ((betterOffer - betterBid) - threshold <= tolerent);
         logger.trace("threshold:{}\tReturn:{}\tofferPrice:{}\tbidPrice:{}\tnLevelImpOfferPrice:{}\tnLevelImpbidPrice:{}\t betterDid:{}\tbetterOffer:{}\ttolerent is{}",threshold,rtn,offerPrice.getValue(),bidPrice.getValue(),nLevelImpOfferPrice.getValue(),nLevelImpBidPrice.getValue() ,betterBid,betterOffer,tolerent);
         return rtn;
      } catch (Exception e) {
         logger.error("calculate price tightness error.", e);
         return false;
      }
   }


   private Fun1<ObservableReplyRow, ObservableValue<Boolean>> isPriceTight(ReadOnlyBooleanProperty priceTightnessProperty) {
      return new Fun1<ObservableReplyRow, ObservableValue<Boolean>>(){
         @Override
         public ObservableValue<Boolean> call(ObservableReplyRow row) {
            return new BooleanBinding(){
               final ObservableValue<Double> bidPrice = row.getProperty(AmpIcapSecBoardTrim2.bidPrice_d);
               final ObservableValue<String> bidPriceType = row.getProperty(AmpIcapSecBoardTrim2.bidSpecialOrderType);
               final ObservableValue<Double> offerPrice = row.getProperty(AmpIcapSecBoardTrim2.offerPrice_d);
               final ObservableValue<String> offerPriceType = row.getProperty(AmpIcapSecBoardTrim2.offerSpecialOrderType);
               final ObservableValue<Double> nLevelImpOfferPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
               final ObservableValue<Double> nLevelImpBidPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d);
               final ObservableValue<Integer> classId = row.getProperty(AmpIcapSecBoardTrim2.secClassId);

               {
                  bind(bidPrice, offerPrice, bidPriceType, offerPriceType, nLevelImpBidPrice, nLevelImpOfferPrice, priceTightnessProperty, classId, settingsData.strategyPriceTight(), settingsData.outrightPriceTight());
               }

               @Override
               protected boolean computeValue() {
                  try {
                     if (!xfeSession.loggedOnProperty().get() ||
                        !priceTightnessProperty.getValue() ||
                        Constants.PRICE_TYPE_INDICATIVE.equals(bidPriceType.getValue()) ||
                        Constants.PRICE_TYPE_INDICATIVE.equals(offerPriceType.getValue())) return false;
                     double threshold = (classId != null && classId.getValue() == AmpSecClassId.strategy) ?
                        (settingsData.strategyPriceTight() == null ? 0.5 : settingsData.strategyPriceTight().getValue()) :
                        (settingsData.outrightPriceTight() == null ? 50 : settingsData.outrightPriceTight().getValue());
                     double tolerance  = threshold / 100;
                     boolean rtn;
                     rtn = (offerPrice.getValue() != null &&
                        bidPrice.getValue() != null &&
                        (offerPrice.getValue() - bidPrice.getValue())  - threshold <= tolerance) ||
                        (nLevelImpOfferPrice.getValue() != null &&
                           nLevelImpBidPrice.getValue() != null &&
                           ((nLevelImpOfferPrice.getValue() - nLevelImpBidPrice.getValue()) - threshold) <= tolerance );
                     logger.debug("threshold:{}\tReturn:{}\tofferPrice:{}\tbidPrice:{}\tnLevelImpOfferPrice:{}\tnLevelImpbidPrice:{} tolerance is {}",
                        threshold,
                        rtn,
                        offerPrice.getValue(),
                        bidPrice.getValue(),
                        nLevelImpOfferPrice.getValue(),
                        nLevelImpBidPrice.getValue(),
                        tolerance);
                     return rtn;
                  } catch (Exception e) {
                     logger.error("calculate price tightness error.",e);
                     return false;
                  }
               }

            };
         }
      };
   }

   TableColumn<ObservableReplyRow, String> createInstrumentColumn(
      Property<Runnable> interrogationActionProperty,
      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> cellAction) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(
         asnStringCell(AmpIcapSecBoardTrim2.secCode)
            .doubleClickHandler(clickHandler)
            .strong()
            .flashStyle()
            .toggleStyle(NodeFlashDecorator.FLASH_TOKEN, flashOnRfq())
            .annotate(cellSelectedPropertyOnNode, interrogationActionProperty, cellAction, rowAvailableAccessor)
            .style(CELL_STYLE_INSTR)
            .textTooltip()
            .basic())).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createWatchInstrumentColumn(
      Property<Runnable> interrogationActionProperty,
      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> cellAction,
      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> watchDoubleClickHandler,
      TradesFlashModule tradesFlashModule,
      boolean forPriceTightness) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of((asnStringCell(AmpIcapSecBoardTrim2.secCode)
         .toggleStyle(PRICE_TIGHTNESS_STYLE, priceTight(forPriceTightness ? Fx.FalseProp : priceTightnessProperty4MiniWatchlist))
         .toggleStyle(FLASH_BUY, isBlink(FlashTradeSide.Pay, tradesFlashModule.blinkTradeSideToOffProp, settingsData.hiVisProperty(), AmpIcapSecBoardTrim2.secCode))
         .toggleStyle(FLASH_SELL, isBlink(FlashTradeSide.Receive, tradesFlashModule.blinkTradeSideToOffProp, settingsData.hiVisProperty(), AmpIcapSecBoardTrim2.secCode))
         .toggleStyle(FLASH_NEUTRAL, isBlink(FlashTradeSide.Neutral, tradesFlashModule.blinkNeutralToOffProp, Fx.valueOf(true), AmpIcapSecBoardTrim2.secCode))
         .doubleClickHandler(watchDoubleClickHandler)
         .textTooltip()
         .strong()
         .flashStyle()
         .style(CELL_STYLE_INSTR)
         .annotate(cellSelectedPropertyOnNode, interrogationActionProperty, cellAction, rowAvailableAccessor)
         .basic())).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createPopupInstrumentColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(
         asnStringCell(AmpIcapSecBoardTrim2.secCode)
            .strong()
            .style(CELL_STYLE_INSTR)
            .basic())).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR);
      col.setPrefWidth(200);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createTypeCol(boolean isBid, boolean orImplied) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      AsnConversionAccessor<String> acc = isBid ? AmpIcapSecBoardTrim2.bidSpecialOrderType : AmpIcapSecBoardTrim2.offerSpecialOrderType;

      Fun1<ObservableReplyRow, ObservableValue<String>> rightTypeStringGetter = orImplied
         ? (isBid ? AmpIcapSecBoardTrim2.bidOrderTypeGetter : AmpIcapSecBoardTrim2.offerOrderTypeGetter)
         : (isBid ? AmpIcapSecBoardTrim2.realBidTypeGetter : AmpIcapSecBoardTrim2.realOfferTypeGetter);

      Function<ObservableReplyRow, ObservableValue<Boolean>> indicativeFn = (r) -> filters.isIndicative.call(r, isBid, orImplied);
      TableCellFactory.of(cellSelect(DynamicTableCell.defaultCell(rightTypeStringGetter)
         .toggleStyle("indicative", indicativeFn)
         .style(CELL_STYLE_INSTR_TYPE)
         .style(isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .toggleStyle(CELL_BLINK_STYLE, isBlink(acc))
         .basic())).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR_TYPE);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createFirmColumn(boolean isBid, XfeSession session) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<ObservableReplyRow, ObservableValue<String>> firmAccessor = InstrumentFactory.firmFactory(isBid, session);
      TableCellFactory.of(cellSelect(DynamicTableCell.defaultCell(firmAccessor)
         .style(CELL_STYLE_INSTR_TYPE)
         .style(isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic())).setCellFactoryIn(col);
      col.setText(isBid ? "Pay Firm" : "Rec Firm");
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createPopupTypeCol(boolean isBid) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell = DynamicTableCell
         .defaultCell(InstrumentFactory.typeFactory(isBid));
      TableCellFactory.of(cell)
         .style(CELL_STYLE_INSTR_TYPE)
         .style(isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR_TYPE);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createTotalColumn(boolean isBid, boolean orImplied) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();

      Fun1<ObservableReplyRow, ObservableValue<String>> rightTotalStringGetter = orImplied
         ? (isBid ? AmpIcapSecBoardTrim2.betterBidTotalGetter : AmpIcapSecBoardTrim2.betterOfferTotalGetter)
         : (isBid ? AmpIcapSecBoardTrim2.realBidTotalStringGetter : AmpIcapSecBoardTrim2.realOfferTotalStringGetter);

      AsnConversionAccessor<Double> totalAccessor = isBid ? AmpIcapSecBoardTrim2.bidDepth_d : AmpIcapSecBoardTrim2.offerDepth_d;
      AsnConversionAccessor<Double> impliedQuantityAccessor = isBid ? AmpIcapSecBoardTrim2.nLevelImpBidQuantity : AmpIcapSecBoardTrim2.nLevelImpOfferQuantity;

      TableCellFactory.of(cellSelect(
         asnStringCell(rightTotalStringGetter)
            .doubleClickHandler(clickHandler)
            .textTooltip()
            .style(CELL_STYLE_INSTR_TOTAL)
            .style(isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
            .toggleStyle(CELL_BLINK_STYLE, isBlink(totalAccessor, isBid, orImplied, impliedQuantityAccessor))
            .style("number-top-right")
            .basic())).setCellFactoryIn(col);
      col.setText("Total");
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, Double> createPopupTotalColumn(boolean isBid) {
      TableColumn<ObservableReplyRow, Double> col = new TableColumn<>();
      AsnConversionAccessor<Double> totalAccessor = isBid ? AmpIcapSecBoardTrim2.bidDepth_d : AmpIcapSecBoardTrim2.offerDepth_d;
      TableCellFactory.of(
         asnNumberCell(totalAccessor, 0)
            .textTooltip()
            .basic()).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR_TOTAL);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createImpliedColumn(
      Property<Runnable> interrogationActionProperty, boolean isBid,
      BooleanProperty showingInfoPopups, ObservableMap<Tuple2<String, String>, SecBoard> secBoardsByKey) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();

      AsnConversionAccessor<Double> impliedAccessor = isBid ? AmpIcapSecBoardTrim2.nLevelImpBidPrice_d : AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d;

      TableCellFactory.of(cellSelect(
         asnUsdBondPriceNumberCell(impliedAccessor, AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId, secBoardsByKey)
            .style(isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER)
            .style(CELL_STYLE_INSTR_NLEVEL)
            .annotate(cellSelectedPropertyOnNode, interrogationActionProperty, nImpliedCellAction(isBid, showingInfoPopups), nImpliedCellActionAvailable(isBid))
            .doubleClickHandler(clickHandler)
            .textTooltip()
            .toggleStyle(CELL_BLINK_STYLE, isBlink(impliedAccessor))
            .basic())).setCellFactoryIn(col);
      col.setText(isBid ? COLUMN_NAME_INSTR_NLEVEL_BID : COLUMN_NAME_INSTR_NLEVEL_OFFER);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createPopupImpliedColumn(boolean isBid, ObservableMap<Tuple2<String, String>, SecBoard> secBoardsByKey) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      String style = isBid ? BUY_STYLE : SELL_STYLE;
      AsnConversionAccessor<Double> impliedAccessor = isBid ? AmpIcapSecBoardTrim2.nLevelImpBidPrice_d : AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d;
      TableCellFactory.of(
         asnUsdBondPriceNumberCell(impliedAccessor, AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId, secBoardsByKey)
            .textTooltip()
            .style(style)
            .basic()).setCellFactoryIn(col);
      col.setText(isBid ? COLUMN_NAME_INSTR_NLEVEL_BID : COLUMN_NAME_INSTR_NLEVEL_OFFER);
      col.setResizable(false);
      return col;
   }

   public static ObservableValue<Double> observable(AsnConversionAccessor<Double> accessor, ObservableReplyRow row) {
      return AsnValueFactory.asValue(accessor).call(row);
   }

   public static Fun1<ObservableValue<Integer>, ObservableValue<Boolean>> even() {
      return new Fun1<ObservableValue<Integer>, ObservableValue<Boolean>>() {
         @Override
         public ObservableValue<Boolean> call(ObservableValue<Integer> observableValue) {

            return new SimpleObjectProperty<Boolean>(false) {
               final SimpleObjectProperty<Boolean> self = this;

               @SuppressWarnings("unused")
               final Object ref = Fx.addWeakListener(observableValue, (dummy, oldValue, newValue) -> self.setValue(observableValue.getValue() % 2 == 0));
            };
         }
      };
   }

   private static final String STALE_STYLE = "stale";

   TableColumn<ObservableReplyRow, String> createBidOfferSeparatorColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();

      TableCellFactory.of(emptyCell()
         .style("table-cell-bidoffer-separator")
         .basic()).setCellFactoryIn(col);
      col.setMinWidth(3);
      col.setMaxWidth(3);
      col.setResizable(false);

      return col;
   }

   void setupWatchPriceColumn(
      TableColumn<ObservableReplyRow, String> col,
      Property<Runnable> interrogationActionProperty,
      boolean isBid,
      ObservableBooleanValue showingInfoPopups,
      boolean orImplied,
      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> watchDoubleClickHandler,
      WeakHashMap<Boolean, Callback<ObservableReplyRow,
         ObservableValue<String>>> columnContext,
      Map<Tuple2<String, String>, SecBoard> secBoardsByKey) {
      String style = isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER;
      Callback<ObservableReplyRow, ObservableValue<String>> betterPriceStringGetter = orImplied
         ? (isBid ? AmpIcapSecBoardTrim2.betterBidStringGetter(secBoardsByKey) : AmpIcapSecBoardTrim2.betterOfferStringGetter(secBoardsByKey))
         : (isBid ? AmpIcapSecBoardTrim2.realBidStringGetter(secBoardsByKey) : AmpIcapSecBoardTrim2.realOfferStringGetter(secBoardsByKey));
      AsnConversionAccessor<Double> priceAccessor = isBid ? AmpIcapSecBoardTrim2.bidPrice_d : AmpIcapSecBoardTrim2.offerPrice_d;
      AsnConversionAccessor<Double> impliedPriceAccessor = isBid ? AmpIcapSecBoardTrim2.nLevelImpBidPrice_d : AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d;
      if (columnContext != null) {
         columnContext.put(isBid, betterPriceStringGetter);
      }

      Function<ObservableReplyRow, ObservableValue<Boolean>> tfn = r -> filters.isIndicative.call(r, isBid, orImplied);
      TableCellFactory.of(cellSelectExpanded(fingerPrint(isBid,true,
         asnStringCell(betterPriceStringGetter)
            .toggleStyle("indicative", tfn)
            .strong()
            .toggleStyle(CELL_BLINK_STYLE, isBlink(priceAccessor, isBid, orImplied, impliedPriceAccessor))
            .doubleClickHandler(watchDoubleClickHandler)
            .textTooltip()
            .style(style)
            .style(CELL_STYLE_INSTR_PRICE)
            .annotate(cellSelectedPropertyOnNode,
               interrogationActionProperty,
               impliedCellAction(isBid, showingInfoPopups),
               impliedCellActionAvailable(isBid))
            .basic()))).setCellFactoryIn(col);
      col.setText(isBid ? (orImplied ? "B/B^n" : Constants.COLUMN_NAME_BID) : (orImplied ? "O/O^n" : Constants.COLUMN_NAME_OFFER));
      col.setResizable(false);
   }

   TableColumn<ObservableReplyRow, String> createPriceOrImpliedColumn(
      Property<Runnable> interrogationActionProperty,
      boolean isBid,
      ObservableBooleanValue showingInfoPopups,
      boolean orImplied, ObservableMap<Tuple2<String, String>, SecBoard> secBoardsByKey) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();

      Callback<ObservableReplyRow, ObservableValue<String>> betterPriceStringGetter = orImplied
         ? (isBid ? AmpIcapSecBoardTrim2.betterBidStringGetter(secBoardsByKey) : AmpIcapSecBoardTrim2.betterOfferStringGetter(secBoardsByKey))
         : (isBid ? AmpIcapSecBoardTrim2.realBidStringGetter(secBoardsByKey) : AmpIcapSecBoardTrim2.realOfferStringGetter(secBoardsByKey));
      AsnConversionAccessor<Double> priceAccessor = isBid ? AmpIcapSecBoardTrim2.bidPrice_d : AmpIcapSecBoardTrim2.offerPrice_d;
      AsnConversionAccessor<Double> impliedPriceAccessor = isBid ? AmpIcapSecBoardTrim2.nLevelImpBidPrice_d : AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d;

      String style = isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER;

      Function<ObservableReplyRow, ObservableValue<Boolean>> tfn = r -> filters.isIndicative.call(r, isBid, orImplied);
      TableCellFactory.of(cellSelect(fingerPrint(isBid, false,
         asnStringCell(betterPriceStringGetter)
            .toggleStyle("indicative", tfn)
            .toggleStyle(CLEARING_STYLE, isBid ? InstrumentsFilters.isClearingBid : InstrumentsFilters.isClearingOffer)
            .toggleStyle(CLEARINGTOYOU_STYLE, isBid ? InstrumentsFilters.isClearingToYouBid : InstrumentsFilters.isClearingToYouOffer)
            .strong()
            .toggleStyle(CELL_BLINK_STYLE, isBlink(priceAccessor, isBid, orImplied, impliedPriceAccessor))
            .toggleStyle(STALE_STYLE, isBid ? InstrumentsFilters.isStaleIndicativeBid : InstrumentsFilters.isStaleIndicativeOffer)
            .doubleClickHandler(clickHandler)
            .textTooltip()
            .style(CELL_STYLE_INSTR_PRICE)
            .style(style)
            .annotate(cellSelectedPropertyOnNode, interrogationActionProperty, impliedComplexCellAction(isBid, showingInfoPopups), impliedComplexCellActionAvailable(isBid))
            .basic()))).setCellFactoryIn(col);
      col.setText(isBid ? (orImplied ? "B/B^n" : Constants.COLUMN_NAME_BID) : (orImplied ? "O/O^n" : Constants.COLUMN_NAME_OFFER));
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createWatchTotalColumn(
      Property<Runnable> interrogationActionProperty,
      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> cellAction,
      boolean isBid, boolean orImplied, WeakHashMap<Boolean,Fun1<ObservableReplyRow,ObservableValue<String>>> columnContext) {

      Fun1<ObservableReplyRow, ObservableValue<String>> rightTotalStringGetter = orImplied
         ? (isBid ? AmpIcapSecBoardTrim2.betterBidTotalGetter : AmpIcapSecBoardTrim2.betterOfferTotalGetter)
         : (isBid ? AmpIcapSecBoardTrim2.realBidTotalStringGetter : AmpIcapSecBoardTrim2.realOfferTotalStringGetter);

      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      if (columnContext != null) {
         columnContext.put(isBid,rightTotalStringGetter);
      }

      TableCellFactory.of((cellSelect(
         asnStringCell(rightTotalStringGetter)
            .textTooltip()
            .strong()
            .flashStyle()
            .style(isBid ? "watchlist-bid-total" : "watchlist-offer-total") //this is not for styling, it is for locate the cell.
            .style("number-top-right")
            .annotate(cellSelectedPropertyOnNode, interrogationActionProperty, cellAction, rowAvailableAccessor)
            .basic()))).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR_TOTAL);
      col.setMinWidth(0);
      col.setMaxWidth(0);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createPopupPriceColumn(boolean isBid, ObservableMap<Tuple2<String, String>, SecBoard> secBoardsByKey) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      String style = isBid ? CELL_STYLE_ANY_BID : CELL_STYLE_ANY_OFFER;
      AsnConversionAccessor<Double> priceAccessor = isBid ? AmpIcapSecBoardTrim2.bidPrice_d : AmpIcapSecBoardTrim2.offerPrice_d;

      TableCellFactory.of(fingerPrint(isBid,false,
         asnUsdBondPriceNumberCell(priceAccessor, AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId, secBoardsByKey)
            .strong()
            .textTooltip()
            .style(style)
            .style(CELL_STYLE_INSTR_PRICE)
            .basic())).setCellFactoryIn(col);
      col.setText(isBid ? Constants.COLUMN_NAME_BID : Constants.COLUMN_NAME_OFFER);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createPriceTightnessColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(doubleClickHandler(
         asnNumberCell(AmpIcapSecBoardTrim2.priceTightness)
            .textTooltip()
            .style(CELL_STYLE_INSTR_PRICE)
            .basic()))).setCellFactoryIn(col);
      col.setText("P. Tightness");
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createLastPriceColumn(boolean isPopup, ObservableMap<Tuple2<String, String>, SecBoard> secBoardsByKey) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();

      TableCellFactory.of(cellSelect(doubleClickHandler(
         asnUsdBondPriceNumberCell(AmpIcapSecBoardTrim2.lastPrice_d, AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId, secBoardsByKey)
            .textTooltip()
            .style(CELL_STYLE_INSTR_LASTPRICE)
            .toggleStyle(CELL_BLINK_STYLE, isBlink(AmpIcapSecBoardTrim2.lastPrice_d))
            .basic()))).setCellFactoryIn(col);
      if (isPopup) {
         col.setText("Last");
      } else {
         col.setText("Last Price");
      }
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createLastQuantityColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(doubleClickHandler(
         asnNumberCell(AmpIcapSecBoardTrim2.lastQuantity)
            .textTooltip()
            .style(CELL_STYLE_INSTR_LASTQTY)
            .basic()))).setCellFactoryIn(col);
      col.setText("Last Amt");
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, XfeAction> createReferColumn() {
      TableColumn<ObservableReplyRow, XfeAction> col = new TableColumn<>();
      col.setCellFactory(cellSelect(XfeDynamicActionCell.factory(referAction())
      ));
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createScrollbarColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      col.setText("");
      col.setResizable(false);
      col.setPrefWidth(12);
      return col;
   }

   private static final Fun1<Integer, Duration> asMillis = new Fun1<Integer, Duration>() {
      @Override
      public Duration call(Integer value) {
         return Duration.of(value, TimeUnit.MILLISECONDS);
      }
   };

   InstrumentsColumns(XfeSession session, ListenerTracker tracker, SelectionContextModule selectionContextModule, LayoutManager<Node> layoutManager,
                      InstrumentsFilters filters, SettingsData settingsData,
                      BooleanProperty priceTightnessProperty4MiniWatchList) {
      this.xfeSession = session;
      this.tracker = tracker;
      this.selectionContextModule = selectionContextModule;
      this.layoutManager = layoutManager;
      this.filters = filters;
      this.settingsData = settingsData;
      IntegerExpression flashTimeoutProperty = Fx.when(settingsData.cellFlashProperty()).then(settingsData.cellFlashTimeoutProperty())
         .otherwise(Fx.valueOf(0));
      this.priceTightnessProperty4MiniWatchlist = priceTightnessProperty4MiniWatchList;
      Fx.map(flashTimeoutProperty, asMillis);
   }

   private Callback<? super ObservableReplyRow, ? extends ObservableValue<? extends XfeAction>> referAction() {
      return row -> {
         XfeAction action = new XfeAction();
         Tuple2<String, String> secBoardGetter = row.getValue(AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId);
         ObservableList<ObservableReplyRow> openOrdersForSecBoard = xfeSession.orders.get().getOpenOrdersForSecBoard(secBoardGetter);
         ObservableList<ObservableReplyRow> orders = Fx.dynamicFilterByF(
            openOrdersForSecBoard,
            DynamicFilter.of(Filters.and(OrderFilters.clonedOrder.not(),xfeSession.getOrderFilters().isAmendable, OrderFilters.isStatusReferable)));
         action.availableProperty().bind(Bindings.not(Bindings.isEmpty(orders)));
         action.getStyleClass().add(CELL_STYLE_REFER);
         action.setText("R");
         action.setOnAction(actionEvent -> {
            for (ObservableReplyRow managedOrder : orders) {
               OrdersTrans.deactivate(xfeSession.getUnderlyingSession(), managedOrder.getAsn(AmpManagedOrder.currentOrderId), managedOrder.getValue(AmpManagedOrder.userId));
            }
         });

         return Fx.constOf(action);
      };
   }

   private Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> nImpliedCellAction(boolean isBid, BooleanProperty showingInfoPopups) {
      OrderSide orderSide = isBid ? OrderSide.BUY : OrderSide.SELL;
      return new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
         @Override
         public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
            ImpliedInfoPopup.doPopup(cell, xfeSession, layoutManager, row, orderSide, AmpOrderImpliedType.credit,
               AmpIcapSecBoardTrim2.nLevelPriceOn(orderSide), AmpIcapSecBoardTrim2.nLevelQuantityOn(orderSide), filters, showingInfoPopups);
         }
      };
   }

   private Fun1<ObservableReplyRow, ObservableBooleanValue> nImpliedCellActionAvailable(boolean isBid) {
      return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
         final AsnConversionAccessor<Double> impliedAccessor = isBid ? AmpIcapSecBoardTrim2.nLevelImpBidPrice_d : AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d;

         @Override
         public ObservableBooleanValue call(ObservableReplyRow row) {
            if (row == null) {
               return Fx.valueOf(false);
            }

            return RowFilters.notNull(impliedAccessor).accept(row);
         }
      };
   }

   private Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> impliedCellAction(
      boolean isBid,
      ObservableBooleanValue showingInfoPopups) {
      OrderSide orderSide = isBid ? OrderSide.BUY : OrderSide.SELL;

      return new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
         @Override
         public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
            ImpliedInfoPopup.doPopup(cell, xfeSession, layoutManager, row, orderSide, AmpOrderImpliedType.display, AmpIcapSecBoardTrim2.priceOn(orderSide),
               AmpIcapSecBoardTrim2.quantityOn(orderSide), filters, showingInfoPopups);
         }
      };
   }

   private Fun1<ObservableReplyRow, ObservableBooleanValue> impliedCellActionAvailable(boolean isBid) {
      DynamicFilter<ObservableReplyRow> filter = isBid ? InstrumentsFilters.isImpliedBid : InstrumentsFilters.isImpliedOffer;

      return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
         @Override
         public ObservableBooleanValue call(ObservableReplyRow row) {
            if (row == null) {
               return Fx.valueOf(false);
            }

            return filter.accept(row);
         }

      };
   }

   private Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> impliedComplexCellAction(
      boolean isBid,
      ObservableBooleanValue showingInfoPopups) {
      OrderSide orderSide = isBid ? OrderSide.BUY : OrderSide.SELL;

      return new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
         @Override
         public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {

            ObservableBooleanValue isImplied = impliedCellActionAvailable(isBid).call(row);

            if (isImplied.getValue() != null && isImplied.get()) {
               ImpliedInfoPopup.doPopup(cell, xfeSession, layoutManager, row, orderSide, AmpOrderImpliedType.display, AmpIcapSecBoardTrim2.priceOn(orderSide),
                  AmpIcapSecBoardTrim2.quantityOn(orderSide), filters, showingInfoPopups);
            } else {
               ImpliedInfoPopup.doPopup(cell, xfeSession, layoutManager, row, orderSide, AmpOrderImpliedType.credit,
                  AmpIcapSecBoardTrim2.nLevelPriceOn(orderSide), AmpIcapSecBoardTrim2.nLevelQuantityOn(orderSide), filters, showingInfoPopups);
            }
         }
      };
   }

   private Fun1<ObservableReplyRow, ObservableBooleanValue> impliedComplexCellActionAvailable(boolean isBid) {
      return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
         @Override
         public ObservableBooleanValue call(ObservableReplyRow row) {
         if (row == null) {
            return Fx.valueOf(false);
         }
         return filters.isImpliedComplex.call(row, isBid);
         }
      };
   }

   private <_S extends TableCellFactory<_S, ObservableReplyRow, T, U>, T, U extends TableCell<ObservableReplyRow, T>>
   TableCellFactory<_S, ObservableReplyRow, T, U> doubleClickHandler(
      TableCellFactory<_S, ObservableReplyRow, T, U> wrappedCellFactory) {
      return wrappedCellFactory.doubleClickHandler(clickHandler);
   }

   @SuppressWarnings("unused")
   private String shorten(UUID id) {
      String idString = id.toString();
      return String.format("%s...%s", idString.substring(0, 4), idString.substring(idString.length() - 4));
   }

   void toggleHighlight(InstrumentKey key, List<String> styleClass) {
      State state = toggledRowsHeight.get(key);
      styleClass.remove(INSTRUMENT_FULL_HIGHTLIGHT);
      styleClass.remove(INSTRUMENT_HALF_HIGHTLIGHT);
      if (state != null)
         switch (state) {
            case FINAL:
               styleClass.add(INSTRUMENT_FULL_HIGHTLIGHT);
               break;
            case INTERMEDIATE:
               styleClass.add(INSTRUMENT_HALF_HIGHTLIGHT);
               break;
         }
   }

   void toggleGhosts(String secCode, List<String> styleClass, boolean removing) {
      Fx.runLater(() -> styleClass.remove(OrdersColumns.REFERRED_ORDER_STYLE));
      if (!removing && priceTightnessGhosts.contains(secCode)) {
         Fx.runLater(() -> styleClass.add(OrdersColumns.REFERRED_ORDER_STYLE));
      }
   }

   private <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> cellSelect(
      Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory) {
      return column -> {
         U cell = wrappedCellFactory.call(column);
         // logger.debug("Creating rowSelect cell in column {} on tab {}",
         // column.getText(), shorten(tabId.get()));
         InvalidationListener cellSelectListener = new InvalidationListener() {
            void set() {
               if (!cell.getStyleClass().contains("table-cell-selected"))
                  cell.getStyleClass().add("table-cell-selected");
               cellSelectedPropertyOnNode.on(cell).setValue(true);
            }

            void clear() {
               cell.getStyleClass().remove("table-cell-selected");
               cellSelectedPropertyOnNode.on(cell).setValue(false);
            }

            void setRow() {
               if (!cell.getStyleClass().contains("table-row-cell-selected"))
                  cell.getStyleClass().add("table-row-cell-selected");
            }

            void clearRow() {
               cell.getStyleClass().remove("table-row-cell-selected");
            }

            @SuppressWarnings("rawtypes")
            @Override
            public void invalidated(Observable observable) {
               ObservableList<TablePosition> selectedCells = cell.getTableView().getSelectionModel().getSelectedCells();

               if (!selectedCells.isEmpty() && selectedCells.get(0).getRow() == cell.getIndex()) {
                  setRow();
                  if (selectedCells.get(0).getTableColumn() == cell.getTableColumn()) {
                     set();
                  } else {
                     clear();
                  }
               } else {
                  clearRow();
                  clear();
               }
            }
         };

         WeakInvalidationListener weakCellListener = new WeakInvalidationListener(cellSelectListener);
         cell.indexProperty().addListener(cellSelectListener);
         cell.tableViewProperty().addListener((obsTableView, oldTableView, newTableView) -> {
            if (oldTableView != null) {
               oldTableView.getSelectionModel().getSelectedCells().removeListener(weakCellListener);
            }

            if (newTableView != null) {
               newTableView.getSelectionModel().getSelectedCells().addListener(weakCellListener);
            }
         });

         return cell;
      };
   }

   private <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> cellSelectExpanded(
      Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory) {
      return wrappedCellFactory;
   }

   private <_S extends TableCellFactory<_S, ObservableReplyRow, T, U>, T, U extends TableCell<ObservableReplyRow, T>>
   TableCellFactory<_S, ObservableReplyRow, T, U> fingerPrint(
      boolean isBid,
      boolean isMiniWatchlist,
      TableCellFactory<_S, ObservableReplyRow, T, U> wrappedCellFactory
   ) {
      if(isBid) {
         return wrappedCellFactory.
            toggleStyle(MINE_STYLE, filters.isBestBidMine(isMiniWatchlist)).
            toggleStyle(SHARED_STYLE, filters.isBestBidMyFirm).
            toggleStyle(MINE_BROKER_STYLE, filters.isBestBidBroker);
      } else {
         return wrappedCellFactory.
            toggleStyle(MINE_STYLE, filters.isBestOfferMine(isMiniWatchlist)).
            toggleStyle(SHARED_STYLE, filters.isBestOfferMyFirm).
            toggleStyle(MINE_BROKER_STYLE, filters.isBestOfferBroker);
      }
   }

   public InstrumentKey createKey(UUID tabId, ObservableReplyRow row, boolean isRfq) {
      String secCode;
      String boardId;
      if (isRfq) {
         secCode = row.getValue(AmpRfq.secCode);
         boardId = row.getValue(AmpRfq.boardId);

      } else {
         secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
      }

      return InstrumentKey.create(tabId, secCode, boardId);
   }

   void toggleRowHighlight(InstrumentKey key, State highlightValue) {
      toggledRowsHeight.remove(key); //remove the key anyway to trigger the MapChangeListener event so that when the state updates, row factory will update the background color too.
      switch (highlightValue) {
         case INIT:
            logger.debug("{} is removed from highlight row", key);
            break;
         case INTERMEDIATE:
         case FINAL:
            logger.debug("{} is added in to highlight {} row", key, highlightValue);
            toggledRowsHeight.put(key, highlightValue);
      }
   }

   void setPriceTightnessGhost(String secCode, Boolean isGhost) {
      priceTightnessGhosts.remove(secCode);
      if (isGhost)
         priceTightnessGhosts.add(secCode);
   }

   void toggleRowHighlightOff() {

   }

   public State rowHighlightValue(InstrumentKey key) {
      State value = toggledRowsHeight.get(key);
      if (value == null) {
         return State.INIT;
      } else
         return value;
   }

   void disableFlash(String instrCode, String boardId) {
      if (xfeSession.rfqs.isInitialized() && xfeSession.rfqs.get().isRfqInFinalPhase(instrCode, boardId)) {
         logger.debug("code {}, boardId {} is added into flashDisabledSet", instrCode, boardId);
         flashDisabledSet.add(instrCode);
      }
   }

   private ObservableValue<Boolean> isSecFlashDisabled(String instrCode) {
      return new BooleanBinding() {
         {
            bind(flashDisabledSet);
         }
         @Override
         protected boolean computeValue() {
            return flashDisabledSet.contains(instrCode);
         }
      };
   }

   void enableFlash(String instrCode, String boardId) {
      logger.debug("code {}, boardId {} is removed from flashDisabledSet", instrCode, boardId);
      flashDisabledSet.remove(instrCode);
   }

   void setDoubleClickHandler(Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> cellAction) {
      this.clickHandler = cellAction;
   }

   public TableColumn<ObservableReplyRow, String> createColumn(AsnAccessor accessor, String columnHeader, String style) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(asnStringCell(accessor)
         .style(style)
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic())).setCellFactoryIn(col);
      col.setText(columnHeader);
      col.setResizable(false);
      return col;
   }

   public TableColumn<ObservableReplyRow, String> createRfqInitiatorCol() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(asnStringCell(AmpRfq.userId,AmpRfq.isAnonymous)
         .style("xfe-type-cell")
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic())).setCellFactoryIn(col);
      col.setText("Initiator");
      col.setResizable(false);
      return col;
   }

   public TableColumn<ObservableReplyRow, Date> createRfqStartTimeCol() {
      TableColumn<ObservableReplyRow, Date> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, Date>, DynamicTableCell<ObservableReplyRow, Date>> cell =
         DynamicTableCell.converterCell(AsnValueFactory.asValue(AmpRfq.startTime), RfqColumns.RfqBeginTimeConverter);

      TableCellFactory.of(cell)
         .style("xfe-type-cell")
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Begin");
      col.setPrefWidth(55);
      col.setResizable(false);
      return col;
   }

   public TableColumn<ObservableReplyRow, Date> createRfqStartBespokedCol() {
      TableColumn<ObservableReplyRow, Date> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, Date>, DynamicTableCell<ObservableReplyRow, Date>> cell =
         DynamicTableCell.converterCell(AsnValueFactory.asValue(AmpRfq.bespokeIssueDate), RfqColumns.RfqDateConverter);

      TableCellFactory.of(cell)
         .style("xfe-type-cell")
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Start");
      col.setPrefWidth(70);
      col.setResizable(false);
      return col;
   }

   public TableColumn<ObservableReplyRow, Date> createRfqMatBespokedCol() {
      TableColumn<ObservableReplyRow, Date> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, Date>, DynamicTableCell<ObservableReplyRow, Date>> cell =
         DynamicTableCell.converterCell(AsnValueFactory.asValue(AmpRfq.bespokeMaturityDate), RfqColumns.RfqDateConverter);

      TableCellFactory.of(cell)
         .style("xfe-type-cell")
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Maturity");
      col.setPrefWidth(70);
      col.setResizable(false);
      return col;
   }


   public TableColumn<ObservableReplyRow, String> createRfqRemainingtimeCol() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(asnStringCell(AmpRfq.endTime,xfeSession.getUnderlyingSession().teClock)
         .style("xfe-type-cell")
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .flashStyle()
         .toggleStyle(NodeFlashDecorator.FLASH_TOKEN, xfeSession.getColumnsUtil().flashOnLastMinute(AmpRfq.endTime,REMAINING_TIME_TO_FLASH))
         .toggleStyle("rfq-ending-style", xfeSession.getColumnsUtil().flashOnLastMinute(AmpRfq.endTime,REMAINING_TIME_TO_FLASH))
         .basic())).setCellFactoryIn(col);
      col.setText("Remain");
      col.setPrefWidth(45);
      col.setResizable(false);
      return col;
   }

   public TableColumn<ObservableReplyRow, String> createRfqInitiatorFirmCol() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(asnStringCell(AmpRfq.groupId,AmpRfq.isAnonymous)
         .style("xfe-type-cell")
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic())).setCellFactoryIn(col);
      col.setText("Firm");
      col.setResizable(false);
      return col;
   }

   public TableColumn<ObservableReplyRow, Integer> createRfqRequestCol() {
      TableColumn<ObservableReplyRow, Integer> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, Integer>, DynamicTableCell<ObservableReplyRow, Integer>> cell =
         DynamicTableCell.converterCell(AsnValueFactory.asValue(AmpRfq.buySell), RfqColumns.RfqBuySellConverter);

      TableCellFactory.of(cell)
         .style("xfe-type-cell")
         .toggleStyle(SELL_STYLE, InstrumentsFilters.isRfqBid) // we're displaying 'offer' for buy and 'bid' for sell (74201)
         .toggleStyle(BUY_STYLE, InstrumentsFilters.isRfqOffer)
         .toggleStyle(BUYSELL_STYLE, InstrumentsFilters.isRfqBoth)
         .doubleClickHandler(clickHandler)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Req");
      col.setPrefWidth(35);
      col.setResizable(false);
      return col;
   }

   public TableColumn<ObservableReplyRow, String> createRfqInstrumentColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(cellSelect(
         asnStringCell(AmpRfq.parentSecCode)
            .strong()
            .textTooltip()
            .basic())).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR);
      col.setPrefWidth(InstrumentsPane.COLUMN_SECCODE_SIZE);
      col.setResizable(false);
      return col;
   }

   void addListenerToToggleRowHeight(MapChangeListener<InstrumentKey, State> hightlightKeyLis) {
      tracker.addListener(toggledRowsHeight,hightlightKeyLis);
   }
}
