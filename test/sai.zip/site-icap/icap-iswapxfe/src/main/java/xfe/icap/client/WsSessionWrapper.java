package xfe.icap.client;

import xstr.session.Credentials;
import xstr.session.XstrClientConfig;
import xstr.util.concurrent.Future;

public class WsSessionWrapper extends IcapWebSession {
//   private static final Logger logger = LoggerFactory.getLogger(WsSessionWrapper.class);

   public WsSessionWrapper(XstrClientConfig config) {
      super(config);
   }

   @Override
   public boolean isWebConnection() {
      return true;
   }

   @Override
   public Future<? extends XstrWebConnection> connect(Credentials cred) {
      return XstrWsConnection.connect(cred, this);
   }

}
