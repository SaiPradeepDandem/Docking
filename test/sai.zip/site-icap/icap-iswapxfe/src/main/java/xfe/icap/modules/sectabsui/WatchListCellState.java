package xfe.icap.modules.sectabsui;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Specifies different states of a cell(style) which can be in.
 */
public enum WatchListCellState {
   NONE(""),
   MY_CLOB_ORDER("xfe-my-order"),
   MY_CM_ORDER("xfe-my-cm-orders"),
   FIRM_CLOB_ORDER("xfe-firm-order"),
   FIRM_CM_ORDER("xfe-firm-cm-orders"),
   WORKUP_CLOB_ORDER("xfe-workup-order"),
   WORKUP_CM_ORDER("xfe-cm-workup-order"),
   CLOB_PRICE_CHANGE_FLASHING("xfe-clob-price-flashing"),
   CM_PRICE_CHANGE_FLASHING("xfe-cm-price-flashing"),
   IN_EDIT_PENDING("inedit-pending"),
   CM_TRADE("xfe-cm-trades");

   private String style;

   WatchListCellState(String style) {
      this.style = style;
   }

   public String getStyle() {
      return style;
   }

   /**
    * Returns all state styles to clear while resetting the cell.
    *
    * @return List of cell state styles
    */
   public static List<String> getAllStyles() {
      List<String> allStyles = new ArrayList<>();
      Stream.of(WatchListCellState.values()).filter(state -> state != NONE)
         .forEach(state -> allStyles.add(state.getStyle()));
      return allStyles;
   }
}
