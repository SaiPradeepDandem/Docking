package xfe.icap.modules.obbo;

import com.nomx.persist.linelist.Participant;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import com.omxgroup.xstream.amp.AmpRFQStatus;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TablePosition;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.text.TextAlignment;
import javafx.util.Callback;
import javafx.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.*;
import xfe.icap.amp.Util;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xfe.icap.types.OrderBook;
import xfe.icap.types.OrderBook.OrderBookKey;
import xstr.types.OrderSide;
import xstr.util.*;
import xstr.util.concurrent.Future;
import xfe.util.scene.control.DecoratedTitledPane;
import xfe.util.scene.control.SelectionTracker;
import xfe.icap.XfeSession;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.layout.FxAbstractLayout;
import xfe.layout.LayoutManager;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.SettingsUIModule;
import xfe.icap.modules.watchlist.WatchlistModule;
import xfe.icap.ui.RfqTimerPane;
import xfe.ui.notifications.ModalAlertModule;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Module.Autostart
public class ObboModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(ObboModule.class);

   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public DataContextModule dataContextModule;
   @ModuleDependency
   public ModalAlertModule modalAlertModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public SettingsUIModule settingsUIModule;
   @ModuleDependency
   public LayoutManager<Node> layoutManagerModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public WatchlistModule watchlistModule;

   private static boolean isObboSelected(GridType gridType){
      return gridType==GridType.OBBO_BUY || gridType==GridType.OBBO_SELL;
   }

   public OrderBook getOrderBook() {
      return orderBook;
   }

   String getCurrentSecCode(){
      return secNameProp.get();
   }

   String getCurrentBoardId(){
      return boardIdProp.get();
   }

   public Callback<Pair<Boolean, Integer>, Void> getSweepObboClickClbk() {
      return sweepObboClickClbk;
   }

   public void setSweepObboClickClbk(Callback<Pair<Boolean, Integer>, Void> callback) {
      sweepObboClickClbk = callback;
   }

   boolean isAllowNewDepthPopup(){
      return openedDepth.size()<10;
   }

   public ListenerTracker getTracker() {
      return tracker;
   }

   public void setSweepObboDragClbk(Callback<Pair<Boolean, Integer>, Void> callback) {
      sweepObboDragClbk = callback;
   }

   void setPickupPrice(double price){
      pickupPrice.setValue(price);
   }

   void setPickupQuantity(double quantity){
      pickupQuantity.setValue(quantity);
   }

   @Override
   public Future<Void> startModule() {
      applyAutoAcceptFilter = Bindings.and(settingsUIModule.getData().hideNonAutoAcceptProperty(), dataContextModule.dataContextRfsOrRfqSec);
      if (obboPane == null) {
         tracker.addListener(selectionContextModule.gridTypeProperty.get(), (_0, _1, newGridType) -> {
            //temporaryModeProperty.set(false);
            if (!SelectionTracker.breadcrumbs.getTrail().contains(SelectionTracker.RESTORING_SELECTION)) {
               if (newGridType == GridType.OBBO_BUY) {
                  sideProperty.set(OrderSide.BUY);
               } else if (newGridType == GridType.OBBO_SELL) {
                  sideProperty.set(OrderSide.SELL);
               }
            }
         });

         orderBook = new OrderBook(xfeSessionModule, this);
         obboTable = new IndependentObboTablePanel(xfeSessionModule, modalAlertModule, orderBook, this);
         tracker.bind(obboTable.bidOnLeftProperty(), settingsUIModule.getData().bidOnLeftProperty());
         obboTable.arrangeGrid();
         tracker.addListener(obboTable.bidOnLeftProperty(), observable -> {
            obboTable.arrangeGrid();
         });
         tracker.disposes(Fx.addListener(selectionContextModule.selectionContextProperty(), selectedGridListener));

         tracker.disposes(Fx.addListener(sessionNameProp, sessionNameListener));
         tracker.disposes(Fx.addListener(workupPriceProp, workupPriceListener));

         StackPane stackPane = new StackPane();
         stackPane.getChildren().addAll(obboTable.getContentNode());
         InvalidationListener selectedTraderLis = observable -> {
            Participant par = xfeSessionModule.onBehalfTrader.get();
            String text = par == null ? "" : par.getId();
            OnbehalfTraderLabel.textProperty().set(text);
         };
         tracker.addListener(xfeSessionModule.onBehalfTrader, selectedTraderLis);
         Fx.runLater(()->selectedTraderLis.invalidated(null));
         obboPane = new DecoratedTitledPane("Depth", stackPane,false, layoutModule,true,true);
         obboPane.blockMouseDragEvent = false;
//         obboPane.getDecoratedTitledPaneSkin().getTitleButton().getStyleClass().add("disabled-look-title-button");
         obboPane.setId("xfe-depth-view");
         obboPane.getStyleClass().add("xfe-iswap-pane");
         tracker.bindBidirectional(obboPane.sizeProperty(), settingsUIModule.getData().marketDepthHeightProperty());
         tracker.bindBidirectional(obboPane.expandProperty(), settingsUIModule.getData().marketDepthExpandProperty());
         obboPane.displayProperty().set(true);
         setTitledPaneSpring();
         layoutModule.addView(obboPane);

         tracker.bind(sessionNameProp, selectionContextModule.secBoardContext.get().sessionNameProperty());
         tracker.bind(workupPriceProp, selectionContextModule.secBoardContext.get().workupPriceProperty());
         if(xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker()){
            tracker.addListener(xfeSessionModule.getUnderlyingSession().onBehalfTraderId, observable -> {
               if (xfeSessionModule.getUnderlyingSession().isLoggedOn()) {
                  String onBehalfOfTrader = xfeSessionModule.getUnderlyingSession().onBehalfTraderId.get();
                  OrderBookKey key = orderBook.getKey();
                  if (key != null) {
                     orderBook.setKey(new OrderBookKey(key.getSecCode(), key.getBoardId(), onBehalfOfTrader, null));
                  } else {
                     orderBook.setKey(null);
                     setOrderBookAttributes(null, null, "", false);
                  }
               }
            });
         }

         tracker.addListener(orderBook.bidSide.orders, (Observable arg0) -> {
            if ((manualSelect.get() != null) &&
               (orderBook.bidSide.orders.size() == (manualSelect.get().getValue() + 1)) &&
               manualSelect.get().getKey()) {

               Integer rowToSelect = manualSelect.get().getValue();
               manualSelect.set(null);
               Fx.runLater(() -> obboTable.selectRow(true, rowToSelect));
            }
         });

         tracker.addListener(orderBook.offerSide.orders, (Observable arg0) -> {
            if ((manualSelect.get() != null) &&
               (orderBook.offerSide.orders.size() == (manualSelect.get().getValue() + 1)) &&
               !manualSelect.get().getKey()) {
               Integer rowToSelect = manualSelect.get().getValue();
               manualSelect.set(null);
               Fx.runLater(() -> obboTable.selectRow(false, rowToSelect));
            }
         });

         tracker.addListener(xfeSessionModule.onBehalfTrader, observable -> {
            if (xfeSessionModule.getUnderlyingSession().isLoggedOn()) {
               String onBehalfOfTrader = xfeSessionModule.onBehalfTrader.get() == null ? null : xfeSessionModule.onBehalfTrader.get().getId();
               OrderBookKey key = orderBook.getKey();
               if (key != null) {
                  orderBook.setKey(new OrderBookKey(key.getSecCode(), key.getBoardId(), onBehalfOfTrader, null));
               } else {
                  orderBook.setKey(null);
                  setOrderBookAttributes(null, null, "", false);
               }
            }
         });
      }
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      // create a new property to allow listeners of secName to be gc'd
      applyAutoAcceptFilter = null;
      titleNameProp = new SimpleStringProperty("");
      secNameProp = new SimpleStringProperty("");
      boardIdProp = new SimpleStringProperty("");
      if (obboPane != null) {
         obboPane.dispose();
         obboTable.dispose();
         tracker.rollback();
         orderBook = null;
         obboTable = null;
         layoutModule.removeView(obboPane);
         obboPane = null;
      }
      cancelCountDown();

      try {
         Object[] stages = openedDepth.values().toArray();
         for(Object obj:stages){
            ((ObboStage)obj).dispose();
         }
      } finally{
         openedDepth.clear();
      }

      return Future.SUCCESS;
   }

   public void addSweepBtn(ToggleButton sweepBtn) {
      this.obboPane.insertNode2RightButtonArea(0, sweepBtn);
   }

   public void removeSweepBtn(ToggleButton sweepBtn) {
      this.obboPane.removeNode2RightButtonArea(sweepBtn);
   }

   public void highlightTo(boolean obboSideIsBuy, int toRow) {
      obboTable.highlightTo(obboSideIsBuy, toRow);
   }

   void setOrderBookAttributes(String secCode,
                               String boardId,
                               String titleName,
                               boolean setKey) {
      titleNameProp.set(titleName);
      secNameProp.set(secCode);
      boardIdProp.set(boardId);

      if (setKey)
         orderBook.setKey(new OrderBookKey(secCode,
            boardId,
            xfeSessionModule.onBehalfTrader.get() == null ? null : xfeSessionModule.onBehalfTrader.get().getId(), null));
   }

   Void dragObboRows(Boolean side, Integer numRows) {
      if (sweepObboDragClbk != null) {
         sweepObboDragClbk.call(new Pair<>(side, numRows));
      }

      return null;
   }

   Void clickObboRow(Boolean side, Integer rowIndex) {
      if (sweepObboClickClbk != null) {
         return sweepObboClickClbk.call(new Pair<>(side, rowIndex));
      }

      return null;
   }

   void selectRow(boolean obboSideIsBuy, int rowIndex) {
      manualSelect.set(new Pair(obboSideIsBuy, rowIndex));
      Fx.runLater(() -> obboTable.selectRow(obboSideIsBuy, rowIndex));
   }

   ObboStage createPopupStage(MouseEvent mouseEvent){
      try {
         String key = secNameProp.get() + "~" +boardIdProp.get();
         ObboStage stage  = openedDepth.get(key);
         if(stage == null) {
            stage = new ObboStage(layoutManagerModule, xfeSessionModule, this, secNameProp.get() ,boardIdProp.get(), watchlistModule , openedDepth,key, mouseEvent);
            openedDepth.put(key, stage);
         }
         stage.toFront();
         return stage;
      } catch (Exception e) {
         logger.error("can't create depth popup, due to "+e.getMessage(),e);
         return null;
      }
   }

   private synchronized void createTimerForRfq(ObservableReplyRow rfqRow, String secCode, String boardId){
      TeClock teClock = xfeSessionModule.getUnderlyingSession().teClock;
      teClock.removeTask(rfqInitiateStageTimerTask);
      teClock.removeTask(rfqFinalStageTimerTask);
      //sessionName
      ObservableValue<Date> endTimeProp = rfqRow.getProperty(AmpRfq.endTime);
      Date endTime = endTimeProp.getValue();
      ObservableValue<Integer> rfqStatusProp = rfqRow.getProperty(AmpRfq.status);

      if(!titleBoxChildren.contains(rfqInstrRootNode)){
         titleBoxChildren.add(rfqInstrRootNode);
      }

      rfqInstr.setVisible(true);
      rfqInitiateStageTimerTask = new TickTask("rfq_"+secCode+"_countdown", () ->{
         long endingTimeInsecond = (endTimeProp.getValue().getTime() - teClock.get().getTime())/1000;
         rfqInstr.setText(endingTimeInsecond,rfqStatusProp.getValue());
      },
         () -> {
            rfqInstr.clearText();
            rfqInstr.setVisible(false);
            titleBoxChildren.remove(rfqInstrRootNode);
         },
         endTime);
      logger.debug("rfq {} end time for initial stage is {}", secCode, endTime);

      teClock.addTickTask(rfqInitiateStageTimerTask);

      tracker.addListener(rfqStatusProp, new ChangeListener<Integer>() {

         @Override
         public void changed(ObservableValue<? extends Integer> observable, Integer oldState, Integer newState) {
            if (secCode.equals(secNameProp.getValue()) && boardId.equals(boardIdProp.getValue())) {
               if (newState == AmpRFQStatus.active) {
                  teClock.removeTask(rfqInitiateStageTimerTask);
                  String msg = titleNameProp.get() + " Ending";
                  rfqInstr.instrTextProperty().set(msg);
                  Date endTime2 = rfqRow.getValue(AmpRfq.endTime);
                  if (!titleBoxChildren.contains(rfqInstrRootNode)) {
                     titleBoxChildren.add(rfqInstrRootNode);
                  }
                  rfqInstr.visibleProperty().set(true);
                  teClock.removeTask(rfqFinalStageTimerTask);
                  rfqFinalStageTimerTask = new TickTask(msg,
                     ()->{
                        long endingTimeInsecond = (endTime2.getTime() - teClock.get().getTime()) / 1000;
                        rfqInstr.setText(endingTimeInsecond,rfqStatusProp.getValue());},
                     () -> rfqInstr.visibleProperty().set(true),
                     endTime2);

                  logger.debug("rfq {} end time for final stage is {}", secCode , endTime2);

                  teClock.addTickTask(rfqFinalStageTimerTask);
               }
               if (newState == AmpRFQStatus.finished || newState == AmpRFQStatus.cancelled) {
                  rfqStatusProp.removeListener(this);
                  teClock.removeTask(rfqFinalStageTimerTask);
                  rfqInstr.clearText();
                  rfqInstr.visibleProperty().set(false);
               }
               if (newState != AmpRFQStatus.initial && newState != AmpRFQStatus.active) {
                  rfqStatusProp.removeListener(this);
               }
            } else {
               rfqStatusProp.removeListener(this);
            }
         }

      });

   }

   private synchronized void  cancelCountDown() {
      if(rfqFinalStageTimerTask!=null){
         rfqFinalStageTimerTask.setStop();
         rfqFinalStageTimerTask = null;
      }
      if(rfqInitiateStageTimerTask!=null){
         rfqInitiateStageTimerTask.setStop();
         rfqInitiateStageTimerTask = null;
      }

      titleBoxChildren.remove(rfqInstrRootNode);
      //rfqInstr.visibleProperty().set(false);
   }

   private void setTitledPaneSpring() {
      titleBox.getStyleClass().add("xfe-depth-label");
      titleBox.setAlignment(Pos.CENTER);
      rfqInstr.visibleProperty().set(true);
      Label secNameLabel = new Label(){
         {
            HBox.setHgrow(this, Priority.ALWAYS);
            this.setTextAlignment(TextAlignment.RIGHT);
         }
      };
      rfqInstrRootNode.setVisible(false);
      titleBoxChildren.setAll(OnbehalfTraderLabel,rfqInstrRootNode,secNameLabel);
      // This is a hack but it seems to get it in the center
      obboPane.setHeaderSpring(titleBox);
      secNameLabel.textProperty().bind(titleNameProp);
   }

   private void selectRfsSessionRow(SelectionContext oldVal) {
      ObservableReplyRow obboRow = oldVal.row;
      TablePosition tablePosition = oldVal.tablePosition;
      GridType grid = oldVal.grid;
      logger.trace("selectRfsSessionRow called for obboRow {}, gridType {}, tablePosition {}",
         obboRow, grid, tablePosition);
      doSelection(obboRow, grid, tablePosition);
   }

   private void doSelection(ObservableReplyRow obboRow, GridType grid, TablePosition tablePosition) {
      obboTable.selectRow(grid == GridType.OBBO_BUY, obboRow, tablePosition, logger);
   }
   public final ObjectProperty<OrderSide> sideProperty = new SimpleObjectProperty<>();
   public final ObjectProperty<Pair<Boolean, Integer>> manualSelect = new SimpleObjectProperty<>();
   private final StringProperty sessionNameProp = new SimpleStringProperty("");
   private final ObjectProperty<BigDecimal> workupPriceProp = new SimpleObjectProperty<>();
   private final DoubleProperty pickupPrice = new SimpleDoubleProperty(Double.MIN_VALUE);
   private final DoubleProperty pickupQuantity = new SimpleDoubleProperty(Double.MIN_VALUE);
   private final BooleanProperty priceEntryNeedFocus = new SimpleBooleanProperty(false);
   private final ListenerTracker tracker = new ListenerTracker();
   private final RfqTimerPane rfqInstr = RfqTimerPane.load(false) ;
   private final Node rfqInstrRootNode = rfqInstr.getRootElement();
   private final Label OnbehalfTraderLabel = new Label(){{
      this.getStyleClass().add("xfe-orderentry-inst-name");
      StackPane.setAlignment(this, Pos.CENTER_LEFT);
   }};
   private final DragAndPopupHBox titleBox= new DragAndPopupHBox(this){{
      StackPane.setAlignment(rfqInstrRootNode,Pos.CENTER_RIGHT);
      StackPane.setAlignment(OnbehalfTraderLabel,Pos.CENTER_LEFT);
   }};
   private final ObservableList<Node> titleBoxChildren = titleBox.getChildren();
   private final Map<String,ObboStage> openedDepth = new ConcurrentHashMap<>(16);
   public StringProperty secNameProp = new SimpleStringProperty("");
   public ObjectProperty<Double> updatedPrice = new SimpleObjectProperty<>();
   public ObjectProperty<Double> rfsPriceOverride  = new SimpleObjectProperty<>();
   public ObjectProperty<Double> rfsQtyOverride  = new SimpleObjectProperty<>();
   public ReadOnlyDoubleProperty readOnlyPickupPrice = pickupPrice;
   public ReadOnlyDoubleProperty readOnlyPickupQuantity = pickupQuantity;
   public ReadOnlyBooleanProperty readonlyPriceEntryNeedFocus  = priceEntryNeedFocus;
   public BooleanBinding applyAutoAcceptFilter ;
   boolean loading;
   private OrderBook orderBook;
   private StringProperty boardIdProp = new SimpleStringProperty("");
   private StringProperty titleNameProp = new SimpleStringProperty("");
   private final ChangeListener<String> sessionNameListener = new ChangeListener<String>() {
      @Override
      public void changed(ObservableValue<? extends String> arg0,
                          String oldSessionName,
                          String newSessionName) {
         String fullSecCodeName = secNameProp.get();
         if (newSessionName != null && (newSessionName.equals("Public") || newSessionName.equals("Private"))) {
            BigDecimal workupPrice = selectionContextModule.secBoardContext.get().workupPriceProperty().getValue();
            String workupPriceStr = workupPrice == null ? "" : " " + workupPrice;
            fullSecCodeName += " " + newSessionName + " Workup" + workupPriceStr;
         }
         titleNameProp.set(fullSecCodeName);
      }
   };
   private final ChangeListener<BigDecimal> workupPriceListener = new ChangeListener<BigDecimal>() {
      @Override
      public void changed(ObservableValue<? extends BigDecimal> arg0,
                          BigDecimal oldWorkupPrice,
                          BigDecimal newWorkupPrice) {
         String fullSecCodeName = secNameProp.get();
         if (newWorkupPrice != null) {
            String sessionName = selectionContextModule.secBoardContext.get().sessionNameProperty().getValue();
            if (sessionName != null && (sessionName.equals("Public") || sessionName.equals("Private")))
               fullSecCodeName += " " + sessionName + " Workup " + newWorkupPrice;
         }

         titleNameProp.set(fullSecCodeName);
      }
   };
   private Callback<Pair<Boolean, Integer>, Void> sweepObboDragClbk;
   private Callback<Pair<Boolean, Integer>, Void> sweepObboClickClbk;
   private DecoratedTitledPane obboPane;
   private IndependentObboTablePanel obboTable;
   private TickTask rfqInitiateStageTimerTask;
   private TickTask rfqFinalStageTimerTask;
   private final ChangeListener<SelectionContext> selectedGridListener = new ChangeListener<SelectionContext>() {
      @Override
      public void changed(
         ObservableValue<? extends SelectionContext> observableVal,
         SelectionContext oldVal,
         SelectionContext newVal) {
         logger.trace("selected grid changed from:\n{} to \n{}",oldVal, newVal);
         obboTable.setSelectedGrid(newVal.grid);
         pickupPrice.setValue(Double.MIN_VALUE);
         switch(newVal.grid) {
            case Watchlist:
               if (newVal.row != null) {
                  cancelCountDown();
                  String secCode = newVal.row.getValue(AmpIcapSecBoardTrim2.secCode);
                  String boardId  = newVal.row.getValue(AmpIcapSecBoardTrim2.boardId);
                  BigDecimal workupPrice = workupPriceProp.get();
                  String sessionName = sessionNameProp.get();

                  String fullSecCodeName = secCode;
                  if (sessionName != null && (sessionName.equals("Private") || sessionName.equals("Public"))) {
                     String workupPriceStr = workupPrice == null ? "" : " " + workupPrice;
                     fullSecCodeName += " " + sessionName + " Workup" + workupPriceStr;
                  }

                  setOrderBookAttributes(secCode, boardId, fullSecCodeName, false);

                  ObservableReplyRow rfqRow = xfeSessionModule.rfqs.get().isActiveRfq(secCode,boardId);
                  if (rfqRow != null) {
                     createTimerForRfq(rfqRow, secCode, boardId);
                  }
                  boolean reselect = false;

                  // user select an OBBO row then initiate an RFS, the new created rfq will be automatically selected in watchlist, which is why this code is being triggered.
                  // if previous selection is on obbo and it is an rfs session, we want the previous selected obbo row be reselected.
                  if (oldVal != null && isObboSelected(oldVal.grid) && rfqRow != null) {
                     String previousObboSecCode = Util.getSecCodeFromObboReplyRow(oldVal.row);
                     String previousObboBoardId = Util.getBoardIdFromObboReplyRow(oldVal.row);
                     logger.trace("Checking for obbo reselection for {}", previousObboSecCode);
                     if (previousObboBoardId.equals(rfqRow.getString(AmpRfq.parentBoardId)) &&
                        previousObboSecCode.equals(rfqRow.getString(AmpRfq.parentSecCode))) {

                        rfsPriceOverride.setValue(oldVal.row.getValue(AmpOrderBookByOrder.price));
                        rfsQtyOverride.setValue(oldVal.row.getValue(AmpOrderBookByOrder.quantity));

                        logger.trace("Reselecting {} in obbo", oldVal);
                        reselect = true;
                     }
                  }

                  orderBook.getReselectProperty().addListener((observable, oldValue, newValue) -> {
                     if (newValue != null && newValue == oldVal) {
                        selectRfsSessionRow(oldVal);
                     }
                  });

                  orderBook.setKey(new OrderBookKey(secCode,
                     boardId,
                     xfeSessionModule.onBehalfTrader.get() == null ?
                        null :
                        xfeSessionModule.onBehalfTrader.get().getId(),
                     reselect ? oldVal: null));
               }
               break;
            case Rfq:
               ObservableReplyRow rfqRow = newVal.row;
               if(rfqRow!=null){
                  String secCode = rfqRow.getValue(AmpRfq.secCode);
                  String boardId = rfqRow.getValue(AmpRfq.boardId);
                  String size = rfqRow.getString(AmpRfq.maxQuantity);
                  OrderBookKey key = new OrderBookKey(secCode,
                     boardId,
                     xfeSessionModule.onBehalfTrader.get() == null ? null : xfeSessionModule.onBehalfTrader.get().getId(),
                     null);
                  key.setNeedBestPrice(true);
                  orderBook.setKey(key);
                  setOrderBookAttributes(secCode, boardId, secCode + " size: " + size, false);
                  createTimerForRfq(newVal.row, secCode, boardId);
                  Integer buysell = rfqRow.getValue(AmpRfq.buySell);
                  watchlistModule.retrieveSecBoardTrim2(boardId,secCode).map(new Fun1Throws<QueryReplyRow, Void>() {
                     @Override
                     public Void call(QueryReplyRow row) {
                        Double price;
                        if (AmpOrderVerb.buy==buysell) {
                           price = row.getValue(AmpIcapSecBoardTrim2.bidPrice_d);
                        } else {
                           price = row.getValue(AmpIcapSecBoardTrim2.offerPrice_d);
                        }
                        pickupPrice.set(price == null ? 0D : price);
                        logger.debug("get best price for rfq instrument {}, return {}",secCode,price);
                        priceEntryNeedFocus.setValue(!priceEntryNeedFocus.get());
                        return null;
                     }
                  }).onError(e -> {
                     logger.error("can't get best price for " + secCode);
                     return null;
                  });
               }else{
                  orderBook.setKey(null);
                  setOrderBookAttributes(null, null, "", false);
               }
               break;
            case Orders:
               if (newVal.row != null) {
                  String secCode = newVal.row.getValue(AmpManagedOrder.secCode);
                  String boardId = newVal.row.getValue(AmpManagedOrder.boardId);
                  setOrderBookAttributes(secCode,
                     boardId,
                     secCode,
                     true);
               }
               break;
            default:
               break;
         }

      }

   };
}
