package xfe.icap.modules.tradesui;

import com.nomx.persist.watchlist.ColumnSpec;
import com.nomx.persist.watchlist.ColumnsSpec;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.VBox;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.toolbar.actions.InstrumentCell;
import xfe.icap.modules.toolbar.actions.TradesAggregatePopupSource;
import xfe.icap.ui.table.TableCellUtil;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.types.SecBoardStaticInfo;
import xfe.ui.table.AlignedTableColumn;
import xfe.ui.table.ConfigurableTableView;
import xfe.ui.table.Tables;
import xfe.ui.table.XfeActionCell;
import xfe.util.Util;
import xfe.util.XfeAction;
import xstr.session.ObservableReplyRow;
import xstr.types.DealStatus;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.Date;
import java.util.function.*;

class TradesViewTable extends ConfigurableTableView<ObservableReplyRow> implements TradesAggregatePopupSource {

   TradesViewTable() {
      setId("trades-deals-view-table");
      setPlaceholder(Tables.stripedRowCSSPlaceholder());
      getStyleClass().add("trades-view-table");
      initializeTableColumns();
      setColumnResizePolicy(CONSTRAINED_RESIZE_POLICY);
   }

   void setTradeAgreeFactory(Function<ObservableReplyRow, ObservableValue<XfeAction>> tradeAgreeValueFactoryImpl) {
      this.tradeAgreeFactory = tradeAgreeValueFactoryImpl;
   }

   void setSideFactory(Function<ObservableReplyRow, ObservableValue<OrderSide>> sideColFactoryImpl) {
      this.sideColFactory = sideColFactoryImpl;
   }

   void setTypeFactory(Function<ObservableReplyRow, ObservableValue<String>> typeColFactoryImpl) {
      this.typeColFactory = typeColFactoryImpl;
   }

   void setStatusFactory(Function<ObservableReplyRow, ObservableValue<String>> statusColFactoryImpl) {
      this.statusColFactory = statusColFactoryImpl;
   }

   void setCommTypeFactory(Function<ObservableReplyRow, ObservableValue<String>> commTypeColFactoryImpl) {
      this.commTypeColFactory = commTypeColFactoryImpl;
   }

   void setNetValueFactory(Function<ObservableReplyRow, ObservableValue<BigDecimal>> netValueFactoryImpl) {
      this.netValueColFactory = netValueFactoryImpl;
   }

   void setTraderFactory(Function<ObservableReplyRow, ObservableValue<String>> traderColFactoryImpl) {
      this.traderColFactory = traderColFactoryImpl;
   }

   void setTradeRefFactory(Function<ObservableReplyRow, ObservableValue<String>> extTradeRefColFactoryImpl) {
      this.extTradeRefColFactory = extTradeRefColFactoryImpl;
   }

   void setBrokerFactory(Function<ObservableReplyRow, ObservableValue<String>> brokerColFactoryImpl) {
      this.brokerColFactory = brokerColFactoryImpl;
   }

   private void initializeTableColumns() {
      // When column label is empty or duplicated, you need to define SETTING_TEXT property.
      final TableColumn<ObservableReplyRow, String> extTradeRef = new AlignedTableColumn<>("Ext Trade Ref");
      extTradeRef.setId("exttraderef-tablecolumn");
      extTradeRef.setCellValueFactory(param -> extTradeRefColFactory.apply(param.getValue()));
      extTradeRef.setCellFactory(p -> new TableCellUtil.StringCell());
      extTradeRef.setMinWidth(110);

      final TableColumn<ObservableReplyRow, Date> time = new AlignedTableColumn<>("Time", HPos.RIGHT);
      time.setId("time-tablecolumn");
      time.setCellValueFactory(cd -> cd.getValue().getProperty(AmpTrade.time));
      time.setCellFactory(param -> new TableCellUtil.TimeCell());
      time.setMinWidth(65);

      final TableColumn<ObservableReplyRow, OrderSide> side = new AlignedTableColumn<>("B/S");
      side.setId("side-tablecolumn");
      side.setCellValueFactory(param -> sideColFactory.apply(param.getValue()));
      side.setCellFactory(p -> new TableCellUtil.BuySellCell());
      side.setMinWidth(50);

      final TableColumn<ObservableReplyRow, BigDecimal> total = new AlignedTableColumn<>("Total");
      total.setId("total-tablecolumn");
      total.setCellValueFactory(cd -> cd.getValue().getProperty(AmpTrade.quantity));
      total.setMinWidth(80);

      final TableColumn<ObservableReplyRow, String> instrument = new AlignedTableColumn<>("Instrument", HPos.LEFT);
      instrument.setId("instrument-tablecolumn");
      instrument.setCellValueFactory(TradesViewTable::call);
      instrument.setCellFactory(p -> new InstrumentCell());
      instrument.setMinWidth(90);

      final TableColumn<ObservableReplyRow, String> type = new AlignedTableColumn<>("Type");
      type.setId("type-tablecolumn");
      type.setCellValueFactory(param -> typeColFactory.apply(param.getValue()));
      type.setCellFactory(p -> new TableCellUtil.StringCell());
      type.setMinWidth(60);

      final TableColumn<ObservableReplyRow, BigDecimal> price = new AlignedTableColumn<>("Price", HPos.RIGHT);
      price.setId("price-tablecolumn");
      price.setCellValueFactory(cd -> cd.getValue().getProperty(AmpTrade.price));
      price.setMinWidth(60);
      price.setCellFactory(param -> new TableCellUtil.PriceCell(AmpTrade.secCode, AmpTrade.boardId, secBoardStaticInfoGetter));

      final TableColumn<ObservableReplyRow, String> commType = new AlignedTableColumn<>("Comm");
      commType.setId("comm-tablecolumn");
      commType.setCellValueFactory(param -> commTypeColFactory.apply(param.getValue()));
      commType.setCellFactory(p -> new TableCellUtil.StringCell());
      commType.setMinWidth(60);

      final TableColumn<ObservableReplyRow, BigDecimal> netValue = new AlignedTableColumn<>("Net");
      netValue.setId("net-tablecolumn");
      netValue.setCellValueFactory(param -> netValueColFactory.apply(param.getValue()));
      netValue.setCellFactory(p -> new TableCellUtil.BigDecimalCell());
      netValue.setMinWidth(50);

      final TableColumn<ObservableReplyRow, String> status = new AlignedTableColumn<>("Status");
      status.setId("status-tablecolumn");
      status.setCellValueFactory(param -> statusColFactory.apply(param.getValue()));
      status.setCellFactory(p -> new TableCellUtil.StringCell());
      status.setMinWidth(70);

      final TableColumn<ObservableReplyRow, String> traderId = new AlignedTableColumn<>("Trader");
      traderId.setId("traderid-tablecolumn");
      traderId.setCellValueFactory(param -> traderColFactory.apply(param.getValue()));
      traderId.setCellFactory(p -> new TableCellUtil.StringCell());
      traderId.setMinWidth(70);


      final TableColumn<ObservableReplyRow, String> brokerId = new AlignedTableColumn<>("Broker");
      brokerId.setId("brokerid-tablecolumn");
      brokerId.setCellValueFactory(param -> brokerColFactory.apply(param.getValue()));
      brokerId.setCellFactory(p -> new TableCellUtil.StringCell());
      brokerId.setMinWidth(70);

      TableColumn<ObservableReplyRow, XfeAction> agreeTrade = new AlignedTableColumn<>(); // need to be replaced by icon
      agreeTrade.setId("agree-tablecolumn");
      agreeTrade.getProperties().put(SETTING_TEXT,"Agree");
      agreeTrade.getStyleClass().add(XfeActionCell.DEFAULT_STYLE);
      agreeTrade.setResizable(false);
      agreeTrade.setSortable(false);
      agreeTrade.setCellFactory(p -> new XfeActionCell<>());
      agreeTrade.setCellValueFactory(param -> tradeAgreeFactory.apply(param.getValue()));
      agreeTrade.setMinWidth(80);
      agreeTrade.setMaxWidth(80);
      Button agreeBtn = new Button();
      XfeAction agreeAction = new XfeAction();
      agreeAction.bindTo(agreeBtn);
      agreeAction.setText("Agree");
      agreeAction.setOnAction(event -> getItems().forEach(tradeRow -> {
         String buyDealStatus = tradeRow.getValue(AmpTrade.buyDealStatus);
         if (DealStatus.BrokerApproved.name().equals(buyDealStatus)) {
            tradeAgreeOp.accept(tradeRow, OrderSide.BUY);
         }

         String sellDealStatus = tradeRow.getValue(AmpTrade.sellDealStatus);
         if (DealStatus.BrokerApproved.name().equals(sellDealStatus)) {
            tradeAgreeOp.accept(tradeRow, OrderSide.SELL);
         }
      }));
      agreeTrade.setGraphic(agreeBtn);

      getColumns().addAll(extTradeRef, time, side, total, instrument, type, price, commType, netValue, status, traderId, brokerId, agreeTrade);
      getSortOrder().add(time);

    }

   private void setupColumnsMenu() {
      // setting up the menu for showing/hiding columns
      VBox settingsPane = new VBox();
      settingsPane.setPadding(new Insets(15));
      settingsPane.setSpacing(10);
      settingsPane.setPrefWidth(150);
      getColumns().forEach(col -> {
         String cbTitle = (String) col.getProperties().getOrDefault(SETTING_TEXT, col.getText());
         Double colWidth = col.getWidth();

         if (!cbTitle.isEmpty()) {
            final CheckBox cb = new CheckBox(cbTitle);
            cb.selectedProperty().bindBidirectional(col.visibleProperty());
            cb.selectedProperty().addListener((observable, oldValue, newValue) -> {
               final ObjectProperty<ColumnsSpec> columnsSpec = getColumnsSpecifications();
               columnsSpec.setValue(columnsSpec.get().editColumnSpec(cbTitle, newValue));
            });
            col.widthProperty().addListener((observable, oldValue, newValue) -> {
               final ObjectProperty<ColumnsSpec> columnsSpec = getColumnsSpecifications();
               columnsSpec.setValue(columnsSpec.get().editColumnSpec(cbTitle, (Double) newValue));
            });
            settingsPane.getChildren().add(cb);

            final ObjectProperty<ColumnsSpec> columnsSpec = getColumnsSpecifications();
            columnsSpec.setValue(columnsSpec.get().setColumnSpec(cbTitle, colWidth));
            final ColumnSpec spec = columnsSpec.get().getColumnSpec(cbTitle);
            col.setPrefWidth(spec.getWidth());
            col.setVisible(spec.isVisible());
         }
      });
      setSettingsContent(settingsPane);
      setTableMenuButtonVisible(true);
   }

   void setTradeAgreeOp(BiConsumer<ObservableReplyRow, OrderSide> tradeAgreeOp) {
      this.tradeAgreeOp = tradeAgreeOp;
   }

   private static ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableReplyRow, String> cd) {
      return new ReadOnlyObjectWrapper<>(Util.stripper(cd.getValue().getProperty(AmpTrade.secCode).get(), "UKT"));
   }

   public void setSecBoardStaticInfoGetter(BiFunction<String, String, Future<SecBoardStaticInfo>> secBoardStaticInfoGetter) {
      this.secBoardStaticInfoGetter = secBoardStaticInfoGetter;
   }

   private Function<ObservableReplyRow, ObservableValue<XfeAction>> tradeAgreeFactory;
   private BiConsumer<ObservableReplyRow, OrderSide> tradeAgreeOp;
   private Function<ObservableReplyRow, ObservableValue<OrderSide>> sideColFactory;
   private Function<ObservableReplyRow, ObservableValue<String>> typeColFactory;
   private Function<ObservableReplyRow, ObservableValue<String>> statusColFactory;
   private Function<ObservableReplyRow, ObservableValue<String>> commTypeColFactory;
   private Function<ObservableReplyRow, ObservableValue<BigDecimal>> netValueColFactory;
   private Function<ObservableReplyRow, ObservableValue<String>> traderColFactory;
   private Function<ObservableReplyRow, ObservableValue<String>> extTradeRefColFactory;
   private Function<ObservableReplyRow, ObservableValue<String>> brokerColFactory;
   private BiFunction<String, String, Future<SecBoardStaticInfo>> secBoardStaticInfoGetter;

   private Consumer<TradesAggregateArgs> tradesAggregatePopupActionConsumer;
   private Supplier<ObjectProperty<ColumnsSpec>> tradesColsSpecificationPropertySupplier;

   @Override
   public void setTradesAggregatePopupActionConsumer(Consumer<TradesAggregateArgs> tradesAggregatePopupActionConsumer) {
      this.tradesAggregatePopupActionConsumer = tradesAggregatePopupActionConsumer;
   }

   @Override
   public Consumer<TradesAggregateArgs> getTradesAggregatePopupActionConsumer() {
      return this.tradesAggregatePopupActionConsumer;
   }

   public void setTradesColsSpecificationPropertySupplier(Supplier<ObjectProperty<ColumnsSpec>> tradesColsSpecificationPropertySupplier) {
      this.tradesColsSpecificationPropertySupplier = tradesColsSpecificationPropertySupplier;
      if(tradesColsSpecificationPropertySupplier!=null) {
         setupColumnsMenu();
      }
   }

   private ObjectProperty<ColumnsSpec> getColumnsSpecifications() {
      return this.tradesColsSpecificationPropertySupplier.get();
   }


}
