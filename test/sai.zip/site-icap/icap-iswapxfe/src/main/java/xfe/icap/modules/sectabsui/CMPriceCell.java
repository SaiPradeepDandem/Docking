package xfe.icap.modules.sectabsui;

import javafx.scene.input.MouseEvent;
import xfe.modules.actions.PopupOrderEntryArgs;
import xfe.modules.actions.WorkupArgs;
import xstr.session.WatchlistRow;

import java.math.BigDecimal;

/**
 * Price cell for CM orders.
 */
public class CMPriceCell extends WatchlistPriceCell {

   @Override
   protected void onSingleClick(MouseEvent e) {
      final PriceCellValue<BigDecimal> item = getItem();
      if (item != null) {
         final WatchlistRow tRow = getWatchListRow();
         final SecTable secTable = getSecTable();
         if (item.isCMWorkup()) {
            secTable.getCMPriceColWorkupAction().accept(new WorkupArgs(tRow.getRow(), this, null));
         } else if (!isPopOverShowing()) {
            if (item.isCMAmend()) {
               secTable.getCMPriceColAmend().accept(new PopupOrderEntryArgs(tRow.getRow(), this, null, null, PopupOrderEntryArgs.DefaultOn.PRICE));
            } else {
               secTable.getCMPriceColEntry().accept(new PopupOrderEntryArgs(tRow.getRow(), this, null, null, PopupOrderEntryArgs.DefaultOn.PRICE));
            }
         }
      }
   }

}
