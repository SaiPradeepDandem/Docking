package xfe.icap.modules.sectabsui;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.types.RowHighlight;
import xfe.types.StepArray;
import xstr.session.ObservableReplyRow;
import xstr.session.WatchlistRow;

/**
 * Instrument cell.
 */
public class InstrumentCell extends WatchlistCell<String> {
   public static final String INSTRUMENT_TICK_PRICE_KEY = "instrument-tick-price";
   private StackPane container;
   private StackPane notch;
   private Label cellValue;

   @Override
   protected void updateDataItem(String item) {
      setStyle("-fx-font-size: " + glyphFontSizeMap.get(getSecTable().getZoomLevel().get()));
      if (container == null) {
         setupContainer();
      }
      cellValue.setText(item);
      setGraphic(container);
      setText(null); /* We deal with only graphic in non-heading instrument cell */
      setStepArrayValue();
   }

   private void setStepArrayValue() {
      final ObservableReplyRow row = ((WatchlistRow) getTableRow().getItem()).getRow();
      String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
      String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      StepArray stepArray = getSecTable().getStepArrayCallBack().apply(secCode,boardId);
      getProperties().put(INSTRUMENT_TICK_PRICE_KEY,stepArray);
   }

   @Override
   protected void resetForNonInstrumentRow() {
      getProperties().remove(INSTRUMENT_TICK_PRICE_KEY);
   }

   /**
    * Event handler to toggle the row highlighting. Row highlighting can only be done by clicking on this Instrument cell.
    *
    * @param e Mouse event
    */
   @Override
   protected void onDoubleClick(MouseEvent e) {
      final ObservableReplyRow row = getWatchListRow().getRow();
      final RowHighlight currState = (RowHighlight) row.getCustomPropertyValue(SecTable.HIGHLIGHT_PROP_NAME);
      final RowHighlight nextState = currState.getNext();
      row.setCustomProperty(SecTable.HIGHLIGHT_PROP_NAME, nextState);
      getTableRow().pseudoClassStateChanged(currState.getStyle(), false);
      getTableRow().pseudoClassStateChanged(nextState.getStyle(), true);
      getSecTable().getSaveToggle().accept(row, currState);
   }

   /**
    * Creates the container for the cell. The whole purpose of this container is to provide the notch(small green triangle)
    * display option when the mouse hovers the cell.
    */
   private void setupContainer() {
      notch = new StackPane();
      notch.setVisible(false);
      notch.getStyleClass().add("instrument-cell-notch");
      notch.setMaxSize(10, 10);
      notch.setMinSize(10, 10);
      setOnMouseEntered(e -> notch.setVisible(true));
      setOnMouseExited(e -> notch.setVisible(false));
      StackPane.setAlignment(notch, Pos.TOP_RIGHT);
      notch.setOnMouseClicked(e -> {
         final ObservableReplyRow row = ((WatchlistRow) getTableRow().getItem()).getRow();
         final TradesAggregateArgs args = new TradesAggregateArgs(row.getValue(AmpIcapSecBoardTrim2.boardId), row.getValue(AmpIcapSecBoardTrim2.secCode), container);
         getSecTable().getTradesAggregatePopupAction().accept(args);
      });

      cellValue = new Label();
      container = new StackPane();
      container.getStyleClass().add("wrapper");
      container.setAlignment(Pos.CENTER_LEFT);
      container.getChildren().addAll(cellValue, notch);
   }
}
