package xfe.icap.modules.tradesui;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Callback;
import xfe.amp.AmpMarketTrade;
import xfe.ui.table.AlignedTableColumn;
import xfe.ui.table.Tables;
import xfe.util.Util;
import xstr.session.ObservableReplyRow;

import java.math.BigDecimal;
import java.util.Date;
import java.util.function.BiConsumer;

class MarketTradesTable extends TableView<ObservableReplyRow> {

   MarketTradesTable() {
      setPlaceholder(Tables.stripedRowCSSPlaceholder());
      TableColumn<ObservableReplyRow, String> secCol = new AlignedTableColumn<>("Instrument", HPos.LEFT);
      secCol.getStyleClass().add("xfe-bold-text");
      secCol.setCellValueFactory(c -> new ReadOnlyObjectWrapper(Util.stripper(c.getValue().getProperty(AmpMarketTrade.secCode).get(), "UKT")));
      getColumns().add(secCol);

      TableColumn<ObservableReplyRow, BigDecimal> priceCol = new AlignedTableColumn<>("Price", HPos.RIGHT);
      priceCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpMarketTrade.price));
      priceCol.setCellFactory(param -> new TableCell<ObservableReplyRow, BigDecimal>() {
         @Override
         protected void updateItem(BigDecimal item, boolean empty) {
            super.updateItem(item, empty);
            setText(null);
            if (item != null && !empty) {
               if (getPriceFormatter() != null) {
                  getPriceFormatter().accept(this, item);
               } else {
                  setText(item.toString());
               }
            }
         }
      });
      getColumns().add(priceCol);

      TableColumn<ObservableReplyRow, Double> qtyCol = new AlignedTableColumn<>("Total", HPos.RIGHT);
      qtyCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpMarketTrade.quantity));
      getColumns().add(qtyCol);

      TableColumn<ObservableReplyRow, Date> timeCol = new AlignedTableColumn<>("Time", HPos.RIGHT);
      timeCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpMarketTrade.tradeTime));
      timeCol.setCellFactory(param -> new TableCell<ObservableReplyRow, Date>() {
         @Override
         protected void updateItem(Date item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null) {
               setText(null);
            } else {
               setText(Util.formatTime(item));
            }
         }
      });
      getColumns().add(timeCol);
   }

   public void setPriceFormatter(BiConsumer<TableCell<ObservableReplyRow, BigDecimal>, BigDecimal> priceFormatter) {
      this.priceFormatter = priceFormatter;
   }

   public BiConsumer<TableCell<ObservableReplyRow, BigDecimal>, BigDecimal> getPriceFormatter() {
      return priceFormatter;
   }

   private BiConsumer<TableCell<ObservableReplyRow, BigDecimal>, BigDecimal> priceFormatter;
}
