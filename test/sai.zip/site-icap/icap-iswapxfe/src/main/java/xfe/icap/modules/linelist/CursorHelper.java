package xfe.icap.modules.linelist;

import com.nomx.persist.linelist.Participant;

import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;

public class CursorHelper {

  private final HBox hbox = new HBox();
  private final Label tradername = new Label();
  private final Label firm = new Label();
  private final CheckBox isAuto = new CheckBox();
  private final Label hotkey = new Label();
  private final Label ib  = new Label();

  public CursorHelper(Participant par,boolean isAdd){
     hbox.setSpacing(1);
     hbox.setPrefWidth(400);
     tradername.setText(par.getId());
     firm.setText(par.getParentfirmId());
     isAuto.setSelected(par.isAutoTrader);
     hotkey.setText(par.getHK());
     ib.setText(par.getSubTitle());

     tradername.setPrefWidth(150);
     firm.setPrefWidth(150);
     hbox.getChildren().addAll(tradername,firm,isAuto,hotkey,ib);
  }

  public Cursor convert2Cursor(){
     WritableImage writableImage = new WritableImage(400, 30);
     Image image = hbox.snapshot(new SnapshotParameters(), writableImage);
     return new ImageCursor(image);
  }

  private static final ImageView dragImageView = new ImageView();
  private Node dragItem;
//  public static void addGesture(final Node node) {
//     node.setOnDragDetected(new EventHandler<MouseEvent>() {
//         public void handle(MouseEvent e) {
//
//             SnapshotParameters snapParams = new SnapshotParameters();
//             snapParams.setFill(Color.TRANSPARENT);
//             dragImageView.setImage(node.snapshot(snapParams, null));
//
////             sceneRoot.getChildren().add(dragImageView);
//
//             dragImageView.startFullDrag();
//             e.consume();
//         }
//     });
//     node.setOnMouseDragged(new EventHandler<MouseEvent>() {
//         public void handle(MouseEvent e) {
//             Point2D localPoint = sceneRoot.sceneToLocal(new Point2D(e.getSceneX(), e.getSceneY()));
//             dragImageView.relocate(
//                     (int)(localPoint.getX() - dragImageView.getBoundsInLocal().getWidth() / 2),
//                     (int)(localPoint.getY() - dragImageView.getBoundsInLocal().getHeight() / 2)
//             );
//             e.consume();
//         }
//     });
//     node.setOnMouseEntered(new EventHandler<MouseEvent>() {
//         public void handle(MouseEvent e) {
//             node.setCursor(Cursor.HAND);
//         }
//     });
//     node.setOnMousePressed(new EventHandler<MouseEvent>() {
//         public void handle(MouseEvent e) {
//             dragItem = node;
//             dragImageView.setMouseTransparent(true);
//             node.setMouseTransparent(true);
//             node.setCursor(Cursor.CLOSED_HAND);
//         }
//     });
//     node.setOnMouseReleased(new EventHandler<MouseEvent>() {
//         public void handle(MouseEvent e) {
//             dragItem = null;
//             dragImageView.setMouseTransparent(false);
//             node.setMouseTransparent(false);
//             node.setCursor(Cursor.DEFAULT);
//             sceneRoot.getChildren().remove(dragImageView);
//         }
//     });
//
// }
}
