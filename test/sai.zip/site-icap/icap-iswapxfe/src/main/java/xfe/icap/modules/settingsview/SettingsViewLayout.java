package xfe.icap.modules.settingsview;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.settings.SettingsData;
import xstr.session.ServerSession;

import java.util.BitSet;

/**
 * Controller for SettingsViewLayout.fxml
 */
public class SettingsViewLayout {

   @FXML
   public void initialize() {
      root.setId(MidiLayoutViews.SETTINGSVIEW);
      if (expandedStates != null) {
         this.settingsLayoutController.setExpandedStates(expandedStates);
      }
      this.settingsLayoutController.expandedSetProperty().addListener(observable -> {
         expandedStates = settingsLayoutController.getExpandedSet();
      });
   }

   public void bindSettingsData(SettingsData data, ServerSession xfeSession) {
      this.settingsLayoutController.bindSettingsData(data, xfeSession);
   }

   public void tailorForRole(ServerSession xfeSession) {
      this.settingsLayoutController.tailorForRole(xfeSession);
   }

   public VBox getRoot() {
      return root;
   }

   public void setLoadDefaultSettingsHandler(Runnable loadDefaultSettingsHandler) {
      this.settingsLayoutController.setLoadDefaultSettingsHandler(loadDefaultSettingsHandler);
   }

   public void setSaveHandler(Runnable saveHandler) {
      this.saveHandler = saveHandler;
   }

   public void setCancelHandler(Runnable cancelHandler) {
      this.cancelHandler = cancelHandler;
   }

   public void addNewTab(Node view, String title) {
      final Tab tab = new Tab(title);
      tab.setId(view.getId());
      tab.setClosable(false);
      tab.setContent(view);
      int index = 1;
      if (view.getId().equals(MidiLayoutViews.MMGROUPVIEW)) {
         boolean hasLineList = tabPane.getTabs().stream().map(Tab::getContent)
            .anyMatch(n -> MidiLayoutViews.LINELISTVIEW.equals(n.getId()));
         if (hasLineList) {
            index = 2;
         }
      } else if (view.getId().equals(MidiLayoutViews.TAB_EDITORVIEW) || view.getId().equals(MidiLayoutViews.INSTRUMENT_SETTINGSVIEW)) {
         index = tabPane.getTabs().size();
      }
      tabPane.getTabs().add(index, tab);
   }

   public void removeTab(String tabId) {
      tabPane.getTabs().removeIf(tab -> tab.getId().equals(tabId));
   }

   public void save() {

   }

   public void reset() {
      settingsLayoutController.reset();
   }

   @FXML
   private void save(ActionEvent e) {
      if (saveHandler != null) {
         saveHandler.run();
      }
   }

   @FXML
   private void cancel(ActionEvent e) {
      if (cancelHandler != null) {
         cancelHandler.run();
      }
   }

   @FXML
   private VBox root;

   @FXML
   private TabPane tabPane;

   @FXML
   private SettingsLayout settingsLayoutController;

   private Runnable saveHandler;

   private Runnable cancelHandler;

   private BitSet expandedStates;

}
