package xfe.icap.modules.instrumentsettingsview;

import com.nomx.instrumentsettings.InstrumentSettingsSpec;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.Callback;
import org.controlsfx.glyphfont.Glyph;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xfe.ui.control.GlyphButton;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.util.scene.layout.FxmlPane;

import java.util.*;

public class InstrumentSettingsViewLayout implements FxmlPane {

   @FXML
   private void initialize() {
      root.setId(MidiLayoutViews.INSTRUMENT_SETTINGSVIEW);
      productsTreeView.setCellFactory(new Callback<TreeView<InstrumentSettingsTreeData>, TreeCell<InstrumentSettingsTreeData>>() {
         @Override
         public TreeCell<InstrumentSettingsTreeData> call(TreeView<InstrumentSettingsTreeData> param) {
            return new TreeCell<InstrumentSettingsTreeData>() {
               Label lbl = new Label();
               BorderPane bp = new BorderPane();
               GlyphButton undo = new GlyphButton("UNDO");
               {
                  bp.setCenter(lbl);
                  BorderPane.setAlignment(lbl,Pos.CENTER_LEFT);
                  ((Glyph)undo.getGraphic()).setColor(Color.RED);
                  undo.setOnAction(e->resetSpec(getTreeItem()));
                  undo.setId("xfe-instruments-settings-reset"); // Id for showing the tooltip from properties file
                  XfeTooltipFactory.setTooltip(undo);
               }
               @Override
               protected void updateItem(InstrumentSettingsTreeData item, boolean empty) {
                  super.updateItem(item, empty);
                  if (item != null && !empty) {
                     lbl.setText(item.getDisplayValue());
                     setGraphic(bp);
                     if (item.isDirty()) {
                        lbl.getStyleClass().add("xfe-bold-text");
                        bp.setRight(undo);
                     }else{
                        lbl.getStyleClass().removeAll("xfe-bold-text");
                        bp.setRight(null);
                     }

                  } else {
                     setGraphic(null);
                     lbl.getStyleClass().removeAll("xfe-bold-text");
                     bp.setRight(null);
                  }
               }
            };
         }
      });
      productsTreeView.getSelectionModel().selectedItemProperty().addListener((obs, oldItem, newItem) -> {
         if (newItem != null) {
            InstrumentSettingsSpec spec = getSpecByInstrumentId(newItem.getValue().getInstrumentId());
            if (spec == null) {
               spec = getSpecByInstrumentId(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
            }
            workupPopupCB.setSelected(spec.isEnableWorkupPopup());
            activeTabsCB.setSelected(spec.isActiveTabs());
            flashOnCMPriceChange.setSelected(spec.isFlashOnCMPriceChange());
            flashOnCLOBPriceChange.setSelected(spec.isFlashOnCLOBPriceChange());
            settingsPane.setDisable(false);
         } else {
            settingsPane.setDisable(true);
         }
      });

      workupPopupCB.setOnAction(e -> updateDirty());
      activeTabsCB.setOnAction(e -> updateDirty());
      flashOnCMPriceChange.setOnAction(e -> updateDirty());
      flashOnCLOBPriceChange.setOnAction( e -> updateDirty());
   }

   private void resetSpec(TreeItem<InstrumentSettingsTreeData> treeItem) {
      productsTreeView.getSelectionModel().select(treeItem);
      // Remove the spec from the list.
      InstrumentSettingsSpec selectedSpec = getSpecByInstrumentId(treeItem.getValue().getInstrumentId());
      instrumentSettingsSpecs.remove(selectedSpec);

      // Update the cell dirty property
      InstrumentSettingsTreeData data = treeItem.getValue();
      data.setDirty(false);
      treeItem.setValue(null);
      treeItem.setValue(data);

      // Update the form with rootspec details
      InstrumentSettingsSpec rootSpec = getSpecByInstrumentId(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
      workupPopupCB.setSelected(rootSpec.isEnableWorkupPopup());
      activeTabsCB.setSelected(rootSpec.isActiveTabs());
      flashOnCMPriceChange.setSelected(rootSpec.isFlashOnCMPriceChange());
      flashOnCLOBPriceChange.setSelected(rootSpec.isFlashOnCLOBPriceChange());
   }

   private void updateDirty() {
      modified = true;
      TreeItem<InstrumentSettingsTreeData> selectedItem = productsTreeView.getSelectionModel().getSelectedItem();
      if (selectedItem != null) {
         InstrumentSettingsTreeData selectedData = selectedItem.getValue();
         boolean isRoot = selectedData.getInstrumentId().equals(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
         InstrumentSettingsSpec rootSpec = getSpecByInstrumentId(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
         // IF the changes are on root Item
         if (isRoot) {
            rootSpec.setEnableWorkupPopup(workupPopupCB.isSelected());
            rootSpec.setActiveTabs(activeTabsCB.isSelected());
            rootSpec.setFlashOnCMPriceChange(flashOnCMPriceChange.isSelected());
            rootSpec.setFlashOnCLOBPriceChange(flashOnCLOBPriceChange.isSelected());
            List<InstrumentSettingsSpec> specsToRemove = new ArrayList<>();
            instrumentSettingsSpecs.stream().forEach(spec -> {
               // Checking for not root items only
               if (!spec.getInstrumentId().equals(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID)) {
                  boolean isDirty = checkForDirty(rootSpec, spec);
                  if (!isDirty) {
                     specsToRemove.add(spec);
                  }
                  treeData.stream().filter(td -> td.getInstrumentId().equals(spec.getInstrumentId())).findFirst().map(td -> {
                     td.setDirty(isDirty);
                     return td;
                  });
               }
            });
            instrumentSettingsSpecs.removeAll(specsToRemove);
            productsTreeView.refresh();
            productsTreeView.getSelectionModel().select(selectedItem);
         } else {
            // If it is not a root item.
            boolean isDirty = checkForDirty(rootSpec);
            if (isDirty) {
               InstrumentSettingsSpec selectedSpec = getSpecByInstrumentId(selectedData.getInstrumentId());
               if (selectedSpec == null) {
                  instrumentSettingsSpecs.add(new InstrumentSettingsSpec(selectedData.getInstrumentId(), selectedData.getSecCode(), workupPopupCB.isSelected(), activeTabsCB.isSelected()
                     , flashOnCMPriceChange.isSelected(), flashOnCLOBPriceChange.isSelected()));
               } else {
                  selectedSpec.setEnableWorkupPopup(workupPopupCB.isSelected());
                  selectedSpec.setActiveTabs(activeTabsCB.isSelected());
                  selectedSpec.setFlashOnCMPriceChange(flashOnCMPriceChange.isSelected());
                  selectedSpec.setFlashOnCLOBPriceChange(flashOnCLOBPriceChange.isSelected());
               }
            } else {
               instrumentSettingsSpecs.removeIf(is -> is.getInstrumentId().equals(selectedData.getInstrumentId()));
            }
            selectedData.setDirty(isDirty);
            // Forcing the tree cell to refresh.
            selectedItem.setValue(null);
            selectedItem.setValue(selectedData);
         }

      }
   }

   private InstrumentSettingsSpec getSpecByInstrumentId(String instrumentId) {
      return instrumentSettingsSpecs.stream().filter(is -> is.getInstrumentId().equals(instrumentId)).findFirst().orElse(null);
   }

   private boolean checkForDirty(InstrumentSettingsSpec parentSpec) {
      return parentSpec.isActiveTabs() != activeTabsCB.isSelected() || parentSpec.isEnableWorkupPopup() != workupPopupCB.isSelected()
         || parentSpec.isFlashOnCMPriceChange() != flashOnCMPriceChange.isSelected() || parentSpec.isFlashOnCLOBPriceChange() != flashOnCLOBPriceChange.isSelected();
   }

   private boolean checkForDirty(InstrumentSettingsSpec parentSpec, InstrumentSettingsSpec childSpec) {
      return parentSpec.isActiveTabs() != childSpec.isActiveTabs() || parentSpec.isEnableWorkupPopup() != childSpec.isEnableWorkupPopup()
         || parentSpec.isFlashOnCMPriceChange() != childSpec.isFlashOnCMPriceChange() || parentSpec.isFlashOnCLOBPriceChange() != childSpec.isFlashOnCLOBPriceChange();
   }

   public VBox getRoot() {
      return root;
   }

   public void updateLayout(SecBoards secBoards, List<InstrumentSettingsSpec> instrumentSettingsSpecs) {
      if(productsTreeView.getRoot()!=null){
         productsTreeView.getRoot().getChildren().clear();
      }

      this.instrumentSettingsSpecs = instrumentSettingsSpecs;
      Map<String, List<SecBoard>> productsMap = new HashMap<>();
      secBoards.getAll().forEach(sb -> {
         String key = sb.getInstrumentId();
         productsMap.computeIfAbsent(key, k -> new ArrayList<>());
         productsMap.get(key).add(sb);
      });

      treeData = new ArrayList<>();
      final InstrumentSettingsTreeData allData = new InstrumentSettingsTreeData();
      allData.setInstrumentId(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
      treeData.add(allData);

      final TreeItem<InstrumentSettingsTreeData> rootItem = new TreeItem<>(allData);
      rootItem.setExpanded(true);
      productsTreeView.setRoot(rootItem);

      final InstrumentSettingsSpec rootSpec = getSpecByInstrumentId(InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
      final List<String> keyList = new ArrayList<>(productsMap.keySet());
      Collections.sort(keyList);
      keyList.forEach(instrumentId -> {
         List<SecBoard> secBoardList = productsMap.get(instrumentId);
         InstrumentSettingsTreeData data = new InstrumentSettingsTreeData();
         data.setInstrumentId(instrumentId);
         data.setSecBoards(secBoardList);
         InstrumentSettingsSpec spec = getSpecByInstrumentId(instrumentId);
         if (spec != null) {
            data.setDirty(checkForDirty(rootSpec, spec));
         }
         treeData.add(data);
         rootItem.getChildren().add(new TreeItem<>(data));
      });

      productsTreeView.getSelectionModel().select(rootItem);
      productsTreeView.setVisible(true);
   }


   public boolean isModified() {
      return modified;
   }

   public void reset(){
      modified = false;
   }

   @FXML
   private VBox root;

   @FXML
   private TreeView<InstrumentSettingsTreeData> productsTreeView;

   @FXML
   private StackPane settingsPane;

   @FXML
   private CheckBox workupPopupCB;

   @FXML
   private CheckBox activeTabsCB;

   @FXML
   private CheckBox flashOnCMPriceChange;

   @FXML
   private CheckBox flashOnCLOBPriceChange;

   private List<InstrumentSettingsTreeData> treeData;

   private List<InstrumentSettingsSpec> instrumentSettingsSpecs;

   private boolean modified;
}
