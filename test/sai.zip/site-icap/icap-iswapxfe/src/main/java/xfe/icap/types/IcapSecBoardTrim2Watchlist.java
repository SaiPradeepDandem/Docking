package xfe.icap.types;

import java.util.*;

import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xfe.types.Watchlist;
import xfe.icap.XfeSession;

import xfe.icap.modules.selectioncontext.SelectionContextModule;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;

import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;

import javafx.beans.value.WeakChangeListener;
import javafx.collections.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import xstr.session.QueryFeed;
import xstr.session.XtrQueryRequestBuilder;
import xstr.amp.AMP;
import xstr.session.XtrQueryRequest;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import xstr.util.filter.DynamicFilter;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xstr.session.ObservableReplyRow;
import xstr.util.Fun1;
import xstr.session.ObservableReplyRow.ObservableRowFactory;

public class IcapSecBoardTrim2Watchlist implements Watchlist {
   private static final Logger logger = LoggerFactory.getLogger(IcapSecBoardTrim2Watchlist.class);
   private static int nextWatchlistId = 1;
   private final XfeSession session;
   private final FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpIcapSecBoardTrim2.rep, new ObservableRowFactory());
   private final BooleanProperty isItemsDownload = new SimpleBooleanProperty(false);

   private final Map<String,Integer> positionMap = new HashMap<>(63);


   //There are two sets of SecBoard being watched. One set from watchlistSpec, the other from active rfq.
   private final ObservableList<SecBoard> specWatchedSecboards = FXCollections.observableArrayList();
   private final ObservableSet<SecBoard> watchedRfqSecBoards;

   //there are two sets of ObservableReplyRow being displayed in watchlist. One set from watchlist spec. the other from active rfq
   private final ObservableList<ObservableReplyRow> watchedRfqRows;
   private final ObservableSet<ObservableReplyRow> joinedItems = FXCollections.observableSet(new HashSet<>(100)); //combined rows from watchlist and active RFQ
   private final ObservableList<ObservableReplyRow> sortedWatchedItems;
   private final Map<String,ObservableReplyRow> specRowMap; //hash row items from watchlist spec. Convenient to bring them back once rfs session ends.
   private final ObservableList<ObservableReplyRow> readOnlyWatchedItems;
   private final SelectionContextModule selectionContextModule;
   private final StringProperty removedRSec;

   private boolean hidden;
   private final StringProperty titleProperty = new SimpleStringProperty();
   private final StringProperty subtitleProperty = new SimpleStringProperty();
   private final BooleanProperty visibleProperty = new SimpleBooleanProperty(true);

   private final BooleanProperty busyProperty = new SimpleBooleanProperty(true);

   private static int setNextWatchlistId(int nextWatchlistId) {
      int currWatchlistId = IcapSecBoardTrim2Watchlist.nextWatchlistId;
      IcapSecBoardTrim2Watchlist.nextWatchlistId = nextWatchlistId;
      return currWatchlistId;
   }

   private final SetChangeListener rfqSecboardLis = new SetChangeListener<SecBoard>() {
      @Override
      public void onChanged(Change<? extends SecBoard> c) {

         if (c.wasAdded()) {
            SecBoard secBoard = c.getElementAdded();
            logger.debug("An rfq secboard is added in to watchlist: {}",secBoard);
            String secCode = secBoard.getSecCode();
            if (!positionMap.containsKey(secCode)) {
               String parentCode = secBoard.getOriginalSecCode();
               Integer parentPosition = positionMap.get(parentCode);
               if (parentPosition != null) {
                  Integer pos = parentPosition + 1;
                  positionMap.put(secCode, pos);
                  logger.debug("The position of rfq {} is {}", secCode, pos);
               }
            }
         }
         if (c.wasRemoved()) {
            logger.debug("rfq secboard was removed from watchlist: {}", c.getElementRemoved());
            logger.debug("removing the position of rfq {}",c.getElementRemoved().getSecCode());
            positionMap.remove(c.getElementRemoved().getSecCode());
         }
      }
   };

   public IcapSecBoardTrim2Watchlist(XfeSession session,
                                     ObservableSet<SecBoard> extraWatchedSecBoard,
                                     ObservableList<ObservableReplyRow> extraWatchedList,
                                     SelectionContextModule selectionContextModule,
                                     StringProperty removedRSec) {
      this(session, "Watchlist " + String.valueOf(setNextWatchlistId(nextWatchlistId + 1)),
         extraWatchedSecBoard,
         extraWatchedList,
         selectionContextModule,
         removedRSec);
   }

   public IcapSecBoardTrim2Watchlist(XfeSession session) {
      this(session, "Watchlist " + String.valueOf(setNextWatchlistId(nextWatchlistId + 1)),
         FXCollections.emptyObservableSet(),
         FXCollections.emptyObservableList(),
         null,
         null);
   }

   public IcapSecBoardTrim2Watchlist(XfeSession session,
                                     String title,
                                     ObservableSet<SecBoard> extraWatchedSecBoard,
                                     ObservableList<ObservableReplyRow> watchedRfqRows,
                                     SelectionContextModule selectionContextModule,
                                     StringProperty removedRSec) {
      this.session = session;
      this.watchedRfqSecBoards = extraWatchedSecBoard;
      this.selectionContextModule = selectionContextModule;
      this.removedRSec = removedRSec;

      specRowMap = Fx.keyBy(aggregator.items, new Fun1<ObservableReplyRow, String>() {
         @Override
         public String call(ObservableReplyRow observableReplyRow) {
            return observableReplyRow.getString(AmpIcapSecBoardTrim2.secCode);
         }
      });

      this.watchedRfqRows = watchedRfqRows;
      this.titleProperty.set(title);
      specWatchedSecboards.addListener(specWatchedSecboardsLis);
      joinItems();
      Comparator<ObservableReplyRow> comparator = (row1, row2) -> {
         String secCode1 = row1.getValue(AmpIcapSecBoardTrim2.secCode);
         String secCode2 = row2.getValue(AmpIcapSecBoardTrim2.secCode);
         Integer position1 = positionMap.get(secCode1);
         if (position1 == null) return -1;
         Integer position2 = positionMap.get(secCode2);
         if (position2 == null) return 1;
         return position1 - position2;
      };
      sortedWatchedItems = Fx.sortBy(joinedItems, comparator);

      this.readOnlyWatchedItems =  FXCollections.unmodifiableObservableList(sortedWatchedItems);

      ChangeListener<Boolean> aggregatorBusyListener = (observable, oldValue, newValue) -> {
         busyProperty.set(newValue);
         logger.debug("Item count: {} - Busy: {}", aggregator.items.size(), busyProperty.get());
      };
      this.aggregator.busyProperty().addListener(new WeakChangeListener<>(aggregatorBusyListener));

      updateList();

      watchedRfqSecBoards.addListener(rfqSecboardLis);
   }

   private final InvalidationListener specWatchedSecboardsLis = observable -> {
      logger.info("watchlist spec changed(Tab selection)");
      updateList();
   };

   @Override
   public ObservableList<SecBoard> getSpecWatchedSecboards() {
      return specWatchedSecboards;
   }

   @Override
   public ObservableList<ObservableReplyRow> getItems() {
      return readOnlyWatchedItems;
   }

   private final ObjectProperty<Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue>> itemsFilterProperty =
         new SimpleObjectProperty<>(DynamicFilter.alwaysTrue);

   @Override
   public ObjectProperty<Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue>> itemsFilterProperty() {
      return itemsFilterProperty;
   }

   private final InvalidationListener aggregatorBusyLis = new InvalidationListener() {
      @Override
      public void invalidated(Observable observable) {
         if (!aggregator.busyProperty().get()) {
            aggregator.busyProperty().removeListener(this);
            isItemsDownload.setValue(true);
            logger.trace("changing tab: finished downloading");
         }
      }
   };

   private void updatePositionMap() {
      logger.trace("updating positionMap. watchedSecboards is {}; watchedRfqSecBoards is {}.",
         specWatchedSecboards,
         watchedRfqSecBoards);
      positionMap.clear();
      int i = 0;
      for (SecBoard secBoard: specWatchedSecboards) {
         String secCode = secBoard.getSecCode();
         positionMap.put(secCode, i);
         for (SecBoard rfqSecBoard: watchedRfqSecBoards) {
            if (rfqSecBoard.getOriginalSecCode().equals(secCode)) {
               positionMap.put(rfqSecBoard.getSecCode(), i + 1);
               break;
            }
         }
         i += 10;
      }
      logger.trace("updated positionMap. size is {}, {}", positionMap.size() ,positionMap);
   }

   private void updateList() {
      int size = specWatchedSecboards.size();
      Long[] sortedIndices = new Long[size];
      for (int i = 0; i < size; i++) {
         sortedIndices[i] = specWatchedSecboards.get(i).getIndex();
      }
      logger.trace("updating watchlist");
      logger.trace("sortedIndices is {}",Arrays.toString(sortedIndices));
      updatePositionMap();
      isItemsDownload.setValue(false);
      if (!session.getUnderlyingSession().isLoggedOn()) {
         return;
      }
      if (sortedIndices.length > 0 && !hidden) {
         try {
            logger.trace("changing tab: building request");
            XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req, session.getUnderlyingSession())
                  .set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), sortedIndices)
                  .build();
            logger.debug("{}|{} new request: {}", titleProperty.get(), subtitleProperty.get(), req);
            QueryFeed feedSrc = session.getUnderlyingSession().queries.getFeedSource(req);
            aggregator.registerToFeedScc(feedSrc);
            aggregator.busyProperty().addListener(aggregatorBusyLis);
         } catch (AsnTypeException | AmpPermissionException ex) {
            logger.error(ex.getMessage(), ex);
         }
      } else {
         aggregator.reset();
      }
   }

   @Override
   public void setHidden(boolean hidden) {
	   //	We should stop polling if this watchlist belongs to the watchlistStage and that is hidden
	   this.hidden = hidden;
	   if (hidden) {
   	   aggregator.deregisterToFeedScc();
	   } else {
		   updateList();
	   }
   }

   @Override
   public void setTitle(String title) {
      this.titleProperty.set(title);
   }

   @Override
   public void setSubtitle(String subtitle) {
      this.subtitleProperty.set(subtitle);
   }

   @Override
   public void setVisible(boolean isVisible) {
      this.visibleProperty.set(isVisible);
   }

   @Override
   public void dispose() {
      specWatchedSecboards.removeListener(specWatchedSecboardsLis);
      watchedRfqSecBoards.removeListener(rfqSecboardLis);
      specWatchedSecboards.clear();
      aggregator.items.removeListener(listChangeListener);
      watchedRfqRows.removeListener(listChangeListener);
      aggregator.deregisterToFeedScc();
   }

   @Override
   public void setOnSecBoardsReady(SecBoards secBoards, Runnable runnable) {

      secBoards.ready().onSuccess(new Fun1<Boolean, Void>(){

         @Override
         public Void call(Boolean a) {
            runnable.run();
            return null;
         }
      });
   }

   @Override
   public ObservableBooleanValue itemsReadyProperty() {
      return isItemsDownload;
   }

   private String secPendingRemoval;
   private final ListChangeListener<ObservableReplyRow> listChangeListener = new ListChangeListener<ObservableReplyRow>() {
      @Override
      public void onChanged(Change<? extends ObservableReplyRow> c) {
         while (c.next()) {
            logger.trace("*** listChangeListener called CHANGE: {}", c);
            ObservableList<? extends ObservableReplyRow> sourceList = c.getList();
            if (c.wasAdded()) {
               List<? extends ObservableReplyRow> addedList = c.getAddedSubList();
               if (sourceList == aggregator.items) { //watchlist row added
                  logger.trace("secPendingRemoval is {}", secPendingRemoval);
                  addedList.stream().forEach(row -> {
                     if (!isActiveRfsInitialedByMeExist(row) &&
                         !row.getString(AmpIcapSecBoardTrim2.secCode).equals(secPendingRemoval)) {
                        logger.trace("Adding row: {}", row);
                        joinedItems.add(row);
                     }
                  });
                  secPendingRemoval = null;
               } else {
                  // Here we need to handle a new active rfs being received

                  // First we add the new row to the joinedItems list
                  // this should not trigger a selection change
                  logger.trace("Adding rows: {}", c.getAddedSubList());
                  joinedItems.addAll(c.getAddedSubList());

                  // Now we find and remove the parent row of the newly received rfq
                  addedList.stream().forEach(row -> {
                     String rfsSecCode = row.getString(AmpIcapSecBoardTrim2.secCode);
                     Optional<String> parentCode = getParentCode(rfsSecCode);
                     String parentSecCode;
                     if (parentCode.isPresent())
                        parentSecCode = parentCode.get();
                     else
                        parentSecCode = guessParentCode(rfsSecCode);

                     if (parentSecCode != null && session.rfqs.get().isRfsSessionInitiator(rfsSecCode)) {
                        ObservableReplyRow parentSecCodeRow = specRowMap.get(parentSecCode);
                        if (parentSecCodeRow != null) {
                           ObservableReplyRow selectedRow = selectionContextModule.getSelectionContext().row;
                           logger.trace("*** Parent row to be removed is: {}", parentSecCodeRow);
                           logger.trace("*** Selected row is: {}", selectedRow);

                           String selectedSecCode = null;
                           if (selectedRow != null)
                              selectedSecCode = selectedRow.getString(AmpIcapSecBoardTrim2.secCode);
                           logger.trace("selectedSecCode is {}", selectedSecCode);
                           logger.trace("parentSecCode is {}", parentSecCode);
                           if (selectedSecCode != null && selectedSecCode.contains(parentSecCode) ||
                               selectionContextModule.getSelectionContext().grid == GridType.OBBO_BUY ||
                               selectionContextModule.getSelectionContext().grid == GridType.OBBO_SELL) {
                              logger.trace("*** Setting removedRSec to {}", parentSecCode);
                              removedRSec.setValue(parentSecCode);
                           }

                           logger.trace("*** Removing  parentSecCodeRow: {} from joinedItems", parentSecCodeRow);
                           joinedItems.remove(parentSecCodeRow);
                        } else {
                           logger.error("can't identify row for parent for REMOVAL. child code is : {}", rfsSecCode);
                           secPendingRemoval = parentCode.get();
                        }
                     } else {
                        logger.error("can't identify security code for parent. child code is : {}", rfsSecCode);
                     }
                  });
               }
            }

            if (c.wasRemoved()) {
               List<? extends ObservableReplyRow> removed = c.getRemoved();
               if (sourceList == watchedRfqRows) {
                  removed.stream().forEach(row -> {
                     // We first want to add back the the parent security
                     // this should not trigger a selection change
                     String rfsSecCode = row.getString(AmpIcapSecBoardTrim2.secCode);
                     Optional<String> parentCode = getParentCode(rfsSecCode);
                     String parentSecCode;
                     if (parentCode.isPresent())
                        parentSecCode = parentCode.get();
                     else
                        parentSecCode = guessParentCode(rfsSecCode);
                     if (parentSecCode != null) {
                        ObservableReplyRow parentSecCodeRow = specRowMap.get(parentSecCode);
                        if (parentSecCodeRow != null) {
                           if (!joinedItems.contains(parentSecCodeRow)) {
                              logger.trace("*** Adding  parentSecCodeRow: {} to joinedItems", parentSecCodeRow);
                              joinedItems.add(parentSecCodeRow); //
                           }
                        } else {
                           // If here it means we'll get the parent later
                           logger.error("can't identify row for parent for ADDITION. child code is : {}", rfsSecCode);
                        }
                     } else {
                        logger.error("can't get parent sec code for: {}. active RFS secBoard is {}", rfsSecCode, watchedRfqSecBoards);
                     }

                     // Now we remove the rfq row
                     logger.trace("*** Removing RFQ row: {}", row);
                     joinedItems.remove(row);

                        ObservableReplyRow selectedRow = selectionContextModule.getSelectionContext().row;
                        logger.trace("*** Selected row is: {}", selectedRow);

                        String selectedSecCode = null;
                        if (selectedRow != null && selectionContextModule.getSelectionContext().grid == GridType.Watchlist)
                           selectedSecCode = selectedRow.getString(AmpIcapSecBoardTrim2.secCode);

                        logger.trace("rfsSecCode is {}", rfsSecCode);
                        if (selectedSecCode != null && rfsSecCode.contains(selectedSecCode) ||
                            selectionContextModule.getSelectionContext().grid == GridType.OBBO_BUY ||
                            selectionContextModule.getSelectionContext().grid == GridType.OBBO_SELL) {
                           logger.trace("*** Setting removedRSec to {}", rfsSecCode);
                           removedRSec.setValue(guessParentCode(rfsSecCode));
                        } else {
                           removedRSec.setValue(selectedSecCode);
                           removedRSec.setValue(null);
                        }
                     //}
                  });

               } else {
                  // We just need to remove this rfs unrelated secs
                  joinedItems.removeAll(removed);
               }
            }
         }
      }
   };

   /*
   For RFS Session, if there is active RFS session and the logged user is the initiator, the parent instrument need to be removed.
   When RFS session ended, the parent instrument needs to get back
    */
   private void joinItems() {
      aggregator.items.stream().filter(row -> !isActiveRfsInitialedByMeExist(row)).forEach(joinedItems::add);
      logger.trace("Add all watchedRfqRows {} to joinedItems", watchedRfqRows);
      joinedItems.addAll(watchedRfqRows);
      aggregator.items.addListener(listChangeListener);
      watchedRfqRows.addListener(listChangeListener);
   }

   private Optional<String> getParentCode(String rfqCode) {
      logger.trace("watchedRfqSecBoards: {}", watchedRfqSecBoards);
      return watchedRfqSecBoards.stream().filter(secBoard -> rfqCode.equals(secBoard.getSecCode())).findAny().map(SecBoard::getOriginalSecCode);
   }

   private String guessParentCode(String rfqCode) {
      int index = rfqCode.indexOf("-rfs");
      if (index != -1)
         return rfqCode.substring(0, index);
      return null;
   }

   private boolean isActiveRfsInitialedByMeExist(ObservableReplyRow row) {
      String secCode = row.getString(AmpIcapSecBoardTrim2.secCode);
      Optional<SecBoard> optionalSecBoard = watchedRfqSecBoards.stream().filter(secBoard -> secCode.equalsIgnoreCase(secBoard.getOriginalSecCode())).findFirst();
      return optionalSecBoard.isPresent() &&
         session.rfqs.get().isRfsSessionInitiator(optionalSecBoard.get().getSecCode());
   }
}
