package xfe.icap.modules.watchlist;

import static xfe.ui.table.Cells.asnNumberCell;
import static xfe.ui.table.Cells.asnUsdBondPriceNumberCell;
import static xfe.ui.table.Cells.asnStringCell;

import javafx.scene.layout.*;
import xfe.types.SecBoard;
import xfe.icap.XfeSession;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Callback;

import xfe.icap.types.BuySellDecorator;
import xstr.types.OrderSide;
import xstr.util.collection.UnequalObservableList;
import xfe.util.scene.control.Builders.LabelBuilder;
import xfe.util.scene.control.EnhancedTableView;
import xfe.util.scene.control.InfoPopup;
import xfe.icap.amp.AmpNLevelImplied;
import xfe.layout.LayoutManager;
import xstr.session.ObservableReplyRow;
import xfe.util.Constants;
import xfe.ui.table.DynamicTableCell;
import xfe.ui.table.TableCellFactory;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import xstr.util.Tuple2;

import java.util.Map;

public class InstrumentsInfoPopup extends InfoPopup implements Constants{
	public InstrumentsInfoPopup(
           Node node,
           LayoutManager<Node> layoutManager,
           String instrument,
           OrderSide orderSide,
           ObservableObjectValue<String> rate,
           ObservableObjectValue<String> quantity,
           ObservableList<ObservableReplyRow> rows,
           InstrumentsFilters filters,
           ObservableBooleanValue showing,
           XfeSession session) {
		super(node, showing, false);

		contentProperty().bind(new ObjectBinding<Region>() {
         { bind(detachedProperty()); }

         @Override
         protected Region computeValue() {
            boolean detached = detachedProperty().get();
            TableView<ObservableReplyRow> tableView = createTableView(detached, orderSide, rows, filters,session);
            VBox vbox = createDecorationPaneAttached(detached, tableView, instrument, orderSide, rate, quantity);
            vbox.getChildren().add(0, createDraggableHeaderPane("Implied Interrogation"));
            return vbox;
         }
		});
	}

	private static VBox createDecorationPaneAttached(
         boolean detached,
         TableView<ObservableReplyRow> asnTableView,
         String instrument,
         OrderSide orderSide,
         ObservableObjectValue<String> rate,
         ObservableObjectValue<String> quantity) {
		if (detached) {
			asnTableView.getStyleClass().add("detached");
		}

      ColumnConstraints colConstr0 = new ColumnConstraints();
      colConstr0.setHgrow(Priority.ALWAYS);
      ColumnConstraints colConstr1 = new ColumnConstraints();
      colConstr1.setHgrow(Priority.SOMETIMES);
      ColumnConstraints colConstr2 = new ColumnConstraints();
      colConstr2.setPrefWidth(10);
      ColumnConstraints colConstr3 = new ColumnConstraints();
      colConstr1.setHgrow(Priority.SOMETIMES);
		GridPane gridPane = new GridPane();
      gridPane.getStyleClass().add("xfe-info-grid");
      gridPane.getColumnConstraints().addAll(colConstr0, colConstr1, colConstr2, colConstr3);

		LabelBuilder infoLabelBuilder = LabelBuilder.create();
		if (detached) {
			infoLabelBuilder.styleClass("label", "xfe-grid-instrument-label");
		}

		gridPane.add(infoLabelBuilder.text(instrument).build(), 0, 0);

		LabelBuilder labelDataBuilder = LabelBuilder.create();
		if (!detached) {
			labelDataBuilder.styleClass("label", "xfe-label-data");
		} else {
			labelDataBuilder.styleClass("label", orderSide == OrderSide.BUY ? BUY_STYLE : SELL_STYLE);
		}

		Label rateLabel = labelDataBuilder.build();
		rateLabel.textProperty().bind(rate);

		Label qtyLabel = labelDataBuilder.build();
		qtyLabel.textProperty().bind(quantity);

		LabelBuilder labelBuilder = LabelBuilder.create();

		if (!detached) {
			labelBuilder.styleClass("label", "xfe-label");
		}

      Label rateInfoLabel = labelBuilder.text(orderSide == OrderSide.BUY ? "BID " : "OFFER ").build();

      HBox rateInfo = new HBox();
      rateInfo.getChildren().addAll(rateInfoLabel, rateLabel);

      HBox qtyInfo = new HBox();
      qtyInfo.getChildren().addAll(labelBuilder.text("QTY ").build(), qtyLabel);

		rateInfo.visibleProperty().bind(Bindings.isNotNull(rate));
		qtyInfo.visibleProperty().bind(Bindings.isNotNull(quantity));
		gridPane.add(rateInfo, 1, 0);
		gridPane.add(new Pane(), 2, 0);

		gridPane.add(qtyInfo, 3, 0);
		VBox infoContent = new VBox();

		if (!detached) {
			infoContent.getChildren().setAll(gridPane, asnTableView);
			infoContent.getStyleClass().add("xfe-info-content");
		} else {
		   StackPane detachedGridWrapper = new StackPane();
         detachedGridWrapper.getStyleClass().add("detached-grid-wrapper");
         detachedGridWrapper.getChildren().add(gridPane);
         StackPane detachedTableWrapper = new StackPane();
         detachedTableWrapper.getStyleClass().add("detached-table-wrapper");
         detachedTableWrapper.getChildren().add(gridPane);
			infoContent.getStyleClass().add("xfe-info-detached-content");
			infoContent.getChildren().setAll(detachedGridWrapper, detachedTableWrapper);
		}

		VBox decoration = new VBox();
		decoration.getStyleClass().add(!detached ? "xfe-info-decoration" : "xfe-info-detached-decoration");
      decoration.getChildren().add(infoContent);
      return decoration;
	}

	@SuppressWarnings("unchecked")
	private static TableView<ObservableReplyRow> createTableView(
           boolean detached,
           OrderSide orderSide,
           ObservableList<ObservableReplyRow> rows,
           InstrumentsFilters filters,
           XfeSession session) {
      Map<Tuple2<String, String>, SecBoard> secBoardMap = session.secBoards.get().getSecBoardsByKey();
		TableColumn<ObservableReplyRow, String> instrCol = new TableColumn<>();
		TableCellFactory.of(buySellStyle(
		      asnStringCell(AmpNLevelImplied.secCode)))
		      .textTooltip()
		      .strong()
		      .basic().setCellFactoryIn(instrCol);
		instrCol.setText(COLUMN_NAME_INSTR);
		instrCol.setPrefWidth(150);
		instrCol.setResizable(false);
		TableColumn<ObservableReplyRow, String> payRecCol = new TableColumn<>();
		Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
				DynamicTableCell.defaultCell(BuySellDecorator.fromOrderVerb(AmpNLevelImplied.impliedBuySell));
		TableCellFactory.of(
		      buySellStyle(cell))
		      .textTooltip()
		      .basic().setCellFactoryIn(payRecCol);
		payRecCol.setText("P/R");
		payRecCol.setPrefWidth(35);
		payRecCol.setResizable(false);
		TableColumn<ObservableReplyRow, String> rateCol = new TableColumn<>();
		TableCellFactory.of(buySellStyle(
                      asnUsdBondPriceNumberCell(AmpNLevelImplied.price, AmpNLevelImplied.secCode, AmpNLevelImplied.boardId,secBoardMap)))
                      .textTooltip()
                      .strong()
                      .basic().setCellFactoryIn(rateCol);
      rateCol.setText(Constants.COLUMN_NAME_RATE);
		rateCol.setPrefWidth(61);
		rateCol.setResizable(false);
		TableColumn<ObservableReplyRow, String> qtyCol = new TableColumn<>();
		TableCellFactory.of(buySellStyle(
		      asnNumberCell(AmpNLevelImplied.orderQty)))
		      .textTooltip()
		      .basic().setCellFactoryIn(qtyCol);
		qtyCol.setText("Order Qty");
		qtyCol.setPrefWidth(70);
		qtyCol.setResizable(false);
		TableColumn<ObservableReplyRow, String> iQtyCol = new TableColumn<>();
		TableCellFactory.of(buySellStyle(
		      asnNumberCell(AmpNLevelImplied.implyQty)))
		      .textTooltip()
		      .basic().setCellFactoryIn(iQtyCol);
		iQtyCol.setText("Imply Qty");
		iQtyCol.setPrefWidth(70);
		iQtyCol.setResizable(false);

		return new EnhancedTableView<ObservableReplyRow>() {{
			this.getColumns().setAll(instrCol, payRecCol, rateCol, qtyCol, iQtyCol);
			this.setItems(new UnequalObservableList<>(rows));
			this.getStyleClass().add("xfe-table");
		}};
	}

	private static class OrderStyleBinding extends StringBinding {
		int orderVerb = AmpOrderVerb.buyorsell;

		@Override
		protected String computeValue() {
			switch (orderVerb) {
			case AmpOrderVerb.buy:
				return BUY_STYLE;
			case AmpOrderVerb.sell:
				return SELL_STYLE;
			default:
				return "";
			}
		}

		public void setRow(ObservableReplyRow row) {
			if (row != null) {
				orderVerb = row.getValue(AmpNLevelImplied.impliedBuySell);
			} else {
				orderVerb = AmpOrderVerb.buyorsell;
			}

			invalidate();
		}
	}

	public static <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> buySellStyle(Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory) {
		return column -> {
            U cell = wrappedCellFactory.call(column);
            OrderStyleBinding orderStyle = new OrderStyleBinding();

            orderStyle.addListener((obsVal, oldStyle, newStyle) -> {
                if (oldStyle != null && !oldStyle.isEmpty()) {
                    cell.getStyleClass().remove(oldStyle);
                }

                if (newStyle != null && !newStyle.isEmpty()) {
                    cell.getStyleClass().add(newStyle);
                }
            });

            InvalidationListener listener = observable -> {
                int index = cell.getIndex();

                if (index < 0 || index >= cell.getTableView().getItems().size()) {
                    orderStyle.setRow(null);
                } else {
                    orderStyle.setRow(cell.getTableView().getItems().get(index));
                }
            };

            cell.itemProperty().addListener(listener);

            return cell;
        };
	}
}
