package xfe.icap.modules.watchlist;

import com.nomx.domain.types.InstrumentKey;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import xfe.util.scene.control.AsnTableRow;
import xstr.session.ObservableReplyRow;
import javafx.beans.property.ObjectProperty;
import javafx.collections.MapChangeListener;
import javafx.collections.ObservableList;
import xfe.ui.TriStateButton.State;

import static xfe.util.Constants.INSTRUMENT_FULL_HIGHTLIGHT;
import static xfe.util.Constants.INSTRUMENT_HALF_HIGHTLIGHT;

/**
 * Created by jiadin on 9/11/2015.
 */
class HighLightTableRow extends AsnTableRow {
   private final InstrumentsColumns columns;
   private final ObjectProperty<WatchlistSpec_v2> activeSpec;
   private InstrumentKey key;
   protected final ObservableList<String> styles = this.getStyleClass();

   private final MapChangeListener<InstrumentKey, State> hightlightKeyLis = new MapChangeListener<InstrumentKey, State>() {
      @Override
      public void onChanged(Change<? extends InstrumentKey, ? extends State> change) {
         if (key != null) {
            columns.toggleHighlight(key, styles);
         }
      }
   };

   HighLightTableRow(InstrumentsColumns columns, ObjectProperty<WatchlistSpec_v2> activeSpec) {
      this.columns = columns;
      this.activeSpec = activeSpec;
   }

   @Override
   protected void updateItem(ObservableReplyRow item, boolean empty) {
      super.updateItem(item, empty);
      columns.toggledRowsHeight.removeListener(hightlightKeyLis);
      if (item == null || empty) {
         key = null;
         styles.remove(INSTRUMENT_FULL_HIGHTLIGHT);
         styles.remove(INSTRUMENT_HALF_HIGHTLIGHT);
      }
      else {
         WatchlistSpec_v2 activeTab = activeSpec.get();
         if (activeTab == null) {
            key = null;
         } else {
            key = columns.createKey(activeTab.getId(), item, activeTab.isRfqOnly);
            columns.addListenerToToggleRowHeight(hightlightKeyLis);
            columns.toggleHighlight(key, styles);
         }
      }
   }
}
