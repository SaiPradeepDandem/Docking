package xfe.icap.types;

import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableStringValue;
import javafx.util.Callback;

import xstr.amp.AsnConversionAccessor;
import xstr.util.Fx;
import xstr.session.ObservableReplyRow;
import xfe.util.Constants;
import com.omxgroup.xstream.amp.AmpOrderVerb;

public abstract class BuySellDecorator {
	static class ImpliedBuySell {
		static final ObservableStringValue Unknown = Fx.constOf("");
	}

	public static Callback<ObservableReplyRow, ObservableStringValue> fromOrderVerb(AsnConversionAccessor<Integer> acc) {
		return new Callback<ObservableReplyRow, ObservableStringValue>() {
			@Override
			public ObservableStringValue call(ObservableReplyRow row) {
				if (row != null) {
					return new StringBinding() {
						private final ObservableObjectValue<Integer> val = row.getProperty(acc);
						{
							super.bind(val);
						}

						@Override
						protected String computeValue() {
							if(val == null || val.get() == null)
								return "";
							int value = val.get();
							return getAsString(value);
						}
					};
				}
				return ImpliedBuySell.Unknown;
			}
		};
	}

	public static String getAsString(int value) {
		switch (value) {
			case AmpOrderVerb.buy:
				return Constants.LABEL_PAY;
			case AmpOrderVerb.sell:
				return Constants.LABEL_REC;
			default:
				return Constants.LABEL_PAY +"/" + Constants.LABEL_REC;
		}
	}
}
