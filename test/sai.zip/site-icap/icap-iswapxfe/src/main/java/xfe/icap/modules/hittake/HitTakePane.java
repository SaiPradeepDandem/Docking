package xfe.icap.modules.hittake;

import com.nomx.domain.types.DefaultDurationType;
import com.nomx.domain.types.OnLogoffAction;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.ordersdata.OrderEntryData;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.Orders;
import xfe.ui.PresetSizeButtonsPane;
import xfe.ui.popover.XfePopOver;
import xfe.util.scene.control.DoubleTextField;
import xstr.session.ServerSession;
import xstr.session.XtrTransReply;
import xstr.types.MapWrapper;
import xstr.types.OrderSide;
import xstr.types.XtrBlob;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.function.Consumer;

public class HitTakePane {
   private static final Logger logger = LoggerFactory.getLogger(HitTakePane.class);

   @FXML
   private Parent root;

   @FXML
   private StackPane sizeButtonsPane;

   @FXML
   private DoubleTextField sizeTextField;

   @FXML
   private TextArea errorMsgField;

   private boolean isShared;
   private boolean isTopcut;
   private String popupSecCode;
   private String popupBoardId;
   private BigDecimal defaultQuantity;
   private BigDecimal hitTakePrice;
   private OrderSide orderSide;
   private ServerSession session;
   private XfePopOver popOver;
   private Consumer<String> closeHandler;
   private String orderTag;

   public Parent getRoot() {
      return root;
   }

   @FXML
   public void initialize(){
      root.setOnKeyPressed(event -> {
         if (event.getCode() == KeyCode.ESCAPE) {
            onClose();
         }
      });

      sizeTextField.setOnAction(event -> {
         Optional<Double> quantity = sizeTextField.getTextValue();
         quantity.ifPresent(aDouble -> onBidOffer(quantity.get()));
         root.requestFocus();
      });

      errorMsgField.managedProperty().bind(errorMsgField.visibleProperty());
   }

   private void enableQuantityTextField(DoubleTextField textField) {
      textField.setVisible(true);
      int decimals = 1;
      textField.setDecimals(decimals);
      textField.setValue(0.0);
      textField.positionCaret(0);
      textField.selectAll();
      textField.requestFocus();
      textField.setId("hitTakeTextField");
   }

   public void setup(OrderEntryData orderEntryData) {
      popupSecCode = orderEntryData.getSecCode();
      popupBoardId = orderEntryData.getBoardId();
      orderSide = orderEntryData.getSide();

      defaultQuantity = orderEntryData.getQty();
      hitTakePrice = orderEntryData.getPrice();
      isShared = orderEntryData.isShared();
      isTopcut = orderEntryData.isTopcut();
      orderTag = orderEntryData.getOrderTag();

      final EventHandler<ActionEvent> qtyBtnHandler = e -> {
         final double quantity = Double.parseDouble(((Button) e.getTarget()).getId());
         onBidOffer(quantity);
      };

      PresetSizeButtonsPane sizeButtons = new PresetSizeButtonsPane(4,
         defaultQuantity.doubleValue(),
         qtyBtnHandler,
         false,
         Color.WHITE,
         "xfe-custom-button");
      sizeButtonsPane.getChildren().add(sizeButtons);

      Platform.runLater(() -> enableQuantityTextField(sizeTextField));
   }

   private void onBidOffer(double quantity){
      AbstractOrderTrans orderTrans = new ManagedOrderTrans(null);

      orderTrans.setSecCode(popupSecCode);
      orderTrans.setBoardId(popupBoardId);

      // If this is a gilts spread we need to negate the price
      double orderPrice = hitTakePrice.doubleValue();
      orderTrans.setPrice(orderPrice);

      // we need to make sure that our size is >= minimum default size
      // otherwise show error and return
      if (quantity < defaultQuantity.doubleValue()){
         showErrorMessage("Entered QTY is less than Default QTY");
         return;
      }
      orderTrans.setQuantity(quantity);
      orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
      orderTrans.setShared(isShared);
      orderTrans.setTopCut(isTopcut);
      orderTrans.setOnLogOffAction(OnLogoffAction.Default);
      final MapWrapper mapWrapper = new MapWrapper();
      mapWrapper.put(Orders.ORDER_TAG_KEY,new XtrBlob(orderTag.getBytes()));
      orderTrans.setMapWrapper(mapWrapper);
      orderTrans.executeBuySell(session,
         orderSide.equals(OrderSide.BUY) ? AmpOrderVerb.sell : AmpOrderVerb.buy).onDone(x -> {
         if (x.get().getStatus() == XtrTransReply.Status.RESULT_OK) {
            onClose();
         } else {
            String errorMsg = x.get().getMessage();
            logger.error("Hit/Take: {}", errorMsg);
            showErrorMessage(errorMsg);
         }
         return Future.SUCCESS;
      });
   }

   private void onClose() {
      if (popOver != null) {
         if (closeHandler != null) {
            closeHandler.accept(popOver.id());
         }
         popOver.hide();
         popOver = null;
      }
      errorMsgField.setText("");
   }

   void setSession(ServerSession session) {
      this.session = session;
   }
   void setPopover(XfePopOver p) {
      this.popOver = p;
   }

   void setCloseHandler(Consumer<String> closeHandler) {
      this.closeHandler = closeHandler;
   }

   private void showErrorMessage(String errorMsg) {
      errorMsgField.setText(errorMsg);
      errorMsgField.setVisible(true);
      root.getScene().getWindow().sizeToScene();
   }



}
