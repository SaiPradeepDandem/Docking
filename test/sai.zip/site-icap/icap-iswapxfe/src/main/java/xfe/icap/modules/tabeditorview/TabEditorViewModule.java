package xfe.icap.modules.tabeditorview;

import com.nomx.persist.ParametersStorage;
import com.nomx.persist.PersistantName;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settingsview.SettingsViewTab;
import xfe.icap.modules.settingsview.SettingsViewModule;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.types.SecBoards;
import xfe.types.SettingsRoot;
import xfe.util.EasyFXML;
import xstr.util.Fun1;
import xstr.util.concurrent.Future;

import java.util.List;
import java.util.Optional;

@Module.Autostart
public class TabEditorViewModule extends SessionScopeModule implements SettingsViewTab {
   private static final Logger logger = LoggerFactory.getLogger(TabEditorViewModule.class);

   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public SettingsViewModule settingsViewModule;
   @ModuleDependency
   public XfeSession xfeSession;

   @Override
   public Future<Void> startModule() {
      this.tabEditorLayout = EasyFXML.load(TabEditorLayout.class);
      final SecBoards secBoards = xfeSession.secBoards.get();
      // Creating the tab editor view only when all the SecBoards are loaded.
      secBoards.ready().onSuccess(new Fun1<Boolean, Void>() {
         @Override
         public Void call(Boolean a) {
            tabEditorLayout.createView(secBoards, configurationModule.getWatchlists());
            return null;
         }
      });
      // TODO: Select the appropriate WatchlistSpec_v2 in listview based on current selection in instruments tab.
      settingsViewModule.addView(getRoot(), this);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      settingsViewModule.removeView(getRoot(), this);
      tabEditorLayout.getWatchlistEditView().dispose();
      return Future.SUCCESS;
   }

   public Node getRoot() {
      return this.tabEditorLayout.getRoot();
   }

   @Override
   public boolean isModified() {
      return tabEditorLayout.isModified();
   }

   @Override
   public void resetForTestFX() {
      if(ParametersStorage.TESTFX_DATA!=null) {
         List<WatchlistSpec_v2> watchList =
                 (List<WatchlistSpec_v2>) SettingsRoot.unmarshallJson(ParametersStorage.TESTFX_DATA).get(PersistantName.WatchlistTabs);
         tabEditorLayout.getWatchlistEditView().populateFrom(watchList);
         save();
      }
   }

   @Override
   public Future<Void> save() {
      // Do not check isModified again because save only called after checking isModified so it's wasting process.
      final List<WatchlistSpec_v2> instrSpecs = tabEditorLayout.getTabsListViewItems();
      // Marking the current selected tab in listview.
      final WatchlistSpec_v2 currentWL = tabEditorLayout.getWatchlistEditView().getCurrentTab();
      instrSpecs.forEach(instrSpec -> {
         boolean selected = currentWL != null && instrSpec.getId().equals(currentWL.getId());
         instrSpec.setSelectedInTabListView(selected);
      });
      tabEditorLayout.save();

      xfeSession.secBoards.get().findAll(secBoards -> {
         final List<WatchlistSpec_v2> newSpecs = WatchlistSpec_v2.updateFullProducts(instrSpecs, secBoards);
         final ObservableList<WatchlistSpec_v2> configInstList = configurationModule.getWatchlists();
         newSpecs.forEach(newWatchListSpec -> {
            final Optional<WatchlistSpec_v2> configWatchListSpec = configInstList.stream().filter(cwl -> newWatchListSpec.getId().equals(cwl.getId())).findFirst();
            //configWatchListSpec.ifPresent(newWatchListSpec::updateColumnSettingsFrom);
         });
         configurationModule.getWatchlists().setAll(newSpecs);
         return null;
      });
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> reset() {
      tabEditorLayout.reset();
      return Future.SUCCESS;
   }

   @Override
   public void onShown() {
      final Optional<WatchlistSpec_v2> activeTab = configurationModule.getWatchlists().stream().filter(WatchlistSpec_v2::isSelectedInTabListView).findFirst();
      activeTab.ifPresent(tabEditorLayout.getWatchlistEditView()::setActiveTab);
   }

    private TabEditorLayout tabEditorLayout;
}
