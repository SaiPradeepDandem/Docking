package xfe.icap.modules.dev;

import ch.qos.logback.classic.Level;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.XfeAppModule;
import xfe.app.XfeApplicationContext;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.module.Module;
import xfe.modules.layout.FxLayoutManager;
import xfe.modules.skin.XfeSkin;
import xfe.types.UiSession;
import xfe.ui.CssSkin;
import xfe.ui.notifications.ModalAlertModule;
import xfe.util.Util;
import xfe.util.scene.MonitorWindow;
import xstr.util.concurrent.Disposer;
import xstr.util.concurrent.Future;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;

public class DevModule implements Module {
   static final Logger logger = LoggerFactory.getLogger(DevModule.class);

   @ModuleDependency
   public XfeApplicationContext appContextModule;
   @ModuleDependency
   public XfeAppModule appModule;
   @ModuleDependency
   public XfeSkin skinModule;
   @ModuleDependency
   public UiSession sessionModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;

   private static final int ONE_MB = 1024*1024;

   private static double bytesToMb(long bytes) {
      return (int)(bytes * 10. / ONE_MB ) / 10.;
   }

   private Menu getDevMenuNode() {

      Menu logLevelMenu = new Menu("Log Level");
      ToggleGroup toggleGroup = new ToggleGroup();
      ch.qos.logback.classic.Logger rootLogger = (ch.qos.logback.classic.Logger)LoggerFactory.getLogger("root");
      RadioMenuItem errorLog = createMenuItem("Error",toggleGroup,rootLogger);
      RadioMenuItem warnLog = createMenuItem("Warn",toggleGroup,rootLogger);
      RadioMenuItem infoLog = createMenuItem("Info",toggleGroup,rootLogger);
      RadioMenuItem debugLog = createMenuItem("Debug",toggleGroup,rootLogger);
      RadioMenuItem traceLog = createMenuItem("Trace",toggleGroup,rootLogger);
      RadioMenuItem allLog = createMenuItem("All",toggleGroup,rootLogger);
      MenuItem advLog = createAdvItem();
      logLevelMenu.getItems().setAll(errorLog,warnLog,infoLog,debugLog,traceLog,allLog,advLog);

      if (devMenu == null) {
         devMenu = new Menu("Developer Options");
         devMenu.getItems().setAll(monitorButton, eraseSettingsButton, exportSettingsButton, exportSettingsJsonButton, hogMemoryButton, logLevelMenu);
      }

      return devMenu;
   }

   @Override
   public Future<Void> startModule() {
      monitorButton.setOnAction(actionEvent -> showMonitor());
      hogMemoryButton.setOnAction(actionEvent -> {
         double maxMem = bytesToMb(Runtime.getRuntime().maxMemory());
         double totalMem = bytesToMb(Runtime.getRuntime().totalMemory());
         double freeMem = bytesToMb(Runtime.getRuntime().freeMemory());
         double toAllocate = freeMem / 5;
         System.gc();System.gc();
         logger.info("Before forced memory increase: Max: {}Mb, Used: {}Mb Free: {}Mb", maxMem, totalMem, freeMem);
         logger.info("Before forced memory increase: Attempting to allocate {}Mb", toAllocate);
         // Allocate in chunks of 1Mb bytes to prevent out of memory due to fragmentation
         while (toAllocate > 0) {
            try {
               heldMem.add(new Byte[ONE_MB]);
               toAllocate--;
            } catch (OutOfMemoryError e) {
               logger.info("Out Of memory reached with {}Mb not yet allocated", toAllocate);
               break;
            }
         }
         System.gc();System.gc();
         maxMem = bytesToMb(Runtime.getRuntime().maxMemory());
         totalMem = bytesToMb(Runtime.getRuntime().totalMemory());
         freeMem = bytesToMb(Runtime.getRuntime().freeMemory());
         logger.info("After forced memory increase: Max: {}Mb, Used: {}Mb, Free: {}Mb", maxMem, totalMem, freeMem);
      });

      eraseSettingsButton.setOnAction(actionEvent -> {
         try {
            configurationModule.eraseAppConfig();
            if (configurationModule.getData().autoSaveWorkspaceProperty().get()) {
               new Alert(
                  Alert.AlertType.INFORMATION,
                  "Auto Save will be disabled to prevent settings from being saved on exit.",
                  ButtonType.OK).showAndWait().ifPresent(b -> {
                  configurationModule.getData().autoSaveWorkspaceProperty().set(false);
               });
            }
         } catch (Exception e) {
            logger.error("Unable to erase settings: ", e);
         }

      });

      exportSettingsButton.setOnAction(actionEvent -> {
         FileChooser fileChooser = new FileChooser();

         fileChooser.setTitle("Export watch tab settings");

         File file = fileChooser.showSaveDialog(appModule.getStage());

         if (file != null) {
            Disposer disposer = new Disposer();

            try {
               FileOutputStream outputStream = disposer.disposes(new FileOutputStream(file));
               configurationModule.writeAppConfigToStream(outputStream, null);
            } catch (FileNotFoundException e) {
               e.printStackTrace();
            } finally {
               disposer.dispose();
            }
         }

      });

      exportSettingsJsonButton.setOnAction(actionEvent -> {
         FileChooser fileChooser = new FileChooser();

         fileChooser.setTitle("Export watch tab settings");

         File file = fileChooser.showSaveDialog(appModule.getStage());

         if (file != null) {
            Disposer disposer = new Disposer();

            try {
               FileOutputStream outputStream = disposer.disposes(new FileOutputStream(file));
               configurationModule.writeAppConfigToStream(outputStream, null);
            } catch (FileNotFoundException e) {
               e.printStackTrace();
            } finally {
               disposer.dispose();
            }
         }
      });

      enableDevFeatures();

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      appContextModule.removeMenu(getDevMenuNode());
      return Future.SUCCESS;
   }

   private MenuItem createAdvItem() {
      MenuItem rtn = new MenuItem("Advance");
      rtn.setOnAction(event -> {

         if(loggerConfigStage == null){
            this.loggerConfigStage = new Stage();
            loggerLevelConfigView = new LoggerLevelConfigView();
//            loggerLevelConfigView.setOnClose(() -> modalAlertModule.hideModalView(loggerLevelConfigView));
            loggerLevelConfigView.setOnClose(() -> {
               if (loggerConfigStage != null) {
                  loggerConfigStage.close();
                  loggerConfigStage = null;
               }
            });
            loggerConfigStage.setScene(new Scene(loggerLevelConfigView.getRootElement()));
         }
//         modalAlertModule.showModalView(loggerLevelConfigView);
      });
      return  rtn;
   }

   private RadioMenuItem createMenuItem(String name, ToggleGroup toggleGroup, ch.qos.logback.classic.Logger rootLogger) {
      RadioMenuItem rtn = new RadioMenuItem(name);
      Level level = Level.toLevel(name.toUpperCase());
      rtn.setOnAction(event -> rootLogger.setLevel(level));
      rtn.setToggleGroup(toggleGroup);
      if(level.equals(rootLogger.getLevel())){
         rtn.setSelected(true);
      }
      return rtn;
   }

   private void enableDevFeatures() {
      appContextModule.addMenu(getDevMenuNode(), 9999);
      CssSkin baseSkin = new CssSkin("base", "base", "/css/base.css", null);
      skinModule.addSkin(baseSkin);
//      CssSkin demoSkin = new CssSkin("demo", "demo", "/css/demo.css", baseSkin);
//      skinModule.addSkin(demoSkin);
      String pp = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
      Path classPathRoot = Paths.get(pp.substring(1));
      skinModule.enableCssFileScan(classPathRoot);
      CssSkin iswapBase = new CssSkin("iswap", "iswap",  "/css/iswap.css", baseSkin);
      skinModule.addSkin(new CssSkin("iswap_classic", "dev > iswap (classic)", "/css/iswap_classic.css", iswapBase));
   }

   private void showMonitor() {
      MonitorWindow.show(startTime);
   }
   private final Date startTime = new Date();
   private final MenuItem monitorButton = new MenuItem("Monitor");
   private final ArrayList<Byte[]> heldMem = new ArrayList<>();
   private final MenuItem hogMemoryButton = new MenuItem("Increase memory usage");
   private final MenuItem eraseSettingsButton = new MenuItem("Erase Settings");
   private final MenuItem exportSettingsButton = new MenuItem("Export Settings (XML) ...");
   private final MenuItem exportSettingsJsonButton = new MenuItem("Export Settings (JSON) ...");
   private Menu devMenu;
   private LoggerLevelConfigView loggerLevelConfigView;
   private Stage loggerConfigStage;
}
