package xfe.icap.modules.orderentry;

import com.google.common.base.Strings;
import xfe.icap.types.*;
import xfe.types.SecBoard;
import xfe.types.SecurityInfo;
import xfe.types.StepArray;
import xstr.amp.AMP;
import xstr.session.XtrTransRequestBuilder;
import xstr.session.XtrTransReply;
import xstr.session.XtrTransReply.Status;
import xstr.util.Fx;
import xstr.util.collection.XstrCollections;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpRfqAcc;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.modules.orderentry.Command.ActionType;
import xfe.modules.orderentry.RfqView;
import xfe.modules.orderentry.RfqView.Presenter;
import xfe.modules.session.SessionModule;
import xfe.icap.modules.settings.SettingsUIModule;
import xstr.session.ObservableReplyRow;
import xfe.ui.notifications.ModalAlertModule;
import com.objsys.asn1j.runtime.Asn1Choice;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import com.omxgroup.xstream.amp.AmpRFQStatus;
import com.omxgroup.xstream.amp.AmpReplyOK;
import com.omxgroup.xstream.amp.AmpSecBoardId;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.Fun1Throws;
import xstr.util.concurrent.*;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.io.UnsupportedEncodingException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;

public abstract class RfqPresenter extends DisposableBase implements Presenter<Node> {
   private static final Logger logger = LoggerFactory.getLogger(RfqPresenter.class);

   private final Disposer disposer = new Disposer();
   private final SelectionContextModule selectionContextModule;
   private final RfqView<Node> view;
   private final XfeSession session;
   private final SessionModule sessionModule;
   private final ObjectProperty<SelectionContext> selectionContextProperty = new SimpleObjectProperty<>();
   private final ObjectProperty<ObservableReplyRow> amendableOrderRowProperty = new SimpleObjectProperty<>();

   private SecBoardContext getSecBoardContext() {
      return entryModule.selectionContextModule.secBoardContext.get();
   }

   private final ModalAlertModule notifier;

   private final EntryModule entryModule;

   private final DataContextModule dataContextModule;
   private final SettingsUIModule settings;

   public BooleanProperty pendingDatesProperty() {
      return pendingDates;
   }

   private final BooleanProperty pendingDates = new SimpleBooleanProperty(true);
   private final ObjectProperty<ObservableValue<Integer>> selectedRfqStatusObject = new SimpleObjectProperty<>();

   RfqPresenter(
      XfeSession session,
      SessionModule sessionModule,
      EntryModule entryModule,
      SettingsUIModule settings, ModalAlertModule notifier, SelectionContextModule selectionContextModule, DataContextModule dataContextModule, RfqPane view) {
      this.entryModule = entryModule;
      this.notifier = notifier;
      this.dataContextModule = dataContextModule;
      this.selectionContextModule = selectionContextModule;
      this.settings = settings;
      this.view = view;
      this.session = session;
      this.sessionModule = sessionModule;
      // Create a dummy transaction to make sure all the required classes are loaded now
      // This is done in an attempt to prevent delays related to class loading when the
      // user submits the first order transaction
      AbstractOrderTrans dummyTrans = new ManagedOrderTrans(notifier);
      dummyTrans = new OrderTrans(notifier);
      dummyTrans = new OrderTrans(notifier);
      dummyTrans.setDoneIfTouched(true);

//      getSecBoardContext().defaultStrategyQtyProperty().bind(entryModule.prefs.strategyDefaultQty());
//      getSecBoardContext().defaultOutrightQtyProperty().bind(entryModule.prefs.outrightDefaultQty());

      ObjectProperty<Double> bidSizeProperty = new SimpleObjectProperty<>(this, "bidSizeProperty");
      bidSizeProperty.bind(getSecBoardContext().bidSizeProperty());
      ObjectProperty<Double> offerSizeProperty = new SimpleObjectProperty<>(this, "offerSizeProperty");
      offerSizeProperty.bind(getSecBoardContext().offerSizeProperty());
      spinQuantityStepArray.bind(getSecBoardContext().spinQtyStepsProperty());

      //Lazy<ObservableSet<String>> allFirms = session.mmFirms.get().firms;
      RfqMarketMakers rfqMMs = session.mmFirms.get();
      if (rfqMMs.readyProperty.getValue()) {
         view.setAllFirms(rfqMMs.firms.get());
      } else {
         rfqMMs.readyProperty.addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
               if (newValue) {
                  view.setAllFirms(rfqMMs.firms.get());
                  rfqMMs.readyProperty.removeListener(this);
               }
            }
         });
      }
   }

   private final ObjectProperty<StepArray> spinQuantityStepArray = new SimpleObjectProperty<>();

   double getDefaultSize(){
      return getSecBoardContext().getDefaultQty();
   }

   public StepArray getQuantityStepArray() {
      return quantityStepArrayProperty().get();
   }

   public void setQuantityStepArray(StepArray quantityStepArray) {
      quantityStepArrayProperty().set(quantityStepArray);
   }

   private ObjectProperty<StepArray> quantityStepArrayProperty() {
      return spinQuantityStepArray;
   }

   private final ObjectProperty<SecurityInfo> securityInfoProperty = new SimpleObjectProperty<>();

   public SecurityInfo getSecurityInfo() {
      return securityInfoProperty().get();
   }

   private ObjectProperty<SecurityInfo> securityInfoProperty() {
      return securityInfoProperty;
   }

   private final DisposableSlot<Disposer> viewDisposerSlot = disposer.disposes(new DisposableSlot<>());

   void initView() {

      view.setPresenter(this);
      view.getRootElement();

      Disposer viewDisposer = viewDisposerSlot.disposeAndSet(new Disposer());
      viewDisposer.disposes(Fx.bind(view.quantityStepArrayProperty(), this.spinQuantityStepArray));
      viewDisposer.disposes(Fx.addWeakListener(getSecBoardContext().rowProperty(), (obsVal, oldVal, newVal) -> {
         if (newVal == null) {
            return;
         }

         SelectionContext ctx = selectionContextProperty.get();

         if (ctx == null) {
            return;
         }

         String oldName = null;
         if (oldVal != null)
            oldName = oldVal.getValue(AmpIcapSecBoardTrim2.secCode);
         String newName = newVal.getValue(AmpIcapSecBoardTrim2.secCode);

         if (oldName != null && oldName != "" && newName.contains(oldName)) return;

         switch (ctx.grid) {
         case Watchlist:
            setSize(getSecBoardContext().getDefaultQty());
            default:
         }
      }));

      InvalidationListener rfqStatusLis = new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            observable.removeListener(this);
            entryModule.orderEntryPane.get().isInstrumentOrderable(true);
            entryModule.orderEntryPane.get().enableOrderEntry(!sessionModule.safeModeProperty().get());
         }
      };


      viewDisposer.disposes(Fx.addWeakListener(selectionContextModule.secBoardContext.get().liveSecBoard.get(), (observable, oldValue, newValue) -> {
            if (newValue == null) {
               view.enableRfq(false);
            } else {
               view.enableRfq(true);
               SecBoard secBoard = ((ObservableValue<SecBoard>) observable).getValue();
               if (secBoard == null) return;
               entryModule.orderEntryPane.get().isInstrumentOrderable(true);
               entryModule.orderEntryPane.get().enableOrderEntry(!sessionModule.safeModeProperty().get());
               String parentCode = Strings.isNullOrEmpty(secBoard.getOriginalSecCode()) ? secBoard.getSecCode() : secBoard.getOriginalSecCode();
               if (!Strings.isNullOrEmpty(parentCode)) {
                  List<String> mmOfInstrument = session.mmFirms.get().firmsByInstrument.get().get(secBoard.getInstrumentId());
                  boolean isMarketMaker = session.traderFirmMap != null && XstrCollections.anyIntersection(mmOfInstrument, session.traderFirmMap.getGroup());
                  if (!isMarketMaker) {
                     String secCode = secBoard.getSecCode();
                     String boardId = secBoard.getBoardId();
                     if (session.rfqs.get().isActiveRfq(secCode, boardId) == null) {
                        return;
                     }
                     ObservableValue<Integer> status = session.rfqs.get().liveBooleanisRfqInitStatus(secCode, boardId);
                     if (status.getValue() == AmpRFQStatus.initial) {
                        entryModule.orderEntryPane.get().enableOrderEntry(false);
                        entryModule.orderEntryPane.get().isInstrumentOrderable(false);
                        selectedRfqStatusObject.set(status);
                     }
                  }
               }
            }
         }
      ));

      selectedRfqStatusObject.addListener((observable, oldValue, newValue) -> {
         if(oldValue!=null){
            oldValue.removeListener(rfqStatusLis);
         }
         if(newValue!=null){
            newValue.addListener(rfqStatusLis);
         }
      });

      viewDisposer.disposes(new DisposableBase() {
         @Override
         protected Future<Void> dispose(boolean disposing) {
            ObservableValue<Integer> rfqStatusValue = selectedRfqStatusObject.getValue();
            if(rfqStatusValue!=null){
               rfqStatusValue.removeListener(rfqStatusLis);
            }
            return super.dispose(disposing);
         }
      });
      viewDisposer.disposes(Fx.bind(view.sizeDecimalsProperty(), getSecBoardContext().spinQtyDecimalsProperty()));
   }

   private Double getDoubleEditVal(String strVal) {
      if (strVal.isEmpty()) {
         return null;
      }

      if (strVal.equals("-")) {
         return 0.0;
      }

      NumberFormat format = NumberFormat.getInstance();
      try {
         return format.parse(strVal).doubleValue();
      } catch (ParseException e) {
         logger.error("Failed to populate order transaction", e);
      }

      return null;
   }

   public Future<Boolean> onSubmit(boolean isRfsSession) {
      return entryModule.doBespoke(
         getSecBoardContext().getSecCode(),getSecBoardContext().getBoardId(),isRfsSession
      ).flatMap(ampSecBoardId -> initiateRFQ(ampSecBoardId, isRfsSession));
   }

   private Future<Boolean> initiateRFQ(AmpSecBoardId secBoardId, boolean isRfsSession){
      try {
         if (secBoardId == null ||
             secBoardId.getSecCode().value == null ||
             secBoardId.getBoardId().value == null) {
            logger.error("Cannot initiate RFQ/RFS session for invalid secboard");
            return Future.valueOf(false);
         }

         if (isRfsSession && !selectionContextModule.dataContextRfsSec.get()) {
            logger.error("Rfs Session only allowed in RFS instruments");
            return Future.valueOf(false);
         }
         String secCode = new String(secBoardId.getSecCode().value, "US-ASCII");
         String boardId = new String(secBoardId.getBoardId().value, "US-ASCII");
         // "RBS", "AIB", "AIG GRP"
         //for RFS session, need to set: mmgrouplist is empty, maxQuantity is zero, anonymous is true.
         XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(AmpRfqAcc.txn, session.getUnderlyingSession())
            .set(AmpRfqAcc.secCode, secCode)
            .set(AmpRfqAcc.boardId, boardId)
            .set(AmpRfqAcc.maxQuantity,
               isRfsSession ?
                  0D :
                  getDoubleEditVal(view.getSizeText()))
            .set(AmpRfqAcc.fullAmount,
               isRfsSession ?
                  false :
                  view.getFullSize())
            .set(AMP.tREQ("rfq.mmGroupList"),
               isRfsSession ?
                  new String[0] :
                  view.getFirms())
            .set(AmpRfqAcc.anonymous,
               isRfsSession || settings.getData().rfqAnonymousProperty().get())
            .set(AMP.tREQ("rfq.clearingHouseList"), new String[0]);

         if (isRfsSession) {
            reqBuilder = reqBuilder.set(AmpRfqAcc.minQuantity, 0D);
            reqBuilder =  reqBuilder.set(AmpRfqAcc.buySell, AmpOrderVerb.buyorsell);
            if (ActionType.MINE.equals(entryModule.orderEntryPresenter.get().getActionType())) {
               reqBuilder = reqBuilder.set(AmpRfqAcc.buySell, AmpOrderVerb.buy);
            } else if(ActionType.YOURS.equals(entryModule.orderEntryPresenter.get().getActionType())) {
               reqBuilder = reqBuilder.set(AmpRfqAcc.buySell, AmpOrderVerb.sell);
            }
         } else {
            boolean isBid = view.getRequestBids();
            boolean isOffer = view.getRequestOffers();

            if (isBid != isOffer) {
               reqBuilder = isBid ? reqBuilder.set(AmpRfqAcc.buySell, AmpOrderVerb.sell) : reqBuilder.set(AmpRfqAcc.buySell, AmpOrderVerb.buy);
            }
         }

         return session.getUnderlyingSession().execute(reqBuilder.build()).flatMap(new Fun1Throws<XtrTransReply, Future<Boolean>>() {
            @Override
            public Future<Boolean> call(XtrTransReply reply) throws Exception {
               Asn1Choice replyChoice = reply.getReplyChoice();

               if (replyChoice != null) {
                  Asn1Type replyElement = replyChoice.getElement();
                  if (replyElement != null && replyElement instanceof AmpReplyOK) {
                     AmpReplyOK replyOk = (AmpReplyOK)replyElement;
                     AmpSecBoardId secBoardId1 = replyOk.getSecBoardId();

                     if (secBoardId1.getSecCode().value == null || secBoardId1.getBoardId().value == null) {
                        logger.error("Cannot anticipate select for invalid secboard");
                        return Future.valueOf(false);
                     }

                     String secCode1 = new String(secBoardId1.getSecCode().value, "US-ASCII");
                     String boardId1 = new String(secBoardId1.getBoardId().value, "US-ASCII");

                     if (reply.getStatus() == Status.RESULT_OK) {
                        entryModule.rotateToOrderEntry();
                        return entryModule.watchlistModule.selectOrDefer(secCode1, boardId1);
                     } else {
                        logger.error("Rfq creation failed with status {}", reply.getStatus());
                     }
                  } else {
                     logger.error("Rfq reply not OK: {}", replyElement);
                  }
               } else {
                  logger.error("Rfq reply failed: Invalid reply choice");
               }
               return Future.valueOf(false);
            }
         });
      } catch (AmpPermissionException | AsnTypeException e) {
         notifier.showError(e.getMessage());
         return Futures.error(e);
      } catch (UnsupportedEncodingException e) {
         logger.error("Encoding error:", e);
         return Futures.error(e);
      }
   }

   public void setSecurityData(IcapSecurity security) {

   }

   private void setSize(Double size) {
      if (size != null) {
         entryModule.rfqSizeEditProperty.get().set(size);
      } else {
         entryModule.rfqSizeEditProperty.get().set(0.0);
      }
   }

   public void setQuantityDecimals(int quantityDecimals) {
      view.setSizeDecimals(quantityDecimals);
   }

   public SelectionContext getSelectionContext() {
      return selectionContextProperty.get();
   }

   public ObjectProperty<SelectionContext> selectionContextProperty() {
      return selectionContextProperty;
   }

   public void setAmendableOrder(ObservableReplyRow row) {
      amendableOrderRowProperty.set(row);
   }

   public ObservableReplyRow getAmendableOrder() {
      return amendableOrderRowProperty.get();
   }

   public ObjectProperty<ObservableReplyRow> amendableOrderProperty() {
      return amendableOrderRowProperty;
   }

   void setPendingDates(boolean isPending) {
      pendingDates.set(isPending);
   }
}
