package xfe.icap.types;

import java.util.*;

import javafx.collections.ListChangeListener.Change;
import xfe.icap.amp.AmpRfq;
import xstr.util.ListenerTracker;

import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.*;
import javafx.collections.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.session.QueryFeed;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import xstr.util.collection.ObservableCollections;
import xstr.util.filter.*;
import xstr.session.ObservableReplyRow;
import xfe.util.Constants;
import com.omxgroup.xstream.amp.*;
import xstr.util.Lazy;
import xstr.util.Tuple3;
import xstr.session.ObservableReplyRow.ObservableRowFactory;

public class Rfqs implements Constants{
   private final FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpRfq.rep,new ObservableRowFactory());
   private static final Logger logger = LoggerFactory.getLogger(Rfqs.class);

   private final Lazy<ObservableList<ObservableReplyRow>> rfqs = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return Fx.unmodifiable(aggregator.items);
      }
   };


   public final Lazy<ObservableList<ObservableReplyRow>> initRfqs = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(rfqs.get(), RowFilters.equals(AmpRfq.status, AmpRFQStatus.initial),tracker);
      }
   };

   public final Lazy<ObservableList<ObservableReplyRow>> activeRfqs = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(rfqs.get(), RowFilters.equalsAny(AmpRfq.status, AmpRFQStatus.initial, AmpRFQStatus.active), tracker);
      }
   };

   final Lazy<ObservableList<ObservableReplyRow>> activeRfqWithoutRfsSession = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(activeRfqs.get(), RowFilters.greaterThan(AmpRfq.maxQuantity,0D),tracker);
      }
   };

   public final Lazy<ObservableList<ObservableReplyRow>> activeRfsSession = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(activeRfqs.get(), RowFilters.greaterThan(AmpRfq.maxQuantity,0D).not(),tracker);
      }
   };

   public final Lazy<ObservableList<ObservableReplyRow>> finishedRfqs = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(rfqs.get(), RowFilters.equals(AmpRfq.status, AmpRFQStatus.finished),tracker);

      }
   };

   public final Lazy<ObservableList<ObservableReplyRow>> sortByEndingFinalPhaseRfqs = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return Fx.sortBy(finalPhaseRfqsInitialtedByLogginUser.get(), (o1, o2) -> {
            Date endTime1 = o1.getValue(AmpRfq.endTime);
            Date endTime2 = o2.getValue(AmpRfq.endTime);
            if (endTime1 == null || endTime2 == null || endTime1.equals(endTime2)) return 0;
             return endTime1.after(endTime2) ? 1: -1;
         });

      }
   };

   public final Lazy<ObservableList<ObservableReplyRow>> endedRfqs = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(rfqs.get(), RowFilters.equalsAny(AmpRfq.status, AmpRFQStatus.finished,AmpRFQStatus.cancelled),tracker);

      }
   };

   /*
    * In final phase stage, the status is active
    */
   public final Lazy<ObservableList<ObservableReplyRow>> finalPhaseRfqs = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(rfqs.get(), RowFilters.equals(AmpRfq.status, AmpRFQStatus.active),tracker);

      }
   };

   /*
 * In final phase stage, the status is active
 */
   public final Lazy<ObservableList<ObservableReplyRow>> finalPhaseRfqsInitialtedByLogginUser = new Lazy<ObservableList<ObservableReplyRow>>() {
      @Override
      protected ObservableList<ObservableReplyRow> initialize() {
         return ObservableCollections.filter(finalPhaseRfqs.get(), RowFilters.equals(AmpRfq.userId, loggedOnUserId),tracker);

      }
   };

   private final String loggedOnUserId;
   private final ListenerTracker tracker;
   public Rfqs(ServerSession session, ListenerTracker tracker) {
      this.tracker = tracker;
      loggedOnUserId = session.getLoggedOnUserId();
      QueryFeed feed = session.getFeedSource(AmpRfq.req);
      feed.addListener(aggregator);

      if (logger.isTraceEnabled()) {
         Fx.delay(10000, () -> {
            logger.debug("added listeners to all lists:");

            activeRfqs.get().addListener((Change<? extends ObservableReplyRow> c) -> {
               while (c.next())
                  logger.debug("activeRfq added list:" + c.getAddedSubList() + "\n removed list:" + c.getRemoved());
            });
            activeRfqWithoutRfsSession.get().addListener((Change<? extends ObservableReplyRow> c) -> {
               while (c.next())
                  logger.debug("activeRfqWithoutRfsSession added list:" + c.getAddedSubList() + "\n removed list:" + c.getRemoved());
            });

            activeRfsSession.get().addListener((Change<? extends ObservableReplyRow> c) -> {
               while (c.next())
                  logger.debug("activeRfsSession added list:" + c.getAddedSubList() + "\n removed list:" + c.getRemoved());
            });

            rfqs.get().addListener((Change<? extends ObservableReplyRow> c) -> {
               while (c.next())
                  logger.debug("rfqs added list:" + c.getAddedSubList() + "\n removed list:" + c.getRemoved());
            });

            finalPhaseRfqs.get().addListener((Change<? extends ObservableReplyRow> c) -> {
               while (c.next())
                  logger.debug("finalPhaseRfqs added list:" + c.getAddedSubList() + "\n removed list:" + c.getRemoved());
            });

            finishedRfqs.get().addListener((Change<? extends ObservableReplyRow> c) -> {
               while (c.next())
                  logger.debug("finishedRfqs added list:" + c.getAddedSubList() + "\n removed list:" + c.getRemoved());
            });
         });
      }
   }

//   /**
//    * For count down timer
//    */
//   public ObservableReplyRow isRfqInFinalPhaseAndRtnRow(final String instrCode, final String boardId) throws Exception {
//      for (final ObservableReplyRow aRow : finalPhaseRfqs.get()) {
//         if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.endsWith(aRow.getString(AmpRfq.boardId))) {
//            return aRow;
//         }
//      }
//      return null;
//   }

   public ObservableValue<Boolean> liveBooleanisRfqFinalPhase(String instrCode, String boardId) {
      return new BooleanBinding() {
         {
            bind(finalPhaseRfqs.get());
         }

         @Override
         protected boolean computeValue() {
            return isRfqInFinalPhase(instrCode, boardId);
         }

      };
   }


   public ObservableValue<Integer> liveBooleanisRfqInitStatus(String instrCode, String boardId) {
      return new ObjectBinding<Integer>(){
         {
            bind(initRfqs.get());
         }

         @Override
         protected Integer computeValue() {
            List<ObservableReplyRow> rows = activeRfqs.get();
            for(ObservableReplyRow aRow : rows){
               if(instrCode.equals(aRow.getValue(AmpRfq.secCode))){
                  return aRow.getValue(AmpRfq.status);
               }
            }
            return AmpRFQStatus.finished;
         }
      };
   }


   public ObservableBooleanValue orderable(String instrCode, String boardId) {
      return new BooleanBinding() {

         {
            bind(activeRfqs.get());
         }

         @Override
         protected boolean computeValue() {
            for (QueryReplyRow aRow : activeRfqs.get()) {
               if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.endsWith(aRow.getString(AmpRfq.boardId))) {
                  Integer status = aRow.getValue(AmpRfq.status);
                  if(AmpRFQStatus.initial==status){
                     String initiator = aRow.getValue(AmpRfq.userId);
                     return !loggedOnUserId.equals(initiator);
                  }else{
                     return true;
                  }
               }
            }
            return false;
         }

      };
   }

   public boolean isRfqInFinalPhase(String instrCode, String boardId) {
      for (QueryReplyRow aRow : finalPhaseRfqs.get()) {
         if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.endsWith(aRow.getString(AmpRfq.boardId))) {
            logger.debug("secCode {} boardId {} is in final phase. ", instrCode, boardId);
            return true;
         }
      }
      return false;
   }

   public boolean isRfqFinished(String instrCode, String boardId) {
      for (QueryReplyRow aRow : finishedRfqs.get()) {
         if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.endsWith(aRow.getString(AmpRfq.boardId))) {
            return true;
         }
      }
      return false;
   }

   public ObservableReplyRow isActiveRfq(String instrCode, String boardId) {
      for (ObservableReplyRow aRow : activeRfqs.get()) {
         if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.equalsIgnoreCase(aRow.getString(AmpRfq.boardId))) {
            return aRow;
         }
      }
      return null;
   }

   /**
    * is active rfq session , but not RFS session.
    * @param instrCode
    * @param boardId
    * @return
     */
   public boolean isActiveRfqSession(String instrCode, String boardId) {
      for (ObservableReplyRow aRow : activeRfqWithoutRfsSession.get()) {
         if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.equalsIgnoreCase(aRow.getString(AmpRfq.boardId))) {
            return true;
         }
      }
      return false;
   }


   /*
    * refer to @AmpOrderVerb
    * if return @Integer.MIN_VALUE, means there is no such rfq spectified by the instrCode and boardId
    */
   public int getRfqRequest(String instrCode, String boardId) {
      for (ObservableReplyRow aRow : activeRfqs.get()) {
         if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.equalsIgnoreCase(aRow.getString(AmpRfq.boardId))) {
            return getRfqRequest(aRow);
         }
      }
      return NOTRFQ;
   }

   public String getRfqSecCodeByParent(String parentInstrCode) {
      if(parentInstrCode==null) return null;
      for (ObservableReplyRow aRow : activeRfqs.get()) {
         if (parentInstrCode.equalsIgnoreCase(aRow.getString(AmpRfq.parentSecCode)) ) {
            return aRow.getValue(AmpRfq.secCode);
         }
      }
      return null;
   }


   public int getRfqRequest(ObservableReplyRow aRow) {
      Integer buySellObj = aRow.getValue(AmpRfq.buySell);
      if (buySellObj == null) return NOTRFQ;
      int buySellV  = buySellObj;
      if(AmpOrderVerb.buyorsell == buySellV) return buySellV;
      String initiator = aRow.getValue(AmpRfq.userId);
      if(loggedOnUserId.equals(initiator)){
         return buySellV;
      } else{
         return buySellV == AmpOrderVerb.sell ? AmpOrderVerb.buy : AmpOrderVerb.sell;
      }
   }

   public boolean canRfqPickedup(String instrCode, String boardId, String userId) {
      for (QueryReplyRow aRow : activeRfqs.get()) {
         if (instrCode.equalsIgnoreCase(aRow.getString(AmpRfq.secCode)) && boardId.equalsIgnoreCase(aRow.getString(AmpRfq.boardId))
               && userId.equals(aRow.getString(AmpRfq.userId))  && !aRow.getValue(AmpRfq.isPublic)) {
            return true;
         }
      }
      return false;
   }

   boolean isRfsSessionInitiator(String rfqSecCode){
      for (ObservableReplyRow row: activeRfsSession.get()) {
         if (row.getString(AmpRfq.secCode).equals(rfqSecCode)) {
            return loggedOnUserId.equals(row.getString(AmpRfq.userId));
         }
      }
      return false;
   }

   /**
    *
    * @param rfqSecCode
    * @param rfqSecBoard
    * @return a Tuple3 of sec code, sec board, boolean, true indicates rfs session, false indicates
     */
   public Optional<Tuple3<String,String,Boolean>> searchRfq(String rfqSecCode, String rfqSecBoard, Date orderEntryTime){
      List<ObservableReplyRow> allRfq = rfqs.get(); //according to the implementation of aggregator, the later row is appended.
      int size = allRfq.size();
      for(int index = size - 1; index>=0;index--){
         ObservableReplyRow row = allRfq.get(index);
         Date rfqEndTime = row.getValue(AmpRfq.endTime);
         if(rfqEndTime.before(orderEntryTime)){
            break;
         }
         Date createTime = row.getValue(AmpRfq.startTime);
         if(orderEntryTime.after(createTime) && rfqSecCode.equals(row.getString(AmpRfq.secCode)) && rfqSecBoard.equals(row.getString(AmpRfq.boardId))) {
            Double maxQ = row.getValue(AmpRfq.maxQuantity);
            Boolean isRfsSession = maxQ==null|| maxQ.doubleValue()==0D ? Boolean.TRUE : Boolean.FALSE;
            return Optional.of(new Tuple3<>(row.getString(AmpRfq.parentSecCode), row.getString(AmpRfq.parentBoardId),isRfsSession));
         }

      }
      return Optional.empty();
   }

}
