package xfe.icap.modules.sectabsui;

import javafx.scene.input.MouseEvent;
import xfe.modules.actions.PopupOrderEntryArgs;
import xstr.types.OrderSide;

/**
 * Specifies the total cell in the instruments table.
 */
public class TotalCell extends WatchlistCell<Double> {
   /**
    * Specifies the order side of the total cell.
    */
   private OrderSide side;

   /**
    * Constructor.
    *
    * @param side Specifies the total's order side
    */
   TotalCell(OrderSide side) {
      this.side = side;
   }

   /**
    * Event handler to show the order entry popover.
    *
    * @param e Mouse event
    */
   @Override
   protected void onSingleClick(MouseEvent e) {
      if (!isPopOverShowing()) {
         final PopupOrderEntryArgs args = new PopupOrderEntryArgs(getWatchListRow().getRow(), this, this.side, null, PopupOrderEntryArgs.DefaultOn.SIZE);
         getSecTable().getTotalColDblClickAction().accept(args);
      }
   }

   @Override
   protected void updateDataItem(Double item) {
      setText(item.toString());
   }
}
