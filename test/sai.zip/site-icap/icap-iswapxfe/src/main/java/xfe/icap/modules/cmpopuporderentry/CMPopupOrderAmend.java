package xfe.icap.modules.cmpopuporderentry;

import com.nomx.domain.types.DefaultDurationType;
import com.nomx.domain.types.OnLogoffAction;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.modules.ordersdata.OrderEntryData;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.OrderTrans;
import xfe.icap.types.Orders;
import xfe.modules.actions.MyOrdersArgs;
import xfe.types.OrderType;
import xfe.ui.popover.XfePopOver;
import xfe.util.Util;
import xfe.util.scene.control.DoubleTextField;
import xstr.session.ObservableReplyRow;
import xstr.session.ServerSession;
import xstr.session.XtrTransReply;
import xstr.types.MapWrapper;
import xstr.types.OrderSide;
import xstr.types.XtrBlob;
import xstr.util.Fx;
import xstr.util.concurrent.Future;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

public class CMPopupOrderAmend {
   private static final Logger logger = LoggerFactory.getLogger(CMPopupOrderAmend.class);
   private boolean isDIT = false;
   private int decimals = 2;
   private BigDecimal bidBalance;
   private BigDecimal offerBalance;
   private BigDecimal bidSize;
   private BigDecimal offerSize;

   public Parent getRoot() {
      return root;
   }

   @FXML
   public void initialize(){
      colleaguedetails.setVisible(false);
      colleaguedetails.setManaged(false);

      final EventHandler<KeyEvent> handler = event -> {
         if (event.getCode() == KeyCode.ESCAPE) {
            root.requestFocus();
         }
      };

      sellTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (focused == null || !focused) {
            sellTextField.setVisible(false);
         }
      });

      sellTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);

      sellTextField.setOnAction(event -> {
         Optional<Double> quantity = sellTextField.getTextValue();
         quantity.ifPresent(aDouble -> onBidOffer(aDouble , OrderSide.SELL));
         root.requestFocus();
      });

      sellLabel.setOnMouseClicked(e -> enableQuantityTextField(sellTextField));

      buyTextField.focusedProperty().addListener((obs, old, focused) -> {
         if (focused == null || !focused) {
            buyTextField.setVisible(false);
         }
      });

      buyTextField.addEventHandler(KeyEvent.KEY_RELEASED, handler);

      buyTextField.setOnAction(event -> {
         Optional<Double> quantity = buyTextField.getTextValue();
         quantity.ifPresent(aDouble -> onBidOffer(aDouble, OrderSide.BUY));
         root.requestFocus();
      });

      buyLabel.setOnMouseClicked(e -> enableQuantityTextField(buyTextField));


      buyCloseButton.setOnAction(e -> withdrawHandler.apply(new OrderWithdrawData(popupSecCode, cmOrderPrice, OrderSide.BUY, false)));
      sellCloseButton.setOnAction(e -> withdrawHandler.apply(new OrderWithdrawData(popupSecCode, cmOrderPrice, OrderSide.SELL, false)));

      buyColleagueCloseButton.setOnAction(e -> colleagueWithdrawHandler.apply(new OrderWithdrawData(popupSecCode, cmOrderPrice, OrderSide.BUY, false)));
      sellColleagueCloseButton.setOnAction(e -> colleagueWithdrawHandler.apply(new OrderWithdrawData(popupSecCode, cmOrderPrice, OrderSide.SELL, false)));

      ordersListener = c -> handleOrderUpdates();

      errorMsgField.managedProperty().bind(errorMsgField.visibleProperty());
      errorMsgPane.managedProperty().bind(errorMsgPane.visibleProperty());

      yesButton.setOnAction(e -> {
         // get size from buy/sell text fields
         double buyQty = buyTextField.getValue();
         double sellQty = sellTextField.getValue();

         // if text fields are not populated,
         // get size from buy/sell labels
         if(sellQty == 0.0 && buyQty == 0.0){
            buyQty = bidSize.doubleValue();
            sellQty = offerSize.doubleValue();
         }

         // submit the order
         if (buyQty != 0) {
            onBidOffer(buyQty, OrderSide.BUY);
         }else if(sellQty != 0) {
            onBidOffer(sellQty, OrderSide.SELL);
         }else{
            showErrorMessage("Cannot Renew Order With 0 Quantity.");
         }
      });

      noButton.setOnAction(e -> withdrawAndClose());
   }

   private void handleOrderUpdates() {
      final MyOrdersArgs myOrdersArgs = new MyOrdersArgs();
      myOrdersArgs.setSecCode(popupSecCode);
      ObservableList<ObservableReplyRow> myOrders = getMyOrders.apply(myOrdersArgs, isRenew);

      bidSize = BigDecimal.ZERO;
      bidBalance = BigDecimal.ZERO;
      offerSize = BigDecimal.ZERO;
      offerBalance = BigDecimal.ZERO;

      if (!myOrders.isEmpty()) {
         int buysell = AmpOrderVerb.buyorsell;
         for (ObservableReplyRow order : myOrders) {
            BigDecimal orderPrice = order.getValue(AmpManagedOrder.price);

            if (orderPrice.abs().compareTo(cmOrderPrice.abs()) == 0) {
               // we have price match
               int side = order.getValue(AmpManagedOrder.buySell);
               if (side != buysell && buysell != AmpOrderVerb.buyorsell)
                  this.bothSides = true;
               buysell = side;
               BigDecimal orderQty = order.getValue(AmpManagedOrder.quantity);
               BigDecimal orderBalance = order.getValue(AmpManagedOrder.balance);
               if (buysell == AmpOrderVerb.buy) {
                  bidSize = bidSize.add(orderQty);
                  bidBalance = bidBalance.add(orderBalance);
               } else if (buysell == AmpOrderVerb.sell) {
                  offerSize = offerSize.add(orderQty);
                  offerBalance = offerBalance.add(orderBalance);
               }
            }
         }
      }

      if (bidSize.doubleValue() > 0.0 || bidBalance.doubleValue() > 0.0) {
         buyLabel.setText("0 / "+ Util.sizeFormatter.format(bidBalance.doubleValue()));
      }
      else {
         buyLabel.setText("");
      }

      if (offerSize.doubleValue() > 0.0 || offerBalance.doubleValue() > 0.0) {
         sellLabel.setText("0 / "+ Util.sizeFormatter.format(offerBalance.doubleValue()));
      }
      else {
         sellLabel.setText("");
      }

      ObservableList<ObservableReplyRow> myFirmsOrders = getMyFirmsOrders.apply(myOrdersArgs);

      BigDecimal firmBidSize = BigDecimal.ZERO;
      BigDecimal firmBidBalance = BigDecimal.ZERO;
      BigDecimal firmOfferSize = BigDecimal.ZERO;
      BigDecimal firmOfferBalance = BigDecimal.ZERO;

      if (myFirmsOrders != null && !myFirmsOrders.isEmpty()) {
         for (ObservableReplyRow order : myFirmsOrders) {
            BigDecimal orderPrice = order.getProperty(AmpManagedOrder.price).getValue();
            if (orderPrice.abs().doubleValue() == cmOrderPrice.abs().doubleValue()) {
               // we have price match
               int buysell = order.getProperty(AmpManagedOrder.buySell).getValue();
               BigDecimal orderQty = order.getValue(AmpManagedOrder.quantity);
               BigDecimal orderBalance = order.getValue(AmpManagedOrder.balance);
               if (buysell == AmpOrderVerb.buy) {
                  firmBidSize = firmBidSize.add(orderQty);
                  firmBidBalance = firmBidBalance.add(orderBalance);
               } else if (buysell == AmpOrderVerb.sell) {
                  firmOfferSize = firmOfferSize.add(orderQty);
                  firmOfferBalance = firmOfferBalance.add(orderBalance);
               }
            }
         }
      }

      boolean showFirmInfo = false;
      if (firmBidSize.doubleValue() > 0.0 || firmBidBalance.doubleValue() > 0.0) {
         buyColleagueLabel.setText("0 / " + Util.sizeFormatter.format(firmBidBalance.doubleValue()));
         showFirmInfo = true;
      }
      else {
         buyColleagueLabel.setText("");
      }

      if (firmOfferSize.doubleValue() > 0.0 || firmOfferBalance.doubleValue() > 0.0) {
         sellColleagueLabel.setText("0 / " + Util.sizeFormatter.format(firmOfferBalance.doubleValue()));
         showFirmInfo = true;
      }
      else {
         sellColleagueLabel.setText("");
      }

      colleaguedetails.setVisible(showFirmInfo);
      colleaguedetails.setManaged(showFirmInfo);

      if (root.getScene() != null) {
         root.getScene().getWindow().sizeToScene();
      }
   }

   void showRenewMessage(OrderSide side, String price) {
      referredOrderSide = side;
      referredPrice = price;

      String renewMsg = "The CM Price for " +
         popupSecCode +
         " has changed.\n" +
         "Would you like to Renew your order at the new CM price?";
      showErrorMessage(renewMsg);
   }

   public void setup(OrderEntryData orderEntryData) {
      switch (orderEntryData.getDataMode()) {
         case AMEND:
            isRenew = false;
            break;
         case RENEW:
            isRenew = true;
            break;
         default:
            logger.error("Expecting Amend or Renew mode");
            return;
      }

      if (addOrdersListenerHandler != null)
         addOrdersListenerHandler.accept(ordersListener);

      popupSecCode = orderEntryData.getSecCode();
      popupBoardId = orderEntryData.getBoardId();
      isPriceReversal = orderEntryData.isPriceReversal();

      cmOrderPrice = orderEntryData.getOrderPrice();
      cmPrice = orderEntryData.getPrice();
      cmPriceFormatted = orderEntryData.getPriceFormatted();
      cmPriceLabel.setText(cmPriceFormatted);
      cmcolleaguePriceLabel.setText(cmPriceFormatted);

      handleOrderUpdates();

      onLogoffAction = orderEntryData.getOnLogoffAction();
      isShared = orderEntryData.isShared();
      isDIT = orderEntryData.isDark();
      isTopcut = orderEntryData.isTopcut();

      Fx.run(() -> secCodeLabel.setText(orderEntryData.getSecCode().replaceFirst("(UKT )*", "")));

      if(isRenew){
         renewButtonPanel.setManaged(true);
         renewButtonPanel.setVisible(true);
      }
      else{
         renewButtonPanel.setManaged(false);
         renewButtonPanel.setVisible(false);
      }
   }

   void setWithdrawHandler(Function <OrderWithdrawData, Future<List<XtrTransReply>>> withdrawHandler) {
      this.withdrawHandler = withdrawHandler;
   }

   void setCMOrderHandler(Function<CMOrderData, Future<XtrTransReply>> cmOrderHandler){
      this.cmOrderHandler =cmOrderHandler;
   }

   void setColleagueWithdrawHandler(Function <OrderWithdrawData, Future<List<XtrTransReply>>> colleagueWithdrawHandler) {
      this.colleagueWithdrawHandler = colleagueWithdrawHandler;
   }

   void setAddOrdersListenerHandler(Consumer <ListChangeListener<ObservableReplyRow>> addOrdersListenerHandler) {
      this.addOrdersListenerHandler = addOrdersListenerHandler;
   }

   private void enableQuantityTextField(DoubleTextField textField) {
      textField.setVisible(true);
      textField.setDecimals(this.decimals);
      //textField.setValue(quantity);
      textField.positionCaret(0);
      textField.selectAll();
      textField.requestFocus();
   }

   private boolean isManaged() {
      return isManaged;
   }

   private void onBidOffer(double size, OrderSide side) {
      boolean isImmediate = false;
      AbstractOrderTrans orderTrans = isManaged() ?
         new ManagedOrderTrans(null) : new OrderTrans(null);
      // for all CM orders the order Tag is set as CM
      MapWrapper extField=  new MapWrapper();
      extField.put(Orders.ORDER_TAG_KEY, new XtrBlob(Orders.CM.getBytes()));
      orderTrans.setMapWrapper(extField);
      populateTransactionData(orderTrans, isImmediate, size, side);
      logger.debug("**** Executing BUY/SELL ****");
      cmOrderHandler.apply(new CMOrderData(orderTrans.getSecCode(),cmPrice, side,orderTrans)).onDone(xtrTransReply -> {
         if (xtrTransReply.get().getStatus() == XtrTransReply.Status.RESULT_OK) {
            onClose();
         }
         else {
            String errorMsg = xtrTransReply.get().getMessage();
            logger.error("onBidOffer: {}", errorMsg);
            showErrorMessage(errorMsg);
         }
         return Future.SUCCESS;
      });
   }

   public void updateCMPrice(String priceFormatted) {
      cmcolleaguePriceLabel.setText(priceFormatted);
      cmPriceLabel.setText(priceFormatted);
   }

   private void populateTransactionData(AbstractOrderTrans orderTrans, boolean isImmediate, double size, OrderSide side) {
      orderTrans.setCloneIntoRFS(false);
      orderTrans.setSecCode(popupSecCode);
      orderTrans.setBoardId(popupBoardId);
      orderTrans.setOrderType(OrderType.REGULAR);
      orderTrans.setVwap(false);
      double negatePrice = side.equals(OrderSide.SELL) && isPriceReversal ? -1.0 : 1.0;
      orderTrans.setPrice(cmPrice.doubleValue() * negatePrice);
      orderTrans.setQuantity(size);
      orderTrans.setDoneIfTouched(isDIT);
      orderTrans.setAnonymous(false);
      orderTrans.setUnderRef(false);

      if (isImmediate) {
         orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
      } else {
         orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DAY);
      }

      orderTrans.setOnLogOffAction(onLogoffAction);
      orderTrans.setShared(isShared);
      orderTrans.setTopCut(isTopcut);
   }

   private void withdrawAndClose() {
      // withdraw referred order
      if (bidSize.compareTo(BigDecimal.ZERO) == 0 && offerSize.compareTo(BigDecimal.ZERO) == 0) {
         // nothing to withdraw
         onClose();
      }else {
         withdrawHandler.apply(new OrderWithdrawData(popupSecCode, new BigDecimal(referredPrice), referredOrderSide, false)).onDone(xtrTransReply -> {
            List<XtrTransReply> replyList = xtrTransReply.get();
            boolean successfulWithdraw = true;
            for (XtrTransReply aReplyList : replyList) {
               XtrTransReply.Status replyStatus = aReplyList.getStatus();
               if (!replyStatus.isSuccess()) {
                  successfulWithdraw = false;
               }
            }
            if (!successfulWithdraw) {
               showErrorMessage("Failed to withdraw order");
            } else {
               onClose();
            }
            return Future.SUCCESS;
         });
      }
   }

   private void onClose() {
      managedOrderToAmend = null;

      errorMsgField.setText("");
      errorMsgField.setVisible(false);
      errorMsgPane.setVisible(false);

      if (isRenew) {
         closeHandler.accept(getRoot().getId());
      }
      else {
         closeHandler.accept(popOver.id());
      }

      if(popOver != null)
         popOver.hide();

      popOver = null;
   }

   private void showErrorMessage(String errorMsg) {
      Fx.runLater(() -> {
         errorMsgField.setText(errorMsg);
         errorMsgField.setVisible(true);
         errorMsgPane.setVisible(true);
         if (root.getScene() != null)
            root.getScene().getWindow().sizeToScene();
      });
   }

   void setCloseHandler(Consumer<String> closeHandler) {
      this.closeHandler = closeHandler;
   }

   void setSession(Optional<ServerSession> session) {
      this.session = session;
   }

   void setPopover(XfePopOver po) {
      this.popOver = po;
   }

   void setMyOrdersGetter(BiFunction<MyOrdersArgs, Boolean, ObservableList<ObservableReplyRow>> ordersGetter) {
      this.getMyOrders = ordersGetter;
   }

   void setMyFirmsOrdersGetter(Function<MyOrdersArgs, ObservableList<ObservableReplyRow>> ordersGetter) {
      this.getMyFirmsOrders = ordersGetter;
   }

   private BiFunction<MyOrdersArgs, Boolean, ObservableList<ObservableReplyRow>> getMyOrders;
   private Function<MyOrdersArgs, ObservableList<ObservableReplyRow>> getMyFirmsOrders;

   @FXML
   private Parent root;

   @FXML
   private HBox colleaguedetails;

   @FXML
   private Label sellLabel;

   @FXML
   private DoubleTextField sellTextField;

   @FXML
   private Label buyLabel;

   @FXML
   private DoubleTextField buyTextField;

   @FXML
   private Button buyCloseButton;

   @FXML
   private Button sellCloseButton;

   @FXML
   private Button buyColleagueCloseButton;

   @FXML
   private Button sellColleagueCloseButton;

   @FXML
   private Label buyColleagueLabel;

   @FXML
   private Label sellColleagueLabel;

   @FXML
   private Label cmPriceLabel;

   @FXML
   private Label cmcolleaguePriceLabel;

   @FXML
   private TextArea errorMsgField;

   @FXML
   private Node errorMsgPane;

   @FXML
   private Label secCodeLabel;

   @FXML
   private Node renewButtonPanel;

   @FXML
   private Button yesButton;

   @FXML
   private Button noButton;

   private boolean isManaged = true;

   private OnLogoffAction onLogoffAction;

   private Optional<ServerSession> session;

   private boolean isShared;

   private boolean isTopcut;

   private boolean isRenew;
   private String popupSecCode;
   private String popupBoardId;
   private BigDecimal cmPrice;
   private BigDecimal cmOrderPrice;
   private boolean bothSides = false;
   private String cmPriceFormatted;
   private boolean isPriceReversal = false;
   private XfePopOver popOver;
   private ObservableReplyRow managedOrderToAmend;
   private Consumer<String> closeHandler;
   private Function <OrderWithdrawData, Future<List<XtrTransReply>>> withdrawHandler;
   private Function <OrderWithdrawData, Future<List<XtrTransReply>>> colleagueWithdrawHandler;
   private Consumer<ListChangeListener<ObservableReplyRow>> addOrdersListenerHandler;
   private Function<CMOrderData,Future<XtrTransReply>> cmOrderHandler;
   private ListChangeListener<ObservableReplyRow> ordersListener;
   private OrderSide referredOrderSide = null;
   private String referredPrice = null;
}
