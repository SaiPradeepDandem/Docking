package xfe.icap.modules.iswaporders;

import com.nomx.persist.PersistantName;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.HBox;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.util.WeakCompositeRef;
import xfe.util.scene.control.*;
import xstr.amp.AMP;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpOrderBookByOrder;
import xstr.session.ObservableReplyRow;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xstr.session.QueryFeed;
import xstr.session.ServerSession;
import xfe.icap.types.ManagedOrder;
import xfe.types.OrdersTrans;
import xstr.util.*;
import xfe.util.HandlerCompositeUtils.ObservableFilterExpression;
import xstr.util.collection.FilteredStaticSorter;
import xstr.util.collection.ObservableCollections;
import xstr.util.collection.SortValueFactory;
import xstr.util.concurrent.Future;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.RowFilters;
import xfe.icap.XfeSession;
import xfe.util.XfeAction;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.layout.FxAbstractLayout;
import xfe.layout.LayoutManager;
import xfe.module.Module;
import xfe.modules.actionsui.ActionButton;
import xfe.icap.modules.actionsui.ActionsUIModule;
import xfe.modules.session.SessionModule;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.ui.KeyEventFilter;
import xfe.ui.TabSelector;
import xfe.ui.ToggleButtonPaneSelector;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Module.Autostart
public class OrdersUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(OrdersUIModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public DataContextModule dataContextModule;
   @ModuleDependency
   public LayoutManager<Node> layoutManagerModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public ActionsUIModule actionsUIModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;

   private static final int ditColumnIndex = 2;
   private static final int traderOrBrokerColumnIndex = 7;
   private static final int durationColumnIndex = 9;
   private static final int firmColumnIndex = 8;
   private static BooleanProperty isFlash = new SimpleBooleanProperty(false);
   private static Timeline flashAnimation;

   public OrdersUIModule() {
      myTradersCheckbox.getStyleClass().add("xfe-iswap-chk");

   }

   private GlobalReferBtnsPresenter getGlobalReferBtnsPresenter() {
      if (globalReferBtnsPresenter == null) {
         globalReferBtnsPresenter = new GlobalReferBtnsPresenter(xfeSessionModule, sessionModule.lockedProperty());
      }

      return globalReferBtnsPresenter;
   }

   public List<ManagedOrder> getRfqOrdersWithRemainingBalance(String userId, String rfqInstrCode, String boardId, Date startTime,
                                                              Date endTime) {
      DynamicFilter<ObservableReplyRow> traderFilter = DynamicFilter.of(Filters.and(Filters.not(Filters.or(OrderFilters.isReferred, OrderFilters.isWithdrawn)), OrderFilters.isTraderSubmitOrder(userId),
         Filters.dynamic(OrderFilters.withSecurity(rfqInstrCode, boardId)), Filters.dynamic(OrderFilters.withinTimeFrameWithBalance(startTime, endTime))));
      rfqOrderMovableFilter.setFilter(traderFilter);

      List<ManagedOrder> rtnList = new ArrayList<>(10);
      ObservableList<ObservableReplyRow> allOrders = rfqOrderMovableFilter.getItems();
      for (ObservableReplyRow anOrder : allOrders) {
         rtnList.add(new ManagedOrder(anOrder));
      }
      return rtnList;
   }

   @Override
   public Future<Void> startModule() {

      firmAdded = false;
      if (flashAnimation == null) {
         flashAnimation = new Timeline(
            new KeyFrame(Duration.millis(1000), t -> {
               isFlash.setValue(!isFlash.getValue());
            }));
         flashAnimation.setCycleCount(Timeline.INDEFINITE);
         flashAnimation.play();
      }
      columns = new OrdersColumns(xfeSessionModule);
      isMyTraders.bindBidirectional(myTradersCheckbox.selectedProperty());
      rfqOrderMovableFilter = FilteredStaticSorter.create(ordersAggregator.items, RowFilters.alwaysReject,tracker);
      tracker.bindBidirectional(showReferred, configurationModule.getParametersStorage().get(PersistantName.OrdersPaneShowReferred, false));
      boolean isBroker = xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker();
      boolean isIB = isBroker && xfeSessionModule.getUnderlyingSession().getLoggedOnUser().isIB();
      String userId = xfeSessionModule.getUnderlyingSession().getLoggedOnUserId();

      OrderFilters filters = xfeSessionModule.getOrderFilters();
      DynamicFilter<ObservableReplyRow> allReferredFilter = OrderFilters.isReferred;
      DynamicFilter<ObservableReplyRow> allMyOrdersFilter;
      if (isBroker) {// {Broker-name} � Containing all orders entered by the logged-in broker himself.
         if (isIB) {
            allMyOrdersFilter = OrderFilters.isIntroBrokerOrder(xfeSessionModule.getUnderlyingSession().getLoggedOnUserId());
         } else {
            allMyOrdersFilter = OrderFilters.isBrokerOrder(xfeSessionModule.getUnderlyingSession().getLoggedOnUserId());
         }
      } else {
         allMyOrdersFilter = OrderFilters.isTraderSubmitOrder(xfeSessionModule.getUnderlyingSession().getLoggedOnUserId());
      }

      DynamicFilter<ObservableReplyRow> myOrdersFilter = DynamicFilter.of(ObservableFilterExpression.<ObservableReplyRow> build(
         "my & (open | showReferred & referred)",
         "showReferred",RowFilters.fixed(showReferred),
         "referred", allReferredFilter,
         "my", allMyOrdersFilter,
         "open",OrderFilters.isOpenOrEmbargoed));
      myOrders = ObservableCollections.sort(ordersAggregator.items, orderSequenceFactory, myOrdersFilter,tracker);

      DynamicFilter<ObservableReplyRow> allDeskOrdersFilter;
      if(isBroker){
         if(isIB){
            allDeskOrdersFilter = filters.introBrokerShareFilter;
         }else{
            allDeskOrdersFilter = filters.brokerShareFilter;
         }
      }else{
         allDeskOrdersFilter = OrderFilters.isBrokerOrder.not().and(OrderFilters.isShared);  //Desk (all open shared orders entered the trader, or by others on the traders desk)
      }

      DynamicFilter<ObservableReplyRow> deskFilter = DynamicFilter.of(ObservableFilterExpression.<ObservableReplyRow> build(
         "( (!showMyTraders & desk) | (showMyTraders & myTrders) )& (open | showReferred & referred) ",
         "showReferred", RowFilters.fixed(showReferred),
         "referred", allReferredFilter,
         "desk", allDeskOrdersFilter,
         "open", OrderFilters.isOpenOrEmbargoed,
         "showMyTraders", RowFilters.fixed(showMyTraders),
         "myTrders", filters.myTradersFilter));
      deskView = ObservableCollections.sort(ordersAggregator.items, orderSequenceFactory, deskFilter,tracker);

      allOrders = ordersAggregator.items;
      DynamicFilter<ObservableReplyRow> allBrokerOrTradersFilter;
      if (isBroker) {
         if (isIB) {
            allBrokerOrTradersFilter = filters.onBehalOfTraderFilterForIB;
         } else {
            allBrokerOrTradersFilter = filters.onBehalOfTraderFilterForBroker;
         }
      } else {
         allBrokerOrTradersFilter = OrderFilters.isBrokerOrderForTrader(userId);
      }
      DynamicFilter<ObservableReplyRow> brokerOrTraderFilter = DynamicFilter.of(ObservableFilterExpression.<ObservableReplyRow>build(
         "brokerTrader & (open | showReferred & referred)",
         "showReferred", Filters.fixed(showReferred), "referred", allReferredFilter,
         "brokerTrader", allBrokerOrTradersFilter, "open", OrderFilters.isOpenOrEmbargoed));
      brokerView = ObservableCollections.sort(ordersAggregator.items, orderSequenceFactory, brokerOrTraderFilter,tracker);


      if (pendingOrdersView == null) {
         pendingOrdersView = ObservableCollections.sort(ordersAggregator.items, orderSequenceFactory, OrderFilters.isEmbargoed,tracker);
         pendingOrdersView.addListener((Change<? extends ObservableReplyRow> c) -> {
            while (c.next()) {
               if (c.wasAdded()) {
                  // Setting the new pending order
                  pendingOrder.setValue(c.getAddedSubList().get(0));

                  // This opens the orders view if it is not viewable
                  configurationModule.getData().displayOrdersProperty().setValue(true);

                  // Now that we know the orders view is opened, we browse to the relevant order
                  // in the brokerOrTrader tab

                  // We move via the second tab as a small hack, as it was discovered
                  // that moving from the first tab directly to the third one harms the scrollTo
                  // (probably some race condition betwee two RunLater, the scrollTo one and the one
                  // that updates the information in the view)
                  tg.selectToggle(deskBtn);
                  tg.selectToggle(mineBtn);
                  Fx.runLater(() -> {
                     Integer index = findOrderIndex();
                     if (index != null)
                        ordersTable.scrollTo(index);
                  });
               }
            }

            if (c.wasRemoved()) {
               pendingOrder.setValue(null);
            }
         });
      }
      DynamicFilter<ObservableReplyRow> referredFilter = DynamicFilter.of(ObservableFilterExpression.<ObservableReplyRow>build(
         // Filter expression
         "traderBtn & my & referred | " +
            "deskBtn & desk & referred | " +
            "brokerBtn & brokerTrader & referred",

         // Surrogate filters for buttons
         "traderBtn", RowFilters.fixed(tg.selectedToggleProperty().isEqualTo(mineBtn)),
         "deskBtn", RowFilters.fixed(tg.selectedToggleProperty().isEqualTo(deskBtn)),
         "brokerBtn", RowFilters.fixed(tg.selectedToggleProperty().isEqualTo(brokerBtn)),

         // Order filters
         "my", allMyOrdersFilter,
         "desk", allDeskOrdersFilter,
         "brokerTrader", allBrokerOrTradersFilter,
         "referred", allReferredFilter
      ));

      ObservableList<ObservableReplyRow> referedView = ObservableCollections.filter(ordersAggregator.items, referredFilter,tracker);

      setFeedSource();
      initTabButtons();
      if (ordersPane.get() == null) {
         ordersTable = createOrdersTableView();

         selectionTracker = new Lazy<SelectionTracker<ObservableReplyRow>>() {
            @Override
            protected SelectionTracker<ObservableReplyRow> initialize() {
               tracker.resets(this);
               return new SelectionTracker<ObservableReplyRow>(view.get(), orderRow -> {
                  if (orderRow != null) {
                     String id = orderRow.getString(AmpManagedOrder.managedOrderIdAcc);
                     if (id == null) {
                        id = orderRow.getString(AmpManagedOrder.managedOrderIdAcc);
                     } else {
                        id = orderRow.getString(AmpOrderBookByOrder.orderId);
                     }
                     return id;
                  } else {
                     return null;
                  }
               }, arg0 -> {
                  // TODO Auto-generated method stub
                  return null;
               },"orders") {
                  @Override
                  public void setRowFactory() {
                     ordersTable.setRowFactory(param -> {
                        TableRow<ObservableReplyRow> row = new TableRow<>();
                        row.addEventFilter(MouseEvent.MOUSE_CLICKED, event -> selectionTracker.get().setSelectedItem(row.getItem()));
                        return row;
                     });
                  }
               };
            }
         };

         // Listening on row selection change
         tracker.disposes(Fx.addListener(selectionTracker.get().selectedItemProperty(), (observableVal, oldVal, newVal) -> {
            if (newVal != null) {
               isActive = true;
               selectionContextModule.setSelectionContext(new SelectionContext(GridType.Orders, newVal, null, -1));
            } else if (selectionContextModule.getSelectionContext().grid == GridType.Orders){
               isActive = false;
               selectionContextModule.setSelectionContext(new SelectionContext(GridType.Orders, null, null, -1));
            }
         }));

         tracker.addListener(tg.selectedToggleProperty(), observable -> {
            if (xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker()) {
               if (tg.selectedToggleProperty().get() == mineBtn) {
                  ordersTable.getColumns().remove(traderOrBrokerColumnIndex);
                  ordersTable.getColumns().add(traderOrBrokerColumnIndex, OrdersColumns.createTraderColumn());
               } else {
                  ordersTable.getColumns().remove(traderOrBrokerColumnIndex);
                  ordersTable.getColumns().add(traderOrBrokerColumnIndex, OrdersColumns.createBrokerColumn());
               }
               addFirmColumn();
            } else {
               ordersTable.getColumns().remove(traderOrBrokerColumnIndex);
               ordersTable.getColumns().add(traderOrBrokerColumnIndex, OrdersColumns.createTraderColumn());
               removeFirmColumn();
            }
         });
         tracker.bind(mineBtn.textProperty(), Bindings.format("%s (%d)", xfeSessionModule.getUnderlyingSession()
            .getLoggedOnUserId(), Fx.sizeOfList(myOrders)));

         tracker.bind(deskBtn.textProperty(), Bindings.format("Desk (%d)",
            Fx.sizeOfList(deskView)));

         HBox buttonsPane = new HBox();
         if (xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker()) {
            StringBinding text = new StringBinding() {
               {
                  bind(brokerView, xfeSessionModule.getUnderlyingSession().onBehalfTraderId);
               }

               @Override
               protected String computeValue() {
                  return xfeSessionModule.getUnderlyingSession().onBehalfTraderId.get()+" ("+brokerView.size()+")";
               }
            };
            tracker.bind(brokerBtn.textProperty(), text);
         } else{
            tracker.bind(brokerBtn.textProperty(), Bindings.format("Broker (%d)", Fx.sizeOfList(brokerView)));
         }

         buttonsPane.getChildren().addAll(mineBtn, deskBtn, brokerBtn);

         DecoratedTitledPane titledPane = new DecoratedTitledPane("Orders", ordersTable,true, layoutModule,true);
         ordersPane.set(titledPane);
         ordersPane.get().setLeftDecoration(buttonsPane);
         // TODO: Ref'd checkbox tag

         HBox hbox = new HBox();
         hbox.setAlignment(Pos.CENTER_RIGHT);
         hbox.setSpacing(10);
         ordersPane.get().setRightDecoration(hbox);
         hbox.getChildren().add(myTradersCheckbox);
         if (xfeSessionModule.getUnderlyingSession().getLoggedOnUser().isBroker()){
            myTradersCheckbox.visibleProperty().bind(deskBtn.selectedProperty());
         } else {
            myTradersCheckbox.setVisible(false);
         }

         StringBinding refedtext = new StringBinding(){
            {
               bind(referedView);
            }
            @Override
            protected String computeValue() {
               return "Ref'd ("+ referedView.size()+")";
            }

         };
         CheckBox refedChb = new CheckBox("Ref'd") {{
            //this.setPrefWidth(107);
            this.setTextOverrun(OverrunStyle.CENTER_ELLIPSIS);
            this.getStyleClass().add("xfe-iswap-chk");
         }};

         hbox.getChildren().add(refedChb);
         tracker.bindBidirectional(refedChb.selectedProperty(), showReferred);
         tracker.bind(refedChb.textProperty(), refedtext);

         refedtext.invalidate();

         titledPane.setId("xfe-orders-view");
         titledPane.getStyleClass().add("xfe-iswap-pane");
         tracker.bindBidirectional(titledPane.expandProperty(), configurationModule.getData().ordersExpandProperty());
         tracker.bindBidirectional(titledPane.sizeProperty(), configurationModule.getData().ordersHeightProperty());
         tracker.bindBidirectional(titledPane.displayProperty(), configurationModule.getData().displayOrdersProperty());
         layoutModule.addView(titledPane);

//         tracker.addListener(configurationModule.getData().displayOrdersProperty(), new InvalidationListener() {
//            @Override
//            public void invalidated(final Observable observable) {
//               showMyself();
//            }
//         });
         attachTabSelectorAccelerators();
      }

      // Responsible for the two buttons at the top
      if (globalReferBtnsPane == null) {
         globalReferBtnsPane = new GlobalReferBtnsPane();

         getGlobalReferBtnsPresenter().setView(globalReferBtnsPane);

         Node rootElement = globalReferBtnsPane.getRootElement();
         rootElement.setId("xfe-global-refer-btns-view");
         rootElement.getStyleClass().add("xfe-global-refer-btns-view");
         layoutModule.addView(rootElement);
      }

      actionsUIModule.addAction(7, withdrawAction);
      actionsUIModule.addAction(8, getGlobalReferBtnsPresenter().referMineAction());
      actionsUIModule.addAction(9, getGlobalReferBtnsPresenter().referAllAction());
      actionsUIModule.addAction(10, renewAction);
      actionsUIModule.addAction(11, referAction);

      tracker.bind(renewAction.disableProperty(), Bindings.or(
         sessionModule.lockedProperty(),
         Bindings.not(dataContextModule.hasRenewableOrders())));
      tracker.bind(referAction.disableProperty(), Bindings.or(
         sessionModule.lockedProperty(),
         Bindings.not(dataContextModule.hasReferrableOrders())));
      tracker.bind(withdrawAction.disableProperty(), Bindings.or(sessionModule.lockedProperty(),
         Bindings.not(dataContextModule.hasWithdrawableOrders())));

      IntegerProperty selectedTab = configurationModule.getData().selectedOrdersTabProperty();
      tg.getToggles().get(selectedTab.get()).setSelected(true);

      tracker.addListener(configurationModule.getData().selectedOrdersTabProperty(), ob -> {
         tg.getToggles().get(configurationModule.getData().selectedOrdersTabProperty().get()).setSelected(true);
      });

      actionsUIModule.addCustomButton(1, new ActionButton() {{
         this.getStyleClass().add("xfe-icon-orders");
         this.setText("Orders");
         setId("xfe-iswap-btn-action-orders");
         XfeTooltipFactory.setTooltip(this);
         tracker.bindBidirectional(this.selectedProperty(), configurationModule.getData().displayOrdersProperty());
      }});
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      if (flashAnimation != null) {
         flashAnimation.stop();
         flashAnimation = null;
      }
      isFlash = new SimpleBooleanProperty(false);
      if(ordersPane.get()!=null) {
         ordersPane.get().setRightDecoration(null);
      }
      isMyTraders.unbindBidirectional(myTradersCheckbox.selectedProperty());
      myTradersCheckbox.visibleProperty().unbind();
      allOrders = null;
      myOrders = null;
      pendingOrdersView = null;
      deskView = null;
      brokerView = null;

      if (ordersPane.get() != null) {
         ordersPane.get().dispose();
         ordersTable = null;
         layoutModule.removeView(ordersPane.get());
         ordersPane.set(null);
      }

      if (globalReferBtnsPane != null) {
         layoutModule.removeView(globalReferBtnsPane.getRootElement());
         getGlobalReferBtnsPresenter().resetView();
         globalReferBtnsPresenter = null;
         globalReferBtnsPane = null;
      }

      ordersAggregator.reset();
      ordersAggregator = new FeedAggregator<>(AmpManagedOrder.rep, new ObservableRowFactory());
      tracker.rollback();
//      initTabButtons();
      columns = null;
      return Future.SUCCESS;
   }

   private Integer findOrderIndex() {
      ObservableReplyRow rowToFind = pendingOrder.get();
      if (rowToFind == null) return null;
      for (ObservableReplyRow row : ordersTable.getItems()) {
         if (row.getKey().equals(rowToFind.getKey())) {
            return ordersTable.getItems().indexOf(row);
         }
      }
      return null;
   }

   private void initTabButtons() {
      tg = new ToggleGroup();
      mineBtn = createTgButton();
      mineBtn.getStyleClass().add("orders-mine-tab-btn");
      deskBtn = createTgButton();
      deskBtn.getStyleClass().add("orders-desk-tab-btn");
      brokerBtn = createTgButton();
      brokerBtn.getStyleClass().add("orders-broker-tab-btn");

      tg.selectedToggleProperty().addListener((observableToggle, oldToggle, newToggle) -> {
         ordersTable.setItems(FXCollections.emptyObservableList());
         selectionTracker.get().clearSelection();

         ObservableList<ObservableReplyRow> items = null;
         int toggleIndex = tg.getToggles().indexOf(newToggle);
         if (toggleIndex != -1)
            configurationModule.getData().selectedOrdersTabProperty().set(toggleIndex);
         if (newToggle == mineBtn) {
            items = myOrders;
         } else if (newToggle == deskBtn) {
            items = deskView;
         } else if (newToggle == brokerBtn) {
            items = brokerView;
         }

         if (items != null) {
            ordersTable.setItems(items);
         }

         selectionTracker.get().clearSelection();

         if (newToggle == mineBtn) {
            Fx.runLater(() -> {
               Integer index = findOrderIndex();
               if (index != null)
                  ordersTable.scrollTo(index);
            });
         }
      });
   }

   private ToggleButton createTgButton() {
      ToggleButton tgButton = Builders.create(tg, WeakCompositeRef.valueOf(ordersPane));
      double prefBtnWidth = -1;
      tgButton.setPrefWidth(prefBtnWidth);
      tgButton.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(tgButton));
      return tgButton;
   }

   private void setFeedSource() {
      QueryFeed ordersFeed = xfeSessionModule.getUnderlyingSession().getFeedSource(AmpManagedOrder.req);
      tracker.addFeedListener(ordersFeed, ordersAggregator);
   }

   private TableView<ObservableReplyRow> createOrdersTableView() {

      // DEBUG: Listening if items property really modified
      //Fx.printStackTrace("myOrders.items", myOrders.itemsProperty(), System.err);
      tracker.disposes(Fx.addListener(selectionContextModule.selectionContextProperty(), activeGridListener));

//      view.setMinHeight(60);
      view.get().setPrefHeight(100);
      //		view.setMaxHeight(200);
      view.get().getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");

      return view.get();
   }

   private void addFirmColumn()
   {
      if (!firmAdded) {
         ordersTable.getColumns().add(firmColumnIndex, OrdersColumns.createFirmColumn());
         ordersTable.getColumns().remove(ditColumnIndex);
         ordersTable.getColumns().add(ditColumnIndex, OrdersColumns.createDoneIfTouchedColumn(25));
         ordersTable.getColumns().remove(durationColumnIndex);
         ordersTable.getColumns().add(durationColumnIndex, OrdersColumns.createDurationColumn(xfeSessionModule, 50));
         firmAdded = true;
      }
   }

   private void removeFirmColumn()
   {
      if (firmAdded) {
         ordersTable.getColumns().remove(firmColumnIndex);
         ordersTable.getColumns().remove(ditColumnIndex);
         ordersTable.getColumns().add(ditColumnIndex, OrdersColumns.createDoneIfTouchedColumn(40));
         ordersTable.getColumns().remove(durationColumnIndex);
         ordersTable.getColumns().add(durationColumnIndex, OrdersColumns.createDurationColumn(xfeSessionModule, 65));
         firmAdded = false;
      }
   }

   private void attachTabSelectorAccelerators() {
      TabSelector tabSelector = new ToggleButtonPaneSelector(WeakCompositeRef.valueOf(tg),
         WeakCompositeRef.valueOf(ordersPane));
      ordersPane.get().addEventFilter(KeyEvent.KEY_PRESSED, KeyEventFilter.filterBy(tabSelector.reverseEvent(),
         new KeyCodeCombination(KeyCode.PAGE_UP, KeyCombination.CONTROL_DOWN)));
      ordersPane.get().addEventFilter(KeyEvent.KEY_PRESSED, KeyEventFilter.filterBy(tabSelector.forwardEvent(),
         new KeyCodeCombination(KeyCode.PAGE_DOWN, KeyCombination.CONTROL_DOWN)));
   }
   final BooleanProperty isMyTraders = new SimpleBooleanProperty();
   final SortValueFactory<ObservableReplyRow, OrderEntryTimeSequence> orderSequenceFactory = row -> new ObjectBinding<OrderEntryTimeSequence>() {
      @Override
      protected OrderEntryTimeSequence computeValue() {
         return new OrderEntryTimeSequence(
            row.getValue(AmpManagedOrder.entryTime),row.getValue(AmpManagedOrder.managedOrderId),row.getValue(AmpManagedOrder.normalOrderId),row.getValue(AmpManagedOrder.normalOrderDate));
      }
   };
   final BooleanProperty showReferred = new SimpleBooleanProperty(false);
   final BooleanProperty showMyTraders = new SimpleBooleanProperty(false);
   private final  CheckBox myTradersCheckbox = new CheckBox("My Traders");
   private final ObjectProperty<ObservableReplyRow> pendingOrder = new SimpleObjectProperty<>(null);
   private final ObjectProperty<DecoratedTitledPane> ordersPane = new SimpleObjectProperty<>();
   private final XfeAction withdrawAction = new XfeAction() {{
      getStyleClass().add("xfe-icon-withdraw");
      setText("Withdraw");
      setActionId("withdraw");

      setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            try {
               for (ObservableReplyRow order : dataContextModule.getWithdrawableOrders()) {
                  OrdersTrans.withdrawByOrderId(
                     xfeSessionModule.getUnderlyingSession(),
                     order.getAsn(AmpManagedOrder.currentOrderId), order.getString(AmpManagedOrder.userId),order.getString(AmpManagedOrder.introBrokerId),false);
               }
            } catch (Exception e) {
               logger.error("withdraw order failed.", e);
            }
         }
      });

   }};
   private final XfeAction renewAction = new XfeAction() {{
      setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            for (ObservableReplyRow order: dataContextModule.getRenewableOrders()) {
               OrdersTrans.activate(xfeSessionModule.getUnderlyingSession(), order.getAsn(AmpManagedOrder.currentOrderId),order.getValue(AmpManagedOrder.userId));
            }
         }
      });
      setText("Renew");
      setActionId("renew");
      getStyleClass().add("xfe-icon-small-renew");
   }};
   private final XfeAction referAction = new XfeAction() {{
      setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            for (ObservableReplyRow order: dataContextModule.getReferrableOrders()) {

               OrdersTrans.deactivate(xfeSessionModule.getUnderlyingSession(), order.getAsn(AmpManagedOrder.currentOrderId), order.getValue(AmpManagedOrder.userId));
            }
         }
      });
      setText("Refer");
      setActionId("refer");
      getStyleClass().add("xfe-icon-small-refer");
   }};
   private final ListenerTracker tracker = new ListenerTracker();
   private final Lazy<Property<Runnable>> interrogationActionProperty = new Lazy<Property<Runnable>>() {
      @Override
      protected Property<Runnable> initialize() {
         tracker.resets(this);
         return new SimpleObjectProperty<>();
      }
   };
   OrdersColumns columns;
   private final Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> orderInfoAction = new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
      @Override
      public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
         logger.debug("Creating Info popup");
         OrdersInfoPopup infoPopup = new OrdersInfoPopup(cell, row, columns, sessionModule.connectedProperty(),tracker, xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker());
         layoutManagerModule.register(infoPopup,null);
         infoPopup.show(cell.getScene().getWindow());
      }
   };
   private final Lazy<TableView<ObservableReplyRow>> view = new Lazy<TableView<ObservableReplyRow>>() {
      @Override
      protected TableView<ObservableReplyRow> initialize() {
         tracker.resets(this);
         return new TableViewHeaderUnmovable<ObservableReplyRow>() {
            {
               ServerSession serverSession = xfeSessionModule.getUnderlyingSession();
               List<TableColumn<ObservableReplyRow,?>> tableColumns = getColumns();
               tableColumns.add(OrdersColumns.createInstrumentColumn(interrogationActionProperty.get(), orderInfoAction));
               tableColumns.add(OrdersColumns.createPayRecColumn());
               tableColumns.add(OrdersColumns.createDoneIfTouchedColumn(40));
               tableColumns.add(OrdersColumns.createRateColumn());
               tableColumns.add(OrdersColumns.createBalanceColumn());
               tableColumns.add(OrdersColumns.createStatusColumn(isFlash));
               tableColumns.add(OrdersColumns.createAmendTimeColumn());
               tableColumns.add(OrdersColumns.createTraderColumn());
               tableColumns.add(OrdersColumns.createDurationColumn(xfeSessionModule, 65));
               tableColumns.add(columns.createReferColumn(serverSession));
               this.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            }
         };
      }
   };
   ObservableList<ObservableReplyRow> allOrders;
   ObservableList<ObservableReplyRow> myOrders;
   ObservableList<ObservableReplyRow> deskView;
   ObservableList<ObservableReplyRow> brokerView;
   ObservableList<ObservableReplyRow> pendingOrdersView;
   GlobalReferBtnsPresenter globalReferBtnsPresenter;
   private TableView<ObservableReplyRow> ordersTable;
   private boolean isActive;
   private boolean firmAdded;
   private FeedAggregator<ObservableReplyRow> ordersAggregator = new FeedAggregator<>(AMP.qREP("managedOrderRep"), new ObservableRowFactory());
   /*
    * Filter on the orders only to get the desired rfq orders.
    * Looking for order
    *    whose enter time is between starttime and endtime, inclusive, and
    *    whose userId, instrcode and boardId matches and
    *    whose balance is greater than zero
    *
    * Warning: Using linear searching here. If too many orders affects the performance, using an ordered list instead, ordered by enter time
    *
    * return a list of rfqs or null if underlying aggregator is busy
    */
   private FilteredStaticSorter<ObservableReplyRow> rfqOrderMovableFilter ;
   private Lazy<SelectionTracker<ObservableReplyRow>> selectionTracker;
   // Listening on other grids' selection change
   private final ChangeListener<SelectionContext> activeGridListener = new ChangeListener<SelectionContext>() {
      @Override
      public void changed(
         ObservableValue<? extends SelectionContext> observableVal,
         SelectionContext oldVal,
         SelectionContext newVal) {
         if (newVal.grid != GridType.Orders ) {
            selectionTracker.get().clearSelection();
            if(isActive) {
               ordersTable.getSelectionModel().clearSelection();
            }
         }
      }
   };
   private GlobalReferBtnsPane globalReferBtnsPane;
   private ToggleGroup tg = new ToggleGroup();
   private ToggleButton mineBtn;
   private ToggleButton deskBtn;
   private ToggleButton brokerBtn;
}
