package xfe.icap.modules.ordersdata;

import com.omxgroup.xstream.amp.AmpOrderStatus_v2;
import xfe.icap.amp.AmpManagedOrder;
import xstr.amp.AsnAccessor;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderEvent;
import xstr.types.OrderSide;

import java.math.BigDecimal;
import java.util.function.Predicate;

import static xstr.util.filter.RowFilters.*;

public class OrderFilters {

   private OrderFilters(){}

   public static Predicate<ObservableReplyRow> matchOperatorID(String operatorId) {
      return fieldEqual(AmpManagedOrder.operatorId, operatorId);
   }

   public static Predicate<ObservableReplyRow> matchSecCode(String secCode) {
      return fieldEqual(AmpManagedOrder.secCode, secCode);
   }

   public static Predicate<ObservableReplyRow> matchPrice(BigDecimal price) {
      return fieldEqual_bd(AmpManagedOrder.price, price);
   }

   public static Predicate<ObservableReplyRow> matchPriceAbs(BigDecimal price) {
      return fieldEqual_bd_abs(AmpManagedOrder.price, price);
   }

   public static Predicate<ObservableReplyRow> matchUserID(String userId) {
      return fieldEqual(AmpManagedOrder.userId, userId);
   }

   public static Predicate<ObservableReplyRow> notMatchUserID(String userId) {
      return fieldNotEqual(AmpManagedOrder.userId, userId);
   }

   public static Predicate<ObservableReplyRow> notMatchFirmID(String firmID) {
      return fieldNotEqual(AmpManagedOrder.firmId, firmID);
   }

   public static Predicate<ObservableReplyRow> matchBuySell(int buySell) {
      return fieldEqual(AmpManagedOrder.buySell, buySell);
   }

   public static Predicate<ObservableReplyRow> matchFirmID(String firmId) {
      return fieldEqual(AmpManagedOrder.firmId, firmId);
   }

   public static Predicate<ObservableReplyRow> matchReferredOrder() {
      return fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.privateOrder);
   }

   public static Predicate<ObservableReplyRow> matchSystemReferredOrder() {
      return fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.privateOrder)
         .and(fieldEqual(AmpManagedOrder.orderEvent, OrderEvent.rangeLimit)
            .or(fieldEqual(AmpManagedOrder.orderEvent, OrderEvent.clearforworkup)));
   }

   public static Predicate<ObservableReplyRow> matchOpenOrder() {
      return fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.open);
   }

   public static Predicate<ObservableReplyRow> matchIsWithdrawable() {
      return fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.open)
         .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.inactiveStop)
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.unplaced))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.unplacedStop))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.unapproved))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.unconfirmed))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.embargoed))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.confirmed))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.pending))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.clearingqueued))
            .or(fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.privateOrder)));
   }

   public static Predicate<ObservableReplyRow> matchAmendedOrder() {
      return fieldEqual(AmpManagedOrder.orderStatus, AmpOrderStatus_v2.amended);
   }

   public static Predicate<ObservableReplyRow> matchIsDarkOrder() {
      return fieldEqual(AmpManagedOrder.isDoneIfTouched, Boolean.TRUE);
   }

   public static Predicate<ObservableReplyRow> matchIsManagedOrder() {
      return fieldEqual(AmpManagedOrder.managedOrder, Boolean.TRUE);
   }

   public static Predicate<ObservableReplyRow> matchIsCMOrder(BigDecimal cmPrice) {
      // An order is CM if constant match price equals order's price and it is a dark order
      return  matchIsDarkOrder().and(matchPrice(cmPrice));
   }

   public static Predicate<ObservableReplyRow> matchIsCMOrderAbs(BigDecimal cmPrice) {
      // An order is CM if constant match price equals order's price and it is a dark order
      return  matchIsDarkOrder().and(matchPriceAbs(cmPrice));
   }

   public static Predicate<ObservableReplyRow> matchSide(OrderSide side) {
      return fieldEqual(AmpManagedOrder.buySell, side.ordinal());
   }

   public static Predicate<ObservableReplyRow> matchIsCloned() {
      return  fieldEqual(AmpManagedOrder.orderType,"Clone");
   }

   public static Predicate<ObservableReplyRow> matchOrderId(AsnAccessor rowOrderId) {
      return fieldEqualsAsn(AmpManagedOrder.currentOrderId, rowOrderId);
   }
}
