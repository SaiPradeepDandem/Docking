package xfe.icap.modules.settings;

public class SettingsChoice<T> {
   public final String text;
   public final T value;

   public SettingsChoice(String text, T value) {
      this.text = text;
      this.value = value;
   }

   @Override
   public String toString() {
      return text;
   }
}
