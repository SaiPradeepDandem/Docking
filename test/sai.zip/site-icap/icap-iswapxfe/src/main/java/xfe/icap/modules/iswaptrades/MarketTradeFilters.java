package xfe.icap.modules.iswaptrades;

import com.omxgroup.xstream.amp.AmpStrategyTradeType_v2;
import xfe.amp.AmpMarketTrade;
import xfe.icap.types.Trade;
import xstr.session.ObservableReplyRow;

import java.util.Objects;
import java.util.function.Predicate;

public class MarketTradeFilters {
   public static Predicate<ObservableReplyRow> isBuyOutright() {
      return (row) -> Objects.equals(Integer.valueOf(AmpStrategyTradeType_v2.outright), row.getValue(AmpMarketTrade.buyStrategyTradeType));
   }

   public static Predicate<ObservableReplyRow> isSellOutright() {
      return (row) -> Objects.equals(Integer.valueOf(AmpStrategyTradeType_v2.outright), row.getValue(AmpMarketTrade.sellStrategyTradeType));
   }

   public static Predicate<ObservableReplyRow> isBuyStrategy() {
      return (row) -> Trade.isStrategyType(row.getValue(AmpMarketTrade.buyStrategyTradeType));
   }

   public static Predicate<ObservableReplyRow> isSellStrategy() {
      return (row) -> Trade.isStrategyType(row.getValue(AmpMarketTrade.sellStrategyTradeType));
   }

   public static Predicate<ObservableReplyRow> isBuyStrategyLeg() {
      return (row) -> Trade.isLegType(row.getValue(AmpMarketTrade.buyStrategyTradeType));
   }

   public static Predicate<ObservableReplyRow> isSellStrategyLeg() {
      return (row) -> Trade.isLegType(row.getValue(AmpMarketTrade.sellStrategyTradeType));
   }
}
