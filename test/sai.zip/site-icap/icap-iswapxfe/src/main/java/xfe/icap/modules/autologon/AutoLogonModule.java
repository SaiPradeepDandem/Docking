package xfe.icap.modules.autologon;

import javafx.animation.Animation.Status;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ObservableValue;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.session.SessionListener;
import xfe.types.UiSession;
import xstr.util.Fun0Throws;
import xstr.util.Functions;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.FutureFn;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.Exceptions;
import xstr.util.exception.XtrException;
import xfe.module.Module;
import xfe.modules.logon.LogonModule;
import xfe.modules.session.SessionModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.ui.logon.impl.ConnectionStatusPane;
import xfe.ui.notifications.ModalAlertModule;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

//TODO: Move this into LogonModule - It does not have to be a module on its own.
@Deprecated // All the functionality of this module should be integrated into LogonModule
@Module.Autostart
public class AutoLogonModule implements Module,SessionListener {
   private static final Logger logger = LoggerFactory.getLogger(AutoLogonModule.class);

   @ModuleDependency
   public ConfigurationModule settingsModule;
   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public UiSession xfeSessionModule;
   @ModuleDependency
   public ConnectionStatusPane logonViewModule;
   @ModuleDependency
   public ModalAlertModule eventNotificationModule;
   @ModuleDependency
   public LogonModule logonModule;

   private static final Pattern errorMsgPattern = Pattern.compile("\\((\\d+)\\)\\s*:");
   private static final int ERRORCODE_LOGGEDOFFBYSU = 99;

   @Override
   public Future<Void> startModule() {
      sessionModule.suppressErrorsProperty().bind(enabled);
      xfeSessionModule.getUnderlyingSession().addSessionListener(this);
      xfeSessionModule.getUnderlyingSession().addPreLogonTask(preLogon);
//      xfeSessionModule.getUnderlyingSession().addPreLogoffTask(preLogoff);
      xfeSessionModule.getUnderlyingSession().addDisconnectTask(onDisconnect);
      logonViewModule.canDoAutologonProperty().addListener(this::autoLogonChanged);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      logonViewModule.canDoAutologonProperty().removeListener(this::autoLogonChanged);
      xfeSessionModule.getUnderlyingSession().removeDisconnectTask(onDisconnect);
//      xfeSessionModule.getUnderlyingSession().removePreLogoffTask(preLogoff);
      xfeSessionModule.getUnderlyingSession().removePreLogonTask(preLogon);
      xfeSessionModule.getUnderlyingSession().removeSessionListener(this);
      enabled.unbind();
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> handleLogon() {
      if (logonViewModule.autologonVisibleProperty().get()) {
         logger.info("Autologon succeeded");
      }
      logonViewModule.autologonVisibleProperty().set(false);
      enabled.bind(settingsModule.getData().autoLogonEnabledProperty().and(sessionModule.isTwoFactorAuthRO.not()));
      timeoutSeconds.bind(settingsModule.getData().autoLogonTimeoutProperty());
      return SessionListener.DONE;
   }

   private void stopTimer() {
      if (timeline.getStatus() == Status.RUNNING) {
         logger.info("Stopping autologon timer");
         logonViewModule.autologonVisibleProperty().set(false);
         timeline.stop();
      }

      timeline.getKeyFrames().removeAll();
   }

   private void startTimer() {
      logonViewModule.autologonVisibleProperty().set(true);
      logonViewModule.autoLogonTimeoutProperty().set(timeoutSeconds.get());
      timeline.stop();
      timeline.getKeyFrames().removeAll();
      KeyValue startVal = new KeyValue(logonViewModule.autoLogonTimeRemainingProperty(), timeoutSeconds.get());
      timeline.getKeyFrames().add(new KeyFrame(Duration.ZERO, startVal));
      KeyValue endVal = new KeyValue(logonViewModule.autoLogonTimeRemainingProperty(), 0.0);
      timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(timeoutSeconds.get()), endVal));
      timeline.setOnFinished(actionEvent -> {
         logger.info("Performing Autologon...");
         try {
            sessionModule.autoLogon().onError(e -> {
               logger.error("Auto Logon error: {}", e.getMessage());

               if (e instanceof AmpPermissionException) {
                  eventNotificationModule.showError(e.getMessage());
               } else {
                  String origMsg = e.getMessage();
                  Matcher matcher;
                  int errorCode = 0;
                  if (origMsg != null && (matcher = errorMsgPattern.matcher(origMsg)).find()) {
                     errorCode = Integer.valueOf(matcher.group(1));
                  }

                  switch (errorCode) {
//                     case 89:    // User already logged on
                     case ERRORCODE_LOGGEDOFFBYSU: //user is force logged off by super user
                        logonViewModule.autologonVisibleProperty().set(false);
                        stopTimer();
                        eventNotificationModule.showError(e.getMessage());
                        break;
                     case 92:
                     case 124:   // Incorrect username or password
                        logonViewModule.autologonVisibleProperty().set(false);
                        stopTimer();
                        String msg = Exceptions.format(e);
                        eventNotificationModule.showError(msg);
                        break;
                     default:
                        if (enabled.get()) {
                           logger.info("Retrying Autologon...");
                           startTimer();
                        }
                  }
               }

               throw Functions.wrapException(e);
            });
         } catch (Exception e) {
            boolean isLoggedon = sessionModule.xfeSessionModule.loggedOnProperty().get();
            logger.error("auto logon exception. isLoggedon is "+isLoggedon,e);
            if(!isLoggedon){
               startTimer();
            }
         }
      });

      timeline.playFromStart();
   }

   private void autoLogonChanged(ObservableValue<? extends Boolean> o, Boolean oldVal, Boolean newVal) {
      if (!newVal) {
         logonViewModule.autologonVisibleProperty().set(false);
         stopTimer();
      }
   }

   private final Timeline timeline = new Timeline();
   private final BooleanProperty enabled = new SimpleBooleanProperty(this, "enabled", true);
   private final IntegerProperty timeoutSeconds = new SimpleIntegerProperty(this, "timeoutSeconds", 10);
   private final Fun0Throws<Future<Void>> preLogoff = new Fun0Throws<Future<Void>>() {
      @Override
      public Future<Void> call() {
         enabled.unbind();
         enabled.set(false);
         timeoutSeconds.unbind();
         logonViewModule.autologonVisibleProperty().set(false);
         return Future.SUCCESS;
      }
   };

   private final Fun0Throws<Future<Void>> preLogon = () -> {
      stopTimer();
      return Future.SUCCESS;
   };

   private final FutureFn<XtrException, Void> onDisconnect = new FutureFn<XtrException, Void>() {
      @Override
      public Future<Void> call(XtrException e) {
         String origMsg = e.getMessage();
         Matcher matcher;
         int errorCode = 0;
         if (origMsg != null && (matcher = errorMsgPattern.matcher(origMsg)).find()) {
            errorCode = Integer.valueOf(matcher.group(1));
         }
         if(errorCode==ERRORCODE_LOGGEDOFFBYSU){
            eventNotificationModule.showError(e.getMessage());
         } else {
            if( enabled.get() && xfeSessionModule.loggedOnProperty().get()) {
               logger.info("Unexpected disconnect. Initiating Auto Logon.",e);
               startTimer();
            }
         }
         enabled.unbind();
         timeoutSeconds.unbind();
         return Future.SUCCESS;
      }
   };
}
