package xfe.icap.types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xfe.types.StepArray;
import xstr.util.Fun1;
import xstr.util.concurrent.Future;

public class StepArrays {
   private static final Logger logger = LoggerFactory.getLogger(StepArrays.class);

   private final SecBoards secBoards;

   public StepArrays(SecBoards secBoards) {
      this.secBoards = secBoards;
   }

   public Future<StepArray> getSpinPriceStepArray(SecBoard secboard) {
      return secBoards.getStatics(secboard).map(info -> info.priceContext.getSpinStepArray());
   }

   Future<StepArray> getSpinPriceStepArray(String secCode, String boardId) {
      return secBoards.getSecBoard(secCode, boardId).onSuccess(this::getSpinPriceStepArray);
   }

   public Future<StepArray> getSpinQtyStepArray(SecBoard secboard) {
      return secBoards.getStatics(secboard).map(info -> info.qtyContext.getSpinStepArray());
   }

   public Future<StepArray> getPriceStepArray(SecBoard secboard) {
      return secBoards.getStatics(secboard).map(info -> info.priceContext.getStepArray());
   }

   public Future<StepArray> getQtyStepArray(SecBoard secboard) {
      return secBoards.getStatics(secboard).map(info -> info.qtyContext.getStepArray());
   }

   public Future<Double> getNextPrice(String boardId, String secCode, double price, boolean isUp) {
      return getSpinPriceStepArray(secCode, boardId).onSuccess(new Fun1<StepArray, Double>() {

         @Override
         public Double call(StepArray stepArray) {
            return stepArray.notch(price, isUp ? 1 : -1);
         }
      });
   }
}
