package xfe.icap.modules.sweep;

import com.omxgroup.xstream.amp.AmpDisplayCredit;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.scene.control.ToggleButton;
import javafx.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.ui.control.IconToggleButton;
import xstr.amp.AsnAccessor;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpOrderBookByOrder;
import xstr.session.ObservableReplyRow;
import xfe.icap.types.Orders;
import xfe.types.StepArray;
import xfe.util.Constants;
import xstr.util.ListenerTracker;
import xstr.util.Strings;
import xstr.util.concurrent.Future;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.icap.XfeSession;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.selectioncontext.SelectedRowCellContext;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.module.Module;
import xfe.icap.modules.obbo.ObboModule;
import xfe.icap.modules.orderentry.EntryModule;
import xfe.modules.session.SessionScopeModule;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;

@Module.Autostart
public class SweepModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(SweepModule.class);

   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public DataContextModule dataContextModule;
   @ModuleDependency
   public ObboModule obboModule;
   @ModuleDependency
   public EntryModule entryModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;

   @Override
   public Future<Void> startModule() {

      sweepBtn = new ToggleButton("Sw") {{
         this.getStyleClass().add("xfe-sweep-toggle");
         this.setId("xfe-iswap-Depth-tg-sweep");
         XfeTooltipFactory.setTooltip(this);
      }};
      obboModule.addSweepBtn(sweepBtn);
      tracker.addListener(selectionContextModule.dataContextRfqSessionSec, new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            if(selectionContextModule.dataContextRfqSessionSec.get()){
               sweepBtn.setDisable(true);
            }else{
               sweepBtn.setDisable(false);
            }
         }
      });


      tracker.addListener(inSweep, (arg0, oldSweepMode, newSweepMode) -> {
         if (newSweepMode) {
            setSweep();
            applySweepValues(null, null, null);
         } else {
            resetSweep();
            cedeSweepValues();
            resetHighlight();
         }
      });

      // If the busy property is changed this means that a new instrument has been selected
      // and we started/finished loading the order books for this instrument

      // If we are in Stable Sweep Mode then we need to re-sweep
      // orderbooks finished loading and once readyToSweep is true
      // (flag is set to true when instrument is selected)

      tracker.addListener(obboModule.getOrderBook().getAggregator().busyProperty(), (arg0, oldBusyVal, newBusyVal) -> {
         if (oldBusyVal && !newBusyVal) {
            if (readyToSweep) {
               // We finished loading the order book already and can do the work

               // Calculating values for Rate/Size and Highlighting all order book
               // orders on that side

               // Sweeping
               if (isSweepedSideBuy != null) {
                  numberOfSweepedRows = isSweepedSideBuy ? obboModule.getOrderBook().bidSide.orders.size() :
                     obboModule.getOrderBook().offerSide.orders.size();
                  calcAndSweep(null, null, null);
               }

               readyToSweep = false;
            } else {
               // readyToSweep is false - nothing to do?!
            }
         }
      });

      tracker.addListener(obboModule.getOrderBook().bidSide.orders, (Observable arg0) -> {

         if (obboModule.getOrderBook().getAggregator().busyProperty().get()) return;

         // If the swept side has a data change we re-calculate the new number of rows
         // but retain the same sweep values
         if (inSweep.get() && isSweepedSideBuy != null && isSweepedSideBuy) {
            Double rate = entryModule.orderEntryPresenter.get().getPaneRateProperty().getValue();
            Double size = entryModule.orderEntryPresenter.get().getPaneSizeProperty().getValue();

            // If the values are blank we just make sure the highlight is reset
            // (not sure if this can be wrong anyway)
            if (rate == null || size == null) {
               resetHighlight();
               return;
            }

            calcAndSweep(rate, size, null);
         }
      });

      tracker.addListener(obboModule.getOrderBook().offerSide.orders, (Observable arg0) -> {

         if (obboModule.getOrderBook().getAggregator().busyProperty().get()) return;

         if (inSweep.get() && isSweepedSideBuy != null && !isSweepedSideBuy) {
            Double rate = entryModule.orderEntryPresenter.get().getPaneRateProperty().getValue();
            Double size = entryModule.orderEntryPresenter.get().getPaneSizeProperty().getValue();

            // If the values are blank we just make sure the highlight is reset
            // (not sure if this can be wrong anyway)
            if (rate == null || size == null) {
               resetHighlight();
               return;
            }

            calcAndSweep(rate, size, null);
         }
      });

      tracker.addListener(sweepBtn.selectedProperty(), arg0 -> {

         // If the orders grid is selected then we cannot get into sweep mode even
         // if we press the sweep button
         if (selectionContextModule.gridTypeProperty.get().getValue() == GridType.Orders)
            return;

         // sweep button gets selected and we were not in sweep mode already
         // (were not in temporary sweep mode)
         if (sweepBtn.isSelected() && !inSweep.get()) {
            // Getting into sweep mode and blanking sweep values until we calculate them
            inSweep.set(true);
            applySweepValues(null, null, null);

            if (selectionContextModule.selectedObboRowProperty().getValue() != null &&
               selectionContextModule.getSelectionContext().rowIndex >= 0) {
               // If the user selects a bid or offer row in the orderbook whilst the sweep icon
               // is activated then we will select and highlight that order as well as all other
               // orders better than it.
               numberOfSweepedRows = selectionContextModule.getSelectionContext().rowIndex + 1;
               if (selectionContextModule.gridTypeProperty.get().getValue() == GridType.OBBO_BUY)
                  isSweepedSideBuy = true;
               else if (selectionContextModule.gridTypeProperty.get().getValue() == GridType.OBBO_SELL)
                  isSweepedSideBuy = false;
               else
                  isSweepedSideBuy = null;

               // Re-calc values for Rate/Size and highlight up to selected row
               calcAndSweep(null, null, numberOfSweepedRows);
            }
            else if (selectionContextModule.gridTypeProperty.get().getValue() == GridType.Watchlist) {
               SelectedRowCellContext currentLine = selectionContextModule.selectedSecurityRowProperty().getValue();
               if (currentLine != null) {
                  AsnAccessor selectedField = currentLine.selectedFieldProperty().get();

                  if (selectedField != null) {
                     if (AmpIcapSecBoardTrim2.offerSide.contains(selectedField)) {
                        numberOfSweepedRows = obboModule.getOrderBook().offerSide.orders.size();
                        isSweepedSideBuy = false;
                     }
                     else if (AmpIcapSecBoardTrim2.bidSide.contains(selectedField)) {
                        numberOfSweepedRows = obboModule.getOrderBook().bidSide.orders.size();
                        isSweepedSideBuy = true;
                     }
                     else isSweepedSideBuy = null;

                     // Re-calc values for Rate/Size and highlight all order book
                     // orders on that side
                     calcAndSweep(null, null, null);
                  }
               }
            }
         }
         else {

            // Sweep button has been depressed
            // Getting out of sweep mode, removing highlighting and sweep values
            if (!sweepBtn.isSelected()) {
               inSweep.set(false);
            } else {
               // Changing from temporary sweep mode to fixed one - nothing to do
            }
         }
      });

      this.obboModule.setSweepObboDragClbk(this::onObboDrag);
      this.obboModule.setSweepObboClickClbk(this::onObboClick);

      tracker.addListener(entryModule.rateEditProperty.get(), (o, oldRate, newRate) -> {

         if (inSweep.get()) {

            if (selectionContextModule.getSelectionContext().grid == GridType.Orders) return;

            // We need to prevent infinite recursion of rate->size->rate changes
            if (entryModule.orderEntryPresenter.get().getPaneSizeProperty().getValue() != null &&
               wavgRate.equals(newRate) || newRate == null) return;

            calcAndSweep(newRate, null, null);
         }
      });

      tracker.addListener(entryModule.orderEntryPresenter.get().getPaneSizeProperty(), (arg0, oldQtyVal, newQtyVal) -> {

         if (inSweep.get()) {

            if (selectionContextModule.getSelectionContext().grid == GridType.Orders) return;

            // We need to prevent infinite recursion of size->rate->size changes
            if (entryModule.orderEntryPresenter.get().getPaneRateProperty().getValue() != null &&
               totalQty.equals(newQtyVal) || newQtyVal == null) return;

            calcAndSweep(null, newQtyVal, null);
         }
      });

      tracker.addListener(obboModule.manualSelect, arg0 -> {
         if (obboModule.manualSelect.get() != null)
            inSweep.set(false);
      });

      ChangeListener<SelectionContext> selectionContextListener = (arg0, oldContext, newContext) -> {
         if (newContext != null &&
            newContext.grid == GridType.Orders) {

            // Getting out of sweep mode.
            inSweep.set(false);
            return;
         }

         if (sweepBtn.isSelected()) {
            // We are-in/go-into Fixed Sweep Mode
            inSweep.set(true);

            // We need to respond to selection change on watchlist
            // Selections on obbo will be treated via obbo mouse click
            // so that changes to orderbook that may trigger a selection
            // change can be ignored here.

            if (newContext != null &&
               newContext.grid == GridType.Watchlist &&
               (oldContext == null ||
                  !newContext.row.equals(oldContext.row) ||
                  !newContext.field.equals(oldContext.field))) {

               // Removing current highligting
               resetHighlight();

               // Finding the side to sweep
               if (AmpIcapSecBoardTrim2.bidSide.contains(newContext.field))
                  isSweepedSideBuy = true;
               else if (AmpIcapSecBoardTrim2.offerSide.contains(newContext.field))
                  isSweepedSideBuy = false;
               else
                  isSweepedSideBuy = null;

               // It may take some time to load the orderbook
               if (obboModule.getOrderBook().getAggregator().busyProperty().get()) {
                  // We are busy loading the order book, so the listener for this
                  // property will be responsible for the work.
                  readyToSweep = true;
               } else {
                  // We finished loading the order book already and can do the work

                  // Re-calc values for Rate/Size and re highlight for all order book
                  // orders on that side
                  if (isSweepedSideBuy != null) {
                     numberOfSweepedRows = isSweepedSideBuy ? obboModule.getOrderBook().bidSide.orders.size() :
                        obboModule.getOrderBook().offerSide.orders.size();
                  }
                  calcAndSweep(null, null, null);
               }
            }

         } else {
            // We are in Transient Sweep Mode
            // Any selection event would sweep out except
            // for selections in the active obbo as we will
            // handle these through mouse clicks

            if (oldContext != null &&
               newContext != null &&
               (oldContext.grid == GridType.OBBO_BUY ||
                  oldContext.grid == GridType.OBBO_SELL) &&
               oldContext.grid == newContext.grid) return;

            //Get out of sweep mode.
            inSweep.set(false);
         }
      };

      tracker.addListener(this.selectionContextModule.selectionContextProperty(), selectionContextListener);

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      obboModule.removeSweepBtn(sweepBtn);
      obboModule.setSweepObboDragClbk(null);
      obboModule.setSweepObboClickClbk(null);
      tracker.rollback();
      return Future.SUCCESS;
   }

   private Void onObboClick(Pair<Boolean, Integer> clickedRow) {
      if (sweepBtn.isSelected()) {
         // In fix mode we get into sweep or stay in it
         inSweep.set(true);
         resetHighlight();
         isSweepedSideBuy = clickedRow.getKey();
         calcAndSweep(null, null, clickedRow.getValue() + 1);
      } else if (inSweep.get()) {
         // In transient mode we get our of sweep
         inSweep.set(false);
      }

      return null;
   }

   private void calcAndSweep(Double enteredRate, Double enteredQty, Integer maxToSweep) {
      boolean calcResult = calcRateAndQty(enteredRate, enteredQty, maxToSweep);

      // We never change the values if both are entered - only re-hghlight in this case
      boolean rateEntered = (enteredRate != null);
      boolean qtyEntered = (enteredQty != null);
      boolean bothEntered = rateEntered && qtyEntered;

      if (calcResult) {
         highLight();
         if (!bothEntered)
            applySweepValues(wavgRate, totalQty, isSweepedSideBuy);
      } else {
         resetHighlight();
         if (!bothEntered) {
            if (rateEntered)
               applySweepValues(enteredRate, null, null);
            else if (qtyEntered)
               applySweepValues(null, enteredQty, null);
            else
               applySweepValues(null, null, null);
         }
      }
   }

   private boolean calcRateAndQty(Double enteredRate, Double enteredQty, Integer maxToSweep) {

      // If this method is invoked with both parameters being null it means
      // we need to calculate them both.

      // If the method is called with only one of them null, then this one needs to be calculated
      // based on the one with the valid value.

      // If both rate and size are specified then we need to find the number of rows to
      // highlight that will fit these values

      if (isSweepedSideBuy == null) {
         logger.trace("isSweepedSideBuy is null. Can't sweep");
         return false;
      }

      double qtyDecimals = this.selectionContextModule.secBoardContext.get().getSpinQtyDecimals();
      double comparedEnteredRate = 0.0;

      if (enteredRate != null) {
         comparedEnteredRate = isSweepedSideBuy ? -enteredRate : enteredRate;
      }
      boolean autoCalc = (enteredRate == null && enteredQty == null);
      double tempPrevTotalQty, tempTotalQty = 0.0;
      double tempPrevTotalWorth, tempTotalWorth = 0.0;
      double tempWavgRate;
      double totalWorth = 0.0;

      int totalNumRows = isSweepedSideBuy ? obboModule.getOrderBook().bidSide.orders.size() :
         obboModule.getOrderBook().offerSide.orders.size();

      // If we get here via normal sweep, then the total number of rows for this side
      // cannot be less than the one we sweep
      if (autoCalc && (totalNumRows < (maxToSweep == null ?
         numberOfSweepedRows : Math.min(numberOfSweepedRows, maxToSweep)))) {
         logger.trace("autoCalc is true and totalNumRows less than {} or {}. Can't sweep",numberOfSweepedRows,maxToSweep);
         return false;
      }

      // We do not sweep manual changes of quantity that are 0 or below.
      if (enteredQty != null && enteredQty <= 0.0) {
         logger.trace("enteredQty is {}(not null) and it is less than zero. Can't sweep",enteredQty);
         return false;
      }

      if (maxToSweep != null) totalNumRows = maxToSweep;
      int tempNumberOfSweepedRows = 0;
      int index = 0;
      boolean foundEqualAvg = false; // indicates if we found an exact average
      int tempNumberOfSweepedRowsExact = 0;
      for (; index < totalNumRows; ++index) {
         ObservableReplyRow row = isSweepedSideBuy ? obboModule.getOrderBook().bidSide.orders.get(index) :
            obboModule.getOrderBook().offerSide.orders.get(index);

         // Skipping rows with no credit and indicatives
         if (row.getValue(AmpOrderBookByOrder.orderTradability).equals(AmpDisplayCredit.no) ||
            Constants.PRICE_TYPE_INDICATIVE.equals(row.getProperty(AmpOrderBookByOrder.specialOrderType).get())) {
            logger.trace("{} can't sweep, since orderTradability is no or it is indicative",row);
            continue;
         }

         // Skipping an rfq/rfs that are not auto-accept
         boolean isAutoAccept = Orders.isAutoAcceptOrder(row);
         if (!isAutoAccept){
            logger.trace("{} can't sweep since it is isAutoAccept is false",row);
            continue;
         }
         if (autoCalc && index + 1 > totalNumRows){
            logger.trace("autoCalc is true and index({}) is greater than totalnumberrows(). stop sweeping",index,totalNumRows);
            break;
         }

         if (dataContextModule.dataContextRfsOrRfqSec.get() && tempNumberOfSweepedRows == xfeSessionModule.getUnderlyingSession().getStats().rfqRfsMaxSweepNum) {
            logger.trace("rfq instrument and the swept row({}) is equals rfqMaxSweepnumber. stop sweeping.",tempNumberOfSweepedRows);
            break;
         }

         ++tempNumberOfSweepedRows;
         numberOfSweepedRows = index + 1;

         Double currQty = row.getValue(AmpOrderBookByOrder.quantity);
         Double currRate = getRoundedRate(row.getValue(AmpOrderBookByOrder.price));
         tempPrevTotalQty = tempTotalQty;
         tempTotalQty += currQty;
         tempPrevTotalWorth = tempTotalWorth;
         tempTotalWorth += currRate * currQty;
         tempWavgRate = (tempTotalQty == 0.0) ? 0.0 : tempTotalWorth / tempTotalQty;
         if (isSweepedSideBuy)
            tempWavgRate = -tempWavgRate;

         if (!autoCalc) {
            if (enteredQty != null) {
               if (tempTotalQty > enteredQty) {
                  // The calculated quantity is bigger than the entered one
                  // after sweeping a single row
                  // In this case we need to return the best rate
                  // but remove highlight
                  if (tempNumberOfSweepedRows == 1) {
                     // Blank rate and remove highlight
                     numberOfSweepedRows = -1;
                     wavgRate = isSweepedSideBuy ? -tempWavgRate : tempWavgRate;
                     totalQty = enteredQty;
                     return true;
                  }

                  totalWorth += currRate * (enteredQty - tempPrevTotalQty);
                  tempTotalQty = enteredQty;
                  tempNumberOfSweepedRows = numberOfSweepedRows;
                  break;
               } else {
                  totalWorth = tempTotalWorth;

                  if (tempTotalQty == enteredQty) {
                     tempNumberOfSweepedRows = numberOfSweepedRows;
                     logger.trace("enteredQty({}) is equals swept quantity. stop sweeping.",tempTotalQty);
                     break;
                  }
               }
            }

            if (enteredRate != null) {
               tempWavgRate = getRoundedRate(tempWavgRate);
               if (comparedEnteredRate < tempWavgRate) {
                  // The calculated average rate is bigger than the entered one
                  // after sweeping a single row
                  // In this case we need blank the size and reset the highlight
                  if (tempNumberOfSweepedRows == 1) {
                     // Blank size and remove highlight
                     return false;
                  }

                  double diffRate = Math.abs(currRate - enteredRate);
                  tempTotalQty = tempPrevTotalQty + Math.abs((enteredRate * tempPrevTotalQty - tempPrevTotalWorth) / diffRate);
                  break;
               } else if (tempWavgRate == comparedEnteredRate) {
                  // We need to know that we reached here
                  foundEqualAvg = true;
                  tempNumberOfSweepedRowsExact = numberOfSweepedRows;
               }
            }
         }
         else {
            totalWorth += currRate * currQty;
         }
      }

      if (tempTotalQty == 0.0) {
         return false;
      }

      if (index == totalNumRows) {
         tempNumberOfSweepedRows = numberOfSweepedRows;
      }

      if (!autoCalc) {
         numberOfSweepedRows = foundEqualAvg ? tempNumberOfSweepedRowsExact : tempNumberOfSweepedRows;
      }

      // Since in this case we do not change the values we can skip
      // the rounding code below
      if (enteredRate != null && enteredQty != null) {
         return true;
      }

      Double roundedTotalQty, roundedWavgRate;
      if (enteredRate != null) {
         roundedTotalQty = tempTotalQty;
         roundedWavgRate = enteredRate;
      } else {
         roundedTotalQty = tempTotalQty;
         roundedWavgRate = totalWorth / roundedTotalQty;
      }

      wavgRate = getRoundedRate(roundedWavgRate);

      NumberFormat df = DecimalFormat.getInstance();
      df.setMinimumFractionDigits((int) qtyDecimals);
      df.setMaximumFractionDigits((int) qtyDecimals);
      df.setRoundingMode(isSweepedSideBuy ?  RoundingMode.UP : RoundingMode.DOWN);

      Double potentialTotalQty = Double.parseDouble(df.format(roundedTotalQty)
         .replaceAll(Strings.regexGroupingSeparator(), "")
         .replaceAll(",","."));

      StepArray qtyArr = this.selectionContextModule.secBoardContext.get().getQtySteps();

      Double validTotalQty = potentialTotalQty;
      if (!qtyArr.isValid(potentialTotalQty))
         validTotalQty = this.selectionContextModule.secBoardContext.get().getQtySteps().notch(potentialTotalQty, -1);

      totalQty = validTotalQty;

      return true;
   }

   private Double getRoundedRate(Double avgRate) {
      double priceDecimals = this.selectionContextModule.secBoardContext.get().getPriceDecimals();
      double delta = Math.pow(10, -priceDecimals)/2;
      if (isSweepedSideBuy) delta = -delta;

      if (avgRate < 0) avgRate = avgRate - delta;
      if (avgRate > 0) avgRate = avgRate + delta;


      NumberFormat df = DecimalFormat.getInstance();
      df.setMinimumFractionDigits((int) priceDecimals);
      df.setMaximumFractionDigits((int) priceDecimals);
      df.setRoundingMode(isSweepedSideBuy ?  RoundingMode.UP : RoundingMode.DOWN);
      return Double.parseDouble(df.format(avgRate)
         .replaceAll(Strings.regexGroupingSeparator(), "")
         .replaceAll(",","."));
   }

   private void setSweep() {
      entryModule.orderEntryPresenter.get().setSweep();
   }

   private void resetSweep() {
      entryModule.orderEntryPresenter.get().resetSweep();
   }

   private void highLight() {
      if (isSweepedSideBuy != null)
         obboModule.highlightTo(isSweepedSideBuy, numberOfSweepedRows - 1);
   }

   private void resetHighlight() {
      if (isSweepedSideBuy != null)
         obboModule.highlightTo(isSweepedSideBuy, -1);
   }

   private void cedeSweepValues() {
      entryModule.orderEntryPresenter.get().cedeSweepValues();
   }

   private void applySweepValues(Double wavgRate, Double totalQty, Boolean isSweepBuy) {
      entryModule.orderEntryPresenter.get().applySweepValues(wavgRate, totalQty, isSweepBuy);
   }

   private Void onObboDrag(Pair<Boolean, Integer> rows) {
      //whileDragging = (rows != null);

      if (rows == null || sweepBtn.isDisabled()) return null;

      inSweep.set(true);
      resetHighlight();
      isSweepedSideBuy = rows.getKey();
      calcAndSweep(null, null, rows.getValue());

      return null;
   }
   private final BooleanProperty inSweep = new SimpleBooleanProperty(false);
   private final ListenerTracker tracker = new ListenerTracker();
   private ToggleButton sweepBtn;
   private Integer numberOfSweepedRows = 0;
   private Boolean isSweepedSideBuy;
   private Double totalQty = 0.0;
   private Double wavgRate = 0.0;
   private boolean readyToSweep;
}

