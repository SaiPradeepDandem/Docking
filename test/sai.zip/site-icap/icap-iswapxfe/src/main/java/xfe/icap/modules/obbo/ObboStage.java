package xfe.icap.modules.obbo;

import java.util.*;

import xfe.modules.appcontext.FxApplicationModule;
import xfe.icap.XfeSession;
import xfe.icap.modules.watchlist.InstrumentsPane;
import xfe.icap.modules.watchlist.WatchlistModule;
import xfe.icap.types.IcapSecBoardTrim2Watchlist;
import xfe.icap.types.OrderBook;
import xfe.types.SecBoard;
import xfe.types.Watchlist;
import xstr.util.Fun1;

import xfe.icap.types.OrderBook.OrderBookKey;
import xstr.util.ListenerTracker;
import xfe.util.scene.control.VerticalAppContainer;
import xfe.layout.LayoutManager;
import xstr.session.ObservableReplyRow;

import javafx.event.EventHandler;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.*;

public class ObboStage extends Stage {


   private final VerticalAppContainer appContainer = new VerticalAppContainer();
   private final OrderBook orderBook ;
   private final IndependentObboTablePanel obboTable;
   private final Watchlist watchlist;
   public ObboStage(LayoutManager<Node> layoutManager, XfeSession session,
                    ObboModule module, String secName, String secBoard, WatchlistModule watchlistModule, Map<String, ObboStage> openedDepth, String key, MouseEvent mouseEvent) throws Exception{
      super(StageStyle.TRANSPARENT);
//      ZoomableDecorator.makeWindowZoomable(this);
      appContainer.setId("obboStageAppContainer");
      setX(mouseEvent.getScreenX());
      setY(mouseEvent.getScreenY());
      watchlist = new IcapSecBoardTrim2Watchlist(session);
      requestWatchlist(session,secName,secBoard);
      this.setTitle(secName);
      ImageView logo = new ImageView();
      logo.getStyleClass().add("xfe-icon-app-title");
      orderBook = new OrderBook(session,module);
      orderBook.setKey(new OrderBookKey(secName,
         secBoard,session.onBehalfTrader.get() == null ?
         null :
         session.onBehalfTrader.get().getId(),
         null));
      Label secCode = new Label(secName);
      secCode.requestFocus();
      secCode.cursorProperty().set(Cursor.HAND);
      secCode.setPrefWidth(FxApplicationModule.MAIN_STAGE_WIDTH - 100 * 2);
      secCode.getStyleClass().add("xfe-depth-popup-title");
      AnchorPane.setTopAnchor(logo, 5.0);
      AnchorPane.setLeftAnchor(logo, 10.0);
      AnchorPane.setTopAnchor(secCode, 5.0);
      AnchorPane.setLeftAnchor(secCode, 105.0);
      AnchorPane body = new AnchorPane();
      body.getChildren().addAll(logo, secCode);
      body.getStyleClass().add("xfe-depth-popup");

      ListenerTracker tracker = new ListenerTracker();
      VBox vbox = new VBox();
      TableView<ObservableReplyRow> instrumentTable = watchlistModule.createInstrumentTableView(true, tracker);
      instrumentTable.setItems(watchlist.getItems());
      obboTable = new IndependentObboTablePanel(session, module.modalAlertModule, orderBook,  module,true);
      tracker.bind(obboTable.bidOnLeftProperty(), module.settingsUIModule.getData().bidOnLeftProperty());
      obboTable.arrangeGrid();
      tracker.addListener(obboTable.bidOnLeftProperty(), observable -> {
         obboTable.arrangeGrid();
      });

      instrumentTable.setPrefHeight(InstrumentsPane.ROW_HEIGHT * 2 + 4);
      instrumentTable.setMinHeight(Region.USE_PREF_SIZE);
      VBox.setVgrow(instrumentTable, Priority.NEVER);
      VBox.setVgrow(obboTable.getContentNode(), Priority.ALWAYS);

      vbox.getChildren().addAll(instrumentTable, obboTable.getContentNode());
      AnchorPane.setTopAnchor(vbox, VerticalAppContainer.TOP_BANNER_HEIGHT);
      AnchorPane.setRightAnchor(vbox, 0.0);
      AnchorPane.setBottomAnchor(vbox, 0.0);
      AnchorPane.setLeftAnchor(vbox, 0.0);

      body.getChildren().add(vbox);
      appContainer.setContent(body);
      appContainer.setAllowIconified(false);

      Scene scene = new Scene(appContainer.getRoot());
      scene.setFill(null);


      this.setScene(scene);
      this.setOnHidden(event -> {
         tracker.rollback();
         orderBook.dispose();
         layoutManager.unregister(ObboStage.this);
         openedDepth.remove(key).dispose();
      });

      this.setOnShowing(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent windowEvent) {
            layoutManager.register(ObboStage.this,appContainer);
            ObboStage.this.toFront();
         }
      });

      this.setOnShown(new EventHandler<WindowEvent>() {

         @Override
         public void handle(WindowEvent arg0) {
            appContainer.startDrag(mouseEvent);
         }
      });

//      ZoomableDecorator.setHeight(this, 200);
//      ZoomableDecorator.setWidth(this, FxApplicationModule.MAIN_STAGE_WIDTH);
//      this.heightBeforeScale().set(200);
//      this.setWidth(FxApplicationModule.MAIN_STAGE_WIDTH);
      this.show();
   }


   public void dispose() {
      watchlist.dispose();
      if(this.isShowing()){
         this.hide();
      }
      if(obboTable!=null){
         obboTable.dispose();
      }
   }

   public void mouseDragged(MouseEvent event){
      appContainer.mouseDragged(event);
   }

   private void requestWatchlist(XfeSession session, String secCode, String boardId) {
      session.secBoards.get().getSecBoard(secCode, boardId).map(new Fun1<SecBoard, Void>(){

         @Override
         public Void call(SecBoard secboard) {
            watchlist.getSpecWatchedSecboards().setAll(secboard);
            return null;
         }

      });
   }
}
