package xfe.icap.modules.tradesui;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import xfe.icap.amp.AmpTrade;
import xfe.ui.table.AlignedTableColumn;
import xfe.ui.table.Tables;
import xfe.util.Util;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;

import java.math.BigDecimal;
import java.util.Date;
import java.util.function.BiConsumer;
import java.util.function.Function;

class TradesTable extends TableView<ObservableReplyRow> {
   private class SideCell extends TableCell<ObservableReplyRow, OrderSide> {

      @Override
      protected void updateItem(OrderSide item, boolean empty) {
         super.updateItem(item, empty);
         if (item == null) {
            setText(null);
         } else {
            setText(OrderSide.BUY == item ? "B" : "S");
         }
      }
   }

   TradesTable() {
      setPlaceholder(Tables.stripedRowCSSPlaceholder());
      TableColumn<ObservableReplyRow, String> secCol = new AlignedTableColumn<>("Instrument", HPos.LEFT);
      secCol.getStyleClass().add("xfe-bold-text");
      secCol.setCellValueFactory(TradesTable::call);
      getColumns().add(secCol);

      TableColumn<ObservableReplyRow, BigDecimal> priceCol = new AlignedTableColumn<>("Price", HPos.RIGHT);
      priceCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpTrade.price));
      priceCol.setCellFactory(param -> new TableCell<ObservableReplyRow, BigDecimal>() {
         @Override
         protected void updateItem(BigDecimal item, boolean empty) {
            super.updateItem(item, empty);
            setText(null);
            if(item!=null && !empty){
               if (priceFormatter != null) {
                  priceFormatter.accept(this, item);
               } else {
                  setText(item.toString());
               }
            }
         }
      });
      getColumns().add(priceCol);

      TableColumn<ObservableReplyRow, BigDecimal> qtyCol = new AlignedTableColumn<>("Total", HPos.RIGHT);
      qtyCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpTrade.quantity));
      getColumns().add(qtyCol);

      final TableColumn<ObservableReplyRow, OrderSide> side = new AlignedTableColumn<>("B/S", HPos.CENTER);
      side.setId("B/S");
      side.setCellValueFactory(param -> sideColFactory.apply(param.getValue()));
      side.setCellFactory(p -> new TradesTable.SideCell());
      side.setMinWidth(30);
      getColumns().add(side);

      TableColumn<ObservableReplyRow, Date> timeCol = new AlignedTableColumn<>("Time", HPos.RIGHT);
      timeCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpTrade.time));
      timeCol.setCellFactory(param -> new TableCell<ObservableReplyRow, Date>() {
         @Override
         protected void updateItem(Date item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null) {
               setText(null);
            } else {
               setText(Util.formatTime(item));
            }
         }
      });
      getColumns().add(timeCol);

      TableColumn<ObservableReplyRow, String> cpCol = new AlignedTableColumn<>("Firm", HPos.LEFT);
      cpCol.setCellValueFactory(param -> cpColFactory.apply(param.getValue()));
      getColumns().add(cpCol);
   }

   private static ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableReplyRow, String> cd) {
      return new ReadOnlyObjectWrapper(Util.stripper(cd.getValue().getProperty(AmpTrade.secCode).get(), "UKT"));
   }

   public void setPriceFormatter(BiConsumer<TableCell<ObservableReplyRow, BigDecimal>, BigDecimal> priceFormatter) {
      this.priceFormatter = priceFormatter;
   }

   void setSideFactory(Function<ObservableReplyRow, ObservableValue<OrderSide>> sideColFactoryImpl) {
      this.sideColFactory = sideColFactoryImpl;
   }

   void setCounterpartyFactory(Function<ObservableReplyRow, ObservableValue<String>> cpColFactoryImpl) {
      this.cpColFactory = cpColFactoryImpl;
   }

   private BiConsumer<TableCell<ObservableReplyRow, BigDecimal>, BigDecimal> priceFormatter;
   private Function<ObservableReplyRow, ObservableValue<OrderSide>> sideColFactory;
   private Function<ObservableReplyRow, ObservableValue<String>> cpColFactory;

}
