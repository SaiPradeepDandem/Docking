//package xfe.icap.modules.tradesview;
//
//import javafx.beans.value.ChangeListener;
//import javafx.scene.control.TableRow;
//import xfe.icap.amp.AmpManagedOrder;
//import xfe.icap.amp.AmpTrade;
//import xstr.session.ObservableReplyRow;
//import xfe.modules.actions.ActionName;
//
///**
// * Customized TableRow for TradesView table.
// * The main functionality of this customization is to set the row styling based on the trade status.
// */
//public class TradesViewTableRow extends TableRow<ObservableReplyRow> {
//
//   private final ChangeListener<Number> changeListener = (obs, oldStatus, newStatus) -> {
//      pseudoClassStateChanged(TradesViewTable.BROKER_APPROVED_PSEUDO_CLASS, newStatus.intValue() == AmpTrade.extrafields.);
//   };
//
//   public TradesViewTableRow() {
//      itemProperty().addListener((obs, previousRow, currentRow) -> {
//         if (previousRow != null) {
//            previousRow.getProperty(AmpManagedOrder.orderStatus).removeListener(changeListener);
//         }
//         if (currentRow != null) {
//            currentRow.getProperty(AmpManagedOrder.orderStatus).addListener(changeListener);
//            final int orderStatus = currentRow.getProperty(AmpManagedOrder.orderStatus).get().intValue();
//            pseudoClassStateChanged(OrdersViewTable.OPENED_PSEUDO_CLASS, orderStatus == AmpManagedOrder.OPENED);
//            pseudoClassStateChanged(OrdersViewTable.REFERRED_PSEUDO_CLASS, orderStatus == AmpManagedOrder.REFERRED);
//         } else {
//            pseudoClassStateChanged(OrdersViewTable.OPENED_PSEUDO_CLASS, false);
//            pseudoClassStateChanged(OrdersViewTable.REFERRED_PSEUDO_CLASS, false);
//         }
//      });
//
//      setOnMouseClicked(e -> {
//         if (e.getClickCount() == 2) {
//            final OrdersViewUIModule ordersViewUIModule = ((OrdersViewTable)getTableView()).getOrdersViewUIModule();
//            ordersViewUIModule.invokeAction(ActionName.OpenOrderAmend, this, getItem());
//         }
//      });
//   }
//}
