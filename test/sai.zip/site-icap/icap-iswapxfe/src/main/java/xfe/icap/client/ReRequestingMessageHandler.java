package xfe.icap.client;

import com.google.protobuf.Message;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.util.concurrent.GenericFutureListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.exception.DisposedException;
import xstr.util.Duration;
import xstr.util.PromiseMonitor;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;
import xstr.util.exception.Exceptions;

import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

@Sharable
public abstract class ReRequestingMessageHandler<REQ extends Message, REP extends Message> extends SimpleChannelInboundHandler<REP> {
   private static final Logger logger = LoggerFactory.getLogger(ReRequestingMessageHandler.class);

   private final XstrWebConnection xstrWebConnection;
   protected final AtomicLong nextSeq = new AtomicLong();

   public ReRequestingMessageHandler(XstrWebConnection xstrWebConnection) {
      this.xstrWebConnection = xstrWebConnection;
   }

   protected class MessageData {
      final REQ request;
      final Promise<REP> replyPromise;
      final long id;

      MessageData(long id, REQ request) {
         this.id = id;
         this.request = request;
         this.replyPromise = PromiseMonitor.monitor(Futures.newPromise("message-data-" + id));
      }

      @Override
      public String toString() {
         return request.getClass().getSimpleName() + ":" + id;
      }
   }

   private final ConcurrentLinkedDeque<MessageData> msgQueue = new ConcurrentLinkedDeque<>();

   private void scheduleResend(MessageData md) {
      if (xstrWebConnection.live() && !md.replyPromise.isDone()) {
         logger.trace("[{}] Resending now.", md);
         xstrWebConnection.schedule(Duration.of(1, TimeUnit.SECONDS), () -> sendMessage(md));
      } else {
         logger.debug("[{}] Aborting resend.", md);
      }
   }

   private void sendMessage(MessageData md) {
      if (md.replyPromise.isDone())
         return;
      xstrWebConnection.channel().flatMap(channel -> {
         logger.trace("[{}] Sending message.", md);
         GenericFutureListener<io.netty.util.concurrent.Future<? super Void>> closeListener = future -> {
            logger.warn("[{}] Channel closed before a reply was received. Retry in one second.", md);
            scheduleResend(md);
         };
         // Add a listener to resend the message if the channel is closed unexpectedly
         channel.closeFuture().addListener(closeListener);
         // As soon as we have a result we no longer care if the channel is closed.
         md.replyPromise.addListener(r -> channel.closeFuture().removeListener(closeListener));
         return Futures.wrap(channel.writeAndFlush(md.request));
      }).onError(err -> {
         logger.warn("[{}] Error writing message. Retry in one second: {}", md, Exceptions.format(err));
         scheduleResend(md);
         return null;
      });
   }

   public Future<REP> request(REQ request) {
      if(!xstrWebConnection.live()) {
         return Futures.error(new DisposedException());
      }
      MessageData md = add(request);
      sendMessage(md);
      return md.replyPromise;
   }

   private synchronized MessageData add(REQ request) {
      MessageData md = setID(request);
      msgQueue.add(md);
      return md;
   }

   public void disposeMessages() {
      DisposedException ex = new DisposedException();
      msgQueue.forEach(msg -> msg.replyPromise.trySetFailure(ex));
      msgQueue.clear();
   }

   public void resendMessages() {
      logger.debug("Try to resend all messages");
      msgQueue.forEach(this::sendMessage);
   }

   @Override
   protected void channelRead0(ChannelHandlerContext ctx, REP msg) {
      long id = getRepID(msg);
      Iterator<MessageData> it = msgQueue.iterator();
      while (it.hasNext()) {
         MessageData md = it.next();
         if(md.id == id) {
            logger.trace("[{}] Reply received.", md);
            md.replyPromise.setSuccess(msg);
            it.remove();
            return;
         }
      }
      logger.error("Received message {} of type {} but was unable to find matching request", id, msg.getClass().getSimpleName());
   }

   protected abstract MessageData setID(REQ request);
   protected abstract long getRepID(REP reply);

}
