package xfe.icap.modules.layout.midi;

import com.nomx.persist.Types;
import com.omxgroup.xstream.amp.AmpSecClassId;
import com.sun.javafx.stage.StageHelper;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventTarget;
import javafx.event.WeakEventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import org.controlsfx.control.Notifications;
import org.controlsfx.control.PopOver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.XfeAppModule;
import xfe.amp.AmpBoard;
import xfe.icap.ISwapMain;
import xfe.icap.modules.info.XfeInfoPane;
import xfe.icap.modules.popover.PopOverModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.tradesworkup.TradesWorkupViewUIModule;
import xfe.layout.WindowLayout;
import xfe.module.SiteModule;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.modules.logon.LogonModule;
import xfe.modules.session.ActiveSessionModule;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.flasher.PseudoFlasher;
import xfe.ui.popover.XfePopOver;
import xfe.ui.window.*;
import xfe.util.Constants;
import xfe.util.EasyFXML;
import xfe.util.XfeAction;
import xfe.util.scene.control.AppContainer;
import xstr.session.ObservableReplyRow;
import xstr.util.AfterLayout;
import xstr.util.Fx;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static xfe.icap.modules.layout.midi.MidiLayoutViews.*;

public class MidiLayoutModule extends SessionScopeModule implements WindowLayout<Node>, XfeWindowManager {
   private static final Logger logger = LoggerFactory.getLogger(MidiLayoutModule.class);
   private static final String STAGE_ICONIFIED_BOUNDS_KEY = "ICONFIED_POS";
   private static final String DIVIDER_POS_KEY = "divPosKey";
   private static final int MAIN_WIDTH = 800;
   private static final int MAIN_HEIGHT = 1000;
   private Map<Stage, ChangeListener<Boolean>> stageIconifiedListenersMap = new HashMap<>();

   @ModuleDependency
   public XfeAppModule appModule;
   @ModuleDependency
   public FxApplicationModule fxAppModule;
   @ModuleDependency
   public LogonModule logonModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;
   @ModuleDependency
   public SiteModule siteModule;
   @ModuleDependency
   public PopOverModule popOverModule;

   private ObservableList<MenuItem> globalMenuItems = FXCollections.observableArrayList();
   private SimpleObjectProperty<EventTarget> hoverNode = new SimpleObjectProperty<>();
   private Stage appStage;
   private InvalidationListener stageBoundsListener;

   private String notificationsCssPath;
   private String popoverCssPath;
   private XfeWindowFocusHacker windowFocusHacker = new XfeWindowFocusHacker();
   private ChangeListener<Number> workupXValueListener =  ((observable, oldValue, newValue) -> logger.info("Workup X value is changed {}",newValue));
   private ChangeListener<Number> workupYValueListener =  ((observable, oldValue, newValue) -> logger.info("Workup Y value is changed {}",newValue));


   private MidiLayout midiLayout;
   private HeaderLayout headerLayout;
   private Map<String, Types.Rect> popupSizeMap = new HashMap<>();
   private Set<String> activePopups = new HashSet<>();
   private Map<String, ManagedWindow> popoverWindowsMap = new HashMap<>();

   private XfeAction lockAction;
   private Consumer<LockedLabel> lockedLabelConsumer;
   private Consumer<Boolean> marketSubjectConsumer;
   private Runnable springBoardLauncher;


   private EventHandler<MouseEvent> logoClickedEvent;
   private WeakEventHandler<MouseEvent> weakLogoClickedEvent;
   private EventHandler<WindowEvent> onCloseRequest;
   private ChangeListener<Boolean> lockedListener;
   private ListChangeListener<ObservableReplyRow> boardsListener;
   private EventHandler<MouseEvent> mouseMovedFilter;
   private ChangeListener<Number> positionListener;
   private ListChangeListener<? super MenuItem> menuItemsListener;
   private InvalidationListener menuInvalidationlistener;
   private EventHandler<ActionEvent> lockActionHandler;
   private EventHandler<ActionEvent> logoutActionHandler;


   @Override
   public Future<Void> startModule() {
      windowFocusHacker.init();
      notificationsCssPath = Notifications.class.getResource("notificationpopup.css").toExternalForm();
      popoverCssPath = PopOver.class.getResource("popover.css").toExternalForm();

      lockActionHandler = e -> getActiveSessionModule().lock(false);
      logoutActionHandler = e -> logonModule.requestLogoff();
      onCloseRequest = event -> getLogonModule().requestLogoff();
      mouseMovedFilter = e -> hoverNode.set(e.getTarget());
      logoClickedEvent = e -> {
         final XfeInfoPane xfeInfoPane = EasyFXML.load(XfeInfoPane.class);
         xfeInfoPane.setHotLine(getSiteModule().getHotLine());
         xfeInfoPane.setEmailSupport(getSiteModule().getEmailSupport());
         final Node ownerNode = (Node) e.getTarget();
         final PopOver popOver = new PopOver();
         popOver.setAnimated(false);
         popOver.setDetachable(false);
         popOver.setArrowLocation(PopOver.ArrowLocation.TOP_LEFT);
         popOver.setContentNode(xfeInfoPane.getRoot());
         popOver.show(ownerNode);
      };
      weakLogoClickedEvent = new WeakEventHandler<>(logoClickedEvent);
      positionListener = (observable, oldValue, newValue) -> {
         if (configurationModule.getData() != null) {
            configurationModule.getData().midiLayoutDividerPosition().setValue(newValue);
         }
      };
      menuItemsListener = p -> {
         if (p.next()) {
            reloadUserMenus();
            p.getAddedSubList().forEach(this::addListener);
         }
      };
      menuInvalidationlistener = p -> reloadUserMenus();
      stageBoundsListener = obs -> {
         Types.Rect newPosition = getWindowPosition(appStage);

         configurationModule.getData().applicationPositionProperty().set(newPosition);
         logger.debug("{}'s position is set to {}", appStage.getTitle(), newPosition);

         /* When application is maximized (from iconified) and if we maintain the divider position,
            then setting the divider position after rendering the layout and deleting the key. */
         if (!appStage.isIconified() && appStage.getProperties().get(DIVIDER_POS_KEY) != null) {
            /* Always load the value ahead before calling AfterLayout, otherwise the value when requested may not be equal to the value when rendering. */
            final double divPosition = (Double) appStage.getProperties().get(DIVIDER_POS_KEY);
            AfterLayout.execute(() -> midiLayout.setDividerPosition(divPosition));
            appStage.getProperties().remove(DIVIDER_POS_KEY);
         }
      };


      midiLayout = MidiLayout.load();
      XfeWindow xfeWindow = appModule.getXfeWindow();
      appStage = xfeWindow.getStage();

      xfeWindow.getWindowAttributes().setResizable(true);
      xfeWindow.getWindowAttributes().setMaximisable(true);
      xfeWindow.setWindowContent(midiLayout.getRoot(), "ICAP");
      xfeWindow.getLabelSubTitle().setText(siteModule.getShortTitle());
      loadHeaderNode(xfeWindow);
      xfeWindow.showWindow();
      xfeWindow.setOnCloseRequest(onCloseRequest);
      positionStage(xfeWindow.getStage());

      lockedListener = (observable, oldValue, gotLocked) -> {
         if ((gotLocked != null) && gotLocked  && !getActiveSessionModule().safeModePropertyProperty().get()) {
            renderLockedGui();
         }
      };
      boardsListener = c -> determineAndDisplayMarketSubjectStatus();

      headerLayout.setUnlockHandler(this::handleUnlock);
      activeSessionModule.getSession().ifPresent(serverSession -> headerLayout.setUserMenu(buildUserMenu()));

      lockAction = new XfeAction();
      lockAction.setText("Lock");
      lockAction.setOnAction(lockActionHandler);
      fxAppModule.addAction(lockAction);
      if (activeSessionModule.lockedProperty().get()) {
         renderLockedGui();
      }
      activeSessionModule.lockedProperty().addListener(lockedListener);

      loadAndListenGlobalItems();


      // Showing market "Subject" status only for GILTS site.
      if (siteModule.getSiteLogoStyle().equals(ISwapMain.XFE_SITE_GILTS_UK)) {
         determineAndDisplayMarketSubjectStatus();
         securitiesDataModule.getBoards().addListener(boardsListener);
      }

      // Set the flash interval from the settings menu
      IntegerProperty cellFlashInterval = configurationModule.getData().cellFlashInterval();
      PseudoFlasher.setTime(cellFlashInterval.get());
      cellFlashInterval.addListener((observable, oldValue, newValue) -> PseudoFlasher.setTime(cellFlashInterval.get()));

      final double dividerPosition = configurationModule.getData().midiLayoutDividerPosition().get();
      xfeWindow.getStage().getProperties().put(DIVIDER_POS_KEY, dividerPosition);
      midiLayout.getDivider().positionProperty().addListener(positionListener);
      /* Setting the node properties after the stage is fully rendered */
      AfterLayout.execute(() -> {
         midiLayout.setDividerPosition(dividerPosition);
         midiLayout.setStockSelectionExpandedState(configurationModule.getData().stockSelectionExpanded());
      });

      closeAllPopOvers();
      Scene appScene = appModule.getStage().getScene();
      appScene.addEventFilter(MouseEvent.MOUSE_MOVED, mouseMovedFilter);
      appScene.getStylesheets().addAll(notificationsCssPath, popoverCssPath);
      return Future.SUCCESS;
   }

   private void loadAndListenGlobalItems() {
      Bindings.bindContent(globalMenuItems, fxAppModule.getGlobalActions());
      listenMenuItems(globalMenuItems);
      reloadUserMenus();
   }

   private void listenMenuItems(ObservableList<MenuItem> sourceItems) {
      sourceItems.addListener(menuItemsListener);
      sourceItems.forEach(this::addListener);
   }

   private void addListener(MenuItem sourceItem) {
      if (sourceItem instanceof Menu) {
         Menu sourceMenu = (Menu) sourceItem;
         sourceMenu.getItems().addListener(menuInvalidationlistener);
         listenMenuItems(sourceMenu.getItems());
      }
      sourceItem.disableProperty().addListener(menuInvalidationlistener);
      sourceItem.visibleProperty().addListener(menuInvalidationlistener);
      sourceItem.onActionProperty().addListener(menuInvalidationlistener);
      if (sourceItem instanceof RadioMenuItem) {
         ((RadioMenuItem) sourceItem).selectedProperty().addListener(menuInvalidationlistener);
      }
   }

   private void unlistenMenuItems(ObservableList<MenuItem> sourceItems) {
      sourceItems.removeListener(menuItemsListener);
      sourceItems.forEach(this::removeListener);
   }

   private void removeListener(MenuItem sourceItem) {
      if (sourceItem instanceof Menu) {
         Menu sourceMenu = (Menu) sourceItem;
         sourceMenu.getItems().removeListener(menuInvalidationlistener);
         unlistenMenuItems(sourceMenu.getItems());
      }
      sourceItem.disableProperty().removeListener(menuInvalidationlistener);
      sourceItem.visibleProperty().removeListener(menuInvalidationlistener);
      sourceItem.onActionProperty().removeListener(menuInvalidationlistener);
      if (sourceItem instanceof RadioMenuItem) {
         ((RadioMenuItem) sourceItem).selectedProperty().removeListener(menuInvalidationlistener);
      }
   }

   private List<ObservableList<MenuItem>> getAllWindowsUserMenus() {
      List<ObservableList<MenuItem>> list = new ArrayList<>();
      list.add(headerLayout.menuItems());
      getAllIndependentWindowMenus().forEach(menu -> list.add(menu.getItems()));
      return list;
   }

   private void reloadUserMenus() {
      getAllWindowsUserMenus().forEach(this::copyGlobalItems);
   }


   private void unloadUserMenus() {
      getAllWindowsUserMenus().forEach(this::clearItems);
   }


   private void clearItems(List<MenuItem> items) {
      for (MenuItem menuItem : items) {
         if (menuItem instanceof Menu) {
            clearItems(((Menu) menuItem).getItems());
         }
         menuItem.setOnAction(null);
      }
      items.clear();
   }

   private void copyGlobalItems(ObservableList<MenuItem> items) {
      items.clear();
      items.addAll(cloneItems(globalMenuItems, true));
   }

   private ObservableList<MenuItem> cloneItems(ObservableList<MenuItem> sourceItems, boolean addLogout) {
      ObservableList<MenuItem> targetItems = FXCollections.observableArrayList();
      sourceItems.forEach(sourceItem -> {
         if (sourceItem instanceof Menu) {
            Menu sourceMenu = (Menu) sourceItem;
            Menu targetMenu = new Menu(sourceMenu.getText());
            targetMenu.getItems().addAll(cloneItems(sourceMenu.getItems(), false));
            targetMenu.setDisable(sourceMenu.isDisable());
            targetMenu.setVisible(sourceMenu.isVisible());
            targetItems.add(targetMenu);
         } else if (sourceItem instanceof RadioMenuItem) {
            RadioMenuItem targetMenuItem = new RadioMenuItem(sourceItem.getText());
            targetMenuItem.setDisable(sourceItem.isDisable());
            targetMenuItem.setVisible(sourceItem.isVisible());
            targetMenuItem.setSelected(((RadioMenuItem) sourceItem).isSelected());
            targetMenuItem.setOnAction(sourceItem.getOnAction());
            targetItems.add(targetMenuItem);
         } else {
            MenuItem targetMenuItem = new MenuItem(sourceItem.getText());
            targetMenuItem.setDisable(sourceItem.isDisable());
            targetMenuItem.setVisible(sourceItem.isVisible());
            targetMenuItem.setOnAction(sourceItem.getOnAction());
            targetItems.add(targetMenuItem);
         }
      });

      //Adding logout menu item
      if (addLogout) {
         final MenuItem logoutItem = new MenuItem("Logout");
         logoutItem.setOnAction(logoutActionHandler);
         logoutItem.setId("logoutMenuItem");
         targetItems.add(logoutItem);
      }
      return targetItems;
   }

   private void determineAndDisplayMarketSubjectStatus() {
      ObservableList<ObservableReplyRow> boards = securitiesDataModule.getBoards();
      if (boards != null && !boards.isEmpty() && marketSubjectConsumer != null) {
         boolean isSubject = boards.stream().filter(board -> board.getValue(AmpBoard.boardId).equals(Constants.GILTS_BOARD_ID))
            .anyMatch(board -> board.getValue(AmpBoard.sessionName).equals(Constants.SUBJECT_STATUS));
         marketSubjectConsumer.accept(isSubject);
      }
   }

   private void renderLockedGui() {
      fxAppModule.removeAction(lockAction);
      headerLayout.displayLocked(true);
      if (lockedLabelConsumer != null) {
         LockedLabel lckLabel = new LockedLabel("Locked");
         lckLabel.setId("center-lock");
         lckLabel.setUnlockHandler(this::handleUnlock);
         lockedLabelConsumer.accept(lckLabel);
      }
   }

   public boolean isGiltsSite() {
      return siteModule.getSiteLogoStyle().equals(ISwapMain.XFE_SITE_GILTS_UK);
   }

   public void displaySafeModeLabel(Label label) {
      headerLayout.displaySafeModeLabel(label);
   }

   private void handleUnlock(Node owner) {
      final XfeWindowManager windowManager = null; /* Using null instance to call the appropriate method */
      final XfePopOver p = XfePopOver.instance(windowManager);
      p.setDetachable(false);
      p.setArrowLocation("center-lock".equals(owner.getId()) ? PopOver.ArrowLocation.TOP_CENTER : PopOver.ArrowLocation.TOP_RIGHT);

      final Label label = new Label("Enter the password:");
      final PasswordField password = new PasswordField();
      password.setOnAction(e -> getActiveSessionModule().unlock(password.getText().toCharArray(), false).map(aVoid -> {
         headerLayout.displayLocked(false);
         if (lockedLabelConsumer != null) {
            lockedLabelConsumer.accept(null);
         }
         getFxAppModule().addAction(lockAction);
         p.hide();
         return aVoid;
      }));
      final Pane unlock = new Pane();
      unlock.getStyleClass().add("xfe-unlock");
      final HBox hb = new HBox();
      hb.setSpacing(5);
      hb.setPadding(new Insets(15, 10, 15, 10));
      hb.setAlignment(Pos.CENTER);
      hb.getChildren().addAll(label, password, unlock);

      p.setContentNode(hb);
      p.showSafely(owner);
      p.setOnShown(e -> p.sizeToScene());
   }

   private void positionStage(Stage stage) {
      addIconifiedListener(stage);
      Types.Rect rect = configurationModule.getData().applicationPositionProperty().get();

      //If there is any issues reading config position, reset it the best possible way.
      if ((rect == null) || (Double.isNaN(rect.getX()) || Double.isNaN(rect.getY())) ||
         //Even if my xfe is contained in one valid screen, we could be missing the
         //top bar of xfe, which allows us to move window around. this check any of the
         //user screens is including that banner, otherwise reset too
         !isMyBannerInsideAValidScreen(rect.getX(), rect.getY(), rect) ||
         //Even is configuration reading are successful they could not be valid in current screen
         //Check in all available screen for the validity of the coords
         ((Screen.getScreensForRectangle(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight())).isEmpty())) {
         //show screen with default width and height in the middle of the primary screen.
         Rectangle2D myPrimaryScreen = Screen.getPrimary().getVisualBounds();
         rect = new Types.Rect(((myPrimaryScreen.getWidth() / 2) - (MidiLayoutModule.MAIN_WIDTH / 2D)),
            ((myPrimaryScreen.getHeight() / 2D) - (MidiLayoutModule.MAIN_HEIGHT / 2D)),
            MidiLayoutModule.MAIN_WIDTH, MidiLayoutModule.MAIN_HEIGHT);
      }

      /* Always load the values ahead before calling AfterLayout, otherwise the value when requested may not be equal to the value when rendering. */
      Types.Rect wrkSpaceBounds = new Types.Rect();
      wrkSpaceBounds.setX(rect.getX());
      wrkSpaceBounds.setY(rect.getY());
      wrkSpaceBounds.setWidth(rect.getWidth());
      wrkSpaceBounds.setHeight(rect.getHeight());
      Double wrkSpaceDivPosition = configurationModule.getData().midiLayoutDividerPosition().get();

      final boolean amIconified = rect.isIconified();
      AfterLayout.execute(() -> {
         stage.setX(wrkSpaceBounds.getX());
         stage.setY(wrkSpaceBounds.getY());
         stage.setWidth(wrkSpaceBounds.getWidth());
         stage.setHeight(wrkSpaceBounds.getHeight());
         if (amIconified) {
            stage.getProperties().put(STAGE_ICONIFIED_BOUNDS_KEY, new Rectangle2D(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight()));
            stage.setIconified(true);
            stage.getProperties().put(DIVIDER_POS_KEY, wrkSpaceDivPosition);
         }
      });


      stage.xProperty().addListener(stageBoundsListener);
      stage.yProperty().addListener(stageBoundsListener);
      stage.widthProperty().addListener(stageBoundsListener);
      stage.heightProperty().addListener(stageBoundsListener);
      stage.iconifiedProperty().addListener(stageBoundsListener);
   }


   //As XFE can be displayed in multiple screens (Split xfe) we need to guaranty
   //that the banner or x.y coordinate is valid in any of our screens. We need this corner
   //to be able to move xfe around
   private boolean isMyBannerInsideAValidScreen(double x, double y, Types.Rect rect) {
      boolean isBannerInside = false;
      for(Screen screen: (Screen.getScreensForRectangle(x, y, rect.getWidth(), rect.getHeight()))){
         if(screen.getVisualBounds().contains(x,y))
            isBannerInside = true;
      }
      return isBannerInside;
   }

   private void unbindStageBoundsListener() {
      appStage.xProperty().removeListener(stageBoundsListener);
      appStage.yProperty().removeListener(stageBoundsListener);
      appStage.widthProperty().removeListener(stageBoundsListener);
      appStage.heightProperty().removeListener(stageBoundsListener);
      appStage.iconifiedProperty().removeListener(stageBoundsListener);
      stageBoundsListener = null;
   }

   @Override
   public Future<Void> stopModule() {


      windowFocusHacker.reset();
      appModule.getStage().getScene().getStylesheets().removeAll(notificationsCssPath, popoverCssPath);

      popupSizeMap.clear();
      unbindStageBoundsListener();
      appModule.getStage().getScene().removeEventFilter(MouseEvent.MOUSE_MOVED, mouseMovedFilter);
      appModule.getXfeWindow().setOnCloseRequest(null);
      appModule.getXfeWindow().getIconContainer().setOnMouseReleased(null);
      securitiesDataModule.getBoards().removeListener(boardsListener);
      activeSessionModule.lockedProperty().removeListener(lockedListener);
      headerLayout.setUnlockHandler(null);
      midiLayout.getDivider().positionProperty().removeListener(positionListener);
      Bindings.unbindContent(globalMenuItems, fxAppModule.getGlobalActions());
      unlistenMenuItems(globalMenuItems);
      unloadUserMenus();


      lockedListener = null;
      boardsListener = null;
      onCloseRequest = null;
      mouseMovedFilter = null;
      logoClickedEvent = null;
      weakLogoClickedEvent = null;
      positionListener = null;
      menuItemsListener = null;
      menuInvalidationlistener = null;
      lockActionHandler = null;
      logoutActionHandler = null;

      Promise<Void> res = Futures.newPromise("res");
      Fx.run(() -> {
         XfeWindow xfeWindow = appModule.getXfeWindow();
         xfeWindow.getHeaderPane().getChildren().clear();
         Label titleLabel = xfeWindow.getLabelTitle();
         titleLabel.setScaleX(1);
         titleLabel.setScaleY(1);
         titleLabel.setStyle(null);
         titleLabel.setOnMouseReleased(null);
         fxAppModule.removeAction(lockAction);
         lockAction.setOnAction(null);
         closeAllPopOvers();
         XfePopOver.cleanUp();
         stageIconifiedListenersMap.forEach((s,l)->s.iconifiedProperty().removeListener(l));
         stageIconifiedListenersMap.clear();
         res.setFuture(Future.SUCCESS);
      });
      return res;
   }

   private void closeAllPopOvers() {
      List<ManagedWindow> windows = new ArrayList<>(popoverWindowsMap.values());
      windows.forEach(ManagedWindow::hide);
      popoverWindowsMap.clear();
   }

   @Override
   public void addView(Node view) {
      logger.debug("Adding view: {}", view.getId());
      final String title;

      if (view.getId().startsWith(RENEW_CM_PREFIX))
         title = "Renew CM Order?";
      else if (view.getId().startsWith(RENEW_PREFIX))
         title = view.getId().contains(RENEW_BID_POSTFIX) ? "Bid On?" : "Offer On?";
      else
         title = null;

      if (title != null) {
         Fx.runLater(() -> openPopupStage(view, title, null));
         return;
      }

      switch (view.getId()) {
         case INSTR_TABS:
            midiLayout.setInstrTabs(view);
            break;
         case TRADER_TOOLBAR:
            midiLayout.setToolbar(view);
            break;
         case ACTION_TOOLBAR:
            midiLayout.setActionToolBar(view);
            break;
         case TRADES_UI:
            midiLayout.setTradesUI(view);
            break;
         case ORDERSVIEW:
            if (popupSizeMap.get(ORDERSVIEW) == null) {
               Types.Rect position = configurationModule.getData().ordersViewPosition().get();
               if (position != null && !Double.isNaN(position.getX())) {
                  popupSizeMap.put(ORDERSVIEW, position);
               }
            }
            openPopupStage(view, "Orders", configurationModule.getData().ordersViewOpened());
            break;
         case TRADESVIEW:
            if (popupSizeMap.get(TRADESVIEW) == null) {
               Types.Rect position = configurationModule.getData().tradesViewPosition().get();
               if (position != null && !Double.isNaN(position.getX())) {
                  popupSizeMap.put(TRADESVIEW, position);
               }
            }
            openPopupStage(view, "Trades", configurationModule.getData().tradesViewOpened());
            break;
         case HISTORYVIEW:
            openPopupStage(view, "History", null);
            break;
         case SHORTLIST_PANE:
            midiLayout.setShortlistButtonsPane(view);
            break;
         case SPRINGBOARD_VIEW:
            openPopupStage(view, "SpringBoard", configurationModule.getData().springBoardOpened());
            break;
         default:
            logger.error("Unknown view: {}", view.getId());
      }
   }

   @Override
   public void addPopupView(Node view, Consumer<ManagedWindow> stageHandler) {
      logger.debug("Adding popup view: {}", view.getId());
      String title;
      switch (view.getId()) {
         case TRADES_WORKUP:
            title = "Trades Workup";
            break;
         case SETTINGSVIEW:
            title = "Settings";
            break;
         default:
            title = null;
      }
      if (title != null) {
         openPopupStage(view, title, null, stageHandler);
      }
   }

   @Override
   public void removeView(Node view) {
      logger.debug("Removing view: {}", view.getId());

      if (view.getId().startsWith(ORDER_RENEW_BID) ||
         view.getId().startsWith(ORDER_RENEW_OFFER) ||
         view.getId().startsWith(CM_ORDER_RENEW_BID) ||
         view.getId().startsWith(CM_ORDER_RENEW_OFFER)) {
         closePopupStage(view);
         return;
      }

      switch (view.getId()) {
         case INSTR_TABS:
            midiLayout.setInstrTabs(null);
            break;
         case SHORTLIST_PANE:
            midiLayout.setShortlistButtonsPane(null);
            break;
         case TRADER_TOOLBAR:
            midiLayout.setToolbar(null);
            break;
         case ACTION_TOOLBAR:
            midiLayout.setActionToolBar(null);
            break;
         case ORDERSVIEW:
         case TRADESVIEW:
            closePopupStageByRemovingHandler(view);
            break;
         case SETTINGSVIEW:
         case TRADES_WORKUP:
         case SPRINGBOARD_VIEW:
            closePopupStage(view);
            break;
         default:
            logger.error("Unknown view: {}", view.getId());
      }
   }

   @Override
   public AppContainer getLayoutRootElement() {
      return null;
   }

   @Override
   public Pane getPopupGroup() {
      return null;
   }

   @Override
   public void goModal(Node modalNode, Runnable runnable) {
      //No action needed, but required for implementing the WindowLayout interface
   }

   @Override
   public void register(String id, ManagedWindow window) {
      activePopups.add(id);
      if (id.startsWith(XfePopOver.ID_PREFIX) ||
         id.startsWith(RENEW_PREFIX))
         popoverWindowsMap.put(id, window);
      if(TRADES_WORKUP.equals(id)){
         ((ManagedXfeWindow)window).xProperty().addListener(workupXValueListener);
         ((ManagedXfeWindow)window).yProperty().addListener(workupYValueListener);
      }
   }

   @Override
   public void unregister(String id, ManagedWindow window) {
      final Types.Rect position = getWindowPosition(window);
      // Checking if WU is any of the visible screens.
      if (Double.isNaN(position.getX())
         || Double.isNaN(position.getY())
         || !isIntersectWithVisibleBounds(position)) {
         logger.warn(
            "Not saving the value to the local cache for {} received position is {}", id, position);
      } else {
         popupSizeMap.put(id, position);
      }
      saveViewPositionToWS(id, position);
      activePopups.remove(id);
      popoverWindowsMap.remove(id);
      if(TRADES_WORKUP.equals(id)){
         ((ManagedXfeWindow)window).xProperty().removeListener(workupXValueListener);
         ((ManagedXfeWindow)window).yProperty().removeListener(workupYValueListener);
      }
   }

   private boolean isIntersectWithVisibleBounds(Types.Rect position) {
      for(Screen screen : Screen.getScreens()){
         if(screen.getVisualBounds().intersects(position.getX(),position.getY(),position.getWidth(),position.getHeight()))
            return true;
      }
      return false;
   }

   private Types.Rect getWindowPosition(ManagedWindow window) {
      if (window instanceof Stage) {
         return getWindowPosition((Stage) window);
      } else {
         return new Types.Rect(window.getX(), window.getY(), window.getWidth(), window.getHeight());
      }
   }

   private Types.Rect getWindowPosition(Stage stage) {
      final Types.Rect position = new Types.Rect(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
      if (stage.isIconified()) {
         Rectangle2D pos = (Rectangle2D) stage.getProperties().get(STAGE_ICONIFIED_BOUNDS_KEY);
         if (pos != null) {
            position.setX(pos.getMinX());
            position.setY(pos.getMinY());
            position.setIconified(true);
         }
      }
      return position;
   }

   /**
    * Closes the existing opened detached PopOver.
    *
    * @param id Identifier of the PopOver.
    */
   public void closePopOverWindow(String id) {
      final ManagedWindow window = popoverWindowsMap.get(id);
      if (window != null) {
         window.close();
         popoverWindowsMap.remove(id);
      }
   }

   private void saveViewPositionToWS(String id, Types.Rect position) {
      switch (id) {
         case ORDERSVIEW:
            configurationModule.getData().ordersViewPosition().setValue(position);
            break;
         case TRADESVIEW:
            configurationModule.getData().tradesViewPosition().setValue(position);
            break;
         case SPRINGBOARD_VIEW:
            configurationModule.getData().springBoardPosition().setValue(position);
            break;
         default:
            // not belongs to the above screens do nothing
            break;
      }

      if (id.startsWith(RENEW_PREFIX)) {
         configurationModule.getData().orderRenewPosition().setValue(position);
      }
   }

   private ManagedWindow openPopupStage(Node view, String title, BooleanProperty wsOpenedProperty) {
      return openPopupStage(view, title, wsOpenedProperty, null);
   }

   private ManagedWindow openPopupStage(Node view, String title, BooleanProperty wsOpenedProperty, Consumer<ManagedWindow> stageHandler) {
      final String viewId = view.getId();
      /* If the view is already opened, show the window to front */
      if (activePopups.contains(viewId)) {
         ManagedWindow popupFound = findPopupStage(viewId);
         popupFound.toFront();
         if (TRADES_WORKUP.equals(viewId)) {
            logger.debug("Workup already existed, just sent to front at: {},{}", popupFound.getX(), popupFound.getY());
         } else if((TRADESVIEW.equals(viewId) || ORDERSVIEW.equals(viewId)) && ((XfeWindow)popupFound).isIconified()) {
            // if the screen is minimized, change the minimized state
            ((XfeWindow)popupFound).setIconified(false);
         }
      } else {
         /* If the view is not opened, create a stage */
         boolean isWorkup = TRADES_WORKUP.equals(viewId);
         boolean isRenew = viewId.startsWith(RENEW_PREFIX);
         final ManagedWindow stage = createPopupStage(view, title);
         if (stageHandler != null) {
            stageHandler.accept(stage);
         }
         if (isRenew) {
            Types.Rect position = configurationModule.getData().orderRenewPosition().get();
            if (position != null && !Double.isNaN(position.getX())) {
               stage.setX(position.getX());
               stage.setY(position.getY());
            }
         }

         if (isWorkup && view.getProperties().get(TradesWorkupViewUIModule.FORCE_OPEN) != null) {
            logger.debug("Workup show at center");
            stage.showAtXfeCenter(appModule.getStage());
            view.getProperties().remove(TradesWorkupViewUIModule.FORCE_OPEN);
         } else {
            final Types.Rect position = popupSizeMap.get(viewId);
            if (position == null && isWorkup) {
               logger.info("Workup shown at center");
               stage.showAtXfeCenter(appModule.getStage());
            } else {
               if (position != null) {
                  logger.info("Workup shown at position : {}", position);
                  updateStageBounds(stage, position, isWorkup);
               }
               logger.debug("Show workup simply at {},{}", stage.getX(), stage.getY());
               stage.showStage();
            }
         }
         if (wsOpenedProperty != null) {
            wsOpenedProperty.set(true);
            stage.setOnHidingHandler(e -> wsOpenedProperty.set(false));
         }
         return stage;
      }
      return null;
   }

   /**
    * Creates the pop up window for the provided view type.
    *
    * @param view  Node of the view
    * @param title Title of the stage
    * @return ManagedWindow
    */
   private ManagedWindow createPopupStage(Node view, String title) {
      String viewId = view.getId();
      boolean isWorkup = TRADES_WORKUP.equals(viewId);
      boolean isRenew = viewId.startsWith(RENEW_PREFIX);
      boolean isSpringBoard = viewId.equals(SPRINGBOARD_VIEW);
      final ManagedWindow stage;
      /* For workup and renew stages */
      if (isWorkup || isRenew) {
         final ManagedXfeWindow workupStage = new ManagedXfeWindow(viewId, appModule.getStage(), view, title, this);
         updateNonFocusStageSettings(workupStage);
         stage = workupStage;
      }
      /* For SpringBoard stage */
      else if (isSpringBoard) {
         final ManagedXfeWindow springBoard = new ManagedXfeWindow(viewId, appModule.getStage(), view, title, this);
         springBoard.getWindowAttributes().setVerticallyResizable(true);
         springBoard.getWindowAttributes().setMinimisable(false);
         springBoard.getWindowAttributes().setMaximisable(false);
         springBoard.getScene().addEventFilter(MouseEvent.MOUSE_MOVED, mouseMovedFilter);
         springBoard.setOnHidingHandler(e -> springBoard.getScene().removeEventFilter(MouseEvent.MOUSE_MOVED, mouseMovedFilter));
         stage = springBoard;
      }
      /* For all the remaining stages */
      else {
         final ManagedXfeWindow managedXfeWindow = buildIndependentWindow(new IndependentWindowArgs(viewId, view, title, this, null, null));
         Scene windowScene = managedXfeWindow.getScene();
         windowScene.addEventFilter(MouseEvent.MOUSE_MOVED, mouseMovedFilter);
         managedXfeWindow.setOnHidingHandler(e -> windowScene.removeEventFilter(MouseEvent.MOUSE_MOVED, mouseMovedFilter));
         stage = managedXfeWindow;
      }
      return stage;
   }

   /**
    * Updates the settings required for non focusable stage hack.
    *
    * @param stage Stage to update
    */
   private void updateNonFocusStageSettings(ManagedXfeWindow stage) {
      stage.setFocusOnShown(false);
      stage.getWindowAttributes().setResizable(false);
      stage.getWindowAttributes().setMinimisable(false);
      stage.getWindowAttributes().setMaximisable(false);
   }

   /**
    * Updates the stage position and dimensions.
    *
    * @param stage    Stage to which the position and dimensions needs to be updated
    * @param bounds   Bounds of the stage
    * @param isWorkup Specifies whether it is a workup stage or not
    */
   private void updateStageBounds(final ManagedWindow stage, final Types.Rect bounds, final boolean isWorkup) {
      /* Setting the bounds within Fx.runLater. If called directly, it positions the window correctly,
       but setting the dimensions has no effect and the window is opened in default size. (Eg., OrdersView, TradesView etc) */
      Fx.runLater(() -> {
         stage.setX(bounds.getX());
         stage.setY(bounds.getY());
         if(isWorkup){
            logger.info("{} Setting workup at: {},{}", stage, stage.getX(), stage.getY());
         }
         /* Not setting the dimensions for workup stage as workup is a non resizable window */
         if (!isWorkup) {
            stage.setWidth(bounds.getWidth());
            stage.setHeight(bounds.getHeight());
         }
         if (stage instanceof Stage && bounds.isIconified()) {
            ((Stage) stage).setIconified(true);
         }
      });
   }

   public IndependentWindow buildIndependentWindow(IndependentWindowArgs args) {
      args.setOwner(appModule.getStage());
      final IndependentWindow independentWindow = new IndependentWindow(args);
      independentWindow.getIconContainer().setOnMouseReleased(weakLogoClickedEvent);
      independentWindow.setUserMenu(buildUserMenu());
      independentWindow.setOnHidingHandler(e -> {
         if (args.getHidingHandler() != null) {
            args.getHidingHandler().handle(e);
         }
         independentWindow.getIconContainer().setOnMouseReleased(null);
         ArrayList<MenuItem> userMenuList = new ArrayList<>();
         userMenuList.add(independentWindow.getUserMenu());
         clearItems(userMenuList);
      });
      addIconifiedListener(independentWindow);
      return independentWindow;
   }



   private void addIconifiedListener(Stage stage) {
      ChangeListener<Boolean> l =(obs, old, iconified) -> {
         if ((iconified != null)  && iconified) {
            stage.getProperties().put(STAGE_ICONIFIED_BOUNDS_KEY, new Rectangle2D(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight()));
         } else {
            Rectangle2D position = (Rectangle2D) stage.getProperties().get(STAGE_ICONIFIED_BOUNDS_KEY);
            if (position != null) {
               Fx.runLater(() -> {
                  stage.setWidth(position.getWidth()-1);
                  stage.setHeight(position.getHeight()-1);
                  stage.setX(position.getMinX());
                  stage.setY(position.getMinY());
               });
            }
         }
      };
      stage.iconifiedProperty().addListener(l);
      stageIconifiedListenersMap.put(stage,l);
   }

   private MenuBar buildUserMenu() {
      Menu userMenu = new Menu();
      userMenu.setId("userMenu");
      activeSessionModule.getSession().ifPresent(serverSession -> userMenu.setText(serverSession.getLoggedOnUserId()));
      copyGlobalItems(userMenu.getItems());
      MenuBar menuBar = new MenuBar(userMenu);
      menuBar.getStyleClass().add("xfe-user-menu-bar");
      return menuBar;
   }

   private void closePopupStage(Node view) {
      closePopupStage(view.getId());
   }

   public void closePopupStage(String id) {
      ManagedWindow stage = findPopupStage(id);
      if (stage != null) {
         stage.hide();
      }
   }

   private void closePopupStageByRemovingHandler(Node view) {
      ManagedWindow stage = findPopupStage(view.getId());
      if (stage != null) {
         if (stage instanceof IndependentWindow) {
            IndependentWindow independentWindow = (IndependentWindow) stage;
            final List<MenuItem> list = new ArrayList<>();
            list.add(independentWindow.getUserMenu());
            clearItems(list);
         }
         stage.setOnHidingHandler(null);
         stage.hide();
      }
   }

   private List<Menu> getAllIndependentWindowMenus() {
      return StageHelper.getStages().stream()
         .filter(stg -> stg instanceof IndependentWindow)
         .map(stg -> ((IndependentWindow)stg).getUserMenu())
         .filter(Objects::nonNull)
         .collect(Collectors.toList());
   }

   private ManagedWindow findPopupStage(String id) {
      return StageHelper.getStages().stream()
         .filter(stg -> stg instanceof ManagedWindow)
         .map(stg -> (ManagedWindow) stg)
         .filter(stg -> id.equals(stg.getStageId()))
         .findFirst().orElse(null);
   }

   public void setLockedLabelConsumer(Consumer<LockedLabel> lockedLabelConsumer) {
      this.lockedLabelConsumer = lockedLabelConsumer;
   }

   public void setMarketSubjectConsumer(Consumer<Boolean> marketSubjectConsumer) {
      this.marketSubjectConsumer = marketSubjectConsumer;
      determineAndDisplayMarketSubjectStatus();
   }

   /**
    * Gets the default quantity from the configuration module for the provided secClassId.
    *
    * @param secClassId the sec class id
    * @return the default quantity.
    */
   public Double getDefaultQuantity(Integer secClassId) {
      if (secClassId != null && secClassId == AmpSecClassId.strategy) {
         return configurationModule.getData().strategyDefaultQtyProperty().get();
      }
      return configurationModule.getData().outrightDefaultQtyProperty().get();
   }


   private void loadHeaderNode(XfeWindow xfeWindow) {
      Label titleLabel = xfeWindow.getLabelTitle();
      titleLabel.setScaleX(1.1);
      titleLabel.setScaleY(1.1);
      titleLabel.setStyle("-fx-font-weight: bold;");
      xfeWindow.getIconContainer().setOnMouseReleased(weakLogoClickedEvent);
      this.headerLayout = HeaderLayout.load();
      xfeWindow.getHeaderPane().getChildren().add(this.headerLayout.getRoot());
   }

   public Map<String, ManagedWindow> getPopoverWindowsMap() {
      return popoverWindowsMap;
   }

   public void setSpringBoardLauncher(Runnable springBoardLauncher) {
      this.springBoardLauncher = springBoardLauncher;
   }

   private ActiveSessionModule getActiveSessionModule() {
      return activeSessionModule;
   }

   public LogonModule getLogonModule() {
      return logonModule;
   }

   public FxApplicationModule getFxAppModule() {
      return fxAppModule;
   }

   public SiteModule getSiteModule() {
      return siteModule;
   }
}

