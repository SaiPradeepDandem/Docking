package xfe.icap.modules.tradesworkup;

import java.text.SimpleDateFormat;

/**
 * Constants for workup implementation.
 */
public interface WorkupConstants {
   String PRIVATE_SESSION = "Private";
   String PUBLIC_SESSION = "Public";
   String OPEN_SESSION = "Open";
   SimpleDateFormat END_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

   /** Time(in seconds) for evaluating the clearforworkup orders. */
   long CLEAR_FOR_WORKUP_TIMEOUT = 10;
}
