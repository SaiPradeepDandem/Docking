package xfe.icap.modules.groupdata;

import com.omxgroup.xstream.amp.AmpGroupType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpGroup;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.session.QueryFeed;
import xstr.session.QueryReplyRow;
import xstr.session.XtrQueryRequest;
import xstr.session.XtrQueryRequestBuilder;
import xstr.util.Fx;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

@Module.Autostart
public class GroupDataModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(GroupDataModule.class);

   @Override
   public Future<Void> startModule() {
      activeSessionModule.getSession().ifPresent((session) -> {
         try {
            XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpGroup.req, session).set(AmpGroup.groupType, AmpGroupType.button).build();
            QueryFeed srcFeed = session.queries.getFeedSource(req);
            srcFeed.addListener(feedEvents -> Fx.runLater(() -> {
               feedEvents.stream().filter(e -> e.getRow().isPresent()).forEach(e -> {
                  switch (e.getEventType()) {
                     case CREATE:
                     case UPDATE:
                        getGroups().add(e.getRow().get());
                        break;
                     case DELETE:
                        logger.error("!!! AmpGroup delete has be detected !!!");
                     default:
                  }
               });
            }));
         } catch (AsnTypeException | AmpPermissionException e) {
            logger.error("!!! Error in retrieving the AmpGroup data !!!");
            e.printStackTrace();
         }
      });
      return Future.SUCCESS;
   }

   public ObservableList<QueryReplyRow> getSortedGroups() {
      if (sortedGroups == null) {
         sortedGroups = new SortedList<>(groups, (row1, row2) -> {
            final Long priority1 = row1.getValue(AmpGroup.priority);
            final Long priority2 = row2.getValue(AmpGroup.priority);
            return priority1.compareTo(priority2);
         });
      }
      return sortedGroups;
   }

   public ObservableList<QueryReplyRow> getGroups() {
      return groups;
   }

   private ObservableList<QueryReplyRow> sortedGroups;
   private ObservableList<QueryReplyRow> groups = FXCollections.observableArrayList();
}
