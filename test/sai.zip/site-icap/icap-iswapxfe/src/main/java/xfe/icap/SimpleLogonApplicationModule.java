package xfe.icap;

import java.util.Arrays;
import java.util.List;

import xstr.icap.amp.ICAPAmpSiteConfig;
import xstr.util.concurrent.Future;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.MenuItem;

import xstr.amp.Xtr;
import xstr.session.SessionListener;
import xfe.util.SimpleLogonLayout;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.modules.layout.FxLayoutManager;
import xfe.modules.history.HistoryModule;
import xfe.modules.modalnotification.ISwapNotificationModule;
import xfe.module.Module;
import xfe.module.ModuleException;
import xfe.modules.session.SessionModule;
import xfe.ui.KeyboardNavigationModule;
import xfe.ui.logon.impl.ConnectionStatusPane;

public abstract class SimpleLogonApplicationModule extends FxApplicationModule implements SessionListener{
   static {
      Xtr.init(new ICAPAmpSiteConfig());
   }

   private final SimpleLogonLayout layout = new SimpleLogonLayout();
   private final XfeSession session = new XfeSession();

   private final ObservableList<MenuItem> globalActions = FXCollections.observableArrayList();

   @Override
   public ObservableList<MenuItem> getGlobalActions() {
      return globalActions;
   }

//   @Override
   public List<Module> getModules() {
      return Arrays.asList(
         layout,
         session,
//         new FxLayoutManager(),
         new SessionModule(),
         new ConnectionStatusPane(),
         new ISwapNotificationModule(),
         new KeyboardNavigationModule(),
         new HistoryModule());
   }

//   @Override
   public List<Class<? extends Module>> getModuleClasses() {
      return Arrays.asList(
//            layoutModule,
//            sessionModule,
         FxLayoutManager.class,
         SessionModule.class,
         ConnectionStatusPane.class,
         ISwapNotificationModule.class,
         KeyboardNavigationModule.class,
         HistoryModule.class);
   }

   @Override
   public Future<Void> startModule() throws ModuleException {
      return super.startModule().map( x -> {
         session.getUnderlyingSession().addSessionListener(this);
         return null;
      });
   }


      @Override
      public Future<Void> handleLogon() {
         onLogon(session);
         return DONE;
      }

      @Override
      public void handleLogoff() {
         onLogoff();
      }
   protected void setApplicationRootNode(Node n) {
      layout.addView(n);
   }

   protected abstract void initApp();

   protected void onLogon(XfeSession session) {
   }

   protected void onLogoff() {
   }
}
