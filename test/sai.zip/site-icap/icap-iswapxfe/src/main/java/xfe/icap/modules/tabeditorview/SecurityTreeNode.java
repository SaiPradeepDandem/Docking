package xfe.icap.modules.tabeditorview;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableStringValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import xfe.modules.watchlist.InstrumentSecurityTreeNode;
import xfe.types.SecBoard;
import xfe.types.StrategyInfo;
import xstr.util.Fx;
import xstr.util.NoRecurse;

import java.text.DateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Set;

public class SecurityTreeNode implements InstrumentSecurityTreeNode {
   private static final DateFormat dateFormat = DateFormat.getDateInstance();

   private final SecBoard secBoard;
   private final BooleanProperty selectedProperty;
   private final ObservableBooleanValue selectedImplProperty;
   private final ObservableSet<SecBoard> selectedInstruments;

   SecurityTreeNode(
      SecBoard secBoard,
      ObservableSet<SecBoard> selectedInstruments,
      BooleanProperty selectedInstrumentsGateOpen) {
      this.secBoard = secBoard;
      this.selectedProperty = new SimpleBooleanProperty(selectedInstruments.contains(secBoard));
      this.selectedInstruments = selectedInstruments;
      this.selectedImplProperty = Fx.contains(selectedInstruments, secBoard, selectedInstrumentsGateOpen);
      this.selectedImplProperty.addListener(observable -> selectedProperty.set(selectedImplProperty.get()));
      this.selectedProperty.addListener(new ChangeListener<Boolean>() {
         final NoRecurse noRecurse = new NoRecurse();

         @Override
         public void changed(
            ObservableValue<? extends Boolean> observableValue,
            Boolean oldValue,
            Boolean newValue) {
            noRecurse.run(() -> {
               if (!oldValue && newValue) {
                  selectedInstruments.add(secBoard);
               }

               if (oldValue && !newValue) {
                  selectedInstruments.remove(secBoard);
               }
            });
         }
      });
   }

   @Override
   public ObservableStringValue displayProperty() {
      return Fx.constOf(secBoard.getSecCode());
   }

   @Override
   public String getInfoText() {
      StrategyInfo stInfo  = secBoard.getStrategyInfo();
      String info = "";
      if (stInfo == null) {
         Date maturityDate = secBoard.getMaturityDate();
         info = maturityDate == null ? "No maturity" : String.format("%s", dateFormat.format(maturityDate));
      } else {
         for (int i = 0; i < stInfo.getNumLegs(); ++i) {
            SecBoard sb = stInfo.getLegs()[i];
            Date maturityDate = sb.getMaturityDate();
            if (i != 0) info += ", ";
            info += "Leg " + new Integer(i+1).toString() + ": ";
            info += maturityDate == null ? "No maturity" : String.format("%s", dateFormat.format(maturityDate));
         }
      }

      return info;
   }

   @Override
   public ObservableList<InstrumentSecurityTreeNode> getChildrenUnmodifiable() {
      return FXCollections.emptyObservableList();
   }

   @Override
   public int hashCode() {
      return this.secBoard.getSecCode().hashCode();
   }

   @Override
   public boolean equals(Object other) {
      if (other instanceof SecurityTreeNode) {
         SecurityTreeNode that = (SecurityTreeNode)other;

         return this.secBoard.getSecCode().equals(that.secBoard.getSecCode());
      }

      return false;
   }

   @Override
   public BooleanProperty allSelectedProperty() {
      return selectedProperty;
   }

   @Override
   public ObservableBooleanValue someSelectedProperty() {
      return Fx.valueOf(false);
   }

   @Override
   public void toggleSelected() {
      if (this.selectedInstruments.contains(secBoard)) {
         this.selectedInstruments.remove(secBoard);
      } else {
         this.selectedInstruments.add(secBoard);
      }
   }

   @Override
   public long getMaturityDate() {
      Date date = this.secBoard.getMaturityDate();

      return date != null ? this.secBoard.getMaturityDate().getTime() : Long.MAX_VALUE;
   }

   @Override
   public Set<SecBoard> getSecurities() {
      return Collections.singleton(secBoard);
   }

   @Override
   public Long getSortOrder() {
      return null;
   }

   @Override
   public boolean isGiltsStrategy() {
      return secBoard.isStrategy() && secBoard.isGilt();
   }

   @Override
   public StrategyInfo getStrategyInfo() {
      return secBoard.getStrategyInfo();
   }

   @Override
   public String toString() {
      return secBoard.toString();
   }
}
