package xfe.icap.modules.iswaptrades;

import com.omxgroup.xstream.amp.AmpTradeStatus_v2;
import javafx.beans.InvalidationListener;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;
import javafx.util.StringConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.AmpMarketTrade;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpTrade;
import xfe.icap.types.TradesFactory;
import xfe.icap.types.Trade;
import xfe.ui.table.AsnValueFactory;
import xfe.ui.table.DynamicTableCell;
import xfe.ui.table.TableCellFactory;
import xfe.ui.table.TableCellFactory.Me;
import xfe.util.Constants;
import xfe.util.StyleSwitcher;
import xfe.util.scene.control.NodeFlashDecorator;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.session.XtrKey;
import xstr.types.TradeSide;
import xstr.util.*;
import xstr.util.filter.ObservableRowFilter;

import static xfe.ui.table.Cells.*;

class TradesColumns implements Constants {

   static final SimpleBooleanProperty autoPopupWorkupProp = new SimpleBooleanProperty();

   private static final ValueOnNode<TableCell<?, ?>, BooleanProperty> cellSelectedPropertyOnNode = new ValueOnNode<TableCell<?, ?>, BooleanProperty>() {
      @Override
      protected BooleanProperty initialise(TableCell<?, ?> cell) {
         return new SimpleBooleanProperty(false);
      }
   };

   private static final Logger logger = LoggerFactory.getLogger(TradesColumns.class);

   static TableColumn<ObservableReplyRow, String> createMarketInstrumentColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(asnStringCell(AmpMarketTrade.secCode))
         .textTooltip()
         .strong()
         .basic().setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR);
      col.setPrefWidth(147);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarketRateColumn(XfeSession session) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(
         asnUsdBondPriceNumberCell(AmpMarketTrade.price_d, AmpMarketTrade.secCode, AmpMarketTrade.boardId,session.secBoards.get().getSecBoardsByKey()))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText(Constants.COLUMN_NAME_RATE);
      col.setPrefWidth(61);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarketQtyColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(asnNumberCell(AmpMarketTrade.quantity))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Qty");
      col.setPrefWidth(54);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarketTradeTimeColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(asnStringCell(AmpMarketTrade.tradeTime))
         //.textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Trade Time");
      col.setPrefWidth(85);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarketLastUlColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(asnNumberCell(AmpMarketTrade.underlyingPrice))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Last UL");
      col.setPrefWidth(100);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarketPayTypeColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(asnStringCell(AmpMarketTrade.buyStrategyTradeTypeAsString))
         .textTooltip()
         .strong()
         .basic().setCellFactoryIn(col);
      col.setText("Pay Type");
      col.setPrefWidth(90);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarketRecTypeColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(asnStringCell(AmpMarketTrade.sellStrategyTradeTypeAsString))
         .textTooltip()
         .strong()
         .basic().setCellFactoryIn(col);
      col.setText("Rec Type");
      col.setPrefWidth(90);
      col.setResizable(false);
      return col;
   }

   private static Fun1<ObservableReplyRow, ObservableBooleanValue> rowAvailableAccessor = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
      @Override
      public ObservableBooleanValue call(ObservableReplyRow row) {
         return Fx.valueOf(row != null);
      }
   };

   static TableColumn<ObservableReplyRow, ?> createInstrumentColumn(
      ServerSession session,
      Property<Runnable> interrogationActionProperty,
      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> cellAction,
      ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker,
         asnStringCell(AmpTrade.secCode)
            .textTooltip()
            .strong()
            .annotate(cellSelectedPropertyOnNode, interrogationActionProperty, cellAction, rowAvailableAccessor)
            .style("instr-cell")
            .basic())).setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR);
      col.setPrefWidth(147);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, TradeSide> createPayRecColumn(ServerSession session) {
      TableColumn<ObservableReplyRow, TradeSide> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, TradeSide>, DynamicTableCell<ObservableReplyRow, TradeSide>> cell =
         DynamicTableCell.converterCell(tradeSideValueFactory(session), tradeSideConverter);
      TableCellFactory.of(payRecStyle(cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("P/R");
      col.setPrefWidth(50);
      col.setResizable(false);
      return col;
   }


   static TableColumn<ObservableReplyRow, QueryReplyRow> createRateColumn(XfeSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, QueryReplyRow> col = new TableColumn<>();

      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker,
         tradePriceCell(session))).style("number")
         .textTooltip().basic().setCellFactoryIn(col);
      col.setText(Constants.COLUMN_NAME_RATE);
      col.setPrefWidth(61);
      col.setResizable(false);
      col.setCellValueFactory(cellData -> cellData.getValue().rowProperty());

      return col;
   }

   private static Me<ObservableReplyRow, QueryReplyRow, TableCell<ObservableReplyRow, QueryReplyRow>> tradePriceCell(XfeSession session) {

      return new
         Me<ObservableReplyRow,
            QueryReplyRow,
            TableCell<ObservableReplyRow, QueryReplyRow>>() {
            @Override
            public TableCell<ObservableReplyRow, QueryReplyRow> call(TableColumn<ObservableReplyRow, QueryReplyRow> param) {
               return new TableCell<ObservableReplyRow, QueryReplyRow>() {
                  @Override
                  protected void updateItem(QueryReplyRow item, boolean empty) {
                     super.updateItem(item, empty);

                     if (item == null || empty) {
                        setText("");
                        return;
                     }

                     String price = item.getString(AmpTrade.price);
                     String spreadoverBP = item.getString(AmpTrade.spreadoverBP);
                     String secCode = item.getValue(AmpTrade.secCode);
                     String boardId = item.getValue(AmpTrade.boardId);
                     Trade trade = new Trade(item);

                     if (price == null) {
                        setText("");
                        return;
                     }

                     if (session.secBoards.get().isUsBond(secCode,boardId)) {
                        try {
                           price = Util.convertToUsBondPrice(Double.parseDouble(price));
                        } catch (NumberFormatException e) {
                           logger.error("can't parse rate from {}", price);
                           setText("N/A");
                           return;
                        }
                     }
                     else if (trade != null && spreadoverBP != null && trade.isSO_orManualSOFC()) {
                        price = spreadoverBP;
                     }

                     setText(price);
                  }
               };
            }
         };
   }

   static TableColumn<ObservableReplyRow, String> createQtyColumn(ServerSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker,
         asnNumberCell(AmpTrade.quantity_d)))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Qty");
      col.setPrefWidth(54);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, Integer> createStatusColumn(ServerSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, Integer> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, Integer>, DynamicTableCell<ObservableReplyRow, Integer>> cell =
         DynamicTableCell.converterCell(AsnValueFactory.asValue(AmpTrade.status), tradeStatusConverter);
      TableCellFactory.of(conditionalStrategyStyleWithFlashing(session, isLegForBroker,cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Status");
      col.setPrefWidth(64);
      col.setResizable(false);
//      TableCellFactory.of(conditionalStrategyMouseClick(session,cell));
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createTradeTimeColumn(ServerSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker,
         asnStringCell(AmpTrade.time)))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Trade Time");
      col.setPrefWidth(74);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createFirmColumn(ServerSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(tradeFirmValueFactory(session));
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker, cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Firm");
      col.setPrefWidth(100);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarketFirmColumn(ServerSession session,
                                                                         TradeSide side) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(marketTradeFirmValueFactory(session, side));
      TableCellFactory.of(cell)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText(side==TradeSide.BUY ? "Pay Firm" : "Rec Firm");
      col.setPrefWidth(90);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createFirmColumn(ServerSession session,
                                                                   TradeSide side,
                                                                   ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(tradeFirmValueFactory(session,side));
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker, cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText(side==TradeSide.BUY ? "Pay Firm" : "Rec Firm");
      col.setPrefWidth(100);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, Boolean> createBrokerTickColumn(ServerSession session) {
      TableColumn<ObservableReplyRow, Boolean> col = new TableColumn<>();
      col.setCellFactory(asnBooleanCell(brokerTickValueFactory(session)));
      col.setText("B");
      col.setPrefWidth(20);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createBrokerColumn(ServerSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(brokerValueFactory(session,null));
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker, cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Broker");
      col.setPrefWidth(101);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createPayBrokerColumn(ServerSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(brokerValueFactory(session,TradeSide.BUY));
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker, cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Pay Broker");
      col.setPrefWidth(101);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createRecBrokerColumn(ServerSession session, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(brokerValueFactory(session,TradeSide.SELL));
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker, cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Rec Broker");
      col.setPrefWidth(101);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createTraderColumn(ServerSession session, ObservableRowFilter isLegFilterForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(TradesFactory.traderValueFactory());
      TableCellFactory.of(conditionalStrategyStyle(isLegFilterForBroker, cell))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Trader");
      col.setPrefWidth(80);
      col.setMaxWidth(80);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createTraderColumn(ServerSession session, TradeSide side, ObservableRowFilter isLegForBroker) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(TradesFactory.traderValueFactory(side));
      TableCellFactory.of(conditionalStrategyStyle(isLegForBroker, cell))
         .textTooltip()
         .basic()
         .setCellFactoryIn(col);
      col.setText(side==TradeSide.BUY ? "Pay Trader" : "Rec Trader");
      col.setPrefWidth(90);
      col.setMaxWidth(90);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createBuyStpStatusColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(TradesFactory.buyStpStatusFactory());
      TableCellFactory.of(cell)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Pay STP Status");
      col.setPrefWidth(105);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createSellStpStatusColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(TradesFactory.sellStpStatusFactory());
      TableCellFactory.of(cell)
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Rec STP Status");
      col.setPrefWidth(105);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createBackOfficeRefColumn(TradeSide side, String prefix) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      AsnConversionAccessor<String> acc = side == TradeSide.BUY ? AmpTrade.buyGuiReference : AmpTrade.sellGuiReference;
      TableCellFactory.of(asnStringCell(acc))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText(prefix + "i-Swap Back Office Ref");
      col.setPrefWidth(130);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createMarkitWireIdColumn(TradeSide side, String prefix) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      AsnConversionAccessor<String> acc = side == TradeSide.BUY ? AmpTrade.buyMarkitWireId : AmpTrade.sellMarkitWireId;
      TableCellFactory.of(asnStringCell(acc))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText(prefix + "MarkitWire Ref");
      col.setPrefWidth(100);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createTradeTypeColumn(TradeSide side, String prefix) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      AsnConversionAccessor<String> acc = side == TradeSide.BUY ? AmpTrade.buyStrategyTradeTypeAsString : AmpTrade.sellStrategyTradeTypeAsString;
      TableCellFactory.of(asnStringCell(acc))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText(prefix + "Trade Type");
      col.setPrefWidth(120);
      col.setResizable(false);
      return col;
   }

   private static Callback<QueryReplyRow, ObservableObjectValue<TradeSide>> tradeSideValueFactory(ServerSession session) {
      String ownFirmId = session.getStats().getFirmId();
      return row -> {
         if (ownFirmId.equals(row.getValue(AmpTrade.buyFirmId))) {
            return Fx.constOf(TradeSide.BUY);
         } else if (ownFirmId.equals(row.getValue(AmpTrade.sellFirmId))) {
            return Fx.constOf(TradeSide.SELL);
         } else {
            return Fx.constOf(TradeSide.CROSS);
         }
      };
   }

   private static Callback<QueryReplyRow, ObservableObjectValue<String>> marketTradeFirmValueFactory(ServerSession session, TradeSide side) {
      return row -> Fx.constOf(side==TradeSide.BUY ? row.getValue(AmpMarketTrade.buyFirmId) : row.getValue(AmpMarketTrade.sellFirmId));
   }

   private static Callback<QueryReplyRow, ObservableObjectValue<String>> tradeFirmValueFactory(ServerSession session, TradeSide side) {
      return row -> Fx.constOf(side==TradeSide.BUY ? row.getValue(AmpTrade.buyFirmId) : row.getValue(AmpTrade.sellFirmId));
   }

   private static Callback<QueryReplyRow, ObservableObjectValue<String>> tradeFirmValueFactory(ServerSession session) {
      String ownFirmId = session.getStats().getFirmId();
      return row -> {
         String buyFirmId = row.getValue(AmpTrade.buyFirmId);
         String sellFirmId = row.getValue(AmpTrade.sellFirmId);

         if (ownFirmId.equals(sellFirmId)) {
            return Fx.constOf(buyFirmId);
         } else if (ownFirmId.equals(buyFirmId)) {
            return Fx.constOf(sellFirmId);
         } else {
            return Fx.constOf(String.format("%s/%s", buyFirmId, sellFirmId));
         }
      };
   }

   private static Callback<ObservableReplyRow, ObservableObjectValue<String>> brokerValueFactory(ServerSession session, TradeSide side) {
      return row -> {
         TradeSide tradeSide = side == null ? tradeSideValueFactory(session).call(row).get() : side;
         switch(tradeSide) {
            case BUY:
               return row.getProperty(AmpTrade.buyOperatorId);
            default:
               return row.getProperty(AmpTrade.sellOperatorId);
         }
      };
   }

   private static Callback<ObservableReplyRow, ObservableObjectValue<Boolean>> brokerTickValueFactory(ServerSession session) {
      return row -> {
         TradeSide tradeSide = tradeSideValueFactory(session).call(row).get();
         String brokerVal = null;
         switch(tradeSide) {
            case BUY:
               brokerVal = row.getProperty(AmpTrade.buyOperatorId).get();
               return (brokerVal == null || brokerVal.isEmpty()) ? Fx.constOf(false) : Fx.constOf(true);
            default:
               brokerVal = row.getProperty(AmpTrade.sellOperatorId).get();
               return (brokerVal == null || brokerVal.isEmpty()) ? Fx.constOf(false) : Fx.constOf(true);
         }
      };
   }

   private static final String CROSS_ORDER_STYLE = "xfe-cross-cell";
   private static <T extends TableCell<ObservableReplyRow, TradeSide>> Callback<TableColumn<ObservableReplyRow, TradeSide>, T> payRecStyle(Callback<TableColumn<ObservableReplyRow, TradeSide>, T> wrappedCellFactory) {
      StyleSwitcher styles = new StyleSwitcher(BUY_STYLE, SELL_STYLE, CROSS_ORDER_STYLE);

      return new Callback<TableColumn<ObservableReplyRow, TradeSide>, T>() {
         void updateStyle(TableCell<ObservableReplyRow, TradeSide> cell) {
            if (cell.getItem() == null) {
               styles.clear(cell);
            } else {
               switch (cell.getItem()) {
                  case BUY:
                     styles.switchStyle(cell, BUY_STYLE);
                     break;
                  case SELL:
                     styles.switchStyle(cell, SELL_STYLE);
                     break;
                  case CROSS:
                     styles.switchStyle(cell, CROSS_ORDER_STYLE);
                     break;
               }
            }
         }

         @Override
         public T call(TableColumn<ObservableReplyRow, TradeSide> column) {
            T cell = wrappedCellFactory.call(column);

            InvalidationListener updateListener = observable -> updateStyle(cell);

            cell.itemProperty().addListener(updateListener);

            return cell;
         }
      };
   }

   private static final StringConverter<TradeSide> tradeSideConverter = new StringConverter<TradeSide>(){
      @Override
      public String toString(TradeSide side) {
         switch (side) {
            case BUY: return Constants.LABEL_PAY;
            case SELL: return Constants.LABEL_REC;
            case CROSS: return "Cross";
         }
         return "";
      }

      @Override
      public TradeSide fromString(String sideString) {
         return null;
      }
   };

   static final StringConverter<Integer> tradeStatusConverter = new StringConverter<Integer>(){
      @Override
      public String toString(Integer status) {
         switch (status) {
            case AmpTradeStatus_v2.matched: return TradeAlert.STATUS_DONE;
            case AmpTradeStatus_v2.withdrawn: return TradeAlert.STATUS_WITHDRAW;
            case AmpTradeStatus_v2.unapproved: return TradeAlert.STATUS_UNAPPROVED;
            case AmpTradeStatus_v2.unconfirmed_buy: return TradeAlert.STATUS_UNCNF_BUY;
            case AmpTradeStatus_v2.unconfirmed_sell: return TradeAlert.STATUS_UNCNF_SELL;
            case AmpTradeStatus_v2.pending: return TradeAlert.STATUS_PENDING;
            case AmpTradeStatus_v2.amended: return TradeAlert.STATUS_AMENDED;
            //case AmpTradeStatus_v2.workup: return TradeAlert.STATUS_WORKUP;
            case AmpTradeStatus_v2.rfqpending: return TradeAlert.STATUS_RFQ_PENDING;
         }
         return TradeAlert.STATUS_UNKNOW;
      }

      @Override
      public Integer fromString(String sideString) {
         return null;
      }
   };

   private static final String STRATEGY_LEG_STYLE = "xfe-strategy-leg";
   private static final String NO_LEG_STYLE = "xfe-no-leg";
   private static final Integer WORKUP_I_VALUE = 1000/*AmpTradeStatus_v2.workup*/;

   private static <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> conditionalStrategyStyle(
      ObservableRowFilter isLegForBroker,
      Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory) {
      StyleSwitcher styles = new StyleSwitcher(STRATEGY_LEG_STYLE, NO_LEG_STYLE);
      return new Callback<TableColumn<ObservableReplyRow, T>, U>() {
         void updateStyle(TableCell<ObservableReplyRow, T> cell) {
            if (cell.getItem() == null) {
               styles.clear(cell);
            } else {
               int idx = cell.getIndex();

               if (idx < 0 || idx >= cell.getTableView().getItems().size()) {
                  styles.clear(cell);
               } else {
                  ObservableReplyRow row = cell.getTableView().getItems().get(idx);

                  if (isLegForBroker!=null? isLegForBroker.accept(row).get() : TradesFilters.isLeg.accept(row))
                     styles.switchStyle(cell, STRATEGY_LEG_STYLE);
                  else
                     styles.switchStyle(cell, NO_LEG_STYLE);
               }
            }
         }

         @Override
         public U call(TableColumn<ObservableReplyRow, T> column) {
            U cell = wrappedCellFactory.call(column);
            InvalidationListener updateListener = observable -> updateStyle(cell);

            cell.itemProperty().addListener(updateListener);
            return cell;
         }
      };
   }

   private static <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> conditionalStrategyStyleWithFlashing(
      ServerSession session,
      ObservableRowFilter isLegForBroker,
      Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory) {
      StyleSwitcher legStyles = new StyleSwitcher(STRATEGY_LEG_STYLE, NO_LEG_STYLE);

      return new Callback<TableColumn<ObservableReplyRow, T>, U>() {
         void updateStyle(TableCell<ObservableReplyRow, T> cell) {
            if (cell.getItem() == null) {
               legStyles.clear(cell);
            } else {
               int idx = cell.getIndex();

               if (idx < 0 || idx >= cell.getTableView().getItems().size()) {
                  legStyles.clear(cell);
               } else {
                  ObservableReplyRow row = cell.getTableView().getItems().get(idx);
                  if (isLegForBroker!=null? isLegForBroker.accept(row).get() : TradesFilters.isLeg.accept(row)){
                     legStyles.switchStyle(cell, STRATEGY_LEG_STYLE);
                  } else {
                     legStyles.switchStyle(cell, NO_LEG_STYLE);
                     if (TradesFilters.isBuyerOrSeller().accept(row) && !autoPopupWorkupProp.get() )
                        new NodeFlashDecorator(cell,cell.textProperty(),TradeAlert.STATUS_WORKUP);

                  }
               }
            }
         }

         @Override
         public U call(TableColumn<ObservableReplyRow, T> column) {
            U cell = wrappedCellFactory.call(column);
            cell.addEventFilter(MouseEvent.MOUSE_CLICKED, event -> {
               if (WORKUP_I_VALUE.equals(cell.getItem())) {
                  XtrKey key = cell.getTableView().getSelectionModel().getSelectedItem().getKey();
                  TradeWorkupStageFactory.showTradeWorkup(key);
               }
            });

            InvalidationListener updateListener = observable -> updateStyle(cell);

            cell.itemProperty().addListener(updateListener);

            return cell;
         }
      };
   }

}
