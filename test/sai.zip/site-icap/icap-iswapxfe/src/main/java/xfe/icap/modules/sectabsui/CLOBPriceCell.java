package xfe.icap.modules.sectabsui;

import javafx.event.EventHandler;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.MouseEvent;
import javafx.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.modules.actions.PopupOrderEntryArgs;
import xfe.modules.actions.TickUpDownAmendArgs;
import xfe.modules.actions.WorkupArgs;
import xstr.session.WatchlistRow;
import xstr.session.XtrTransReply;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

/**
 * Price cell for CLOB orders.
 */
public class CLOBPriceCell extends WatchlistPriceCell {
   private static final Logger logger = LoggerFactory.getLogger(CLOBPriceCell.class);
   private static final Pattern validEditingState = Pattern.compile("(^[-+]?\\d*\\.?[\\d]+)|(^[-+]?\\d*\\.)");

   private final UnaryOperator<TextFormatter.Change> filter = c -> {
      String text = c.getControlNewText();
      if (validEditingState.matcher(text).matches() || text.isEmpty() ||
         ".".equals(text) ||
         "-".equals(text) ||
         "+".equals(text)) {
         return c;
      } else {
         return null;
      }
   };
   /**
    * Specifies the order side of the cell.
    */
   private OrderSide side;

   /**
    * Text field for editing the cell.
    */
   private TextField editField;

   /**
    * Used to keep backup while editing the value in text field.
    */
   private PriceCellValue<BigDecimal> prevValue;

   private TickUpDown tickUpDown;

   /**
    * Constructor
    *
    * @param side Order side
    */
   CLOBPriceCell(OrderSide side) {
      super();
      this.side = side;
      tickUpDown = new TickUpDown(this);
      tickUpDown.setCallBack(isTickUp->{
         WatchlistRow tRow = (WatchlistRow) getTableRow().getItem();
         getSecTable().getDoTickUpDownPriceAmend().accept(new TickUpDownAmendArgs(tRow.getRow(), side, isTickUp));
      });
   }

   @Override
   protected void updateDataItem(PriceCellValue<BigDecimal> item) {
      if (item.isCLOBWorkup() || item.isCMWorkup()) {
         cancelEdit();
      }

      super.updateDataItem(item);
      //Client wants the ticksup and down disable
      //this is the only place where we enable them if the item is amendable
      //I'm not removing the code, as this is likely to be brought back again.
      //All other functionality to remain
      //tickUpDown.setEnabled(item.isAmendable());

      if (isEditing()) {
         prevValue = item;
      }
   }

   @Override
   protected void resetDataItem() {
      if (isEditing()) {
         prevValue = null;
      } else {
         super.resetDataItem();
      }
   }


   @Override
   protected boolean isDataEditable() {
      return true;
   }

   @Override
   protected void onSingleClick(MouseEvent e) {
      WatchlistRow tRow = (WatchlistRow) getTableRow().getItem();
      SecTable secTable = getSecTable();
      if (getItem() != null && getItem().isCLOBWorkup())
         secTable.getPriceColWorkupAction().accept(new WorkupArgs(tRow.getRow(), this, side));
      else if (!secTable.isOneClickTrading()) {
         if (!isPopOverShowing()) {
            secTable.getPriceColDblClickAction().accept(new PopupOrderEntryArgs(tRow.getRow(), this, side, null, PopupOrderEntryArgs.DefaultOn.PRICE));
         }
      } else {
         secTable.edit(getIndex(), getTableColumn());
      }
   }

   @Override
   protected void resetForNonInstrumentRow() {
      tickUpDown.setEnabled(false);
      tickUpDown.hide();
   }

   @Override
   public void startEdit() {
      if (!isEditable() || !getTableView().isEditable() || !getTableColumn().isEditable()) {
         return;
      }
      if ((getItem() != null && getItem().isCLOBWorkup()) || !getSecTable().isOneClickTrading() || getSecTable().getIsLocked().get()) {
         return;
      }

      super.startEdit();
      prevValue = getItem() == null ? null : new PriceCellValue<>(getItem());
      /* First get the text from cell and put in text field */
      final TextField textField = getEditField();
      textField.setText(getText());

      /* Clear the text from the cell */
      setText(null);

      /* Set the text as graphic and focus on it */
      setGraphic(textField);
      textField.requestFocus();
   }

   /**
    * Lazy getter of the edit text field of the cell.
    *
    * @return TextField
    */
   private TextField getEditField() {
      if (editField == null) {
         final TextFormatter<Double> textFormatter = new TextFormatter<>(filter);
         editField = new TextField();
         editField.setTextFormatter(textFormatter);
         editField.getStyleClass().add("");
         editField.setOnKeyPressed(t -> {
            switch(t.getCode()) {
               case ESCAPE:
                  cancelEdit();
                  break;
               case DECIMAL:
               case PERIOD:
                  if (editField.getText() != null) {
                     final int decPointPos = editField.getText().indexOf('.');
                     if (decPointPos >= 0) {
                        editField.positionCaret(decPointPos + 1);
                        editField.selectRange(decPointPos + 1, editField.getText().length());
                     }
                  }
                  break;
               default:
                  break;
            }
         });
         editField.focusedProperty().addListener((obs,old,focused)->{
            /* The moment the focus is lost from the textField, cancel the edit. The focus can be lost by clicking any where in the current scene.
             * This way it can be handled across main app, popover and popup stages.  */
            if(!focused){
               cancelEdit();
            }
         });
         editField.setOnAction(event -> {
            try {
               PriceCellValue<BigDecimal> newValue = prevValue == null ? new PriceCellValue<>(new BigDecimal(editField.getText())) : new PriceCellValue<>(prevValue);
               newValue.setValue(new BigDecimal(editField.getText()));
               newValue.setState(WatchListCellState.IN_EDIT_PENDING);
               commitEdit(newValue);
            } catch (NumberFormatException e) {
               logger.error("\"{}\" is not a valid value!", editField.getText());
               cancelEdit();
            }
         });
      }
      return editField;
   }

   @Override
   public void cancelEdit() {
      if (!isEditing()) return;

      super.cancelEdit();
      stopEdit(false);
   }

   @Override
   public void commitEdit(PriceCellValue<BigDecimal> newValue) {
      if (newValue == null) {
         return;
      }
      super.commitEdit(newValue);
      setValue(newValue);
      setGraphic(null);

      WatchlistRow tRow = (WatchlistRow) getTableRow().getItem();
      Future<XtrTransReply> res = getSecTable().getSendDefaultOrderClbk().apply(tRow.getRow(), new Pair<>(side, newValue.getValue().doubleValue()));
      if (res == null) {
         stopEdit(true);
      } else {
         res.onDone(x -> {
            XtrTransReply result = x.get();
            if (result.getStatus() != XtrTransReply.Status.RESULT_OK) {
               // Transaction failed
               stopEdit(true);
            }
            return Future.SUCCESS;
         });
      }
   }

   private void stopEdit(boolean resetStyle) {
      setGraphic(null);
      editField = null;
      if (resetStyle) {
         getStyleClass().remove(WatchListCellState.IN_EDIT_PENDING.getStyle());
      }
      if (prevValue != null) {
         setValue(prevValue);
         if (resetStyle)
            getStyleClass().add(prevValue.getState().getStyle());
      } else {
         setText(null);
      }
   }
}
