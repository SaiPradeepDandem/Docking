package xfe.icap.modules.popuporderentry;

import com.nomx.domain.types.DefaultDurationType;
import com.nomx.domain.types.OnLogoffAction;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import org.controlsfx.control.PopOver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.modules.ordersdata.DataMode;
import xfe.icap.modules.ordersdata.OrderEntryData;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.OrderTrans;
import xfe.icap.types.Orders;
import xfe.modules.actions.MyOrdersArgs;
import xfe.modules.actions.PopupOrderEntryArgs;
import xfe.types.OrderType;
import xfe.types.OrdersTrans;
import xfe.types.SecBoardStaticInfo;
import xfe.ui.popover.XfePopOver;
import xfe.util.scene.control.BigDecimalTextField;
import xstr.amp.AsnField;
import xstr.session.ObservableReplyRow;
import xstr.session.ServerSession;
import xstr.session.XtrTransReply;
import xstr.types.MapWrapper;
import xstr.types.OrderSide;
import xstr.types.XtrBlob;
import xstr.util.Fx;
import xstr.util.Lazy;
import xstr.util.Util;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

public class PopupOrderEntryPane {
   private static final Logger logger = LoggerFactory.getLogger(PopupOrderEntryPane.class);

   private static final String PRICE_FIELD_ID= "orderEntryPriceTextField";

   private static final String SIZE_FIELD_ID= "orderEntrySizeTextField";
   private static final String AMEND_TEXT = "AMEND";

   private BiFunction<MyOrdersArgs, Boolean, ObservableList<ObservableReplyRow>> getMyOrders;
   @FXML
   private CheckBox aonCheckbox;
   @FXML
   private CheckBox icebergCheckBox;

   @FXML
   private CheckBox ditCheckBox;

   @FXML
   private Button actionButton;

   @FXML
   private Button cancelButton;

   @FXML
   private TextArea errorMsgField;

   @FXML
   private Parent root;
   @FXML
   private Pane sizeTexfFieldContainer;
   @FXML
   private Pane priceTexfFieldContainer;

   private ObservableReplyRow managedOrderToAmend;

   private boolean isEntry;
   private boolean isRenew;
   private Long managedOrderId;
   private OrderSide side;
   private OnLogoffAction onLogoffAction;
   private boolean isShared;
   private boolean isTopcut;
   private XfePopOver popOver;
   private BigDecimal quantity = BigDecimal.ZERO;
   private Optional<ServerSession> session;
   private Consumer<String> closeHandler;
   private Function<Number, String> priceFormatter;

   private static final String BID = "Bid";
   private static final String OFFER = "Offer";
   private static final String AMEND_BID = "Amend Bid";
   private static final String AMEND_OFFER = "Amend Offer";
   private boolean defaultOnPrice;

   public Parent getRoot() {
      return root;
   }

   public BigDecimal getPrice() {
      return price.getValue();
   }

   public void setPrice(BigDecimal newPrice) {
      // text field refuses to edit with + symbol so DO NOT use SecBoardStaticInfo.priceFormatter
      // For Edit field, always use Util.getDefaultFormatter
      if (newPrice != null) {
         String priceStr = Util.getDefaultFormatter().apply(newPrice);
         price.setValue(new BigDecimal(priceStr));
         try {
            Fx.runLater(() -> {
               priceEdit.get().setText(priceStr);
               if(defaultOnPrice){
                  priceEdit.get().setText(priceStr);
                  priceEdit.get().selectAll();
                  priceEdit.get().requestFocus();
               }
            });
         } catch (Exception e) {
            logger.error("Exception while formatting price in PopupOrderEntryPane !!!");
         }
      } else {
         price.setValue(null);
      }
   }

   public BigDecimal getSize() {
      return size.getValue();
   }

   public void setSize(BigDecimal newSize) {
      size.setValue(newSize);
   }

   void setSession(Optional<ServerSession> session) {
      this.session = session;
   }

   void setMyOrdersGetter(BiFunction<MyOrdersArgs, Boolean, ObservableList<ObservableReplyRow>> ordersGetter) {
      this.getMyOrders = ordersGetter;
   }

   private String popupSecCode;
   private String popupBoardId;

   @FXML
   void initialize() {
      final Text bidAmend = new Text(AMEND_TEXT);
      final Text bidAmendSub = new Text("Bid");
      bidAmendSub.getStyleClass().add("small-font");
      VBox amendBidGraphic = new VBox();
      amendBidGraphic.setAlignment(Pos.CENTER);
      amendBidGraphic.getChildren().addAll(bidAmend, bidAmendSub);

      final Text offerAmend = new Text(AMEND_TEXT);
      final Text offerAmendSub = new Text("Offer");
      offerAmendSub.getStyleClass().add("small-font");
      VBox amendOfferGraphic = new VBox();
      amendOfferGraphic.setAlignment(Pos.CENTER);
      amendOfferGraphic.getChildren().addAll(offerAmend, offerAmendSub);

      errorMsgField.managedProperty().bind(errorMsgField.visibleProperty());

      actionButton.setOnAction(e -> onActionButton());
      cancelButton.setOnAction(e -> onClose());

      icebergCheckBox.setOnAction(event -> {
         if (icebergCheckBox.isSelected()) {
            aonCheckbox.setSelected(false);
         }
      });

      aonCheckbox.setOnAction(event -> {
         if (aonCheckbox.isSelected()) {
            icebergCheckBox.setSelected(false);
         }
      });

      priceEdit.get().getStyleClass().add("xfe-custom-textfield");
      sizeEdit.get().getStyleClass().add("xfe-custom-textfield");
      priceEdit.get().setMinHeight(25);
      sizeEdit.get().setMinHeight(25);


      priceEdit.get().setOnKeyPressed(event -> {
         switch(event.getCode()){
            case MULTIPLY:{
               event.consume();
               sizeEdit.get().requestFocus();
               sizeEdit.get().selectAll();
               break;
            }
            case DECIMAL:
            case PERIOD:  {
               final int decPointPos = priceEdit.get().getText().indexOf(".");
               if (decPointPos >= 0) {
                  priceEdit.get().requestFocus();
                  priceEdit.get().positionCaret(decPointPos + 1);
                  priceEdit.get().selectRange(decPointPos + 1, priceEdit.get().getText().length());
               }
               break;
            }
         }
      });

      root.setOnKeyPressed(ke -> {
         if (ke.getCode().equals(KeyCode.ENTER)) {
            ke.consume();
            price.setValue(new BigDecimal(priceEdit.get().getValue(), MathContext.DECIMAL64));
            size.setValue(new BigDecimal(sizeEdit.get().getValue(), MathContext.DECIMAL64));
            onBidOffer(this.side);
         } else if (ke.getCode().equals(KeyCode.MULTIPLY)) {
            // set focus on size field and select all text
            // set focus on price text field
            Platform.runLater(() -> {
               sizeEdit.get().requestFocus();
               sizeEdit.get().selectAll();
            });
         }
      });

      priceTexfFieldContainer.getChildren().addAll(priceEdit.get());
      sizeTexfFieldContainer.getChildren().addAll(sizeEdit.get());

      priceEdit.get().focusedProperty().addListener((observable, oldValue, newValue) -> {
         if (newValue) {
            Platform.runLater(() -> {
               priceEdit.get().positionCaret(0);
               priceEdit.get().selectAll();
            });
         }
      });

      sizeEdit.get().focusedProperty().addListener((o, oldVal, newVal) -> {
         if (newVal) {
            Platform.runLater(() -> {
               sizeEdit.get().positionCaret(0);
               sizeEdit.get().selectAll();
            });
         }
      });
   }

   private void onAmendOrder() {
      logger.debug("**** Executing Amend ****");
      boolean isManagedOrder = true; // Always true for time being. When there are orders other than Managed order this will be determined.
      if (isManagedOrder) {
         onBidOffer(this.side);
      } else {
         ArrayList<AsnField<?>> amendFields = new ArrayList<>();
         amendFields.add(AsnField.create(AmpManagedOrder.price, price.getValue()));
         amendFields.add(AsnField.create(AmpManagedOrder.quantity, size.getValue()));
         if (aonCheckbox.isSelected()) {
            amendFields.add(AsnField.create(AmpManagedOrder.orderType, OrderType.MIN_FILL.toString()));
            amendFields.add(AsnField.create(AmpManagedOrder.allowMultiMinFill, true));
         } else if (icebergCheckBox.isSelected()) {
            amendFields.add(AsnField.create(AmpManagedOrder.orderType, OrderType.ICEBERG.toString()));
         } else {
            amendFields.add(AsnField.create(AmpManagedOrder.orderType, OrderType.REGULAR.toString()));
         }

         try {
            Orders.amend(session.get(),
               this::showErrorMessage,
               managedOrderToAmend,
               amendFields,
               e -> {
                  try {
                     XtrTransReply reply = e.call();
                     if (reply.getStatus() != XtrTransReply.Status.RESULT_OK) {
                        onClose();
                     }
                  } catch (Exception e1) {
                     showErrorMessage(e1.getMessage());
                  }
               });
         } catch (AmpPermissionException | AsnTypeException e) {
            showErrorMessage(e.getMessage());
         }
      }
   }

   private void onCancelOrder() {
      session.map(session -> {
         if (getMyOrders != null) {
            final MyOrdersArgs myOrdersArgs = new MyOrdersArgs();
            myOrdersArgs.setSecCode(popupSecCode);
            myOrdersArgs.setOrderPrice(price.get());
            ObservableList<ObservableReplyRow> myOrders = getMyOrders.apply(myOrdersArgs, popOver == null);
            myOrders = myOrders.filtered(row -> {
               OrderSide side = row.getValue(AmpManagedOrder.buySell) == 0 ? OrderSide.BUY : OrderSide.SELL;
               return side.equals(this.side);
            });

            if (!myOrders.isEmpty()) {
               // we expect only one managed order row, so just get the first one
               final ObservableReplyRow orderRow = myOrders.get(0);
               logger.debug("Withdrawing order :: " + orderRow.getProperty(AmpManagedOrder.secCode).get());
               final Asn1Type orderId = orderRow.getAsn(AmpManagedOrder.currentOrderId);
               final String userId = orderRow.getValue(AmpManagedOrder.userId);
               final String introBrokerId = orderRow.getValue(AmpManagedOrder.introBrokerId);
               onClose();
               return OrdersTrans.withdrawByOrderId(session, orderId, userId, introBrokerId, true);
            }
         }
         return Future.SUCCESS;
      });
   }

   private void onActionButton() {
      price.setValue(new BigDecimal(priceEdit.get().getValue(), MathContext.DECIMAL64));
      size.setValue(new BigDecimal(sizeEdit.get().getValue(), MathContext.DECIMAL64));
      if (actionButton.getText().startsWith(AMEND_TEXT) || actionButton.getText().startsWith("RENEW")) {
         onAmendOrder();
      } else {
         onBidOffer(this.side);
      }
   }

   private void onBidOffer(OrderSide side) {
      boolean isImmediate = false;
      AbstractOrderTrans orderTrans = isManaged() ?
         new ManagedOrderTrans(null) : new OrderTrans(null);
      populateTransactionData(orderTrans, isImmediate);
      logger.debug("**** Executing BUY/SELL ****");

      session.map(session -> {
         // If performing the opposite side for an existing CM Order, then withdraw the existing order before entering the opposite side.
         /*if (isCM && !amendButton.isDisable() && getMyOrders != null) {
            final MyOrdersArgs myOrdersArgs = new MyOrdersArgs();
            myOrdersArgs.setSecCode(popupSecCode);
            myOrdersArgs.setOrderPrice(price.get());
            ObservableList<ObservableReplyRow> myOrders = getMyOrders.apply(myOrdersArgs);
            if (myOrders != null && !myOrders.isEmpty()) {
               // we expect only one managed order row, so just get the first one
               final ObservableReplyRow orderRow = myOrders.get(0);
               logger.debug("Withdrawing order :: " + orderRow.getProperty(AmpManagedOrder.secCode).get());
               final Asn1Type orderId = orderRow.getAsn(AmpManagedOrder.currentOrderId);
               final String userId = orderRow.getValue(AmpManagedOrder.userId);
               final String introBrokerId = orderRow.getValue(AmpManagedOrder.introBrokerId);
               OrdersTrans.withdrawByOrderId(session, orderId, userId, introBrokerId, true);
            }
         }*/
         return orderTrans.executeBuySell(session,
            side.equals(OrderSide.BUY) ? AmpOrderVerb.buy : AmpOrderVerb.sell).onDone(x -> {
            if (x.get().getStatus() == XtrTransReply.Status.RESULT_OK) {
               onClose();
            } else {
               String errorMsg = x.get().getMessage();
               logger.error("onBidOffer: {}", errorMsg);
               showErrorMessage(errorMsg);
               Platform.runLater(() -> priceEdit.get().requestFocus());
            }
            return Future.SUCCESS;
         });
      });
   }

   private void onClose() {
      managedOrderToAmend = null;
      size.set(BigDecimal.ZERO);
      price.setValue(BigDecimal.ZERO);
      aonCheckbox.setSelected(false);
      icebergCheckBox.setSelected(false);
      errorMsgField.setText("");
      errorMsgField.setVisible(false);
      if (closeHandler != null) {
         if (popOver != null) {
            closeHandler.accept(popOver.id());
            popOver.hide();
            popOver = null;
         } else {
            closeHandler.accept(getRoot().getId());
         }
      }
   }

   private boolean isManaged() {
      boolean isManaged = true;
      return isManaged;
   }

   private void populateTransactionData(AbstractOrderTrans orderTrans, boolean isImmediate) {

      orderTrans.setCloneIntoRFS(false);

      orderTrans.setSecCode(popupSecCode);

      orderTrans.setBoardId(popupBoardId);

      if (aonCheckbox.isSelected()) {
         orderTrans.setOrderType(OrderType.MIN_FILL);
         orderTrans.setAllowMultiMinFill(true);
      } else if (icebergCheckBox.isSelected()) {
         orderTrans.setOrderType(OrderType.ICEBERG);
      } else {
         orderTrans.setOrderType(OrderType.REGULAR);
      }

      orderTrans.setVwap(false);

      orderTrans.setPrice(price.getValue().doubleValue());

      orderTrans.setQuantity(size.getValue().doubleValue());

      orderTrans.setDoneIfTouched(ditCheckBox.isSelected());

      orderTrans.setAnonymous(false);

      orderTrans.setUnderRef(false);

      if (isImmediate) {
         orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
      } else {
         orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DAY);
      }

      if (aonCheckbox.isSelected()) {
         orderTrans.setMinFill(size.getValue().doubleValue());
      }

      if (icebergCheckBox.isSelected()) {
         orderTrans.setVisibleQty(quantity.doubleValue());
      }

      orderTrans.setOnLogOffAction(onLogoffAction);
      orderTrans.setShared(isShared);
      orderTrans.setTopCut(isTopcut);
      // Only hit/take is marked as AGG
      final MapWrapper mapWrapper = new MapWrapper();
      mapWrapper.put(Orders.ORDER_TAG_KEY, new XtrBlob(Orders.CLOB.getBytes()));
      orderTrans.setMapWrapper(mapWrapper);
   }

   private void showErrorMessage(String errorMsg){
      Platform.runLater(()->{
         errorMsgField.setText(errorMsg);
         errorMsgField.setVisible(true);
         root.getScene().getWindow().sizeToScene();
      });
   }

   void showRenewMessage() {
      if(!isRenew || priceFormatter == null) return;
      String priceStr = priceFormatter.apply(price.get().doubleValue());
      String renewMsg = "You have unfulfilled " +
         (side == OrderSide.SELL ? "Selling " : "Buying ") +
         "of " +
         popupSecCode +
         " @ " +
         priceStr;
      showErrorMessage(renewMsg);
   }

   void setPopover(XfePopOver p) {
      this.popOver = p;
   }

   void setup(OrderEntryData orderEntryData) {
      this.side = orderEntryData.getSide();
      this.onLogoffAction = orderEntryData.getOnLogoffAction();
      this.isShared = orderEntryData.isShared();
      this.isTopcut = orderEntryData.isTopcut();
      this.managedOrderId = orderEntryData.getOrderId();

      actionButton.setText(this.side.equals(OrderSide.BUY) ? BID : OFFER);

      // initialise the price and size edit fields
      size.setValue(BigDecimal.ZERO);
      price.setValue(BigDecimal.ZERO);
      final BigDecimal orderPrice;
      BigDecimal orderQty;

      isEntry = orderEntryData.getDataMode().equals(DataMode.ENTRY);
      isRenew = orderEntryData.getDataMode().equals(DataMode.RENEW);

      // If called from AmpManagedOrder (a.k.a OrdersView)
      popupSecCode = orderEntryData.getSecCode();
      popupBoardId = orderEntryData.getBoardId();
      this.quantity = orderEntryData.getQty();
      orderPrice = orderEntryData.getPrice();
      if (isEntry) {
         orderQty = this.quantity;
      } else {
         orderQty = orderEntryData.getBalance();
      }

      SecBoardStaticInfo info = orderEntryData.getStaticInfo();
      priceEdit.get().decimalsProperty().set(info.priceContext.getMaxDecimals());
      sizeEdit.get().decimalsProperty().set(info.qtyContext.getMaxDecimals());
      priceFormatter = info.priceFormatter;

      setPrice(orderPrice);
      if (isRenew) {
         size.setValue(orderEntryData.getDefaultQuantity());
      } else {
         size.setValue(orderQty);
      }
      if (this.popOver != null)
         this.popOver.setTitle(popupSecCode.replaceFirst("(UKT )*", ""));

      final MyOrdersArgs myOrdersArgs = new MyOrdersArgs();
      myOrdersArgs.setSecCode(popupSecCode);
      myOrdersArgs.setOrderPrice(orderPrice);
      computeFromMyOrders(myOrdersArgs);
   }

   private void computeFromMyOrders(MyOrdersArgs myOrdersArgs) {
      boolean amendOrder = false;
      Boolean isDoneIfTouched = null;
      ObservableList<ObservableReplyRow> myOrders = getMyOrders.apply(myOrdersArgs, false);
      myOrders = myOrders.filtered(row -> {
         OrderSide side = row.getValue(AmpManagedOrder.buySell) == 0 ? OrderSide.BUY : OrderSide.SELL;
         return side.equals(this.side);
      });

      if (!myOrders.isEmpty()) {
         // we expect only one managed order row, so just get the first one
         final ObservableReplyRow orderRow = myOrders.get(0);
         managedOrderToAmend = orderRow;
         final BigDecimal balance = orderRow.getProperty(AmpManagedOrder.balance).getValue();

         // TODO: change visibleAmount and minFillQty to use BigDecimal accessors
         final Double visibleAmount = orderRow.getProperty(AmpManagedOrder.visibleQuantity).getValue();
         final Double qty = orderRow.getProperty(AmpManagedOrder.quantity_d).getValue();
         final Double minFillQty = orderRow.getProperty(AmpManagedOrder.minFillQuantity).getValue();

         size.setValue(balance);
         //presetSizeButtons.updateButtonSizes(balance.doubleValue(), defaultQuantity.doubleValue());
         setPrice(myOrdersArgs.getOrderPrice());
         if (visibleAmount != null &&
            visibleAmount > 0.0) {
            icebergCheckBox.setSelected(true);
         } else {
            icebergCheckBox.setSelected(false);
         }
         aonCheckbox.setSelected(minFillQty != null && qty.doubleValue() == minFillQty.doubleValue());

         isDoneIfTouched = orderRow.getValue(AmpManagedOrder.isDoneIfTouched);
      }

      if (popOver != null) {
         if (isDoneIfTouched != null && isDoneIfTouched) {
            priceEdit.get().setDisable(true);
            Fx.runLater(() -> sizeEdit.get().requestFocus());
            amendOrder = true;
         } else {
            Fx.runLater(() -> priceEdit.get().requestFocus());
         }
         if (amendOrder) {
            popOver.setArrowLocation(PopOver.ArrowLocation.TOP_CENTER);
         } else if (this.side.equals(OrderSide.BUY)) {
            popOver.setArrowLocation(PopOver.ArrowLocation.TOP_LEFT);
         } else {
            popOver.setArrowLocation(PopOver.ArrowLocation.TOP_RIGHT);
         }

         if (!myOrders.isEmpty()) {
            if (this.side.equals(OrderSide.BUY)) {
               actionButton.setText(AMEND_BID);
            } else {
               actionButton.setText(AMEND_OFFER);
            }
         }
      }
   }

   void setDefaultFocusOn(PopupOrderEntryArgs.DefaultOn defaultOn) {
      defaultOnPrice = defaultOn == PopupOrderEntryArgs.DefaultOn.PRICE && !priceEdit.get().isDisable();
      Fx.runLater(() -> {
         if (defaultOnPrice) {
            priceEdit.get().requestFocus();
            priceEdit.get().selectAll();
         } else {
            sizeEdit.get().requestFocus();
            sizeEdit.get().selectAll();
         }
      });
   }

   void setCloseHandler(Consumer<String> closeHandler) {
      this.closeHandler = closeHandler;
   }

   private final ObjectProperty<BigDecimal> size = new SimpleObjectProperty<>(BigDecimal.ZERO);
   private final StringProperty validatedSizeProperty = new SimpleStringProperty("");
   private final Lazy<BigDecimalTextField> sizeEdit = new Lazy<BigDecimalTextField>() {
      @Override
      protected BigDecimalTextField initialize() {
         return new BigDecimalTextField(0.000001, 10000.0) {
            {
               this.valueProperty().bindBidirectional(size);
               this.verifiedTextProperty().bindBidirectional(validatedSizeProperty);
               this.setPrefWidth(85);
               this.setMaxWidth(85);
               this.setTextAlignment(TextAlignment.CENTER);
               this.setId(SIZE_FIELD_ID);
            }
         };
      }
   };
   private final ObjectProperty<BigDecimal> price = new SimpleObjectProperty<>(BigDecimal.ZERO);
   private final StringProperty validatedPriceProperty = new SimpleStringProperty("");
   private final Lazy<BigDecimalTextField> priceEdit = new Lazy<BigDecimalTextField>() {
      @Override
      protected BigDecimalTextField initialize() {
         return new BigDecimalTextField(-Double.MAX_VALUE, Double.MAX_VALUE) {
            {
               this.valueProperty().bindBidirectional(price);
               this.verifiedTextProperty().bindBidirectional(validatedPriceProperty);
               this.setPrefWidth(85);
               this.setMaxWidth(85);
               this.setTextAlignment(TextAlignment.CENTER);
               this.setId(PRICE_FIELD_ID);
            }
         };
      }
   };

}
