package xfe.icap.modules.popover;

import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.popover.PopOverManager;
import xfe.ui.popover.XfePopOver;
import xstr.util.concurrent.Future;

import java.util.HashSet;
import java.util.Set;

@Module.Autostart
public class PopOverModule extends SessionScopeModule implements PopOverManager {
   private Set<XfePopOver> popOvers = new HashSet<>();

   @Override
   public Future<Void> startModule() {
      closeAllPopOvers();
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      closeAllPopOvers();
      return Future.SUCCESS;
   }

   @Override
   public void register(XfePopOver popOver) {
      popOvers.add(popOver);
   }

   @Override
   public void unregister(XfePopOver popOver) {
      popOvers.remove(popOver);
   }

   private void closeAllPopOvers() {
      popOvers.forEach(XfePopOver::hide);
      popOvers.clear();
   }
}
