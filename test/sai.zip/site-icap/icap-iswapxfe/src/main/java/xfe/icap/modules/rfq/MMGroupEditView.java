package xfe.icap.modules.rfq;

import java.io.IOException;
import java.util.*;


import xfe.util.XfeBooleanBinding;
import xfe.ui.XfeItemTreeCell;
import javafx.beans.*;
import javafx.beans.Observable;
import javafx.collections.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.util.Callback;

import com.nomx.persist.rfq.*;
import xfe.icap.modules.prefsview.*;
import xfe.ui.SearchableTreeItem;

public class MMGroupEditView extends XfeGroupEditView<MarketMakerGroup,MarketMaker,MarketMaker> {
   final RfqModule module;

   // TODO: spit blood to remove the module
   public MMGroupEditView(RfqModule module) {
      FXMLLoader ldr = new FXMLLoader(XfeGroupEditView.class.getResource("GroupEditor.fxml"));
      this.module = module;
      ldr.setController(this);
      try {
         ldr.load();
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

//   public static XfeGroupEditView<MarketMakerGroup,MarketMaker,MarketMaker> load(RfqModule module){
//      FXMLLoader ldr = new FXMLLoader(XfeGroupEditView.class.getResource("GroupEditor.fxml"));
//      MMGroupEditView rtn = new MMGroupEditView(module);
//      ldr.setController(rtn);
//      try {
//         ldr.load();
//      } catch (IOException e) {
//         e.printStackTrace();
//      }
//      return rtn;
//   }

   protected void populate() {
      xfeGroupListView.setItems(module.getGroupForEditing());
      InvalidationListener listener = new InvalidationListener() {

         @Override
         public void invalidated(Observable observable) {
            if (module.xfeSessionModule.mmFirms.get().readyProperty.get()) {
               module.xfeSessionModule.mmFirms.get().readyProperty.removeListener(this);
               Set<String> allFirms = new TreeSet<>(module.xfeSessionModule.mmFirms.get().firms.get());
               MarketMaker rootNode = new MarketMaker("All",null);
               rootNode.setDraggable(false);
               SearchableTreeItem<MarketMaker> root = new SearchableTreeItem<>(rootNode);
               root.setExpanded(true);
               xfeItemsTreeView.setRoot(root);
               establishTreeView(root, allFirms);
               xfeGroupListView.getSelectionModel().selectFirst();
            }

         }
      };
      module.xfeSessionModule.mmFirms.get().readyProperty.addListener(listener);
      listener.invalidated(null);
   }

   @Override
   protected void applyChanges() {
      if (isModified())
         module.saveMMGroup(xfeGroupListView.getItems());
   }

   @Override
   public boolean isModified() {
      return !module.mmgroupProperty.get().equals(xfeGroupListView.getItems());
   }

   @Override
   public void save() {
      applyChanges();
   }

   private void establishTreeView(SearchableTreeItem<MarketMaker> root, Set<String> allFirms) {
      List<TreeItem<MarketMaker>> children = root.getChildren();
      for(String par:allFirms){
         SearchableTreeItem<MarketMaker> childTreeNode = new SearchableTreeItem<>(new MarketMaker(par,null));
         children.add(childTreeNode);
      }
   }

   @Override
   protected MarketMakerGroup createXfeGroup(){
      MarketMakerGroup mm = new MarketMakerGroup("New MM Group");
      mm.setShortListed(!disableBinding.get());
      return mm;
   }

   final XfeBooleanBinding disableBinding = new XfeBooleanBinding(6);
   final ListChangeListener<MarketMakerGroup> itemLisChange = change -> {
      while(change.next()){
         if(change.wasAdded()){
            List<? extends MarketMakerGroup> added = change.getAddedSubList();
            added.stream().filter(mmg -> mmg != null).forEach(mmg -> disableBinding.bindTo(mmg.getShortcutProp()));
         }else if(change.wasRemoved()){
            List<? extends MarketMakerGroup> removed = change.getRemoved();
            removed.stream().filter(mmg -> mmg != null).forEach(mmg -> disableBinding.unBindTo(mmg.getShortcutProp()));
         }
      }
   };

   private void bindAll(ObservableList<MarketMakerGroup> newList) {
      newList.stream().filter(mmg -> mmg != null).forEach(mmg -> disableBinding.bindTo(mmg.getShortcutProp()));
   }

   @Override
   protected void setCellFactory() {
      Callback<ListView<MarketMaker>, ListCell<MarketMaker>> factory =
              arg0 -> new MarketMakerListCell(selectedListView, selectedGroupId, selectedGroupProp);

      selectedListView.setCellFactory(factory);

      xfeGroupListView.itemsProperty().addListener((paramObservableValue, oldList, newList) -> {
         if(oldList!=null){
            oldList.removeListener(itemLisChange);
            disableBinding.clear();
         }
         if(newList!=null){
            bindAll(newList);
            newList.addListener(itemLisChange);
         }
      });


      Callback<ListView<MarketMakerGroup>, ListCell<MarketMakerGroup>> groupCellfactory =
              arg0 -> new XfeGroupListCell<>(xfeGroupListView, dummy, disableBinding);

      xfeGroupListView.setCellFactory(groupCellfactory);

      xfeItemsTreeView.setShowRoot(true);
      Callback<TreeView<MarketMaker>, TreeCell<MarketMaker>> treeCellFactory =
              arg0 -> new XfeItemTreeCell<>(selectedListView,xfeGroupListView);

      xfeItemsTreeView.setCellFactory(treeCellFactory);

   }

   @Override
   protected void init() {
      add.setText("Create MM Group");
      xfe_group_label.setText("Market Marker Groups");
      xfe_items_label.setText("Market Marker");
   }

   @Override
   public void dispose() {
      disableBinding.clear();
      super.dispose();
   }
}
