package xfe.icap.modules.shortlist;

import com.nomx.persist.watchlist.ColumnsSpec;
import com.nomx.persist.watchlist.ShortlistButtonSpec;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.nomx.persist.watchlist.WatchlistSpec_v2.Security;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.FlowPane;
import javafx.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpGroup;
import xfe.icap.amp.AmpGroupSecs;
import xfe.icap.modules.groupdata.GroupDataModule;
import xfe.icap.modules.groupdata.GroupSecsDataModule;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.popover.PopOverModule;
import xfe.icap.modules.sectabsui.SecTable;
import xfe.icap.modules.sectabsui.PriceCellValue;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.securities.SecurityWatchlist;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.module.Module;
import xfe.module.SiteModule;
import xfe.modules.actions.*;
import xfe.modules.session.SessionScopeModule;
import xfe.types.SecBoard;
import xfe.types.StepArray;
import xfe.util.XfeAction;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.session.WatchlistRow;
import xstr.session.XtrTransReply;
import xstr.types.OrderSide;
import xstr.util.Fx;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * UIModule for the Stock Shortlists view.
 */
@Module.Autostart
public class ShortlistButtonsViewUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(ShortlistButtonsViewUIModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;

   @ModuleDependency
   public SiteModule siteModule;

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public GroupDataModule groupDataModule;

   @ModuleDependency
   public GroupSecsDataModule groupSecsDataModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @ModuleDependency
   public PopOverModule popOverModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   private ShortlistButtonsPopupManager popupManager;
   private ObservableList<ShortlistButtonSpec> shortlistButtonsSpecs;

   @Override
   public Future<Void> startModule() {
      columnsSpecChangeListener = (observable, oldValue, newValue) -> replaceSpec(newValue);
      midiLayoutModuleSupplier = () -> midiLayoutModule;
      shortlistButtonsViewUIModuleSupplier = () -> this;
      popupManager = new ShortlistButtonsPopupManager(popOverModule);
      popupManager.setMidiLayoutModuleSupplier(midiLayoutModuleSupplier);
      popupManager.setShortListButtonsViewUIModuleSupplier(shortlistButtonsViewUIModuleSupplier);

      shortlistButtonsSpecs = configurationModule.getData().shortlistButtonsProperty().get();

      final ObservableList<QueryReplyRow> shortListButtons = this.groupDataModule.getSortedGroups();
      shortListButtonsListener = c -> refreshLayout(shortListButtons, shortlistButtonsSpecs);
      shortListButtons.addListener(shortListButtonsListener);
      changeListenerMap = new WeakHashMap<>();

      this.root = new FlowPane();
      root.setId(MidiLayoutViews.SHORTLIST_PANE);
      root.setHgap(2);
      root.setVgap(2);
      refreshLayout(shortListButtons, shortlistButtonsSpecs);
      midiLayoutModule.addView(root);
      return Future.SUCCESS;
   }

   private void updateShortListItems(String groupName, SecTable table) {
      ObservableList<QueryReplyRow> groupSecs = groupSecsDataModule.getAllGroupSecsByGroupId().get(groupName);
      addSecuritiesToShortlistButtons(table, groupName, groupSecs);
   }

   private void replaceSpec(ColumnsSpec specs) {
      int index = -1;
      int foundIndex = -1;
      for (ShortlistButtonSpec spec : shortlistButtonsSpecs) {
         ++index;
         if (spec.getButtonGroupId().equals(specs.getId())) {
            foundIndex = index;
            break;
         }
      }
      if (foundIndex >= 0) {
         shortlistButtonsSpecs.set(foundIndex, shortlistButtonsSpecs.get(foundIndex).withColumnsSpec(specs));
      }
   }

   private void refreshLayout(ObservableList<QueryReplyRow> shortListButtons, ObservableList<ShortlistButtonSpec> shortlistButtonsSpecs) {
      root.getChildren().clear();
      shortListButtons.forEach(row -> {
         final String groupName = row.getValue(AmpGroup.groupName);
         final String groupId = row.getValue(AmpGroup.groupId);
         final ShortlistButton button = new ShortlistButton(groupName);

         button.setId(groupName);
         button.setOnAction(e -> {
            if (!button.isPopOverShowing()) {
               ShortlistButtonSpec spec = getShortlistButtonSpec(shortlistButtonsSpecs, groupId);
               showShortlistInstruments((Button) e.getTarget(), groupId, spec);
            }
         });
         root.getChildren().add(button);
      });
   }

   private ShortlistButtonSpec getShortlistButtonSpec(ObservableList<ShortlistButtonSpec> shortlistButtonsSpecs, String groupId) {
      Optional<ShortlistButtonSpec> spec = shortlistButtonsSpecs.stream().filter(sbs -> sbs.getButtonGroupId().equals(groupId)).findFirst();
      if (!spec.isPresent()) {
         ShortlistButtonSpec sbSpec = new ShortlistButtonSpec(groupId);
         shortlistButtonsSpecs.add(sbSpec);
         return sbSpec;
      }
      return spec.get();
   }

   private void showShortlistInstruments(Button button, String groupId, ShortlistButtonSpec spec) {
      final SecTable table = new SecTable(spec.getColumnsSpec());
      table.columnsSpecProperty().addListener(columnsSpecChangeListener);
      table.setOneClickTrading(configurationModule.getData().tradeOneClickProperty().get());
      table.setActionFactory(this.actionFactory);
      table.setCMActionFactory(this.CM_ActionFactory);
      table.setMatchColFactory(this.matchColFactory);
      table.setTradesAggregatePopupAction(this.doTradesAggregatePopupAction);
      table.setPriceColFactory(this.priceColFactory);
      table.setTotalColFactory(this.totalColFactory);
      table.setSendDefaultOrderClbk(this.sendDefaultOrder);
      table.setTotalColDblClickAction(this.doTotalColDblClickAction);
      table.setPriceColDblClickAction(this.doPriceColDblClickAction);
      table.setDoTickUpDownPriceAmend(this.doTickUpDownPriceAmendAction);
      table.setStepArrayCallBack(this.stepArrayCallBack);
      table.setCMPriceColEntry(this.doCMPriceColEntry);
      table.setCMPriceColAmend(this.doCMPriceColAmend);
      table.setPriceColWorkupAction(this.doWorkupAction);
      table.setCMPriceColWorkupAction(this.doWorkupAction);
      table.setIsLockedClbk(this.isLocked);
      table.setZoomLevel(this.zoomLevel);
      table.setPriceCellFlashDuration(this::priceCellFlashDuration);
      ObservableList<QueryReplyRow> secList = groupSecsDataModule.getAllGroupSecsByGroupId().get(groupId);
      if (secList != null) {
         updateChangeListener(groupId, table, secList);
      }
      SecurityWatchlist currSecurityWatchlist = groupSecurityWatchListMap.get(groupId);
      if (currSecurityWatchlist == null) {
         ObservableList<QueryReplyRow> groupSecs = groupSecsDataModule.getAllGroupSecsByGroupId().get(groupId);
         if (groupSecs != null) {
            addSecuritiesToShortlistButtons(table, groupId, groupSecs);
         }
      } else {
         Fx.run(() -> table.setItems(currSecurityWatchlist.getAllItems()));
      }
      popupManager.showPopOver(button, table, configurationModule.getData().instrumentsTableZoomLevelProperty());
   }

   public void cleanTableHandlers(SecTable table) {
      table.columnsSpecProperty().removeListener(columnsSpecChangeListener);
      table.setActionFactory(null);
      table.setCMActionFactory(null);
      table.setMatchColFactory(null);
      table.setTradesAggregatePopupAction(null);
      table.setPriceColFactory(null);
      table.setTotalColFactory(null);
      table.setSendDefaultOrderClbk(null);
      table.setTotalColDblClickAction(null);
      table.setPriceColDblClickAction(null);
      table.setDoTickUpDownPriceAmend(null);
      table.setStepArrayCallBack(null);
      table.setCMPriceColEntry(null);
      table.setCMPriceColAmend(null);
      table.setPriceColWorkupAction(null);
      table.setCMPriceColWorkupAction(null);
      table.setIsLockedClbk(null);
      table.setZoomLevel(null);
      table.setPriceCellFlashDuration(null);
   }
   private void updateChangeListener(String groupId, SecTable table, ObservableList<QueryReplyRow> secList) {
      ListChangeListener listChangeListener = changeListenerMap.get(groupId);
      if (null != listChangeListener) {
         secList.removeListener(listChangeListener);
      }
      ListChangeListener<QueryReplyRow> changeListener = (ListChangeListener.Change<? extends QueryReplyRow> c) -> updateShortListItems(groupId, table);
      changeListenerMap.put(groupId, changeListener);
      secList.addListener(changeListener);
   }

   private void addSecuritiesToShortlistButtons(SecTable table, String groupId, ObservableList<QueryReplyRow> groupSecs) {
      try {
         final List<String> secCodes = groupSecs.stream().filter(row -> row.getValue(AmpGroupSecs.secCode) != null).map(row -> row.getValue(AmpGroupSecs.secCode)).collect(Collectors.toList());
         securitiesDataModule.getSecboards().getAllBySecCode(secCodes).map(sortedSecboards -> {
            sortedSecboards.sort(Comparator.comparing(SecBoard::getMaturityDateAsLong));
            final List<Security> secs = sortedSecboards.stream().map(sb -> new Security(sb.getInstrumentId(), sb.getSecCode())).collect(Collectors.toList());
            SecurityWatchlist securityWatchlist = securitiesDataModule.createWatchlist(ShortlistButtonsViewUIModule.class.getName() + "_" + groupId);
            securityWatchlist.setSpec(securityWatchlist.adjustHeadingsState(new WatchlistSpec_v2().withSecurities(secs)));
            groupSecurityWatchListMap.put(groupId, securityWatchlist);
            return Fx.run(() -> table.setItems(securityWatchlist.getAllItems()));
         });
      } catch (Exception e) {
         logger.error("Could not get secboards", e);
      }
   }

   private Integer priceCellFlashDuration() {
      // Set the price cell flash timeout.
      return configurationModule.getData().priceCellFlashDuration().getValue();
   }


   /**
    * Updates the oneClickTrading option in all the currently opened popups.
    *
    * @param oneClickTrading One click trading option to set.
    */
   public void updateOneClickTrading(boolean oneClickTrading) {
      popupManager.updateOneClickTrading(oneClickTrading);
   }

   @Override
   public Future<Void> stopModule() {
      popupManager.disposeAll();
      popupManager.setMidiLayoutModuleSupplier(null);
      popupManager.setShortListButtonsViewUIModuleSupplier(null);
      this.groupDataModule.getSortedGroups().removeListener(shortListButtonsListener);
      midiLayoutModuleSupplier = null;
      shortlistButtonsViewUIModuleSupplier = null;
      shortListButtonsListener = null;
      columnsSpecChangeListener = null;
      root.getChildren().stream().filter(node -> node instanceof Button).map(node -> (Button) node).forEach(button -> button.setOnAction(null));
      root.getChildren().clear();
      midiLayoutModule.removeView(root);
      groupSecurityWatchListMap.values().stream().forEach( securitiesDataModule::stopAndCleanWatchList);
      return Future.SUCCESS;
   }

   public void setActionFactory(BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> actionFactory) {
      this.actionFactory = actionFactory;
   }

   public void setCM_ActionFactory(BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> CM_ActionFactory) {
      this.CM_ActionFactory = CM_ActionFactory;
   }

   public void setMatchColFactory(Function<WatchlistRow, ObservableValue<PriceCellValue<BigDecimal>>> matchColFactory) {
      this.matchColFactory = matchColFactory;
   }

   public void setPriceColFactory(BiFunction<WatchlistRow, OrderSide, ObservableValue<PriceCellValue<BigDecimal>>> priceColFactory) {
      this.priceColFactory = priceColFactory;
   }

   public void setTotalColFactory(BiFunction<ObservableReplyRow, OrderSide, ObservableValue<Double>> totalColFactory) {
      this.totalColFactory = totalColFactory;
   }

   public void setDoTotalColDblClickAction(Consumer<PopupOrderEntryArgs> doTotalColDblClickAction) {
      this.doTotalColDblClickAction = doTotalColDblClickAction;
   }

   public void setDoReferAllButtonAction(Consumer<ReferArgs> doReferAllButtonAction) {
      this.doReferAllButtonAction = doReferAllButtonAction;
   }

   public void setDoHitTakeButtonAction(Consumer<PopupOrderEntryArgs> doHitTakeButtonAction) {
      this.doHitTakeButtonAction = doHitTakeButtonAction;
   }

   public void setTradesAggregatePopupAction(Consumer<TradesAggregateArgs> tradesAggregatePopupHandler) {
      this.doTradesAggregatePopupAction = tradesAggregatePopupHandler;
   }

   public void setSpreadForPriceReversal(Function<ObservableReplyRow, Boolean> isSpreadForPriceReversal) {
      this.isSpreadForPriceReversal = isSpreadForPriceReversal;
   }

   public void setDoCMPriceColEntry(Consumer<PopupOrderEntryArgs> doCMPriceColEntry) {
      this.doCMPriceColEntry = doCMPriceColEntry;
   }

   public void setDoCMPriceColAmend(Consumer<PopupOrderEntryArgs> doCMPriceColAmend) {
      this.doCMPriceColAmend = doCMPriceColAmend;
   }

   public void setDoReferAllCMButtonAction(Consumer<ReferArgs> doReferAllCMButtonAction) {
      this.doReferAllCMButtonAction = doReferAllCMButtonAction;
   }

   public void setDoSideColAction(Consumer<WorkupArgs> doSideColAction) {
      this.doSideColAction = doSideColAction;
   }

   public void setSendDefaultOrder(BiFunction<ObservableReplyRow, Pair<OrderSide, Double>, Future<XtrTransReply>> sendDefaultOrder) {
      this.sendDefaultOrder = sendDefaultOrder;
   }

   public void setIsLockedClbk(Supplier<Boolean> isLockedClbk) {
      this.isLocked = isLockedClbk;
   }

   public void setDoPriceColDblClickAction(Consumer<PopupOrderEntryArgs> doPriceColDblClickAction) {
      this.doPriceColDblClickAction = doPriceColDblClickAction;
   }

   public void setDoTickUpDownPriceAmendAction(Consumer<TickUpDownAmendArgs> doTickUpDownPriceAmendAction) {
      this.doTickUpDownPriceAmendAction = doTickUpDownPriceAmendAction;
   }

   public void setDoWorkupAction(Consumer<WorkupArgs> doWorkupAction) {
      this.doWorkupAction = doWorkupAction;
   }

   public void setScrollEventEventHandler(EventHandler<ScrollEvent> scrollEventEventHandler) {
      popupManager.setScrollEventEventHandler(scrollEventEventHandler);
   }

   public void updateZoomToTables(Integer zoomLevel) {
      popupManager.updateZoomToTables(zoomLevel);
   }

   public Supplier<Integer> getZoomLevel() {
      return zoomLevel;
   }

   public void setZoomLevel(Supplier<Integer> zoomLevel) {
      this.zoomLevel = zoomLevel;
   }

   public void setLoggedInUserId(Supplier<String> loggedInUserId) {
      this.loggedInUserId = loggedInUserId;
   }

   public BiFunction<String, String, StepArray> getStepArrayCallBack() {
      return stepArrayCallBack;
   }

   public void setStepArrayCallBack(BiFunction<String, String, StepArray> stepArrayCallBack) {
      this.stepArrayCallBack = stepArrayCallBack;
   }

   private FlowPane root;
   private BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> actionFactory;
   private BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> CM_ActionFactory;
   private Function<WatchlistRow, ObservableValue<PriceCellValue<BigDecimal>>> matchColFactory;
   private BiFunction<WatchlistRow, OrderSide, ObservableValue<PriceCellValue<BigDecimal>>> priceColFactory;
   private BiFunction<ObservableReplyRow, OrderSide, ObservableValue<Double>> totalColFactory;
   private BiFunction<ObservableReplyRow, Pair<OrderSide, Double>, Future<XtrTransReply>> sendDefaultOrder;
   private BiFunction<String, String, StepArray> stepArrayCallBack;
   private Consumer<TradesAggregateArgs> doTradesAggregatePopupAction;
   private Function<ObservableReplyRow, Boolean> isSpreadForPriceReversal;
   private Consumer<PopupOrderEntryArgs> doTotalColDblClickAction;
   private Consumer<PopupOrderEntryArgs> doPriceColDblClickAction;
   private Consumer<TickUpDownAmendArgs> doTickUpDownPriceAmendAction;
   private Consumer<ReferArgs> doReferAllButtonAction;
   private Consumer<PopupOrderEntryArgs> doHitTakeButtonAction;
   private Consumer<PopupOrderEntryArgs> doCMPriceColEntry;
   private Consumer<PopupOrderEntryArgs> doCMPriceColAmend;
   private Consumer<ReferArgs> doReferAllCMButtonAction;
   private Consumer<WorkupArgs> doSideColAction;
   private Consumer<WorkupArgs> doWorkupAction;
   private Supplier<Boolean> isLocked;
   private Supplier<Integer> zoomLevel;
   private Map<String, ListChangeListener> changeListenerMap;
   private Supplier<String> loggedInUserId;
   private ChangeListener<ColumnsSpec> columnsSpecChangeListener;

   private Map<String, SecurityWatchlist> groupSecurityWatchListMap = new HashMap<>();
   private Supplier<MidiLayoutModule> midiLayoutModuleSupplier;
   private Supplier<ShortlistButtonsViewUIModule> shortlistButtonsViewUIModuleSupplier;
   private ListChangeListener<? super QueryReplyRow> shortListButtonsListener;
}
