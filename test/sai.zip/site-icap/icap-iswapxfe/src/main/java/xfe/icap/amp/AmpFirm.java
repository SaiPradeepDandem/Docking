package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnConversionAccessor;

public class AmpFirm extends AmpAccessor {
   public static final  AmpQreq req = AMP.qREQ("firmReq");
   public static final  AmpQrep rep = AMP.qREP("firmRep");

   public static final AsnConversionAccessor<String>  firmId                     = acc(AMP.qREP("firmRep.firmId"                                         ), String.class);
   public static final AsnConversionAccessor<String>  firmName                   = acc(AMP.qREP("firmRep.statics.firmName"                               ), String.class);
   public static final AsnConversionAccessor<String>  firmShortName              = acc(AMP.qREP("firmRep.statics.firmShortName"                          ), String.class);
   public static final AsnConversionAccessor<String>  firmType                   = acc(AMP.qREP("firmRep.statics.firmType"                               ), String.class);
   public static final AsnConversionAccessor<Integer> firmClass                  = acc(AMP.qREP("firmRep.statics.firmClass"                              ), Integer.class);
   public static final AsnConversionAccessor<Long>    tier                       = acc(AMP.qREP("firmRep.statics.tier"                                   ), Long.class);
   public static final AsnConversionAccessor<String>  contactDetail              = acc(AMP.qREP("firmRep.statics.contactDetail"                          ), String.class);
   public static final AsnConversionAccessor<String>  freeText                   = acc(AMP.qREP("firmRep.statics.freeText"                               ), String.class);
   public static final AsnConversionAccessor<String>  clearingCode               = acc(AMP.qREP("firmRep.statics.clearingCode"                           ), String.class);
   public static final AsnConversionAccessor<Boolean> isVisible                  = acc(AMP.qREP("firmRep.statics.isVisible"                              ), Boolean.class);
   public static final AsnConversionAccessor<String>  clearingHouseList          = acc(AMP.qREP("firmRep.statics.clearingHouseList"                      ), String.class);
   public static final AsnConversionAccessor<String>  bankersAcceptanceCode      = acc(AMP.qREP("firmRep.statics.bankersAcceptanceCode"                  ), String.class);
   public static final AsnConversionAccessor<String>  defClearingMemberFirmId    = acc(AMP.qREP("firmRep.statics.defClearingMemberFirmTrdAccId.firmId"   ), String.class);
   public static final AsnConversionAccessor<String>  defClearingMemberTrdAccId  = acc(AMP.qREP("firmRep.statics.defClearingMemberFirmTrdAccId.trdAccId" ), String.class);
   public static final AsnConversionAccessor<Integer> firmStatus                 = acc(AMP.qREP("firmRep.dynamics.firmStatus"                            ), Integer.class);
   public static final AsnConversionAccessor<Long>    usersLoggedIn              = acc(AMP.qREP("firmRep.dynamics.usersLoggedIn"                         ), Long.class);
   public static final AsnConversionAccessor<Integer> closeOutStatus             = acc(AMP.qREP("firmRep.dynamics.closeOutStatus"                        ), Integer.class);
   public static final AsnConversionAccessor<Long>    creditEmbargoTime          = acc(AMP.qREP("firmRep.dynamics.creditEmbargoTime"                     ), Long.class);
   public static final AsnConversionAccessor<Boolean> internalMatchAllowed       = acc(AMP.qREP("firmRep.dynamics.internalMatchAllowed"                  ), Boolean.class);
   public static final AsnConversionAccessor<Long>    creditUpdateNum            = acc(AMP.qREP("firmRep.dynamics.creditUpdateNum"                       ), Long.class);
   public static final AsnConversionAccessor<Boolean> viewCreditTrdOnbehalfOn    = acc(AMP.qREP("firmRep.dynamics.viewCreditTrdOnbehalfOn"               ), Boolean.class);
   public static final AsnConversionAccessor<Boolean> viewCreditTrdOn            = acc(AMP.qREP("firmRep.dynamics.viewCreditTrdOn"                       ), Boolean.class);
   public static final AsnConversionAccessor<Double>  rfqTradeCompletionPct      = acc(AMP.qREP("firmRep.dynamics.rfqTradeCompletionPct"                 ), Double.class);
}
