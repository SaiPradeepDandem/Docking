package xfe.icap.modules.watchlist;

import java.lang.ref.WeakReference;

public abstract class VirtualReference<T> {
	private WeakReference<T> weakReference;

	public T get() {
		if (weakReference != null) {
			T strongReference = weakReference.get();

			if (strongReference != null) {
				return strongReference;
			}
		}

		T newReference = materialize();

		weakReference = new WeakReference<T>(newReference);

		return newReference;
	}

	protected abstract T materialize();
}
