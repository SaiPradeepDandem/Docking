package xfe.icap.util;

import java.util.*;
import java.util.function.Predicate;

import com.google.common.base.Strings;
import xfe.icap.amp.AmpBrokerTraderPair;
import xstr.amp.acc.AmpUser;

import javafx.collections.ListChangeListener;
import javafx.collections.ObservableSet;
import org.slf4j.*;

import javafx.beans.*;
import javafx.beans.Observable;
import javafx.beans.property.*;

import xfe.icap.types.GroupUser;
import xstr.session.QueryFeed;
import xstr.session.ServerSession;
import com.nomx.persist.linelist.Participant;
import xstr.types.User.Role;
import xstr.util.*;
import xstr.session.ObservableReplyRow;
import xstr.util.exception.AmpPermissionException;
import xstr.session.ObservableReplyRow.ObservableRowFactory;

public class Dictionary {

   private final QueryFeed feedPair;
   private final FeedAggregator<ObservableReplyRow> aggregatorPair = new FeedAggregator<>(AmpBrokerTraderPair.rep, new ObservableRowFactory());

   private final QueryFeed feedUser;
   private final FeedAggregator<ObservableReplyRow> aggregatorUser = new FeedAggregator<>(AmpUser.rep, new ObservableRowFactory());

   private final BooleanProperty readyProperty = new SimpleBooleanProperty(false);
   public final ReadOnlyBooleanProperty readyPropertyRO = readyProperty;

   private static final Logger logger = LoggerFactory.getLogger(Dictionary.class);

   /*
    * mapping trader and its firm
    */
   private final Map<String, String> userFirmMap = new HashMap<>();
   private final Map<String, String> userFullNameMap = new HashMap<>();

   /*
    * The map the data for firm->IB->trade tree in configure linelist.
    *
    * Mapping participant id to participant. Here participant is hierarchy.
    * Top level is Firm, Firm has Traders and IB. TB has Traders. Trader is leaf node.
    */
   private final Map<String, Participant> tradersMap = new HashMap<>(1000);

   /*
    * saves all the traders' ID that the logged on broker can "on behalf of".
    */
   private final HashSet<String> onBehalfOfTraders = new HashSet<>(1000);

   private final HashSet<String> usersWithMM = new HashSet<>(100);

   private final GroupUser groupUser;

   public Dictionary(ServerSession session) throws Exception {

      if (!session.hasPermission(AmpUser.req)) {
         throw new AmpPermissionException(String.format("No permission to query %s", AmpUser.req.toString())) ;
      }
      if (!session.hasPermission(AmpBrokerTraderPair.req)) {
         throw new AmpPermissionException(String.format("No permission to query %s", AmpBrokerTraderPair.req.toString())) ;
      }
      feedUser = session.getFeedSource(AmpUser.req);
      feedPair = session.getFeedSource(AmpBrokerTraderPair.req);

      InvalidationListener dataEstablishedListener = new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            if (!aggregatorUser.isBusy() && !aggregatorPair.isBusy()) {

               aggregatorUser.busyProperty().removeListener(this);
               aggregatorPair.busyProperty().removeListener(this);

               establishUserFirmMap();
               establishTraders();

               readyProperty.setValue(true);
            }
         }
      };

      aggregatorUser.busyProperty().addListener(dataEstablishedListener);
      aggregatorPair.busyProperty().addListener(dataEstablishedListener);

      feedUser.addListener(aggregatorUser);
      feedPair.addListener(aggregatorPair);
      groupUser = new GroupUser(session);

      readyProperty.addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            if (readyProperty.get()) {
               readyProperty.removeListener(this);
               tradersMap.values().stream().forEach(this::setDisplayName);
            }
         }

         private void setDisplayName(Participant participant) {
            participant.displayName = userFullNameMap.get(participant.id);
            Map<String, Participant> tradersMap = participant.getDelegatees();
            if (tradersMap != null) {
               tradersMap.values().stream().forEach(this::setDisplayName);
            }

         }
      });
   }

   public void dispose() {
      aggregatorPair.items.removeListener(brokerDeskChangeListener);
      aggregatorUser.items.removeListener(usersChangeListener);
      feedPair.removeListener(aggregatorPair);
      feedUser.removeListener(aggregatorUser);
      usersWithMM.clear();
      userFirmMap.clear();
      userFullNameMap.clear();
      tradersMap.clear();
      onBehalfOfTraders.clear();
      groupUser.dispose();
   }

   /**
    * establish the tree structure of Broker
    */
   private void establishTraders() {
      for (ObservableReplyRow row : aggregatorPair.items) {
         updateBrokerDesk(row, true);
      }

      aggregatorPair.items.addListener(brokerDeskChangeListener);
   }

   private final ListChangeListener<ObservableReplyRow> brokerDeskChangeListener = c -> {
      while (c.next()) {
         if (c.wasAdded()) {
            for (ObservableReplyRow  row: c.getAddedSubList())
               updateBrokerDesk(row, true);
         }
         if (c.wasRemoved()) {
            for(ObservableReplyRow row:c.getRemoved()){
               updateBrokerDesk(row, false);
            }
         }
      }
   };

   private void updateUserFirmsMap(ObservableReplyRow row, boolean isAdd) {
      String userId = row.getValue(AmpUser.userId);
      Boolean isMM = "MM".equalsIgnoreCase(row.getValue(AmpUser.externalUserId3));

      if (isAdd) {
         if (isMM && !usersWithMM.contains(userId))
            usersWithMM.add(userId);

         if (!isMM && usersWithMM.contains(userId))
            usersWithMM.remove(userId);

         String firmId = row.getValue(AmpUser.firmId);
         if (logger.isDebugEnabled()) {
            logger.debug("trader " + userId + " and firm " + firmId + " are added into userFirmMap");
         }
         userFirmMap.put(userId, firmId);
         userFullNameMap.put(userId, row.getValue(AmpUser.userName));
      } else {
         logger.info("trader " + userId + " is removed from userFirmMap");
         usersWithMM.remove(userId);
         userFirmMap.remove(userId);
         userFullNameMap.remove(userId);
      }
   }

   private void updateBrokerDesk(ObservableReplyRow row, boolean isAdd) {
      boolean isAuto = row.getValue(AmpBrokerTraderPair.isAuto);
      String firmId = row.getValue(AmpBrokerTraderPair.traderFirmId);
      String traderId = row.getValue(AmpBrokerTraderPair.traderId);
      String introBrokerId = row.getValue(AmpBrokerTraderPair.brokerId);
      if (isAdd) {
         Participant firm = getFirm(firmId, tradersMap);
         if (isAuto && !usersWithMM.contains(traderId)) {
            onBehalfOfTraders.add(traderId);
            if (introBrokerId == null || introBrokerId.length() == 0) {
               Participant par = firm.addTrader(traderId);
               if (par != null) {
                  par.displayName = userFullNameMap.get(traderId);
               }
            } else {
               Participant ib = firm.addIb(introBrokerId);
               if (traderId != null && !traderId.equals("")) {
                  Participant par = ib.addTrader(firmId, traderId);
                  if (par != null) {
                     par.displayName = userFullNameMap.get(traderId);
                  }
               }
            }
         } else {
            if (logger.isDebugEnabled()) {
               logger.debug("traderId " + traderId + " is not an AUTO trader or the user is set to MM. IB is " + introBrokerId);
            }
         }
      } else {
         onBehalfOfTraders.remove(traderId);
      }
   }

   public boolean isInSameDesk(String userId, String groupId) {
      return !(userId == null || groupId == null) && groupUser.isUserInGroup(userId, groupId);
   }

   public ObservableSet<String> getGroup(){
      return groupUser.getLoggedOnUserGroups();
   }

   /**
    * the request brokerTraderPairReq returns not the full set of traders and their firms.
    */
   private void establishUserFirmMap() {
      userFirmMap.clear();
      logger.debug("Adding {} users to userFirmMap", aggregatorUser.items.size());
      for (ObservableReplyRow row : aggregatorUser.items) {
         updateUserFirmsMap(row, true);
      }

      aggregatorUser.items.addListener(usersChangeListener);
   }

   private final ListChangeListener<ObservableReplyRow> usersChangeListener = change -> {
      while (change.next()) {
         if (change.wasAdded()) {
            logger.debug("USER ADD EVENT: Adding {} users to userFirmMap", change.getAddedSubList().size());
            for (ObservableReplyRow  row: change.getAddedSubList()) {
               updateUserFirmsMap(row, true);
            }
         }
         if (change.wasRemoved()) {
            logger.info("USER REMOVE EVENT: Removing {} users from userFirmMap", change.getRemoved().size());
            for (ObservableReplyRow row: change.getRemoved()) {
               updateUserFirmsMap(row, false);
            }
         }
      }
   };

   public String getFirmId(String traderId) {
      if (traderId == null) {
         return null;
      }
      String firmId =  userFirmMap.get(traderId);
      if (logger.isTraceEnabled()) {
         logger.trace("get firmId " + firmId + " from userFirmMap for traderId " + traderId);
      }
      return firmId;
   }

   public Map<String, Participant> getFirms() {
      return tradersMap;
   }

   private Participant getFirm(String firmId, Map<String, Participant> firmsMap) {
      Participant firm = firmsMap.get(firmId);
      if (firm == null) {
         firm = new Participant(null, firmId, Role.FIRM);
         firmsMap.put(firmId, firm);
      }
      return firm;
   }

   public boolean isTraderCanOnBehalfof(String traderId) {
      return onBehalfOfTraders.contains(traderId);
   }

   public boolean isTraderCanOnBehalfof(String traderId, String ibId) {
      if(Strings.isNullOrEmpty(ibId)) {
         return tradersMap.values().stream().anyMatch(firm -> firm.getDelegatees().values().stream().anyMatch(new Predicate<Participant>() {
            @Override
            public boolean test(Participant participant) {
               return Objects.equals(participant.id, traderId);
            }
         }));
      }else{
         return tradersMap.values().stream().anyMatch(firm -> firm.getDelegatees().values().stream().anyMatch(new Predicate<Participant>() {
            @Override
            public boolean test(Participant ib) {
               return Objects.equals(ib.id,ibId) && ib.getDelegatees().values().stream().anyMatch(participant -> Objects.equals(participant.id,traderId));
            }
         }));
      }
   }

   public String getUserFullName(String id) {
      String fullName = userFullNameMap.get(id);
      return Strings.isNullOrEmpty(fullName) ? id : fullName;
   }
}
