package xfe.icap.modules.iswaptrades;

import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import xstr.amp.AsnWrapper;
import xfe.icap.amp.AmpTrade;
import xstr.session.ObservableReplyRow;
import com.objsys.asn1j.runtime.Asn1Type;

public class TradesComparator  implements Comparator<ObservableReplyRow> {

	private static final int MAX_SPREAD_DEPTH = 2;
	TradesFeedAdapter tradesAdapter;
	public TradesComparator(TradesFeedAdapter tradesAdapter) {
		this.tradesAdapter = tradesAdapter;
	}

	@Override
	public int compare(ObservableReplyRow trade1, ObservableReplyRow trade2) {

		// We first reverse it by time
		Date trade1Time = trade1.getValue(AmpTrade.time);
		Date trade2Time = trade2.getValue(AmpTrade.time);

		int dateCompare = trade2Time.compareTo(trade1Time);

		if (dateCompare != 0) return dateCompare;

		// If the date is the same we compare based on parents

		AsnWrapper<Asn1Type> trade1Id = new AsnWrapper<>(trade1.getAsn(AmpTrade.tradeId));
		AsnWrapper<Asn1Type> trade2Id = new AsnWrapper<>(trade2.getAsn(AmpTrade.tradeId));

		if (trade1Id.equals(trade2Id)) return 0;

		List<AsnWrapper<Asn1Type>> t1ParentsList = new LinkedList<>();
		List<AsnWrapper<Asn1Type>> t2ParentsList = new LinkedList<>();
		int search1Depth  = GetDeepestParents(trade1Id, t1ParentsList, MAX_SPREAD_DEPTH);
		int search2Depth  = GetDeepestParents(trade2Id, t2ParentsList, MAX_SPREAD_DEPTH);

		// First we handle cases were the two trades either have no common parent or else do have one,
		// but are at exactly the same level relative to it - in this case we determine the order by the first varying parent
		// ids starting from top ancestor (or their own ids if they have no parents)

		for (int i = 0; i <= Math.min(search1Depth, search2Depth); ++i) {
			 if (i > 0) {
				 GetDeepestParents(trade1Id, t1ParentsList, search1Depth - i);
				 GetDeepestParents(trade2Id, t2ParentsList, search2Depth - i);
			 }

			 if (hasCommon(t1ParentsList, t2ParentsList)) continue;

			 AsnWrapper<Asn1Type> parentTrade1Id = t1ParentsList.get(0);// Collections.min(t1ParentsList);
			 AsnWrapper<Asn1Type> parentTrade2Id = t2ParentsList.get(0); //Collections.min(t2ParentsList);

			 return parentTrade2Id.compareTo(parentTrade1Id);
		}

		return search1Depth - search2Depth;
	}

	private int GetDeepestParents(AsnWrapper<Asn1Type> tradeId,
                                 List<AsnWrapper<Asn1Type>> parentsList,
                                 int maxSpreadDepth) {
		// This method returns the deepest list of parents for tradeId up to maxSpreadDepth
		// So if the total depth of the tree starting from tradeId is 5, but maxSpreadDepth is 3, the level 3
		// the level 3 ancestors will be returned.
		// if the total depth is 2 (i.e. less than maxSpreadDepth) then the level 2 ancestors
		// will be returned.

		int searchDepth = maxSpreadDepth;
		parentsList.clear();
		parentsList.addAll(tradesAdapter.getNLevelParentIds(tradeId, searchDepth));

		while (parentsList.isEmpty()) {
			 parentsList.addAll(tradesAdapter.getNLevelParentIds(tradeId, --searchDepth));

			 if (searchDepth == 0) break;
		}

		return searchDepth;
	}

	private boolean hasCommon(List<AsnWrapper<Asn1Type>> t1ParentsList,
							  List<AsnWrapper<Asn1Type>> t2ParentsList) {
		Set<AsnWrapper<Asn1Type>> t1ParentsSet = new HashSet<>(t1ParentsList);
		Set<AsnWrapper<Asn1Type>> t2ParentsSet = new HashSet<>(t2ParentsList);

		t1ParentsSet.retainAll(t2ParentsSet);

		return !t1ParentsSet.isEmpty();
	}
}
