package xfe.icap.modules.rfq;

import com.nomx.persist.PersistantName;
import com.nomx.persist.rfq.MarketMakerGroup;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import com.omxgroup.xstream.amp.AmpPriceIndicator;
import javafx.beans.property.ObjectProperty;
import javafx.collections.*;
import javafx.scene.Node;
import javafx.scene.control.ToggleButton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.util.Constants;
import xfe.util.Pair;
import xstr.amp.AMP;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpRfq;
import xfe.icap.amp.AmpRfqTrade;
import xstr.session.*;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.OrderTrans;
import xfe.types.SecBoard;
import xstr.util.*;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;
import xfe.modules.history.HistoricalEvent;
import xfe.modules.history.HistoryModule;
import xfe.modules.history.HistoryModule.MsgType;
import xfe.icap.XfeSession;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.layout.LayoutManager;
import xfe.module.Module;
import xfe.icap.modules.prefsview.PrefsViewsModule;
import xfe.icap.modules.obbo.ObboModule;
import xfe.modules.orderentry.Command;
import xfe.modules.orderentry.Command.ActionType;
import xfe.icap.modules.orderentry.EntryModule;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.watchlist.WatchlistModule;
import xfe.ui.InitialisableView;
import xfe.ui.PrefsViewFactory;
import xfe.ui.notifications.ModalAlertModule;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static xfe.icap.modules.iswaporders.OrderStatusDecorator.PRIVATE_ORDER;

@Module.Autostart
public class RfqModule extends SessionScopeModule implements Constants {
   private static final Logger logger = LoggerFactory.getLogger(RfqModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public LayoutManager<Node> layoutManagerModule;
   @ModuleDependency
   public ModalAlertModule notifierModule;
   @ModuleDependency
   public PrefsViewsModule prefsViewsModule;
   @ModuleDependency
   public WatchlistModule watchlistModule;
   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public DataContextModule dataContextModule;
   @ModuleDependency
   public EntryModule entryModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public HistoryModule historyModule;
   @ModuleDependency
   public ObboModule obboModule;

   static boolean isRfsSession(QueryReplyRow aRfq) {
      Double maxQ = aRfq.getValue(AmpRfq.maxQuantity);
      return maxQ == null || maxQ == 0D;
   }

   private static boolean isRfsInstrument(String secCode) {
      return secCode.startsWith(RFS_SEC_CODE_PREFIX1) ||
         secCode.startsWith(RFS_SEC_CODE_PREFIX2);
   }

   ObservableList<MarketMakerGroup> getGroupForEditing() {
      LinkedList<MarketMakerGroup> temp = new LinkedList<>();
      if (mmgroupProperty != null)
         temp.addAll(mmgroupProperty.get().stream().map(MarketMakerGroup::copy).collect(Collectors.toList()));
      return FXCollections.observableList(temp);
   }

   @Override
   public Future<Void> startModule() {
      logonTimpStamp = xfeSessionModule.getUnderlyingSession().getStats().getEngineTime();
      mmgroupProperty = configurationModule.getParametersStorage().getList(PersistantName.mmGroup, MarketMakerGroup.class, null);

      tracker.disposes(new RfqNotification(xfeSessionModule,
         configurationModule,
         layoutManagerModule,
         watchlistModule::selectedRfq,
         watchlistModule::setTabFlash,
         watchlistModule::stopTabFlash));

      setRfqTradesSource();

      prefsViewsModule.addView(mmRfqPrefsViewFactory, mmGrpDummyBtn);
      configurationModule.setMMOpenAction(event -> mmGrpDummyBtn.setSelected(true));
      tracker.addListener(xfeSessionModule.orders.get().rfqExpiredOrders, rfqExpiredOrderListChangeListener);
      allLiveRfqSecBoard.clear();
      monitorLiveRfq();

      tracker.addListener(dataContextModule.rfqAllowedVerb, observable -> {
         entryModule.orderEntryPane.get().isMineDisabled.set(dataContextModule.rfqAllowedVerb.get()==AmpOrderVerb.sell);
      });

      if (xfeSessionModule.getUnderlyingSession().getStats().isRfsSessionAllowed) {
         Command mineCommand = createRfsCommand();
         Command yoursCommand = createRfsCommand();
         entryModule.registerActionHandler(ActionType.MINE, mineCommand);
         entryModule.registerActionHandler(ActionType.YOURS, yoursCommand);
//         tracker.registerRollbackAction(() -> entryModule.deregisterActionHandler(Command.ActionType.MINE, mineCommand));
//         tracker.registerRollbackAction(() -> entryModule.deregisterActionHandler(Command.ActionType.YOURS, yoursCommand));
      }
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      aggregatorMap.clear();
      allLiveRfqSecBoard.clear();
      prefsViewsModule.removeView(mmRfqPrefsViewFactory);
      tracker.rollback();
      selectionContextModule.isLoggedUserMarketMaker.setValue(false);
      return Future.SUCCESS;
   }

   void saveMMGroup(ObservableList<MarketMakerGroup> items) {
      List<MarketMakerGroup> targetList = new ArrayList<>(items.size());
      targetList.addAll(items.stream().map(MarketMakerGroup::copy).collect(Collectors.toList()));
      mmgroupProperty.get().setAll(targetList);
   }

   private void setRfqTradesSource() {
      QueryFeed rfqTradesFeed = xfeSessionModule.getUnderlyingSession().queries.getFeedSource(AmpRfqTrade.req);
      tracker.addFeedListener(rfqTradesFeed, feedEvents -> {
         for (QueryRowEvent event : feedEvents) {
            if (event.getEventType() == XtrQueryReplyCommand.CREATE) {
               QueryReplyRow newRow = event.getNewRow();
               // Get initiator's side and cover price
               Long rfqTradeId = newRow.getValue(AmpRfqTrade.rfqNo);
               String initiatorSide = getBuySellString(newRow.getValue(AmpRfqTrade.initiatorOrderVerb));
               String coverPriceStr = "";
               Double coverPrice = newRow.getValue(AmpRfqTrade.coverPrice);
               if (coverPrice != null)
                  coverPriceStr = String.format(" Cover price %f.", coverPrice);
               String priceIndicator = getPriceIndicatorString(newRow.getValue(AmpRfqTrade.priceIndicator));
               String secCode = "";
               String initiator = "";
               String tradeTimeStr = "";
               Date tradeTime = newRow.getValue(AmpRfqTrade.tradeTime);
               if (tradeTime != null)
                  tradeTimeStr = new SimpleDateFormat("HH:mm:ss").format(tradeTime);

               boolean rfqFound = false;
               String rfsInfo = "";
               for (ObservableReplyRow rfqRow : xfeSessionModule.rfqs.get().endedRfqs.get()) {
                  if (Objects.equals(rfqRow.getValue(AmpRfq.rfqNo), rfqTradeId)) {
                     secCode = rfqRow.getValue(AmpRfq.parentSecCode);
                     initiator = rfqRow.getValue(AmpRfq.userId);
                     rfqFound = true;
                     break;
                  }
               }

               if (rfqFound) {
                  rfsInfo = String.format("RFQ (%s): %s %s at %s. You were %s.%s",
                     secCode, initiator, initiatorSide, tradeTimeStr, priceIndicator, coverPriceStr);
                  historyModule.addEvent(new HistoricalEvent(
                     MsgType.INFO,
                     rfsInfo,
                     xfeSessionModule.getUnderlyingSession().getStats().getEngineTime()));
               }

            }
         }
      });
   }

   private String getPriceIndicatorString(int value) {
      switch (value) {
         case AmpPriceIndicator.cover:
            return "cover";
         case AmpPriceIndicator.doneaway:
            return "done away";
         case AmpPriceIndicator.tied:
            return "tied";
         case AmpPriceIndicator.tiedcover:
            return "tied cover";
         case AmpPriceIndicator.hitlift:
            return "hit/lift";
         default:
            return "";
      }
   }

   private String getBuySellString(int value) {
      switch (value) {
         case AmpOrderVerb.buy:
            return "payed";
         case AmpOrderVerb.sell:
            return "received";
         default:
            return "payed/received";
      }
   }

   private void submitUnmatchedOrder(List<QueryReplyRow> rfqOrders, String instrumentCode, String boardId, boolean rfsSession) {
      logger.trace("unmatched orders: {}", rfqOrders);
      for (QueryReplyRow expiredOrder : rfqOrders) {
         AbstractOrderTrans orderTrans;
         if (configurationModule.getData().managedOrdersProperty().get()) {
            orderTrans = new ManagedOrderTrans(notifierModule);
         } else {
            orderTrans = new OrderTrans(notifierModule);
         }
         orderTrans.setSecCode(instrumentCode);
         orderTrans.setBoardId(boardId);
         try {

            orderTrans.setPrice(expiredOrder.getValue(AmpManagedOrder.price_d));
            orderTrans.setQuantity(expiredOrder.getValue(AmpManagedOrder.balance_d));
            orderTrans.setDefaultDurationType(expiredOrder.getValue(AmpManagedOrder.durationType));
            orderTrans.setDuration(expiredOrder.getValue(AmpManagedOrder.durationTime));
            if (rfsSession) {
               orderTrans.setDoneIfTouched(true);
               orderTrans.setPublic(false);
            } else {
               if (isRfsInstrument(instrumentCode)) {
                  orderTrans.setDoneIfTouched(true);
               } else {
                  Boolean dit = expiredOrder.getValue(AmpManagedOrder.isDoneIfTouched);
                  orderTrans.setDoneIfTouched(dit == null ? false : dit);
               }
            }

            orderTrans.setAnonymous(expiredOrder.getValue(AmpManagedOrder.isPublic));
            orderTrans.setUnderRef(expiredOrder.getValue(AmpManagedOrder.orderStatus) == PRIVATE_ORDER);

//            orderTrans.setMinFill(anRfq.getMinFillQuantity());
            orderTrans.setMinFill(expiredOrder.getValue(AmpManagedOrder.minFillQuantity));
            orderTrans.setAllowMultiMinFill(expiredOrder.getValue(AmpManagedOrder.allowMultiMinFill));
            orderTrans.setVisibleQty(expiredOrder.getValue(AmpManagedOrder.visibleQuantity));
            orderTrans.setOnLogOffAction(expiredOrder.getValue(AmpManagedOrder.actionOnLogoff));
            orderTrans.setShared(expiredOrder.getValue(AmpManagedOrder.shared));
            logger.info("executing unmatched {}, code {}, board {},buy/sell order: {}", rfsSession ? "rfs session" : "rfq", instrumentCode, boardId, orderTrans);
            orderTrans.executeBuySell(xfeSessionModule.getUnderlyingSession(), expiredOrder.getValue(AmpManagedOrder.buySell));
         } catch (Exception e) {
            if (notifierModule != null)
               notifierModule.showError("Sending trades to TE failed due to exception " + e);
         }
      }
   }

   private void dealWithUnmatchedOrder(Tuple2<String, String> key, List<QueryReplyRow> expiredOrderRows) {
      if(selectionContextModule.isLoggedUserMarketMaker.get()){
         logger.debug("market maker ignores remaining balance of RFQ orders");
         return;
      }
      int size = expiredOrderRows.size();
      logger.trace("dealing with unmatched RFQ order. {} size {}",key,size);
      Date orderEnterTime = expiredOrderRows.get(0).getValue(AmpManagedOrder.entryTime);
      Optional<Tuple3<String,String,Boolean>> rfsSessionParentKey = xfeSessionModule.rfqs.get().searchRfq(key.a,key.b,orderEnterTime);
      if(rfsSessionParentKey.isPresent()) {
         Tuple3<String,String,Boolean> parentCodeKey = rfsSessionParentKey.get();
         if (parentCodeKey.c) {
            submitUnmatchedOrder(expiredOrderRows, parentCodeKey.a, parentCodeKey.b, true);
         } else {
            double quantities[] = new double[size];
            String prices[] = new String[size];
            int side[] = new int[size];
            int index = 0;
            for (QueryReplyRow expiredOrder : expiredOrderRows) {
               side[index] = expiredOrder.getValue(AmpManagedOrder.buySell);
               quantities[index] = expiredOrder.getValue(AmpManagedOrder.balance_d);
               prices[index] = df.format(expiredOrder.getValue(AmpManagedOrder.price_d));
               index++;
            }
            RfqTradeRemainingStage popupStage = new RfqTradeRemainingStage(key.b, key.a, side,quantities, prices, layoutManagerModule);
            tracker.addListener(xfeSessionModule.loggedOnProperty(), observable -> {
               if(!xfeSessionModule.loggedOnProperty().get()){
                  popupStage.close();
               }
            });
            popupStage.getSubmitProperty().addListener((observable -> {
               submitUnmatchedOrder(expiredOrderRows, parentCodeKey.a, parentCodeKey.b, false);
            }));
            popupStage.show();
            popupStage.toFront();
         }
      } else{
         logger.trace("can't find rfq for ({},{}),order entry time: {}",key.a,key.b,orderEnterTime);
      }
   }

   private void monitorLiveRfq() {

      tracker.addListener(xfeSessionModule.rfqs.get().activeRfqs.get(), new ListChangeListener<ObservableReplyRow>() {
         @Override
         public void onChanged(Change<? extends ObservableReplyRow> c) {
            while (c.next()) {
               if (c.wasAdded()) {
                  List<? extends ObservableReplyRow> added = c.getAddedSubList();
                  for (ObservableReplyRow row : added) {
                     String secCode = row.getString(AmpRfq.secCode);
                     String boardId = row.getString(AmpRfq.boardId);
                     Long rfqNo = row.getValue(AmpRfq.rfqNo);
                     try {
                        xfeSessionModule.secBoards.get().getSecBoard(secCode, boardId).map(new Fun1<SecBoard, Void>() {
                           @Override
                           public Void call(SecBoard secBoard) {
                              SecBoard secBoard1 = secBoard.withParentBoardId(row.getString(AmpRfq.parentBoardId)).withParentSecCode(row.getString(AmpRfq.parentSecCode));
                              if (isRfsSession(row)) {
                                 secBoard1.setRfsSession();
                              }
                              allLiveRfqSecBoard.put(Pair.create(secCode, rfqNo), secBoard1);
                              return null;
                           }
                        });
                     } catch (Exception e) {
                        logger.error("can't get SecBoard for rfs session: {}",secCode);
                     }
                  }
               }
               else if (c.wasRemoved()) {
                  for (ObservableReplyRow row : c.getRemoved()) {
                     String secCode = row.getString(AmpRfq.secCode);
                     Long rfqNo = row.getValue(AmpRfq.rfqNo);
                     logger.trace("removing rfq {}:{}", secCode, rfqNo);
                     allLiveRfqSecBoard.remove(Pair.create(secCode, rfqNo));
                  }
               } else {
                  logger.trace("rfq change {}: ", c);
               }
            }
         }
      });

      watchlistModule.getActiveSpec().addListener(observable -> {
         for (Entry<Pair<String, Long>, SecBoard> entry: allLiveRfqSecBoard.entrySet()) {
            SecBoard rfqSecboard = entry.getValue();
            Long rfqNo = entry.getKey().getValue();
            logger.trace("tabs switched - removing and adding rfq");
            rfqRemove(rfqNo, rfqSecboard);
            if (isSecCodeInActiveSpec(rfqSecboard)) {
               rfqAdd(rfqNo, rfqSecboard);
            }
         }
      });

      tracker.addListener(allLiveRfqSecBoard, new MapChangeListener<Pair<String, Long>, SecBoard>() {
         @Override
         public void onChanged(Change<? extends Pair<String, Long>, ? extends SecBoard> change) {
            if (change.wasAdded()) {
               SecBoard rfqSecboard = change.getValueAdded();
               if (isSecCodeInActiveSpec(rfqSecboard)) {
                  rfqAdd(change.getKey().getValue(), rfqSecboard);
               }
            } if (change.wasRemoved()) {
               rfqRemove(change.getKey().getValue(), change.getValueRemoved());
            }
         }
      });
   }

   private void rfqRemove(Long rfqNo, SecBoard rfqSecboard) {
      logger.trace("rfqRemove called for {}:{}", rfqSecboard, rfqNo);
      Pair<SecBoard, Long> key = Pair.create(rfqSecboard, rfqNo);
      if (aggregatorMap.containsKey(key)) {
         removeAggregator(key);

         for (Pair<ObservableReplyRow, Long> rfq: InstrumentRfqPairList) {
            if (Objects.equals(rfq.getValue(), rfqNo)) {
               InstrumentRfqPairList.remove(rfq);
               watchlistModule.getExtraWatchlist().remove(rfq.getKey());
               break;
            }
         }
         Fx.runLater(() -> {
            logger.trace("removing RFS sec board {} from ExtraSecBoardList {}",
               rfqSecboard, watchlistModule.getExtraSecBoardList());
            watchlistModule.getExtraSecBoardList().remove(rfqSecboard);
         });
      }
   }

   private void rfqAdd(Long rfqNo, SecBoard rfqSecboard) {
      logger.trace("rfqAdd is called for {}:{}", rfqSecboard, rfqNo);
      createQuery(rfqSecboard, rfqNo);
      logger.trace("rfq {} is added into active RFQ index list", rfqSecboard);

      logger.trace("adding RFS sec board {} to ExtraSecBoardList {}",
         rfqSecboard, watchlistModule.getExtraSecBoardList());
      watchlistModule.getExtraSecBoardList().add(rfqSecboard);
   }

   private void removeAggregator(Pair<SecBoard, Long> key) {
      Pair<FeedAggregator<ObservableReplyRow>, QueryFeed> value = aggregatorMap.remove(key);
      if (value.getValue() != null)
         value.getValue().removeListener(value.getKey());
   }

   private void createQuery(SecBoard secBoard, Long rfqNo) {
      FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpIcapSecBoardTrim2.rep, new ObservableRowFactory());
      logger.debug("createQuery - adding change listener to aggregator");
      aggregator.items.addListener(aggregatorItemChanged);
      Pair<SecBoard, Long> key = Pair.create(secBoard, rfqNo);
      if (aggregatorMap.containsKey(key)) {
         removeAggregator(key);
      }

      Long[] indices = {
         key.getKey().getIndex()
      };

      try {
         XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req, xfeSessionModule.getUnderlyingSession())
            .set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), indices)
            .build();
         QueryFeed feedSrc = xfeSessionModule.getUnderlyingSession().queries.getFeedSource(req);
         feedSrc.addListener(aggregator);
         aggregatorMap.put(key, Pair.create(aggregator, feedSrc));
      } catch (AsnTypeException | AmpPermissionException e) {
         e.printStackTrace();
      }
   }

   private boolean isSecCodeInActiveSpec(SecBoard secCode) {
      String parentCode = secCode.getOriginalSecCode();
      WatchlistSpec_v2 spec = watchlistModule.getActiveSpec().get();
      if (spec != null) {
         if (spec.getUnmodifiableSecCodes().contains(parentCode)) {
            return true;
         } else {
            // for bespoken instrument, like A-EUR 060410 090414 4Y
            // original sec code "A-EUR 4Y" need to be considered.
            Pattern bespokenSec = Pattern.compile("( \\d{6}){1,2}");
            Matcher matcher = bespokenSec.matcher(parentCode);
            String result = matcher.replaceAll("");
            if (spec.getUnmodifiableSecCodes().contains(result)) {
               secCode.setParentCode(result);
               return true;
            }
            return false;
         }
      }
      return false;
   }

   private Command createRfsCommand() {
      return isArmed -> {
         logger.error("Executing command. ");

         if (!isArmed && selectionContextModule.dataContextRfsSec.get()) {
            return entryModule.rfqPresenter.get().onSubmit(true);
         }
         return Future.valueOf(false);
      };
   }
   private final ToggleButton mmGrpDummyBtn = new ToggleButton() {{
      this.setVisible(false);
   }};
   private final PrefsViewFactory mmRfqPrefsViewFactory = new PrefsViewFactory() {

      @Override
      public InitialisableView create() {
         MMGroupEditView view = new MMGroupEditView(RfqModule.this);
         view.initialise();
         return view;
      }

      @Override
      public String getViewName() {
         return "MM Group";
      }

      @Override
      public int getLeftPriority() {
         return 30;
      }
   };
   private final ObservableList<Pair<ObservableReplyRow, Long>> InstrumentRfqPairList = FXCollections.observableList(new ArrayList<>(20));
   private final ListenerTracker tracker = new ListenerTracker();
   private final ObservableMap<Pair<String, Long>, SecBoard> allLiveRfqSecBoard = FXCollections.observableMap(new HashMap<>(50)); // contains all secboard for active RFQ
   private final ObservableMap<Pair<SecBoard, Long>, Pair<FeedAggregator<ObservableReplyRow>, QueryFeed>> aggregatorMap = FXCollections.observableMap(new HashMap<>(20));
   private final DecimalFormat df = new DecimalFormat("#.#####");
   private final Map<Tuple2<String,String>,List<QueryReplyRow>> ordersKeyBySecCode = new HashMap<>();
   private final ListChangeListener<ObservableReplyRow> aggregatorItemChanged = new ListChangeListener<ObservableReplyRow>() {
      @Override
      public void onChanged(Change<? extends ObservableReplyRow> c) {
         while (c.next()) {
            if (c.wasAdded()) {
               aggregatorMap.entrySet().stream().filter(entry -> entry.getValue().getKey().items == c.getList()).forEach(entry -> {
                  for (ObservableReplyRow row : c.getAddedSubList()) {
                     InstrumentRfqPairList.add(Pair.create(row, entry.getKey().getValue()));
                     watchlistModule.getExtraWatchlist().add(row);
                  }
               });
            }
         }
      }
   };
   ObjectProperty<ObservableList<MarketMakerGroup>> mmgroupProperty;
   private Runnable onCloseHandler;
   private Date logonTimpStamp;
   private final ListChangeListener<ObservableReplyRow> rfqExpiredOrderListChangeListener = new ListChangeListener<ObservableReplyRow>() {
      @Override
      public void onChanged(Change<? extends ObservableReplyRow> c) {
         if (c.next()){
            if (c.wasAdded()){
               for (QueryReplyRow row:c.getAddedSubList()) {
                  Date enterTime = row.getValue(AmpManagedOrder.entryTime);
                  if(enterTime.after(logonTimpStamp)){ //This is a simple implementation. All orders entered before logon are ignored.
                     Tuple2 key = new Tuple2(row.getValue(AmpManagedOrder.secCode), row.getValue(AmpManagedOrder.boardId));
                     List<QueryReplyRow> orders = ordersKeyBySecCode.get(key);
                     if (orders == null) {
                        orders = new ArrayList<>(10);
                        ordersKeyBySecCode.put(key, orders);
                     }
                     orders.add(row);
                     logger.trace("unmatched orders for rfq:\n{}",ordersKeyBySecCode);
                  }else{
                     logger.trace("order event is ignored due to it entered before logon: {}", row);
                  }
               }
            }
         }
         Fx.delay(2000L, () -> {
            if(xfeSessionModule.loggedOnProperty().get()) {
               for (Tuple2<String, String> key : ordersKeyBySecCode.keySet()) {
                  dealWithUnmatchedOrder(key, ordersKeyBySecCode.remove(key));
               }
            }
         });

      }
   };

}
