package xfe.icap.modules.orderentry;

import com.nomx.domain.types.DefaultDurationType;
import com.omxgroup.syssrv.Duration;
import com.omxgroup.xstream.amp.AmpOrderDuration;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import com.omxgroup.xstream.amp.AmpSecClassId;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.*;
import javafx.beans.property.*;
import javafx.beans.value.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.util.Callback;
import javafx.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpOrderBookByOrder;
import xfe.icap.amp.AmpRfq;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.iswaporders.OrderFilters;
import xfe.icap.modules.obbo.ObboModule;
import xfe.icap.modules.selectioncontext.SelectedRowCellContext;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.icap.modules.settings.SettingsData;
import xfe.icap.modules.settings.SettingsUIModule;
import xfe.icap.types.*;
import xfe.modules.orderentry.Command;
import xfe.modules.orderentry.Command.ActionType;
import xfe.modules.session.SessionModule;
import xfe.types.OrderType;
import xfe.types.Security;
import xfe.types.SecurityInfo;
import xfe.types.StepArray;
import xfe.ui.CommandButton;
import xfe.ui.GenericView;
import xfe.ui.KeyboardNavigationModule;
import xfe.ui.Nodes;
import xfe.ui.logon.UnlockView;
import xfe.ui.notifications.ModalAlertModule;
import xfe.util.Constants;
import xfe.util.DualAction;
import xfe.util.HandlerCompositeUtils;
import xfe.util.scene.control.*;
import xfe.util.scene.layout.FxmlPane;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnField;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.session.XtrTransReply;
import xstr.session.XtrTransReply.Status;
import xstr.types.OrderRelation;
import xstr.types.OrderSide;
import xstr.types.User;
import xstr.util.*;
import xstr.util.concurrent.*;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.io.IOException;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import static javafx.beans.binding.Bindings.isNull;
import static javafx.beans.binding.Bindings.or;
import static xfe.util.Constants.BID_LIT_ACTION_STYLE;
import static xfe.util.Constants.OFFER_LIT_ACTION_STYLE;
import static xstr.util.Fx.numeric;
import static xstr.util.Util.getDoubleEditVal;

public class OrderEntryPane extends DisposableBase implements FxmlPane, GenericView<Node> {
   private static final Logger logger = LoggerFactory.getLogger(OrderEntryPane.class);

   private static final String SWEEP_CUE_STYLECLASS = "xfe-rate-sweep-cue";
   private static final Object SPIN_CHANGE = new Object();

   public class ManagedOrderEntryPresenter extends DisposableBase {
      ManagedOrderEntryPresenter(
         ListenerTracker tracker,
         EntryModule entryModule,
         SessionModule sessionModule,
         SettingsUIModule settings, ModalAlertModule notifier,
         DataContextModule dataContextModule,
         SelectionContextModule selectionContextModule, KeyboardNavigationModule keyboardNavigation) {
         this.settings = settings;
         this.entryModule = entryModule;
         this.obbo = entryModule.obboModule;
         this.notifier = notifier;
         this.dataContextModule = dataContextModule;
         this.selectionContextModule = selectionContextModule;
         this.keyboardNavigation = keyboardNavigation;
         bidCommand = new BestPriceCheck(notifier, selectionContextModule,true);
         offerCommand = new BestPriceCheck(notifier, selectionContextModule,false);
//         isAon = new BooleanBinding() {
//            {
//               //bind(configurationModule.prefs.rfqInitiatorOrderAon(), selectionContextModule.dataContextRfqSec, selectionContextModule.isLoggedUserMarketMaker);
//               bind(selectionContextModule.dataContextRfqSec, selectionContextModule.isLoggedUserMarketMaker);
//            }
//
//            @Override
//            protected boolean computeValue() {
//               boolean rtn;
//               rtn = selectionContextModule.dataContextRfqSec.get() &&
//                  !selectionContextModule.isLoggedUserMarketMaker.get();
//               logger.debug("isAon is set to {}", rtn);
//               return rtn;
//            }
//         };

         unlockViewVisible = sessionModule.lockedProperty().and(sessionModule.safeModeProperty().not());

         this.mineRateBinding = new ObjectBinding<Double>() {
            {
               bind(
                  o_nPriceProperty, o_nQtyProperty,
                  getSecBoardContext().bestOfferProperty(),
                  settings.prefs.yoursMineDefaultAmount(), settings.prefs.strategyDefaultQty(),
                  getSecBoardContext().defaultQtyProperty(), offerIsIndicative,
                  obboOfferPriceProperty, isInSweepProperty(),
                  sweepRateQtyProperty());
            }

            @Override
            protected Double computeValue() {
//               Fx.validateAll(getDependencies());

               boolean inSweep = isInSweepProperty().get();
               SweepRateQty srq = sweepRateQtyProperty().get();
               boolean hasSweepValues = (srq != null);

               // Sweep mode
               if (inSweep && hasSweepValues) {
                  if (srq.getIsSweepBuy() != null && srq.getIsSweepBuy().getValue() != null && srq.getIsSweepBuy().getValue()) {
                     return null;
                  }
                  return sweepRateQtyProperty().getValue().getWavgRate().getValue();
               }

               // Normal mode
               if (!(inSweep || hasSweepValues)) {

                  Double obboRate = obboOfferPriceProperty.getValue();

                  // Market Depth line was not selected
                  if (obboRate == null) {
                     // We do not have a valid value for the rate
                     Double bestOffer = getSecBoardContext().bestOfferProperty().getValue();
                     Double o_nPrice = o_nPriceProperty.getValue();
                     Boolean isOfferIndicative = offerIsIndicative.getValue();

                     if (o_nPrice == null && (bestOffer == null || isOfferIndicative)) {
                        return null;
                     }

                     if (bestOffer == null || isOfferIndicative || o_nPrice != null && o_nPrice < bestOffer) {
                        obboRate = o_nPrice;
                     }

                     if (o_nPrice == null || bestOffer != null && !isOfferIndicative && o_nPrice >= bestOffer) {
                        obboRate = bestOffer;
                     }
                  } else {
                     // Market Depth handling:
                     if (isBestOfferIndicativeProperty == null && isBestOfferIndicativeProperty.get()) {
                        return null;
                     }
                  }

                  return obboRate;
               }

               return null;
            }
         };

         tracker.addListener(sessionModule.safeModeProperty(), (observable, oldValue, newValue) ->
            enableOrderEntry(!newValue));
         tracker.addListener(size, observable -> {
            if (/*isAon.get() && */getOrderType() == OrderType.MIN_FILL.ordinal()) {
               setMinFillAon();
            }
         });

         this.mineQuantityBinding = new ObjectBinding<Double>() {
            {
               bind(
                  sizeTextProperty(),
                  selectionContextProperty(),
                  offerDataChanged,
                  isInSweepProperty(),
                  userEditModeProperty()
               );
            }

            @Override
            protected Double computeValue() {
               boolean currEditMode = getUserEditMode();
               boolean intoEditMode = !prevEditMode && currEditMode;
               if (prevEditMode != currEditMode) prevEditMode = currEditMode;

               SelectionContext currContext = selectionContextProperty().getValue();
               offerDataChanged.getValue();
               boolean currInSweep = isInSweepProperty().get();

               if (currInSweep) // a bit hard to stay in user edit mode while in sweep mode
                  setUserEditMode(false);

               String currSecCode = (getSecBoardContext() == null ? null : getSecBoardContext().getSecCode());

               String currQtyText = sizeTextProperty().getValue();
               Double offerCurrQuantity = null;
               try {
                  offerCurrQuantity = currQtyText.isEmpty() ?
                     null :
                     NumberFormat.getInstance().parse(currQtyText).doubleValue();
               } catch (ParseException e) {
                  e.printStackTrace();
               }

               Double size = null;
               if (currContext != null && currContext.equals(offerPrevContext) &&
                  !offerDataChangedProperty.getValue() || currInSweep) { // No selection or data change or in sweep mode
                  if (Objects.equals(offerPrevQuantity, offerCurrQuantity) && !intoEditMode) { // No change at all
                     size = minePrevQuantity;
                  } else { // Size edit value was changed manually or via sweep
                     if (getUserEditMode() || prevInSweep || currInSweep) {
                        offerPrevQuantity = offerCurrQuantity;
                        minePrevQuantity = offerCurrQuantity;
                     }
                     size = minePrevQuantity;
                  }
               } else { // Selection or data change (sweep should be handled via edit box size changes)

                  // Calculate size for button value for selection/data change

                  // Default value from settings depending on security type
                  Double settingsDefaultSize = getSecBoardContext().getDefaultQty();

                  // We stay in user edit mode iff the same row in the watchlist was re-selected (e.g. via a different cell)
                  if (currContext == null || offerPrevContext == null ||
                     !Objects.equals(currSecCode, prevSecCode) ||
                     currContext.grid != GridType.Watchlist ||
                     offerPrevContext.grid != GridType.Watchlist) {
                     setUserEditMode(false);
                  }

                  // First we handle RFQs, either taking them from default settings or else from size edit box
                  if (entryModule.xfeSessionModule.rfsPickup.get()) {
                     size = settings.prefs.yoursMineDefaultAmount().get() ?
                        settingsDefaultSize :
                        offerCurrQuantity;
                  } else if (getUserEditMode()) {
                     size = minePrevQuantity;
                  } else if (!offerDataChangedProperty.getValue() ||
                     !getUserEditMode() ||
                     prevInSweep
                     ) {
                     // Handling selection and data changes (data changes only handled if not in user edit mode)
                     boolean isOfferIndicative = false;
                     Double obboOfferSize = null;

                     if (currContext != null) { // A Valid selection context
                        ObservableReplyRow row = currContext.row; // Getting selected row

                        if (row != null) { // Valid selected row - initialise top of book indicative-ness
                           if (currContext.grid == GridType.Watchlist) {
                              isOfferIndicative = Constants.PRICE_TYPE_INDICATIVE.equals(row.getProperty(AmpIcapSecBoardTrim2.offerSpecialOrderType).get());
                           } else if (currContext.grid == GridType.OBBO_SELL) {
                              isOfferIndicative = Constants.PRICE_TYPE_INDICATIVE.equals(row.getProperty(AmpOrderBookByOrder.specialOrderType).get());
                              obboOfferSize = row.getValue(AmpOrderBookByOrder.quantity);
                           }
                        }

                        if (obboOfferSize != null && !isOfferIndicative) { // OBBO, not indicative
                           size = (settings.prefs.yoursMineDefaultAmount().get() ? settingsDefaultSize : obboOfferSize);
                        } else { // Not OBBO
                           Double bestOffer = (row == null ? null : row.getValue(AmpIcapSecBoardTrim2.offerPrice_d));
                           Double o_nPrice = (row == null ? null : row.getValue(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d));

                           if (bestOffer != null && !isOfferIndicative || o_nPrice != null) {
                              if (!settings.prefs.yoursMineDefaultAmount().get()) {
                                 if (bestOffer == null || isOfferIndicative || o_nPrice != null && o_nPrice < bestOffer) {
                                    size = row.getValue(AmpIcapSecBoardTrim2.nLevelImpOfferQuantity);
                                 }
                                 if (o_nPrice == null || bestOffer != null && !isOfferIndicative && o_nPrice >= bestOffer) {
                                    size = row.getValue(AmpIcapSecBoardTrim2.offerDepth_d);
                                 }
                              } else {
                                 size = settingsDefaultSize;
                              }
                           }
                        }
                     }
                  }

                  offerPrevQuantity = offerCurrQuantity;
                  offerPrevContext = currContext;
               }

               minePrevQuantity = size;
               prevSecCode = (getSecBoardContext() == null ? null : getSecBoardContext().getSecCode());
               offerDataChangedProperty.setValue(false);
               if (!Objects.equals(size, minePrevQuantity) && !currInSweep && prevInSweep)
                  prevInSweep = false;
               return minePrevQuantity;
            }
         };

         this.yoursRateBinding = new ObjectBinding<Double>() {
            {
               bind(
                  b_nPriceProperty, b_nQtyProperty,
                  getSecBoardContext().bestBidProperty(),
                  settings.prefs.yoursMineDefaultAmount(), settings.prefs.strategyDefaultQty(),
                  getSecBoardContext().defaultQtyProperty(),
                  bidIsIndicative, obboBidPriceProperty,
                  isInSweepProperty(),
                  sweepRateQtyProperty()
               );
            }

            @Override
            protected Double computeValue() {
//               Fx.validateAll(getDependencies());

               boolean inSweep = isInSweepProperty().get();
               SweepRateQty srq = sweepRateQtyProperty().get();
               boolean hasSweepValues = (srq != null);
               // Sweep mode
               if (inSweep && hasSweepValues) {
                  if (srq.getIsSweepBuy() != null && srq.getIsSweepBuy().getValue() != null && !srq.getIsSweepBuy().getValue()) {
                     return null;
                  }

                  return sweepRateQtyProperty().getValue().getWavgRate().getValue();
               }

               // Normal mode
               if (!(inSweep || hasSweepValues)) {

                  Double obboRate = obboBidPriceProperty.getValue();
                  // Market Depth line was not selected
                  if (obboRate == null) {
                     // We do not have a valid value for the rate
                     Double bestBid = getSecBoardContext().bestBidProperty().getValue();
                     Double b_nPrice = b_nPriceProperty.getValue();
                     Boolean isBidIndicative = bidIsIndicative.getValue();

                     if (b_nPrice == null && (bestBid == null || isBidIndicative)) {
                        return null;
                     }

                     if (bestBid == null || isBidIndicative || b_nPrice != null && b_nPrice > bestBid) {
                        obboRate = b_nPrice;
                     }

                     if (b_nPrice == null || bestBid != null && !isBidIndicative && b_nPrice <= bestBid) {
                        obboRate = bestBid;
                     }
                  } else { // Market Depth handling:
                     if (isBestBidIndicativeProperty == null || isBestBidIndicativeProperty.get()) {
                        return null;
                     }
                  }

                  return obboRate;
               }

               return null;
            }
         };

         this.yoursQuantityBinding = new ObjectBinding<Double>() {
            {
               bind(
                  sizeTextProperty(),
                  selectionContextProperty(),
                  bidDataChanged,
                  isInSweepProperty(),
                  userEditModeProperty()
               );
            }

            @Override
            protected Double computeValue() {
               boolean currEditMode = getUserEditMode();
               boolean intoEditMode = !prevEditMode && currEditMode;
               if (prevEditMode != currEditMode) prevEditMode = currEditMode;

               SelectionContext currContext = selectionContextProperty().getValue();
               bidDataChanged.getValue();
               boolean currInSweep = isInSweepProperty().get();

               if (currInSweep) // a bit hard to stay in user edit mode while in sweep mode
                  setUserEditMode(false);

               String currSecCode = (getSecBoardContext() == null ? null : getSecBoardContext().getSecCode());

               String currQtyText = sizeTextProperty().getValue();
               Double bidCurrQuantity = null;
               try {
                  bidCurrQuantity = currQtyText.isEmpty() ?
                     null :
                     NumberFormat.getInstance().parse(currQtyText).doubleValue();
               } catch (ParseException e) {
                  e.printStackTrace();
               }

               Double size = null;
               if (currContext != null && currContext.equals(bidPrevContext) &&
                  !bidDataChangedProperty.getValue() || currInSweep) { // No selection or data change or in sweep mode
                  if (Objects.equals(bidPrevQuantity, bidCurrQuantity) && !intoEditMode) { // No change at all
                     size = yoursPrevQuantity;
                  } else { // Size edit value was changed manually or via sweep
                     if (getUserEditMode() || prevInSweep || currInSweep) {
                        bidPrevQuantity = bidCurrQuantity;
                        yoursPrevQuantity = bidCurrQuantity;
                     }
                     size = yoursPrevQuantity;
                  }
               } else { // Selection or data change (sweep should be handles via edit box size changes)

                  // Calculate size for button value for selection/data change

                  // Default value from settings depending on security type
                  Double settingsDefaultSize = getSecBoardContext().getDefaultQty();

                  // We stay in user edit mode iff the same row in the watchlist was re-selected (e.g. via a different cell)
                  if (currContext == null || bidPrevContext == null ||
                     !Objects.equals(currSecCode, prevSecCode) ||
                     currContext.grid != GridType.Watchlist ||
                     bidPrevContext.grid != GridType.Watchlist) {
                     setUserEditMode(false);
                  }

                  // First we handle RFQs, either taking them from default settings or else from size edit box
                  if (entryModule.xfeSessionModule.rfsPickup.get()) {
                     size = settings.prefs.yoursMineDefaultAmount().get() ?
                        settingsDefaultSize :
                        bidCurrQuantity;
                  } else if (getUserEditMode()) {
                     size = yoursPrevQuantity;
                  } else if (!bidDataChangedProperty.getValue() ||
                     !getUserEditMode() ||
                     prevInSweep
                     ) {
                     // Handling selection and data changes (data changes only handled if not in user edit mode)
                     boolean isBidIndicative = false;
                     Double obboBidSize = null;

                     if (currContext != null) { // A Valid selection context
                        ObservableReplyRow row = currContext.row; // Getting selected row

                        if (row != null) { // Valid selected row - initialise top of book indicative-ness
                           if (currContext.grid == GridType.Watchlist) {
                              isBidIndicative = Constants.PRICE_TYPE_INDICATIVE.equals(row.getProperty(AmpIcapSecBoardTrim2.bidSpecialOrderType).get());
                           } else if (currContext.grid == GridType.OBBO_BUY) {
                              isBidIndicative = Constants.PRICE_TYPE_INDICATIVE.equals(row.getProperty(AmpOrderBookByOrder.specialOrderType).get());
                              obboBidSize = row.getValue(AmpOrderBookByOrder.quantity);
                           }
                        }

                        if (obboBidSize != null && !isBidIndicative) { // OBBO, not indicative
                           size = (settings.prefs.yoursMineDefaultAmount().get() ? settingsDefaultSize : obboBidSize);
                        } else { // Not OBBO
                           Double bestBid = (row == null ? null : row.getValue(AmpIcapSecBoardTrim2.bidPrice_d));
                           Double b_nPrice = (row == null ? null : row.getValue(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d));

                           if (bestBid != null && !isBidIndicative || b_nPrice != null) {
                              if (!settings.prefs.yoursMineDefaultAmount().get()) {
                                 if (bestBid == null || isBidIndicative || b_nPrice != null && b_nPrice > bestBid) {
                                    size = row.getValue(AmpIcapSecBoardTrim2.nLevelImpBidQuantity);
                                 }
                                 if (b_nPrice == null || bestBid != null && !isBidIndicative && b_nPrice <= bestBid) {
                                    size = row.getValue(AmpIcapSecBoardTrim2.bidDepth_d);
                                 }
                              } else {
                                 size = settingsDefaultSize;
                              }
                           }
                        }
                     }
                  }

                  bidPrevQuantity = bidCurrQuantity;
                  bidPrevContext = currContext;
               }

               yoursPrevQuantity = size;
               prevSecCode = (getSecBoardContext() == null ? null : getSecBoardContext().getSecCode());
               bidDataChangedProperty.setValue(false);
               if (!Objects.equals(size, yoursPrevQuantity) && !currInSweep && prevInSweep)
                  prevInSweep = false;
               return yoursPrevQuantity;
            }
         };

         // Create a dummy transaction to make sure all the required classes are loaded now
         // This is done in an attempt to prevent delays related to class loading when the
         // user submits the first order transaction
         AbstractOrderTrans dummyTrans  = new OrderTrans(notifier);
         dummyTrans.setDoneIfTouched(true);

         getSecBoardContext().defaultStrategyQtyProperty().bind(settings.prefs.strategyDefaultQty());
         getSecBoardContext().defaultOutrightQtyProperty().bind(settings.prefs.outrightDefaultQty());
         getSecBoardContext().marketSizePorperty().bind(settings.prefs.isMarketSize());

         bidIsIndicative.bind(getSecBoardContext().bidIsIndicativeProperty());
         offerIsIndicative.bind(getSecBoardContext().offerIsIndicativeProperty());
         b_nPriceProperty.bind(getSecBoardContext().b_nPriceProperty());
         o_nPriceProperty.bind(getSecBoardContext().o_nPriceProperty());
         b_nQtyProperty.bind(getSecBoardContext().b_nQtyProperty());
         o_nQtyProperty.bind(getSecBoardContext().o_nQtyProperty());
         bidSizeProperty.bind(getSecBoardContext().bidSizeProperty());
         offerSizeProperty.bind(getSecBoardContext().offerSizeProperty());
         bestBidProperty.bind(getSecBoardContext().bestBidProperty());
         bestOfferProperty.bind(getSecBoardContext().bestOfferProperty());
         priceStepArrayProperty.bind(getSecBoardContext().spinPriceStepsProperty());
         quantityStepArrayProperty.bind(getSecBoardContext().spinQtyStepsProperty());
      }

      private SecBoardContext getSecBoardContext() {
         return entryModule.selectionContextModule.secBoardContext.get();
      }

      private void setMinFillAon() {
         setMinFill(size.getValue()+"");
      }

      public ObjectProperty<SelectionContext> selectionContextProperty() {
         return selectionContextProperty;
      }

      public StepArray getPriceStepArray() {
         return priceStepArrayProperty().get();
      }

      public void setPriceStepArray(StepArray priceStepArray) {
         priceStepArrayProperty().set(priceStepArray);
      }

      private ObjectProperty<StepArray> priceStepArrayProperty() {
         return priceStepArrayProperty;
      }

      public StepArray getQuantityStepArray() {
         return quantityStepArrayProperty().get();
      }

      public void setQuantityStepArray(StepArray quantityStepArray) {
         quantityStepArrayProperty().set(quantityStepArray);
      }

      private ObjectProperty<StepArray> quantityStepArrayProperty() {
         return quantityStepArrayProperty;
      }

      public SecurityInfo getSecurityInfo() {
         return securityInfoProperty().get();
      }

      private ObjectProperty<SecurityInfo> securityInfoProperty() {
         return securityInfoProperty;
      }

      OrderRelation getContextOrderSide() {
         SelectionContext ctx = selectionContextProperty.get();
         if(ctx == null)
            return OrderRelation.NONE;

         switch (ctx.grid) {
            case OBBO_BUY:
               return OrderRelation.BUY;
            case OBBO_SELL:
               return OrderRelation.SELL;
            case Watchlist:
               if (AmpIcapSecBoardTrim2.isBidRelated(ctx.field))
                  return OrderRelation.BUY;
               if (AmpIcapSecBoardTrim2.isOfferRelated(ctx.field))
                  return OrderRelation.SELL;
               break;
            case Rfq:
               break;
            case Orders:
               Integer side = ctx.row.getValue(AmpManagedOrder.buySell);
               if (side == AmpOrderVerb.buy)
                  return OrderRelation.BUY;
               if (side == AmpOrderVerb.sell)
                  return OrderRelation.SELL;
               break;
         }
         return OrderRelation.NONE;
      }

      public ObservableValue<Double> getPaneRateProperty() {
         return rate;
      }

      public ObservableValue<Double> getPaneSizeProperty() {
         return size;
      }

      public ActionType getActionType() {
         return actionType;
      }

      private void setDoneIfTouchedDisable(boolean isDisable) {
         ditDisable.set(isDisable);
      }

      public void setSession(XfeSession session) {
         this.session = session;
      }

      private void setSecurityData(Security security) throws AsnTypeException {

         // We need to find whether this security code supports done if touched order
         setDoneIfTouchedDisable(!security.isDoneIfTouchedSupported());

         if (settings.prefs.defaultDurationType().get() == DefaultDurationType.GOOD_TILL_DURATION) {
            setGTD(true);
            setDuration(Duration.of(settings.prefs.defaultDuration().get(), TimeUnit.MINUTES));
         } else {
            setGTD(false);
         }

         setSelectedOrderSide(null);

      }

      public void setDuration(Duration duration) {
         long hours = duration.in(TimeUnit.HOURS) % 24;
         long minutes = duration.in(TimeUnit.MINUTES) % 60;
         long seconds = duration.in(TimeUnit.SECONDS) % 60;
         durationTextProperty().set(String.format("%02d:%02d:%02d", hours, minutes,seconds));
      }

      private void setMinFillAon(Double minFill) {
         if (minFill == 0) {
            setMinFill("");
         } else {
            setMinFill(minFill.toString().replaceAll("\\.", Strings.regexDecimalSeparator()));
         }
      }

      private void setViewIceberg(Double iceberg) {
         if (iceberg == 0) {
            setIceberg("");
         } else {
            setIceberg(iceberg.toString().replaceAll("\\.", Strings.regexDecimalSeparator()));
         }
      }

      private void setDefaultOrderData(boolean isSetImmediate) {
         setPrice(null);
         setDefaultValues(isSetImmediate);
      }

      private void setOrderData(ManagedOrder order) {
         if (order != null) {
            setPrice(order.getPrice());
            setOrderTypeInView(OrderType.REGULAR);

            if (order.getBalance() != null) {
               setSize(order.getBalance());
               if (order.getMinFillQuantity() != null) {
                  if (order.getQuantity().equals(order.getMinFillQuantity()) && order.isImmediate())
                     setOrderTypeInView(OrderType.FILL_OR_KILL);
                  else if (order.getAllowMultiMinFill() != null && order.getAllowMultiMinFill())
                     setOrderTypeInView(OrderType.MIN_FILL);
                  else
                     setOrderTypeInView(OrderType.MIN_CLIP);

                  setMinFillAon(order.getMinFillQuantity());
               }
               else setMinFillAon(0.0);
            }

            setDoneIfTouched(order.isDoneIfTouched());
            setAnon(!order.isPublic(), true);
            setUnderRef(order.isPrivate());
            setCloneToTS(order.isCloneToTS());

            // We need to find whether this security code supports done if touched order
            if (order.getVisibleQuantity() != null) {
               setOrderTypeInView(OrderType.ICEBERG);
               setViewIceberg(order.getVisibleQuantity());
            } else {
               setViewIceberg(0.0);
            }

            setImmediate(order.isImmediate());

            durationProperty().set(settings.prefs.defaultDuration().get());

            if (order.getDurationType() == AmpOrderDuration.goodTillDuration) {
               setGTD(true);

               if (order.getDuration() != null) {
                  setDuration(order.getDuration());
               }
            } else {
               setGTD(false);
            }

            setSelectedOrderSide(order.isBid() ? OrderSide.BUY : OrderSide.SELL);
         }
      }

      private void setDefaultValues(boolean isSetImmediate) {
         setOrderTypeInView(OrderType.REGULAR);
         setAnon(settings.prefs.anon().get(), true);
         setUnderRef(false);
         setCloneToTS(settings.prefs.clone2RFS().get());
         durationDisabledProperty().set(false);
         setMinFillDisable(true);
         setIcebergDisable(true);
         setMinFillAon(0.0);
         setViewIceberg(0.0);
         if (isSetImmediate)
            setImmediate(false);
      }

      public ObservableBooleanValue unlockViewVisibleProperty() {
         return unlockViewVisible;
      }

      public void onBid(boolean isArmed) {
         logger.info("BID button pressed: lit {}", isArmed);
         // Disarm the other buttons
         offerAction.get().disarm();
         mineAction.get().disarm();
         yoursAction.get().disarm();

         actionType = ActionType.BID;
         keyboardNavigation.moveContextViewFocus(getView());
         for(Command command:bidActionHandlerLilst){
            Future<Boolean> handled = command.execute(isArmed);
            if (!handled.isDone()) {
               commandInProgress.set(true);
               handled.addListener(h -> commandInProgress.set(false));
               return;
            }
         }

         actionType = ActionType.BID;
         if (!isArmed)
            return;

         if(settings.getData().orderConfirmProperty().get()){
            Double orderPrice = getDoubleEditVal(rateTextProperty().get());
            bidCommand.execute(orderPrice).onSuccess(new Fun1<Boolean,Void>() {
               @Override
               public Void call(Boolean confirmed) {
                  if(confirmed){
                     doBid();
                  }
                  return null;
               }
            });
         } else {
            doBid();
         }
      }

      public OrderEntryPane getView(){
         return view;
      }

      private void doBid() {
         if (isRegularOrderProperty.get()) {
            doAmend(amendableOrderRowProperty.get());
         } else {
            AbstractOrderTrans orderTrans = isManaged() ? new ManagedOrderTrans(notifier) : new OrderTrans(notifier);
            populateTransactionData(orderTrans);
            logger.debug("****Executing BUY****");
            orderTrans.executeBuySell(session.getUnderlyingSession(),AmpOrderVerb.buy);
         }
      }

      private void doAmend(ObservableReplyRow row) {
         ArrayList<AsnField<?>> amendFields = new ArrayList<>();
         amendFields.add(AsnField.create(AmpManagedOrder.price_d, getDoubleEditVal(rateTextProperty().get())));
         amendFields.add(AsnField.create(AmpManagedOrder.quantity_d, getDoubleEditVal(getSizeText())));

         if (immediateProperty().getValue()) {
            amendFields.add(AsnField.create(AmpManagedOrder.durationType, AmpOrderDuration.immediate));
         } else if (isGTD()) {
            amendFields.add(AsnField.create(AmpManagedOrder.durationType, AmpOrderDuration.goodTillDuration));
            amendFields.add(AsnField.create(AmpManagedOrder.durationTime, Duration.of(durationProperty().get(), TimeUnit.SECONDS)));
         } else {
            // Do Nothing, so that current order duration will stay the same
            // we only allow amending properties that are changeable through the Order Entry panel.
         }

         amendFields.add(AsnField.create(AmpManagedOrder.minFillQuantity, getDoubleEditVal(getMinFill())));
         amendFields.add(AsnField.create(AmpManagedOrder.visibleQuantity, getDoubleEditVal(getIceberg())));
         amendFields.add(AsnField.create(AmpManagedOrder.cloneIntoRFS, clone2TSProperty().get()));

         // Not allowing amendment of action on logoff property as it is not changeable via the Order Entry panel

         try {
            Orders.amend(session,
               notifier,
               row,
               amendFields,
               e -> {
                  try {
                     XtrTransReply reply = e.call();
                     if (reply.getStatus() != Status.RESULT_OK) {
                        String hint = reply.getHint().toLowerCase();

                        if (!hint.isEmpty()) {
                           if (hint.startsWith("price")) {
                              setFocusOnPrice();
                           } else if (hint.startsWith("quantity")) {
                              setFocusOnQty();
                           }
                        }
                     }
                  } catch (Exception e1) {
                     notifier.showError(e1.getMessage());
                  }
               });
         } catch (AmpPermissionException | AsnTypeException e) {
            notifier.showError(e.getMessage());
         }
      }

      private void populateTransactionData(AbstractOrderTrans orderTrans) {
         boolean isDIT = !selectionContextModule.dataContextRfsSessionSec.get() && isDoneIfTouched(); //for rfs session, DIT has to be false;
         SecBoardContext context = getSecBoardContext();
         boolean isToParent = (actionType== ActionType.BID || actionType== ActionType.OFFER ) && isDIT  && selectionContextModule.dataContextRfsSessionSec.get();

         orderTrans.setCloneIntoRFS(clone2TSProperty().get());
         orderTrans.setSecCode(isToParent ? context.getParentSecCode() : context.getSecCode());
         orderTrans.setBoardId(isToParent ? context.getParentBoardId() : context.getBoardId());
         orderTrans.setOrderType(OrderType.values()[getOrderType()]);

         orderTrans.setVwap(isInSweepProperty().get());
         orderTrans.setPrice(getDoubleEditVal(rateTextProperty().get()));
         orderTrans.setQuantity(getDoubleEditVal(getSizeText()));
         orderTrans.setDoneIfTouched(isDIT);
         orderTrans.setAnonymous(isAnonymous());
         orderTrans.setUnderRef(isUnderRef());
         if (immediateProperty().getValue()) {
            orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
         } else if (isGTD()) {
            orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DURATION);
            orderTrans.setDuration(Duration.of(durationProperty().get(), TimeUnit.SECONDS));
         } else {
            DefaultDurationType durationType = settings.prefs.defaultDurationType().get();
            if (durationType == DefaultDurationType.GOOD_TILL_DURATION)
               orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DAY);
            else
               orderTrans.setDefaultDurationType(durationType);
         }
         orderTrans.setMinFill(getDoubleEditVal(getMinFill()));
         orderTrans.setAllowMultiMinFill(getAllowMultiMinFill());
         orderTrans.setVisibleQty(getDoubleEditVal(getIceberg()));
         orderTrans.setOnLogOffAction(settings.prefs.onLogoffAction().get());
         orderTrans.setShared(settings.prefs.shared().get());
      }

      public void onOrderType(Integer selectedItem) {
         setOrderType(selectedItem);
         setMinFill("");
         setMinFillDisable(true);
         setIcebergDisable(true);
         durationDisabledProperty().set(false);

         switch (OrderType.values()[selectedItem]) {
            case FILL_OR_KILL:
               enableAdvBtn(false);
               advSelectedProperty.set(true);
               setMinFill(getSizeText());
               setMinFillDisable(true);
               durationDisabledProperty().set(true);
               break;
            case ICEBERG:
               enableAdvBtn(false);
               advSelectedProperty.set(true);
               setIcebergDisable(false);
               break;
            case MIN_FILL:
               enableAdvBtn(false);
               advSelectedProperty.set(true);
               setMinFillDisable(false);
               break;
            case MIN_CLIP:
               enableAdvBtn(false);
               advSelectedProperty.set(true);
               setMinFillDisable(false);
               break;
            case REGULAR:
               enableAdvBtn(true);
               break;
            default:
               break;
         }
      }

      private void setMinFillDisable(boolean isDisable) {
         minFillDisabledProperty().set(isDisable);
      }

      private void setIcebergDisable(boolean isDisable) {
         if (isDisable) setViewIceberg(0.0);
         icebergDisable.set(isDisable);
      }

      public void setSweep() {
         view.setSweep();
      }

      public void resetSweep() {
         view.resetSweep();
      }

      public void cedeSweepValues() {
         view.cedeSweepValues();
      }

      public void applySweepValues(Double wavgRate, Double totalQty, Boolean isSweepBuy) {
         view.applySweepValues(wavgRate, totalQty, isSweepBuy);
      }

      public void registerActionHandler(ActionType actionType, Command command){
         LinkedList<Command> targetList;
         switch (actionType){
            case BID:
               targetList = bidActionHandlerLilst;
               break;
            case MINE:
               targetList = mineActionHandlerLilst;
               break;
            case OFFER:
               targetList = offerActionHandlerLilst;
               break;
            case YOURS:
               targetList = yoursActionHandlerLilst;
               break;
            default:
               targetList = null;
         }
         targetList.add(command);
      }

      public void deregisterActionHandler(ActionType actionType, Command command){
         LinkedList<Command> targetList;
         switch (actionType){
            case BID:
               targetList = bidActionHandlerLilst;
               break;
            case MINE:
               targetList = mineActionHandlerLilst;
               break;
            case OFFER:
               targetList = offerActionHandlerLilst;
               break;
            case YOURS:
               targetList = yoursActionHandlerLilst;
               break;
            default:
               targetList = null;
         }
         targetList.remove(command);
      }

      void bindToView() {
         getRootElement();
         bestBidProperty().bind(getSecBoardContext().bestBidProperty());
         bestOfferProperty().bind(getSecBoardContext().bestOfferProperty());
         isManagedProperty().bind(settings.prefs.managed());
         setAnon(settings.prefs.anon().get(), true);
         ObservableList<OrderType> nonSweepOrderTypes = FXCollections.observableArrayList(OrderType.values());
         ObservableList<OrderType> shownOrderTypes = Fx.dynamicFilterByF(nonSweepOrderTypes, new Fun1<OrderType, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(OrderType orderType) {
               if (orderType == OrderType.ICEBERG) {
                  return isInSweepProperty().not();
               }

               return Fx.valueOf(true);
            }
         });
         populateOrderTypes(shownOrderTypes);

         bindLitState();

         disposer.disposes(Fx.addWeakListener(immediateProperty(), (observableValue, oldValue, newValue) -> {
            if (newValue) {
               setGTD(false);
            }
         }));

         disposer.disposes(Fx.addWeakListener(minFillDisabledProperty(), (observableValue, oldValue, newValue) -> {
            if (!newValue)
               setFocusOnMinFillEdit();
         }));

         disposer.disposes(Fx.addWeakListener(icebergDisabledProperty(), (observableValue, oldValue, newValue) -> {
            if (!newValue)
               setFocusOnIcebergEdit();
         }));

         // Adding a listener to change in Size
         disposer.disposes(Fx.addWeakListener(sizeTextProperty(), observable -> {
            if (getOrderType().equals(OrderType.FILL_OR_KILL.ordinal())) {
               setMinFill(getSizeText());
            }
         }));

         // Adding a listener to change in GTD
         disposer.disposes(Fx.addWeakListener(GTDProperty(), (observableValue, oldValue, newValue) -> {
            enableGTD(newValue);

            if (newValue) {
               immediateProperty().setValue(false);
            }
         }));


         StringExpression orderEntryRateMineQtyBinding = Bindings.format(
            Constants.litButtonDescriptionFormat, rateTextProperty(), sizeTextProperty());

         StringExpression orderEntryRateYoursQtyBinding = Bindings.format(
            Constants.litButtonDescriptionFormat, rateTextProperty(), sizeTextProperty());

         StringExpression mineFormatted = Bindings.format(
            Constants.litButtonDescriptionFormat,
            Fx.asDecimalString(rateDecimalsProperty(), mineRateBinding),
            Fx.asDecimalString(sizeDecimalsProperty(), mineQuantityBinding));

         BooleanBinding mineRateQtyIsNull = Bindings.equal((javafx.util.Pair<?, ?>) null, mineRateBinding);
         StringBinding mineOtherwise1 = Bindings.when(mineRateQtyIsNull).then((String) null).otherwise(mineFormatted);
         StringBinding mineOtherwise2 = Bindings.when(mineLitProperty()).then(orderEntryRateMineQtyBinding).otherwise(mineOtherwise1);

         disposer.disposes(Fx.bind(mineLitDescriptionProperty(), mineOtherwise2));

         StringExpression yoursFormatted = Bindings.format(
            Constants.litButtonDescriptionFormat,
            Fx.asDecimalString(rateDecimalsProperty(), yoursRateBinding),
            Fx.asDecimalString(sizeDecimalsProperty(), yoursQuantityBinding));

         BooleanBinding yoursRateQtyIsNull = Bindings.equal((Pair<?, ?>) null, yoursRateBinding);
         StringBinding yoursOtherwise1 = Bindings.when(yoursRateQtyIsNull).then((String) null).otherwise(yoursFormatted);
         StringBinding yoursOtherwise2 = Bindings.when(yoursLitProperty()).then(orderEntryRateYoursQtyBinding).otherwise(yoursOtherwise1);

         disposer.disposes(Fx.bind(yoursLitDescriptionProperty(), yoursOtherwise2));

         disposer.disposes(Fx.addWeakListener(getSecBoardContext().rowProperty(), (obsVal, oldVal, newVal) -> {
            if (newVal == null) {
               noInstrumentSelected();
               return;
            }
            Double defaultQty = newVal.getValue(AmpIcapSecBoardTrim2.defaultQty_d);
            Integer secClassId = newVal.getValue(AmpIcapSecBoardTrim2.secClassId);

            SelectionContext ctx = selectionContextProperty.get();

            if (ctx == null) {
               return;
            }

            String oldName = null;
            if (oldVal != null) {
               oldName = (oldVal.getRow()).getValue(AmpIcapSecBoardTrim2.secCode);
            }
            String newName = newVal.getValue(AmpIcapSecBoardTrim2.secCode);

            if (oldName != null && !oldName.equals("") && newName.contains(oldName)) return;

            switch (ctx.grid) {
               case Watchlist:
                  clone2TSProperty().set(settings.prefs.clone2RFS().get());
                  if (getSecBoardContext().marketSizePorperty().get() && defaultQty != null) {
                     setSize(defaultQty);
                  }
                  else if (!newName.contains("-rfs")) {
                     setSize(secClassId != null && secClassId == AmpSecClassId.strategy ?
                        getSecBoardContext().defaultStrategyQtyProperty().get() :
                        getSecBoardContext().defaultOutrightQtyProperty().get());
                  }
               default:
            }
         }));

         disposer.disposes(Fx.addWeakListener(selectionContextProperty, new ChangeListener<SelectionContext>() {
            @Override
            public void changed(ObservableValue<? extends SelectionContext> obsVal, SelectionContext oldVal, SelectionContext newVal) {

               if (!selectionContextModule.dataContextRfsSessionSec.get()) {
                  yoursAction.get().disarm();
                  mineAction.get().disarm();
               } else {
                  logger.debug("RFS Session instrument selected - Do not disarm Mine/Yours");
               }

               if (selectedOrderRow != null) {
                  selectedOrderRow.rowProperty().removeListener(orderDataListener);
               }

               // TODO: I have removed the reliance on getSecBoardContext().getSpecWatchedSecboards() since it is not there
               // any more, so we need to check what are the effects of that (BA)
               if (newVal == null || newVal.row == null /*|| (!getSecBoardContext().getSpecWatchedSecboards().isEmpty() && getSecBoardContext().getSpecWatchedSecboards().get(0) == null)*/) {
                  noInstrumentSelected();
                  resetBidOfferLitConditions();
                  return;
               }

               ditDisable.setValue(false);
               qtyResetOnClick = true;

               switch (newVal.grid) {
                  case OBBO_BUY:
                  case OBBO_SELL:
                     obboCase(oldVal, newVal);
                     break;
                  case Watchlist:
                     watchlistCase(newVal);
                     break;
                  case Rfq:
                     rfqCase(newVal);
                     break;
                  case Orders:
                     selectedOrderRow = newVal.row;
                     handleOrderSelection(selectedOrderRow);

                     orderDataListener = arg0 -> handleOrderSelection(selectedOrderRow);
                     selectedOrderRow.rowProperty().addListener(orderDataListener);
                     break;
                  default:
                     break;
               }
               resetBidOfferLitConditions();
            }
            private InvalidationListener orderDataListener;
            private ObservableReplyRow selectedOrderRow;
         }));
         disposer.disposes(Fx.bind(rateDecimalsProperty(), getSecBoardContext().priceDecimalsProperty()));
         disposer.disposes(Fx.bind(sizeDecimalsProperty(), getSecBoardContext().spinQtyDecimalsProperty()));

         setOrderTypeInView(OrderType.REGULAR);
         setImmediate(false);
         setGTD(settings.prefs.defaultDurationType().get() == DefaultDurationType.GOOD_TILL_DURATION);
         Fx.runLater(()->setAnon(settings.prefs.anon().get(), true));
         setUnderRef(false);
         setCloneToTS(settings.prefs.clone2RFS().get());
         durationDisabledProperty().set(false);
         setDoneIfTouchedDisable(false);
         setMinFillDisable(true);
         setIcebergDisable(true);
         durationProperty().set(settings.prefs.defaultDuration().get());

      }

      void onOffer(boolean isArmed) {
         logger.info("OFFER button pressed: lit {}", isArmed);
         // Disarm the other buttons
         bidAction.get().disarm();
         mineAction.get().disarm();
         yoursAction.get().disarm();

         actionType = ActionType.OFFER;
         keyboardNavigation.moveContextViewFocus(getView());
         for(Command command:offerActionHandlerLilst){
            Future<Boolean> handled = command.execute(isArmed);
            if (!handled.isDone()) {
               commandInProgress.set(true);
               handled.addListener(h -> commandInProgress.set(false));
               return;
            }
         }
         actionType = ActionType.OFFER;
         if (!isArmed)
            return;
         if(settings.getData().orderConfirmProperty().get()){
            Double orderPrice = getDoubleEditVal(rateTextProperty().get());
            offerCommand.execute(orderPrice).onSuccess(new Fun1<Boolean,Void>() {
               @Override
               public Void call(Boolean confirmed) {
                  if(confirmed){
                     doOffer();
                  }
                  return null;
               }
            });
         }else {
            doOffer();
         }
      }

      void doOffer() {
         if (isRegularOrderProperty.get() ) {
            doAmend(amendableOrderRowProperty.get());
         } else {
            AbstractOrderTrans orderTrans = isManaged() ? new ManagedOrderTrans(notifier) : new OrderTrans(notifier);

            populateTransactionData(orderTrans);
            logger.debug("****Executing SELL****");
            orderTrans.executeBuySell(session.getUnderlyingSession(), AmpOrderVerb.sell);
         }
      }

      void onMine(boolean isArmed) {
         logger.info("MINE button pressed: lit {}, price {}", mineLitProperty().get(), mineRateBinding.get());
         // Disarm the other buttons
         bidAction.get().disarm();
         offerAction.get().disarm();
         yoursAction.get().disarm();

         actionType = ActionType.MINE;
         keyboardNavigation.moveContextViewFocus(getView());
         for(Command command:mineActionHandlerLilst){
            Future<Boolean> handled = command.execute(isArmed);
            if (!handled.isDone()) {
               commandInProgress.set(true);
               handled.addListener(h -> {
                  commandInProgress.set(false);
                  actionType_init_rfsSession = actionType;
                  mineAction.get().armNow();
               });
               return;
            }
         }

         if(settings.getData().orderConfirmProperty().get() && isArmed){
            Double orderPrice = getDoubleEditVal(rateTextProperty().get());
            bidCommand.execute(orderPrice).onSuccess(new Fun1<Boolean,Void>() {
               @Override
               public Void call(Boolean confirmed) {
                  if(confirmed){
                     doMine(isArmed);
                  }
                  return null;
               }
            });
         }else {
            doMine(isArmed);
         }
      }

      void doMine(boolean isArmed) {

         actionType = ActionType.MINE;
         if (isArmed) {

            AbstractOrderTrans orderTrans;

            if (isManaged() && settings.prefs.yoursMineOrderWithdraw().get()) {
               orderTrans = new ManagedOrderTrans(notifier);
            } else {
               orderTrans = new OrderTrans(notifier);
            }

            populateTransactionData(orderTrans);
            populateLinkedOrdersInfo(orderTrans);

            orderTrans.executeBuySell(session.getUnderlyingSession(), AmpOrderVerb.buy);
            setImmediate(false);
         } else {
            setMinePrice();
         }
      }

      private void populateLinkedOrdersInfo(AbstractOrderTrans orderTrans) {
         SelectedRowCellContext obboRow = obbo.selectionContextModule.getSelectedObboRow();
         if (obboRow != null) {
            ObservableReplyRow row = obboRow.selectedRow;
            Long orderNo = row.getValue(AmpOrderBookByOrder.orderNo);
            orderTrans.setPickupOrderNo(orderNo);
            Long orderNoSuffix = row.getValue(AmpOrderBookByOrder.orderNoSuffix);
            orderTrans.setPickupOrderNoSuffix(orderNoSuffix);
            Date orderDate = row.getValue(AmpOrderBookByOrder.orderDate);
            if (obbo.xfeSessionModule.rfsPickup.get()) {
               populateRfsPickupFields(orderTrans, orderNo, orderNoSuffix, orderDate);
               obbo.xfeSessionModule.rfsPickup.set(false);
               obbo.xfeSessionModule.pickedUpRow.set(null);
            }

            if ((session.getUnderlyingSession().isLoggedOnUserBrokerNoIB() &&
               session.getUnderlyingSession().getLoggedOnUserId().equals(row.getValue(AmpOrderBookByOrder.operatorId))) ||
               (session.getUnderlyingSession().isLoggedOnUserIB() &&
                  session.getUnderlyingSession().getLoggedOnUserId().equals(row.getValue(AmpOrderBookByOrder.introBrokerId))) &&
                  !isInSweepProperty().get()) {
               populateCrossingId(orderTrans, orderNo, orderNoSuffix, orderDate);
            }
         }
      }

      void setImmediate(boolean immediate) {
         immediateProperty().setValue(immediate);
      }

      private void setMinePrice() {
         Double price = mineRateBinding.get();
         Double quantity = mineQuantityBinding.get();

         if (price == null) {
            return;
         }

         setOrderTypeInView(OrderType.REGULAR);
         setPrice(price);
         setSize(quantity);
         setImmediate(true);

      }

      private void populateRfsPickupFields(AbstractOrderTrans orderTrans,
                                           Long orderNo,
                                           Long orderNoSuffix,
                                           Date orderDate) {
         orderTrans.setPickupOrder(true);
         orderTrans.setPickupOrderNo(orderNo);
         orderTrans.setPickupOrderNoSuffix(orderNoSuffix);
         orderTrans.setPickupOrderDate(orderDate);
      }

      private void populateCrossingId(AbstractOrderTrans orderTrans,
                                      Long orderNo,
                                      Long orderNoSuffix,
                                      Date orderDate) {
         orderTrans.setCrossingOrder(true);
         orderTrans.setCrossingOrderNo(orderNo);
         orderTrans.setCrossingOrderNoSuffix(orderNoSuffix);
         orderTrans.setCrossingOrderDate(orderDate);
      }

      private void setOrderTypeInView(OrderType orderType) {
         setOrderType(orderType.ordinal());
      }

      public void setPrice(Double price) {
         entryModule.rateEditProperty.get().set(price);

         if (entryModule.rateEditorNeedFocused.get()) {
            entryModule.rateEditorNeedFocused.set(false);
            Fx.runLater(entryModule::setFocusOnRateEdit);
         }
      }

      void setSize(Double size) {
         if (size != null) {
            entryModule.sizeEditProperty.get().set(size);
         } else {
            entryModule.sizeEditProperty.get().set(0.0);
         }
      }

      void onYours(boolean isArmed) {
         logger.info("YOURS button pressed: lit {}, price {}", yoursLitProperty().get(), yoursRateBinding.get());
         // Disarm the other buttons
         bidAction.get().disarm();
         offerAction.get().disarm();
         mineAction.get().disarm();

         actionType = ActionType.YOURS;
         keyboardNavigation.moveContextViewFocus(getView());
         for(Command command : yoursActionHandlerLilst){
            Future<Boolean> handled = command.execute(isArmed);
            if (!handled.isDone()) {
               commandInProgress.set(true);
               handled.addListener(h -> {
                  commandInProgress.set(false);
                  actionType_init_rfsSession = actionType;
                  mineAction.get().armNow();
               });
               return;
            }
         }
         if(settings.getData().orderConfirmProperty().get() && isArmed){
            Double orderPrice = getDoubleEditVal(rateTextProperty().get());
            offerCommand.execute(orderPrice).onSuccess(new Fun1<Boolean,Void>() {
               @Override
               public Void call(Boolean confirmed) {
                  if(confirmed){
                     doYours(isArmed);
                  }
                  return null;
               }
            });
         }else {
            doYours(isArmed);
         }
      }

      void doYours(boolean isArmed) {

         actionType = ActionType.YOURS;
         if (isArmed) {
            AbstractOrderTrans orderTrans;

            if (isManaged() && settings.prefs.yoursMineOrderWithdraw().get()) {
               orderTrans = new ManagedOrderTrans(notifier);
            } else {
               orderTrans = new OrderTrans(notifier);
            }

            populateTransactionData(orderTrans);
            populateLinkedOrdersInfo(orderTrans);

            orderTrans.executeBuySell(session.getUnderlyingSession(), AmpOrderVerb.sell);
            setImmediate(false);
         } else {
            setYoursPrice();
         }
      }

      private void setYoursPrice() {
         Double price = yoursRateBinding.get();
         Double quantity = yoursQuantityBinding.get();

         if (price == null) {
            return;
         }

         setOrderTypeInView(OrderType.REGULAR);
         setPrice(price);
         setSize(quantity);
         setImmediate(true);

      }

      Optional<Boolean> canAutoArmBid() {
         logger.debug("bidAutoArmListener triggered");

         boolean isRegular = isRegularOrderProperty.get();
         Double entryRate = entryModule.rateEditProperty.get().get();
         Double oBest = getSecBoardContext().getBestOffer();
         Double oImpl = o_nPriceProperty.get();
         boolean armForRegular = isRegular && amendableOrderSideProperty.isEqualTo(AmpOrderVerb.buy).get();
         boolean armForManaged = !isRegular && (
            entryRate == null ||                                                    // Why? No use arming if the order is invalid!?
               (oBest == null || entryRate < (oBest - Constants.priceTolerance)) && // No offer should match...
                  (oImpl == null || entryRate < (oImpl - Constants.priceTolerance)) // Not even an implied offer.
         );
         logger.debug("bidAutoArmListener AutoArm: {}", armForRegular || armForManaged);
         if (armForRegular || armForManaged)
            return Optional.of(true);
         else
            return Optional.empty();
      }

      Optional<Boolean>  canAutoArmOffer() {
         logger.debug("offerAutoArmListener triggered");

         boolean isRegular = isRegularOrderProperty.get();
         Double entryRate = rateEdit.get().getTextValue().orElse(null);
         Double bBest = getSecBoardContext().getBestBid();
         Double bImpl = b_nPriceProperty.get();
         boolean armForRegular = isRegular && amendableOrderSideProperty.isEqualTo(AmpOrderVerb.sell).get();
         boolean armForManaged = !isRegular && (
            entryRate == null ||                                                    // Why? No use arming if the order is invalid!?
               (bBest == null || entryRate > (bBest + Constants.priceTolerance)) && // No bid should match...
                  (bImpl == null || entryRate > (bImpl + Constants.priceTolerance)) // Not even an implied offer.
         );
         logger.debug("offerAutoArmListener AutoArm: {}", armForRegular || armForManaged);
         if (armForRegular || armForManaged)
            return Optional.of(true);
         else
            return Optional.empty();
      }

      ObjectProperty<ObservableReplyRow> amendableOrderProperty() {
         return amendableOrderRowProperty;
      }

      @Override
      protected Future<Void> dispose(boolean disposing) {
         bidIsIndicative.unbind();
         offerIsIndicative.unbind();
         b_nPriceProperty.unbind();
         o_nPriceProperty.unbind();
         b_nQtyProperty.unbind();
         o_nQtyProperty.unbind();
         bidSizeProperty.unbind();
         offerSizeProperty.unbind();
         bestBidProperty.unbind();
         bestOfferProperty.unbind();
         priceStepArrayProperty.unbind();
         quantityStepArrayProperty.unbind();
         isBestOfferIndicativeProperty.dispose();
         isBestBidIndicativeProperty.dispose();
         return super.dispose(disposing);
      }

      private void noInstrumentSelected() {
         setDefaultOrderData(true);
         enableOrderEntry(false);
      }

      private void handleObboSelection(ObservableReplyRow row, boolean isSetImmediate) {
         setDefaultOrderData(isSetImmediate);

         SelectionContext selectionContext = selectionContextProperty.get();

         if (!SelectionTracker.breadcrumbs.getTrail().contains(SelectionTracker.RESTORING_SELECTION)) {
            obbo.sideProperty.set(selectionContext.grid == GridType.OBBO_BUY ? OrderSide.BUY : OrderSide.SELL);
         }
         setSelectedOrderSide(null);
         setPrice(row.getValue(AmpOrderBookByOrder.price));
         if (!obbo.xfeSessionModule.rfsPickup.get() && !obbo.secNameProp.getValue().contains("-rfs")) {
            setSize(getSecBoardContext().getDefaultQty());
         }
      }

      private void handleOrderSelection(ObservableReplyRow rowData) {
         ManagedOrder managedOrder = new ManagedOrder(rowData);

         // DO NOT remove this RunLater unless you want to break the Sweep module!!
         // Sweep module must sweep out before we update the size and rate values from order view,
         // as otherwise they will not be updated for the selected order as they should.
         Fx.runLater(() -> {
            setOrderData(managedOrder);
         });

      }

      private void handleCellSelection(Security security, AsnAccessor selectedField) throws AsnTypeException {
         // Setting the order entry dialog to its default values
         setDefaultValues(true);
         boolean forceDitForRfs = isRfsSecboad(security.getBoardId()) && session.getUnderlyingSession().getStats().isRfsSessionAllowed && !session.rfqs.get().isActiveRfqSession(security.getSecCode(), security.getBoardId());
         ditDisable.setValue(forceDitForRfs);
         setDoneIfTouched(forceDitForRfs);
         if ((yoursAction.get().getArmedState() == DualAction.DualActionState.ARMING ||
            mineAction.get().getArmedState() == DualAction.DualActionState.ARMING) &&
            isRfsSecboad(security.getBoardId()))
            setImmediate(true);

         Double price;
         Double quantity = null;
         if (selectedField != null && AmpIcapSecBoardTrim2.nLevelImpBidPrice_d.hasEqualAccess(selectedField) && security.getNImpBidPrice() != null) {
            logger.debug("B_N Cell");
            price = security.getNImpBidPrice();
         } else if (selectedField != null && AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d.hasEqualAccess(selectedField) && security.getNImpOfferPrice() != null) {
            logger.debug("O_N Cell");
            price = security.getNImpOfferPrice();
         } else if (selectedField != null && AmpIcapSecBoardTrim2.isBidRelated(selectedField)) {
            logger.debug("Bid related cell");
            price = (security.getBidPrice());
         } else if (selectedField != null && AmpIcapSecBoardTrim2.isOfferRelated(selectedField)) {
            logger.debug("Offer related Cell");
            price = (security.getOfferPrice());
         } else {
            logger.debug("Non bid related Cell");
            price = (security.getOfferPrice());
         }

         if (security.getSecCode().contains("rfs")) {
            if (actionType_init_rfsSession == ActionType.MINE)
               price = (security.getOfferPrice());
            else if (actionType_init_rfsSession == ActionType.YOURS)
               price = (security.getBidPrice());
         }

         if (selectionContextModule.dataContextRfqSessionSec.get()) {
            ObservableReplyRow rfqRow = session.rfqs.get().isActiveRfq(security.getSecCode(), security.getBoardId());
            logger.debug("{},{} get rfq row {}", security.getSecCode(), security.getBoardId(), rfqRow);
            if (rfqRow != null) {
               Integer buysell = rfqRow.getValue(AmpRfq.buySell);
               quantity = rfqRow.getValue(AmpRfq.maxQuantity);
            }
         }
         setPrice(price);
         if (quantity != null) {
            setSize(quantity);
         }
      }

      private void resetBidOfferLitConditions() {
         logger.debug("Resetting bid/Offer Lit");
         bidAction.get().disarm();
         offerAction.get().disarm();

         if(isBidValid() && canAutoArmBid().orElse(false))
            bidAction.get().armNow();
         if(isOfferValid() && canAutoArmOffer().orElse(false))
            offerAction.get().armNow();
      }

      private void onQuantity1() {
         if (isInSweepProperty().get()) return;

         double size = settings.prefs.qty1().get();

         try {
            setUserEditMode(true);
            if (getSizeText() == null || getSizeText().isEmpty() || qtyResetOnClick) {
               entryModule.sizeEditProperty.get().set(size);
            } else {
               entryModule.sizeEditProperty.get().set(NumberFormat.getInstance().parse(getSizeText()).doubleValue() + size);
            }
         } catch (ParseException ignored) {
         }

         qtyResetOnClick = false;
      }

      private void onQuantity2() {
         if (isInSweepProperty().get()) return;

         double size = settings.prefs.qty2().get();
         try {
            setUserEditMode(true);
            if (getSizeText() == null || getSizeText().isEmpty() || qtyResetOnClick) {
               entryModule.sizeEditProperty.get().set(size);
            } else {
               entryModule.sizeEditProperty.get().set(NumberFormat.getInstance().parse(getSizeText()).doubleValue() + size);
            }
         } catch (ParseException ignored) {
         }

         qtyResetOnClick = false;
      }

      private void onQuantity3() {
         if (isInSweepProperty().get()) return;

         double size = settings.prefs.qty3().get();

         try {
            setUserEditMode(true);
            if (getSizeText() == null || getSizeText().isEmpty() || qtyResetOnClick) {
               entryModule.sizeEditProperty.get().set(size);
            } else {
               entryModule.sizeEditProperty.get().set(NumberFormat.getInstance().parse(getSizeText()).doubleValue() + size);
            }
         } catch (ParseException ignored) {
         }

         qtyResetOnClick = false;
      }

      private void bindLitState() {
         BooleanBinding rateIsNull = isNull(entryModule.rateEditProperty.get());
         DoubleBinding moduleRate = numeric(entryModule.rateEditProperty.get());
         isBestOfferIndicativeProperty = new BooleanBinding() {
            {
               bind(selectionContextProperty, getSecBoardContext().offerIsIndicativeProperty());
            }

            @Override
            protected boolean computeValue() {
               SelectionContext selectionContext = selectionContextProperty.get();
               ObservableReplyRow row = selectionContext == null ? null : selectionContext.row;
               if (row == null) {
                  return false;
               }
               if (selectionContext.grid == GridType.OBBO_SELL) {
                  return Constants.PRICE_TYPE_INDICATIVE.equals(row.getProperty(AmpOrderBookByOrder.specialOrderType).get());
               } else if (selectionContext.grid == GridType.Watchlist) {
                  return getSecBoardContext().offerIsIndicative();
               }
               return false;
            }
         };

         isBestBidIndicativeProperty = new BooleanBinding() {
            {
               bind(selectionContextProperty,getSecBoardContext().bidIsIndicativeProperty());
            }
            @Override
            protected boolean computeValue() {
               SelectionContext selectionContext = selectionContextProperty.get();
               ObservableReplyRow row = selectionContext==null ? null : selectionContext.row;
               if (row == null){
                  return false;
               }

               if (selectionContext.grid == GridType.OBBO_BUY) {
                  return Constants.PRICE_TYPE_INDICATIVE.equals(row.getProperty(AmpOrderBookByOrder.specialOrderType).get());
               }else if(selectionContext.grid == GridType.Watchlist) {
                  return getSecBoardContext().bidIsIndicative();
               }
               return false;
            }
         };
         BooleanBinding bestOfferIsNull = or(isNull(getSecBoardContext().bestOfferProperty()), isBestOfferIndicativeProperty);
         BooleanBinding o_nPriceIsNull = isNull(o_nPriceProperty);

         BooleanBinding bestBidIsNull = or(isNull(getSecBoardContext().bestBidProperty()), isBestBidIndicativeProperty);
         BooleanBinding b_nPriceIsNull = isNull(b_nPriceProperty);

         BooleanBinding mineShouldBeLit = new BooleanBinding() {
            {
               bind(isRegularOrderProperty,
                  rateIsNull,
                  bestOfferIsNull,
                  o_nPriceIsNull,
                  immediateProperty(),
                  getSecBoardContext().bestOfferProperty(),
                  moduleRate,
                  dataContextModule.isAllowRfsSession,
                  selectionContextModule.dataContextRfsSessionSec,
                  o_nPriceProperty);
            }
            @Override
            protected boolean computeValue() {
               boolean invalidMineValues = !immediateProperty().getValue() ||
                  rateIsNull.get() ||
                  (bestOfferIsNull.get() &&  o_nPriceIsNull.get());
               logger.trace("invalidMineValues is {}. isRegularOrderProperty: {}; view.isInSweepProperty: {}; view.immediateProperty: {}; rateIsNull: {}; bestOfferIsNull: {}; o_nPriceIsNull:{}",
                  invalidMineValues, isRegularOrderProperty.get(), isInSweepProperty().get(), immediateProperty().getValue(),rateIsNull.get(),bestOfferIsNull.get(),o_nPriceIsNull.get());
               return !invalidMineValues;
            }
         };
         mineAction.get().suppressArmProperty().bind(mineShouldBeLit.not().or(commandInProgress));

         BooleanBinding yoursShouldBeLit = new BooleanBinding() {
            {
               bind(isRegularOrderProperty,
                  rateIsNull,
                  bestBidIsNull,
                  b_nPriceIsNull,
                  immediateProperty(),
                  getSecBoardContext().bestBidProperty(),
                  dataContextModule.isAllowRfsSession,
                  selectionContextModule.dataContextRfsSessionSec,
                  moduleRate,
                  b_nPriceProperty);
            }
            @Override
            protected boolean computeValue() {
               boolean invalidYoursValue = !immediateProperty().getValue() ||
                  rateIsNull.get() ||
                  (bestBidIsNull.get() && b_nPriceIsNull.get());
               logger.trace("invalidYoursValue is {}. isRegularOrderProperty: {}; view.isInSweepProperty: {}; view.immediateProperty: {}; rateIsNull: {}; bestBidIsNull: {}; b_nPriceIsNull:{}",
                  invalidYoursValue, isRegularOrderProperty.get(), isInSweepProperty().get(), immediateProperty().getValue(),rateIsNull.get(),bestBidIsNull.get(),b_nPriceIsNull.get());

               return !invalidYoursValue;
            }
         };
         yoursAction.get().suppressArmProperty().bind(yoursShouldBeLit.not().or(commandInProgress));

//         yoursShouldBeLit.addListener(observable -> logger.debug("yoursShouldBeLit: {}", yoursShouldBeLit.get()));
//         mineShouldBeLit.addListener(observable -> logger.debug("mineShouldBeLit: {}", mineShouldBeLit.get()));

         // Check for conditions where we should arm the bid button without a click
         InvalidationListener bidAutoArmListener = o -> {
            //if the rate changed and bid is armed we should disarm if autoArm conditions are not met
            boolean rateChanged = (o == rateEdit.get().textProperty());
            boolean autoArm = isBidValid() && canAutoArmBid().orElse(false);
            if (autoArm) {
               bidAction.get().armNow();
            } else if (rateChanged) {
               // if the rate field changes and autoArm conditions are not met, disarm
               bidAction.get().disarm();
            }
         };
         bestOfferProperty.addListener(bidAutoArmListener);
         rateEdit.get().textProperty().addListener(bidAutoArmListener);
         sizeEdit.get().textProperty().addListener(bidAutoArmListener);

         // Check for conditions where we should arm the offer button without a click
         InvalidationListener offerAutoArmListener = o -> {
            boolean rateChanged = (o == rateEdit.get().textProperty());
            boolean autoArm = isOfferValid() && canAutoArmOffer().orElse(false);
            if (autoArm) {
               offerAction.get().armNow();
            } else if (rateChanged) {
               // if the rate field changes and autoArm conditions are not met, disarm
               offerAction.get().disarm();
            }
         };
         bestBidProperty.addListener(offerAutoArmListener);
         rateEdit.get().textProperty().addListener(offerAutoArmListener);
         sizeEdit.get().textProperty().addListener(offerAutoArmListener);
      }

      private void watchlistCase(SelectionContext newVal) {
         IcapSecurity newIcapSecurity = new IcapSecurity(newVal.row);
         if (queryReplyRow != null && !newVal.row.equals(queryReplyRow)) {
            IcapSecurity prevIcapSecurity = new IcapSecurity(queryReplyRow);

            if (prevIcapSecurity.getSecCode().equals(newIcapSecurity.getSecCode()))
               return;
         }

         queryReplyRow = newVal.row;
         dealWithSelectedSecurity(newIcapSecurity, newVal.field);
      }

      private void dealWithSelectedSecurity(Security icapSecurity, AsnAccessor field) {

         try {
            setSecurityData(icapSecurity);
            durationProperty().set(settings.prefs.defaultDuration().get());
            handleCellSelection(icapSecurity, field);
//            if (isAon.get()) {
//               setMinFillAon();
//               setOrderTypeInView(OrderType.MIN_FILL);
//            }

         } catch (AsnTypeException e) {
            logger.error("Handle cell selection error.",e);
         }
      }

      private void rfqCase(SelectionContext newVal) {
         if (newVal.row != null){ //for rfq, if it is expired, the newVal.row can be null
            IcapRfqSecurity security = new IcapRfqSecurity(newVal.row);
            dealWithSelectedSecurity(security, null);
         }
      }

      private String getObboOrderId(SelectionContext selectionContext) {
         String obboId = null;
         if (selectionContext.row != null) {
            obboId = selectionContext.row.getString(AmpOrderBookByOrder.managedOrderIdAcc);
            if (obboId == null) {
               assert selectionContext.row != null;
               obboId = selectionContext.row.getString(AmpOrderBookByOrder.orderId);
            }
         }

         return obboId;
      }

      private void obboCase(SelectionContext oldVal,
                            SelectionContext newVal) {
         // Not changing the OBBO information in the Order Entry
         // if the selected order is actually the same (sometimes a line will be replaced and re-added upon
         // a tick up, which will trigger this code here)

         // TODO: Add code to Tick-up/Tick-down to listen on change of affected order and set
         // the order entry values accordingly.
         if (oldVal != null) {
            String oldObboId = getObboOrderId(oldVal);
            String newObboId = getObboOrderId(newVal);
//there is a case when both both id is null, such as only indicative price in both sde .
            if ((Objects.equals(oldObboId, newObboId) && newObboId != null) ||
               oldObboId != null && newObboId != null && oldObboId.equals(newObboId))
               return;
         }

         if (newVal.row == null || obbo.xfeSessionModule.pickedUpRow.get() == null || !newVal.row.getKey().equals(obbo.xfeSessionModule.pickedUpRow.get().getKey())){
            obbo.xfeSessionModule.rfsPickup.set(false);
            obbo.xfeSessionModule.pickedUpRow.setValue(null);
         }

         // For our own user (but not for other users), however, we do need to update the Order Entry data when the content on an existing line
         // is changing, on any of the grids (not just OBBO).
         if (session.getObboFilters().isAmendable.and(ObboFilters.isManaged.not()).accept(newVal.row).get()) {
            session.orders.get().findAllOrdersByFilter(OrderFilters.matchObboRow(newVal.row), orderRows -> {
               if (!orderRows.isEmpty()) {
                  handleOrderSelection(orderRows.get(0));
               } else {
                  handleObboSelection(newVal.row, true);
               }
            });
         } else {
            boolean isSetImmediate = true;
            if (oldVal != null && oldVal.grid == GridType.Watchlist && (newVal.grid == GridType.OBBO_BUY || newVal.grid == GridType.OBBO_SELL))
               isSetImmediate = false;
            handleObboSelection(newVal.row, isSetImmediate);
         }
      }

      private boolean isRfsSecboad(String boardId){
         return "EURR".equals(boardId) || "SPRR".equals(boardId) || "ERX_EUR_RFS".equals(boardId) || "ERX_EUR_SPRR".equals(boardId);
      }
      ActionType actionType;
      private final Disposer disposer = new Disposer();
      private final ObservableBooleanValue unlockViewVisible;
      private final BestPriceCheck bidCommand;
      private final BestPriceCheck offerCommand;
      private final OrderEntryPane view = OrderEntryPane.this;
      private XfeSession session;
      private final ObjectProperty<SelectionContext> selectionContextProperty = new SimpleObjectProperty<>();
      private final SimpleObjectProperty<Double> b_nPriceProperty = new SimpleObjectProperty<>(this, "b_nPriceProperty");
      private final ObjectProperty<Double> b_nQtyProperty = new SimpleObjectProperty<>(this, "b_nQtyProperty");
      private final ObjectProperty<Double> bidSizeProperty = new SimpleObjectProperty<>(this, "bidSizeProperty");
      private final ObjectProperty<Double> bestBidProperty = new SimpleObjectProperty<>(this, "bestBidProperty");
      private final ObjectProperty<Double> o_nPriceProperty = new SimpleObjectProperty<>(this, "o_nPriceProperty");
      private final ObjectProperty<Double> o_nQtyProperty = new SimpleObjectProperty<>(this, "o_nQtyProperty");
      private final ObjectProperty<Double> offerSizeProperty = new SimpleObjectProperty<>(this, "offerSizeProperty");
      private final ObjectProperty<Double> bestOfferProperty = new SimpleObjectProperty<>(this, "bestOfferProperty");
      private final ObjectProperty<ObservableReplyRow> amendableOrderRowProperty = new SimpleObjectProperty<>();
      //private final BooleanBinding isAon; //0079790: XFE Phase 5: Size Specific To Instrument (SSTI). In this is set to true, the order type will be MIN_FILL.
      private final LinkedList<Command> bidActionHandlerLilst = new LinkedList<>();
      private final LinkedList<Command> offerActionHandlerLilst = new LinkedList<>();
      private final LinkedList<Command> mineActionHandlerLilst = new LinkedList<>();
      private final LinkedList<Command> yoursActionHandlerLilst = new LinkedList<>();
      private final ObjectBinding<Integer> amendableOrderSideProperty = new ObjectBinding<Integer>() {
         {
            bind(amendableOrderRowProperty);
         }

         @Override
         protected Integer computeValue() {
            if (amendableOrderRowProperty.get() == null) return null;

            return amendableOrderRowProperty.get().getValue(AmpManagedOrder.buySell);
         }
      };
      private final BooleanBinding isRegularOrderProperty = new BooleanBinding() {
         {
            bind(amendableOrderRowProperty);
         }

         @Override
         protected boolean computeValue() {
            if (amendableOrderRowProperty.get() == null)
            {
               setRegularOrderProperty(false);
               return false;
            }

            boolean isRegular = amendableOrderRowProperty.get().getAsn(AmpManagedOrder.managedOrderId) == null;
            setRegularOrderProperty(isRegular);

            return isRegular;
         }
      };
      private BooleanBinding isBestBidIndicativeProperty;
      private final ObservableValue<Double> obboBidPriceProperty = new ObjectBinding<Double>() {

         {
            bind(selectionContextProperty);
         }

         @Override
         protected Double computeValue() {
            SelectionContext selectionContext = selectionContextProperty.get();
            ObservableReplyRow row;
            if (selectionContext == null || (row = selectionContext.row)==null) {
               return null;
            }
            return row.getValue(AmpOrderBookByOrder.price);
         }
      };
      private final BooleanProperty bidDataChangedProperty = new SimpleBooleanProperty(false);
      private final ObservableValue<Boolean> bidDataChanged = new ObjectBinding<Boolean>() {
         {
            bind(b_nPriceProperty, b_nQtyProperty, bestBidProperty, bidSizeProperty);
         }

         @Override
         protected Boolean computeValue() {
            b_nPriceProperty.getValue();
            b_nQtyProperty.getValue();
            bestBidProperty.getValue();
            bidSizeProperty.getValue();

            bidDataChangedProperty.setValue(true);
            return true;
         }
      };
      private final BooleanProperty offerDataChangedProperty = new SimpleBooleanProperty(false);
      private final ObservableValue<Boolean> offerDataChanged = new ObjectBinding<Boolean>() {
         {
            bind(o_nPriceProperty, o_nQtyProperty, bestOfferProperty, offerSizeProperty);
         }

         @Override
         protected Boolean computeValue() {
            o_nPriceProperty.getValue();
            o_nQtyProperty.getValue();
            bestOfferProperty.getValue();
            offerSizeProperty.getValue();

            offerDataChangedProperty.setValue(true);
            return true;
         }
      };
      private BooleanBinding isBestOfferIndicativeProperty;
      private QueryReplyRow queryReplyRow;
      private final ObservableValue<Double> obboOfferPriceProperty = new ObjectBinding<Double>() {
         {
            bind(selectionContextProperty);
         }

         @Override
         protected Double computeValue() {
            SelectionContext selectionContext = selectionContextProperty.get();
            ObservableReplyRow row = selectionContext==null ? null : selectionContext.row;
            if (row == null) {
               return null;
            }

            if (selectionContext.grid == GridType.OBBO_SELL) {
               return row.getValue(AmpOrderBookByOrder.price);
            }else{
               return null;
            }
         }
      };
      private final BooleanProperty commandInProgress = new SimpleBooleanProperty(this, "commandInProgress", false);
      private final ModalAlertModule notifier;
      private boolean qtyResetOnClick = true;
      private final ObjectBinding<Double> mineRateBinding;
      private final ObjectBinding<Double> mineQuantityBinding;
      private Double minePrevQuantity;
      private Double offerPrevQuantity;
      private SelectionContext offerPrevContext;
      private final ObjectBinding<Double> yoursRateBinding;
      private final ObjectBinding<Double> yoursQuantityBinding;
      private Double yoursPrevQuantity;
      private Double bidPrevQuantity;
      private SelectionContext bidPrevContext;
      private String prevSecCode;
      private boolean prevInSweep;
      private boolean prevEditMode;
      private ActionType actionType_init_rfsSession;
      private final EntryModule entryModule;
      private final SettingsUIModule settings;
      private final ObboModule obbo;
      private final DataContextModule dataContextModule;
      private final SelectionContextModule selectionContextModule;
      private final KeyboardNavigationModule keyboardNavigation;
      private final ObjectProperty<SecurityInfo> securityInfoProperty = new SimpleObjectProperty<>();
      private final DisposableSlot<Disposable> rootElementDisableBinding = disposer.disposes(new DisposableSlot<>());

   }
   private OrderEntryPane(SettingsData data, EntryModule entryModule,
                          ListenerTracker tracker, SessionModule sessionModule, SettingsUIModule settingsUIModule,
                          ModalAlertModule notifier, DataContextModule dataContextModule,
                          SelectionContextModule selectionContextModule, KeyboardNavigationModule keyboardNavigation) {
      this.entryModule = entryModule;
      this.obbo = entryModule.obboModule;
      this.selectionContextModule = entryModule.selectionContextModule;
      this.settingsData = data;
      this.dataContextModule = dataContextModule;
      bidAction.get().bindTo(bidBtn);
      mineAction.get().bindTo(mineBtn);
      yoursAction.get().bindTo(yoursBtn);
      offerAction.get().bindTo(offerBtn);

      ManagedOrderEntryPresenter presenter = this.new ManagedOrderEntryPresenter(tracker,entryModule,
         sessionModule,
         settingsUIModule, notifier,dataContextModule,selectionContextModule,keyboardNavigation);

      presenterProperty.set(presenter);
   }

   private boolean getUserEditMode() {
      return sizeEdit.get().getUserEditMode();
   }

   private void setUserEditMode(boolean userModification) {
      sizeEdit.get().setUserEditMode(userModification);
   }

   private String getSizeText() {
      return sizeEdit.get().doubleTextProperty().get();
   }

   private String getIceberg() {
      return icebergEdit.getText();
   }

   private void setIceberg(String iceberg) {
      icebergEdit.setText(iceberg);
      setFocusOnIcebergEdit();
   }

   private void setFocusOnIcebergEdit() {
      icebergEdit.requestFocus();
      icebergEdit.selectAll();
   }

   private String getMinFill() {
      return minFillEdit.getText();
   }

   private void setMinFill(String minFill) {
      minFillEdit.setText(minFill);
      setFocusOnMinFillEdit();
   }

   private void setFocusOnMinFillEdit() {
      minFillEdit.requestFocus();
      minFillEdit.selectAll();
   }

   public boolean isDoneIfTouched() {
      return doneIfTouchedChk.isSelected();
   }

   private void setDoneIfTouched(boolean doneIfTouched) {
      doneIfTouchedChk.setSelected(doneIfTouched);
   }

   private boolean isAnonymous() {
      return anonChk.isSelected();
   }

   private boolean isUnderRef() {
      return underRefChk.isSelected();
   }

   private void setUnderRef(boolean underRef) {
      underRefChk.setSelected(underRef);
   }

   private boolean isGTD() {
      return GTDChk.isSelected();
   }

   private void setGTD(boolean gtd) {
      GTDChk.setSelected(gtd);
   }

   private StepArray getPriceStepArray() {
      return priceStepArrayProperty().get();
   }

   private ObjectProperty<StepArray> priceStepArrayProperty() {
      return priceStepArrayProperty;
   }

   private StepArray getQuantityStepArray() {
      return quantityStepArrayProperty().get();
   }

   private ObjectProperty<StepArray> quantityStepArrayProperty() {
      return quantityStepArrayProperty;
   }

   public boolean isManaged() {
      return isManaged.get();
   }

   public void setManaged(boolean b) {
      isManaged.set(b);
   }

   private boolean getAllowMultiMinFill() {
      return orderTypeComboBox.getSelectionModel().getSelectedItem() == OrderType.MIN_FILL;
   }

   private SettingsData getSettingsData() {
      return settingsData;
   }

   public void setRegularOrderProperty(boolean isRegularOrder) {
      this.isRegularOrderProperty.set(isRegularOrder);
   }

   public void setInfoText(String str) {
      infoLabel.textProperty().set(str);
   }

   private void setCloneToTS(boolean cloneToTS) {
      clone2TS.setSelected(cloneToTS);
   }

   private void setSelectedOrderSide(OrderSide side) {
      selectedOrderSide.set(side);
   }

   public void setUnlockHandler(Consumer<char[]> handler) {
      getUnlockView().setUnlockHandler(handler);
   }

   public BooleanProperty underRefProperty() {
      return underRefChk.selectedProperty();
   }

   public BooleanProperty disableProperty() {
      return this.getRootElement().disableProperty();
   }

   @Override
   public StackPane getRootElement() {
      if (!isInitialized) {
         isInitialized = true;

         orderEntryRootNode.disableProperty().bind(editableProp.not().or(selectedInstrumentOrderableProp.not()));

         // setup bindings for header row
         ObservableStringValue bestBidString = Fx.asDecimalString(rateEdit.get().decimalsProperty(), bestBid);
         ObservableStringValue bestOfferString = Fx.asDecimalString(rateEdit.get().decimalsProperty(), bestOffer);
         disposer.disposes(Fx.bind(leftBestPriceLabel.textProperty(), Bindings.when(bidOnLeftProperty()).then(bestBidString).otherwise(bestOfferString)));
         disposer.disposes(Fx.bind(rightBestPriceLabel.textProperty(), Bindings.when(bidOnLeftProperty()).then(bestOfferString).otherwise(bestBidString)));
         disposer.disposes(Nodes.bindConditionalStyleOn(leftBestPriceLabel, bidOnLeftProperty(), "xfe-bid-content", "xfe-offer-content"));
         disposer.disposes(Nodes.bindConditionalStyleOn(rightBestPriceLabel, bidOnLeftProperty(), "xfe-offer-content", "xfe-bid-content"));
         disposer.disposes(Nodes.bindConditionalStyleOn(leftBestPriceLabel,
            Bindings.when(bidOnLeftProperty()).then(bidIsIndicative).otherwise(offerIsIndicative), Constants.PRICE_TYPE_INDICATIVE, ""));
         disposer.disposes(Nodes.bindConditionalStyleOn(rightBestPriceLabel,
            Bindings.when(bidOnLeftProperty()).then(offerIsIndicative).otherwise(bidIsIndicative), Constants.PRICE_TYPE_INDICATIVE, ""));

         configureFirstRow();
         configureSecondRow();


         Node unlockSplashPane = getUnlockView().getRootElement();
         disposer.disposes(Fx.bind(unlockSplashPane.visibleProperty(), presenterProperty.get().unlockViewVisibleProperty()));
         disposer.disposes(Fx.bind(unlockSplashPane.managedProperty(), presenterProperty.get().unlockViewVisibleProperty()));
         disposer.disposes(Fx.bind(advPanel.managedProperty(), advSelectedProperty));
         disposer.disposes(Fx.bind(advPanel.visibleProperty(), advSelectedProperty));

         disposer.disposes(Fx.addWeakListener(presenterProperty.get().unlockViewVisibleProperty(),
            HandlerCompositeUtils.wrapPostponeListener((observableVisible, oldVisible, newVisible) -> {
               if (newVisible) {
                  getUnlockView().requestFocus();
               }
            })));

         fullDurationHBox.getChildren().addAll(new HBox() {
            {
               XfeTooltipFactory.setTooltip(durationTextBox);
               this.getChildren().addAll(durationTextBox, new SpinBox() {
                  {
                     this.setMaxHeight(20);
                     this.setOnSpin(event -> OrderEntryPane.this.durationTextBox.adjustSelectedPart(event.amount));
                     super.disableProperty().bind(durationTextBox.editorDisabledProperty());
                  }
               });
               this.setAlignment(Pos.CENTER);
            }
         });

         disposer.disposes(Fx.addListener(settingsData.clone2RFSProperty(), (observable, oldValue, newValue) -> {
            clone2TS.selectedProperty().setValue(newValue);
         }));

         rootNode.getChildren().add(unlockSplashPane);

         // Logging property changes
         Fx.debug(logger, mineBtn.litProperty(),"mine button lit prop");
         Fx.debug(logger, yoursBtn.litProperty(),"yours button lit prop");
         Fx.debug(logger, bidBtn.litProperty(),"bid button lit prop");
         Fx.debug(logger, offerBtn.litProperty(),"offer button lit prop");
         Fx.debug(logger, rateEdit.get().decimalsProperty(),"rate edit decial prop");

         Fx.debug(logger, rateEdit.get().doubleTextProperty(),"rate edit double text");
      }

      return rootNode;
   }

   private BooleanProperty bidOnLeftProperty() {
      return settingsData.bidOnLeftProperty();
   }

   private void configureFirstRow() {
      sizeHBox.getChildren().addAll(sizeEdit.get(), new SpinBox() {
         {
            this.setOnSpin(event -> sizeEdit.get().step(event.amount));
         }
      });

      rateHBox.getChildren().addAll(new StackPane() {
         {
            HBox.setHgrow(this, Priority.ALWAYS);
            this.setPrefWidth(196.0);
            this.setMaxWidth(196.0);
            this.getChildren().addAll(rateEdit.get());
         }
      }, new SpinBox() {
         {
            this.setOnSpin(event -> rateEdit.get().step(event.amount));
         }
      });
   }

   private void configureSecondRow() {
      bidAction.get().setOnAction(actionEvent -> getPresenter().onBid(false));
      bidAction.get().setOnActionArmed(actionEvent -> getPresenter().onBid(true));

      offerAction.get().setOnAction(actionEvent -> getPresenter().onOffer(false));
      offerAction.get().setOnActionArmed(actionEvent -> getPresenter().onOffer(true));

      mineAction.get().setOnAction(actionEvent -> getPresenter().onMine(false));
      mineAction.get().setOnActionArmed(actionEvent -> getPresenter().onMine(true));
      mineAction.get().armedStateProperty().addListener(observable -> logger.error(">>>> mine armed State is {}", mineAction.get().armedStateProperty().get()));

      yoursAction.get().setOnAction(actionEvent -> getPresenter().onYours(false));
      yoursAction.get().setOnActionArmed(actionEvent -> getPresenter().onYours(true));
      yoursAction.get().armedStateProperty().addListener(observable -> logger.error(">>>> yours armed State is {}", yoursAction.get().armedStateProperty().get()));

      immChk.getProperties().put(immChk.selectedProperty(), Fx.bindBidirectional(immChk.selectedProperty(), immediateProperty.get()));
      immChk.disableProperty().bind(Bindings.isNotNull(OrderEntryPane.this.immediateOverrideProperty.get()));

      quantity1Button.textProperty().bind(Bindings.format("%d", settingsData.leftQtyBtnProperty()));
      quantity1Button.setOnAction(onQuantity1);
      quantity2Button.textProperty().bind(Bindings.format("%d", settingsData.middleQtyBtnProperty()));
      quantity2Button.setOnAction(onQuantity2);
      quantity3Button.textProperty().bind(Bindings.format("%d", settingsData.rightQtyBtnProperty()));
      quantity3Button.setOnAction(onQuantity3);

      advButton.setOnAction(event -> advSelectedProperty.setValue(!advSelectedProperty.get()));

      populateSecondRow(bidBtn, mineBtn, yoursBtn, offerBtn);
      disposer.disposes(Fx.addWeakListener(bidOnLeftProperty(), obv -> {
         populateSecondRow(bidBtn, mineBtn, yoursBtn, offerBtn);
      }));
      Fx.debug(logger, quantity2Button.textProperty()," quantity2 text");
      Fx.debug(logger, settingsData.middleQtyBtnProperty(),"settings middle qty button");
   }

   public UnlockView<? extends Node> getUnlockView() {
      if (lockedSplash == null) {
         lockedSplash = new LockedSplashPane();
      }
      return lockedSplash;
   }

   protected ManagedOrderEntryPresenter getPresenter() {
      return presenterProperty.get();
   }

   private void populateSecondRow(Node bidBtn, Node mineBtn, Node yoursBtn, Node offerBtn) {

      hbox_bidMine.getChildren().clear();
      hbox_yoursOffer.getChildren().clear();
      if (bidOnLeftProperty().get()) {
         hbox_bidMine.getChildren().addAll(bidBtn, mineBtn);
         GridPane.setConstraints(bidBtn, 0, 0);
         GridPane.setConstraints(mineBtn, 1, 0);
         hbox_yoursOffer.getChildren().addAll(yoursBtn, offerBtn);
         GridPane.setConstraints(yoursBtn, 0, 0);
         GridPane.setConstraints(offerBtn, 1, 0);
      } else {
         hbox_yoursOffer.getChildren().addAll(mineBtn, bidBtn);
         GridPane.setConstraints(mineBtn, 0, 0);
         GridPane.setConstraints(bidBtn, 1, 0);
         hbox_bidMine.getChildren().addAll(offerBtn, yoursBtn);
         GridPane.setConstraints(offerBtn, 0, 0);
         GridPane.setConstraints(yoursBtn, 1, 0);
      }
   }

   @Override
   public void requestFocus() {
   }

   public BooleanProperty isManagedProperty() {
      return isManaged;
   }

   public IntegerProperty rateDecimalsProperty() {
      return rateEdit.get().decimalsProperty();
   }

   public IntegerProperty sizeDecimalsProperty() {
      return sizeEdit.get().decimalsProperty();
   }

   public BooleanProperty clone2TSProperty() {
      return clone2TS.selectedProperty();
   }

   public void isInstrumentOrderable(boolean isOrderable) {
      selectedInstrumentOrderableProp.set(isOrderable);
   }

   public void enableOrderEntry(boolean enable) {
      editableProp.set(enable);
   }

   public void setAnon(boolean anon, boolean override) {
      if (override || !anonChk.isDisabled())
         anonChk.setSelected(anon);
   }

   public void populateOrderTypes(ObservableList<OrderType> orderTypes) {
      orderTypeComboBox.setItems(orderTypes);
   }

   public void setFocusOnPrice() {
      rateEdit.get().requestFocus();
   }

   public void setFocusOnQty() {
      sizeEdit.get().requestFocus();
   }

   static OrderEntryPane load(SettingsData data, EntryModule entryModule, ListenerTracker tracker,
                              SessionModule sessionModule, SettingsUIModule settingsUIModule,
                              ModalAlertModule notifier, DataContextModule dataContextModule,
                              SelectionContextModule selectionContextModule, KeyboardNavigationModule keyboardNavigation) {
      OrderEntryPane orderEntryPane = new OrderEntryPane(data, entryModule, tracker, sessionModule,
         settingsUIModule, notifier, dataContextModule, selectionContextModule, keyboardNavigation);
      orderEntryPane.isInitialized = false;

      try {
         FXMLLoader ldr = new FXMLLoader(OrderEntryPane.class.getResource("OrderEntryPane.fxml"));
         ldr.setController(orderEntryPane);
         ldr.load();

         orderEntryPane.rate.bindBidirectional(entryModule.rateEditProperty.get());
         orderEntryPane.size.bindBidirectional(entryModule.sizeEditProperty.get());
         orderEntryPane.validatedSizeProperty.bindBidirectional(entryModule.validatedSizeProperty);
         return orderEntryPane;
      } catch (IOException e) {
         logger.error("Error Loading Order Entry FXML:", e);
         return null;
      }
   }

   BooleanProperty userEditModeProperty() {
      return sizeEdit.get().userEditModeProperty();
   }

   BooleanProperty advSelectedProperty() {
      return advSelectedProperty;
   }

   ObjectProperty<Double> bestBidProperty() {
      return bestBid;
   }

   ObjectProperty<Double> bestOfferProperty() {
      return bestOffer;
   }

   void requestFocusOnRateEdit() {
      DoubleTextField textField = rateEdit.get();
      logger.debug("rateedit is foucused: {}",textField.focusedProperty().get());
      if (textField.focusedProperty().get()) {
         textField.selectDecimals();
      } else {
         rateEdit.get().requestFocus();
      }
   }

   ReadOnlyBooleanProperty isInSweepProperty() {
      return isInSweep;
   }

   ObjectProperty<SweepRateQty> sweepRateQtyProperty() {
      return sweepRateQtyProp;
   }

   void setSweep() {
      isInSweep.set(true);
   }

   void resetSweep() {
      isInSweep.set(false);
   }

   void cedeSweepValues() {
      sweepRateQtyProp.set(null);
   }

   void applySweepValues(Double wavgRate, Double totalQty, Boolean isSweepBuy) {
      sweepRateQtyProp.set(new SweepRateQty(wavgRate, totalQty, isSweepBuy));
   }

   private Property<Boolean> immediateProperty() {
      return immediateProperty.get();
   }

   private BooleanProperty GTDProperty() {
      return GTDChk.selectedProperty();
   }

   private BooleanProperty icebergDisabledProperty() {
      return icebergDisable;
   }

   private StringProperty mineLitDescriptionProperty() {
      return mineLitDescription;
   }

   private StringProperty yoursLitDescriptionProperty() {
      return yoursLitDescription;
   }

   @FXML
   private void initialize() {
      char decimalSeparator = DecimalFormatSymbols.getInstance().getDecimalSeparator();
      String matchRegEx = "\\d*(\\" + decimalSeparator + "\\d*)?";
      PropertyValidator.applyRegex(minFillEdit.textProperty(), matchRegEx);
      PropertyValidator.applyRegex(icebergEdit.textProperty(), matchRegEx);
      disposer.disposes(Fx.addWeakListener(orderTypeComboBox.getSelectionModel().selectedItemProperty(), (_0, oldOrderType, newOrderType) -> {
         if (!orderTypeComboBox.getItems().contains(oldOrderType) &&
            orderTypeComboBox.getItems().contains(OrderType.REGULAR)) {
            Fx.runLater(() -> orderTypeComboBox.getSelectionModel().select(OrderType.REGULAR));
            return;
         }

         int orderType = getOrderType();

         if (orderType >= 0) {
            getPresenter().onOrderType(getOrderType());
         }
      }));

      minFillOrMinClipLabel.textProperty().bind(
         Bindings.when(Bindings.equal(orderTypeComboBox.getSelectionModel().selectedItemProperty(), OrderType.MIN_CLIP)).then("MIN CLIP")
            .otherwise("MIN FILL"));

      orderTypeComboBox.setConverter(OrderType.DEFAULT_STRING_CONVERTER);
      orderTypeComboBox.setCellFactory(
         new Callback<ListView<OrderType>, ListCell<OrderType>>() {
            @Override
            public ListCell<OrderType> call(ListView<OrderType> param) {
               return new ListCell<OrderType>() {
                  {
                     super.setPrefWidth(100);
                  }

                  @Override
                  public void updateItem(OrderType item,
                                         boolean empty) {
                     super.updateItem(item, empty);
                     if (item != null) {
                        setText(item.getDescription());
                        setId(item.getId());
                        XfeTooltipFactory.setTooltip(this);
                     } else {
                        setText(null);
                     }
                  }
               };
            }
         });

      User user = entryModule.xfeSessionModule.getUnderlyingSession().getLoggedOnUser();

      isBidAllowed = new BooleanBinding() {

         {
            if (user.isTrader())
               bind(rateEdit.get().textProperty(), sizeEdit.get().textProperty(), selectedOrderSide, obbo.xfeSessionModule.rfsPickup, isInSweep, dataContextModule.rfqAllowedVerb);
            else {
               bind(rateEdit.get().textProperty(), sizeEdit.get().textProperty(), selectedOrderSide, obbo.xfeSessionModule.rfsPickup, selectionContextModule.selectedOrderRowProperty(), entryModule.xfeSessionModule.getUnderlyingSession().onBehalfTraderId, isInSweep, dataContextModule.rfqAllowedVerb);
            }
         }
         @Override
         protected boolean computeValue() {

            if (!isBidValid()) return false;

            if (!user.isBroker() && !user.isTrader()) return false;

            if (isInSweep.get() || dataContextModule.rfqAllowedVerb.get() == AmpOrderVerb.sell) return false;

            boolean isOrderAmendable = true;
            if(user.isBroker()) {
               ObservableReplyRow row = selectionContextModule.selectedOrderRowProperty().getValue()!=null ? selectionContextModule.selectedOrderRowProperty().getValue().selectedRow : null;
               if (row != null){
                  isOrderAmendable = entryModule.xfeSessionModule.getOrderFilters().isAmendable.accept(row).get();
               }
            }

            return isOrderAmendable && !isInSweep.get() &&
               selectedOrderSide.isNotEqualTo(OrderSide.SELL).get() &&
               !obbo.xfeSessionModule.rfsPickup.get();
         }
      };
      bidAction.get().disableProperty().bind(isBidAllowed.not());

      bidAction.get().armedProperty().addListener((observable, oldValue, newValue) -> {
         // We blank the rate in this case to prevent user mistakes
         if (newValue && mineLitProperty().get()) {
            rateEdit.get().setBlank();
            immediateProperty.get().setValue(Boolean.FALSE);
         }
      });

      isOfferAllowed = new BooleanBinding() {

         {
            if(user.isTrader()){
               bind(rateEdit.get().textProperty(), sizeEdit.get().textProperty(), isInSweep, selectedOrderSide, obbo.xfeSessionModule.rfsPickup, isInSweep, dataContextModule.rfqAllowedVerb);
            }else{
               bind(rateEdit.get().textProperty(), sizeEdit.get().textProperty(), isInSweep, selectedOrderSide, obbo.xfeSessionModule.rfsPickup, selectionContextModule.selectedOrderRowProperty(), entryModule.xfeSessionModule.getUnderlyingSession().onBehalfTraderId, isInSweep, dataContextModule.rfqAllowedVerb);
            }
         }
         @Override
         protected boolean computeValue() {

            if (!isOfferValid()) return false;

            if (!user.isBroker() && !user.isTrader()) return false;

            if (isInSweep.get() || dataContextModule.rfqAllowedVerb.get() == AmpOrderVerb.buy) return false;

            boolean isOrderAmendable = true;
            if (user.isBroker()) {
               ObservableReplyRow row = selectionContextModule.selectedOrderRowProperty().getValue()!=null ? selectionContextModule.selectedOrderRowProperty().getValue().selectedRow : null;
               if (row!=null){
                  isOrderAmendable = entryModule.xfeSessionModule.getOrderFilters().isAmendable.accept(row).get();
               }
            }

            return isOrderAmendable && !isInSweep.get() &&
               selectedOrderSide.isNotEqualTo(OrderSide.BUY).get() &&
               !obbo.xfeSessionModule.rfsPickup.get();
         }
      };
      offerAction.get().disableProperty().bind(isOfferAllowed.not());

      offerAction.get().armedProperty().addListener((observable, oldValue, newValue) -> {
         // We blank the rate in this case to prevent user mistakes
         if (newValue && yoursLitProperty().get()) {
            rateEdit.get().setBlank();
            immediateProperty.get().setValue(Boolean.FALSE);
         }
      });

      BooleanBinding mineDisable = new BooleanBinding() {
         {
            bind(selectionContextModule.gridTypeProperty.get(), underRefChk.selectedProperty(),
               isInSweep, sweepRateQtyProp, isMineDisabled);
         }


         @Override
         protected boolean computeValue() {
            GridType gridType = selectionContextModule.gridTypeProperty.get().getValue();
            boolean isSweep = isInSweep.get();
            boolean isUnderRef = underRefChk.selectedProperty().get();

            if (isUnderRef) return true;

            if (isMineDisabled.get()) return true;

            boolean sweepInvalid = false;
            if (isSweep) {
               SweepRateQty sweepRateQty = sweepRateQtyProp.get();
               sweepInvalid = sweepRateQty == null || !sweepRateQty.isValid() || sweepRateQty.getIsSweepBuy().getValue();
            }

            switch (gridType) {
               case Watchlist:
               case Rfq:
               case Orders:
               case OBBO_SELL:
                  return sweepInvalid;
               default:
                  return true;
            }
         }
      };
      mineAction.get().disableProperty().bind(mineDisable);

      BooleanBinding yoursDisable = new BooleanBinding() {
         {
            bind(selectionContextModule.gridTypeProperty.get(), underRefChk.selectedProperty(),
               isInSweep, sweepRateQtyProp, isYoursDisabled);
         }

         @Override
         protected boolean computeValue() {
            GridType gridType = selectionContextModule.gridTypeProperty.get().getValue();
            boolean isSweep = isInSweep.get();
            boolean isUnderRef = underRefChk.selectedProperty().get();
            if (isUnderRef) return true;

            if (isYoursDisabled.get()) return true;

            boolean sweepInvalid = false;
            if (isSweep) {
               SweepRateQty sweepRateQty = sweepRateQtyProp.get();
               sweepInvalid = sweepRateQty == null || !sweepRateQty.isValid() || !sweepRateQty.getIsSweepBuy().getValue();
            }

            switch (gridType) {
               case Watchlist:
               case Rfq:
               case Orders:
               case OBBO_BUY:
                  return sweepInvalid;
               default:
                  return true;
            }
         }
      };
      yoursAction.get().disableProperty().bind(yoursDisable);
      anonChk.disableProperty().bind(isRegularOrderProperty);
      underRefChk.disableProperty().bind(isRegularOrderProperty);
      doneIfTouchedChk.disableProperty().bind(ditDisable.or(isRegularOrderProperty));
      icebergEdit.disableProperty().bind(icebergDisable);
      icebergLabel.disableProperty().bind(icebergDisable);
      //rateLabel.textProperty().bind(Bindings.when(isInSweep).then("AVG RATE").otherwise(Constants.COLUMN_NAME_RATE.toUpperCase()));
      rateLabel.setWrapText(true);
      XfeTooltipFactory.setTooltip(rateLabel);
      this.orderTypeChoiceLabel.textProperty().bind(Bindings.when(isInSweep).then("Sweep").otherwise("TYPE"));

      minFillOrMinClipLabel.disableProperty().bind(minFillDisabledProperty());

      ChangeListener<Boolean> sweepChangelistener = (arg0, oldSweepState, newSweepState) -> {

         if (newSweepState) {
            if (!rateEdit.get().getStyleClass().contains(SWEEP_CUE_STYLECLASS)) {
               rateEdit.get().getStyleClass().add(SWEEP_CUE_STYLECLASS);
            }
            rateLabel.setVisible(false);
            rateLabel.setManaged(false);
            avgRateLabel.setVisible(true);
            avgRateLabel.setManaged(true);
            XfeTooltipFactory.setTooltip(rateEdit.get());
         } else {
            rateEdit.get().getStyleClass().remove(SWEEP_CUE_STYLECLASS);
            avgRateLabel.setVisible(false);
            avgRateLabel.setManaged(false);
            rateLabel.setVisible(true);
            rateLabel.setManaged(true);
         }
      };

      rateLabel.textProperty().addListener((observable, oldValue, newValue) -> {
         if ("AVG RATE".equals(newValue)) {
            // installing tooltip
            XfeTooltipFactory.setToolTipDisplay(rateLabel,true);
         } else {
            // removing tooltip
            XfeTooltipFactory.setToolTipDisplay(rateLabel,false);
         }
      });

      ChangeListener<SweepRateQty> sweepDataChangeListener = (arg0, oldSweepState, newSweepState) -> {
         if (newSweepState != null) {
            if (oldSweepState != null) {
               OrderEntryPane.this.rate.unbindBidirectional(oldSweepState.getWavgRate());
               OrderEntryPane.this.size.unbindBidirectional(oldSweepState.getTotalQty());
            } else {
               OrderEntryPane.this.rate.unbindBidirectional(entryModule.rateEditProperty.get());
               OrderEntryPane.this.size.unbindBidirectional(entryModule.sizeEditProperty.get());
            }

            OrderEntryPane.this.rate.bindBidirectional(newSweepState.getWavgRate());
            OrderEntryPane.this.size.bindBidirectional(newSweepState.getTotalQty());
         } else {
            OrderEntryPane.this.rate.unbindBidirectional(oldSweepState.getWavgRate());
            OrderEntryPane.this.size.unbindBidirectional(oldSweepState.getTotalQty());
            OrderEntryPane.this.rate.bindBidirectional(entryModule.rateEditProperty.get());
            OrderEntryPane.this.size.bindBidirectional(entryModule.sizeEditProperty.get());
         }
      };

      sweepRateQtyProp.addListener(sweepDataChangeListener);
      isInSweep.addListener(sweepChangelistener);

      XfeTooltipFactory.setTooltip(this);
      presenterProperty.get().bindToView();
   }

   private Integer getOrderType() {
      if (orderTypeComboBox != null)
         return orderTypeComboBox.getSelectionModel().getSelectedIndex();
      else
         return -1;
   }

   private boolean isBidValid() {
      return isOrderValid();
   }

   public ObservableBooleanValue mineLitProperty() {
      return mineAction.get().armedProperty();
   }

   private boolean isOfferValid() {
      return isOrderValid();
   }

   public ObservableBooleanValue yoursLitProperty() {
      return yoursAction.get().armedProperty();
   }

   public BooleanProperty minFillDisabledProperty() {
      return minFillEdit.disableProperty();
   }

   private boolean isOrderValid() {
      return rateEdit.get().getTextValue().isPresent() && sizeEdit.get().getTextValue().isPresent();
   }

   public void setOrderType(Integer orderTypeIndex) {
      //logger.trace("order type set to "+orderTypeIndex, new Exception("stack trace"));
      if (orderTypeComboBox.getSelectionModel().getSelectedIndex() != orderTypeIndex)
         orderTypeComboBox.getSelectionModel().select(orderTypeIndex);
   }

   private ReadOnlyStringProperty rateTextProperty() {
      return rateEdit.get().doubleTextProperty();
   }

   private ReadOnlyStringProperty sizeTextProperty() {
      return sizeEdit.get().doubleTextProperty();
   }

   private void enableGTD(boolean enable) {
      durationTextBox.setEditorDisable(!enable);
   }

   private IntegerProperty durationProperty() {
      return durationTextBox.valueProperty();
   }

   private StringProperty durationTextProperty() {
      return durationTextBox.textProperty();
   }

   private BooleanProperty durationDisabledProperty() {
      return fullDurationHBox.disableProperty();
   }

   private void enableAdvBtn(boolean enable) {
      advButton.setDisable(!enable);
   }

   @FXML
   public StackPane rootNode;
   @FXML
   public VBox orderEntryRootNode;
   @FXML
   public Label rateLabel;
   @FXML
   public Label avgRateLabel;
   @FXML
   public Label leftBestPriceLabel;
   @FXML
   public Label rightBestPriceLabel;
   @FXML
   public Label infoLabel;
   @FXML
   public Button quantity1Button;
   @FXML
   public Button quantity2Button;
   @FXML
   public Button quantity3Button;
   @FXML
   public CheckBox immChk;
   @FXML
   public CheckBox doneIfTouchedChk;
   @FXML
   public GridPane hbox_bidMine;
   @FXML
   public GridPane hbox_yoursOffer;
   @FXML
   public HBox advPanel;
   @FXML
   public Button advButton;
   @FXML
   public CheckBox anonChk;
   @FXML
   public CheckBox underRefChk;
   @FXML
   public CheckBox GTDChk;
   @FXML
   public HBox fullDurationHBox;
   @FXML
   public TextField minFillEdit;
   @FXML
   public TextField icebergEdit;
   @FXML
   public CheckBox clone2TS;
   @FXML
   public ComboBox<OrderType> orderTypeComboBox;
   @FXML
   public Label minFillOrMinClipLabel;
   @FXML
   public Label icebergLabel;
   @FXML
   public HBox rateHBox;
   @FXML
   public HBox sizeHBox;
   @FXML
   public Label orderTypeChoiceLabel;

   public final BooleanProperty isMineDisabled = new SimpleBooleanProperty(false);
   final Lazy<DualAction> bidAction = new Lazy<DualAction>() {
      @Override
      protected DualAction initialize() {
         return new DualAction(Constants.COLUMN_NAME_BID.toUpperCase()) {
            {
               this.getStyleClass().add("xfe-orderentry-bidbtn");
               this.armDelayMsProperty().bind(getSettingsData().yoursMineLitDelayProperty());
            }
         };
      }
   };
   final Lazy<DualAction> offerAction = new Lazy<DualAction>() {
      @Override
      protected DualAction initialize() {
         return new DualAction(Constants.COLUMN_NAME_OFFER.toUpperCase()) {
            {
               this.getStyleClass().add("xfe-orderentry-offerbtn");
               this.armDelayMsProperty().bind(getSettingsData().yoursMineLitDelayProperty());
            }
         };
      }
   };
   final Lazy<DualAction> mineAction = new Lazy<DualAction>() {
      @Override
      protected DualAction initialize() {
         return new DualAction(Constants.LABEL_MINE) {
            {
               this.getStyleClass().add("xfe-orderentry-bidbtn");
               this.stausTextProperty().bind(Bindings.when(this.disabledProperty()).then("").otherwise(mineLitDescription));
               this.armDelayMsProperty().bind(getSettingsData().yoursMineLitDelayProperty());
            }
         };
      }
   };
   final Lazy<DualAction> yoursAction = new Lazy<DualAction>() {
      @Override
      protected DualAction initialize() {
         return new DualAction(Constants.LABEL_YOURS) {
            {
               this.getStyleClass().add("xfe-orderentry-offerbtn");
               this.stausTextProperty().bind(Bindings.when(this.disabledProperty()).then("").otherwise(yoursLitDescription));
               this.armDelayMsProperty().bind(getSettingsData().yoursMineLitDelayProperty());
            }
         };
      }
   };
   private final SelectionContextModule selectionContextModule;
   private final EntryModule entryModule;
   private final ObboModule obbo;
   private final Disposer disposer = new Disposer();
   private final ObjectProperty<ManagedOrderEntryPresenter> presenterProperty = new SimpleObjectProperty<>();
   private final SettingsData settingsData;
   private final DataContextModule dataContextModule;
   private final ObjectProperty<Double> bestBid = new SimpleObjectProperty<>();
   private final ObjectProperty<Double> bestOffer = new SimpleObjectProperty<>();
   private final BooleanProperty bidIsIndicative = new SimpleBooleanProperty();
   private final BooleanProperty offerIsIndicative = new SimpleBooleanProperty();
   private final ObjectProperty<OrderSide> selectedOrderSide = new SimpleObjectProperty<>();
   /**
    * Indicates that we are editing an order that we have permission to change.
    * <p>
    * Note: This does not guarantee that we will be submitting an amend transaction. For Managed orders amend will be true to indicate that we are busy updating our own order but it will still submit a managed order transaction instead of an amend transaction
    */
   private final BooleanProperty isRegularOrderProperty = new SimpleBooleanProperty();
   private final BooleanProperty isManaged = new SimpleBooleanProperty(true);
   private final BooleanProperty ditDisable = new SimpleBooleanProperty();
   private final BooleanProperty icebergDisable = new SimpleBooleanProperty();
   private final BooleanProperty advSelectedProperty = new SimpleBooleanProperty(this, "advSelectedProperty", false);
   private final ObjectProperty<Double> size = new SimpleObjectProperty<>(0.0);
   private final StringProperty validatedSizeProperty = new SimpleStringProperty("");
   private final Lazy<DoubleTextField> sizeEdit = new Lazy<DoubleTextField>() {
      @Override
      protected DoubleTextField initialize() {
         return new DoubleTextField(0.000001, 10000.0) {{
            HBox.setHgrow(this, Priority.ALWAYS);
            this.setPrefWidth(130);
            this.setMaxWidth(130);
            this.setId("xfe-orderentry-rateedit");
            if (!isInSweep.get()) {
               getStyleClass().remove("xfe-is-sweep-value");
               getStyleClass().add("xfe-orderentry-rateedit");
            }
            else {
               getStyleClass().remove("xfe-orderentry-rateedit");
               getStyleClass().add("xfe-is-sweep-value");
            }
         }
            {
               this.setTextAlignment(TextAlignment.CENTER);
               this.valueProperty().bindBidirectional(size);
               this.verifiedTextProperty().bindBidirectional(validatedSizeProperty);
            }

            @Override
            public void step(int steps) {
               StepArray quantityStepArray = OrderEntryPane.this.getQuantityStepArray();

               if (quantityStepArray != null) {
                  userEditMode.setValue(true);
                  changeTrail.run(SPIN_CHANGE, () -> {
                     double newValue = quantityStepArray.notch(getValue(), steps);
                     setValue(newValue);
                     noRecurse.run(() -> {
                        Fx.runLater(this::selectAll);

                        requestFocus();
                     });
                  });
               }
            }
         };
      }
   };
   private final ObjectProperty<Double> rate = new SimpleObjectProperty<>(0.0);
   private final Lazy<DoubleTextField> rateEdit = new Lazy<DoubleTextField>() {
      @Override
      protected DoubleTextField initialize() {
         return new DoubleTextField(-Double.MAX_VALUE, Double.MAX_VALUE) {

            {
               setId("orderentry-rate-edit");
               HBox.setHgrow(this, Priority.ALWAYS);
               this.setId("xfe-orderentry-sizeedit");

               if (!isInSweep.get()) {
                  getStyleClass().remove("xfe-is-sweep-value");
                  getStyleClass().add("xfe-orderentry-rateedit");
               }
               else {
                  getStyleClass().remove("xfe-orderentry-rateedit");
                  getStyleClass().add("xfe-is-sweep-value");
               }
               decimalsProperty().set(4);
            }

            {
               this.setTextAlignment(TextAlignment.CENTER);
               this.valueProperty().bindBidirectional(rate);
               this.focusedProperty().addListener((observableFocused, oldFocused, newFocused) -> {
                  if (newFocused) noRecurse.run(() -> Fx.runLater(this::selectDecimals));
               });

               this.valueProperty().addListener((ob, oldValue, newValue) -> {
                  rate.set(newValue);
               });
            }

            @Override
            public void selectAll() {
               super.selectAll();
            }

            @Override
            public void step(int steps) {
               StepArray priceStepArray = OrderEntryPane.this.getPriceStepArray();

               if (priceStepArray != null) changeTrail.run(SPIN_CHANGE, () -> {
                  double newValue = priceStepArray.notch(getValue(), steps);

                  setValue(newValue);

                  noRecurse.run(() -> {
                     Fx.runLater(this::selectAll);

                     requestFocus();
                  });
               });
            }
         };
      }
   };
   private final BooleanProperty immediateUnderlyingProperty = new SimpleBooleanProperty(false);
   private final Lazy<ObjectProperty<Boolean>> immediateProperty = new Lazy<ObjectProperty<Boolean>>() {
      @Override
      protected ObjectProperty<Boolean> initialize() {
         return Fx.overriddenByValue(OrderEntryPane.this.immediateUnderlyingProperty, OrderEntryPane.this.immediateOverrideProperty.get());
      }
   };
   private BooleanBinding isBidAllowed;
   private BooleanBinding isOfferAllowed;
   private LockedSplashPane lockedSplash;
   private final BooleanProperty isYoursDisabled  = new SimpleBooleanProperty(false);
   private final EventHandler<ActionEvent> onQuantity1 = event -> getPresenter().onQuantity1();
   private final EventHandler<ActionEvent> onQuantity2 = event -> getPresenter().onQuantity2();
   private final EventHandler<ActionEvent> onQuantity3 = event -> getPresenter().onQuantity3();
   private final Lazy<ObservableObjectValue<ObservableBooleanValue>> immediateOverrideProperty = new Lazy<ObservableObjectValue<ObservableBooleanValue>>() {
      @Override
      protected ObservableObjectValue<ObservableBooleanValue> initialize() {
         return new ObjectBinding<ObservableBooleanValue>() {
            {
               bind(orderTypeComboBox.getSelectionModel().selectedItemProperty(),
                  minFillEdit.textProperty(),
                  isInSweep);
            }

            @Override
            public ObservableBooleanValue computeValue() {

               OrderType orderType = orderTypeComboBox.getSelectionModel().selectedItemProperty().get();
               ObservableBooleanValue rtnValue = null;
               if (orderType != null) {
                  switch (orderType) {
                     case FILL_OR_KILL:
                        rtnValue = Fx.valueOf(true);
                        break;
                     case ICEBERG:
                        rtnValue =  Fx.valueOf(false);
                        break;
                     case MIN_FILL:
                        String minFillString = minFillEdit.textProperty().get();

                        if (!minFillString.equals("") && !minFillString.equals("0")) {
                           rtnValue = Fx.valueOf(true);
                        }
                        break;
                  }
               }
               //logger.trace("immediateOverrideProperty return "+rtnValue, new Exception("stack trace"));
               return rtnValue;
            }
         };
      }
   };
   private final StringProperty mineLitDescription = new SimpleStringProperty();
   private final StringProperty yoursLitDescription = new SimpleStringProperty();
   private final CommandButton bidBtn = new CommandButton(BID_LIT_ACTION_STYLE) {
      {
         this.setId("orderentry-bid-btn");
         this.setPrefWidth(109);
         this.setOpacity(1.0);
      }
   };
   private final CommandButton offerBtn = new CommandButton(OFFER_LIT_ACTION_STYLE) {
      {
         this.setId("orderentry-offer-btn");
         this.setPrefWidth(109);
         this.setOpacity(1.0);
      }
   };
   private final CommandButton mineBtn = new CommandButton(BID_LIT_ACTION_STYLE) {
      {
         this.setId("orderentry-mine-btn");
         this.setPrefWidth(109);
         this.setOpacity(1.0);
      }
   };
   private final CommandButton yoursBtn = new CommandButton(OFFER_LIT_ACTION_STYLE) {
      {
         this.setId("orderentry-yours-btn");
         this.setPrefWidth(109);
         this.setOpacity(1.0);
      }
   };
   private final DurationTextField durationTextBox = new DurationTextField() {
      {
         this.getStyleClass().add("xfe-orderentry-durationtextbox");
         this.setPrefColumnCount(5);
         this.setEditorDisable(true);
      }

      @Override
      public String getControlId() {
         return "orderentry-duration-chk";
      }
   };
   private final BooleanProperty selectedInstrumentOrderableProp = new SimpleBooleanProperty(true);
   private final BooleanProperty editableProp = new SimpleBooleanProperty(true);
   private boolean isInitialized;
   private final ObjectProperty<StepArray> priceStepArrayProperty = new SimpleObjectProperty<>();
   private final ObjectProperty<StepArray> quantityStepArrayProperty = new SimpleObjectProperty<>();
   private final BooleanProperty isInSweep = new SimpleBooleanProperty(false);
   private final ObjectProperty<SweepRateQty> sweepRateQtyProp = new SimpleObjectProperty<>(null);

}
