package xfe.icap.modules.info;

import javafx.fxml.FXML;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import xfe.util.Util;
import xstr.util.XfeVersionInfo;

/**
 * Controller for the XfeInfo dialog pane.
 */
public class XfeInfoPane {

   @FXML
   public void initialize() {
      versionTextField.setText(XfeVersionInfo.getProjectVersion());
      emailSupportLink.setOnAction(e -> {
         String version = "v" + versionTextField.getText();
         String subject = "[i-Swap XFE " + version + "] ";
         String body = "Dear iSwap support,\n\n";
         String mailToString = "mailto:" + emailSupportLink.getText() + uriParam("subject", subject) + uriParam("body", body);
         Util.browser(mailToString);
      });
   }

   public void setHotLine(String hotLine) {
      hotLineTextField.setText(hotLine);
   }

   public void setEmailSupport(String email) {
      emailSupportLink.setText(email);
   }

   public Pane getRoot() {
      return root;
   }

   private static String uriParam(String name, String text) {
      return "&" + name + "=" + escapeUri(text);
   }

   private static String escapeUri(String text) {
      return text.replaceAll(" ", "%20").replaceAll("\n", "%0a");
   }

   @FXML
   private Pane root;

   @FXML
   private TextField versionTextField;

   @FXML
   private TextField hotLineTextField;

   @FXML
   private Hyperlink emailSupportLink;

}
