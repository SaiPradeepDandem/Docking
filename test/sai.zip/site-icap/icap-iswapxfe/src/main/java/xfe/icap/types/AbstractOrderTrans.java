package xfe.icap.types;

import com.nomx.domain.types.DefaultDurationType;
import com.omxgroup.syssrv.Duration;
import com.omxgroup.xstream.amp.AmpOrderDuration;
import com.omxgroup.xstream.amp.AmpOrderType_v1;
import javafx.scene.control.Alert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.types.OrderType;
import xfe.ui.notifications.ModalAlertModule;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ServerSession;
import xstr.session.XtrTransReply;
import xstr.session.XtrTransRequest;
import xstr.session.XtrTransRequestBuilder;
import xstr.types.MapWrapper;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.exception.AsnTypeException;
import xstr.util.exception.XtrException;

import java.util.Date;

public abstract class AbstractOrderTrans {
      private static final Logger logger = LoggerFactory.getLogger(AbstractOrderTrans.class);


   protected interface OrderAcc {
      AmpTreq transaction();
      AsnConversionAccessor<Integer> buySell();
      AsnConversionAccessor<String> secCode();
      AsnConversionAccessor<String> boardId();
      AsnConversionAccessor<Integer> type();
      AsnConversionAccessor<Boolean> isPrivate();
      AsnConversionAccessor<Boolean> isDoneIfTouched();
      AsnConversionAccessor<Boolean> isTopCut();
      AsnConversionAccessor<Double> price();
      AsnConversionAccessor<Double> quantity();
      AsnConversionAccessor<Integer> duration();
      AsnConversionAccessor<Duration> durationTime();
      AsnConversionAccessor<Double> visibleQuantity();
      AsnConversionAccessor<Double> minFillQuantity();
      AsnConversionAccessor<Boolean> isPublic();
      AsnConversionAccessor<Integer> actionOnLogoff();
      AsnConversionAccessor<Boolean> isShared();
      AsnConversionAccessor<Boolean> allowMultiMinFill();
      AsnConversionAccessor<Date> pickupOrderDate();
      AsnConversionAccessor<Long> pickupOrderNo();
      AsnConversionAccessor<Long> pickupOrderNoSuffix();
      AsnConversionAccessor<String> introBrokerId();
      AsnConversionAccessor<Date> crossingOrderDate();
      AsnConversionAccessor<Long> crossingOrderNo();
      AsnConversionAccessor<Long> crossingOrderNoSuffix();
      AsnConversionAccessor<Boolean> isCloneIntoRFS();
      AsnConversionAccessor<MapWrapper> extraField();
   }

   @Deprecated
   public enum OnLogoffAction {
      /**
       * Persist
       */
      NONE,
      /**
       * Withdraw
       */
      WITHDRAW,
      /**
       * Refer
       */
      REFER;

      public static final OnLogoffAction Default = REFER;
   }

   private String secCode;
   private String boardId;
   private Double quantity;
   private Double price;
   private OrderType orderType;
   private boolean doneIfTouched;
   private boolean topCut;
   private boolean anonymous;
   private boolean underRef;
   private Duration duration;
   private Double minFill;
   private Double iceberg;
   private Boolean allowMultiMinFill;
   private DefaultDurationType defaultDurationType;
   private com.nomx.domain.types.OnLogoffAction onLogoffAction;
   private boolean shared;
   private boolean isPublic;
   private boolean vwap;

   private boolean isPickupOrder;
   private Date pickupOrderDate;
   private Long pickupOrderNo;
   private Long pickupOrderNoSuffix;

   private boolean isCrossingOrder;
   private Date crossingOrderDate;
   private Long crossingOrderNo;
   private Long crossingOrderNoSuffix;
   private boolean cloneIntoRFS;
   private MapWrapper mapWrapper;

   /**
    * An error modalAlertModule
    */
   private final ModalAlertModule notifier;
   private final OrderAcc field;

   public AbstractOrderTrans(ModalAlertModule notifier, OrderAcc acc) {
      this.notifier = notifier;
      this.field = acc;
   }

   public Future<XtrTransReply> execute( int buyOrSell, ServerSession session, String userid, String introBrokerId) {
      try {
         XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(field.transaction(), session)
            .set(field.buySell(), buyOrSell)
            .set(field.introBrokerId(), introBrokerId)
            .subjectUser(userid)
            ;

         // Building and sending the transaction
         return execute(session, reqBuilder);
      } catch (XtrException ex) {
         logger.error("Error executing transaction: ", ex);
         return Futures.error(ex);
      }
   }

   public Future<XtrTransReply> executeBuySell(ServerSession session, int buySell) {
      try {
         XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(field.transaction(), session)
               .set(field.buySell(), buySell)
               .set(field.introBrokerId(), session.onBehalfTraderIB.get())
               .subjectUser(session.onBehalfTraderId.get())
               ;

         // Building and sending the transaction
         return execute(session, reqBuilder);
      } catch (XtrException ex) {
         logger.error("Error executing transaction: ", ex);
         return Futures.error(ex);
      }
   }

   private boolean checkValid() {
      if (getPrice() == null) {
         notifyError("Rate field must have a value");
         return false;
      }
      if (getQuantity() == null) {
         notifyError("Size field must have a value");
         return false;
      }
      switch(getOnLogOffAction()) {
      case NONE:
      case WITHDRAW:
      case REFER:
         break;
      default:
         notifyError(String.format("Unknown/unexpected action on logoff: %s", getOnLogOffAction()));
         return false;
      }
      return true;
   }

   private Future<XtrTransReply> execute(ServerSession session, XtrTransRequestBuilder builder) {
      if (!checkValid()) {
         return null;
      }

      int logoffAction = Orders.actionOnLogoffToAmp(getOnLogOffAction());
      Duration durationTime = getDuration();
      int durationType = Orders.durationTypeToAmp(getDefaultDurationType());

      try {
         // Setting the secCode

        	   builder = builder
               .set(field.secCode(), getSecCode())
               .set(field.boardId(), getBoardId())
               .set(field.type(), isVwap() ? AmpOrderType_v1.vwap : AmpOrderType_v1.limit)
               .set(field.isPrivate(), isUnderRef())
               .set(field.isDoneIfTouched(), isDoneIfTouched())
               .set(field.isTopCut(), isTopCut())
               .set(field.price(), getPrice())
               .set(field.quantity(), getQuantity())
               .set(field.visibleQuantity(), getIceberg())
               .set(field.minFillQuantity(), getMinfill())
               .set(field.allowMultiMinFill(), getAllowMultiMinFill())
               .set(field.isPublic(), !isAnonymous())
               .set(field.actionOnLogoff(), logoffAction)
               .set(field.isShared(), shared)
               .set(field.duration(), isVwap() ? AmpOrderDuration.immediate : durationType)
               .set(field.durationTime(), durationTime)
               .set(field.isCloneIntoRFS(), isCloneIntoRFS());
            if (mapWrapper != null){
               builder = builder.set(field.extraField(), mapWrapper);
            }
        	   if (isPickupOrder) {
        		   builder = builder.set(field.pickupOrderDate(),pickupOrderDate)
        				     .set(field.pickupOrderNo(),pickupOrderNo)
        				     .set(field.pickupOrderNoSuffix(),pickupOrderNoSuffix);
        	   }

        	   if (isCrossingOrder) {
        		   builder = builder
        				     .set(field.crossingOrderDate(), crossingOrderDate)
        				     .set(field.crossingOrderNo(), crossingOrderNo)
        				     .set(field.crossingOrderNoSuffix(), crossingOrderNoSuffix);
        	   }
        	   XtrTransRequest req = builder.build();

         return session.execute(req);
      } catch (AsnTypeException e) {
         logger.error("Error while executing transaction:" , e);
         return Futures.error(e);
      }

   }

   public Boolean getAllowMultiMinFill() {
      return allowMultiMinFill;
   }

   public void setAllowMultiMinFill(Boolean value) {
      allowMultiMinFill = value;
   }

   /**
    * secCode methods
    */
   public String getSecCode() {
      return secCode;
   }

   public void setSecCode(String secCode) {
      this.secCode = secCode;
   }

   /**
    * boardId methods
    */
   public String getBoardId() {
      return boardId;
   }

   public void setBoardId(String boardId) {
      this.boardId = boardId;
   }

   public boolean isVwap() {
      return vwap;
   }

   public void setVwap(boolean value) {
      this.vwap = value;
   }

   /**
    * quantity methods
    */
   public Double getQuantity() {
      return quantity;
   }

   public void setQuantity(Double quantity) {
      this.quantity = quantity;
   }

   /**
    * price methods
    */
   public Double getPrice() {
      return price;
   }

   public void setPrice(Double price) {
      this.price = price;
   }

   /**
    * order type methods
    */
   public OrderType getOrderType() {
      return orderType;
   }

   public void setOrderType(OrderType orderType) {
      this.orderType = orderType;
   }

   /**
    * immediate methods
    */
   public boolean isImmediate() {
      return defaultDurationType == DefaultDurationType.IMMEDIATE;
   }

   /**
    * Done if touched methods
    */
   public boolean isDoneIfTouched() {
      return doneIfTouched;
   }

   public void setDoneIfTouched(Boolean isDoneIfTouched) {
      doneIfTouched = isDoneIfTouched!=null?isDoneIfTouched:false;
   }

   public boolean isTopCut() {
      return topCut;
   }

   public void setTopCut(boolean topCut) {
      this.topCut = topCut;
   }

   /**
    * anon methods
    */
   public boolean isAnonymous() {
      return anonymous;
   }

   public void setAnonymous(boolean isAnon) {
      anonymous = isAnon;
   }

   /**
    * underRef methods
    */
   public boolean isUnderRef() {
      return underRef;
   }

   public void setUnderRef(boolean isUnderRef) {
      underRef = isUnderRef;
   }

   /**
    * coneIntoRFS methods
    */
   public boolean isCloneIntoRFS() {
      return cloneIntoRFS;
   }

   public void setCloneIntoRFS(boolean isCloneIntoRFS) { cloneIntoRFS = isCloneIntoRFS; }

   /**
    * duration methods
    */
   public Duration getDuration() {
      return duration;
   }

   public void setDuration(Duration duration) {
      this.duration = duration;
   }

   /**
    * GTD methods
    */
   public boolean isGTD() {
      return defaultDurationType == DefaultDurationType.GOOD_TILL_DURATION;
   }

   /**
    * minFill methods
    */
   public Double getMinfill() {
      return minFill;
   }

   public void setMinFill(Double minFill) {
      this.minFill = minFill;
   }

   /**
    * iceberg methods
    */
   public Double getIceberg() {
      return iceberg;
   }

   public void setVisibleQty(Double iceberg) {
      this.iceberg = iceberg;
   }

   /**
    * defaultDurationType methods
    */
   public DefaultDurationType getDefaultDurationType() {
      return defaultDurationType;
   }

   public void setDefaultDurationType(DefaultDurationType defaultDurationType) {
      this.defaultDurationType = defaultDurationType;
   }

   public void setDefaultDurationType(Integer durationType) {
      setDefaultDurationType(Orders.durationTypeFromAmp(durationType));
   }

   /**
    * onLogoffAction methods
    */
   public com.nomx.domain.types.OnLogoffAction getOnLogOffAction() {
      return onLogoffAction;
   }

   public void setOnLogOffAction(com.nomx.domain.types.OnLogoffAction onLogoffAction) {
      this.onLogoffAction = onLogoffAction;
   }

   public void setOnLogOffAction(Integer onLogoffAction) {
      setOnLogOffAction(Orders.actionOnLogoffFromAmp(onLogoffAction));
   }

   /**
    * shared methods
    */
   public boolean isShared() {
      return shared;
   }

   public void setShared(boolean shared) {
      this.shared = shared;
   }

   public void setPublic(boolean isPublic){
      this.isPublic = isPublic;
   }

   public void setPickupOrder(boolean isPickupOrder) {
	   this.isPickupOrder = isPickupOrder;
   }

	public void setPickupOrderDate(Date pickupOrderDate) {
       this.pickupOrderDate = pickupOrderDate == null ? null : new Date(pickupOrderDate.getTime());
	}

	public void setPickupOrderNo(Long pickupOrderNo) {
		this.pickupOrderNo = pickupOrderNo;
	}

	public void setPickupOrderNoSuffix(Long pickupOrderNoSuffix) {
		this.pickupOrderNoSuffix = pickupOrderNoSuffix;
	}

	public void setCrossingOrder(boolean isCrossingOrder) {
		this.isCrossingOrder = isCrossingOrder;
	}

	public void setCrossingOrderDate(Date crossingOrderDate) {
		this.crossingOrderDate = crossingOrderDate == null ? null : new Date(crossingOrderDate.getTime());
	}

	public void setCrossingOrderNo(Long crossingOrderNo) {
		this.crossingOrderNo = crossingOrderNo;
	}

	public void setCrossingOrderNoSuffix(Long crossingOrderNoSuffix) {
		this.crossingOrderNoSuffix = crossingOrderNoSuffix;
	}

   public void setMapWrapper(MapWrapper mapWrapper) {
      this.mapWrapper = mapWrapper;
   }

   @Override
   public String toString() {
      return "OrderTrans{" +
         "secCode='" + secCode + '\'' +
         ", boardId='" + boardId + '\'' +
         ", quantity=" + quantity +
         ", price=" + price +
         ", orderType=" + orderType +
         ", doneIfTouched=" + doneIfTouched +
         ", topCut=" + topCut +
         ", anonymous=" + anonymous +
         ", underRef=" + underRef +
         ", duration=" + duration +
         ", minFill=" + minFill +
         ", iceberg=" + iceberg +
         ", allowMultiMinFill=" + allowMultiMinFill +
         ", defaultDurationType=" + defaultDurationType +
         ", onLogoffAction=" + onLogoffAction +
         ", shared=" + shared +
         ", isPublic=" + isPublic +
         ", vwap=" + vwap +
         ", isPickupOrder=" + isPickupOrder +
         ", pickupOrderDate=" + pickupOrderDate +
         ", pickupOrderNo=" + pickupOrderNo +
         ", pickupOrderNoSuffix=" + pickupOrderNoSuffix +
         ", isCrossingOrder=" + isCrossingOrder +
         ", crossingOrderDate=" + crossingOrderDate +
         ", crossingOrderNo=" + crossingOrderNo +
         ", crossingOrderNoSuffix=" + crossingOrderNoSuffix +
         ", cloneIntoRFS=" + cloneIntoRFS +
         ", mapWrapper=" + mapWrapper +
         ", field=" + field +
         '}';
   }

   private void notifyError(String err) {
      if (notifier != null) {
         notifier.showError(err);
      } else {
         Alert alert = new Alert(Alert.AlertType.ERROR);
         alert.setTitle("Error submitting order");
         alert.setContentText(err);
         alert.showAndWait();

      }

   }
}
