package xfe.icap;

import xfe.modules.layout.FxLayoutManager;
import xfe.module.Module;
import xfe.icap.modules.layout.midi.MidiLayoutModule;

import java.util.Arrays;
import java.util.List;

@Module.Autostart
public class ISwapMainLayoutManager extends FxLayoutManager {

   @Override
   protected List<Class<? extends Module>> getLayouts() {
      return Arrays.asList(
         ISwapLayoutMedium.class,
         MidiLayoutModule.class
      );
   }

}
