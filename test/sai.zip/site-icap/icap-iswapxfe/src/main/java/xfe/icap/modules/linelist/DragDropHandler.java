package xfe.icap.modules.linelist;

import com.nomx.persist.linelist.Participant;
import xstr.util.ListenerTracker;
import xfe.ui.tabpane.XfeTabPane;
import javafx.scene.control.Tab;
import javafx.scene.input.*;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;


class DragDropHandler {

   private boolean isDragging;
   private static final TransferMode REMOVE_FROM_SHORTCUT = TransferMode.MOVE;
   static final TransferMode ADD_TO_SHORTCUT = TransferMode.COPY;

   private final Region bin = new Region() {{
      this.setMinHeight(32);
      this.setMaxHeight(100);
      this.setMinWidth(32);
      this.setMaxWidth(100);
      this.setMinWidth(50);
      this.setPrefWidth(50);
      this.getStyleClass().add("xfe-bin");
   }};


   private XfeTabPane shortcutPane;
   private final LinelistModule module;

   DragDropHandler(LinelistModule module) {
      this.module = module;
   }

   void setShortcutPane(ListenerTracker tracker, XfeTabPane pane, StackPane toolbarContainer) {
      this.shortcutPane = pane;

      tracker.addEventFilter(shortcutPane, MouseEvent.DRAG_DETECTED, event -> {
         isDragging = true;
         Participant par = null;
         try {
            par = (Participant) ((Tab) (event.getPickResult().getIntersectedNode().getParent().getParent().getParent().getUserData())).getUserData();
         } catch (Exception e) {
            LinelistModule.logger.error("can't get trader when dragging");
         }
         if (par != null) {
            Dragboard db = shortcutPane.startDragAndDrop(REMOVE_FROM_SHORTCUT);
            ClipboardContent content = new ClipboardContent();
            content.put(Participant.dataFormat, par);
            content.put(Participant.dataFormat_linelistUUID, par.getGroup().getUuid());
            content.put(Participant.dataFormat_delete, "");
            db.setContent(content);
            toolbarContainer.getChildren().add(bin);
            bin.toFront();
            LinelistModule.logger.debug("bin pane is added");
         }
         event.consume();
      });

      tracker.addEventFilter(shortcutPane, MouseEvent.MOUSE_RELEASED, event -> {
         if (isDragging) {
            event.consume();
         }
         toolbarContainer.getChildren().remove(bin);
         isDragging = false;
      });

      tracker.addEventFilter(shortcutPane, DragEvent.DRAG_OVER, dragEvt -> {
         Dragboard db = dragEvt.getDragboard();
         if (db.hasContent(Participant.dataFormat) && db.hasContent(Participant.dataFormat_linelistUUID)) {
            if (db.hasContent(Participant.dataFormat_delete)) {
               dragEvt.acceptTransferModes(REMOVE_FROM_SHORTCUT);
            } else if (db.hasContent(Participant.dataFormat_add)) {
               dragEvt.acceptTransferModes(ADD_TO_SHORTCUT);
            }
         }

      });

      tracker.addEventFilter(shortcutPane, DragEvent.DRAG_DROPPED, dragEvt -> {
         Dragboard db = dragEvt.getDragboard();
         if (db.hasContent(Participant.dataFormat_add)) {
            Participant participant = (Participant) db.getContent(Participant.dataFormat);
            Tab tab = shortcutPane.getDragOverTab();
            module.addShortcut(participant, (Participant)tab.getUserData(),shortcutPane.getDraggongPlace());
         }
         if (db.hasContent(Participant.dataFormat_delete)) {
            Participant participant = (Participant) db.getContent(Participant.dataFormat);
            Tab tab = shortcutPane.getDragOverTab();
            module.arrangeShortcut(participant, (Participant)tab.getUserData(),shortcutPane.getDraggongPlace());
         }
      });

      tracker.addEventFilter(shortcutPane, DragEvent.DRAG_DONE, dragEvt -> {
         Dragboard db = dragEvt.getDragboard();
         if (db.hasContent(Participant.dataFormat_delete)) {
            toolbarContainer.getChildren().remove(bin);
         } else if (db.hasContent(Participant.dataFormat_add)) {
            dragEvt.acceptTransferModes(ADD_TO_SHORTCUT);
         }
         isDragging = false;
      });

      tracker.addEventFilter(bin, DragEvent.DRAG_DROPPED, dragEvt -> {
         Dragboard db = dragEvt.getDragboard();
         if (db.hasContent(Participant.dataFormat) && db.hasContent(Participant.dataFormat_linelistUUID)) {
            if (db.hasContent(Participant.dataFormat_delete)) {
               Participant participant = (Participant) db.getContent(Participant.dataFormat);
               module.removeShortcut(participant);
            }
         }

      });

      tracker.addEventFilter(bin, DragEvent.DRAG_OVER, dragEvt -> {
         Dragboard db = dragEvt.getDragboard();
         if (db.hasContent(Participant.dataFormat) && db.hasContent(Participant.dataFormat_linelistUUID)) {
            if (db.hasContent(Participant.dataFormat_delete)) {
               dragEvt.acceptTransferModes(REMOVE_FROM_SHORTCUT);
            }
            if (db.hasContent(Participant.dataFormat_add)) {
               dragEvt.acceptTransferModes(TransferMode.LINK);
            }
         }
      });


   }
}
