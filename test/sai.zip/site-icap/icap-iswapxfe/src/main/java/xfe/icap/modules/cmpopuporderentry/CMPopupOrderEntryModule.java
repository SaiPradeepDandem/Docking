package xfe.icap.modules.cmpopuporderentry;

import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.WeakListChangeListener;
import javafx.scene.Node;
import org.controlsfx.control.PopOver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.Util;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.ordersdata.DataMode;
import xfe.icap.modules.ordersdata.OrdersDataModule;
import xfe.icap.modules.ordersdata.OrderEntryData;
import xfe.icap.modules.ordersdata.OrderFilters;
import xfe.icap.modules.ordersui.OrdersViewUIModule;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.module.Module;
import xfe.modules.actions.MyOrdersArgs;
import xfe.modules.actions.PopupOrderEntryArgs;
import xfe.modules.session.SessionScopeModule;
import xfe.types.OrdersTrans;
import xfe.types.SecBoardStaticInfo;
import xfe.ui.popover.XfePopOver;
import xfe.util.EasyFXML;
import xstr.session.ObservableReplyRow;
import xstr.session.ServerSession;
import xstr.session.XtrTransReply;
import xstr.types.OrderEvent;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.function.Predicate;

@Module.Autostart
public class CMPopupOrderEntryModule  extends SessionScopeModule {
   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @ModuleDependency
   public OrdersDataModule ordersDataModule;

   @ModuleDependency
   public SecTabsUIModule secTabsUIModule;

   @ModuleDependency
   public OrdersViewUIModule ordersViewUIModule;

   private static final Logger log = LoggerFactory.getLogger(CMPopupOrderEntryModule.class);

   private final ListChangeListener<ObservableReplyRow> observableReplyRowListChangeListener =
      c -> {
         while (c.next()) {
            c.getAddedSubList().forEach(row -> {
               if (row.getValue(AmpManagedOrder.orderEvent) == OrderEvent.rangeLimit) {
                  OrderSide side = row.getValue(AmpManagedOrder.buySell) == AmpOrderVerb.sell ? OrderSide.SELL : OrderSide.BUY;
                  // we need to find the new CM price for that seccode
                  securitiesDataModule.retrieveSecBoardTrim2(row.getValue(AmpManagedOrder.secCode)).map(queryReplyRow -> {

                     this.changedCmPrice = queryReplyRow.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
                     if (this.changedCmPrice != null) {
                        Boolean isPriceReversal = queryReplyRow.getValue(AmpIcapSecBoardTrim2.doPriceReversal);
                        PopupOrderEntryArgs args = new PopupOrderEntryArgs(row, null, side, isPriceReversal, PopupOrderEntryArgs.DefaultOn.PRICE);
                        showPopupCMOrderAmend(args);
                     }
                     return Future.SUCCESS;
                  });
               }
            });
         }
      };

   private final InvalidationListener listener = c -> {
      if (configurationModule.getData().popupOnCMPriceChangeProperty().get())
         ordersDataModule.getSystemReferredOrders().addListener(observableReplyRowListChangeListener);
      else
         ordersDataModule.getSystemReferredOrders().removeListener(observableReplyRowListChangeListener);
   };

   @Override
   public Future<Void> startModule() {
      secTabsUIModule.setEnterCMOrdersHandler(this::showPopupCMOrderEntry);
      secTabsUIModule.setAmendCMOrdersHandler(this::showPopupCMOrderAmend);
      ordersViewUIModule.setAmendCMOrdersHandler(this::showPopupCMOrderAmend);

      // Listening on order refers so as to allow re-popping up of the CM Amend dialog
      // if the cause for it was a change to the CM price
      if (configurationModule.getData().popupOnCMPriceChangeProperty().get()) {
         ordersDataModule.getSystemReferredOrders().addListener(observableReplyRowListChangeListener);
      }
      configurationModule.getData().popupOnCMPriceChangeProperty().addListener(listener);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      secTabsUIModule.setEnterCMOrdersHandler(null);
      secTabsUIModule.setAmendCMOrdersHandler(null);
      ordersViewUIModule.setAmendCMOrdersHandler(null);
      ordersDataModule.getSystemReferredOrders().removeListener(observableReplyRowListChangeListener);
      configurationModule.getData().popupOnCMPriceChangeProperty().removeListener(listener);
      return Future.SUCCESS;
   }

   private void showPopupCMOrderAmend(PopupOrderEntryArgs popupOrderEntryArgs) {
      final ObservableReplyRow row = popupOrderEntryArgs.getRow();
      String secCode;
      String boardId;
      Integer buySellInd = AmpOrderVerb.buy;
      BigDecimal cmOrderPrice;
      Function<Number, String> priceFormatter;

      if (Util.canHandle(AmpIcapSecBoardTrim2.req, row)) {
         secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
         cmOrderPrice = row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
         priceFormatter = securitiesDataModule.getStaticInfo(row).priceFormatter;
      } else {
         secCode = row.getValue(AmpManagedOrder.secCode);
         boardId = row.getValue(AmpManagedOrder.boardId);
         buySellInd = row.getValue(AmpManagedOrder.buySell);
         cmOrderPrice = row.getValue(AmpManagedOrder.price);
         try {
            SecBoardStaticInfo info = securitiesDataModule.getStaticInfo(secCode, boardId).get();
            priceFormatter = info.priceFormatter;
         } catch (Exception e) {
            priceFormatter = null;
         }
      }

      if (priceFormatter == null) {
         log.warn("Fail to load priceFormatter from SecBoardStaticInfo");
         priceFormatter = xstr.util.Util.getDefaultFormatter();
      }

      // only open CM renew dialog if this user has an order
      if (popupOrderEntryArgs.getNode() == null &&
         !activeSessionModule.getSession().get().getLoggedOnUserId().equals(row.getValue(AmpManagedOrder.userId))){
         return;
      }

      Boolean isSpreadReversal = popupOrderEntryArgs.getIsPriceReversal();
      // if this is a sell order then price may need negating
      BigDecimal cmPrice = cmOrderPrice;
      if (buySellInd.equals(AmpOrderVerb.sell) && Boolean.TRUE.equals(isSpreadReversal)) {
         cmOrderPrice = cmOrderPrice.negate();
         cmPrice = cmOrderPrice;
      }

      OrderEntryData orderEntryData = new OrderEntryData();

      orderEntryData.setSecCode(secCode);
      orderEntryData.setBoardId(boardId);
      orderEntryData.setSide(popupOrderEntryArgs.getSide());

      if (changedCmPrice != null && popupOrderEntryArgs.getNode() == null)
         cmPrice = changedCmPrice;

      orderEntryData.setPrice(cmPrice);
      orderEntryData.setOrderPrice(cmOrderPrice);
      orderEntryData.setIsAllOrNone(false);
      orderEntryData.setIsIceberg(false);
      orderEntryData.setActionOnLogoff(configurationModule.getData().onLogoffActionProperty().get());
      orderEntryData.setIsShared(configurationModule.getData().sharedOrdersProperty().get());
      orderEntryData.setIsTopcut(configurationModule.getData().topCutProperty().get());
      orderEntryData.setIsDark(true);
      orderEntryData.setIsPriceReversal(isPriceReversal(isSpreadReversal));

      CMPopupOrderAmend pane = EasyFXML.load(CMPopupOrderAmend.class);

      pane.setMyOrdersGetter(this::getMyOrders);
      pane.setMyFirmsOrdersGetter(this::getMyFirmsOrders);

      String priceFormatted = priceFormatter.apply(BigDecimal.valueOf(Double.parseDouble(cmPrice.toString())));
      orderEntryData.setPriceFormatted(priceFormatted);

      pane.setAddOrdersListenerHandler(observableReplyRowListChangeListener -> {
         final ObservableList<ObservableReplyRow> allOrders = this.ordersDataModule.getAllOrders();
         allOrders.addListener(new WeakListChangeListener<>(observableReplyRowListChangeListener));
      });


      pane.setSession(activeSessionModule.getSession());

      /* Setting handlers to withdraw the open orders for the provided secCode & order side. */
      withdrawHandler = withdrawData -> withdrawHandler(withdrawData, activeSessionModule.getSession().get());
      pane.setCMOrderHandler(this::onCMBidOffer);
      pane.setWithdrawHandler(withdrawHandler);
      pane.setColleagueWithdrawHandler(withdrawData -> colleagueWithdrawHandler(withdrawData, activeSessionModule.getSession().get()));

      if (popupOrderEntryArgs.getNode() != null) {
         orderEntryData.setDataMode(DataMode.AMEND);
         pane.setup(orderEntryData);
         pane.setCloseHandler(midiLayoutModule::closePopOverWindow);
         final XfePopOver popOver = XfePopOver.instance(midiLayoutModule);
         popOver.setArrowLocation(PopOver.ArrowLocation.TOP_CENTER);
         pane.setPopover(popOver);
         popOver.setHeaderAlwaysVisible(true);
         popOver.setContentNode(pane.getRoot());

         popOver.setTitle("CM Order Manager");

         midiLayoutModule.closePopOverWindow(XfePopOver.ID_PREFIX + popOver.getTitle());
         popOver.showSafely(popupOrderEntryArgs.getNode());

      } else {
         orderEntryData.setDataMode(DataMode.RENEW);
         priceFormatted = priceFormatter.apply(BigDecimal.valueOf(Double.parseDouble(cmPrice.toString())));
         orderEntryData.setPriceFormatted(priceFormatted);
         pane.setup(orderEntryData);
         pane.setCloseHandler(midiLayoutModule::closePopupStage);
         pane.showRenewMessage(popupOrderEntryArgs.getSide(), priceFormatted);
         Node root = pane.getRoot();
         OrderSide side = orderEntryData.getSide();
         root.setId(side.equals(OrderSide.BUY) ? MidiLayoutViews.CM_ORDER_RENEW_BID + " " + secCode : MidiLayoutViews.CM_ORDER_RENEW_OFFER + " " + secCode);
         midiLayoutModule.addView(root);
      }
   }

   private boolean isPriceReversal(Boolean isSpreadReversal) {
      return isSpreadReversal != null && isSpreadReversal;
   }

   private Future<XtrTransReply> onCMBidOffer(CMOrderData cmOrderData) {
      AtomicReference<XtrTransReply> orderExecResponse  = new AtomicReference<>();
      activeSessionModule.getSession().ifPresent(session -> {
         final OrderSide side = cmOrderData.getSide().equals(OrderSide.BUY) ? OrderSide.SELL : OrderSide.BUY;
         withdrawHandler.apply(new OrderWithdrawData(cmOrderData.getSecCode(), cmOrderData.getCmPrice(), side, true)).onDone(
            tr -> {
               List<XtrTransReply> replyList = null;
               try {
                  replyList = tr.get();
               } catch (Exception e){
                  log.info("Withdraw CM order : failed to retrieve the transaction response");
               }
               changedCmPrice = null;
               if(replyList == null)
                  return Future.SUCCESS;
               boolean successfulWithdraw = true;
               for (XtrTransReply aReplyList : replyList) {
                  XtrTransReply.Status replyStatus = aReplyList.getStatus();
                  if (!replyStatus.isSuccess()) {
                     successfulWithdraw = false;
                  }
               }
               if(!successfulWithdraw)
                  return Future.SUCCESS;
               orderExecResponse.set(cmOrderData.getOrderTrans().executeBuySell(session,
                  cmOrderData.getSide().equals(OrderSide.BUY) ? AmpOrderVerb.buy : AmpOrderVerb.sell).get());
               return Future.SUCCESS;
            });
      });
      return Future.valueOf(orderExecResponse.get());
   }

   private Future<List<XtrTransReply>> withdrawHandler(OrderWithdrawData withdrawData, ServerSession serverSession) {
      ObservableList<ObservableReplyRow> orders;
      if (changedCmPrice == null || withdrawData.getAutoWithdraw())
         orders = ordersDataModule.getOpenOrdersBuilder().ofSec(withdrawData.getSecCode()).own().isCM().inSide(withdrawData.getSide()).build();
      else
         orders = ordersDataModule.getSysRefOrdersBuilder().ofSec(withdrawData.getSecCode()).own().isCM().inSide(withdrawData.getSide()).build();
      return withdrawOrdersHelper(orders, withdrawData, serverSession);
   }



   private Future<List<XtrTransReply>> colleagueWithdrawHandler(OrderWithdrawData withdrawData, ServerSession serverSession) {
      ObservableList<ObservableReplyRow> orders;
      OrderSide ordSide = withdrawData.getSide();
      String secCode = withdrawData.getSecCode();
      if (changedCmPrice == null)
         orders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).colleagues().isCM().inSide(ordSide).build();
      else
         orders = ordersDataModule.getSysRefOrdersBuilder().ofSec(secCode).isNotOwn().isCM().inSide(ordSide).build();

      return withdrawOrdersHelper(orders, withdrawData, serverSession);
   }

   private Future<List<XtrTransReply>> withdrawOrdersHelper(ObservableList<ObservableReplyRow> orders, OrderWithdrawData withdrawData, ServerSession serverSession) {
      List<Future<XtrTransReply>> withdrawResults = new ArrayList<>();
      if (!orders.isEmpty()) {
         for (ObservableReplyRow orderRow : orders) {
            if (orderRow.getValue(AmpManagedOrder.price).abs().compareTo(withdrawData.getCmPrice().abs()) == 0 &&
               orderRow.getValue(AmpManagedOrder.isDoneIfTouched)) {
               withdrawResults.add(OrdersTrans.withdrawByOrderId(serverSession, orderRow.getAsn(AmpManagedOrder.currentOrderId)));
            }
         }
      }
      return Futures.collect(withdrawResults);
   }

   private void showPopupCMOrderEntry(PopupOrderEntryArgs popupOrderEntryArgs) {
      ObservableReplyRow row = popupOrderEntryArgs.getRow();
      String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);

      BigDecimal price = row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
      BigDecimal defaultQty = row.getValue(AmpIcapSecBoardTrim2.defaultQty);
      if (defaultQty == null) {
         defaultQty = BigDecimal.valueOf(getDefaultQtyBySecClassId(row.getValue(AmpIcapSecBoardTrim2.secClassId)));
      }

      OrderEntryData orderEntryData = new OrderEntryData();
      orderEntryData.setDataMode(DataMode.ENTRY);
      orderEntryData.setSecCode(secCode);
      orderEntryData.setBoardId(boardId);
      orderEntryData.setSide(popupOrderEntryArgs.getSide());
      orderEntryData.setPrice(price);
      orderEntryData.setIsAllOrNone(false);
      orderEntryData.setIsIceberg(false);
      orderEntryData.setBalance(BigDecimal.ZERO);
      orderEntryData.setQty(defaultQty);
      orderEntryData.setActionOnLogoff(configurationModule.getData().onLogoffActionProperty().get());
      orderEntryData.setIsShared(configurationModule.getData().sharedOrdersProperty().get());
      orderEntryData.setIsTopcut(configurationModule.getData().topCutProperty().get());
      orderEntryData.setIsDark(true);
      orderEntryData.setIsPriceReversal(securitiesDataModule.isSpreadForPriceReversal(row));

      CMPopupOrderEntry pane = EasyFXML.load(CMPopupOrderEntry.class);
      pane.setup(orderEntryData);
      pane.setCloseHandler(midiLayoutModule::closePopOverWindow);
      withdrawHandler = withdrawData -> withdrawHandler(withdrawData,activeSessionModule.getSession().get());
      pane.setCMOrderHandler((this::onCMBidOffer));
      final XfePopOver popOver = XfePopOver.instance(midiLayoutModule);
      popOver.setArrowLocation(PopOver.ArrowLocation.TOP_CENTER);
      pane.setPopover(popOver);
      popOver.setHeaderAlwaysVisible(true);
      popOver.setContentNode(pane.getRoot());
      popOver.setTitle(secCode.replaceFirst("(UKT )*", ""));
      midiLayoutModule.closePopOverWindow(XfePopOver.ID_PREFIX + popOver.getTitle());
      popOver.showSafely(popupOrderEntryArgs.getNode());
   }

   private Double getDefaultQtyBySecClassId(Integer secClassId) {
      return midiLayoutModule.getDefaultQuantity(secClassId);
   }

   private ObservableList<ObservableReplyRow> getMyOrders(MyOrdersArgs args, boolean referredIncluded) {
      final String secCode = args.getSecCode();

      return activeSessionModule.getSession().map(session -> {
         final String userId = session.getLoggedOnUserId();

         Predicate<ObservableReplyRow> orderRowFilter =
            OrderFilters.matchSecCode(secCode)
               .and(OrderFilters.matchUserID(userId))
               .and(OrderFilters.matchOpenOrder().or(OrderFilters.matchAmendedOrder()).or(OrderFilters.matchReferredOrder()));

         if (!referredIncluded)
            orderRowFilter = orderRowFilter.and(OrderFilters.matchReferredOrder().negate());
         return ordersDataModule.getFilteredOrders(orderRowFilter);
      }).orElse(FXCollections.emptyObservableList());
   }

   private ObservableList<ObservableReplyRow> getMyFirmsOrders(MyOrdersArgs args) {
      final String secCode = args.getSecCode();

      return activeSessionModule.getSession().map(session -> {
         final String userId = session.getLoggedOnUserId();
         final String firmId = session.getLoggedOnUserFirmId();

         final Predicate<ObservableReplyRow> orderRowFilter =
            OrderFilters.matchSecCode(secCode)
               .and(OrderFilters.notMatchUserID(userId))
               .and(OrderFilters.matchFirmID(firmId))
               .and(OrderFilters.matchOpenOrder()
                  .or(OrderFilters.matchAmendedOrder()));

         return ordersDataModule.getFilteredOrders(orderRowFilter);
      }).orElse(FXCollections.emptyObservableList());
   }

   private BigDecimal changedCmPrice = null; // this represents the changed cm price value causing the dark order to get referred
   private Function <OrderWithdrawData, Future<List<XtrTransReply>>> withdrawHandler;
}
