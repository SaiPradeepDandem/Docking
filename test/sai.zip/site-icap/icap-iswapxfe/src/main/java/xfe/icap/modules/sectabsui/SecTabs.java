package xfe.icap.modules.sectabsui;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;

import static xfe.icap.modules.layout.midi.MidiLayoutViews.INSTR_TABS;

public class SecTabs extends TabPane {


   SecTabs() {
      setId(INSTR_TABS);
      getStyleClass().add("instruments-tab-pane");
   }

   void addTab(Tab t) {
      super.getTabs().add(t);

   }

   void addTab(int location, Tab t) {
      super.getTabs().add(location, t);
   }

   // TODO: Should tabs be removed by ID or object?
   void removeTab(Tab t) {
      super.getTabs().remove(t);
   }


   private TabPane root;
}
