package xfe.icap.amp;

import com.objsys.asn1j.runtime.Asn1BerDecodeBuffer;
import com.objsys.asn1j.runtime.Asn1BerEncodeBuffer;
import com.objsys.asn1j.runtime.Asn1Choice;
import com.objsys.asn1j.runtime.Asn1Exception;
import com.omxgroup.xstream.api.MarshalError;

public class AmpDeepCopy {
   AmpDeepCopy() {
   }

   public static Asn1Choice copy(Asn1Choice from) throws MarshalError {
      if (from != null) {
         Asn1Choice to = null;
         try {
            to = from.getClass().newInstance();
         } catch (InstantiationException | IllegalAccessException e) {
            throw new MarshalError(e.getMessage(), e);
         }
         if (to != null) {
            copy(from, to, new Asn1BerEncodeBuffer());
            return to;
         } else return null;
      } else {
         return null;
      }
   }

   private static void copy(Asn1Choice from, Asn1Choice to, Asn1BerEncodeBuffer ebuf) throws MarshalError {
      try {
         if (from != null && to != null) {
            from.encode(ebuf, true);
            Asn1BerDecodeBuffer dbuf = new Asn1BerDecodeBuffer(ebuf.getInputStream());
            to.decode(dbuf, true, 0);
         }
      } catch (Asn1Exception var4) {
         throw new MarshalError(var4.getMessage(), var4);
      } catch (Exception e) {
         throw new MarshalError(e.getMessage(), e);
      }
   }
}
