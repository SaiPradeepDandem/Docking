package xfe.icap.modules.cmpopuporderentry;

import xfe.icap.types.AbstractOrderTrans;
import xstr.types.OrderSide;

import java.math.BigDecimal;

/**
 * Created by soopot on 4/10/2019.
 *
 * @author Sooraj Pottekat
 */
public class CMOrderData {
   private final AbstractOrderTrans orderTrans;
   private final String secCode;
   private final BigDecimal cmPrice;
   private final OrderSide side;

   public CMOrderData(String secCode, BigDecimal cmPrice, OrderSide side, AbstractOrderTrans orderTrans) {
      this.secCode = secCode;
      this.cmPrice = cmPrice;
      this.side = side;
      this.orderTrans = orderTrans;
   }

   public AbstractOrderTrans getOrderTrans() {
      return orderTrans;
   }

   public String getSecCode() {
      return secCode;
   }

   public BigDecimal getCmPrice() {
      return cmPrice;
   }

   public OrderSide getSide() {
      return side;
   }
}
