/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xfe.icap.types;

import xstr.amp.AMP.AmpQrep;
import xstr.amp.AmpService;
import xstr.amp.AsnAccessor;
import xfe.icap.amp.AmpPickMatchingOrder;
import xstr.session.XtrTransRequestBuilder;
import xstr.session.XtrTransRequest;
import xfe.types.Identifier;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpOrderBookByOrder;
import xstr.session.ObservableReplyRow;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.util.Date;


/**
 *
 * @author KEWA
 */
public class OrderBookOrder extends Order{
    private static final Logger logger = LoggerFactory.getLogger(ManagedOrder.class);
    private final ObservableReplyRow data;

    public static final String req = "orderbookByOrderReq";
    public static final String rep = "orderbookByOrderRep";

    @Deprecated // Use accessors defined in AmpOrderBookByOrder instead
    public enum Member implements Identifier<AmpQrep> {
        ORDER_ID(rep + ".order.orderId");

        private final AmpQrep fieldId;
        private final AsnAccessor accessor;

        Member(String id) {
            fieldId = new AmpQrep(id);
            accessor = AmpService.INSTANCE.getAccessor(fieldId);
        }

        @Override
        public AmpQrep getId(){
            return fieldId;
        }

        public AsnAccessor getAccessor() {
            return accessor;
        }

    }

    public OrderBookOrder(ObservableReplyRow row) {
        super(row.getAsn(Member.ORDER_ID.accessor));
        this.data = row;
    }

    @Override
    public String getUserId() {
        return data.getValue(AmpOrderBookByOrder.userId);
    }


    @Override
    public boolean canRenew() {
        //order book orders are always active orders
        return false;
    }

    @Override
    public String getOperatorId() {
    	return data.getValue(AmpOrderBookByOrder.operatorId);
    }

    @Override
    public String getIntroBrokerId(){
       return data.getValue(AmpOrderBookByOrder.introBrokerId);
    }

    @Override
    public String getOrderType() {
    	return data.getValue(AmpOrderBookByOrder.specialOrderType);
    }

	public ObservableReplyRow getData() {
		return data;
	}

	@Override
	public boolean canWithdraw() {
		return false;
	}

	public Double getPrice() {
		return data.getValue(AmpOrderBookByOrder.price);
    }

	public Double getQuantity() {
		return data.getValue(AmpOrderBookByOrder.quantity);
    }

	@Override
	public boolean isManaged() {
        return true;
	}

   public void pickedup(XfeSession xfeSession, String secCode, String boardId) throws AsnTypeException, AmpPermissionException {
      long orderNo = data.getValue(AmpOrderBookByOrder.orderNo);
      Date orderDate = data.getValue(AmpOrderBookByOrder.orderDate);
      int buysell = data.getValue(AmpOrderBookByOrder.buySell);
      buysell = (buysell == AmpOrderVerb.buy) ? AmpOrderVerb.sell : AmpOrderVerb.buy;
      XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder
            .create(AmpPickMatchingOrder.txn, xfeSession.getUnderlyingSession())
            .set(AmpPickMatchingOrder.orderNo, orderNo).set(AmpPickMatchingOrder.orderDate, orderDate)
            .set(AmpPickMatchingOrder.buySell, buysell).set(AmpPickMatchingOrder.secCode, secCode)
            .set(AmpPickMatchingOrder.introBrokerId, xfeSession.getUnderlyingSession().onBehalfTraderIB.get())
            .set(AmpPickMatchingOrder.boardId, boardId);
      XtrTransRequest trans = reqBuilder.build();
      trans.setSubjectUser(xfeSession.getUnderlyingSession().onBehalfTraderId.get());
      xfeSession.getUnderlyingSession().execute(trans);
   }
}
