package xfe.icap.modules.settings;

import com.nomx.persist.*;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.modules.watchlist.Presets;
import xfe.module.Module;
import xfe.modules.appcontext.FxContext;
import xfe.modules.logon.LogonModule;
import xfe.modules.session.SessionScopeModule;
import xfe.types.ConfigHeaderInfo;
import xfe.types.SettingsRoot;
import xstr.session.AppConfig;
import xstr.session.ServerSession;
import xstr.types.AppConfigData;
import xstr.types.XtrBlob;
import xstr.util.Fun1Throws;
import xstr.util.concurrent.Disposer;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.exception.XtrSessionException;
import xstr.util.io.LocalStorage;

import java.io.*;
import java.util.*;

@Module.Autostart
public class ConfigurationModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(ConfigurationModule.class);

   @ModuleDependency
   public FxContext fxContextModule;

   @ModuleDependency
   public XfeSession xfeSessionModule;

   @ModuleDependency
   public LogonModule logonModule;

   private final HashMap<PersistantName, Serializable> userData = new HashMap<>();
   private final String userDataFilePrefix = "Workspace_";
   private String userDataFileName;
   private boolean updateWSVersion;
   private ParametersStorage parametersStorage;
   private boolean saveOnExit = true;

   ParametersStorage getOrigStorage() {
      return origStorageCopy;
   }

   public ObservableList<WatchlistSpec_v2> getWatchlists() {
      return data.getStorage().getList(PersistantName.WatchlistTabs, WatchlistSpec_v2.class, FXCollections.observableArrayList(Presets.PRESETS)).get();
   }

   public void setMMOpenAction(EventHandler<ActionEvent> handler) {
      data.setMMOpenAction(handler);
   }

   @Override
   public Future<Void> startModule() {
      Converters.registerConverter(OnLogoffActionConverter.INSTANCE);
      Converters.registerConverter(DefaultDurationTypeConverter.INSTANCE);
      initialise();
      if (xfeSessionModule.activeSessionModule.getSession().get().isAutoLoggedOn() && !data.unlockOnAutoLogonProperty().get())
         xfeSessionModule.activeSessionModule.lock(false);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      uninitializeContents();
      return Future.SUCCESS;
   }

   private void initialise() {
      saveOnExit = true;
      activeSessionModule.getSession().ifPresent(session -> {
         userDataFileName = userDataFilePrefix + session.getLoggedOnUserId().replace(" ", "_");
         updateWSVersion = session.getLoggedOnUserId().startsWith(xstr.session.Presets.DEFAULT);
      });

      ParametersStorage paramStorage = getParametersStorage();
      Map<PersistantName, Serializable> currentParameters ;
      if(ParametersStorage.TESTFX_DATA!=null){
         currentParameters = new HashMap<>();
         SettingsRoot.unmarshallJson(ParametersStorage.TESTFX_DATA).forEach(currentParameters::put);
      }else {
         Map<PersistantName, Serializable> teWS = loadRemoteAppConfig();
         Map<PersistantName, Serializable> localWS = loadLocalAppConfig();
         currentParameters = chooseLatest(teWS, localWS);
      }

      if (currentParameters != null) {
         Map<PersistantName, Serializable> userAppConfig = new HashMap<>(currentParameters);
         paramStorage.setAll(userAppConfig, null);
      }

      // OLD CODE
      origStorageCopy = paramStorage.clone(null);
      ObservableSet<String> allFirms = xfeSessionModule.mmFirms.get().firms.get();
      data = new SettingsData(paramStorage, activeSessionModule.getSession().get().getLoggedOnUser(), allFirms);
      getData().autoLogonEnabledProperty().addListener(this::updateAutoLogon);
      updateAutoLogon(getData().autoLogonEnabledProperty());
      getData().autoLogonTimeoutProperty().addListener(this::updateAutoLogonTime);
      updateAutoLogonTime(getData().autoLogonEnabledProperty());
   }

   public void save() {
      if (userDataFileName != null) {
         writeAppConfigToLocal();
         activeSessionModule.getSession().map(session -> writeAppConfigToServer());
         origStorageCopy = getParametersStorage().clone(null);
      }
   }

   private void uninitializeContents() {
      if (activeSessionModule.getSession().isPresent() && saveOnExit || data.autoSaveWorkspaceProperty().get()) {
         if (userDataFileName != null) {
            writeAppConfigToLocal();
            activeSessionModule.getSession().map(session -> writeAppConfigToServer());
         }
      }

      if (data != null) {
         data.setOpenTradeNotificationProp(null);
         data.setMMOpenAction(null);
         SettingsData disposeData = data;
         data = null;
         disposeData.dispose();
      }

      if (parametersStorage != null) {
         parametersStorage = null;
      }
      userData.clear();

      origStorageCopy = null;
   }

   public ParametersStorage getParametersStorage() {
      if (parametersStorage == null) {
         parametersStorage = new ParametersStorage(userData);
      }
      return parametersStorage;
   }

   private Map<PersistantName, Serializable> loadLocalAppConfig() {
      if (!LocalStorage.data.exists(userDataFileName)) {
         return null;
      }
      DataInputStream isDisk = null;
      ObjectInputStream oisDisk = null;
      try {
         isDisk = new DataInputStream(LocalStorage.data.openInputStream(userDataFileName));

         // Reading the header
         ConfigHeaderInfo header = new ConfigHeaderInfo();
         header.read(isDisk);

         // Analysing the header to choose the protocol
         if (header.getProtocol() == ConfigHeaderInfo.JAVA_SERIALIZATION) {
            oisDisk = new ObjectInputStream(isDisk);
            Object oDisk = oisDisk.readObject();

            if (oDisk instanceof HashMap<?, ?>) {
               @SuppressWarnings("unchecked") HashMap<PersistantName, Serializable> data = (HashMap<PersistantName, Serializable>) oDisk;
               return data;
            }
         } else if (header.getProtocol() == ConfigHeaderInfo.XML) {
            return SettingsRoot.unmarshall(isDisk);
         } else if (header.getProtocol() == ConfigHeaderInfo.JSON) {
            return SettingsRoot.unmarshallJson(isDisk);
         }
      } catch (IOException e) {
         logger.debug("loadDiskUserData failed - IO error", e);
      } catch (ClassNotFoundException e) {
         logger.error("loadDiskUserData failed - Class not found", e);
      } catch (RuntimeException e) {
         logger.error("loadDiskUserData failed - Runtime error", e);
      } finally {
         try {
            if (oisDisk != null) {
               oisDisk.close();
            }

            if (isDisk != null) {
               isDisk.close();
            }
         } catch (IOException e) {
            logger.error("loadDiskUserData - failed to close stream", e);
         }
      }

      return null;
   }

   private Map<PersistantName, Serializable> loadRemoteAppConfig() {

      return activeSessionModule.getSession().map(session -> {
         Map<PersistantName, Serializable> teUserData = null;
         // We check if there is information in the engine
         // and if so we get it
         try {
            if (!session.getAppConfig().isEmpty()) {
               // Reading the header
               DataInputStream isTe = new DataInputStream(new ByteArrayInputStream(session.getAppConfig().getData().toByteArray()));
               ConfigHeaderInfo header = new ConfigHeaderInfo();

               try {
                  header.read(isTe);
               } catch (IOException e) {
                  logger.warn("Unable to load user data header - IO error: {}", e.getMessage());
               }

               if (header.getProtocol() == ConfigHeaderInfo.JAVA_SERIALIZATION) {
                  ObjectInputStream oisTe = new ObjectInputStream(isTe);
                  Object oTe = oisTe.readObject();

                  if (oTe instanceof HashMap<?, ?>) {
                     @SuppressWarnings("unchecked") HashMap<PersistantName, Serializable> data = (HashMap<PersistantName, Serializable>) oTe;
                     teUserData = data;
                  }

                  oisTe.close();
               } else if (header.getProtocol() == ConfigHeaderInfo.XML) {
                  logger.debug("Reading settings in XML format");
                  return SettingsRoot.unmarshall(isTe);
               } else if (header.getProtocol() == ConfigHeaderInfo.JSON) {
                  logger.debug("Reading settings in JSON format");
                  return SettingsRoot.unmarshallJson(isTe);
               }

               isTe.close();
            }
         } catch (IOException e) {
            logger.warn("Unable to load user data from server - IO error: {}", e);
         } catch (ClassNotFoundException e) {
            logger.warn("Unable to load user data from server - Class not found: {}", e);
         } catch (RuntimeException e) {
            logger.warn("Unable to load user data from server - Runtime error: {}", e);
         }

         return teUserData;
      }).orElse(null);
   }

   private Future<Void> writeAppConfigToServer() {
      return activeSessionModule.getSession().map(s -> {
         Disposer disposer = new Disposer();
         // Saving the header1
         ByteArrayOutputStream os = disposer.disposes(new ByteArrayOutputStream());
         writeAppConfigToStream(os, null);
         XtrBlob data = XtrBlob.valueOf(os);
         disposer.dispose();
         return s.saveAppConfig(data);
      }).orElse(Futures.error(new XtrSessionException("No server")));
   }

   Future<Void> writeUserPresetToServer(String presetId, Map<PersistantName, Serializable> val) {
      return activeSessionModule.getSession().map(s -> {
         Disposer disposer = new Disposer();
         val.put(PersistantName.PRESET, presetId);
         // Saving the header
         ByteArrayOutputStream os = disposer.disposes(new ByteArrayOutputStream());
         writeAppConfigToStream(os, val);
         XtrBlob data = XtrBlob.valueOf(os);
         disposer.dispose();
         return s.saveUserPreset(data, presetId);
      }).orElse(Futures.error(new XtrSessionException("No server")));
   }

   private void writeAppConfigToLocal() {
      // Just save it locally as well...
      try (OutputStream os = LocalStorage.data.openOutputStream(userDataFileName, true)) {
         writeAppConfigToStream(os, null, activeSessionModule.getSession().isPresent() ? activeSessionModule.getSession().get().getLogginhOffTime() : new Date() );
      } catch (IOException e) {
         logger.warn("Unable to write local user data to {}", userDataFileName);
      }
   }

   private void writeAppConfigToStream(OutputStream outputStream, Map<PersistantName, Serializable> val, Date current) {
      ParametersStorage storage;
      if (val == null) {
         storage = getParametersStorage();
      } else {
         storage = new ParametersStorage(val);
      }

      storage.get(PersistantName.TIMESTAMP_KEY, Date.class, (Date) null).set(current);

      if (updateWSVersion) {
         storage.get(PersistantName.WorkSpaceVersion, Double.class, (Double) null).set((double) fxContextModule.getWsVersion());
      }

      writeAppConfigToStream(val == null ? userData : val, outputStream);
   }

   public void writeAppConfigToStream(OutputStream outputStream, Map<PersistantName, Serializable> val) {
      writeAppConfigToStream(outputStream, val, activeSessionModule.getSession().get().getStats().getEngineTime());
   }

   private void writeAppConfigToStream(Map<PersistantName, Serializable> data, OutputStream outputStream) {
      Disposer disposer = new Disposer();
      Date current = (Date) data.get(PersistantName.TIMESTAMP_KEY);
      try {
         // Saving the header
         DataOutputStream dos = disposer.disposes(new DataOutputStream(outputStream));
         dos.writeLong(ConfigHeaderInfo.CURRENT_PROTOCOL);
         dos.writeLong(current == null ? 0L : current.getTime());
         dos.writeLong(0L);

         SettingsRoot.marshall(data, outputStream);
      } catch (Exception e) {
         logger.error("Saving user data to local storage failed: {}", e.getMessage());
      } finally {
         disposer.dispose();
      }
   }

   public void eraseAppConfig() {
      Disposer disposer = new Disposer();
      eraseLocalAppConfig();
      activeSessionModule.getSession().ifPresent(session -> {
         try {
            ByteArrayOutputStream os = disposer.disposes(new ByteArrayOutputStream());
            writeAppConfigToStream(new HashMap<>(), os);
            session.saveAppConfig(XtrBlob.valueOf(os));
         } catch (Exception e) {
            logger.error("Unable to erase settings: ", e);
         } finally {
            disposer.dispose();
         }
      });
   }

   private static Future<Map<PersistantName, Serializable>> loadUserPresetAppConfigData(ServerSession primarySession, String presetId) {
      // We check if there is information in the engine and if so we get it
      return primarySession.getUserPresetAppConfig(presetId).onSuccess(ConfigurationModule::getAppConfigData);
   }

   private static Future<Map<PersistantName, Serializable>> loadPresetAppConfig(ServerSession primarySession, String presetId) {
      // We check if there is information in the engine and if so we get it
      Future<AppConfig> f = primarySession.getPresetAppConfig(presetId);
      long t0 = System.nanoTime() / 1000000;
      return f.onSuccess((Fun1Throws<AppConfig, Map<PersistantName, Serializable>>) val -> {
         logger.debug("loadPresetAppConfig cost time: {}ms", System.nanoTime() / 1000000 - t0);
         return getAppConfigData(val);
      });
   }

   private static Map<PersistantName, Serializable> getAppConfigData(AppConfig val)
      throws IOException, ClassNotFoundException {
      if (val == null) return null;
      AppConfigData presetAppConfig = val.getAppData();
      Map<PersistantName, Serializable> presetMap = new HashMap<>();

      if (presetAppConfig != null && !presetAppConfig.isEmpty()) {
         // Reading the header
         DataInputStream isTe = new DataInputStream(new ByteArrayInputStream(presetAppConfig.getData().toByteArray()));
         ConfigHeaderInfo header = new ConfigHeaderInfo();
         header.read(isTe);

         // Analysing the header to choose the protocol
         if (header.getProtocol() == ConfigHeaderInfo.JAVA_SERIALIZATION) {
            ObjectInputStream oisTe = new ObjectInputStream(isTe);
            Object oTe = oisTe.readObject();

            if (oTe instanceof HashMap<?, ?>) {
               @SuppressWarnings("unchecked") HashMap<PersistantName, Serializable> data = (HashMap<PersistantName, Serializable>) oTe;
               presetMap.putAll(data);
            }

            oisTe.close();
         } else if (header.getProtocol() == ConfigHeaderInfo.XML) {
            presetMap.putAll(SettingsRoot.unmarshall(isTe));
         } else if (header.getProtocol() == ConfigHeaderInfo.JSON) {
            presetMap.putAll(SettingsRoot.unmarshallJson(isTe));
         }

         isTe.close();
      }
      return presetMap;
   }

   final Future<Map<PersistantName, Serializable>> loadUserPresetAppConfigData(String presetId) {
      return activeSessionModule.getSession().map(s -> loadUserPresetAppConfigData(s, presetId))
         .orElse(Future.valueOf(Collections.EMPTY_MAP));
   }

   final Future<Map<PersistantName, Serializable>> loadPresetAppConfig(String presetId) {
      return activeSessionModule.getSession().map(s -> loadPresetAppConfig(s, presetId))
         .orElse(Future.valueOf(Collections.EMPTY_MAP));
   }

   private void eraseLocalAppConfig() {
      LocalStorage.data.remove(userDataFileName);
   }

   public SettingsData getData() {
      return data;
   }

   void setUpdateWSVersion(boolean b) {
      updateWSVersion = b;
   }

   void setSaveOnExit(boolean saveOnExit) {
      this.saveOnExit = saveOnExit;
   }


   private static Map<PersistantName, Serializable> chooseLatest(Map<PersistantName, Serializable> input1, Map<PersistantName, Serializable> input2) {
      Date date1 = (Date) (input1 != null ? input1.get(PersistantName.TIMESTAMP_KEY) : null);
      Date date2 = (Date) (input2 != null ? input2.get(PersistantName.TIMESTAMP_KEY) : null);

      System.out.println("Remote WS time is: " + date1);
      System.out.println("Local WS time is: " + date2);

      if (date2 != null && (date1 == null || date2.compareTo(date1) > 0)) {
         System.out.println("Loading local WS");
         return input2;
      } else {
         System.out.println("Loading remote WS");
         return input1;
      }
   }

   private void updateAutoLogon(Observable o) {
      logonModule.setAutoLogon(getData().autoLogonEnabledProperty().get());
   }

   private void updateAutoLogonTime(Observable o) {
      logonModule.setAutoLogonTime(getData().autoLogonTimeoutProperty().get());
   }

   private ParametersStorage origStorageCopy;
   private SettingsData data;
}
