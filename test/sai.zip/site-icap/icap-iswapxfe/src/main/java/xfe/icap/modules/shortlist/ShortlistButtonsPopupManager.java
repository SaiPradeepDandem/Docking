package xfe.icap.modules.shortlist;

import javafx.beans.property.IntegerProperty;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import org.controlsfx.control.PopOver;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.popover.PopOverModule;
import xfe.icap.modules.sectabsui.SecTable;
import xfe.ui.popover.XfePopOver;
import xfe.ui.window.IndependentWindow;
import xfe.ui.window.IndependentWindowArgs;
import xfe.ui.window.ManagedXfeWindow;
import xstr.util.Fx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Popup & PopOver manager class for stock selection buttons functionality.
 */
public class ShortlistButtonsPopupManager {
   private static double ARROW_SIZE = 12.0;
   private static double SHADOW_EFFECT_FACTOR = 4;
   private Supplier<MidiLayoutModule> midiLayoutModuleSupplier;
   private Supplier<ShortlistButtonsViewUIModule> shortListButtonsViewUIModuleSupplier;
   private Map<String, ManagedXfeWindow> popupMap = new HashMap<>();
   private final PopOverModule popOverModule;
   private EventHandler<WindowEvent> hidingHandler = e -> {
      Stage window = (Stage) e.getTarget();
      popupMap.remove(window.getTitle());
   };

   public void setMidiLayoutModuleSupplier(Supplier<MidiLayoutModule> midiLayoutModuleSupplier) {
      this.midiLayoutModuleSupplier = midiLayoutModuleSupplier;
   }

   public void setShortListButtonsViewUIModuleSupplier(Supplier<ShortlistButtonsViewUIModule> shortListButtonsViewUIModuleSupplier) {
      this.shortListButtonsViewUIModuleSupplier = shortListButtonsViewUIModuleSupplier;
   }

   private EventHandler<ScrollEvent> scrollEventEventHandler;

   public ShortlistButtonsPopupManager(PopOverModule popOverModule) {
      this.popOverModule = popOverModule;
   }

   private XfePopOver currentPopOver;

   /**
    * Shows the popOver for the given owner node.
    *
    * @param button    Owner node for the popOver
    * @param content   Content inside the popOver
    * @param zoomLevel Zoom level to set
    */
   public void showPopOver(Button button, SecTable content, IntegerProperty zoomLevel) {
      final String id = button.getId();
      final Stage oldStage = popupMap.get(id);
      if (oldStage != null) {
         oldStage.close();
         popupMap.remove(id);
      }

      StackPane container = new StackPane();
      container.addEventFilter(ScrollEvent.SCROLL, scrollEventEventHandler);
      container.setPadding(new Insets(2, 1, 0, 1)); // Setting the padding for allowing the popover shadow effect
      container.getChildren().add(content);

      final Scene scene = button.getScene();
      final Bounds boundsInLocal = button.getBoundsInLocal();
      final Bounds boundsInScreen = button.localToScreen(boundsInLocal);
      final Bounds boundsInScene = button.localToScene(boundsInLocal);
      final Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

      final double x = scene.getWindow().getX() /*+ SHADOW_EFFECT_FACTOR*/;
      final double y = boundsInScreen.getMinY() + boundsInLocal.getHeight() - 6;
      final double w = scene.getWidth() - (SHADOW_EFFECT_FACTOR * 2) - 10;
      double h = scene.getHeight() - boundsInScene.getMinY() - boundsInLocal.getHeight() - 15 - (SHADOW_EFFECT_FACTOR * 2);
      // If the scene is moved below the screen bounds, showing the popover only for the visual bounds.
      if ((y + h) > primaryScreenBounds.getHeight()) {
         h = primaryScreenBounds.getHeight() - y - boundsInLocal.getHeight();
      }
      final double indent = button.getLayoutX() + ((boundsInLocal.getWidth() / 2) - ARROW_SIZE) - (SHADOW_EFFECT_FACTOR * 2);

      final XfePopOver popOver = XfePopOver.instance(popOverModule);
      popOver.setArrowSize(ARROW_SIZE);
      popOver.setTitle("");
      popOver.setArrowLocation(PopOver.ArrowLocation.TOP_LEFT);
      popOver.setArrowIndent(indent);
      popOver.setHeaderAlwaysVisible(true);
      popOver.setContentNode(container);
      popOver.setHideHandler(() -> currentPopOver = null);
      popOver.showSafely(button, x, y);
      currentPopOver = popOver;

      // After showing the popOver applying the zoom styling
      applyZoom(content, zoomLevel.getValue());

      // TWEAK FOR A BUG IN POPOVER CONTROL (the minSize binding is wrong in PopOverSkin implementation)
      // This code has top be placed after popOver.show() call only !!
      final StackPane popOverRoot = popOver.getRoot();
      popOverRoot.minHeightProperty().unbind();
      popOverRoot.minWidthProperty().unbind();
      popOverRoot.setMinSize(w, h);
      popOverRoot.setMaxSize(w, h);
      Fx.runLater(() -> {
         Fx.runLater(() -> { // Double Fx.runLater is a tweak for showing the popup in correct place when window size is big and have many buttons.
            final Window popOverWindow = popOver.getScene().getWindow();
            popOverWindow.setX(x);
            popOverWindow.setY(y);
         });
      });
      // END OF TWEAK !!

      popOver.setDetachedHandler((old, detached) -> {
         if (detached) {
            // Noting the bounds & dimensions of the popOver.
            final double w1 = container.getWidth();
            final double h1 = container.getHeight();
            final double x1 = popOver.getX();
            final double y1 = popOver.getY();
            final Rectangle2D currentBounds = new Rectangle2D(x1, y1, w1, h1);

            // Clearing the content and hiding the popOver.
            ((BorderPane) popOver.getRoot().getChildren().get(1)).setCenter(null);
            popOver.hide();

            // Showing the content in a new Stage with the same dimensions as popOver.
            container.setPadding(Insets.EMPTY); // Resetting the padding set for purpose of shadow effect.

            /* Build window and show */
            final String title = button.getText();
            final String windowId = "SHRTLIST_" + title;
            final IndependentWindow independentWindow = midiLayoutModuleSupplier.get().buildIndependentWindow(new IndependentWindowArgs(windowId, container, title, null, hidingHandler, currentBounds));
            independentWindow.show();
            popupMap.put(id, independentWindow);
         }
      });
   }

   /**
    * Updates the oneClickTrading option in all the currently opened popups.
    *
    * @param oneClickTrading One click trading option to set.
    */
   public void updateOneClickTrading(boolean oneClickTrading) {
      popupMap.forEach((id, popupStage) -> {
         final Node mainNode = ((Region) popupStage.getContent()).getChildrenUnmodifiable().get(0);
         if (mainNode instanceof SecTable) {
            ((SecTable) mainNode).setOneClickTrading(oneClickTrading);
         }
      });
   }

   /**
    * Disposes all the stages in the map.
    */
   public void disposeAll() {
      popupMap.values().forEach(popupStage -> {
         final Node mainNode = ((Region) popupStage.getContent()).getChildrenUnmodifiable().get(0);
         if (mainNode instanceof SecTable) {
            shortListButtonsViewUIModuleSupplier.get().cleanTableHandlers((SecTable) mainNode);
         }
         popupStage.close();
      });
      popupMap.clear();
   }

   public void setScrollEventEventHandler(EventHandler<ScrollEvent> scrollEventEventHandler) {
      this.scrollEventEventHandler = scrollEventEventHandler;
   }

   /**
    * Updates the zoom styling of all the opened popup's secTables.
    *
    * @param zoomLevel Zoom level to update
    */
   public void updateZoomToTables(Integer zoomLevel) {
      final List<SecTable> secTables = new ArrayList<>();
      popupMap.forEach((id, popupStage) -> secTables.add((SecTable) ((StackPane) popupStage.getContent()).getChildren().get(0)));
      if (currentPopOver != null) {
         secTables.add((SecTable) ((StackPane) currentPopOver.getContentNode()).getChildren().get(0));
      }
      secTables.forEach(secTable -> applyZoom(secTable, zoomLevel));
   }

   /**
    * Applies the zoom style on the table.
    *
    * @param secTable  Security Table
    * @param zoomLevel Zoom level value
    */
   private void applyZoom(SecTable secTable, int zoomLevel) {
      secTable.getStyleClass().removeIf(style -> style.startsWith(SecTable.ZOOM_STYLE));
      secTable.getStyleClass().add(SecTable.ZOOM_STYLE + zoomLevel);
      secTable.applyCss();
      secTable.requestLayout();
   }
}
