package xfe.icap.modules.tabeditorview;

import javafx.scene.layout.VBox;

public class WatchlistEditPane extends VBox {
	public WatchlistEditPane() {
		this.getStyleClass().add("xfe-content-pane");
      this.setId("xfe-watchlist-editor-root");
	}
}
