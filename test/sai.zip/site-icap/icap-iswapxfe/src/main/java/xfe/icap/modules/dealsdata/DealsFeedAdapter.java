package xfe.icap.modules.dealsdata;

import com.objsys.asn1j.runtime.Asn1ValueParseException;
import com.omxgroup.xstream.amp.AmpDealStatus;
import com.omxgroup.xstream.api.MarshalError;
import com.omxgroup.xstream.api.cometheader.PrimaryKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpDeal;
import xfe.icap.amp.AmpDeepCopy;
import xstr.icap.csdk.ICAPQueryReplyKey;
import xstr.session.*;

import java.util.*;

public class DealsFeedAdapter implements QueryFeed {
    private static final Logger logger = LoggerFactory.getLogger(DealsFeedAdapter.class);
    private final HashSet<QueryFeedListener> listeners = new HashSet<>();
    private final QueryFeedListener listener;
    private final QueryFeed srcFeed;
    private final Map<Long, DealNode> dealNodeMap = new HashMap<>(1024);

    public DealsFeedAdapter(QueryFeed feed) {
        listener = this::handleEvent;
        this.srcFeed = feed;
    }

    public void startPolling() {
        srcFeed.addListener(listener);
    }

    public void stopPolling() {
        srcFeed.removeListener(listener);
    }

    @Override
    public void addContListener(QueryFeedListener sink) {
        listeners.add(sink);
    }

    @Override
    public void addListener(QueryFeedListener sink) {
        listeners.add(sink);
    }

    @Override
    public void removeListener(QueryFeedListener sink) {
        listeners.remove(sink);
        sink.handleEvent(Collections.emptyList());
    }

    @Override
    public void dispose() {
        srcFeed.removeListener(listener);
        listeners.clear();
        dealNodeMap.clear();
    }

    private void handleEvent(QueryRowEvent ev, List<QueryRowEvent> handledFeedEvents) {
        DealNode node;
        final QueryReplyRow row = ev.getNewRow();
        final Long dealNo = row.getValue(AmpDeal.dealNo);
        // Check if already the same deal is registered..
        if (dealNodeMap.get(dealNo) == null) {
            if (isValidDeal(row)) {
                processNewDeal(dealNo, row, handledFeedEvents);
            }
        } else if (isCancelledDeal(row)) {
            node = dealNodeMap.get(dealNo);
            // Create a delete event for the row
            handledFeedEvents.add(QueryRowEvent.delete(node.row));
        } else {
            // Existing DEAL with new suffix
            if (isValidDeal(row)) {
                processUpdateDeal(ev, dealNo, row, handledFeedEvents);
            }
        }
    }

    /**
     * Process the update deal feed event.
     *
     * @param dealNo            Deal number
     * @param row               Deal row
     * @param handledFeedEvents List of handled feed events
     */
    private void processUpdateDeal(QueryRowEvent ev, Long dealNo, QueryReplyRow row, List<QueryRowEvent> handledFeedEvents) {
        QueryRowEvent createEventForUpdateDeal;
        DealNode node = dealNodeMap.get(dealNo);
        QueryReplyRow newRow;

        // Create a delete event for the old row
        handledFeedEvents.add(QueryRowEvent.delete(node.row));

        // Create a new row using deepCopy with the dealKey and include it as create event.
        if (ev.getEventType() == XtrQueryReplyCommand.CREATE) {
            try {
                newRow = new AbstractQueryReplyRow(node.key, AmpDeepCopy.copy(row.getData()), row.getTimestamp()) {
                    @Override
                    public XtrQueryRequest getRequest() {
                        return null;
                    }
                };
                node.row = newRow; // Update the new row to the DealNode.
                createEventForUpdateDeal = QueryRowEvent.create(newRow);
                handledFeedEvents.add(createEventForUpdateDeal);
            } catch (MarshalError marshalError) {
                logger.error("Exception when processing update deal feed event :: ", marshalError);
            }

        } else if (ev.getEventType() == XtrQueryReplyCommand.UPDATE) {
            // Create a new row with the rowData with the dealKey and include it as create event.
            newRow = new AbstractQueryReplyRow(node.key, row.getData(), row.getTimestamp()) {
                @Override
                public XtrQueryRequest getRequest() {
                    return null;
                }
            };
            node.row = newRow; // Update the new row to the DealNode.
            createEventForUpdateDeal = QueryRowEvent.create(newRow);
            handledFeedEvents.add(createEventForUpdateDeal);
        }
    }

    /**
     * Process the new deal feed event.
     *
     * @param dealNo            Deal number
     * @param row               Deal row
     * @param handledFeedEvents List of handled feed events
     */
    private void processNewDeal(Long dealNo, QueryReplyRow row, List<QueryRowEvent> handledFeedEvents) {
        QueryRowEvent createEventForNewDeal;
        QueryReplyRow newRow = null;
        try {
            XtrKey key = new ICAPQueryReplyKey(new PrimaryKey(dealNo + ""));
            newRow = new AbstractQueryReplyRow(key,
                    AmpDeepCopy.copy(row.getData()),
                    row.getTimestamp()) {
                @Override
                public XtrQueryRequest getRequest() {
                    return null;
                }
            };
            // Register in the nodeMap.
            new DealNode(dealNo, key, newRow);
        } catch (MarshalError | Asn1ValueParseException marshalError) {
            logger.error("Exception when processing new deal feed event :: ", marshalError);
        }
        // Create a new create event
        if (newRow != null) {
            createEventForNewDeal = QueryRowEvent.create(newRow);
            handledFeedEvents.add(createEventForNewDeal);
        }
    }

    /**
     * Determines whether the provided Deal row is valid deal or not.
     *
     * @param row QueryReplyRow
     * @return {@code true} if the deal is valid else returns {@code false}
     */
    private boolean isValidDeal(QueryReplyRow row) {
        final Long dealNoSuffix = row.getValue(AmpDeal.dealNoSuffix);
        final int dealStatus = row.getValue(AmpDeal.status);
        final boolean historical = row.getValue(AmpDeal.historical);
        return dealNoSuffix == 0 && dealStatus != AmpDealStatus.cancelled && !historical;
    }

    /**
     * Determines whether the provided Deal row is cancelled or not.
     *
     * @param row QueryReplyRow
     * @return {@code true} if the deal is cancelled else returns {@code false}
     */
    private boolean isCancelledDeal(QueryReplyRow row) {
        return row.getValue(AmpDeal.status) == AmpDealStatus.cancelled;
    }

    private void handleEvent(List<QueryRowEvent> feedEvents) {
        List<QueryRowEvent> handledFeedEvents = new ArrayList<>();
        for (QueryRowEvent ev : feedEvents) {
            switch (ev.getEventType()) {
                case CREATE:
                case UPDATE:
                case DELETE:
                    handleEvent(ev, handledFeedEvents);
                    break;
                case CLEAR:
                    dealNodeMap.clear();
                    break;
                case NONE:
                case UNKNOWN:
                default:
                    break;
            }
        }

        for (QueryFeedListener l : listeners) {
            try {
                l.handleEvent(handledFeedEvents);
            } catch (Exception e) {
                logger.error("Error while processing events:", e);
            }
        }
    }

    class DealNode {
        final Long dealNo;
        final XtrKey key;
        QueryReplyRow row;

        public DealNode(Long dealNo, XtrKey key, QueryReplyRow queryReplyRow) {
            this.dealNo = dealNo;
            this.key = key;
            this.row = queryReplyRow;
            dealNodeMap.put(dealNo, this);
        }
    }
}
