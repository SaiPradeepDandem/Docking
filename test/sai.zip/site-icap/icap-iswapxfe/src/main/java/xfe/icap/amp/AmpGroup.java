package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.acc.AmpAccessor;

/**
 * Accessor for Shortlist groups.
 */
public class AmpGroup extends AmpAccessor {

   public static final AMP.AmpQreq req = AMP.qREQ("groupReq");
   public static final AMP.AmpQrep rep = AMP.qREP("groupRep");

   public static final AsnConversionAccessor<Integer> groupType = acc(AMP.qREQ("groupReq.groupType"), Integer.class);
   public static final AsnConversionAccessor<String> groupId = acc(AMP.qREP("groupRep.groupId"), String.class);
   public static final AsnConversionAccessor<String> firmId = acc(AMP.qREP("groupRep.firmId"), String.class);
   public static final AsnConversionAccessor<Long> priority = acc(AMP.qREP("groupRep.priority"), Long.class);
   public static final AsnConversionAccessor<String> groupName = acc(AMP.qREP("groupRep.groupName"), String.class);
   public static final AsnConversionAccessor<Boolean> preferSameCHForStrategies = acc(AMP.qREP("groupRep.preferSameCHForStrategies"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> reducedClearingSpend = acc(AMP.qREP("groupRep.reducedClearingSpend"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> internalMatchAllowed = acc(AMP.qREP("groupRep.internalMatchAllowed"), Boolean.class);

}
