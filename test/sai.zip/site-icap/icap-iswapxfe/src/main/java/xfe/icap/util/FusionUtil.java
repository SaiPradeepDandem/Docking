package xfe.icap.util;

import fusion.core.openfin.FusionApplication;
import fusion.core.openfin.LaunchOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by jiadin on 2015-06-01.
 */
public class FusionUtil {
   private static final Logger logger = LoggerFactory.getLogger(FusionUtil.class);
//   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
   public static void openFusion(String userId) {
      try {
         FusionApplication application = new FusionApplication("xfe-application", "localhost", 9696);
         application.setLogLevel(true);

         //Create launch options
         LaunchOptions launchOptions = new LaunchOptions();
//         launchOptions.setHostUrl("https://qa.icapfusion.com");
//         launchOptions.setUuid("xfe-launch");
         launchOptions.setShortcut(false);
         launchOptions.setHostUrl("https://www.icapfusion.com");
         //Launch openfin
         application.launchAndConnect(launchOptions);
      } catch (Exception e) {
         logger.error("Start fusion error.",e);
      }
   }
}
