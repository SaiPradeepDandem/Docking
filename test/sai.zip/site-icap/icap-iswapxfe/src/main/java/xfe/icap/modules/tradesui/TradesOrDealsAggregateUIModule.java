package xfe.icap.modules.tradesui;

import javafx.collections.FXCollections;
import javafx.util.Pair;
import org.controlsfx.control.PopOver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.ISwapMain;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.modules.dealsdata.DealsDataModule;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.ordersui.OrdersViewUIModule;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.tradesdata.TradesDataModule;
import xfe.icap.modules.tradesdata.TradesOrDealsPriceAggregateData;
import xfe.module.Module;
import xfe.module.SiteModule;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.popover.XfePopOver;
import xfe.util.EasyFXML;
import xstr.util.Tuple2;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Module.Autostart
public class TradesOrDealsAggregateUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradesOrDealsAggregateUIModule.class);

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public SecTabsUIModule secTabsUIModule;

   @ModuleDependency
   public TradesViewUIModule tradesViewUIModule;

   @ModuleDependency
   public DealsViewUIModule dealsViewUIModule;

   @ModuleDependency
   public OrdersViewUIModule ordersViewUIModule;

   @ModuleDependency
   public TradesDataModule tradesDataModule;

   @ModuleDependency
   public DealsDataModule dealsDataModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @Override
   public Future<Void> startModule() {
      secTabsUIModule.setTradesAggregatePopupHandler(this::showTradesOrDealsAggregatePopup);
      tradesViewUIModule.setTradesAggregatePopupHandler(this::showTradesOrDealsAggregatePopup);
      dealsViewUIModule.setTradesAggregatePopupHandler(this::showTradesOrDealsAggregatePopup);
      ordersViewUIModule.setTradesAggregatePopupHandler(this::showTradesOrDealsAggregatePopup);
      tradesDataModule.setTradeUpdateNotifier(this::updateTradesOrDealsAggregate);
      dealsDataModule.setDealUpdateNotifier(this::updateTradesOrDealsAggregate);
      return Future.SUCCESS;
   }
   @Override
   public Future<Void> stopModule() {
      secTabsUIModule.setTradesAggregatePopupHandler(null);
      tradesViewUIModule.setTradesAggregatePopupHandler(null);
      dealsViewUIModule.setTradesAggregatePopupHandler(null);
      ordersViewUIModule.setTradesAggregatePopupHandler(null);
      tradesDataModule.setTradeUpdateNotifier(null);
      dealsDataModule.setDealUpdateNotifier(null);
      return Future.SUCCESS;
   }

   /**
    * Updates the trades aggregate data in all opened popups and popover.
    */
   private void updateTradesOrDealsAggregate() {
      //  Updating the aggregate table if any current popover is showing.
      if (currentPopOverPane != null && currentPopOverSecBoardKey != null) {
         currentPopOverPane.updateData(buildAggregatedData(currentPopOverSecBoardKey.getKey(), currentPopOverSecBoardKey.getValue()));
      }

      //  Updating the aggregate table for all opened trade aggregate windows.
      midiLayoutModule.getPopoverWindowsMap().forEach((id, managedXfeWindow) -> {
         if (id.endsWith(POP_OVER_TITLE)) {
            String secCode = (String) managedXfeWindow.getProperties().get(SEC_CODE_KEY);
            String boardId = (String) managedXfeWindow.getProperties().get(BOARD_ID_KEY);
            if (secCode != null && boardId != null) {
               List<TradesOrDealsAggregateData> updatedData = buildAggregatedData(secCode, boardId);
               ((TradesOrDealsAggregatePane) managedXfeWindow.getContent().getUserData()).updateData(updatedData);
            }
         }
      });
   }

   /**
    * Builds the aggregated trade data for the given secCode and boardId.
    *
    * @param secCode SecCode
    * @param boardId BoardId
    * @return List of trade aggregate data.
    */
   private List<TradesOrDealsAggregateData> buildAggregatedData(String secCode, String boardId) {
      boolean isGiltsSite = midiLayoutModule.isGiltsSite();
      Map<Tuple2<String, String>, Map<BigDecimal, TradesOrDealsPriceAggregateData>> aggregateMap;
      if (isGiltsSite) {
         aggregateMap = dealsDataModule.getDealsAggregateByPriceBySecBoard();
      } else {
         aggregateMap = tradesDataModule.getTradesAggregateByPriceBySecBoard();
      }

      Map<BigDecimal, TradesOrDealsPriceAggregateData> priceMap = aggregateMap.get(new Tuple2<>(secCode, boardId));
      if (priceMap != null && !priceMap.isEmpty()) {
         List<TradesOrDealsAggregateData> data = FXCollections.observableArrayList();
         priceMap.forEach((price, aggData) -> {
            if (isGiltsSite) {
               data.add(new TradesOrDealsAggregateData(secCode, price, aggData.getMyQuantity(), aggData.getMyFirmQuantity()));
            } else {
               data.add(new TradesOrDealsAggregateData(secCode, price, aggData.getMyQuantity(), aggData.getMyFirmQuantity(), aggData.getMarketQuantity()));
            }
         });
         return data;
      }
      return FXCollections.emptyObservableList();
   }

   private void showTradesOrDealsAggregatePopup(TradesAggregateArgs args) {
      TradesOrDealsAggregatePane pane = EasyFXML.load(TradesOrDealsAggregatePane.class);
      pane.setIsForDeals(midiLayoutModule.isGiltsSite());
      securitiesDataModule.getStaticInfo(args.getSecCode(), args.getBoardId()).map(info -> {
         pane.setPriceFormatter(info.priceFormatter);
         return Future.SUCCESS;
      });
      pane.updateData(buildAggregatedData(args.getSecCode(), args.getBoardId()));
      this.currentPopOverPane = pane;
      this.currentPopOverSecBoardKey = new Pair<>(args.getSecCode(), args.getBoardId());

      Map<String, String> propertiesMap = new HashMap<>();
      propertiesMap.put(SEC_CODE_KEY, args.getSecCode());
      propertiesMap.put(BOARD_ID_KEY, args.getBoardId());

      XfePopOver popOver =  XfePopOver.instance(midiLayoutModule, propertiesMap);
      popOver.setIndependentWindowSupplier(midiLayoutModule::buildIndependentWindow);
      popOver.setHideHandler(() -> {
         currentPopOverPane = null;
         currentPopOverSecBoardKey = null;
      });
      popOver.setDetachable(true);
      //popOver.setVerticallyResizableOnDetached(true);
      popOver.setArrowLocation(PopOver.ArrowLocation.LEFT_TOP);
      popOver.setHeaderAlwaysVisible(true);
      popOver.setContentNode(pane.getRoot());
      popOver.setTitle(args.getSecCode() + " " + POP_OVER_TITLE);
      popOver.showSafely(args.getNode());
      pane.getRoot().setId(popOver.id());
      midiLayoutModule.closePopOverWindow(popOver.id());
   }

   private TradesOrDealsAggregatePane currentPopOverPane;
   private Pair<String, String> currentPopOverSecBoardKey;

   private static String SEC_CODE_KEY = "secCode";
   private static String BOARD_ID_KEY = "boardId";
   private static String POP_OVER_TITLE = "Trade Statistics";
}
