package xfe.icap.modules.iswaporders;


import java.util.Date;

public class OrderEntryTimeSequence implements Comparable<OrderEntryTimeSequence> {
	private final long entryTime;
	private final Long managedOrderId;
	private final Long normalOrderId;
	private final Date normalOrderDate;

	OrderEntryTimeSequence(Date entryTime, Long managedOrderId, Long normalOrderId, Date nornalOrderDate) {
		if (entryTime == null) {
			this.entryTime = Long.MAX_VALUE;
		} else {
			this.entryTime = entryTime.getTime();
		}
		this.managedOrderId=managedOrderId;
		this.normalOrderId = normalOrderId;
		this.normalOrderDate = nornalOrderDate;
	}

	@Override
	public int compareTo(OrderEntryTimeSequence other) {
		if (managedOrderId != null && other.managedOrderId != null) {
			return -Long.signum(managedOrderId - other.managedOrderId);
		}
		long timeDiff = entryTime - other.entryTime;
		if (timeDiff != 0)
			return -Long.signum(timeDiff);
		else {
			if (normalOrderId!=null && other.normalOrderId!=null) {
				long idDiff = normalOrderId - other.normalOrderId;
				return idDiff != 0 ? -Long.signum(idDiff) : Long.signum(normalOrderDate.getTime() - other.normalOrderDate.getTime());
			} else {
				if(managedOrderId!=null) {
					return 1;
				}else {
					return -1;
				}
			}
		}
	}
}
