package xfe.icap;

import javafx.stage.Stage;
import xfe.XfeAppModule;
import xfe.icap.client.IcapWebSiteConfig;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.icap.modules.actionsdata.ActionsDataModule;
import xfe.icap.modules.actionsui.ActionsUIModule;
import xfe.icap.modules.actionsui.ConfigActionsUIModule;
import xfe.icap.modules.autologon.AutoLogonModule;
import xfe.icap.modules.cmpopuporderentry.CMPopupOrderEntryModule;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.dealsdata.DealsDataModule;
import xfe.icap.modules.dev.DevModeInitiator;
import xfe.icap.modules.dev.DevModule;
import xfe.icap.modules.groupdata.GroupDataModule;
import xfe.icap.modules.groupdata.GroupSecsDataModule;
import xfe.icap.modules.historyui.HistoryViewUIModule;
import xfe.icap.modules.historyview.HistoryViewModule;
import xfe.icap.modules.hittake.HitTakeModule;
import xfe.icap.modules.instrumentsettingsview.InstrumentSettingsViewModule;
import xfe.icap.modules.iswaporders.AmendOrdersModule;
import xfe.icap.modules.iswaporders.OrdersUIModule;
import xfe.icap.modules.iswaptrades.TradeNotificationsModule;
import xfe.icap.modules.iswaptrades.TradesModule;
import xfe.icap.modules.iswaptrades.TradesTickerModule;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.linelist.LinelistModule;
import xfe.icap.modules.linelistview.LineListViewModule;
import xfe.icap.modules.mmgroupview.MMGroupViewModule;
import xfe.icap.modules.obbo.ObboModule;
import xfe.icap.modules.orderentry.EntryModule;
import xfe.icap.modules.ordersdata.OrdersDataModule;
import xfe.icap.modules.ordersui.OrdersViewUIModule;
import xfe.icap.modules.popover.PopOverModule;
import xfe.icap.modules.popuporderentry.PopupOrderEntryModule;
import xfe.icap.modules.prefsview.PrefsViewsModule;
import xfe.icap.modules.rfq.RfqModule;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settings.SettingsPresetModule;
import xfe.icap.modules.settings.SettingsUIModule;
import xfe.icap.modules.settingsview.SettingsViewModule;
import xfe.icap.modules.shortlist.ShortlistButtonsViewUIModule;
import xfe.icap.modules.site.DefaultSiteModule;
import xfe.icap.modules.site.UsSwapsSiteModule;
import xfe.icap.modules.site.UkGiltsSiteModule;
import xfe.icap.modules.site.UkSwapsSiteModule;
import xfe.icap.modules.springboard.SpringBoardUIModule;
import xfe.icap.modules.sweep.SweepModule;
import xfe.icap.modules.tabeditorview.TabEditorViewModule;
import xfe.icap.modules.toolbar.TraderToolbarModule;
import xfe.icap.modules.toolbar.actions.ActionToolBarUIModule;
import xfe.icap.modules.tradealert.TradeAlertSoundModule;
import xfe.icap.modules.tradesdata.TradesDataModule;
import xfe.icap.modules.tradesui.DealsViewUIModule;
import xfe.icap.modules.tradesui.TradesOrDealsAggregateUIModule;
import xfe.icap.modules.tradesui.TradesUIModule;
import xfe.icap.modules.tradesui.TradesViewUIModule;
import xfe.icap.modules.tradesworkup.TradesWorkupViewUIModule;
import xfe.icap.modules.watchlist.PriceTightnessModule;
import xfe.icap.modules.watchlist.WatchlistModule;
import xfe.icap.types.ConverterForAsnDateTime_Duration;
import xfe.module.ModuleViewerModule;
import xfe.module.SchedulerModule;
import xfe.module.SiteModule;
import xfe.modules.actions.ActionsModule;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.modules.history.HistoryModule;
import xfe.modules.localsettings.LocalSettingsModule;
import xfe.modules.logging.LoggingModule;
import xfe.modules.logon.LogonModule;
import xfe.modules.modalnotification.ISwapNotificationModule;
import xfe.modules.session.ActiveSessionModule;
import xfe.modules.session.CertVerificationModule;
import xfe.modules.session.SessionModule;
import xfe.modules.skin.XfeSkin;
import xfe.modules.test.TestHelperModule;
import xfe.ui.KeyboardNavigationModule;
import xfe.ui.logon.impl.ConnectionStatusPane;
import xstr.amp.Xtr;
import xstr.util.concurrent.Future;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

public class ISwapMain extends XfeAppModule {
   private static final Logger logger = LoggerFactory.getLogger(ISwapMain.class);

   public static final String XFE_SITE_SWAPS_UK =  "i-Swap EUR";
   public static final String XFE_SITE_SWAPS_US =  "i-Swap US";
   public static final String XFE_SITE_SWAPS_AU =  "i-Swap AU";
   public static final String XFE_SITE_GILTS_UK =  "ICAP Gilts";

   {
      Xtr.init(new IcapWebSiteConfig());
      Xtr.addConverter(new ConverterForAsnDateTime_Duration());
   }

   @Override
   public Future<? extends SiteModule> startSiteModule(String site) {
      switch (site) {
         case XFE_SITE_GILTS_UK:
            return manualStartModule(UkGiltsSiteModule.class);
         case XFE_SITE_SWAPS_UK:
            return manualStartModule(UkSwapsSiteModule.class);
         case XFE_SITE_SWAPS_US:
            return manualStartModule(UsSwapsSiteModule.class);
         default:
            return manualStartModule(DefaultSiteModule.class);
      }
   }

   @Override
   public List<String> getSites() {
      return Arrays.asList(
         XFE_SITE_SWAPS_UK,
         XFE_SITE_SWAPS_US,
         XFE_SITE_GILTS_UK
      );
   }

   @Override
   public void start(Stage primaryStage) throws Exception {
      Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
         logger.error("Unhandled exception on JavaFx Thread: {}", e.getMessage());
         logger.debug("Unhandled exception on JavaFx Thread: ", e);
      });

      addModules( Arrays.asList(
         ActionsModule.class,
         ActionsUIModule.class,
         ActionToolBarUIModule.class,
         ActiveSessionModule.class,
         AutoLogonModule.class,
         AmendOrdersModule.class,
         CertVerificationModule.class,
         ConfigActionsUIModule.class,
         ConfigurationModule.class,
         ConnectionStatusPane.class,
         DataContextModule.class,
         DealsDataModule.class,
         ActionsDataModule.class,
         DefaultSiteModule.class,
         DevModeInitiator.class,
         DevModule.class,
         EntryModule.class,
         FxApplicationModule.class,
         GroupDataModule.class,
         GroupSecsDataModule.class,
         HistoryModule.class,
         HistoryViewModule.class,
         HistoryViewUIModule.class,
         ISwapLayoutMedium.class,
         ISwapMainLayoutManager.class,
         KeyboardNavigationModule.class,
         LocalSettingsModule.class,
         LoggingModule.class,
         LogonModule.class,
         LinelistModule.class,
         LineListViewModule.class,
         MidiLayoutModule.class,
         ISwapNotificationModule.class,
         ModuleViewerModule.class,
         MMGroupViewModule.class,
         ObboModule.class,
         TradesDataModule.class,
         TradesUIModule.class,
         DealsViewUIModule.class,
         TradesViewUIModule.class,
         TradesWorkupViewUIModule.class,
         OrdersDataModule.class,
         OrdersUIModule.class,
         OrdersViewUIModule.class,
         PopOverModule.class,
         PopupOrderEntryModule.class,
         CMPopupOrderEntryModule.class,
         HitTakeModule.class,
         PrefsViewsModule.class,
         PriceTightnessModule.class,
         RfqModule.class,
         SchedulerModule.class,
         SecTabsUIModule.class,
         SecuritiesDataModule.class,
         ShortlistButtonsViewUIModule.class,
         SelectionContextModule.class,
         SessionModule.class,
         SettingsPresetModule.class,
         SettingsUIModule.class,
         SettingsViewModule.class,
         SpringBoardUIModule.class,
         SweepModule.class,
         TabEditorViewModule.class,
         InstrumentSettingsViewModule.class,
         TradeNotificationsModule.class,
         TraderToolbarModule.class,
         TradesFlashModule.class,
         TradesModule.class,
         TradesOrDealsAggregateUIModule.class,
         TradesTickerModule.class,
         UkSwapsSiteModule.class,
         UsSwapsSiteModule.class,
         UkGiltsSiteModule.class,
         WatchlistModule.class,
         XfeSession.class,
         XfeSkin.class,
         TradeAlertSoundModule.class,
         TestHelperModule.class
      ));
      super.start(primaryStage);
   }


   public static void main(String args[]) {
      logger.info("Launching application");
      launch(args);
   }
}
