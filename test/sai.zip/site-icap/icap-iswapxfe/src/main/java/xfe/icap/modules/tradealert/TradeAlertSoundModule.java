package xfe.icap.modules.tradealert;

import com.nomx.domain.types.AlertSound;
import com.nomx.domain.types.AlertsGroup;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.AmpMarketTrade;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.iswaptrades.TradesFilters;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.tradesdata.TradesDataModule;
import xfe.icap.util.SoundPlayer;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.session.*;
import xstr.types.TradeSide;
import xstr.util.concurrent.Future;

import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

/**
 * Created by alum on 16/04/2020.
 *
 * @author Alum Lee
 * The business logic part codes taken from Trade Notification module.
 * Getting and handling tradeRep and marketTradeRep part is using TradesDataModule instead of ListenerTracker.
 * For playing alert sound, using SoundPlayer instead of Sounds.
 */
@Module.Autostart
public class TradeAlertSoundModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradeAlertSoundModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   @ModuleDependency
   public TradesDataModule tradesDataModule;

   private final HashSet<String> dealtTradeNo = new HashSet<>(1052);
   private ListChangeListener<? super ObservableReplyRow> marketTradeDataListener;
   private ListChangeListener<? super ObservableReplyRow> tradeDataListener;
   private Clip currenPlay;
   private TradesFilters filters;

   private final ChangeListener<AlertSound> alertSoundChangeListener = (ObservableValue<? extends AlertSound> observable, AlertSound oldValue, AlertSound newValue) -> {
      if (!Objects.equals(oldValue, newValue) && currenPlay != null)
         currenPlay.stop();
   };

   private final ChangeListener<Boolean> tradeSoundChangeListener = (ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
      if (Objects.equals(oldValue, newValue) && currenPlay != null)
         currenPlay.stop();
   };
   
   public Future<Void> startModule() {
      subscribeToTradesFeed();
      //add listeners for changes in sound configs
      configurationModule.getData().alertSoundForMineProperty().addListener(alertSoundChangeListener);
      configurationModule.getData().alertSoundForAllProperty().addListener(alertSoundChangeListener);
      configurationModule.getData().tradeSoundProperty().addListener(tradeSoundChangeListener);
      return Future.SUCCESS;
   }

   public Future<Void> stopModule() {
      if (tradeDataListener != null) {
         tradesDataModule.getTradeData().removeListener(tradeDataListener);
         tradeDataListener = null;
      }
      if (marketTradeDataListener != null) {
         tradesDataModule.getMarketTradeData().removeListener(marketTradeDataListener);
         marketTradeDataListener = null;
      }
      //remove listeners for changes in sound configs
      configurationModule.getData().alertSoundForMineProperty().removeListener(alertSoundChangeListener);
      configurationModule.getData().alertSoundForAllProperty().removeListener(alertSoundChangeListener);
      configurationModule.getData().tradeSoundProperty().removeListener(tradeSoundChangeListener);
      dealtTradeNo.clear();
      currenPlay = null;
      if (filters != null) {
         filters.dispose();
         filters = null;
      }
      return Future.SUCCESS;
   }

   private void subscribeToTradesFeed() {
      filters = new TradesFilters(xfeSessionModule);
      String userId = activeSessionModule.getSession().map(ServerSession::getLoggedOnUserId).orElse(null);
      String firmId = activeSessionModule.getSession().map(ServerSession::getLoggedOnUserFirmId).orElse(null);
      ReadOnlyObjectProperty<AlertsGroup> alertsGroup = configurationModule.getData().tradeAlertsProperty();
      ReadOnlyBooleanProperty alertsShowLegs = configurationModule.getData().alertsShowLegsProperty();

      tradeDataListener = c -> {
         while (c.next()) {
            if (c.wasAdded()) {
               final List<? extends ObservableReplyRow> list = c.getAddedSubList();
               if (list.isEmpty()) return;
               logger.info("Processing {} tradeReq events", list.size());
               Date connectedTime = xfeSessionModule.getUnderlyingSession().getConnectTime();
               logger.debug("Processing Alert Event. logon time is " + connectedTime);
               list.forEach(row -> {
                  logger.info("Trade received: {} with row timestamp {}", row, row.getTimestamp());
                  String tradeInfo = AmpTrade.abbreviate(row);
                  Date tradeTime = row.getValue(AmpTrade.time);
                  logger.debug(
                     "{} tradeTime is {} logon Time is {} status is {}",
                     tradeInfo,
                     row.getValue(AmpTrade.time).getTime(),
                     connectedTime,
                     row.getValue(AmpTrade.status));

                  if (tradeTime.before(connectedTime)) {
                     logger.debug("{} notification skipped: Trade predates logon", tradeInfo);
                     return;
                  }

                  boolean isLeg = filters.isLeg.accept(row);
                  // Skipping legs if they are not shown
                  if (isLeg && !alertsShowLegs.get()) {
                     logger.debug("{} notification skipped: leg trade", tradeInfo);
                     return;
                  }
                  // Skipping manual trades
                  if (!filters.isAuto.accept(row)) {
                     logger.debug("{} notification skipped: Not Auto Trade", tradeInfo);
                     return;
                  }

                  boolean isMyTrade = filters.isMyTrade(userId, row);
                  if (alertsGroup.get() == AlertsGroup.MINE && !isMyTrade) {
                     logger.debug("{} notification skipped: AlertGroup is MINE and trade is not mine", tradeInfo);
                     return;
                  }

                  TradeSide side = filters.getTradeSide(row);
                  if (side == null) {
                     logger.warn("{} notification skipped: Trade Side is null", tradeInfo);
                     return;
                  }

                  String tradeNo = row.getString(AmpTrade.tradeNo);
                  if (dealtTradeNo.contains(tradeNo)) {
                     logger.debug("{} notification skipped: already processed", tradeInfo);
                     return;
                  }
                  dealtTradeNo.add(tradeNo);

                  logger.debug("{} generating notification", tradeInfo);

                  if (configurationModule.getData().tradeSoundProperty().get()) {
                     logger.debug("{} Playing trade alert sound...", tradeInfo);
                     if (isMyTrade) {
                        currenPlay = SoundPlayer.createClip(configurationModule.getData().alertSoundForMineProperty().get());
                        if (currenPlay != null) {
                           addClipListener();
                           currenPlay.start();
                        }
                     } else {
                        currenPlay = SoundPlayer.createClip(configurationModule.getData().alertSoundForAllProperty().get());
                        if (currenPlay != null) {
                           addClipListener();
                           currenPlay.start();
                        }
                     }
                     logger.debug("{} Playing trade alert sound - Done", tradeInfo);
                  }
               });
            }
         }
      };

      marketTradeDataListener = c -> {
         while (c.next()) {
            if (c.wasAdded()) {
               final List<? extends ObservableReplyRow> list = c.getAddedSubList();
               if (list.isEmpty()) return;
               if (AlertsGroup.MINE.equals(alertsGroup.get())) {
                  logger.info("MktTrade notifications skipped: Alert group is MINE");
                  return;
               }
               Date connectedTime = xfeSessionModule.getUnderlyingSession().getConnectTime();
               logger.debug("Processing Alert Event. logon time is " + connectedTime);
               list.forEach(row -> {
                  String tradeInfo = AmpMarketTrade.toShortString(row);
                  logger.info("MktTrade received: {} with row timestamp {}", tradeInfo, row.getTimestamp());


                  Date tradeTime = row.getValue(AmpMarketTrade.tradeTime);
                  int intStatus = row.getValue(AmpMarketTrade.status);
                  logger.debug("tradeTime is "
                        + tradeTime.getTime()
                        + " logon Time is "
                        + connectedTime
                        + " status is "
                        + intStatus);

                  // TODO: if we need to support broker trades checkbox option for DESK
                  // then we need to find out how to detect such trades
                  // isMyFirmMarketTrade then needs to change to detect it properly
                  boolean isMyFirmTrade = filters.isMyFirmMarketTrade(firmId, row);
                  if (AlertsGroup.DESK.equals(alertsGroup.get()) && !isMyFirmTrade) {
                     logger.debug(
                        "{} notification skipped: AlertGroup is DESK and trade is not from my firm",
                        tradeInfo);
                     return;
                  }

                  if (tradeTime.before(connectedTime)) {
                     logger.debug("{} notification skipped: Trade predates logon", tradeInfo);
                     return;
                  }

                  boolean isLeg = filters.isLeg.accept(row);
                  // Skipping legs if they are not shown
                  if (isLeg && !alertsShowLegs.get()) {
                     logger.debug("{} notification skipped: leg trade", tradeInfo);
                     return;
                  }

                  String tradeNo = row.getString(AmpMarketTrade.tradeNo);
                  if (dealtTradeNo.contains(tradeNo)) {
                     logger.debug("{} notification skipped: already processed", tradeInfo);
                     return;
                  }
                  dealtTradeNo.add(tradeNo);

                  logger.debug("{} generating notification", tradeInfo);

                  if (configurationModule.getData().tradeSoundProperty().get()) {
                     currenPlay = SoundPlayer.createClip(configurationModule.getData().alertSoundForAllProperty().get());
                     if (currenPlay != null) {
                        addClipListener();
                        currenPlay.start();
                     }
                  }
               });
            }
         }
      };

      tradesDataModule.getTradeData().addListener(tradeDataListener);

      if (AlertsGroup.ALL.equals(configurationModule.getData().tradeAlertsProperty().get())
         || AlertsGroup.DESK.equals(configurationModule.getData().tradeAlertsProperty().get())) {
         tradesDataModule.getMarketTradeData().addListener(marketTradeDataListener);
      }
   }

   private void addClipListener() {
      currenPlay.addLineListener(new LineListener() {
         public void update(LineEvent event) {
            if (event.getType() == LineEvent.Type.STOP) {
               event.getLine().removeLineListener(this);
               event.getLine().close();
            }
         }
      });
   }
}
