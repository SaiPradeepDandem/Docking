package xfe.icap.modules.watchlist;

import java.util.Date;

import javafx.beans.property.*;
import javafx.collections.ObservableList;

import org.slf4j.*;

import xstr.util.*;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpRfq;
import xstr.session.ObservableReplyRow;
import xfe.icap.ui.RfqTimerPane;

public class RfqFinalStageCounterDown {

   private static final Logger logger = LoggerFactory.getLogger(RfqFinalStageCounterDown.class);

   /**
    * keep the current sec/board to avoid canceling and starting the timer for the same instrument again.
    */
   private String currentSecCode;
   private String currentBoardId;

   private final RfqTimerPane rfqInstr;
   private final XfeSession xfeSession;

   public RfqFinalStageCounterDown(RfqTimerPane rfqInstr, XfeSession xfeSession) {
      this.rfqInstr = rfqInstr;
      this.xfeSession = xfeSession;
   }

   private final ObjectProperty<TickTask> currentTask = new SimpleObjectProperty<>();
   private void startRfqCountDown(ObservableReplyRow rfqRow, String secCode, String boardId) {
      try {
         Date endTime = rfqRow.getValue(AmpRfq.endTime);
         if (endTime != null) {
            TeClock  teClock = xfeSession.getUnderlyingSession().teClock;
            rfqInstr.setSecCode(secCode);
            TickTask task = currentTask.get();
            if(task!=null){
               teClock.removeTask(task);
            }
            TickTask newTask = new TickTask("Rfq_Fianl_Stage_Timer",
               () -> {
               rfqInstr.visibleProperty().set(true);
                  long endingTimeInsecond = (endTime.getTime() - teClock.get().getTime())/1000;
                  rfqInstr.setText(endingTimeInsecond,rfqRow.getValue(AmpRfq.status));
            },
               () -> {
                  rfqInstr.visibleProperty().set(false);
               }, endTime);



            currentTask.set(newTask);
            teClock.addTickTask(newTask);
         }
      } catch (Exception e) {
         logger.error("count down timer failed", e);
      }
   }

   /**
    * there are following scenarios need to pick up soonest ending rfq: 1, an none-rfq instrument is selected in the watchlist 2. current rfq is timeout. (the RFQ status turns into "finshed")
    *
    * The following scenarios should not trigger it 1. current an rfq is selected, and another rfq is selected right after the current selection.
    */
   public synchronized void startEndingSoonestRfqCountDown() {
      ObservableList<ObservableReplyRow> sortedList = xfeSession.rfqs.get().sortByEndingFinalPhaseRfqs.get();
      if (sortedList.size() > 0) {
         ObservableReplyRow row = sortedList.get(0);
         String secCode = row.getValue(AmpRfq.secCode);
         String boardId = row.getValue(AmpRfq.boardId);
         if (currentSecCode != null && currentSecCode.equals(secCode) && currentBoardId != null && currentBoardId.equals(boardId)) {
            logger.debug("{} {} is the current count down.",currentBoardId ,currentSecCode );
            return;
         }
         currentSecCode = secCode;
         currentBoardId = boardId;
         startRfqCountDown(row,secCode, boardId);
      } else {
         removeTask();
      }
   }

   private void removeTask() {
      TeClock  teClock = xfeSession.getUnderlyingSession().teClock;
      TickTask task = currentTask.get();
      if(task!=null && teClock!=null){
         teClock.removeTask(task);
      }
      currentTask.set(null);
      rfqInstr.visibleProperty().set(false);
   }

   public synchronized void cancel() {
      removeTask();
      currentSecCode = null;
      currentBoardId = null;
   }

}
