package xfe.icap.modules.iswaptrades;

import java.util.LinkedList;
import java.util.List;

import xfe.util.Constants;
import xstr.amp.ASN;
import xstr.util.*;
import xstr.util.Filter.Statics;
import xfe.icap.XfeSession;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.icap.modules.settings.ConfigurationModule;
import com.objsys.asn1j.runtime.Asn1Type;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableStringValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.StackPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import javafx.util.Pair;

import org.slf4j.Logger;

import xstr.types.TradeSide;
import xstr.util.FilterCallback.RowFilterCallback;
import xstr.util.FilterCallback.ValueFilterCallback;
import xfe.util.scene.control.NodeFlashDecorator;
import xfe.util.scene.control.EnhancedTableCell;
import xfe.util.scene.control.EnhancedTableColumn;
import xfe.util.scene.control.EnhancedTableView;
import xfe.util.scene.control.LabeledLayerFactory;
import xfe.util.scene.control.NotificationSliderPane;
import xfe.util.scene.control.VerticalAppContainer;
import fxext.LabelBuilder;

import xfe.layout.LayoutManager;
import xstr.util.concurrent.Future;

class TradeNotificationsStage extends Stage implements Constants {
   private final Logger logger;

   private static final int slideTime = 1500;
   private final IntegerProperty minRowCount = new SimpleIntegerProperty(3);
   private final IntegerProperty maxRowCount = new SimpleIntegerProperty(12);
   private final Final<NotificationSliderPane> sliderPane = new Final<>();
   private final LinkedList<TradeAlert> backList = new LinkedList<>(); // LinkedList here is better than arraylist, especially in case of memory space expanding
   private final ObservableList<TradeAlert> items = FXCollections.observableList(backList);
   private final TradeAlertComparator comparatorAlert = new TradeAlertComparator();
   private final ObservableList<TradeAlert> sortedItems = Fx.sortBy(items, comparatorAlert);

   private final ObservableList<TradeAlert> tableItems = Fx.alwaysUnequal(sortedItems);

   private final IntegerProperty rowCountProperty = new SimpleIntegerProperty(0);
   private final ObjectProperty<EventHandler<TradeIdEvent>> onItemAction = new SimpleObjectProperty<>();

   // public final Stage popupStage ;
   private final String logonUserId;
   private final NotificationSliderPane notificationPane;
   private final VerticalAppContainer appContainer = new VerticalAppContainer(Constants.STYLE_HIVIS, -1, -1, true, null, 2.0,true);
   private java.time.Duration expiryDuration = java.time.Duration.ZERO;

   TradeNotificationsStage(TradesFlashModule tradesFlashModule,
                           ConfigurationModule settingsModule,
                           LayoutManager<Node> layoutManager,
                           ObservableBooleanValue showTradeAlert,
                           ObservableBooleanValue showWorkup,
                           String useId,
                           org.slf4j.Logger logger) {
      super(StageStyle.TRANSPARENT);
//      ZoomableDecorator.makeWindowZoomable(this);
      this.logger = logger;
      // initOwner(TradeNotificationsStage.this);
      this.setX(settingsModule.getData().tradeAlertsNotificationPosXProperty().get());
      this.setY(settingsModule.getData().tradeAlertsNotificationPosYProperty().get());
      ListenerTracker tracker = new ListenerTracker();
      tracker.rollback();
      tracker.bind(rowCountProperty, Fx.sizeOfList(items));
      ImageView logo = new ImageView();
      logo.getStyleClass().addAll("xfe-icon-app-title");

      appContainer.setId("Trade-notification-root");
      appContainer.setTradeSideProp(tradesFlashModule.blinkTradeSideToInitProp, Fx.valueOf(true));
      notificationPane = new NotificationSliderPane("trade-notifier", slideTime, 21) {
         {
            this.slidingAnimationDelayProperty().set(slideTime);
            HBox.setHgrow(this, Priority.ALWAYS);
            this.setPlaceholder(new StackPane() {
               {
                  this.setId("xfe_trade_notification_title");
                  // this.prefWidthProperty().bind(headerOuter.widthProperty());
                  this.getStyleClass().addAll("xfe-trade-notifications-header-content");
                  this.getChildren().setAll(new Label() {
                     {
                        // Right Caption
                        this.getStyleClass().addAll("xfe-title");
                        this.setText("Trade Notifications");
                        StackPane.setAlignment(this, Pos.CENTER_RIGHT);
                     }
                  });
               }
            });
         }
      };

      this.setAlwaysOnTop(true);
      VBox vbox = new VBox() {
         {
            this.getStyleClass().addAll("xfe-trade-notifications-content");
            this.setFillWidth(true);
            this.getChildren().addAll(new HBox() {
               {
                  this.getStyleClass().addAll("xfe-trade-notifications-header");
                  this.getChildren().setAll(logo, sliderPane.init(notificationPane));
                  HBox.setMargin(logo, new Insets(4));
                  VBox.setVgrow(this, Priority.NEVER);
               }
            }, new EnhancedTableView<TradeAlert>() {
               {
                  setId("xfe_trade_notifications_table");
                  VBox.setVgrow(this, Priority.ALWAYS);

                  double headerHeight = 15;
                  double rowHeight = 17;

                  this.prefHeightProperty().bind(Bindings.add(headerHeight, Bindings.multiply(rowHeight, Bindings.min(maxRowCountProperty(), Bindings.max(minRowCountProperty(), Fx.sizeOfList(items))))));
                  this.getColumns().setAll(createColumns(items,settingsModule.xfeSessionModule));
                  this.setMinHeight(headerHeight + 3 * rowHeight);
                  this.setItems(tableItems);
                  this.getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
               }

            });
         }
      };
      logonUserId = useId;
      this.setTitle("i-Swap - Trade Notifications");
      if (logger.isTraceEnabled()) {
         logger.debug("Creating Trade Notification pop-up stage...");
         tableItems.addListener(new InvalidationListener() {

            @Override
            public void invalidated(Observable observable) {
               logger.debug("notification table item has {}", tableItems.size());
            }
         });
      }


      appContainer.setContent(vbox);
      appContainer.setAllowIconified(false);
      appContainer.setOnClose(() -> {
         hide();
         items.clear();
         notificationPane.interruptToShowPlaceholder();
         if(TradeNotificationsStage.this.isShowing()){
            TradeNotificationsStage.this.hide();
         }
         return Future.valueOf(false);
      });
      Scene scene = new Scene(appContainer.getRoot());
      scene.setFill(null);

      this.setScene(scene);

      logger.debug("Creating Trade Notification pop-up stage - Done");
      layoutManager.register(this,appContainer);
      this.show();
   }

   final IntegerProperty rowCountProperty() {
      return rowCountProperty;
   }

   private IntegerProperty minRowCountProperty() {
      return minRowCount;
   }

   private IntegerProperty maxRowCountProperty() {
      return maxRowCount;
   }

   private <Value> Proc1<RowValueEvent<TradeAlert, Value, Event>> createActionWrapper() {
      return value -> {
         // if (value.row != null && onAutoHideProperty().get() != null) {
         // onAutoHideProperty().get().handle(new TradeIdEvent(value.row.getTradeId()));
         // }
      };
   }

   @SuppressWarnings("unchecked")
   private List<TableColumn<TradeAlert, ?>> createColumns(ObservableList<TradeAlert> items, XfeSession xfeSession) {
      List<TableColumn<TradeAlert, ?>> columns = new LinkedList<>();

      RowFilterCallback<TradeAlert, Boolean> isStrategyTradeFilterCallback = FilterCallback.create(new Callback<TradeAlert, ObservableBooleanValue>() {
         @Override
         public ObservableBooleanValue call(TradeAlert alert) {
            return alert != null ? Fx.valueOf(alert.isLeg) : Fx.valueOf(false);
         }
      });

      Filter<Pair<TradeAlert, Object>> strategyTradeFilter = isStrategyTradeFilterCallback.bind(Bindings.equal(true, isStrategyTradeFilterCallback.bindingPoint())).build();

      columns.add(new EnhancedTableColumn<TradeAlert, String>() {
         {
            this.setText(COLUMN_NAME_INSTR);
            this.setPrefWidth(130);
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {
                  if (alert.isLeg) {
                     return Fx.constOf("  " + alert.secCode);
                  } else {
                     return Fx.constOf(alert.secCode);
                  }
               }
            });
            this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper())));
         }
      });

      if(xfeSession.getUnderlyingSession().isLoggedOnTrader()) {
         columns.add(new EnhancedTableColumn<TradeAlert, TradeSide>() {
            {
               this.setText("P/R");
               this.setPrefWidth(35);
               this.setValueFactory(new Callback<TradeAlert, ObservableObjectValue<TradeSide>>() {
                  @Override
                  public ObservableObjectValue<TradeSide> call(TradeAlert alert) {
                     return Fx.constOf(alert.side);
                  }
               });

               ValueFilterCallback<TradeSide> filterCallback = FilterCallback.create();
               this.setLayerFactories(layerFactoryWithValue("xfe-bid-cell-label", filterCallback.bind(Bindings.equal(filterCallback.bindingPoint(), TradeSide.BUY)).build(),
                  layerFactoryWithValue("xfe-offer-cell-label", filterCallback.bind(Bindings.equal(filterCallback.bindingPoint(), TradeSide.SELL)).build(), LabeledLayerFactory.create(new Callback<TradeSide, ObservableStringValue>() {
                     @Override
                     public ObservableStringValue call(TradeSide side) {
                        if (side != null) {
                           switch (side) {
                              case BUY:
                                 return Fx.constOf(Constants.LABEL_PAY);
                              case SELL:
                                 return Fx.constOf(Constants.LABEL_REC);
                              case CROSS:
                                 return Fx.constOf("Cross");
                           }
                        }
                        return Fx.constOf("");
                     }
                  }))));
            }
         });
      }

      columns.add(new EnhancedTableColumn<TradeAlert, String>(Pos.TOP_RIGHT) {
         {
            this.setText(Constants.COLUMN_NAME_RATE);
            this.setPrefWidth(61);
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {
                  return alert != null ? Fx.constOf(alert.rate) : null;
               }
            });
            this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
         }
      });

      columns.add(new EnhancedTableColumn<TradeAlert, String>(Pos.TOP_RIGHT) {
         {
            this.setText(Constants.COLUMN_NAME_QTY);
            this.setPrefWidth(54);
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {
                  return alert != null ? Fx.asDecimalString(alert.amount) : null;
               }
            });
            this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
         }
      });

      EventHandler<Event> eventHandler = event -> {
         EnhancedTableCell<TradeAlert, ObservableStringValue> cell = (EnhancedTableCell<TradeAlert, ObservableStringValue>) event.getSource();
         if (cell.getRow() != null)
            TradeWorkupStageFactory.showTradeWorkup(cell.getRow().key);
      };

      columns.add(new EnhancedTableColumn<TradeAlert, String>(MouseEvent.MOUSE_CLICKED, eventHandler, true) {
         {
            this.setText("Status");
            this.setPrefWidth(77);
            EnhancedTableColumn<TradeAlert, String> tableColumn = this;
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {
                  if (alert != null) {
                     StringProperty stringProp = alert.alertStatusProperty();
                     if (!TradesColumns.autoPopupWorkupProp.get() && alert.isNeedFlash(logonUserId)) {
                        tableColumn.getCellStyleClass().add(NodeFlashDecorator.FLASH_TOKEN);
                     }
                     stringProp.addListener((observable, oldValue, newValue) -> {
                        if (oldValue != null && newValue != null && TradeAlert.STATUS_WORKUP.equals(oldValue))
                           tableColumn.getCellStyleClass().remove(NodeFlashDecorator.FLASH_TOKEN);
                     });
                     return stringProp;
                  } else
                     return null;
               }
            });
            this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
         }
      });

      if(xfeSession.getUnderlyingSession().isLoggedOnTrader()) {
         columns.add(new EnhancedTableColumn<TradeAlert, String>() {
            {
               this.setText("CP");
               this.setPrefWidth(106);
               this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
                  @Override
                  public ObservableStringValue call(TradeAlert alert) {
                     if (alert != null) {
                        return Fx.constOf(alert.getCPFirmId());
                     } else {
                        return null;
                     }
                  }
               });
               this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
            }
         });
      }else{
         columns.add(new EnhancedTableColumn<TradeAlert, String>() {
            {
               this.setText("Pay CP");
               this.setPrefWidth(106);
               this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
                  @Override
                  public ObservableStringValue call(TradeAlert alert) {
                     if (alert != null) {
                        return Fx.constOf(alert.getPayCPFirmId());
                     } else {
                        return null;
                     }
                  }
               });
               this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
            }
         });
         columns.add(new EnhancedTableColumn<TradeAlert, String>() {
            {
               this.setText("Rev CP");
               this.setPrefWidth(106);
               this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
                  @Override
                  public ObservableStringValue call(TradeAlert alert) {
                     if (alert != null) {
                        return Fx.constOf(alert.getRecCPFirmId());
                     } else {
                        return null;
                     }
                  }
               });
               this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
            }
         });
      }

      columns.add(new EnhancedTableColumn<TradeAlert, String>() {
         {
            this.setText("Broker");
            this.setPrefWidth(118);
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {
                  if (alert != null) {
                     return Fx.constOf(alert.getBrokerId());
                  } else {
                     return null;
                  }
               }
            });
            this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
         }
      });


      columns.add(new EnhancedTableColumn<TradeAlert, String>() {
         {
            this.setText("Trader Name");
            this.setPrefWidth(118);
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {
                  if (alert != null) {
                     return Fx.constOf(alert.getTraderName());
                  } else {
                     return null;
                  }
               }
            });
            this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper(), LabelBuilder.create(), null)));
         }
      });

      columns.add(new EnhancedTableColumn<TradeAlert, String>() {
         {
            this.setText("Trade Time");
            this.setPrefWidth(74);
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {

                  return Fx.constOf(Constants.timeFormatter.format(alert.timestamp));
               }
            });
            this.setLayerFactories(layerFactoryWithRowValue("xfe-strategy-trade-cell-label", strategyTradeFilter, LabeledLayerFactory.create(createActionWrapper())));
         }
      });


      columns.add(new EnhancedTableColumn<TradeAlert, String>() {
         {
            this.setPrefWidth(29);
            this.setValueFactory(new Callback<TradeAlert, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(TradeAlert alert) {
                  return alert != null ? Fx.constOf("X") : null;
               }
            });
            this.setLayerFactories(layerFactory("xfe-trade-alert-close", Statics.acceptNonNull(), LabeledLayerFactory.create(new Proc1<RowValueEvent<TradeAlert, String, Event>>() {
               @Override
               public void call(RowValueEvent<TradeAlert, String, Event> event) {
                  items.remove(event.row);
               }
            })));
         }
      });

      return columns;
   }

   final void addAlerts(TradeAlert tradeAlert, boolean isNew, Asn1Type asnBuyParentId, Asn1Type asnSellParentId) {
      comparatorAlert.addTradeNode(tradeAlert.tradeId, asnBuyParentId, asnSellParentId);
      if (isNew) {
         items.add(tradeAlert);
      } else {
         int index = items.indexOf(tradeAlert);
         if (index >= 0) {
            TradeAlert existAlert = items.get(index);
            existAlert.alertStatus.set(tradeAlert.getAlertStatus());
            existAlert.amount.set(tradeAlert.amount.get());
         } else {
            logger.warn("Trade alert not added: Trade is not new but does not exist in the list");
         }
      }

      if (!expiryDuration.isZero() && !expiryDuration.isNegative()) {
         Fx.delay(expiryDuration, () -> items.removeAll(tradeAlert));
      }
   }

   static Node createNotification(String string) {
      return new HBox() {
         {
            this.getStyleClass().addAll("xfe-trade-notifications-header-content");
            this.getChildren().addAll(new Label() {
               {
                  this.getStyleClass().addAll("xfe-title");
                  this.setText(string);
               }
            });
         }
      };
   }

   void addNotification(Node notification) {
      sliderPane.get().addNotification(notification);
   }

   final ObjectProperty<EventHandler<TradeIdEvent>> onItemActionProperty() {
      return onItemAction;
   }

   public void dispose() {
      appContainer.setTradeSideProp(null,null);
      hide();
      items.clear();
      comparatorAlert.dispose();
      notificationPane.dispose();
   }

   public void setExpiryDuration(java.time.Duration expiryDuration) {
      this.expiryDuration = expiryDuration;
   }
}
