package xfe.icap.modules.rfq;

import xfe.util.scene.control.AppContainer;
import xfe.util.scene.control.VerticalAppContainer;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import xstr.util.Fun0;
import xstr.util.concurrent.Future;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class RfqNotificationPane {

   private final Stage stage;
   private final String title;
   final ListView<NotificationInfo> root = new ListView<>();

   public void close() {
      stage.close();
   }

    ReadOnlyDoubleProperty posX() {
      return stage.xProperty();
    }

    ReadOnlyDoubleProperty posY() {
      return stage.yProperty();
    }

   public RfqNotificationPane(ObservableList<NotificationInfo> myObservableList,
                              Supplier<Future<Boolean>> closeHandler,
                              String title) {
      this.title = title;
      stage = new Stage(StageStyle.TRANSPARENT);
      stage.setTitle(title);


      root.getStyleClass().add("xfe-list-view");
      root.setItems(myObservableList);
      root.setCellFactory(param -> new CustomCell());

      initContainer(closeHandler);

      stage.show();
      stage.toFront();

      myObservableList.addListener((ListChangeListener<NotificationInfo>) c -> {
         while (c.next()) {
            if (c.wasAdded() && stage != null)
               stage.toFront();
         }
      });
   }

   private final double prefWidth = 600D;
   private final double prefHeight = 130D;
   VerticalAppContainer appContainer = new VerticalAppContainer(null, prefWidth, prefHeight, false, null,true);
   private void initContainer(Supplier<Future<Boolean>> closeHandler) {
      appContainer.setContent(new VBox() {
         {
            this.setPrefWidth(prefWidth);
            this.getChildren().add(new StackPane() {
               {
                  // Header outer
                  StackPane headerOuter = this;
                  this.setMinWidth(prefWidth);
                  this.getChildren().add(new HBox() {
                     {
                        this.prefWidthProperty().bind(headerOuter.widthProperty());
                        this.getStyleClass().addAll("xfe-trade-notifications-header-content");
                        this.setFillHeight(true);
                        this.getChildren().setAll(new ImageView() {
                           {
                              this.getStyleClass().addAll("xfe-icon-app-title");
                           }
                        }, new Pane() {
                           {
                              // Spacer
                              HBox.setHgrow(this, Priority.ALWAYS);
                           }
                        }, new Label() {
                           {
                              // Right Caption
                              this.getStyleClass().add("xfe-title");
                              this.setText(title);
                           }
                        });
                     }
                  });
                  VBox.setVgrow(this, Priority.SOMETIMES);
               }
            });
            this.getChildren().add(root);
            VBox.setVgrow(root, Priority.SOMETIMES);
         }
      });
      appContainer.setAllowIconified(false);
      appContainer.setOnClose(closeHandler);
      stage.setScene(new Scene(appContainer.getRoot()));
      stage.setOnCloseRequest(Event::consume);
   }

   public Stage getStage() {
      return stage;
   }

   private static class CustomCell extends ListCell<NotificationInfo> {
      @Override
      protected void updateItem(NotificationInfo item, boolean empty) {
         super.updateItem(item, empty);

         setText(null);  // No text in label of super class
         if (empty) {
            setGraphic(null);
         } else {
            HBoxCell cellContents = new HBoxCell(item.getRfqNumber(),
                                                 item.getRfqInfo(),
                                                 item.getQuoteClbk(),
                                                 item.getCancelClbk());
            this.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            setGraphic(cellContents);
         }
      }
   }

   private static class HBoxCell extends HBox {

      HBoxCell(Long rfqNumber,
               String rfqInfo,
               Consumer<Long> quoteClbk,
               Consumer<Long> cancelClbk) {
         super();

         Label label = new Label(rfqInfo) {
            {
               setPadding(new Insets(5, 0, 0, 5));
            }
         };
         this.getChildren().add(label);
         this.getChildren().add(new Button("Quote") {
            {
               setOnAction(event -> quoteClbk.accept(rfqNumber));
            }
         });
         this.getChildren().add(new Button("Cancel") {
            {
               setOnAction(event -> cancelClbk.accept(rfqNumber));
            }
         });

         label.setMaxWidth(Double.MAX_VALUE);
         HBox.setHgrow(label, Priority.ALWAYS);
      }
   }

   public void setPosition(double x, double y) {
      if (x >= 0. && y >= 0.) {
         double w = stage.getWidth();
         double h = stage.getHeight();

         boolean stageInBounds = false;
         stage.setX(x);
         stage.setY(y);
         double newX = x;
         double newY = y;

         for (Screen screen : Screen.getScreens()) {
            Rectangle2D screeBounds = screen.getBounds();
            if (screeBounds.contains(x, y, w, h)) {
               stageInBounds = true;
            }

            if (screeBounds.getMinX() == 0. && screeBounds.getMinY() == 0.0) {

               newX = (screeBounds.getWidth() - w) / 2.;
               newY = (screeBounds.getHeight() - h) / 2.;
            }
         }

         // If popup not in bounds of any of the screens we move it to center of main screen
         if (!stageInBounds) {
            stage.setX(newX);
            stage.setY(newY);
         }
      }
   }

   AppContainer getAppContainer(){
      return appContainer;
   }
}
