package xfe.icap.types;

import javafx.beans.binding.IntegerBinding;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import xstr.types.OrderSide;
import xstr.util.Fun1;
import xstr.util.Fun2;
import xstr.util.Fun3;
import xstr.util.Lazy;

import xstr.util.Fx;
import xfe.icap.amp.AmpOrderBookByOrder;
import xstr.session.ObservableReplyRow;
import com.omxgroup.xstream.amp.AmpDisplayCredit;

public class OrderBookSide {
   public final OrderSide side;
   public final ObservableList<ObservableReplyRow> orders;

   public final boolean isBuy() {
	   return this.side == OrderSide.BUY;
   }


   public final Fun1<ObservableReplyRow, ? extends ObservableValue<Double>> availableOrderValueGetter = new Fun1<ObservableReplyRow, ObservableValue<Double>>() {
      @Override
      public ObservableValue<Double> call(ObservableReplyRow row) {
         return Fx.bindApply(
               row.getProperty(AmpOrderBookByOrder.orderTradability),
               row.getProperty(AmpOrderBookByOrder.quantity),
               row.getProperty(AmpOrderBookByOrder.price),
               new Fun3<Integer, Double, Double, Double>() {
                  @Override
                  public Double call(Integer orderTradeability, Double quantity, Double price) {
                     return orderTradeability != AmpDisplayCredit.no ? quantity * price : 0.0;
                  }
               });
      }
   };

   public final Fun1<ObservableReplyRow, ? extends ObservableValue<Double>> totalAvailableQuantityGetter ;

   public final Fun1<ObservableReplyRow, ? extends ObservableValue<Double>> availableQuantityGetter ;
   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableValue<Double>>> totalAvailableOrderValueGetter = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableValue<Double>>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableValue<Double>> initialize() {
         return ObservableReplyRow.fold(
               orders,
               0.0,
               ObservableReplyRow.materializerFor(availableOrderValueGetter),
               Fun2.NULLSAFE_ADD_DOUBLE);
      }
   };

   public final IntegerBinding availabilityChangedObservable ;

   public OrderBookSide(OrderSide side, OrderBook orderBook, ObservableList<ObservableReplyRow> orders) {
      this.side = side;
      this.orders = orders;
      ObservableValue<ObservableReplyRow> lastOrderRow = Fx.lastOf(orders);
      availableQuantityGetter = new Fun1<ObservableReplyRow, ObservableValue<Double>>() {
         @Override
         public ObservableValue<Double> call(ObservableReplyRow row) {
            return Fx.bindApply(row.getProperty(AmpOrderBookByOrder.orderTradability), row.getProperty(AmpOrderBookByOrder.quantity), new Fun2<Integer, Double, Double>() {
               @Override
               public Double call(Integer orderTradeability, Double quantity) {
                  return orderTradeability == null ? 0.0 : (orderTradeability != AmpDisplayCredit.no ? (quantity != null ? quantity : 0.0) : 0.0);
               }
            });
         }
      };

      totalAvailableQuantityGetter = ObservableReplyRow.fold(orders, 0.0, availableQuantityGetter, Fun2.NULLSAFE_ADD_DOUBLE);
      ObservableValue<Double> liveTotalQuantity = Fx.flatMap(lastOrderRow, ObservableReplyRow.materializerFor(totalAvailableQuantityGetter), Fx.objectValueOf(0.0));
      availabilityChangedObservable = Fx.countChanges(liveTotalQuantity);
   }

}
