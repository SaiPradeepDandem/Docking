package xfe.icap.modules.settingsview;

import com.nomx.persist.ParametersStorage;
import com.nomx.persist.PersistantName;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settings.SettingsData;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.util.EasyFXML;
import xstr.types.User;
import xstr.util.Fx;
import xstr.util.concurrent.Future;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Module.Autostart
public class SettingsViewModule extends SessionScopeModule implements SettingsViewTab {
   private static final Logger logger = LoggerFactory.getLogger(SettingsViewModule.class);

   @ModuleDependency
   public ConfigurationModule configurationModule;

   private Set<PersistantName> relevantItems;
   private SettingsData data;
   private SettingsData changingData;

   @Override
   public Future<Void> startModule() {
      this.relevantItems = new HashSet<>(SettingsData.getNames());
      final User currentUser = activeSessionModule.getSession().get().getLoggedOnUser();
      if (currentUser.isBroker()) {
         relevantItems.remove(PersistantName.ManagedOrders);
      }

      this.data = configurationModule.getData();
      this.changingData = data.copy();

      this.settingsViewLayout = EasyFXML.load(SettingsViewLayout.class);
      activeSessionModule.getSession().ifPresent((xfeSession) -> {
         this.settingsViewLayout.tailorForRole(xfeSession);
         this.settingsViewLayout.bindSettingsData(changingData, xfeSession);
      });

      initialize();
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      return super.stopModule();
   }

   private void initialize() {
      this.cancelHandler = () -> {
         if (this.settingsViewTabs.stream().anyMatch(SettingsViewTab::isModified)) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "If you don't save, your changes will be lost",
               ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
            alert.setHeaderText("Do you want to save the changes to the settings?");
            alert.showAndWait().ifPresent(result -> {
               if (result == ButtonType.YES) {
                  saveSettingsView();
               } else if (result == ButtonType.NO) {
                  this.settingsViewTabs.forEach(SettingsViewTab::reset);
                  closeSettingsView();
               }
            });
         } else {
            closeSettingsView();
         }
      };
      this.settingsViewLayout.setSaveHandler(this::saveSettingsView);
      this.settingsViewLayout.setCancelHandler(this.cancelHandler);
      this.settingsViewLayout.setLoadDefaultSettingsHandler(this::loadDefaultSettings);
      this.settingsViewTabs.add(this);
   }

   public void addView(Node view, SettingsViewTab settingsViewTab) {
      String title = null;
      switch (view.getId()) {
         case MidiLayoutViews.MMGROUPVIEW:
            title = "MM Group";
            break;
         case MidiLayoutViews.LINELISTVIEW:
            title = "Line List";
            break;
         case MidiLayoutViews.TAB_EDITORVIEW:
            title = "Tab Editor";
            break;
         case MidiLayoutViews.INSTRUMENT_SETTINGSVIEW:
            title = "Product Settings";
            break;
      }
      if (title != null) {
         this.settingsViewLayout.addNewTab(view, title);
         this.settingsViewTabs.add(settingsViewTab);
      }
   }

   public void removeView(Node view, SettingsViewTab settingsViewTab){
      this.settingsViewLayout.removeTab(view.getId());
      this.settingsViewTabs.remove(settingsViewTab);
   }
   public void onPopupShown() {
      this.settingsViewTabs.forEach(SettingsViewTab::onShown);
   }

   public Node getRoot() {
      return settingsViewLayout.getRoot();
   }

   private void saveSettingsView() {
      this.settingsViewTabs.stream().filter(SettingsViewTab::isModified).forEach(SettingsViewTab::save);
      closeSettingsView();
   }

   public void resetAllForTestFX(){
      this.settingsViewTabs.stream().forEach(SettingsViewTab::resetForTestFX);
   }

   private void loadDefaultSettings() {
      changingData.getStorage().revertToDefaults(PersistantName.settingsItems);
      changingData.revertAutoOCO();
   }

   @Override
   public void resetForTestFX() {
      loadDefaultSettings();
      save();
   }

   private void closeSettingsView() {
      getRoot().getScene().getWindow().hide();
   }

   public Runnable getCancelHandler() {
      return cancelHandler;
   }

   private Runnable cancelHandler;

   private SettingsViewLayout settingsViewLayout;

   private List<SettingsViewTab> settingsViewTabs = new ArrayList<>();

   @Override
   public boolean isModified() {
      return !ParametersStorage.equals(data.getStorage(), changingData.getStorage(), relevantItems);
   }

   @Override
   public Future<Void> save() {
      // Do not check isModified again because save only called after checking isModified so it's wasting process.
      Set<PersistantName> changes = ParametersStorage.changes(data.getStorage(), changingData.getStorage(), relevantItems);
      if (!changes.isEmpty()) {
         ParametersStorage.logChanges(logger, data.getStorage(), changingData.getStorage(), changes);
         // Applying the changes
         if (changes.contains(PersistantName.HiVis)) {
            //notificationModule.showModalView(ConfirmView.create("Updating Hi-Vis property, Please wait", 3000));
         }
         Fx.delay(1000L, () -> {
            data.getStorage().setAll(changingData.getStorage(), SettingsData.getNames());
         });
      }

      boolean currAutoOCO = changingData.autoOCOProperty().get();
      if (data.autoOCOProperty().get() != currAutoOCO) {
         // In this case we need to send a TE transaction to change the autoOCO value.
         data.setAutoOCO(currAutoOCO);
         // SendAutoOCO(currAutoOCO); TODO
      }
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> reset() {
      changingData.getStorage().setAll(data.getStorage(), SettingsData.getNames());
      changingData.revertAutoOCO();
      return Future.SUCCESS;
   }
}
