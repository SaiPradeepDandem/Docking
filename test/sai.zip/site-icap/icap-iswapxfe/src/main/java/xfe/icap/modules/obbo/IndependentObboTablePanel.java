package xfe.icap.modules.obbo;

import xfe.util.XfePickupAction;
import xstr.session.ObservableReplyRow;
import javafx.beans.*;
import javafx.beans.property.*;
import javafx.beans.value.*;
import javafx.scene.Node;
import javafx.scene.control.TablePosition;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import org.slf4j.Logger;
import xstr.util.Lazy;

import xfe.icap.types.OrderBook;
import xstr.types.OrderSide;
import xfe.icap.XfeSession;
import xfe.util.XfeAction;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.util.Constants;
import xfe.ui.notifications.ModalAlertModule;

public class IndependentObboTablePanel implements Constants{
   private final XfeSession xfeSession;
   private final BooleanProperty bidOnLeftProperty = new SimpleBooleanProperty(true);
   private final OrderBook orderBook;
   private final boolean is4PopupStage;
   private final ObboModule obboModule;
   private final ModalAlertModule eventNotification;

   private final ObjectProperty<XfePickupAction> pickedupActionProp = new SimpleObjectProperty<>();

   public final Lazy<HBox> contentNode = new Lazy<HBox>() {
      @Override
      protected HBox initialize() {
         HBox hbox = new HBox();
         HBox.setHgrow(bidSidePane.get(), Priority.ALWAYS);
         HBox.setHgrow(offerSidePane.get(), Priority.ALWAYS);
         return hbox;
      }
   };

   Lazy<ObboSidePane> bidSidePane = new Lazy<ObboSidePane>() {
      @Override
      protected ObboSidePane initialize() {
         return new ObboSidePane(xfeSession,
               OrderSide.BUY, obboModule, eventNotification, true, bidOnLeftProperty, orderBook.bidSide,pickedupActionProp,is4PopupStage);
      }
   };

   Lazy<ObboSidePane> offerSidePane = new Lazy<ObboSidePane>() {
      @Override
      protected ObboSidePane initialize() {
         return new ObboSidePane(xfeSession,
               OrderSide.SELL, obboModule, eventNotification, false, bidOnLeftProperty, orderBook.offerSide,pickedupActionProp,is4PopupStage);
      }
   };

   private final Lazy<HBox> centralDivide = new Lazy<HBox>() {
      @Override
      protected HBox initialize() {
         HBox hbox = new HBox();
         hbox.setPrefWidth(3);
         hbox.setMinWidth(Region.USE_PREF_SIZE);
         return hbox;
      }
   };

   public void arrangeGrid() {
      if (bidOnLeftProperty.get())
         contentNode.get().getChildren().setAll(bidSidePane.get(), centralDivide.get(), offerSidePane.get());
      else
         contentNode.get().getChildren().setAll(offerSidePane.get(), centralDivide.get(), bidSidePane.get());
   }

   private final InvalidationListener pickupModeLis ;
   private final  ChangeListener<XfeAction> pickupActionLis = new ChangeListener<XfeAction>() {

      @Override
      public void changed(ObservableValue<? extends XfeAction> paramObservableValue, XfeAction oldAction, XfeAction newAction) {
         if(oldAction!=null){
            java.util.List<String> styles = oldAction.getStyleClass();
            styles.remove(PICKEDUP_ACTION_STYLE);
            styles.add(PICKUP_ACTION_STYLE);
         }
         if(newAction!=null){
            java.util.List<String> styles = newAction.getStyleClass();
            styles.add(PICKEDUP_ACTION_STYLE);
            styles.remove(PICKUP_ACTION_STYLE);

         }
      }
   };

   public IndependentObboTablePanel(
         XfeSession session,
         ModalAlertModule eventNotification,
         OrderBook orderBook,
         ObboModule obboModule){
      this(session,eventNotification,orderBook,obboModule,false);
   }

   public IndependentObboTablePanel(
         XfeSession session,
         ModalAlertModule eventNotification,
         OrderBook orderBook,
         ObboModule obboModule, boolean isPopup) {
      this.is4PopupStage = isPopup;
      this.obboModule = obboModule;
      this.eventNotification = eventNotification;
      this.xfeSession = session;
      this.orderBook = orderBook;
      pickupModeLis = new InvalidationListener() {

         @Override
         public void invalidated(Observable observable) {
            if(!session.rfsPickup.get()){
               pickedupActionProp.set(null);
            }
         }
      };


      xfeSession.rfsPickup.addListener(pickupModeLis);
      pickedupActionProp.addListener(pickupActionLis);

   }

   public BooleanProperty bidOnLeftProperty() {
      return bidOnLeftProperty;
   }

   void setSelectedGrid(GridType type) {
      bidSidePane.get().setActive(type == GridType.OBBO_BUY);
      offerSidePane.get().setActive(type == GridType.OBBO_SELL);
   }

   public Node getContentNode() {
      return contentNode.get();
   }

   public void highlightTo(boolean obboSideIsBuy, int toRow) {
	   if (obboSideIsBuy)
		   bidSidePane.get().highlightTo(toRow);
	   else
		   offerSidePane.get().highlightTo(toRow);
   }

   public void selectRow(boolean obboSideIsBuy, int rowIndex) {
		if (obboSideIsBuy)
			bidSidePane.get().selectRow(rowIndex);
		else
			offerSidePane.get().selectRow(rowIndex);
   }

   void selectRow(boolean obboSideIsBuy, ObservableReplyRow rfwRow, TablePosition tablePosition, Logger logger) {
      if (obboSideIsBuy)
         bidSidePane.get().selectRow(rfwRow, tablePosition, logger);
      else
         offerSidePane.get().selectRow(rfwRow, tablePosition, logger);
   }

   public void dispose(){
      bidSidePane.get().dispose();
      offerSidePane.get().dispose();
      xfeSession.rfsPickup.removeListener(pickupModeLis);
      pickedupActionProp.removeListener(pickupActionLis);
   }
}
