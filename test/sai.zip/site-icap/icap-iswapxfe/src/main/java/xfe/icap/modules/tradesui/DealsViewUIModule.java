package xfe.icap.modules.tradesui;

import com.nomx.persist.watchlist.ColumnsSpec;
import com.omxgroup.xstream.amp.AmpDealStatus;
import com.omxgroup.xstream.amp.AmpDealType;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpDeal;
import xfe.icap.modules.dealsdata.DealsDataModule;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.toolbar.actions.ActionToolBarUIModule;
import xfe.module.Module;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.modules.session.SessionScopeModule;
import xfe.util.XfeAction;
import xstr.amp.AMP;
import xstr.amp.AmpService;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.session.XtrTransRequestBuilder;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Consumer;

@Module.Autostart
public class DealsViewUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(DealsViewUIModule.class);

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ActionToolBarUIModule actionToolBarUIModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   @ModuleDependency
   public DealsDataModule dealsDataModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   private Pane root;

   public Pane getRoot() {
      return root;
   }

   private DealsViewTable dealsViewTable;

   private XfeAction tradesAction;

   // Showing the deals popup automatically if the setting property is set.
   private ListChangeListener<? super ObservableReplyRow> listener = c -> {
      checkForTradeFlash(dealsDataModule.getAllDeals());
      while (c.next()) {
         final List<? extends ObservableReplyRow> list = c.getAddedSubList();
         if (configurationModule.getData().tradeAutoPopupProperty().get()) {
            for (ObservableReplyRow row : list) {
               if (isDealBrokerApproved(row)) {
                  midiLayoutModule.addView(getRoot());
                  return;
               }
            }
         }
      }
   };
   @Override
   public Future<Void> startModule() {
      if(!midiLayoutModule.isGiltsSite()){
         return Future.SUCCESS;
      }
      ObservableList<ObservableReplyRow> deals = dealsDataModule.getAllDeals();
      deals.addListener(listener);
      dealsViewTable = new DealsViewTable();
      dealsViewTable.setCOGWheelToTheLeft(true);
      dealsViewTable.setItems(deals);
      dealsViewTable.setTradesColsSpecificationPropertySupplier(this::getTradesColsSpecificationProperty);
      dealsViewTable.setIsDealBrokerApproved(this::isDealBrokerApproved);
      dealsViewTable.setDealApproveFactory(this::dealAgreeValueFactoryImpl);
      dealsViewTable.setSideFactory(this::sideValueFactoryImpl);
      dealsViewTable.setTradeRefFactory(this::extTradeRefValueFactoryImpl);
      dealsViewTable.setTypeFactory(this::typeValueFactoryImpl);
      dealsViewTable.setStatusFactory(this::statusValueFactoryImpl);
      dealsViewTable.setCommTypeFactory(this::commTypeFactoryImpl);
      dealsViewTable.setNetValueFactory(this::netValueFactoryImpl);
      dealsViewTable.setTraderFactory(this::traderValueFactoryImpl);
      dealsViewTable.setBrokerFactory(this::brokerValueFactoryImpl);
      dealsViewTable.setDealApproveOp(this::approveDeal);
      dealsViewTable.setTradesAggregatePopupActionConsumer(this::doTradesAggregatePopupAction);
      dealsViewTable.setSecBoardStaticInfoGetter(securitiesDataModule::getStaticInfo);

      this.root = new StackPane();
      this.root.setId(MidiLayoutViews.TRADESVIEW);
      this.root.getChildren().add(dealsViewTable);

      tradesAction = new XfeAction();
      tradesAction.setActionId("trades");
      tradesAction.setOnAction(e -> midiLayoutModule.addView(getRoot()));
      tradesAction.getStyleClass().add("xfe-icon-trades");
      actionToolBarUIModule.addViewAction(tradesAction);

      if (configurationModule.getData().tradesViewOpened().get()) {
         midiLayoutModule.addView(getRoot());
      }
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tradesAction.setOnAction(null);
      dealsDataModule.getAllDeals().removeListener(listener);
      dealsViewTable.setTradesColsSpecificationPropertySupplier(null);
      dealsViewTable.setIsDealBrokerApproved(null);
      dealsViewTable.setDealApproveFactory(null);
      dealsViewTable.setSideFactory(null);
      dealsViewTable.setTradeRefFactory(null);
      dealsViewTable.setTypeFactory(null);
      dealsViewTable.setStatusFactory(null);
      dealsViewTable.setCommTypeFactory(null);
      dealsViewTable.setNetValueFactory(null);
      dealsViewTable.setTraderFactory(null);
      dealsViewTable.setBrokerFactory(null);
      dealsViewTable.setDealApproveOp(null);
      dealsViewTable.setTradesAggregatePopupActionConsumer(null);
      dealsViewTable.setSecBoardStaticInfoGetter(null);
      midiLayoutModule.removeView(getRoot());
      return Future.SUCCESS;
   }

   private void checkForTradeFlash(List<? extends ObservableReplyRow> trades) {
      boolean isBrokerApproved = trades.stream().anyMatch(this::isDealBrokerApproved);
      actionToolBarUIModule.toggleTradeButtonFlash(isBrokerApproved);
   }

   public boolean isDealBrokerApproved(QueryReplyRow row) {
      return AmpDealStatus.brokerApproved == row.getValue(AmpDeal.status);
   }

   private ObservableValue<XfeAction> dealAgreeValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> isBrokerApproved(row), row.rowProperty());
   }

   private ObservableValue<BigDecimal> netValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getNetValue(row), row.rowProperty());
   }

   private BigDecimal getNetValue(ObservableReplyRow row) {
      return row.getValue(AmpDeal.adjustedPrice);
   }

   private ObservableValue<String> commTypeFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getCommType(row), row.rowProperty());
   }

   private String getCommType(ObservableReplyRow row) {
      return row.getValue(AmpDeal.commissionType);
   }

   private ObservableValue<String> typeValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getType(row), row.rowProperty());
   }

   private String getType(ObservableReplyRow row) {
      Integer strategyType = row.getValue(AmpDeal.dealType);
      if (strategyType == null) return null;

      if (strategyType == AmpDealType.dealOutright)
         return "Outright";
      if (strategyType == AmpDealType.dealStrategy)
         return "Strategy";
      if (strategyType == AmpDealType.dealStrategyLeg || strategyType == AmpDealType.dealBasisLeg)
         return "Leg";
      if (strategyType == AmpDealType.dealNone)
         return "None";

      return null;
   }

   private ObservableValue<String> statusValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getStatus(row), row.rowProperty());
   }

   private String getStatus(ObservableReplyRow row) {
      return AmpDeal.getStatusAsString(row.getValue(AmpDeal.status));
   }

   private ObservableValue<String> traderValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getTrader(row), row.rowProperty());
   }

   private String getTrader(ObservableReplyRow row) {
      return row.getValue(AmpDeal.traderId);
   }


   private ObservableValue<String> brokerValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getBroker(row), row.rowProperty());
   }

   private String getBroker(ObservableReplyRow row) {
      return row.getValue(AmpDeal.operatorId);
   }

   private ObservableValue<OrderSide> sideValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getSide(row), row.rowProperty());
   }

   public static OrderSide getSide(ObservableReplyRow row) {
      Integer buySell = row.getValue(AmpDeal.buySell);
      if (buySell != null) {
         if (buySell == AmpOrderVerb.buy) {
            return OrderSide.BUY;
         } else if (buySell == AmpOrderVerb.sell) {
            return OrderSide.SELL;
         }
      }
      return null;
   }

   private ObservableValue<String> extTradeRefValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getExtDealRef(row), row.rowProperty());
   }

   private String getExtDealRef(ObservableReplyRow row) {
      return row.getValue(AmpDeal.extDealId);
   }

   private XfeAction isBrokerApproved(ObservableReplyRow row) {
      OrderSide orderSide = getSide(row);
      boolean brokerApproved = isDealBrokerApproved(row);
      if (orderSide != null && brokerApproved) {
         XfeAction action = new XfeAction();
         action.getStyleClass().add("xfe-icon-confirm");
         action.setOnAction(event -> approveDeal(row, Boolean.FALSE));
         return action;
      } else {
         XfeAction action = new XfeAction();
         action.setAvailable(false);
         return action;
      }
   }

   private void approveDeal(ObservableReplyRow row, Boolean onlyCurrentUser) {
      activeSessionModule.getSession().ifPresent(session -> {
         if (onlyCurrentUser != null && onlyCurrentUser) {
            String loggedOnUserId = session.getLoggedOnUserId();
            if (!row.getValue(AmpDeal.traderId).equals(loggedOnUserId))
               return;
         }
         AMP.AmpTreq trns = AMP.tREQ("dealApprove");
         try {
            XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(trns, session)
               .setAsn(AmpService.INSTANCE.getAccessor(AMP.tREQ("dealApprove.dealId")),
                  row.getAsn(AmpDeal.dealId));
            session.execute(reqBuilder.build());
         } catch (AsnTypeException | AmpPermissionException e) {
            logger.error("Catch Exception : {}", e.getMessage());
            logger.info("Catch Exception : ", e);
         }
      });
   }

   public void setTradesAggregatePopupHandler(Consumer<TradesAggregateArgs> tradesAggregatePopupHandler) {
      this.tradesAggregatePopupHandler = tradesAggregatePopupHandler;
   }

   private void doTradesAggregatePopupAction(TradesAggregateArgs args) {
      if (tradesAggregatePopupHandler != null)
         tradesAggregatePopupHandler.accept(args);
   }

   private Consumer<TradesAggregateArgs> tradesAggregatePopupHandler;

   private ObjectProperty<ColumnsSpec> getTradesColsSpecificationProperty(){
     return  configurationModule.getData().tradesColsSpecificationProperty();
   }
}

