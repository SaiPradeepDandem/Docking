package xfe.icap.modules.tradesdata;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpTrade;
import xfe.icap.types.Trade;
import xfe.types.SecBoard;
import xstr.session.*;

import java.util.*;

public class IswapTradesFeedAdapter implements QueryFeed {
   private static final Logger logger = LoggerFactory.getLogger(IswapTradesFeedAdapter.class);

   public IswapTradesFeedAdapter(QueryFeed feed) {
      listener = feedEvents -> {
         List<QueryRowEvent> handledFeedEvents = new ArrayList<>();
         for (QueryRowEvent ev : feedEvents) {
            switch (ev.getEventType()) {
               case CREATE:
                  handleEvent(ev, handledFeedEvents);
                  break;
               case CLEAR:
                  giltsTradeIds.clear();
                  nonGiltsStrategyTrades.clear();
                  nonGiltsLegTrades.clear();
                  break;
               case UPDATE:
                  System.out.println("Checkout !! an UPDATE is fired");
                  break;
               case DELETE:
                  System.out.println("Checkout !! a DELETE is fired");
                  break;
               case NONE:
               case UNKNOWN:
               default:
                  break;
            }
         }

         for (QueryFeedListener l : listeners) {
            try {
               l.handleEvent(handledFeedEvents);
            } catch (Exception e) {
               logger.error("Error while processing events:", e);
            }
         }
      };
      this.srcFeed = feed;
   }

   private void handleEvent(QueryRowEvent ev, List<QueryRowEvent> handledFeedEvents) {
      final QueryReplyRow row = ev.getNewRow();
      final String tradeNo = row.getValue(AmpTrade.tradeNo);
      final boolean isGilts = SecBoard.isGilt(row.getValue(AmpTrade.boardId));
      if (isGilts) {
         // Keeping cache of all gilts trades
         giltsTradeIds.add(tradeNo);
         //Ensuring to remove any non-gilts leg trades of this gilts strategy trade
         nonGiltsLegTrades.remove(tradeNo);
      } else {
         // Non Gilts Trade
         boolean isLeg = isLegTrade(row);
         if (isLeg) {
            // This is a Non-Gilts leg trade
            String parentTradeNo = getStrategyTradeNo(row);
            // If the strategy/parent trade of this non-gilts leg trade is a Gilts
            if (giltsTradeIds.contains(parentTradeNo)) {
               // Do nothing if it is a leg of gilts trade
            } else {
               // Not sure whether its parent is a GILTS or not. So better keep a backup for later use.
               putTradeInNonGiltsLegTradeMap(row);
               // Cross check for parent trade and leg trades count. If everything is retrieved include them.
               checkAndCreateIfAllTradesRetrieved(parentTradeNo, handledFeedEvents);
            }
         } else {
            // This is a Non-Gilts Strategy/Parent trade
            Integer type = row.getValue(AmpTrade.buyTraderId) != null ? row.getValue(AmpTrade.buyStrategyTradeType) : row.getValue(AmpTrade.sellStrategyTradeType);
            if (Trade.isStrategyType(type)) {
               // If it is a strategy type & Non-Gilts trade, better keep a reference for later use.
               nonGiltsStrategyTrades.put(tradeNo, row);
               // Cross check for parent trade and leg trades count. If everything is retrieved include them.
               checkAndCreateIfAllTradesRetrieved(tradeNo, handledFeedEvents);
            } else {
               // If it is a non strategy type & Non-Gilts trade, then include it directly.
               includeCreateEvent(ev.getNewRow(), handledFeedEvents);
            }
         }
      }
   }

   private void checkAndCreateIfAllTradesRetrieved(String parentTradeNo, List<QueryRowEvent> handledFeedEvents) {
      QueryReplyRow parentTrade = nonGiltsStrategyTrades.get(parentTradeNo);
      List<QueryReplyRow> legTrades = nonGiltsLegTrades.get(parentTradeNo);
      Long desiredLegTradesCount = -1L;
      if (parentTrade != null) {
         desiredLegTradesCount = parentTrade.getValue(AmpTrade.numLegTrades);
      }
      if (parentTrade != null && legTrades != null && legTrades.size() == desiredLegTradesCount) {
         includeCreateEvent(parentTrade, handledFeedEvents);
         // TODO : check the order to create leg events
         legTrades.forEach(legTrade -> includeCreateEvent(legTrade, handledFeedEvents));
      }
   }

   private void includeCreateEvent(QueryReplyRow row, List<QueryRowEvent> handledFeedEvents) {
      QueryReplyRow newRow = new AbstractQueryReplyRow(row.getKey(), row.getData(), row.getTimestamp()) {
         @Override
         public XtrQueryRequest getRequest() {
            return null;
         }
      };
      QueryRowEvent createEvent = QueryRowEvent.create(newRow);
      handledFeedEvents.add(createEvent);
   }

   private void putTradeInNonGiltsLegTradeMap(QueryReplyRow row) {
      String parentTradeNo = getStrategyTradeNo(row);
      List<QueryReplyRow> legTrades = nonGiltsLegTrades.get(parentTradeNo);
      if (legTrades == null) {
         legTrades = new ArrayList<>();
         nonGiltsLegTrades.put(parentTradeNo, legTrades);
      }
      legTrades.add(row);
   }

   public static Boolean isLegTrade(QueryReplyRow row) {
      return row.getAsn(AmpTrade.buyStrategyTradeId) != null || row.getAsn(AmpTrade.sellStrategyTradeId) != null;
   }

   public static String getStrategyTradeNo(QueryReplyRow row) {
      boolean isBuy = row.getValue(AmpTrade.buyTraderId) != null;
      return isBuy ? row.getValue(AmpTrade.buyStrategyTradeNo) : row.getValue(AmpTrade.sellStrategyTradeNo);
   }

   public void startPolling() {
      srcFeed.addListener(listener);
   }

   public void stopPolling() {
      srcFeed.removeListener(listener);
   }

   @Override
   public void addContListener(QueryFeedListener sink) {
      listeners.add(sink);
   }

   @Override
   public void addListener(QueryFeedListener sink) {
      listeners.add(sink);
   }

   @Override
   public void removeListener(QueryFeedListener sink) {
      listeners.remove(sink);
      sink.handleEvent(Collections.emptyList());
   }

   @Override
   public void dispose() {
      srcFeed.removeListener(listener);
      listeners.clear();
      giltsTradeIds.clear();
      nonGiltsStrategyTrades.clear();
      nonGiltsLegTrades.clear();
   }

   private final HashSet<QueryFeedListener> listeners = new HashSet<>();
   private final QueryFeedListener listener;
   private final QueryFeed srcFeed;

   private Set<String> giltsTradeIds = new HashSet<>();
   private Map<String, List<QueryReplyRow>> nonGiltsLegTrades = new HashMap<>();
   private Map<String, QueryReplyRow> nonGiltsStrategyTrades = new HashMap<>();

}
