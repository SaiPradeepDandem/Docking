package xfe.icap.amp;

import java.math.BigDecimal;
import java.util.Date;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import com.omxgroup.syssrv.Duration;

public class AmpManagedOrder extends AmpAccessor {
   public static final AmpQreq req = AMP.qREQ("managedOrderReq");
   public static final AmpQrep rep = AMP.qREP("managedOrderRep");



   public static final AsnAccessor currentOrderId = acc(AMP.qREP("managedOrderRep.currentOrderId"));
   public static final AsnAccessor managedOrderIdAcc = acc(AMP.qREP("managedOrderRep.managedOrderId"));
   public static final AsnConversionAccessor<String> secBoardId = acc(AMP.qREP("managedOrderRep.statics.secBoardId"), String.class);
   public static final AsnConversionAccessor<String> firmId = acc(AMP.qREP("managedOrderRep.statics.firmId"), String.class);
   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("managedOrderRep.statics.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("managedOrderRep.statics.secBoardId.boardId"), String.class);
   public static final AsnConversionAccessor<String> userId = acc(AMP.qREP("managedOrderRep.dynamics.userId"), String.class);
   public static final AsnConversionAccessor<String> introBrokerId = acc(AMP.qREP("managedOrderRep.dynamics.introBrokerId"), String.class);
   public static final AsnConversionAccessor<String> operatorId = acc(AMP.qREP("managedOrderRep.dynamics.operatorId"), String.class);
   public static final AsnConversionAccessor<String> updateOperatorId = acc(AMP.qREP("managedOrderRep.dynamics.updateOperatorId"), String.class);
   public static final AsnConversionAccessor<Integer> orderStatus = acc(AMP.qREP("managedOrderRep.dynamics.orderStatus"), Integer.class);
   public static final AsnConversionAccessor<Boolean> shared = acc(AMP.qREP("managedOrderRep.dynamics.shared"), Boolean.class);
   public static final AsnConversionAccessor<Double> price_d = acc(AMP.qREP("managedOrderRep.dynamics.price"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> price = acc(AMP.qREP("managedOrderRep.dynamics.price"), BigDecimal.class);
   public static final AsnConversionAccessor<String> priceStr = acc(AMP.qREP("managedOrderRep.dynamics.price"), String.class);
   public static final AsnConversionAccessor<Double> quantity_d = acc(AMP.qREP("managedOrderRep.dynamics.quantity"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> quantity = acc(AMP.qREP("managedOrderRep.dynamics.quantity"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> balance_d = acc(AMP.qREP("managedOrderRep.dynamics.balance"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> balance = acc(AMP.qREP("managedOrderRep.dynamics.balance"), BigDecimal.class);
   public static final AsnConversionAccessor<Duration> durationTime = acc(AMP.qREP("managedOrderRep.dynamics.durationTime"), Duration.class);
   public static final AsnConversionAccessor<Integer> durationType = acc(AMP.qREP("managedOrderRep.dynamics.duration"), Integer.class);
   public static final AsnConversionAccessor<Date> expiryTime = acc(AMP.qREP("managedOrderRep.dynamics.expiryTime"), Date.class);
   public static final AsnConversionAccessor<Integer> actionOnLogoff = acc(AMP.qREP("managedOrderRep.dynamics.actionOnLogoff"), Integer.class);
   public static final AsnConversionAccessor<Double> visibleQuantity = acc(AMP.qREP("managedOrderRep.dynamics.visibleQuantity"), Double.class);
   public static final AsnConversionAccessor<Double> minFillQuantity = acc(AMP.qREP("managedOrderRep.dynamics.minFillQuantity"), Double.class);
   public static final AsnConversionAccessor<Boolean> allowMultiMinFill = acc(AMP.qREP("managedOrderRep.dynamics.allowMultiMinFill"), Boolean.class);
   public static final AsnConversionAccessor<String> orderType = acc(AMP.qREP("managedOrderRep.dynamics.orderType"), String.class);
   public static final AsnConversionAccessor<Long> managedOrderId = acc(AMP.qREP("managedOrderRep.managedOrderId"), Long.class);
   public static final AsnConversionAccessor<Long> normalOrderId = acc(AMP.qREP("managedOrderRep.currentOrderId.orderNo"), Long.class);
   public static final AsnConversionAccessor<Date> normalOrderDate = acc(AMP.qREP("managedOrderRep.currentOrderId.orderDate"), Date.class);
   public static final AsnConversionAccessor<Date> entryTime = acc(AMP.qREP("managedOrderRep.statics.entryTime"), Date.class);
   public static final AsnConversionAccessor<Date> amendTime = acc(AMP.qREP("managedOrderRep.dynamics.amendTime"), Date.class);
   public static final AsnConversionAccessor<Integer> buySell = acc(AMP.qREP("managedOrderRep.statics.buySell"), Integer.class);
   public static final AsnConversionAccessor<Boolean> isDoneIfTouched = acc(AMP.qREP("managedOrderRep.statics.isDoneIfTouched"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> isPublic = acc(AMP.qREP("managedOrderRep.dynamics.isPublic"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> cloneIntoRFS = acc(AMP.qREP("managedOrderRep.dynamics.cloneIntoRFS"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> managedOrder = acc(AMP.qREP("managedOrderRep.statics.managedOrder"), Boolean.class);

   // XFE unsupported fields that may be received via TW and need to retain their values on orderAmend
   public static final AsnConversionAccessor<Integer> trackingType = acc(AMP.qREP("managedOrderRep.dynamics.trackingType"), Integer.class);
   public static final AsnAccessor trackedSecBoardId = acc(AMP.qREP("managedOrderRep.dynamics.trackedSecBoardId"));
   public static final AsnConversionAccessor<Boolean> isTopcut = acc(AMP.qREP("managedOrderRep.dynamics.isTopcut"), Boolean.class);
   public static final AsnAccessor clearingMemberFirmTrdAccId = acc(AMP.qREP("managedOrderRep.dynamics.clearingMemberFirmTrdAccId"));
   public static final AsnConversionAccessor<Double> doddFrankMidMkt = acc(AMP.qREP("managedOrderRep.dynamics.doddFrankMidMkt"), Double.class);
   public static final AsnConversionAccessor<Integer> orderEvent = acc(AMP.qREP("managedOrderRep.orderEvent"), Integer.class);

   /** EXTRA FIELD ACCESSOR DEFINITION EXAMPLE **/
   public static final AsnConversionAccessor<String> idmShortCode = acc(AMP.qREP("managedOrderRep.dynamics.extraFieldsList"),
      "idmShortCode",
      String.class);
   /** ORDER TAG Allowed values "AGG" "CLOB" "CM" */
   public static final AsnConversionAccessor<String> orderTag = acc(AMP.qREP("managedOrderRep.dynamics.extraFieldsList"),
                                                                        "orderTag",
                                                                        String.class);

   // values: for above field are:
   // "cmpricechanged" - CM price was changed
   // "clearforworkup" - an immediate order being refered at end of workup
   // "referred" - refered normally (e.g. via transaction)
   // "" - was not refered

   public static final Integer OPENED = 1;
   public static final Integer REFERRED = 12;

   public static String getOrderStatusDisplayValue(Integer orderStatus) {
      switch (orderStatus) {
         case 1:
            return "Open";
         case 2:
            return "Amended";
         case 3:
            return "Matched";
         case 4:
            return "Withdrawn";
         case 5:
            return "Unconfirmed";
         case 6:
            return "Unapproved";
         case 7:
            return "Expired";
         case 8:
            return "Inactive Stop";
         case 9:
            return "Unplaced Stop";
         case 10:
            return "Unplaced";
         case 11:
            return "Embargoed";
         case 12:
            return "Refer";
         case 13:
            return "Pending";
         case 14:
            return "Confirmed";
         case 15:
            return "Clearing Queued";
         case 16:
            return "Withdraw Pending";
         case 17:
            return "Pending Clearing";
         default:
            throw new IllegalArgumentException("Not a valid order status code");
      }
   }
}

//BUY_SELL(rep + ".statics.buySell"),
//IS_DARK(rep + ".statics.isDark"),
//CURRENT_ORDER_ID(rep + ".currentOrderId"),
//IS_PUBLIC(rep + ".dynamics.isPublic"),
//IS_IMMEDIATE(rep + ".dynamics.duration"),
