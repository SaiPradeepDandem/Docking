package xfe.icap.modules.tabeditorview;

import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xfe.ui.InitialisableView;
import xfe.ui.Nodes;
import xfe.util.XfeFocusModel;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.util.Fx;
import xstr.util.ListenerTracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.function.Consumer;

public class WatchlistEditView implements InitialisableView<Pane> {
   @SuppressWarnings("unused")
   private static final Logger logger = LoggerFactory.getLogger(WatchlistEditView.class);

   private static final int INSTRUMENTS_MAX_COUNT = 100;

   private final String IDLE_BUTTON_STYLE = "-fx-background-color: darkgray;";
   private final String HOVERED_BUTTON_STYLE = "-fx-background-color: silver;";

   private SecBoards secBoards;
   private final Consumer<String> notifier;
   private VBox root;
   private final ListView<WatchlistSpec_v2> tabsListView = new ListView<WatchlistSpec_v2>() {{
      this.setId("xfe-watchlist-tab-listview");
      this.setEditable(true);
      this.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
   }};

   private List<WatchlistSpec_v2> originalWatchListSpec;
   private final ListenerTracker tracker = new ListenerTracker();

   protected WatchlistEditView(SecBoards secBoards, Consumer<String> notifier) {
      this.secBoards = secBoards;
      this.notifier = notifier;
      createRootElement();
   }

   public final void populateFrom(List<WatchlistSpec_v2> srcList) {
      originalWatchListSpec = new ArrayList<>(srcList);
      tabsListView.getItems().clear();
      tabsListView.getItems().setAll(new ArrayList<>(srcList));
   }

   public final void reset() {
      if (originalWatchListSpec != null) {
         tabsListView.getItems().clear();
         tabsListView.getItems().setAll(new ArrayList<>(originalWatchListSpec));
      }
   }

   @Override
   public Pane getRootElement() {
      return root;
   }

   private void createRootElement() {
      WatchlistEditView self = this;
      root = new WatchlistEditPane() {
         {
            ObservableList<SecBoard> allSecboards = self.secBoards.getSecBoardForEdtior();
            IncludedSecuritiesView includedSecuritiesView = new IncludedSecuritiesView(allSecboards, self.notifier, tabsListView, INSTRUMENTS_MAX_COUNT);
            ObservableList<SecBoard> includedSecBoards = includedSecuritiesView.getItems();

            GridPane grid = new GridPane() {
               {
                  this.getStyleClass().add("xfe-spacing-dialog");
               }
            };

            ObservableSet<SecBoard> selectedInstruments = FXCollections.observableSet(new HashSet<>());


            if (logger.isTraceEnabled()) {
               includedSecBoards.addListener((Observable paramObservable) -> logger.debug("includedSecBoards {}", includedSecBoards));
            }

            Button removeButton = new Button() {
               {
                  this.getStyleClass().addAll("xfe-arrow-button", "xfe-arrow-button-left");
                  setButtonStyles(this);
                  this.disableProperty().bind(includedSecuritiesView.hasCheckedProperty());
                  this.setOnAction(actionEvent -> includedSecuritiesView.removeChecked());
               }
            };

            ProductsComponent productsComponent = new ProductsComponent(allSecboards, self.secBoards.instrs, includedSecBoards, selectedInstruments, visibleProperty());

            Button addButton = new Button() {
               {
                  this.getStyleClass().addAll("xfe-arrow-button", "xfe-arrow-button-right");
                  setButtonStyles(this);
                  this.setOnAction(actionEvent -> {
                     if (!selectedInstruments.isEmpty()) {
                        List<SecBoard> checkedSecBoards = productsComponent.checkedSecBoards();

                        if (includedSecBoards.size() + checkedSecBoards.size() > INSTRUMENTS_MAX_COUNT) {
                           String message = String.format("Please make sure the number of instruments for the tab does not exceed (%d).", INSTRUMENTS_MAX_COUNT);
                           self.notifier.accept(message);
                           return;
                        }
                        MultipleSelectionModel<SecBoard> selectedItemsSelectionModel = includedSecuritiesView.getSelectionModel();

                        int selectedIndex = selectedItemsSelectionModel.getSelectedIndex();
                        if (selectedIndex >= 0)
                           includedSecBoards.addAll(selectedIndex + 1, checkedSecBoards);
                        else
                           includedSecBoards.addAll(checkedSecBoards);
                        selectedInstruments.clear();

                        selectedItemsSelectionModel.clearSelection();

                        selectedInstruments.forEach(selectedItemsSelectionModel::select);
                     }
                  });
               }
            };

            Button mvUpButton = new Button() {
               {
                  this.getStyleClass().addAll("xfe-arrow-button", "xfe-arrow-button-up");
                  setButtonStyles(this);
                  this.disableProperty().bind(Bindings.not(includedSecuritiesView.canMoveUpProperty()));
                  this.setOnAction(actionEvent -> includedSecuritiesView.moveCheckedUp());
               }
            };

            Button mvDnButton = new Button() {
               {
                  this.getStyleClass().addAll("xfe-arrow-button", "xfe-arrow-button-down");
                  setButtonStyles(this);
                  this.disableProperty().bind(Bindings.not(includedSecuritiesView.canMoveDownProperty()));
                  this.setOnAction(actionEvent -> includedSecuritiesView.moveCheckedDown());
               }
            };

            includedSecuritiesView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            includedSecuritiesView.setEditable(false);
            self.tracker.addListener(includedSecBoards, Fx.coalesced(paramObservable -> {
               if (includedSecBoards.size() > INSTRUMENTS_MAX_COUNT) {

                  // Displaying error
                  int rejectedNumber = includedSecBoards.size() - INSTRUMENTS_MAX_COUNT;
                  String message = String.format("Maximum number of instruments per tab (%d) exceeded. " + "%d instruments rejected", INSTRUMENTS_MAX_COUNT, rejectedNumber);
                  self.notifier.accept(message);

                  // Removing full product flag from those we remove
                  ArrayList<SecBoard> removedSecurities = new ArrayList<>(includedSecBoards);
                  removedSecurities.subList(0, INSTRUMENTS_MAX_COUNT).clear();
                  includedSecuritiesView.removeFullProduct(self.getCurrentTab(), removedSecurities);

                  // Those we retain
                  includedSecBoards.remove(INSTRUMENTS_MAX_COUNT, includedSecBoards.size());
               }

               includedSecuritiesView.getCheckedSecurities().retainAll(includedSecBoards);
            }));

            self.tracker.disposes(productsComponent);

            // List of tabs ----------------------------------------------------------

            self.tabsListView.getStyleClass().add("xfe-list-view");
            self.tabsListView.setCellFactory(WatchlistTabDetailsCell.factory);
            self.tabsListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            self.tabsListView.setOnDragOver(event -> {
               Integer target = (Integer) event.getDragboard().getContent(WatchlistTabDetailsCell.dataFormat);
               if (target != null) {

                  event.acceptTransferModes(TransferMode.MOVE);

                  Group listGrp = Nodes.getGroup(self.tabsListView);
                  if (listGrp != null) {
                     if (listGrp.getChildren().size() == 2) {
                        Node theImage = listGrp.getChildren().get(1);

                        if (theImage != null) {
                           theImage.setTranslateY(event.getY());
                        }
                     }
                  }
               }

               event.consume();
            });

            InvalidationListener includedInstrumentsListener = Fx.coalesced(paramObservable -> {
               WatchlistSpec_v2 sel = self.getCurrentTab();
               if (sel != null) {
                  self.setCurrentTab(sel.withSecBoards(includedSecBoards));
               }
            });

            self.tracker.addListener(self.tabsListView.getSelectionModel().selectedItemProperty(), (observableValue, oldVal, newVal) -> {
               selectedInstruments.clear();

               if (oldVal != null) {
                  includedSecBoards.removeListener(includedInstrumentsListener);
               }

               includedSecBoards.clear();

               if (newVal != null) {
                  newVal.populate(self.secBoards, secBoards -> {
                     includedSecBoards.setAll(secBoards);
                     return null;
                  });

                  includedSecBoards.addListener(includedInstrumentsListener);

               }
            });

            // ------------------------------------------------------------------------
            LabelBuilder<?> titleBuilder = LabelBuilder.create().styleClass("label", "xfe-title");
            Label tabLabel = titleBuilder.text("Tab").build();
            Label availableLabel = titleBuilder.text("Products").build();
            Label selectedLabel = titleBuilder.text("Selected").build();

            final GridPane moveButtons = new GridPane() {
               {
                  this.setAlignment(Pos.CENTER);
                  this.add(removeButton, 0, 1);
                  this.add(addButton, 2, 1);
                  this.add(mvUpButton, 1, 0);
                  this.add(mvDnButton, 1, 2);
               }
            };

            self.tracker.bind(addButton.disableProperty(), Bindings.equal(0, Fx.sizeOfSet(selectedInstruments)).or(Bindings.greaterThan(INSTRUMENTS_MAX_COUNT, Fx.sizeOfList(includedSecBoards)).not()));

            Button createTabButton = new Button("") {
               {
                  this.getStyleClass().add("xfe-icon-new");
                  HBox.setHgrow(this, Priority.NEVER);
                  setId("xfe-iswap-create-tab-btn");
                  XfeTooltipFactory.setTooltip(this);
                  this.setOnAction(paramT -> {
                     WatchlistSpec_v2 item = self.getCurrentTab();
                     WatchlistSpec_v2 newItem = new WatchlistSpec_v2("New Tab", "-", new String[0]);
                     self.tabsListView.getItems().add(self.tabsListView.getItems().indexOf(item) + 1, newItem);
                  });
               }
            };

            Button dupTabButton = new Button("") {
               {
                  this.getStyleClass().add("xfe-icon-clone");
                  setId("xfe-iswap-dup-tab-btn");
                  XfeTooltipFactory.setTooltip(this);
                  HBox.setHgrow(this, Priority.NEVER);
                  this.setOnAction(paramT -> {
                     WatchlistSpec_v2 item = self.getCurrentTab();
                     WatchlistSpec_v2 newItem = null;
                     if (item == null) {
                        newItem = new WatchlistSpec_v2("New Tab", "-", new String[0]);
                     } else {
                        newItem = WatchlistSpec_v2.copy(item);
                     }
                     self.tabsListView.getItems().add(self.tabsListView.getItems().indexOf(item) + 1, newItem);
                  });
               }
            };

            ToolBar tabsAddBox = new ToolBar() {
               {
                  getStyleClass().add("xfe-tabs-add-box");
                  this.getItems().addAll(createTabButton, dupTabButton);
                  AnchorPane.setLeftAnchor(this, 0.0);
                  AnchorPane.setBottomAnchor(this, 5.0);
               }
            };

            AnchorPane controlsBox = new AnchorPane() {
               {
                  this.getChildren().add(tabsAddBox);
               }
            };

            Region spacer = new Region();

            grid.add(tabLabel, 0, 0);
            grid.add(availableLabel, 2, 0);
            grid.add(selectedLabel, 4, 0);

            grid.add(self.tabsListView, 0, 1);
            grid.add(spacer, 1, 1);
            grid.add(productsComponent.getNode(), 2, 1);
            grid.add(moveButtons, 3, 1);
            grid.add(includedSecuritiesView, 4, 1);

            grid.add(controlsBox, 0, 2, 5, 1);

            GridPane.setVgrow(self.tabsListView, Priority.ALWAYS);
            GridPane.setVgrow(productsComponent.getNode(), Priority.ALWAYS);
            GridPane.setVgrow(includedSecuritiesView, Priority.ALWAYS);

            ColumnConstraints cc1 = new ColumnConstraints();
            cc1.setPercentWidth(25);
            ColumnConstraints cc2 = new ColumnConstraints();
            cc2.setMinWidth(10);
            ColumnConstraints cc3 = new ColumnConstraints();
            cc3.setPercentWidth(35);
            ColumnConstraints cc4 = new ColumnConstraints();
            cc4.setMinWidth(40);
            ColumnConstraints cc5 = new ColumnConstraints();
            cc5.setHgrow(Priority.ALWAYS);
            grid.getColumnConstraints().addAll(cc1, cc2, cc3, cc4, cc5);

            HBox buttonsBox = new HBox() {
               {
                  this.getStyleClass().addAll("hbox", "control-buttons-box");

                  AnchorPane.setRightAnchor(this, 0.0);
                  AnchorPane.setBottomAnchor(this, 5.0);
               }
            };

            controlsBox.getChildren().add(buttonsBox);

            this.getChildren().addAll(grid);
            setVgrow(grid, Priority.ALWAYS);
            //this.setVisible(false);
         }
      };

   }

   private void setButtonStyles(Button btn) {
      btn.setStyle(IDLE_BUTTON_STYLE);
      btn.setOnMouseEntered(e -> btn.setStyle(HOVERED_BUTTON_STYLE));
      btn.setOnMouseExited(e -> btn.setStyle(IDLE_BUTTON_STYLE));
      btn.disabledProperty().addListener((observable, oldValue, newValue) -> {
         if (!newValue) {
            btn.setStyle(IDLE_BUTTON_STYLE);
         }
      });
   }

   public void setActiveTab(WatchlistSpec_v2 wl) {
      WatchlistSpec_v2 activeList = wl != null ? WatchlistSpec_v2.findById(tabsListView.getItems(), wl.getId()) : null;
      tabsListView.getSelectionModel().clearSelection();

      tabsListView.getSelectionModel().select(activeList);
      // The line below causes the tabsListView to come up empty when the editor is opened for the first time
      //tabsListView.scrollTo(tabsListView.getItems().indexOf(activeList));
   }

   protected WatchlistSpec_v2 getCurrentTab() {
      return tabsListView.getSelectionModel().getSelectedItem();
   }

   private void setCurrentTab(WatchlistSpec_v2 spec) {
      tabsListView.getItems().set(tabsListView.getSelectionModel().getSelectedIndex(), spec);
   }

   @Override
   public void requestFocus() {
      XfeFocusModel.setViewFocus(getRootElement());
   }

   public void applyChanges(List<WatchlistSpec_v2> instrSpecs) {

   }

   public final List<WatchlistSpec_v2> getUnmodifiableSpecs() {
      return Collections.unmodifiableList(tabsListView.getItems());
   }

   public void dispose() {
      tracker.rollback();
      if (root != null) {
         root.getChildren().clear();
      }
      secBoards.dispose();
      secBoards = null;
      root = null;
   }

   @Override
   public void initialise() {

   }

   @Override
   public boolean isModified() {
      return originalWatchListSpec != null && !originalWatchListSpec.equals(tabsListView.getItems());
   }

   @Override
   public void save() {
      // Setting the list view items as the original items.
      originalWatchListSpec = new ArrayList<>(tabsListView.getItems());
      applyChanges(tabsListView.getItems());
   }

   List<WatchlistSpec_v2> getTabsListViewItems() {
      return tabsListView.getItems();
   }
}
