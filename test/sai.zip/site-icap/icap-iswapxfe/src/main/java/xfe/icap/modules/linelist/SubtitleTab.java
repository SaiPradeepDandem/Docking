package xfe.icap.modules.linelist;

import xfe.ui.list.XfeItem;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.layout.VBox;

/**
 * Created by jiadin on 10/01/2017.
 */
class SubtitleTab extends Tab {
   SubtitleTab(XfeItem par) {
      VBox titleBox = new VBox();
      titleBox.getStyleClass().add("xfe-split-title");
      Label titleText = new Label();
      titleText.getStyleClass().add("xfe-title-2");
      titleText.setText(par.getId());
      Label subTitleText = new Label();
      subTitleText.getStyleClass().add("xfe-title-3");
      subTitleText.setText(par.getParentfirmId()+(par.getSubTitle()==null || par.getSubTitle().length()==0 ? "" : "-"+par.getSubTitle()) );
      titleBox.getChildren().addAll(titleText, subTitleText);
      this.setGraphic(titleBox);
      this.setUserData(par);
      this.setClosable(false);
   }
}
