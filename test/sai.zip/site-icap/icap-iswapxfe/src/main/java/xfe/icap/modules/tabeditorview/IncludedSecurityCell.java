package xfe.icap.modules.tabeditorview;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableSet;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.StackPane;
import xfe.types.DomainDataFormat;
import xfe.types.SecBoard;
import xfe.util.scene.control.CheckListCell;
import xfe.util.scene.control.SelectablePane;
import xstr.util.Fun1;
import xstr.util.Fx;

import java.util.*;
import java.util.stream.Collectors;

class IncludedSecurityCell extends CheckListCell<SecBoard> {

   IncludedSecurityCell(
      IncludedSecuritiesView listView,
      ObservableSet<SecBoard> selectedSecurities,
      StringProperty selectedProduct,
      EventHandler<DragEvent> dragOver,
      EventHandler<DragEvent> dragDrop) {
      super(listView, selectedSecurities);
      getStyleClass().add("included-security-cell");
      fxext.ObjectBinding<String> instrumentIdBinding = Fx.map(itemProperty(), new Fun1<SecBoard, String>() {
         @Override
         public String call(SecBoard secBoard) {
            return secBoard != null ? secBoard.getInstrumentId() : null;
         }
      });

      fxext.ObjectBinding<String> secCodeBinding = Fx.map(itemProperty(), new Fun1<SecBoard, String>() {
         @Override
         public String call(SecBoard secBoard) {
            return secBoard != null ? secBoard.getSecCode() : null;
         }
      });

      SelectablePane pane = new SelectablePane() {{
         this.getStyleClass().add("same-product");
         this.getChildren().setAll(
            new Label() {{
               this.setMinWidth(2);
               this.getStyleClass().add("product-grip");
               this.tooltipProperty().bind(new ObjectBinding<Tooltip>() {
                  {
                     bind(instrumentIdBinding);
                  }

                  @Override
                  protected Tooltip computeValue() {
                     String text = instrumentIdBinding.get();

                     return text != null ? new Tooltip(text) : null;
                  }
               });
               this.setOnMouseClicked(actionEvent -> {
                  actionEvent.consume();

                  List<SecBoard> instrumentSecurities = listView.getItems().stream().filter(board -> board.getInstrumentId().equals(instrumentIdBinding.get())).collect(Collectors.toList());

                  List<SecBoard> addingSecurities = new ArrayList<>(instrumentSecurities);

                  addingSecurities.removeAll(selectedSecurities);

                  if (addingSecurities.size() != 0) {
                     selectedSecurities.addAll(addingSecurities);
                  } else {
                     selectedSecurities.removeAll(instrumentSecurities);
                  }

                  SecBoard item = getItem();
                  int selfIndex = listView.getItems().indexOf(item);

                  listView.getFocusModel().focus(selfIndex);
                  listView.getSelectionModel().clearAndSelect(selfIndex);
               });
               StackPane.setAlignment(this, Pos.CENTER_LEFT);
            }},
            new Label() {{
               this.textProperty().bind(Fx.nonNullStr(secCodeBinding));
               StackPane.setAlignment(this, Pos.CENTER_LEFT);
               this.getStyleClass().add("instrument-grip");
               Node box = IncludedSecurityCell.this.getGraphic();
               this.setGraphic(box);
            }});

         this.selectedProperty().bind(
            Bindings.and(
               Bindings.equal((String)null, instrumentIdBinding).not(),
               Bindings.equal(instrumentIdBinding, selectedProduct)));
      }};

      setGraphic(null);
      setGraphicTextGap(0);
      setGraphic(pane);

      this.setOnDragDetected(mouseEvent -> {
         if (!IncludedSecurityCell.this.getChecked()) {
            SecBoard node = IncludedSecurityCell.this.getItem();

            selectedSecurities.clear();
            selectedSecurities.add(node);
         }

         Dragboard dragBoard = IncludedSecurityCell.this.startDragAndDrop(TransferMode.COPY_OR_MOVE);
         ClipboardContent content = new ClipboardContent();

         StringBuilder builder = new StringBuilder();

         for (SecBoard secBoard: selectedSecurities) {
            builder.append(secBoard.getSecCode());
            builder.append("\n");
         }

         content.put(DomainDataFormat.SECBOARDS, builder.toString());

         dragBoard.setContent(content);
         mouseEvent.consume();
      });

      this.setOnDragOver(dragOver);

      this.setOnDragDropped(dragDrop);

      this.setOnDragDone(dragEvent -> {
         if (dragEvent.getTransferMode() == TransferMode.MOVE) {
            Dragboard dragboard = dragEvent.getDragboard();

            if (dragboard.hasContent(DomainDataFormat.SECBOARDS)) {
               Object content = dragboard.getContent(DomainDataFormat.SECBOARDS);

               if (content instanceof String) {
                  String text = (String)content;
                  Set<String> secBoardNames = new HashSet<>(Arrays.asList(IncludedSecuritiesView.trimAll(text.split("\n"))));

                  new ArrayList<>(getListView().getItems()).stream().filter(secBoard ->
                     secBoardNames.contains(secBoard.getSecCode())).forEach(secBoard ->
                     getListView().getItems().remove(secBoard));

                  selectedSecurities.clear();
               }

               dragEvent.consume();
            }
         }
      });
   }
}
