package xfe.icap.client;

import xmp.message.XMP.XmpQueryRequest;
import xmp.message.XMP.XmpSubscriptionRequest;
import xmp.message.XMP.XmpSubscriptionRequest.Builder;
import xstr.session.XtrQueryRequestContext;
import xstr.icap.csdk.ExceptionWrapper;
import xstr.session.XtrCombinedIterator;
import xstr.session.XtrQueryReply;
import xstr.session.XtrReplyRow;
import xstr.util.collection.MultiHashMap;
import com.objsys.asn1j.runtime.Asn1ValueParseException;
import com.omxgroup.xstream.amp.AmpQueryReqChoice;
import com.omxgroup.xstream.api.BadParam;
import com.omxgroup.xstream.api.QueryRequest;
import com.omxgroup.xstream.api.cometheader.UserId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xmp.message.XMP.XmpQueryReply;
import xmp.message.XMP.XmpReplyRow;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.exception.Exceptions;
import xstr.util.exception.XtrMessageException;
import xstr.icap.csdk.ICAP;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;

public class XstrWebSubscription extends DisposableBase implements XtrCombinedIterator {
   private static final Logger logger = LoggerFactory.getLogger(XstrWebSubscription.class);
   private final XstrWebConnection connection;

   private final IcapWebSession webSession;
   private final ConcurrentHashMap<Long, XtrQueryRequestContext> queryMap = new ConcurrentHashMap<>();
   protected static final AtomicLong nextSubscriptionId = new AtomicLong();
   protected final ConcurrentLinkedQueue<XmpQueryRequest> addedRequests = new ConcurrentLinkedQueue<>();
   protected final ConcurrentLinkedQueue<Long> removedRequests = new ConcurrentLinkedQueue<>();
   private final long id = nextSubscriptionId.incrementAndGet();


   public XstrWebSubscription(IcapWebSession /*@NonNull*/icapWebSession, XstrWebConnection connection, List<XtrQueryRequestContext> reqs)
         throws XtrMessageException {
      this.webSession = icapWebSession;
      this.connection = connection;
      for (XtrQueryRequestContext req : reqs) {
         addQuery(req);
      }
   }

   @Override
   public Future<MultiHashMap<Long, XtrQueryReply>> next() {
      logger.trace("Web Subscription next");
      Date timestamp = new Date();
      webSession.resetLastSendTime();
      XmpSubscriptionRequest req;
      try {
         req = buildRequest();
      } catch (Exception e) {
         logger.error("Unable to build request: ", Exceptions.format(e));
         logger.debug("Unable to build request: ", e);
         return Futures.error(e);
      }
      return connection.subscriptionHandler.request(req).map(reply -> {
         webSession.resetLastReceiveTime();
         List<XmpQueryReply> replies = reply.getReplyGroupList();
         logger.trace("Received subscription reply with {} rows", replies.stream().mapToInt(XmpQueryReply::getRowCount).sum());
         MultiHashMap<Long, XtrQueryReply> result = new MultiHashMap<>();
         for (XmpQueryReply r : replies) {
            XtrQueryRequestContext context = queryMap.get(r.getId());
            // Ignore replies for which we do not have a context
            if (context != null) {
               for (XmpReplyRow b : r.getRowList()) {
                  XtrReplyRow row = new XtrReplyRow(b, r.getId(), timestamp);
                  webSession.getStats().addRep(row.getData());
                  result.add(r.getId(), row);
                  context.setCookie(r.getCookie().toByteArray());
               }
            }
         }
         logger.trace("next yielded subscription reply with map of size {}", result.size());
         return result;
      });
   }

   public void addQuery(XtrQueryRequestContext context) throws XtrMessageException {
      queryMap.put(context.getGroupId(), context);

      QueryRequest rawRequest = new QueryRequest((AmpQueryReqChoice) context.getRequest().getData());

      byte[] cookie = context.getCookie();
      try {
         String subjectUser = context.getRequest().getSubjectUser();

         if (subjectUser != null && !subjectUser.isEmpty()) {
            rawRequest.subject_user(new UserId(context.getRequest().getSubjectUser()));
         }

         rawRequest.group_id(context.getGroupId());
         XmpQueryRequest xmpRequest = ICAP.tsmrToXmp(rawRequest, cookie);
         logger.trace("Adding subscription request: {} with cookie {}. Id: {}", rawRequest.message().getElemName(), Arrays.toString(cookie), xmpRequest.getId());
         addedRequests.add(ICAP.tsmrToXmp(rawRequest, cookie));

         logger.debug("[gid:{}]:{} Query Added", context.getGroupId(), context.getRequest().getData().getElemName());
      } catch (BadParam e) {
         logger.error("{} Error adding newIterator to combined iterator: {}", context, e.getMessage());
         throw ExceptionWrapper.wrap(null, e);
      } catch (Asn1ValueParseException e) {
         logger.error("{} Error adding query to combined iterator: {}", context, Exceptions.format(e));
         throw ExceptionWrapper.wrap(null, e);
      }
   }

   @Override
   public void removeQuery(XtrQueryRequestContext context) {
      long gid = context.getGroupId();
      queryMap.remove(gid);
      for (XmpQueryRequest req: addedRequests) {
         if (req.getId() == id) {
            addedRequests.remove(req);
            logger.trace("request removed id: {}", id);
            return;
         }
      }
      removedRequests.add(id);
      logger.debug("[gid:{}]:{} Query Removed", context.getGroupId(), context.getRequest().getData().getElemName());
   }


   protected XmpSubscriptionRequest buildRequest() {
      Builder reqBuilder = XmpSubscriptionRequest.newBuilder();

      while (!addedRequests.isEmpty()) {
         XmpQueryRequest request = addedRequests.poll();
         logger.debug("Add subscription request: {}", request);
         reqBuilder.addQueriesAdded(request);
      }

      while (!removedRequests.isEmpty()) {
         long groupId = removedRequests.poll();
         reqBuilder.addQueriesRemoved(groupId);
         logger.debug("Remove subscription request: groupId: {}", groupId);
      }
      reqBuilder.setSeqNo(-1);
      return reqBuilder.build();
   }

}
