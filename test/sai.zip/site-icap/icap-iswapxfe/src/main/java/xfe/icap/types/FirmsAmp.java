package xfe.icap.types;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.*;
import xstr.util.Fun1;
import xstr.util.Lazy;

import xstr.session.QueryFeed;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.util.AmpListAggregator;
import xstr.util.Fx;
import xfe.icap.amp.AmpFirm;

public class FirmsAmp {
   private final AmpListAggregator aggregator = new AmpListAggregator(AmpFirm.rep);

   public final Lazy<ObservableList<QueryReplyRow>> all = new Lazy<ObservableList<QueryReplyRow>>() {
      @Override
      protected ObservableList<QueryReplyRow> initialize() {
         return Fx.unmodifiable(aggregator.items);
      }
   };

   public final Lazy<ObservableMap<String, QueryReplyRow>> byId = new Lazy<ObservableMap<String, QueryReplyRow>>() {
      @Override
      protected ObservableMap<String, QueryReplyRow> initialize() {
         return Fx.keyBy(all.get(), new Fun1<QueryReplyRow, String>() {
            @Override
            public String call(QueryReplyRow row) {
               return row.getString(AmpFirm.firmId);
            }
         });
      }
   };

   public FirmsAmp(ServerSession session) {
      QueryFeed feed = session.getFeedSource(AmpFirm.req);
      feed.addListener(aggregator);
      BooleanProperty readyProperty = new SimpleBooleanProperty(false);
      readyProperty.bind(aggregator.busyProperty().not());
   }
}
