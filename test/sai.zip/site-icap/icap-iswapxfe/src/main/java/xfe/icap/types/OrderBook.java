package xfe.icap.types;

import java.util.List;
import java.util.Objects;

import xstr.types.OrderSide;
import xstr.types.OrderbookSortKey;
import xfe.icap.modules.selectioncontext.SelectionContext;
import javafx.beans.*;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import xstr.session.QueryFeed;
import xstr.session.XtrQueryRequestBuilder;
import xstr.session.ServerSession;
import xstr.session.XtrQueryRequest;
import xstr.util.FeedAggregator;
import xstr.util.collection.ObservableCollections;
import xstr.util.collection.SortValueFactory;
import xstr.util.filter.*;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpOrderBookByOrder;
import xfe.icap.modules.obbo.ObboModule;
import xstr.session.ObservableReplyRow;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import xstr.session.ObservableReplyRow.ObservableRowFactory;


public class OrderBook {
   private static final Logger logger = LoggerFactory.getLogger(OrderBook.class);
   private final ServerSession session;
   private QueryFeed feedSrc;
   private final FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpOrderBookByOrder.rep, new ObservableRowFactory());
   private final ObjectProperty<SelectionContext> reselectProperty = new SimpleObjectProperty<>();

   private final ObjectProperty<OrderBookKey> key = new SimpleObjectProperty<>();
   public final OrderBookSide bidSide;
   public final OrderBookSide offerSide;

   private final InvalidationListener invalidationListener;

   public FeedAggregator<ObservableReplyRow> getAggregator() {
	   return aggregator;
   }

   public void setReselectProperty(SelectionContext reselectProperty) {
      this.reselectProperty.setValue(reselectProperty);
   }

   public ObjectProperty<SelectionContext> getReselectProperty() {
      return reselectProperty;
   }

   public static class OrderBookKey {

      public String getBoardId() {
         return boardId;
      }

      public String getSecCode() {
         return secCode;
      }

      public OrderBookKey(String secCode, String boardId, String onBehalfOf, SelectionContext reselect) {
         if (secCode == null || boardId == null) {
            logger.error("SecCode and boardId cannot be null!");
            throw new NullPointerException("SecCode and boardId cannot be null!");
         }

         this.secCode = secCode;
         this.boardId = boardId;
         this.onBehalfOf = onBehalfOf;
         this.reselect = reselect;
      }

      final String secCode;
      final String boardId;
      final String onBehalfOf;
      final SelectionContext reselect;
      boolean needBestPrice = true;
      private final DoubleProperty bestBid = new SimpleDoubleProperty();
      private final DoubleProperty bestOffer = new SimpleDoubleProperty();

      @Override
      public int hashCode() {
         return Objects.hash(secCode, boardId,onBehalfOf);
      }

      @Override
      public boolean equals(Object o) {
         if (o instanceof OrderBookKey) {
            OrderBookKey that = (OrderBookKey)o;
            return Objects.equals(this.secCode, that.secCode) && Objects.equals(this.boardId, that.boardId) && Objects.equals(this.onBehalfOf,that.onBehalfOf);
         }

         return false;
      }

      public void setNeedBestPrice(boolean needBestPrice){
         this.needBestPrice = needBestPrice;
      }
      @Override
      public String toString() {
         return "OrderBookKey{" +
            "boardId='" + boardId + '\'' +
            ", secCode='" + secCode + '\'' +
            '}';
      }
   }



   private final ChangeListener<OrderBookKey> keyChangeLis =
      (observableKey, oldKey, newKey) -> {
         logger.trace("order book key changed from {} to {}", oldKey, newKey);
         updateList(newKey);
      };

   private final InvalidationListener bestBidLis  = new InvalidationListener() {

      @Override
      public void invalidated(Observable arg0) {
         List<ObservableReplyRow> bids = bidSide.orders;
         if(bids.size()>0){
            Double bestOfferPrice = bids.get(0).getValue(AmpOrderBookByOrder.price);
            if (key.get() != null){
               key.get().bestBid.set(bestOfferPrice);
            }
         }
      }
   };


   private final InvalidationListener bestOfferLis  = new InvalidationListener() {

      @Override
      public void invalidated(Observable arg0) {
         List<ObservableReplyRow> offers = offerSide.orders;
         if(offers.size()>0){
            Double bestOfferPrice = offers.get(0).getValue(AmpOrderBookByOrder.price);
            if (key.get() != null){
               key.get().bestOffer.set(bestOfferPrice);
            }
         }
      }
   };

   public OrderBook(XfeSession session, ObboModule module) {
      DynamicFilter<ObservableReplyRow> autoAcceptFilter = session.getObboFilters().createAutoAcceptFilter(module.applyAutoAcceptFilter);
      SortValueFactory<ObservableReplyRow, OrderbookSortKey> orderBookSortKeyAccessor = row -> row.getProperty(AmpOrderBookByOrder.sortKey);
      this.bidSide = new OrderBookSide(
         OrderSide.BUY, this,
         ObservableCollections.sort(
            ObservableCollections.filter(aggregator.items, autoAcceptFilter, module.getTracker()), orderBookSortKeyAccessor, RowFilters.equalsAsnStatic(AmpOrderBookByOrder.buySell, new AmpOrderVerb(AmpOrderVerb.buy)), module.getTracker()));
      this.offerSide = new OrderBookSide(
         OrderSide.SELL, this,
         ObservableCollections.sort(
            ObservableCollections.filter(aggregator.items, autoAcceptFilter, module.getTracker()), orderBookSortKeyAccessor, RowFilters.equalsAsnStatic(AmpOrderBookByOrder.buySell, new AmpOrderVerb(AmpOrderVerb.sell)), module.getTracker()));
      this.session = session.getUnderlyingSession();

      invalidationListener = observable -> {
         OrderBookKey orderbookKey = key.get();
         logger.trace("busy property for key {} is {}", orderbookKey, aggregator.busyProperty().get());
         if (orderbookKey != null) {
            if (orderbookKey.needBestPrice && !aggregator.busyProperty().get()) {
               List<ObservableReplyRow> bids = bidSide.orders;
               if (bids.size() > 0) {
                  Double bestBidPrice = bids.get(0).getValue(AmpOrderBookByOrder.price);
                  orderbookKey.bestBid.set(bestBidPrice);
               }
               bidSide.orders.addListener(bestBidLis);
               List<ObservableReplyRow> offers = offerSide.orders;
               if (offers.size() > 0) {
                  Double bestOfferPrice = offers.get(0).getValue(AmpOrderBookByOrder.price);
                  orderbookKey.bestOffer.set(bestOfferPrice);
               }
               offerSide.orders.addListener(bestOfferLis);
            }

            if (!aggregator.busyProperty().get()) {
               logger.trace("Setting reselect property to {}", orderbookKey.reselect);
               setReselectProperty(orderbookKey.reselect);
            }
         }
      };

      onLoading();
//      aggregator.items.addListener(new ListChangeListener<ObservableReplyRow>() {
//         @Override
//         public void onChanged(Change<? extends ObservableReplyRow> c) {
//            while (c.next()) {
//               if (c.wasAdded()) {
//                  for (ObservableReplyRow row: c.getAddedSubList()) {
//                     logger.trace("orderbook row {} added", row);
//                  }
//               }
//            }
//         }
//      });
      key.addListener(keyChangeLis);
   }

   private void onLoading() {
      aggregator.busyProperty().removeListener(invalidationListener);
      aggregator.busyProperty().addListener(invalidationListener);
   }

   private void updateList(OrderBookKey orderbookKey) {
      logger.trace("updateList called for {}", orderbookKey);
      if (feedSrc != null) {
         bidSide.orders.removeListener(bestBidLis);
         offerSide.orders.removeListener(bestOfferLis);
         aggregator.deregisterToFeedScc();
      }

      try {
         if (orderbookKey != null) {
            logger.info("Doing orderbook query on behalf of {}", orderbookKey.onBehalfOf);
            XtrQueryRequestBuilder reqBuilder = XtrQueryRequestBuilder.create(AmpOrderBookByOrder.req, session)
                  .set(AmpOrderBookByOrder.reqSecCode, orderbookKey.secCode)
                  .set(AmpOrderBookByOrder.reqBoardId, orderbookKey.boardId).subjectUser(orderbookKey.onBehalfOf);

            XtrQueryRequest req = reqBuilder.build();

            feedSrc = session.queries.getFeedSource(req);
            aggregator.registerToFeedScc(feedSrc);
            logger.trace("onLoading() called");
            onLoading();
         }
      } catch (AsnTypeException | AmpPermissionException ex) {
         logger.error(ex.getMessage(), ex);
      }

      if (orderbookKey == null) {
         aggregator.reset();
      }
   }

   public void setKey(OrderBookKey orderbookKey) {
      key.set(orderbookKey);
   }

   public OrderBookKey getKey() {
      return key.get();
   }

   public void dispose(){
      key.removeListener(keyChangeLis);
      aggregator.deregisterToFeedScc();
   }
}
