package xfe.icap.client;

import io.netty.handler.codec.http.HttpHeaders.Names;
import xmp.message.XMP.XmpReply;
import xstr.amp.Xtr;
import xstr.session.Credentials;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.*;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.MessageToMessageCodec;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.protobuf.ProtobufDecoder;
import io.netty.handler.codec.protobuf.ProtobufEncoder;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.concurrent.GenericFutureListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xmp.message.XmpClientCodec;
import xstr.util.PromiseMonitor;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;
import xstr.util.exception.Exceptions;
import xstr.util.exception.XtrLogonException;
import xstr.util.exception.XtrSessionException;
import xstr.netty.XfeUserAgent;
import xstr.util.ssl.XstrHttpSessionConstants;

import java.util.List;
import java.util.concurrent.TimeUnit;

class XstrHttpConnection extends XstrWebConnection {
   private static final Logger logger = LoggerFactory.getLogger(XstrHttpConnection.class);
   private final Future<Void> connectionCloseFuture = disposed();


   public class XstrHttpCodec extends MessageToMessageCodec<FullHttpResponse, ByteBuf> {

      @Override
      protected void encode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
         logger.trace("Encoding {} bytes", in.readableBytes());
         HttpRequest writeRequest = createHttpReq(HttpMethod.POST, "/api/http", in.retain());
         HttpHeaders headers = writeRequest.headers();
         headers.add(Names.USER_AGENT, new XfeUserAgent(Xtr.getVersion()).toString());
         String sessionID = sessionWrapper.getTESessionId();
         if(sessionID != null)
            headers.add(XstrHttpSessionConstants.HTTP_KEY_SESSION_ID, sessionID);
         headers.add("Content-Length", in.readableBytes());
         out.add(writeRequest);
      }

      @Override
      protected void decode(ChannelHandlerContext ctx, FullHttpResponse msg, List<Object> out) throws Exception {
         logger.trace("Http channel: decode {}", msg, msg.getClass());
         if (!msg.getStatus().equals(HttpResponseStatus.OK)) {
            logger.error("Http response error: {}", msg.getStatus());
            throw new XtrLogonException("Not logged on");
         }
         ByteBuf contentBytes = msg.content();

         if(contentBytes.readableBytes() == 0) {
            logger.warn("Empty reply received");
         }
         logger.trace("Decoding {} bytes", msg.content().readableBytes());
         out.add(contentBytes.retain());
      }

      @Override
      public void channelActive(ChannelHandlerContext ctx) {
         // If the channel becomes active with an invalid sessionID we require a logon
         if (sessionWrapper.getTESessionId() == null)
            ctx.fireUserEventTriggered(LOGON_REQUIRED);
      }

      @Override
      public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
         super.userEventTriggered(ctx, evt);
      }
   }

   static Future<? extends XstrWebConnection> connect(Credentials cred,
                                                      HttpSessionWrapper session) {
      XstrHttpConnection connection = new XstrHttpConnection(session);
      return connection.channel(cred).map(x -> connection).onError(err ->
         connection.dispose().thenRaise(err)
      );
   }

   XstrHttpConnection(HttpSessionWrapper sessionWrapper) {
      super(sessionWrapper);
      logger.debug("Http connection created.");
   }

   @Override
   public Future<Channel> channel(Credentials cred) {
      logger.trace("[{}] Creating channel", this);
      Promise<Channel> channelPromise = PromiseMonitor.monitor(Futures.newPromise("http-channel"));
      createChannel(cred, channelPromise);
      return channelPromise;
   }

   private void createChannel(Credentials cred, Promise<Channel> channelPromise) {
      logger.trace("Creating channel.");

      Bootstrap bootstrap = new Bootstrap();
      ChannelInitializer<SocketChannel> handler = new ChannelInitializer<SocketChannel>() {
         @Override
         protected void initChannel(SocketChannel channel) {
            logger.trace("Initializing channel ...");
            ReadTimeoutHandler readTimeoutHandler = new ReadTimeoutHandler((int) sessionWrapper.getConnectTimeout().in(TimeUnit.SECONDS));
            ChannelPipeline pipeline = channel.pipeline();
            pipeline.addFirst(readTimeoutHandler);
            installProxyHandler(pipeline);
            installSslHandler(pipeline);
            pipeline.addLast("logging", new LoggingHandler("xstr.net.message.http", LogLevel.TRACE));
            pipeline.addLast("http-codec", new HttpClientCodec());
            pipeline.addLast("http-aggregator", new HttpObjectAggregator(512*1024){
               @Override
               protected void decode(ChannelHandlerContext ctx, HttpObject msg, List<Object> out) throws Exception {
                  if (!live()) return;
                  if (msg instanceof HttpResponse) {
                     HttpResponse res = (HttpResponse) msg;
                     if (HttpResponseStatus.BAD_REQUEST.equals(res.getStatus())) {
                        channelPromise.trySetFailure(new XtrSessionException(res.getStatus().toString()));
                        dispose();
                        ctx.close();
                        return;
                     }
                  }
                  super.decode(ctx, msg, out);
               }
            });
            pipeline.addLast("xstr-http-codec", new XstrHttpCodec());
            pipeline.addLast("protobufDecoder", new ProtobufDecoder(XmpReply.getDefaultInstance()));
            pipeline.addLast("protobufEncoder", new ProtobufEncoder());
            pipeline.addLast("xstr-message-codec", new XmpClientCodec());
            pipeline.addLast("txn-handler", transactionHandler);
            pipeline.addLast("qry-handler", queryHandler);
            pipeline.addLast("sub-handler", subscriptionHandler);
            pipeline.addLast("xstr-logon-handler", logonHandler(cred, channelPromise));
            pipeline.addLast("xstr-logoff-handler", logoffHandler);
            pipeline.addLast("session-reply-handler", sessionWrapper.sessionMessageHandler);
         }
      };

      int timeout = (int)sessionWrapper.getConnectTimeout().in(TimeUnit.MILLISECONDS);
      bootstrap
         .group(eventLoopGroup)
         .channel(NioSocketChannel.class)
         .option(ChannelOption.TCP_NODELAY,true)
         .option(ChannelOption.CONNECT_TIMEOUT_MILLIS,timeout)
         .handler(handler);

      clientBootstrap.connect(bootstrap).addListener(new GenericFutureListener<ChannelFuture>() {
         @Override
         public void operationComplete(ChannelFuture connectFuture) {
            try {
               connectFuture.get();
               Channel channel = connectFuture.channel();
               logger.trace("Channel connected {}", channel);
               channel.closeFuture().addListener(future -> {
                  try {
                     future.get();
                     if (!channelPromise.isDone()) {
                        String msg = "Connection closed unexpectedly.";
                        logger.warn(msg);
                        channelPromise.trySetFailure(new XtrSessionException(msg));
                     }
                  } catch (Exception e) {
                     logger.warn("Connection closed unexpectedly due to error: {}", Exceptions.format(e));
                     logger.debug("Connection closed unexpectedly due to error:", e);
                     channelPromise.trySetFailure(e);
                  }
               });
               if (cred == null) {
                  // No credentials provided - this is a session query (already logged on) so we return the future here.
                  channelPromise.setSuccess(channel);
                  logger.trace("Http Connect completed OK");
               } else {
                  // This is a logon query - the future will be set by the logonHandler.
                  logger.info("Connection established. Waiting for logon.");
               }
            } catch (Exception t) {
               logger.warn("Http Failed to connect.", t);
               channelPromise.setFailure(t);
            }
         }
      });
   }

   @Override
   public Future<Void> closeFuture() {
      return connectionCloseFuture;
   }

}
