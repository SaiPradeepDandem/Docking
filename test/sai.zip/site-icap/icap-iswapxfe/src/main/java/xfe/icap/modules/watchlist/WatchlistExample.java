package xfe.icap.modules.watchlist;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xfe.icap.types.IcapSecBoardTrim2Watchlist;
import xfe.types.SecBoard;
import xfe.types.Watchlist;
import xstr.util.Fun1;

import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;

import xstr.session.QueryReplyRow;
import xstr.amp.AMP;
import xstr.util.Fx;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.icap.SimpleLogonApplicationModule;
import xfe.icap.XfeSession;
import xfe.util.Constants;
import xfe.ui.table.AsnRefTableColumn;

public class WatchlistExample  extends SimpleLogonApplicationModule {
   private static final Logger logger = LoggerFactory.getLogger(WatchlistExample.class);
   @Override
   protected void initApp() {
      onLogoff();
   }

//	public static void main(String[] args) {
//		launch(args);
//   }

	@Override
	protected void onLogon(XfeSession session) {
		Watchlist wl = new IcapSecBoardTrim2Watchlist(session);

		Runnable watchlistPopulator = new Runnable() {
			@Override
			public void run() {
				System.out.println("--------------- ADDING WATCHLIST ENTRIES -------------------------");
				ArrayList<SecBoard> secCodes = new ArrayList<SecBoard>();
				try {
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 30Y").get());
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 2Y").get());
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 3Y").get());
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 5Y").get());
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 9Y").get());
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 10Y").get());
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 15Y").get());
				secCodes.add(session.secBoards.get().getFirstBySecCode("A-EUR 20Y").get());
				} catch (Exception e) {
				   logger.error("Error populating watchlist:", e);
				}
				wl.getSpecWatchedSecboards().setAll(secCodes);
			}
		};

		if (session.secBoards.get().isReady())
			watchlistPopulator.run();
		else
			session.secBoards.get().ready().onSuccess(new Fun1<Boolean, Void>(){

            @Override
            public Void call(Boolean a) {
               Fx.runLater(watchlistPopulator);
               return null;
            }

			});

		TableView<QueryReplyRow> asnTableView = new TableViewHeaderUnmovable<QueryReplyRow>() {{
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("Inst");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.secBoardId.secCode"));
				this.setPrefWidth(150);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("Type");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.bidSpecialOrderType"));
				this.setPrefWidth(40);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("Total");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.bidDepth"));
				this.setPrefWidth(40);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("B^n");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.nLevelImpBidPrice"));
				this.setPrefWidth(40);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName(Constants.COLUMN_NAME_BID);
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.bidPrice"));
				this.setPrefWidth(70);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName(Constants.COLUMN_NAME_OFFER);
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.offerPrice"));
				this.setPrefWidth(70);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("O^n");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.nLevelImpOfferPrice"));
				this.setPrefWidth(40);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("Total");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.offerDepth"));
				this.setPrefWidth(40);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("Type");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.offerSpecialOrderType"));
				this.setPrefWidth(40);
			}});
			this.getColumns().add(new AsnRefTableColumn() {{
				this.setDisplayName("Last Price");
				this.setQueryRep(AMP.qREP("icapSecBoardTrim2Rep.lastPrice"));
				this.setPrefWidth(80);
			}});
		}};


		asnTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		asnTableView.getItems().addAll(wl.getItems());

		setApplicationRootNode(asnTableView);
	}

	@Override
	protected void onLogoff() {
		setApplicationRootNode(new Label("Table Example - Logged off"));
	}

	public List<Image> getIcons() {
		// TODO Auto-generated method stub
		return null;
	}
}
