package xfe.icap.modules.toolbar.actions;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import xfe.icap.modules.historyui.HistoryViewUIModule;
import xfe.icap.modules.layout.midi.LockedLabel;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.toolbar.TraderToolbarModule;
import xfe.module.Module;
import xfe.modules.actionsui.ActionButton;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.control.IconButton;
import xfe.ui.flasher.PseudoFlasher;
import xfe.util.XfeAction;
import xstr.util.concurrent.Future;

import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * UIModule for the actions tool bar.
 */
@Module.Autostart
public class ActionToolBarUIModule extends SessionScopeModule {
   private static final int BUTTON_WIDTH = 28;
   private static final int BUTTON_HEIGHT = 24;

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public TraderToolbarModule traderToolbarModule;

   @ModuleDependency
   public HistoryViewUIModule historyViewUIModule;


   @Override
   public Future<Void> startModule() {
      this.viewButtonsPane = new HBox();
      this.viewButtonsPane.setAlignment(Pos.CENTER_LEFT);
      this.viewButtonsPane.getStyleClass().add("actions-tool-bar-pane");

      this.lockOrSafeMsgPane = buildStatusPane();
      this.marketStatusMsgPane = buildStatusPane();
      this.subjectStatusLabel = new Label("Subject");
      this.subjectStatusLabel.getStyleClass().add("lockedLbl");

      HBox center = new HBox();
      center.setSpacing(5);
      center.getChildren().addAll(this.lockOrSafeMsgPane, this.marketStatusMsgPane);
      center.setAlignment(Pos.CENTER);

      this.tradeButtonsPane = new HBox();
      this.tradeButtonsPane.setAlignment(Pos.CENTER_RIGHT);
      this.tradeButtonsPane.getStyleClass().add("actions-tool-bar-pane");

      this.root = new BorderPane();
      this.root.getStyleClass().add("actions-tool-bar");
      this.root.setId(MidiLayoutViews.ACTION_TOOLBAR);
      this.root.setLeft(viewButtonsPane);
      this.root.setCenter(center);
      this.root.setRight(tradeButtonsPane);
      midiLayoutModule.addView(root);

      midiLayoutModule.setLockedLabelConsumer(lockedLabelConsumer);
      midiLayoutModule.setMarketSubjectConsumer(marketSubjectConsumer);
      traderToolbarModule.setSafeModeLabelConsumer(safeModeLabelConsumer);
      return Future.SUCCESS;
   }

   private StackPane buildStatusPane() {
      final StackPane statusPane = new StackPane();
      statusPane.setAlignment(Pos.CENTER);
      statusPane.setMaxWidth(200);
      statusPane.setPrefWidth(200);
      statusPane.setMinWidth(100);
      statusPane.setVisible(false);
      statusPane.setManaged(false);
      return statusPane;
   }

   @Override
   public Future<Void> stopModule() {
      midiLayoutModule.setLockedLabelConsumer(null);
      midiLayoutModule.setMarketSubjectConsumer(null);
      traderToolbarModule.setSafeModeLabelConsumer(null);
      midiLayoutModule.removeView(root);
      return Future.SUCCESS;
   }

   public void addViewAction(XfeAction action) {
      Button button = createActionButton();
      button.getProperties().put("actionId", action.getActionId());
      action.bindTo(button);
      if (action.getActionId().equals("orders")) {
         viewButtonsPane.getChildren().add(0, button);
      } else {
         viewButtonsPane.getChildren().add(button);
      }
   }

   public void toggleTradeButtonFlash(boolean doFlash) {
      viewButtonsPane.getChildren().stream()
         .filter(node -> "trades".equals(node.getProperties().get("actionId")))
         .findFirst().ifPresent(node -> {
         if (doFlash) {
            PseudoFlasher.addNodeToFlash(node);
         } else {
            PseudoFlasher.removeNodeFromFlash(node);
         }
      });
   }

   public void addTradeActions(XfeAction... actions) {
      Stream.of(actions).forEach(action -> {
         Button button = createActionButton();
         action.bindTo(button);
         tradeButtonsPane.getChildren().add(button);
      });
   }

   private Button createActionButton() {
      Button btn = new IconButton();
      btn.setPrefWidth(BUTTON_WIDTH);
      btn.setPrefHeight(BUTTON_HEIGHT);
      btn.setMaxWidth(BUTTON_WIDTH);
      btn.setMaxHeight(BUTTON_HEIGHT);
      btn.setMinWidth(BUTTON_WIDTH);
      btn.setMinHeight(BUTTON_HEIGHT);
      List<String> styles = btn.getStyleClass();
      if (!styles.contains(ActionButton.NORMAL_STYLE)) {
         styles.add(ActionButton.NORMAL_STYLE);
      }
      return btn;
   }

   private Button getHistoryButton() {
      if (this.historyButton == null) {
         this.historyButton = new IconButton("xfe-icon-history");
         this.historyButton.setOnAction(e -> {
            midiLayoutModule.addView(historyViewUIModule.getRoot());
         });
      }
      return this.historyButton;
   }

   private BorderPane root;
   private HBox viewButtonsPane;
   private HBox tradeButtonsPane;
   private StackPane lockOrSafeMsgPane;
   private StackPane marketStatusMsgPane;
   private Label subjectStatusLabel;
   private Button historyButton;

   private Consumer<LockedLabel> lockedLabelConsumer = lockedLabel -> {
      if (lockedLabel == null) {
         lockOrSafeMsgPane.getStyleClass().clear();
         lockOrSafeMsgPane.getChildren().clear();
         lockOrSafeMsgPane.setVisible(false);
         lockOrSafeMsgPane.setManaged(false);
      } else {
         lockOrSafeMsgPane.getStyleClass().add("locked-pane");
         lockOrSafeMsgPane.setVisible(true);
         lockOrSafeMsgPane.setManaged(true);
         if(!lockOrSafeMsgPane.getChildren().contains(lockedLabel))
            lockOrSafeMsgPane.getChildren().add(lockedLabel);
      }
   };

   private Consumer<Boolean> marketSubjectConsumer = isMarketSubject -> {
      if (isMarketSubject) {
         marketStatusMsgPane.setVisible(true);
         marketStatusMsgPane.setManaged(true);
         marketStatusMsgPane.getStyleClass().add("locked-pane");
         if(!marketStatusMsgPane.getChildren().contains(subjectStatusLabel))
             marketStatusMsgPane.getChildren().add(subjectStatusLabel);
      } else {
         marketStatusMsgPane.setVisible(false);
         marketStatusMsgPane.setManaged(false);
         marketStatusMsgPane.getStyleClass().clear();
         marketStatusMsgPane.getChildren().clear();
      }
   };

   private Consumer<Label> safeModeLabelConsumer = safeModeLabel -> {
      if (safeModeLabel == null) {
         lockOrSafeMsgPane.getStyleClass().clear();
         lockOrSafeMsgPane.getChildren().clear();
         lockOrSafeMsgPane.setVisible(false);
         lockOrSafeMsgPane.setManaged(false);
      } else {
         lockOrSafeMsgPane.getStyleClass().add("safe-mode-pane");
         lockOrSafeMsgPane.setVisible(true);
         lockOrSafeMsgPane.setManaged(true);
         lockOrSafeMsgPane.getChildren().add(safeModeLabel);
      }
   };
}
