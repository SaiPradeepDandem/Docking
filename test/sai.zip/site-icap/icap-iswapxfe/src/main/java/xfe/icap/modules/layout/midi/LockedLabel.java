package xfe.icap.modules.layout.midi;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import org.controlsfx.glyphfont.Glyph;
import xfe.ui.popover.PopOverOwner;

import java.util.function.Consumer;

public class LockedLabel extends Label implements PopOverOwner {
   public LockedLabel(String text) {
      super(text);
      getStyleClass().add("lockedLbl");
      final Glyph lock = new Glyph("FontAwesome", "LOCK");
      lock.size(20);
      lock.setColor(Color.valueOf("#FF0000"));
      setGraphic(lock);
      setOnMouseClicked(e -> {
         if (unlockHandler != null && !isPopOverShowing()) {
            unlockHandler.accept(LockedLabel.this);
         }
      });
   }

   public void setUnlockHandler(Consumer<Node> unlockHandler) {
      this.unlockHandler = unlockHandler;
   }

   private Consumer<Node> unlockHandler;
}
