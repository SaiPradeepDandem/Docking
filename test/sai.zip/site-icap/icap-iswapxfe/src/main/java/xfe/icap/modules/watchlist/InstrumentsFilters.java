package xfe.icap.modules.watchlist;

import com.google.common.base.Strings;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.types.Order;
import xstr.types.User;
import xstr.session.ServerSession;
import com.nomx.persist.PersistantName;
import com.nomx.persist.linelist.Participant;
import xfe.util.Constants;
import xstr.util.Fx;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.ObservableRowFilter;
import xstr.util.filter.RowFilters;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpRfq;
import xstr.session.ObservableReplyRow;
import com.omxgroup.xstream.amp.AmpClearingStatus;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.Fun1;
import xstr.util.Fun2;
import xstr.util.Fun3;
import xstr.util.Util;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;

import static xfe.icap.modules.iswaporders.OrderStatusDecorator.CLEARING_QUEUED;
import static xfe.icap.modules.iswaporders.OrderStatusDecorator.OPEN;

public class InstrumentsFilters {
   private static final Logger logger = LoggerFactory.getLogger(InstrumentsFilters.class);

   static final DynamicFilter<ObservableReplyRow> isRfqBid = RowFilters.equals(AmpRfq.buySell, AmpOrderVerb.buy);
   static final DynamicFilter<ObservableReplyRow> isRfqOffer = RowFilters.equals(AmpRfq.buySell, AmpOrderVerb.sell);
   static final DynamicFilter<ObservableReplyRow> isRfqBoth = RowFilters.equals(AmpRfq.buySell, AmpOrderVerb.buyorsell);

   public static final DynamicFilter<ObservableReplyRow> isIndicativeBid = RowFilters.equals(AmpIcapSecBoardTrim2.bidSpecialOrderType, Constants.PRICE_TYPE_INDICATIVE);
   public static final DynamicFilter<ObservableReplyRow> isIndicativeOffer = RowFilters.equals(AmpIcapSecBoardTrim2.offerSpecialOrderType, Constants.PRICE_TYPE_INDICATIVE);
   public static final DynamicFilter<ObservableReplyRow> isPrivateWorkup = RowFilters.equals(AmpIcapSecBoardTrim2.sessionName, "Private");
   public static final DynamicFilter<ObservableReplyRow> isPublicWorkup = RowFilters.equals(AmpIcapSecBoardTrim2.sessionName, "Public");
   static final DynamicFilter<ObservableReplyRow> isClearingBid = RowFilters.equals(AmpIcapSecBoardTrim2.bidClearingStatus, AmpClearingStatus.clearing);
   static final DynamicFilter<ObservableReplyRow> isClearingOffer = RowFilters.equals(AmpIcapSecBoardTrim2.offerClearingStatus, AmpClearingStatus.clearing);
   static final DynamicFilter<ObservableReplyRow> isClearingToYouBid = RowFilters.equals(AmpIcapSecBoardTrim2.bidClearingStatus, AmpClearingStatus.clearingToYou);
   static final DynamicFilter<ObservableReplyRow> isClearingToYouOffer = RowFilters.equals(AmpIcapSecBoardTrim2.offerClearingStatus, AmpClearingStatus.clearingToYou);
   static final DynamicFilter<ObservableReplyRow> isStaleIndicativeBid =
      DynamicFilter.of(Filters.and(RowFilters.equals(AmpIcapSecBoardTrim2.bidSpecialOrderType, Constants.PRICE_TYPE_INDICATIVE),
         DynamicFilter.of(Filters.or(RowFilters.equals(AmpIcapSecBoardTrim2.secBoardState, "O"), RowFilters.equals(AmpIcapSecBoardTrim2.inheritedState, "O")))));
   static final DynamicFilter<ObservableReplyRow> isStaleIndicativeOffer =
      DynamicFilter.of(Filters.and(RowFilters.equals(AmpIcapSecBoardTrim2.offerSpecialOrderType, Constants.PRICE_TYPE_INDICATIVE),
         DynamicFilter.of(Filters.or(RowFilters.equals(AmpIcapSecBoardTrim2.secBoardState, "O"), RowFilters.equals(AmpIcapSecBoardTrim2.inheritedState, "O")))));
   static final DynamicFilter<ObservableReplyRow> isImpliedBid = new ObservableRowFilter() {
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         ObservableObjectValue<String> orderType = row.getProperty(AmpIcapSecBoardTrim2.bidSpecialOrderType);
         return Fx.asBoolean(Fx.map(orderType, Order.isImplied));
      }
   };
   static final DynamicFilter<ObservableReplyRow> isImpliedOffer = new ObservableRowFilter() {
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         ObservableObjectValue<String> orderType = row.getProperty(AmpIcapSecBoardTrim2.offerSpecialOrderType);
         return Fx.asBoolean(Fx.map(orderType, Order.isImplied));
      }
   };

   final Fun3<ObservableReplyRow, Boolean, Boolean, ? extends ObservableBooleanValue> isIndicative;
   final Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> isBestBidMyFirm;
   final Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> isBestOfferMyFirm;

   final Function<ObservableReplyRow, ? extends ObservableBooleanValue> isBestBidBroker;
   final Function<ObservableReplyRow, ? extends ObservableBooleanValue> isBestOfferBroker;

   private final BooleanProperty isPriceMergedInMain;
   private final BooleanProperty isPriceMergedInMini;

   final Fun2<ObservableReplyRow, Boolean, ? extends ObservableBooleanValue> isImpliedComplex;

   private final XfeSession xfeSession;
   private final User user;

   InstrumentsFilters(XfeSession xfeSession, ConfigurationModule configurationModule) {
      this.xfeSession = xfeSession;
      ServerSession session = xfeSession.getUnderlyingSession();
      isPriceMergedInMain = configurationModule.getParametersStorage().get(PersistantName.MergeWatchListImplied, false);
      isPriceMergedInMini = configurationModule.getParametersStorage().get(PersistantName.MergeImplied, false);
      user = session.getLoggedOnUser();

      isImpliedComplex = new Fun2<ObservableReplyRow, Boolean, ObservableBooleanValue>() {
         @Override
         public ObservableBooleanValue call(
            ObservableReplyRow row,
            Boolean isBid) {

            return new fxext.BooleanBinding() {
               {
                  bind(isPriceMergedInMain, row.rowProperty());
               }

               @Override
               protected boolean computeValue() {
                  boolean orImplied = isPriceMergedInMain.getValue() != null && isPriceMergedInMain.get();
                  final Fun1<ObservableReplyRow, ObservableValue<String>> rightTypeStringGetter = orImplied
                     ? (isBid ? AmpIcapSecBoardTrim2.bidOrderTypeGetter : AmpIcapSecBoardTrim2.offerOrderTypeGetter)
                     : (isBid ? AmpIcapSecBoardTrim2.realBidTypeGetter : AmpIcapSecBoardTrim2.realOfferTypeGetter);

                  String typeVal = rightTypeStringGetter.call(row).getValue();

                  return typeVal != null && (typeVal.contains("mp") ||
                     typeVal.contains("^") ||
                     typeVal.contains("EFI"));
               }
            };
         }
      };

      isIndicative = new Fun3<ObservableReplyRow, Boolean, Boolean, ObservableBooleanValue>() {
         @Override
         public ObservableBooleanValue call(ObservableReplyRow row,
                                            Boolean isBid,
                                            Boolean orImplied) {

            ObservableObjectValue<String> liveSpecialOrderType = isBid ?
               row.getProperty(AmpIcapSecBoardTrim2.bidSpecialOrderType) :
               row.getProperty(AmpIcapSecBoardTrim2.offerSpecialOrderType);

            ObservableObjectValue<Double> livePrice = isBid ?
               row.getProperty(AmpIcapSecBoardTrim2.bidPrice_d) :
               row.getProperty(AmpIcapSecBoardTrim2.offerPrice_d);

            ObservableObjectValue<Double> liveImpliedPrice = isBid ?
               row.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d) :
               row.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
            return new fxext.BooleanBinding() {
               {
                  bind(liveSpecialOrderType, livePrice, liveImpliedPrice);
               }

               @Override
               protected boolean computeValue() {
                  boolean rtn = liveSpecialOrderType.get() != null && liveSpecialOrderType.get().equals(Constants.PRICE_TYPE_INDICATIVE);

                  return rtn &&
                     (!orImplied ||
                        !(liveImpliedPrice != null &&
                           liveImpliedPrice.get() != null) ||
                        (isBid ?
                           (livePrice.get() >= liveImpliedPrice.get()) :
                           (livePrice.get() <= liveImpliedPrice.get())));

               }
            };
         }
      };

      if (xfeSession.getUnderlyingSession().isLoggedOnTrader()) {
         isBestBidMyFirm = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.bidUserId);
               return new fxext.BooleanBinding() {
                  {
                     bind(liveUserId);
                  }

                  @Override
                  protected boolean computeValue() {
                     String bestBidUserId = liveUserId.get();
                     return !Strings.isNullOrEmpty(bestBidUserId) && !bestBidUserId.equals(user.getUserId());
                  }
               };
            }
         };
      } else {
         isBestBidMyFirm = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow observableReplyRow) {
               return Fx.valueOf(false);
            }
         };
//         isBestBidMyFirm = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
//            @Override
//            public ObservableBooleanValue call(final ObservableReplyRow row) {
//               final ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.bidUserId);
//               final ObservableObjectValue<Asn1Type> liveOperatorId = row.getAsnProperty(AmpIcapSecBoardTrim2.bidOperatorId);
//               return new fxext.BooleanBinding() {
//                  {
//                     bind(liveUserId, xfeSessionModule.onBehalfTrader, liveOperatorId);
//                  }
//
//                  @Override
//                  protected boolean computeValue() {
//                     if (Strings.isNullOrEmpty(liveUserId.get()) || xfeSessionModule.onBehalfTrader.get() == null) { //when logging off, it is set to null and other modules are disposing.  Following code may cause null exceptions.
//                        return false;
//                     }
//                     Participant onBehalfTrader = xfeSessionModule.onBehalfTrader.get();
//                     String userId = liveUserId.get();
//                     boolean rtn = onBehalfTrader != null && !userId.equals(onBehalfTrader.getId()) && xfeSessionModule.traderFirmMap.getFirmId(userId).equals(onBehalfTrader.getParentfirmId());
////                     if (logger.isTraceEnabled()) {
////                        if (xfeSessionModule.onBehalfTrader.get() == null) {
////                           logger.trace("isBestBidMyFirm. isLoggedOnUserBroker {} liveUserId: {},   rtn : {}.", sessionModule.isLoggedOnUserBroker(), liveUserId.get(),  rtn);
////                        } else {
////                           logger.trace("isBestBidMyFirm. isLoggedOnUserBroker {} liveUserId: {},  onbehalf of {}, rtn : {}.", sessionModule.isLoggedOnUserBroker(), liveUserId.get(), onBehalfTrader==null ? null : onBehalfTrader.toFullString(), rtn);
////                        }
////                     }
//                     return rtn;
//                  }
//
//               };
//            }
//         };
      }

      if (xfeSession.getUnderlyingSession().isLoggedOnTrader()) {
         isBestOfferMyFirm = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.offerUserId);
               return new fxext.BooleanBinding() {
                  {
                     bind(liveUserId);
                  }

                  @Override
                  protected boolean computeValue() {
                     String bestOfferUserId = liveUserId.get();
                     return !Strings.isNullOrEmpty(bestOfferUserId) && !bestOfferUserId.equals(user.getUserId());
                  }
               };
            }
         };
      } else {
         isBestOfferMyFirm = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow observableReplyRow) {
               return Fx.valueOf(false);
            }
         };
//         isBestOfferMyFirm = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
//            @Override
//            public ObservableBooleanValue call(final ObservableReplyRow row) {
//               final ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.offerUserId);
//               final ObservableObjectValue<Asn1Type> liveOperatorId = row.getAsnProperty(AmpIcapSecBoardTrim2.offerOperatorId);
//               return new fxext.BooleanBinding() {
//                  {
//                     bind(liveUserId, xfeSessionModule.onBehalfTrader, liveOperatorId);
//                  }
//
//                  @Override
//                  protected boolean computeValue() {
//                     if (Strings.isNullOrEmpty(liveUserId.get()) || xfeSessionModule.onBehalfTrader.get() == null) { //when logging off, it is set to null and other modules are disposing.  Following code may cause null exceptions.
//                        return false;
//                     }
//                     Participant onBehalfTrader = xfeSessionModule.onBehalfTrader.get();
//                     String userId = liveUserId.get();
//                     boolean rtn = onBehalfTrader != null && !userId.equals(onBehalfTrader.getId()) && xfeSessionModule.traderFirmMap.getFirmId(userId).equals(onBehalfTrader.getParentfirmId());
//                     if (logger.isTraceEnabled()) {
//                        if (xfeSessionModule.onBehalfTrader.get() == null) {
//                           logger.debug("isBestBidMyFirm. isLoggedOnUserBroker {} liveUserId: {},   rtn : {}.", sessionModule.isLoggedOnUserBroker(), liveUserId.get(), rtn);
//                        } else {
//                           logger.debug("isBestBidMyFirm. isLoggedOnUserBroker {} liveUserId: {},  onbehalf of {}, rtn : {}.", sessionModule.isLoggedOnUserBroker(), liveUserId.get(), onBehalfTrader == null ? null : onBehalfTrader.toFullString(), rtn);
//                        }
//                     }
//                     return rtn;
//                  }
//
//               };
//            }
//         };
      }

/*
 *   If there are orders entered by the broker that are for firms other than that of the selected trader, paint light green.
 *   If the broker does not have auto permission for the selected trader,
 *   maintain the light-green for orders entered by the broker for other traders
 *   but don't apply any trader-specific colouring.
 */
      if (xfeSession.getUnderlyingSession().isLoggedOnUserBroker()) {
         isBestBidBroker = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.bidUserId);
               ObservableObjectValue<String> liveOperatorId = row.getProperty(AmpIcapSecBoardTrim2.bidOperatorId);
               return new fxext.BooleanBinding() {
                  {
                     bind(liveUserId, xfeSession.onBehalfTrader, liveOperatorId);
                  }

                  @Override
                  protected boolean computeValue() {
                     if (!session.isLoggedOn()) return false;
                     if (session.isLoggedOnUserBroker() && xfeSession.onBehalfTrader.get() == null) { //when logging off, it is set to null and other modules are disposing.  Following code may cause null exceptions.
                        return false;
                     }
                     //the order should be submit by the broker,
                     Participant participant = xfeSession.onBehalfTrader.get();
                     String onBehalfUserId = participant == null ? null : participant.getId();
                     String onBehalfFirm = participant == null ? null : xfeSession.onBehalfTrader.get().getParentfirmId();
                     String userFirm = xfeSession.traderFirmMap.getFirmId(liveUserId.get());
                     boolean rtn = Objects.equals(liveOperatorId.get(), user.getUserId()) && !Objects.equals(liveUserId.get(), onBehalfUserId) && !Objects.equals(userFirm, onBehalfFirm);
                     //                  if (logger.isTraceEnabled()) {
                     //                     if (xfeSessionModule.onBehalfTrader.get() == null) {
                     //                        logger.trace("isBestOfferBroker. sessionModule.isLoggedOnUserBroker():" + sessionModule.isLoggedOnUserBroker() + " liveUserId.get():" + liveUserId.get() +" rtn :" + rtn);
                     //                     } else {
                     //                        logger.trace("isBestOfferBroker. sessionModule.isLoggedOnUserBroker():" + sessionModule.isLoggedOnUserBroker() + " xfeSessionModule.onBeHalfOf :" + participant==null ? null : participant.toFullString() + " liveUserId.get():" + liveUserId.get() + " rtn:" + rtn);
                     //                     }
                     //                  }
                     return rtn;
                  }

               };
            }
         };
      } else {
         isBestBidBroker = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {

            @Override
            public ObservableBooleanValue call(ObservableReplyRow observableReplyRow) {
               return Fx.valueOf(false);
            }
         };
      }

      if (xfeSession.getUnderlyingSession().isLoggedOnUserBroker()) {
         isBestOfferBroker = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.offerUserId);
               ObservableObjectValue<String> liveOperatorId = row.getProperty(AmpIcapSecBoardTrim2.offerOperatorId);
               return new fxext.BooleanBinding() {
                  {
                     bind(liveUserId, xfeSession.onBehalfTrader, liveOperatorId);
                  }

                  @Override
                  protected boolean computeValue() {
                     if (!session.isLoggedOn()) return false;
                     if (session.isLoggedOnUserBroker() && xfeSession.onBehalfTrader.get() == null) { //when logging off, it is set to null and other modules are disposing.  Following code may cause null exceptions.
                        return false;
                     }
                     //the order should be submit by the broker,
                     Participant onBehalf = xfeSession.onBehalfTrader.get();
                     String onBehalfId = onBehalf == null ? null : xfeSession.onBehalfTrader.get().getId();
                     String onBehalfFirm = onBehalf == null ? null : xfeSession.onBehalfTrader.get().getParentfirmId();
                     String userFirm = xfeSession.traderFirmMap.getFirmId(liveUserId.get());
                     boolean rtn = Objects.equals(liveOperatorId.get(), user.getUserId()) && !Objects.equals(liveUserId.get(), onBehalfId) && !Objects.equals(userFirm, onBehalfFirm);
                     //                  if (logger.isTraceEnabled()) {
                     //                     if (xfeSessionModule.onBehalfTrader.get() == null) {
                     //                        logger.debug("isBestOfferBroker. sessionModule.isLoggedOnUserBroker():" + sessionModule.isLoggedOnUserBroker() + " liveUserId.get():" + liveUserId.get() +" rtn :" + rtn);
                     //                     } else {
                     //                        logger.debug("isBestOfferBroker. sessionModule.isLoggedOnUserBroker():" + sessionModule.isLoggedOnUserBroker() + " xfeSessionModule.onBeHalfOf :" + onBehalf==null ? null : onBehalf.toFullString() + " liveUserId.get():" + liveUserId.get() + " rtn:" + rtn);
                     //                     }
                     //                  }
                     return rtn;
                  }

               };
            }
         };

      }  else {
         isBestOfferBroker = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {

            @Override
            public ObservableBooleanValue call(ObservableReplyRow observableReplyRow) {
               return Fx.valueOf(false);
            }
         };
      }
   }
   /**
    *
    * @param row it is AmpIcapSecBoardTrim2 row
    */
   boolean hasMyFirmOpenOrder(ObservableReplyRow row) {
      String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
      String firmId = user.isTrader() ? xfeSession.getUnderlyingSession().getStats().getFirmId() : xfeSession.traderFirmMap.getFirmId(xfeSession.getUnderlyingSession().onBehalfTraderId.get());
      if(firmId==null){
         logger.error("firmId is null. Current user is Trader: {}",user.isTrader());
         return false;
      }
      //it is orderReq row
      List<ObservableReplyRow> orders = xfeSession.orders.get().allOrders;
      for (ObservableReplyRow orderRow : orders) {
         if (secCode.equals(orderRow.getValue(AmpManagedOrder.secCode)) && boardId.equals(orderRow.getValue(AmpManagedOrder.boardId))) {
            int orderStatus = orderRow.getValue(AmpManagedOrder.orderStatus);
            if (orderStatus == OPEN || orderStatus == CLEARING_QUEUED) {
               if (firmId.equals(orderRow.getString(AmpManagedOrder.firmId)))
                  return true;
            }
         }
      }
      return false;
   }

   boolean hasMyOpenOrder(ObservableReplyRow icapSecBoardTrim2Row){
      String secCode = icapSecBoardTrim2Row.getValue(AmpIcapSecBoardTrim2.secCode);
      String boardId = icapSecBoardTrim2Row.getValue(AmpIcapSecBoardTrim2.boardId);
      List<ObservableReplyRow> orders = xfeSession.orders.get().allOrders;
      boolean isTrader = user.isTrader();
      String userId =  isTrader ? xfeSession.getUnderlyingSession().getLoggedOnUserId() : xfeSession.getUnderlyingSession().onBehalfTraderId.get();
      for (ObservableReplyRow orderRow : orders) {
         if (secCode.equals(orderRow.getValue(AmpManagedOrder.secCode)) && boardId.equals(orderRow.getValue(AmpManagedOrder.boardId))) {
            int orderStatus = orderRow.getValue(AmpManagedOrder.orderStatus);
            if (orderStatus == OPEN || orderStatus == CLEARING_QUEUED) {
               if (userId.equals(orderRow.getString(AmpManagedOrder.userId)) && ( !isTrader || (orderRow.getValue(AmpManagedOrder.operatorId) == null && orderRow.getValue(AmpManagedOrder.introBrokerId) == null)))
                  return true;
            }
         }
      }
      return false;

   }

   Fun1<ObservableReplyRow, ObservableBooleanValue> isBestBidMine(boolean isMiniWatchList) {
      ServerSession session = xfeSession.getUnderlyingSession();
      BooleanProperty priceMergeProperty = isMiniWatchList ? isPriceMergedInMini : isPriceMergedInMain;

      return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
         @Override
         public ObservableBooleanValue call(ObservableReplyRow row) {
            ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.bidUserId);
            ObservableObjectValue<Double> price = row.getProperty(AmpIcapSecBoardTrim2.bidPrice_d);
            ObservableObjectValue<Double> nLevelPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d);
            return new fxext.BooleanBinding() {
               {
                  bind(liveUserId, xfeSession.onBehalfTrader, priceMergeProperty, price, nLevelPrice);
               }

               @Override
               public String toString() {
                  return "InstrumentsFilters.isBestBidMine for row " + row.getKey();
               }

               @Override
               protected boolean computeValue() {
                  boolean rtn = session.isLoggedOnUserBroker() &&
                     xfeSession.onBehalfTrader.get() != null ?
                     xfeSession.onBehalfTrader.get().isAutoTrader() &&
                        xfeSession.onBehalfTrader.get().getId().equals(liveUserId.get()) :
                     session.getLoggedOnUserId().equals(liveUserId.get());
                  if (priceMergeProperty.get()) {
                     rtn = rtn && Util.isBestPrice(true, price.get(), nLevelPrice.get());
                  }

//                  if (xfeSessionModule.onBehalfTrader.get() == null) {
//                     logger.trace("isBestBidMine. sessionModule.isLoggedOnUserBroker: {}, liveUserId.get: {}, rtn: {}.",
//                        sessionModule.isLoggedOnUserBroker(),
//                        liveUserId.get(),
//                        rtn);
//                  } else {
//                     logger.trace("isBestBidMine. sessionModule.isLoggedOnUserBroker: {}, xfeSessionModule.onBeHalfOf: {}, liveUserId.get: {}, rtn: {}.",
//                        sessionModule.isLoggedOnUserBroker(),
//                        xfeSessionModule.onBehalfTrader.get().toFullString() ,
//                        liveUserId.get(),
//                        rtn);
//                  }
                  return rtn;
               }

            };
         }
      };
   }

   Fun1<ObservableReplyRow, ObservableBooleanValue> isBestOfferMine(boolean isMiniWatchlist) {
      ServerSession session = xfeSession.getUnderlyingSession();
      BooleanProperty isPriceMerge = isMiniWatchlist ? isPriceMergedInMini : isPriceMergedInMain;
      return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
         @Override
         public ObservableBooleanValue call(ObservableReplyRow row) {
            ObservableObjectValue<String> liveUserId = row.getProperty(AmpIcapSecBoardTrim2.offerUserId);
            ObservableObjectValue<Double> price = row.getProperty(AmpIcapSecBoardTrim2.offerPrice_d);
            ObservableObjectValue<Double> nLevelPrice = row.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
            return new fxext.BooleanBinding() {
               {
                  bind(liveUserId, xfeSession.onBehalfTrader, isPriceMerge, price, nLevelPrice);
               }
               @Override
               public String toString() {
                  return "InstrumentsFilters.isBestOfferMine for row " + row.getKey();
               }


               @Override
               protected boolean computeValue() {
                  boolean rtn = session.isLoggedOnUserBroker() &&
                     xfeSession.onBehalfTrader.get() != null ?
                     xfeSession.onBehalfTrader.get().isAutoTrader() &&
                        xfeSession.onBehalfTrader.get().getId().equals(liveUserId.get()) :
                     session.getLoggedOnUserId().equals(liveUserId.get());
                  if (isPriceMerge.get()) {
                     rtn = rtn && Util.isBestPrice(false, price.get(), nLevelPrice.get());
                  }

//                  if (xfeSessionModule.onBehalfTrader.get() == null) {
//                     logger.trace("isBestOfferMine. sessionModule.isLoggedOnUserBroker: {}, liveUserId.get: {}, rtn: {}",
//                        sessionModule.isLoggedOnUserBroker(),
//                        liveUserId.get(),
//                        rtn);
//                  } else {
//                     logger.trace("isBestOfferMine. sessionModule.isLoggedOnUserBroker: {}, xfeSessionModule.onBeHalfOf: {}, liveUserId.get: {}. rtn: {}",
//                        sessionModule.isLoggedOnUserBroker(),
//                        xfeSessionModule.onBehalfTrader.get().toFullString(),
//                        liveUserId.get(),
//                        rtn);
//                  }

                  return rtn;
               }

            };
         }
      };
   }
}
