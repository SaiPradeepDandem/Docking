package xfe.icap.types;

import com.nomx.persist.linelist.Participant;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.session.ServerSession;
import xstr.types.User;
import xstr.util.filter.*;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpOrderBookByOrder;
import xfe.util.XfeAction;
import xstr.session.ObservableReplyRow;
import xfe.util.Constants;
import com.omxgroup.xstream.amp.AmpClearingStatus;
import com.omxgroup.xstream.amp.AmpDisplayCredit;
import xstr.util.Fun1;
import xstr.util.Lazy;

import java.util.Objects;

public class ObboFilters {

   private static final Logger logger = LoggerFactory.getLogger(ObboFilters.class);

   private final XfeSession xfeSession;
   private final ServerSession session;

   private  String getCurrentUser() {
      return session.isLoggedOn() ? session.getLoggedOnUserId() : "";
   }

   private String getCurrentFirm() {
      return session.isLoggedOn() ? session.getStats().getFirmId() : "";
   }

   public ObboFilters(XfeSession xfeSession) {
      this.xfeSession = xfeSession;
      this.session = xfeSession.getUnderlyingSession();
      User user = xfeSession.getUnderlyingSession().getLoggedOnUser();
      String loggedOnuserId = user.getUserId();

      if(user.isBroker()){
    	  if(user.isIB()){
    		  isAmendable = new DynamicFilter<ObservableReplyRow>() {

    			  @Override
    			  public ObservableBooleanValue accept(ObservableReplyRow row) {
    				  return new fxext.BooleanBinding() {
    					  {
    						  bind(session.onBehalfTraderId);
    					  }
    					  @Override
    					  protected boolean computeValue() {
    						  if(row.getValue(AmpOrderBookByOrder.operatorId)!=null){
    							  return false;
    						  }
    						  String ibId = row.getValue(AmpOrderBookByOrder.introBrokerId);
    						  if(ibId==null){
    							  return false;
    						  }
    						  boolean isIbMatch = ibId.equals(loggedOnuserId);
    						  return isIbMatch || Objects.equals(session.onBehalfTraderId.get(), row.getValue(AmpOrderBookByOrder.userId));
    					  }
    				  };
    			  }
    		  };
    	  }else{
    		  isAmendable = new DynamicFilter<ObservableReplyRow>() {

    			  @Override
    			  public ObservableBooleanValue accept(ObservableReplyRow row) {
    				  return new fxext.BooleanBinding() {
    					  {
    						  bind(session.onBehalfTraderId);
    					  }
    					  @Override
    					  protected boolean computeValue() {
    						  String opId = row.getValue(AmpOrderBookByOrder.operatorId);
    						  if(opId==null && row.getValue(AmpOrderBookByOrder.introBrokerId)==null){
    							  return false;
    						  }
    						  boolean isOpMatch = loggedOnuserId.equals(opId);
    						  return isOpMatch || Objects.equals(session.onBehalfTraderId.get(),row.getValue(AmpOrderBookByOrder.userId));
    					  }
    				  };
    			  }
    		  };
    	  }
      } else if (user.isTrader()) {
    	  isAmendable = new DynamicFilter<ObservableReplyRow>() {

    		  @Override
    		  public ObservableBooleanValue accept(ObservableReplyRow row) {
    			  return new fxext.BooleanBinding() {
    				  @Override
    				  protected boolean computeValue() {
    					  if(row.getValue(AmpOrderBookByOrder.operatorId)!=null || row.getValue(AmpOrderBookByOrder.introBrokerId)!= null ){
    						  return false;
    					  }
    					  if(loggedOnuserId.equals(row.getValue(AmpOrderBookByOrder.userId))){
    						  return true;
    					  }
    					  Boolean isShare = row.getValue(AmpOrderBookByOrder.shared);
    					  return isShare!=null && isShare;
    				  }
    			  };
    		  }
    	  };
      } else {
    	  isAmendable = new DynamicFilter<ObservableReplyRow>() {

    		  @Override
    		  public ObservableBooleanValue accept(ObservableReplyRow row) {
    			  return new fxext.BooleanBinding() {
    				  @Override
    				  protected boolean computeValue() {
    					  return false;
    				  }
    			  };
    		  }
    	  };
      }
   }

   DynamicFilter<ObservableReplyRow> createAutoAcceptFilter(BooleanBinding needApplyFilter){
	      return new DynamicFilter<ObservableReplyRow>() {

	  		@Override
	  		public ObservableBooleanValue accept(ObservableReplyRow row) {
	  			return new fxext.BooleanBinding() {
	  				{
	  					bind(needApplyFilter);
	  				}
	  				@Override
	  				protected boolean computeValue() {
                  return !needApplyFilter.get() || Orders.isAutoAcceptOrder(row);
               }
	  			};
	  		}
	  	};

   }

   public static final DynamicFilter<ObservableReplyRow> noLastLookTime = RowFilters.isLongNull(AmpOrderBookByOrder.lastLookTime);
   public static final DynamicFilter<ObservableReplyRow> isIndicative = RowFilters.equals(AmpOrderBookByOrder.specialOrderType, Constants.PRICE_TYPE_INDICATIVE);
   public static final DynamicFilter<ObservableReplyRow> notClone = RowFilters.notEquals(AmpOrderBookByOrder.specialOrderType, "Clone");
   public static final DynamicFilter<ObservableReplyRow> isManaged = RowFilters.valueOf(AmpOrderBookByOrder.managedOrder);
   public final DynamicFilter<ObservableReplyRow> isAmendable;
   public static final DynamicFilter<ObservableReplyRow> isClearing = RowFilters.equals(AmpOrderBookByOrder.clearingStatus, AmpClearingStatus.clearing);
   public static final DynamicFilter<ObservableReplyRow> isClearingToYou = RowFilters.equals(AmpOrderBookByOrder.clearingStatus, AmpClearingStatus.clearingToYou);

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isIndicativeStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
         return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveSpecialOrderType = row.getProperty(AmpOrderBookByOrder.specialOrderType);
               return Bindings.equal(liveSpecialOrderType, Constants.PRICE_TYPE_INDICATIVE);
            }
         };
      }
   };

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isClearingStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
	   @Override
	   protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
		   return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
			   @Override
			   public ObservableBooleanValue call(ObservableReplyRow row) {
				   ObservableObjectValue<Integer> clearingStatus = row.getProperty(AmpOrderBookByOrder.clearingStatus);
				   return Bindings.equal(clearingStatus, AmpClearingStatus.clearing);
			   }
		   };
	   }
   };

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isClearingToYouStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
	   @Override
	   protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
		   return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
			   @Override
			   public ObservableBooleanValue call(ObservableReplyRow row) {
				   ObservableObjectValue<Integer> clearingStatus = row.getProperty(AmpOrderBookByOrder.clearingStatus);
				   return Bindings.equal(clearingStatus, AmpClearingStatus.clearingToYou);
			   }
		   };
	   }
   };

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isStaleStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
         return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<Boolean> liveStale = row.getProperty(AmpOrderBookByOrder.stale);
               return Bindings.equal(liveStale, true);
            }
         };
      }
   };

   /*
For traders the rule should be as follows:
•  if you can see the order in the orderReq and you are the trader on the order, paint the background dark green,
•  if you can see the order in the orderReq and you are not the trader on the order, paint it mauve/purple,
•  if you can’t see the order in the orderReq don’t colour it at all.
For brokers the rule should be as follows:
•  If the broker has auto permission for the selected trader, and the order belongs to the selected trader, paint dark green.
•  If the broker has auto permission for the selected trader, and the order belongs to another trader within the selected trader’s firm, paint the order mauve/purple
•  If there are orders entered by the broker that are for firms other than that of the selected trader, paint light green.
•  if the broker does not have auto permission for the selected trader, maintain the light-green for orders entered by the broker for other traders but don’t apply any trader-specific colouring.



So.
   mine(dark green): if login user is trader, trader's order, or if login user is broker, the broker is auto and onbehalf of the order's trader
   ours/firms (purple): if login user is trader, same firm with the trader or if login user is broker, the broker is auto and same firm with the onbehalf-ed trader
   mine-broker: if login is broker only, ....
    */

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isMineStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
         return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveUserId = row.getProperty(AmpOrderBookByOrder.userId);
//               return Bindings.equal(liveUserId, getCurrentUser());
               return new fxext.BooleanBinding(){
                  {
                     bind(liveUserId, xfeSession.onBehalfTrader);
                  }

                  @Override
                  public String toString() {
                     return "ObboFilters.isMineStyle for row " + row.getKey();
                  }

                  @Override
                  protected boolean computeValue() {
                     Participant onBehalfTrader = xfeSession.onBehalfTrader.get();
                     boolean rtn  = session.isLoggedOnUserBroker() &&
                        onBehalfTrader != null ?
                        onBehalfTrader.isAutoTrader() &&
                           Objects.equals(onBehalfTrader.getId(), liveUserId.get()) :
                        getCurrentUser().equals(liveUserId.get());
                        if (onBehalfTrader == null) {
                           logger.trace("isMineStyle. session.isLoggedOnUserBroker: {}, liveUserId.get: {}, rtn: {}",
                              session.isLoggedOnUserBroker(),
                              liveUserId.get(),
                              rtn);
                        } else {
                           logger.trace("isMineStyle. session.isLoggedOnUserBroker: {}, xfeSessionModule.onBeHalfOf: {}, liveUserId.get : {}, rtn: {}",
                              session.isLoggedOnUserBroker(),
                              onBehalfTrader.toFullString(),
                              liveUserId.get(),
                              rtn);
                        }
                     return rtn;
                  }

               };
            }
         };
      }
   };

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isOursStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
         return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveFirmId = row.getProperty(AmpOrderBookByOrder.firmId);
               ObservableObjectValue<String> liveUserId = row.getProperty(AmpOrderBookByOrder.userId);
//               return Bindings.equal(liveFirmId, getCurrentFirm());
               return new fxext.BooleanBinding(){
                  {
                     bind(liveFirmId, xfeSession.onBehalfTrader);
                  }

                  @Override
                  public String toString() {
                     return "ObboFilters.isOursStyle for row " + row.getKey();
                  }

                  @Override
                  protected boolean computeValue() {
                     Participant onBehalfTrader = xfeSession.onBehalfTrader.get();
                     boolean rtn  = session.isLoggedOnUserBroker() &&
                        onBehalfTrader != null ?
                        onBehalfTrader.isAutoTrader &&
                              (!Objects.equals(onBehalfTrader.getId(), liveUserId.get())) &&
                          onBehalfTrader.getParentfirmId() != null &&
                          Objects.equals(onBehalfTrader.getParentfirmId(), liveFirmId.get()) :
                        (!getCurrentUser().equals(liveUserId.get())) &&
                           getCurrentFirm().equals(liveFirmId.get());
                        if (onBehalfTrader == null) {
                           logger.trace("isOursStyle. session.isLoggedOnUserBroker: {}, liveUserId.get: {}, liveFirmId.get: {}, rtn: {}",
                              session.isLoggedOnUserBroker(),
                              liveUserId.get(),
                              liveFirmId.get(),
                              rtn);
                        } else {
                           logger.trace("isOursStyle. session.isLoggedOnUserBroker: {}, xfeSessionModule.onBeHalfOf.get: {}, liveUserId.get: {}, liveFirmId.get: {}, rtn: {}",
                              session.isLoggedOnUserBroker(),
                              onBehalfTrader.toFullString(),
                              liveUserId.get(),
                              liveFirmId.get(),
                              rtn);
                        }
                     return rtn;
                  }
               };
            }
         };
      }
   };

   /*
    * If current login is a broker and the order entered by the broker that are for firms other than that of the on behalf trader, paint light green.
    * if the broker does not have auto permission for the selected trader, maintain the light-green for orders entered by the broker for other traders but don’t apply any trader-specific colouring.
    * */
   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isMineBrokerStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
         return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<String> liveUserId = row.getProperty(AmpOrderBookByOrder.userId);
               ObservableObjectValue<String> liveFirmId = row.getProperty(AmpOrderBookByOrder.firmId);
               ObservableObjectValue<String> operatorId = row.getProperty(AmpOrderBookByOrder.operatorId);
               ObservableObjectValue<String> introBrokerId = row.getProperty(AmpOrderBookByOrder.introBrokerId);
               return new fxext.BooleanBinding(){
                  {
                     bind(liveUserId, xfeSession.onBehalfTrader, operatorId, liveFirmId, introBrokerId);
                  }
                  //xfeSessionModule.onBeHalfOf.get()!= null && ( !xfeSessionModule.onBeHalfOf.get().isAutoTrader() || (getCurrentUser().equals(liveUserId.get()) && (!xfeSessionModule.onBeHalfOf.get().getParentfirmId().equals(liveFirmId.get()))
                  @Override
                  protected boolean computeValue() {
                     if (!session.isLoggedOn()) return false;
                     Participant onBehalfTrader = xfeSession.onBehalfTrader.get();
                     String operationIdStr = session.getLoggedOnUser().isIB() ? introBrokerId.get() : operatorId.get();
                     boolean rtn = session.isLoggedOnUserBroker() &&
                        session.getLoggedOnUserId().equals(operationIdStr) &&
                        onBehalfTrader != null &&
                        !(Objects.equals(onBehalfTrader.getParentfirmId(), liveFirmId.get()) &&
                           (onBehalfTrader.isAutoTrader || Objects.equals(onBehalfTrader.getId(), liveUserId.get())));
                        if (onBehalfTrader == null) {
                           logger.trace("isMineBrokerStyle. session.isLoggedOnUserBroker: {}, liveUserId.get: {}, liveFirmId.get: {}, rtn: {}",
                              session.isLoggedOnUserBroker(),
                              liveUserId.get(),
                              liveFirmId.get(),
                              rtn);
                        } else {
                           logger.trace("isMineBrokerStyle. session.isLoggedOnUserBroker: {}, xfeSessionModule.onBeHalfOf.get: {}, liveUserId.get: {}, liveFirmId.get: {}, rtn: {}",
                              session.isLoggedOnUserBroker(),
                              onBehalfTrader.toFullString(),
                              liveUserId.get(),
                              liveFirmId.get(),
                              rtn);
                        }
                     return rtn;
                  }
               };
            }
         };
      }
   };

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isCreditAvailableStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
         return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {
               ObservableObjectValue<Integer> liveOrderTradability = row.getProperty(AmpOrderBookByOrder.orderTradability);
               return Bindings.equal(liveOrderTradability, AmpDisplayCredit.yes);
            }
         };
      }
   };

   public final Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>> isCreditUnavailableStyle = new Lazy<Fun1<ObservableReplyRow, ? extends ObservableBooleanValue>>() {
      @Override
      protected Fun1<ObservableReplyRow, ? extends ObservableBooleanValue> initialize() {
         return new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
            @Override
            public ObservableBooleanValue call(ObservableReplyRow row) {

            	return new fxext.BooleanBinding(){
                  final ObservableObjectValue<Integer> liveOrderTradability = row.getProperty(AmpOrderBookByOrder.orderTradability);
                	final ObservableObjectValue<String> firmId = row.getProperty(AmpOrderBookByOrder.firmId);

                  {
            			bind(liveOrderTradability,firmId);
            		}

					@Override
                     protected boolean computeValue() {
                      Integer tradability = liveOrderTradability.get();
                      return (tradability != null && tradability == AmpDisplayCredit.no)
                              && !getCurrentFirm().equals(firmId.get());
                   }
            	};
            }
         };
      }
   };

}
