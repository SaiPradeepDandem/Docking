package xfe.icap.modules.watchlist;

import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class SubtitleTab extends Tab {
   final VBox titleBox = new VBox();
   final Label titleText = new Label();
   final Label subTitleText = new Label();

   public SubtitleTab(String title, String subTitle) {
      titleBox.getStyleClass().add("xfe-split-title");
      titleText.getStyleClass().add("xfe-title-2");
      titleText.setText(title);
      subTitleText.getStyleClass().add("xfe-title-3");
      subTitleText.setText(subTitle);
      titleBox.getChildren().addAll(titleText, subTitleText);
      this.setGraphic(titleBox);
      this.setText(title + "|" + subTitle);
   }

   @Override
   public String toString() {
      return "Tab-" + titleText.getText() + " - " + subTitleText.getText();
   }

   public String getTitle() {
      return titleText.getText();
   }

   public String getSubtitle() {
      return subTitleText.getText();
   }
}
