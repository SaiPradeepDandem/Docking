package xfe.icap.modules.linelist;

//import org.slf4j.*;

import com.nomx.persist.PersistantName;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.StageStyle;
import xstr.util.Fx;
import xfe.util.UiUtil;
import xfe.util.scene.control.VerticalAppContainer;
import xfe.icap.XfeSession;
import xfe.layout.LayoutManager;
import xfe.icap.ui.AttachableStage;

class LinelistStage extends AttachableStage{
   public LinelistStage(LayoutManager<Node> layoutManager,
                        XfeSession session,
                        ButtonBase editorButton,
                        LinelistModule module,
                        LinelistTreeTable node) {
      super(StageStyle.TRANSPARENT, module.sessionModule.fxApplicationModule.getStage(), true, true);
      tableview = node;
      this.setTitle("Line List");
      ImageView logo = new ImageView();
      logo.getStyleClass().add("xfe-icon-app-title");

      StackPane hbox = new StackPane();
      hbox.setMinWidth(150);
      hbox.getStyleClass().add("xfe-linelist-selected-trader");
      if (module.onBehalfTrader.get() == null) {
         userId.setText(session.getUnderlyingSession().getLoggedOnUserId());
      } else {
         userId.setText(module.onBehalfTrader.get().getId());
      }
      StackPane.setAlignment(userId, Pos.CENTER_LEFT);
      StackPane.setAlignment(editorButton, Pos.CENTER_RIGHT);
      hbox.getChildren().addAll(userId, editorButton);
      AnchorPane.setTopAnchor(logo, 5.0);
      AnchorPane.setLeftAnchor(logo, 10.0);
      AnchorPane.setTopAnchor(hbox, 5.0);
      AnchorPane.setLeftAnchor(hbox, 105.0);

      AnchorPane body = new AnchorPane();
      body.getChildren().addAll(logo, hbox);
      body.getStyleClass().add("xfe-linelist");
//      view  = new LinelistView(module);
//      Node node = view.getRoot();
      AnchorPane.setTopAnchor(node, VerticalAppContainer.TOP_BANNER_HEIGHT);
      AnchorPane.setRightAnchor(node, 0.0);
      AnchorPane.setBottomAnchor(node, 0.0);
      AnchorPane.setLeftAnchor(node, 0.0);

      body.getChildren().add(node);
      appContainer.getCloseButton().disableProperty().bind(Bindings.not(module.configurationModule.getParametersStorage().get(PersistantName.DisplayLinstlistShortcut, false)));
      appContainer.setContent(body);
      appContainer.setAllowIconified(false);

      Parent root = appContainer.getRoot();
      root.setId("linelist");
      Scene scene = new Scene(root);
      scene.setFill(null);

      DoubleProperty xProp = module.configurationModule.getData().lineListPosXProperty();
      DoubleProperty yProp = module.configurationModule.getData().lineListPosYProperty();
      this.setX(xProp.get());
      this.setY(yProp.get());
      this.xProperty().addListener(paramObservable -> {
         xProp.set(LinelistStage.this.xProperty().get());
      });

      this.yProperty().addListener(paramObservable -> {
         yProp.set(LinelistStage.this.yProperty().get());
      });


      this.setScene(scene);
      this.setOnHiding(event -> {
         layoutManager.unregister(LinelistStage.this);
         xProp.unbind();
         yProp.unbind();
      });

      this.setOnHidden(event -> {
         if (session.getUnderlyingSession().isLoggedOn()) {
            module.configurationModule.getParametersStorage().get(PersistantName.DisplayLinstlist, true).set(false);
         }
         removeEventFilter(KeyEvent.KEY_PRESSED, module.keyPressLis);
         dispose();
      });

      this.setOnShowing(windowEvent -> {
         layoutManager.register(LinelistStage.this,appContainer);
         addEventFilter(KeyEvent.KEY_PRESSED, module.keyPressLis);
         LinelistStage.this.toFront();
      });

      this.setOnShown(arg0 -> {

//            ZoomableDecorator.setWidth(LinelistStage.this, view.getRoot().prefWidth(307));
//            LinelistStage.this.widthBeforeScale().set(view.getRoot().prefWidth(307));
         hbox.setPrefWidth(userId.getWidth() + editorButton.getWidth() + 20);
         if(!UiUtil.isPointInsideScreens(LinelistStage.this.getX(), LinelistStage.this.getY())){
            LinelistStage.this.setX(0);
            LinelistStage.this.setY(0);
         }
      });

   }

   void setOnHalfTraderId(String tradeId){
      userId.setText(tradeId);
   }

   public void dispose() {
      appContainer.getCloseButton().disableProperty().unbind();
//      view.dispose();
      if(this.isShowing()){
         this.hide();
      }
   }

   @Override
   public void toFront() {
      super.toFront();
      Fx.runLater(tableview::requestFocus);
   }
   //   final LinelistView view ;
   private final Label userId = new Label();
   private final LinelistTreeTable tableview;

//   public void adjustHeight(double totalHeight) {
//      this.setHeight(totalHeight + VerticalAppContainer.getResizerHeight()+6);
//   }
   private final VerticalAppContainer appContainer = new VerticalAppContainer();
}
