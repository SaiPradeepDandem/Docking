package xfe.icap.modules.watchlist;

import com.nomx.domain.types.DefaultDurationType;
import com.nomx.persist.PersistantName;
import com.nomx.persist.Types.Rect;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import com.omxgroup.xstream.amp.AmpSecClassId;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settings.SettingsData;
import xfe.icap.modules.settings.SettingsUIModule;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.IcapSecBoardTrim2Watchlist;
import xfe.icap.types.OrderTrans;
import xfe.layout.LayoutManager;
import xfe.types.Watchlist;
import xfe.ui.CommandButton;
import xfe.ui.notifications.ModalAlertModule;
import xfe.util.Constants;
import xfe.util.UiUtil;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.util.scene.control.VerticalAppContainer;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.*;
import xstr.util.concurrent.Future;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

final class WatchlistStage extends Stage implements Constants {
   private static final Logger logger = LoggerFactory.getLogger(WatchlistStage.class);

   private class ChangeLisForTableRow implements ChangeListener<Object> {
      ChangeLisForTableRow(TableRow<ObservableReplyRow> row) {
         this.row = row;
      }

      @Override
      public void changed(ObservableValue<?> observable, Object oldValue, Object newValue) {
         mineYoursChanged(row, true);
      }
      private final TableRow<ObservableReplyRow> row;
   }
   private static final int EXPANDED_ROW_HEIGHT = 60;
   private static final int NORMAL_ROW_HEIGHT = 17;
   private static final String VIEW_ID = "WL";

   private static boolean isOfferCell(List<String> styleClass) throws Exception {
      int size = styleClass.size();
      for(int i = size -1 ; i>=0 ; i--){
         String style = styleClass.get(i);
         if(style.contains("bid")){
            return false;
         }
         if(style.contains("offer")){
            return true;
         }
      }
      throw new Exception("can't identify bid/offer cell from style "+styleClass);
   }

   WatchlistStage(String extraStyle, ListenerTracker tracker) {
      super(StageStyle.TRANSPARENT);
      this.tracker = tracker;
      if (extraStyle == null || extraStyle.isEmpty())
         this.extraStyle = STYLE_MINIWATCH_BLINKER;
      else
         this.extraStyle = extraStyle + " " + STYLE_MINIWATCH_BLINKER;

      mineBtn.setId("xfe-miniwatch-minebtn");
      mineBtn.textProperty().set("MINE");
      mineBtn.getStyleClass().add("xfe-orderentry-bidbtn");
      mineBtn.getStyleClass().add("xfe-mineyours-border");
      mineBtn.descriptionProperty().bind(Bindings.when(mineBtn.disabledProperty()).then("").otherwise(mineLitDescription));

      yoursBtn.setId("xfe-miniwatch-yoursbtn");
      yoursBtn.textProperty().set("YOURS");
      yoursBtn.getStyleClass().add("xfe-orderentry-offerbtn");
      yoursBtn.getStyleClass().add("xfe-mineyours-border");
      yoursBtn.descriptionProperty().bind(Bindings.when(yoursBtn.disabledProperty()).then("").otherwise(yoursLitDescription));

      watchCombo.setId("xfe-miniwatch-combo");
      watchCombo.setCellFactory(listView -> new WatchlistViewCell());

      watchCombo.setButtonCell(new WatchlistViewCell());
      watchCombo.setMaxWidth(154);//   prevent overlap of logo

      double height = 44;
      double width = 112;
      mineBtn.setPrefHeight(height);
      mineBtn.setMaxHeight(height);
      mineBtn.setPrefWidth(width);
      mineBtn.setMaxWidth(width);
      mineBtn.setOpacity(1D);
      yoursBtn.setPrefHeight(height);
      yoursBtn.setMaxHeight(height);
      yoursBtn.setPrefWidth(width);
      yoursBtn.setMaxWidth(width);
      yoursBtn.setOpacity(1D);

      mineBtn.disabledProperty().addListener((observable, oldValue, newValue) -> {
         if (newValue && mineBtn.litProperty().get())
            mineBtn.litProperty().setValue(true);
      });

      yoursBtn.disabledProperty().addListener((observable, oldValue, newValue) -> {
         if (newValue && yoursBtn.litProperty().get())
            yoursBtn.litProperty().setValue(true);
      });

      mineBtn.litProperty().addListener((observable, oldValue, newValue) -> {
         if (newValue) {
            dynamicOfferSize.unbind();
            dynamicImpOfferSize.unbind();
            dynamicOfferRate.unbind();
            dynamicImpOfferRate.unbind();

            effectiveMineQuantity.setValue(mineQuantity.getValue());
            effectiveMineRate.setValue(mineRate.getValue());

            mineLitDescription.unbind();
         } else if (oldValue && selectedRowProperty.getValue() != null) { // we need to rebind
            effectiveMineQuantity.setValue(null);
            effectiveMineRate.setValue(null);

            dynamicOfferSize.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.offerDepth_d));
            dynamicImpOfferSize.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferQuantity));
            dynamicOfferRate.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.offerPrice_d));
            dynamicImpOfferRate.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d));

            mineLitDescription.bind(Bindings.format(litButtonDescriptionFormat, sMineRate, sMineQuantity));
         }
      });

      yoursBtn.litProperty().addListener((observable, oldValue, newValue) -> {
         if (newValue) {
            dynamicBidSize.unbind();
            dynamicImpBidSize.unbind();
            dynamicBidRate.unbind();
            dynamicImpBidRate.unbind();

            effectiveYoursQuantity.setValue(yoursQuantity.getValue());
            effectiveYoursRate.setValue(yoursRate.getValue());

            yoursLitDescription.unbind();
         } else if (oldValue && selectedRowProperty.getValue() != null) { // we need to rebind
            effectiveYoursQuantity.setValue(null);
            effectiveYoursRate.setValue(null);

            dynamicBidSize.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.bidDepth_d));
            dynamicImpBidSize.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpBidQuantity));
            dynamicBidRate.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.bidPrice_d));
            dynamicImpBidRate.bind(selectedRowProperty.getValue().getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d));

            yoursLitDescription.bind(Bindings.format(litButtonDescriptionFormat, sYoursRate, sYoursQuantity));
         }
      });

      mineBtn.setOnAction(actionEvent -> onMine());

      yoursBtn.setOnAction(actionEvent -> onYours());

      this.setOnHiding(event -> layoutManager.unregister(WatchlistStage.this));

      this.setOnShowing(windowEvent -> layoutManager.register(WatchlistStage.this,appContainer));

      this.setOnShown(windowEvent -> {
         double width1;
         if (activeTableViewProperty.get() != null) {
            if (isExpanded.get()) {
               width1 = activeTableViewProperty.get().prefWidth(506);
            } else {
               width1 = activeTableViewProperty.get().prefWidth(406);
            }
         }
//           ZoomableDecorator.setWidth(WatchlistStage.this,width);
         WatchlistStage.this.toFront();
         WatchlistStage.this.requestFocus();
      });

      setTitle("i-Swap Watchlist");
   }

   private double getDefaultQty() {
     TableView<ObservableReplyRow> activeTableView;
      if (activeView.get().getId() == Constants.PRICE_TIGHTNESS_ID)
         activeTableView = asnTableViewForPT;
      else
         activeTableView = asnTableView;

      ObservableReplyRow row = activeTableView.getSelectionModel().getSelectedItem();

      if (row != null) {
         ReadOnlyObjectWrapper<Integer> secClassId = new ReadOnlyObjectWrapper<>();
         secClassId.set(row.getValue(AmpIcapSecBoardTrim2.secClassId));
         if(secClassId.get() != null && secClassId.get() == AmpSecClassId.strategy) {
            return settingsData.strategyDefaultQtyProperty().get();
         }
         return settingsData.outrightDefaultQtyProperty().get();
      }

      return 0;
   }

   void setActiveTableViewProperty(TableView<ObservableReplyRow> activeTableViewProperty) {
      this.activeTableViewProperty.set(activeTableViewProperty);
   }

   private void setActiveView(WatchlistView ws) {
      watchCombo.getSelectionModel().select(ws);
   }

   public void init(
      LayoutManager<Node> layoutManager,
      XfeSession session,
      TradesFlashModule tradesFlashModule,
      SelectionContextModule selectionContextModule,
      SettingsUIModule settings,
      InstrumentsFilters instrumentsFilters, InstrumentsPane instrumentsPane,
      ObservableList<WatchlistSpec_v2> specs,
      ObservableBooleanValue showingInfoPopups,
      ModalAlertModule notifier, ConfigurationModule configurationModule) {
      this.instrumentsPane = instrumentsPane;
      this.filters = instrumentsFilters;
      this.watchlist = new IcapSecBoardTrim2Watchlist(session);
      this.specs = specs;
      this.settings = settings;
      this.settingsData = settings.getData();
      this.notifier = notifier;
      this.session = session;
      this.layoutManager = layoutManager;
      this.selectionContextModule = selectionContextModule;
      this.showingInfoPopups = showingInfoPopups;
      this.tradesFlashModule = tradesFlashModule;

      asnTableView = setupView(null, false);

      ImageView logo = new ImageView();
      logo.getStyleClass().add("xfe-icon-app-title");
      AnchorPane.setTopAnchor(logo, 5.0);
      AnchorPane.setLeftAnchor(logo, 10.0);
      AnchorPane.setTopAnchor(watchCombo, 5.0);
      AnchorPane.setRightAnchor(watchCombo, 35.0);

      StackPane watchlistStackPane = new StackPane();
      watchlistStackPane.setAlignment(Pos.TOP_LEFT);
      watchlistStackPane.getChildren().addAll(asnTableView, mineBtn, yoursBtn);

      tracker.addListener(activeTableViewProperty, (observable, oldValue, newValue) -> {
         if (newValue != null) {
            watchlistStackPane.getChildren().setAll(newValue, mineBtn, yoursBtn);
         }
      });

      AnchorPane body = new AnchorPane();
      body.getChildren().addAll(logo, watchCombo);
      body.getStyleClass().add("xfe-watchlist");

      if (WatchlistModule.includeWatchlistMineYours) {
         ToggleButton expandButton = new ToggleButton() {{
            this.getStyleClass().add("xfe-expand-miniwatchlist-button");
            this.setId("xfe-expand-miniwatchlist-button");
         }};
         expandButton.setOnAction(actionEvent -> {
            //   expand/contract window
            if (isExpanded.get()) {
               contractWatchlist();
            } else {
               expandWatchlist();
            }
         });
         AnchorPane.setTopAnchor(expandButton, 15.0);
         AnchorPane.setRightAnchor(expandButton, 1.0);
         body.getChildren().add(expandButton);

      }

      appContainer = new VerticalAppContainer(extraStyle);
      appContainer.setContent(body);
      appContainer.setAllowIconified(false);
      appContainer.setId("w-list");
      appContainer.setOnClose(() -> {
         settingsData.displayMiniWatchlistProperty().set(false);
         return Future.valueOf(true);
      });

      Scene scene = new Scene(appContainer.getRoot());
      scene.setFill(null);

      body.getChildren().add(watchlistStackPane);
      AnchorPane.setTopAnchor(watchlistStackPane, 35.0);
      AnchorPane.setRightAnchor(watchlistStackPane, 0.0);
      AnchorPane.setBottomAnchor(watchlistStackPane, 0.0);
      AnchorPane.setLeftAnchor(watchlistStackPane, 0.0);
      setScene(scene);

      appContainer.setTradeSideProp(tradesFlashModule.blinkTradeSideToOffProp,Fx.valueOf(true));
      selectedTabIdProp = configurationModule.getParametersStorage().get(PersistantName.SelectedMiniWatchlistTab, UUID.class, (UUID)null);
      instrumentsPane.priceTightnessProperty4MiniWatchList.bind(priceTightnessProperty);
      mineLitDescription.bind(Bindings.format(litButtonDescriptionFormat, sMineRate, sMineQuantity));
      yoursLitDescription.bind(Bindings.format(litButtonDescriptionFormat, sYoursRate, sYoursQuantity));


      tracker.addListener(watchCombo.getSelectionModel().selectedItemProperty(), (observable, oldValue, newValue) -> {
         if (newValue != null) {
            WatchlistSpec_v2 newSpec = newValue.getSpec();
            activeTab.setValue(newSpec);
            if (newSpec != null)
               setActiveTableViewProperty(asnTableView);
         }
         activeView.setValue(newValue);
      });
      activeView.addListener(activeMiniWatchListInvalidationListener);

      InvalidationListener dynamicDataListener = observable -> mineYoursChanged(selectedRowProperty.get(), false);
      dynamicBidSize.addListener(dynamicDataListener);
      dynamicImpBidSize.addListener(dynamicDataListener);
      dynamicOfferSize.addListener(dynamicDataListener);
      dynamicImpOfferSize.addListener(dynamicDataListener);
      dynamicBidRate.addListener(dynamicDataListener);
      dynamicImpBidRate.addListener(dynamicDataListener);
      dynamicOfferRate.addListener(dynamicDataListener);
      dynamicImpOfferRate.addListener(dynamicDataListener);

      /*this.dynamicValueTurnedNull = new ObjectBinding<Boolean>() {
         {
            bind(dynamicBidSizeUpdater, dynamicImpBidSizeUpdater, dynamicOfferSizeUpdater, dynamicImpOfferSizeUpdater,
                 dynamicBidRateUpdater, dynamicImpBidRateUpdater, dynamicOfferRateUpdater, dynamicImpOfferRateUpdater);
         }
         @Override
         protected Boolean computeValue() {

            System.out.println("dynamicBidSize:" + dynamicBidSize.getValue() + "," + dynamicBidSizeUpdater.getValue());
            System.out.println("dynamicImpBidSize:" + dynamicImpBidSize.getValue() + "," + dynamicImpBidSize.getValue());
            System.out.println("dynamicOfferSize:" + dynamicOfferSize.getValue() + "," + dynamicOfferSizeUpdater.getValue());
            System.out.println("dynamicImpOfferSize:" + dynamicImpOfferSize.getValue() + "," + dynamicImpOfferSizeUpdater.getValue());
            System.out.println("dynamicBidRate:" + dynamicBidRate.getValue() + "," + dynamicBidRateUpdater.getValue());
            System.out.println("dynamicImpBidRate:" + dynamicImpBidRate.getValue() + "," + dynamicImpBidRateUpdater.getValue());
            System.out.println("dynamicOfferRate:" + dynamicOfferRate.getValue() + "," + dynamicOfferRateUpdater.getValue());
            System.out.println("dynamicImpOfferRate:" + dynamicImpOfferRate.getValue() + "," + dynamicImpOfferRateUpdater.getValue());

            return null;
         }
      };

      this.dynamicValueTurnedNull.addListener(new ChangeListener<Boolean>() {
         @Override
         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            if (newValue != null)
               System.out.println(newValue);
         }
      });*/

      tracker.addListener(settings.getData().displayPTTabProperty(), (observable, oldValue, newValue) -> {
         priceTightnessChanged = true;
         specsInvalidationLis.invalidated(null);
      });

      WatchlistStage.this.specs.addListener(specsInvalidationLis);
      specsInvalidationLis.invalidated(null);
      asnTableView.setItems(watchlist.getItems());
      activeMiniWatchListInvalidationListener.invalidated(null);
      focusProp.bind(this.focusedProperty());
      isWatchlistVisible.bind(this.showingProperty());

   }

   @Override
   public void close() {
      appContainer.setTradeSideProp(null, null);
      clearSelectionLis();
      instrumentsPane.priceTightnessProperty4MiniWatchList.unbind();
      mineLitDescription.unbind();
      yoursLitDescription.unbind();
      dynamicBidSize.unbind();
      dynamicImpBidSize.unbind();
      dynamicOfferSize.unbind();
      dynamicImpOfferSize.unbind();
      dynamicBidRate.unbind();
      dynamicImpBidRate.unbind();
      dynamicOfferRate.unbind();
      dynamicImpOfferRate.unbind();

      /*dynamicBidSizeUpdater.unbind();
      dynamicImpBidSizeUpdater.unbind();
      dynamicOfferSizeUpdater.unbind();
      dynamicImpOfferSizeUpdater.unbind();
      dynamicBidRateUpdater.unbind();
      dynamicImpBidRateUpdater.unbind();
      dynamicOfferRateUpdater.unbind();
      dynamicImpOfferRateUpdater.unbind();*/

      yoursBtn.layoutYProperty().unbind();
      mineBtn.layoutYProperty().unbind();
      List<TableColumn<ObservableReplyRow, ?>> columns = asnTableView.getColumns();
      for (TableColumn<ObservableReplyRow, ?> aColumn : columns){
         aColumn.setCellFactory(null);
      }
      columns.clear();
      asnTableView.setItems(null);
      focusProp.unbind();
      isWatchlistVisible.unbind();
      activeTab.unbind();
      activeTab.removeListener(activeMiniWatchListInvalidationListener);
      specs.removeListener(specsInvalidationLis);

      super.close();
      this.instrumentsPane = null;
      this.filters = null;
      this.watchlist = null;
      this.specs = null;
      this.settings = null;
      this.settingsData = null;
      this.notifier = null;
      this.session = null;
      this.layoutManager = null;
      selectedTabIdProp = null;
   }

   ObjectProperty<WatchlistView> activeViewProperty() {
      return activeView;
   }

   TableView<ObservableReplyRow> createTableViewForPT(ListenerTracker listenerTracker) {
      asnTableViewForPT = setupView(listenerTracker, true);
      return asnTableViewForPT;
   }

   private TableViewHeaderUnmovable<ObservableReplyRow> setupView(ListenerTracker listenerTracker, boolean forPriceTightness) {
      TableViewHeaderUnmovable theView = new TableViewHeaderUnmovable() {
         {
            this.getStyleClass().add("xfe-watchlist-tableview");
            setRowFactory(new Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>>() {
               boolean notPriceTight(Double pt, String secCode, Integer secClass) {
                  double threshold;
                  if (secClass == AmpSecClassId.strategy) {
                     if (secCode.endsWith(".bf")) {
                        threshold = settings.getData().butterflyPTForTabProperty().get();
                     } else {
                        threshold = settings.getData().strategyPTForTabProperty().get();
                     }
                  } else {
                     threshold = settings.getData().outrightPTForTabProperty().get();
                  }
                  return pt > threshold;
               }

               @Override
               public TableRow<ObservableReplyRow> call(TableView<ObservableReplyRow> param) {
                  return new HighLightTableRow(instrumentsPane.getColumns(),activeTab) {
                     {
                        ChangeLisForTableRow lis = new ChangeLisForTableRow(this);
                        emptyProperty().addListener((observable, oldValue, newValue) -> {
                           if (newValue) {
                              isWatchlistVisible.removeListener(lis);
                              isExpanded.removeListener(lis);
                              focusProp.removeListener(lis);
                              tableRowSelectionProperty.remove(selectedProperty());
                           } else {
                              isWatchlistVisible.addListener(lis);
                              isExpanded.addListener(lis);
                              focusProp.addListener(lis);
                              tableRowSelectionProperty.put(selectedProperty(), lis);
                           }
                        });

                        selectedProperty().addListener(lis);
                     }

                     @Override
                     protected void updateItem(ObservableReplyRow item, boolean empty) {
                        super.updateItem(item, empty);
                        if (forPriceTightness) {
                           List<String> styles = _this.getStyleClass();
                           if (!empty) {
                              Double pt = item.getValue(AmpIcapSecBoardTrim2.priceTightness);
                              if (pt == null || notPriceTight(pt, item.getValue(AmpIcapSecBoardTrim2.secCode), item.getValue(AmpIcapSecBoardTrim2.secClassId))) {
                                 if (!styles.contains("xfe-pricetightness-empty")) {
                                    styles.add("xfe-pricetightness-empty");
                                 }
                              } else {
                                 styles.remove("xfe-pricetightness-empty");
                              }
                           } else {
                              styles.remove("xfe-pricetightness-empty");
                           }
                        }
                     }
                  };
               }
            });

            InstrumentsColumns instrColumns = instrumentsPane.getColumns();

            TableColumn<ObservableReplyRow, String> bidPriceCol = new TableColumn<>();
            TableColumn<ObservableReplyRow, String> bidOrImpliedPriceCol = new TableColumn<>();

            instrColumns.setupWatchPriceColumn(
               bidPriceCol,
               interrogationActionProperty,
               true,
               showingInfoPopups,
               false,
               watchlistDoubleClickHandler(instrumentsPane, bidPriceCol, bidOrImpliedPriceCol, false),
               columnContextPrice,
               session.secBoards.get().getSecBoardsByKey());
            bidPriceCol.setPrefWidth(InstrumentsPane.COLUMN_PRICE_SIZE + 2);


            instrColumns.setupWatchPriceColumn(
               bidOrImpliedPriceCol,
               interrogationActionProperty,
               true,
               showingInfoPopups,
               true,
               watchlistDoubleClickHandler(instrumentsPane, bidPriceCol, bidOrImpliedPriceCol, true),
               columnContextOrImpliedPrice,
               session.secBoards.get().getSecBoardsByKey());
            bidOrImpliedPriceCol.setPrefWidth(InstrumentsPane.COLUMN_PRICE_SIZE + 2);

            TableColumn<ObservableReplyRow, String> instCol = instrColumns.createWatchInstrumentColumn(interrogationActionProperty, new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
                  @Override
                  public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
                     WatchlistInfoPopup infoPopup = new WatchlistInfoPopup(
                        cell, session, selectionContextModule, row, settingsData, filters, showingInfoPopups,instrumentsPane.columns);

                     layoutManager.register(infoPopup,null);
                     infoPopup.show(cell.getScene().getWindow());
                  }
               }, watchlistDoubleClickHandler(instrumentsPane, bidPriceCol, bidOrImpliedPriceCol, false),
               tradesFlashModule,
               forPriceTightness);
            instCol.setPrefWidth(InstrumentsPane.COLUMN_SECCODE_SIZE);

            TableColumn<ObservableReplyRow, String> bidTotalCol = instrColumns.createWatchTotalColumn(interrogationActionProperty, new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
               @Override
               public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
                  WatchlistInfoPopup infoPopup = new WatchlistInfoPopup(
                     cell, session, selectionContextModule, row, settingsData, filters, showingInfoPopups,instrumentsPane.columns);

                  layoutManager.register(infoPopup,null);
                  infoPopup.show(cell.getScene().getWindow());
               }
            }, true, false, columnContextQuantity);
            bidTotalCol.setPrefWidth(InstrumentsPane.COLUMN_QUANTITY_SIZE);

            TableColumn<ObservableReplyRow, String> bidOrImpliedTotalCol = instrColumns.createWatchTotalColumn(interrogationActionProperty, new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
               @Override
               public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
                  WatchlistInfoPopup infoPopup = new WatchlistInfoPopup(
                     cell, session, selectionContextModule, row, settingsData, filters, showingInfoPopups,instrumentsPane.columns);

                  layoutManager.register(infoPopup,null);
                  infoPopup.show(cell.getScene().getWindow());
               }
            }, true, true, columnContextOrImpliedQuantity);
            bidOrImpliedTotalCol.setPrefWidth(InstrumentsPane.COLUMN_QUANTITY_SIZE);


            TableColumn<ObservableReplyRow, String> offerPriceCol = new TableColumn<>();
            instrColumns.setupWatchPriceColumn(
               offerPriceCol,
               interrogationActionProperty,
               false,
               showingInfoPopups,
               false,
               watchlistDoubleClickHandler(instrumentsPane, bidPriceCol, bidOrImpliedPriceCol, false),
               columnContextPrice,
               session.secBoards.get().getSecBoardsByKey());
            offerPriceCol.setPrefWidth(InstrumentsPane.COLUMN_PRICE_SIZE + 2);


            TableColumn<ObservableReplyRow, String> offerOrImpliedPriceCol = new TableColumn<>();
            instrColumns.setupWatchPriceColumn(
               offerOrImpliedPriceCol,
               interrogationActionProperty,
               false,
               showingInfoPopups,
               true,
               watchlistDoubleClickHandler(instrumentsPane, bidPriceCol, bidOrImpliedPriceCol, true),
               columnContextOrImpliedPrice,
               session.secBoards.get().getSecBoardsByKey());
            offerOrImpliedPriceCol.setPrefWidth(InstrumentsPane.COLUMN_PRICE_SIZE + 2);

            TableColumn<ObservableReplyRow, String> offerTotalCol = instrColumns.createWatchTotalColumn(interrogationActionProperty, new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
               @Override
               public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
                  WatchlistInfoPopup infoPopup = new WatchlistInfoPopup(
                     cell, session, selectionContextModule, row, settingsData, filters, showingInfoPopups,instrumentsPane.columns);

                  layoutManager.register(infoPopup,null);
                  infoPopup.show(cell.getScene().getWindow());
               }
            }, false, false, columnContextQuantity);
            offerTotalCol.setPrefWidth(InstrumentsPane.COLUMN_QUANTITY_SIZE);

            TableColumn<ObservableReplyRow, String> offerOrImpliedTotalCol = instrColumns.createWatchTotalColumn(interrogationActionProperty, new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
               @Override
               public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
                  WatchlistInfoPopup infoPopup = new WatchlistInfoPopup(
                     cell, session, selectionContextModule, row, settingsData, filters, showingInfoPopups,instrumentsPane.columns);

                  layoutManager.register(infoPopup,null);
                  infoPopup.show(cell.getScene().getWindow());
               }
            }, false, true, columnContextOrImpliedQuantity);
            offerOrImpliedTotalCol.setPrefWidth(InstrumentsPane.COLUMN_QUANTITY_SIZE);

            TableColumn<ObservableReplyRow, String> scrollbarCol = instrColumns.createScrollbarColumn();

            InvalidationListener columnSwitchListener = observable -> {
               List<TableColumn<ObservableReplyRow, ?>> cols = new ArrayList<>();
               cols.add(instCol);

               boolean isMerginImp = settingsData.mergeImpliedMiniWatchlistProperty().get();
               boolean isBidOnLeft = settingsData.bidOnLeftProperty().get();

               TableColumn<ObservableReplyRow, String> bidSideColumn =  isMerginImp ? bidOrImpliedPriceCol : bidPriceCol;
               TableColumn<ObservableReplyRow, String> offerSideColumn = isMerginImp ? offerOrImpliedPriceCol : offerPriceCol;
               TableColumn<ObservableReplyRow, String> leftColumn =  isBidOnLeft ? bidSideColumn : offerSideColumn;
               TableColumn<ObservableReplyRow, String> rightColumn = isBidOnLeft ? offerSideColumn : bidSideColumn;

               TableColumn<ObservableReplyRow, String> bidSideTotalColumn = isMerginImp ? bidOrImpliedTotalCol : bidTotalCol;
               TableColumn<ObservableReplyRow, String> offerSideTotalColumn = isMerginImp ? offerOrImpliedTotalCol : offerTotalCol;
               TableColumn<ObservableReplyRow, String> leftTotalColumn = isBidOnLeft ? bidSideTotalColumn : offerSideTotalColumn;
               TableColumn<ObservableReplyRow, String> rightTotalColumn = isBidOnLeft ? offerSideTotalColumn : bidSideTotalColumn;

               cols.add(leftTotalColumn);
               cols.add(leftColumn);
               cols.add(rightColumn);
               cols.add(rightTotalColumn);
               cols.add(scrollbarCol);

               getColumns().setAll(cols);
            };

            InvalidationListener columnExpanderListener = observable -> {
               if (expandColWidths.get()) {
                  setColWidths(bidTotalCol, 54);
                  setColWidths(offerTotalCol, 54);
                  setColWidths(bidOrImpliedTotalCol, 54);
                  setColWidths(offerOrImpliedTotalCol, 54);
               } else {
                  setColWidths(bidTotalCol, 0);
                  setColWidths(offerTotalCol, 0);
                  setColWidths(bidOrImpliedTotalCol, 0);
                  setColWidths(offerOrImpliedTotalCol, 0);
               }
            };

            if (listenerTracker != null) {
               listenerTracker.addListener(settingsData.mergeImpliedMiniWatchlistProperty(), columnSwitchListener);
               listenerTracker.addListener(settingsData.bidOnLeftProperty(),columnSwitchListener);
               listenerTracker.addListener(expandColWidths, columnExpanderListener);
            } else {
               tracker.addListener(settingsData.mergeImpliedMiniWatchlistProperty(), columnSwitchListener);
               tracker.addListener(settingsData.bidOnLeftProperty(),columnSwitchListener);
               tracker.addListener(expandColWidths, columnExpanderListener);
            }

            columnSwitchListener.invalidated(null);
            columnExpanderListener.invalidated(null);
         }

         private Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> watchlistDoubleClickHandler(
            InstrumentsPane instrumentsPane,
            TableColumn<ObservableReplyRow, String> bidPriceCol,
            TableColumn<ObservableReplyRow, String> bidOrImpliedPriceCol,
            boolean allowImplied) {
            return new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
               @Override
               public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
                  OrderSide orderSide = cell.getTableColumn() == bidPriceCol || cell.getTableColumn() == bidOrImpliedPriceCol ? OrderSide.BUY : OrderSide.SELL;

                  instrumentsPane.activateMainWindow();

                  if (row != null) {
                     instrumentsPane.selectTabAndRow(
                        watchCombo.getSelectionModel().getSelectedItem() != null ? watchCombo.getSelectionModel().getSelectedItem().getId() : null,
                        row.getValue(AmpIcapSecBoardTrim2.secCode),
                        AmpIcapSecBoardTrim2.secCode,
                        orderSide,
                        allowImplied && (orderSide == OrderSide.BUY
                           ? AmpIcapSecBoardTrim2.impliedBidBetterGetter.call(row).getValue()>0
                           : AmpIcapSecBoardTrim2.impliedOfferBetterGetter.call(row).getValue()>0));

                     // this line below fails if instrumentsPane needs to change activeTab
                     Fx.runLater(() -> instrumentsPane.selectionContextModule.getOnDoubleClicked().run());
                  }
               }
            };
         }
      };

      theView.setId("xfe-miniwatch-table");
      theView.getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
      theView.setMinHeight(40);
      theView.setPrefHeight(350);

      return theView;
   }

   void showWatchlist(boolean show) {
      if (show) {
         this.show();
         Rect position = settingsData.miniWatchListPostionProperty().get();
         if (position != null) {
            UiUtil.setPosition(this,position);
            this.contractWatchlist();
         } else {
            this.setHeight(400.0);
         }
         Fx.runLater(()->updateStageWidth());
      } else {
         this.hide();
      }
      watchlist.setHidden(!show);
   }

   void contractWatchlist() {

      expandColWidths.set(false);
      isExpanded.set(false);
      updateStageWidth();
   }

   void setPriceTightness(boolean isPT, WatchlistSpec_v2 activeSpecInWatchlist){
      WatchlistSpec_v2 spec = activeListProperty().get();
      if (spec != null && activeSpecInWatchlist.id.equals(spec.id)) {
         spec.setPriceTight(isPT);
         priceTightnessProperty.set(isPT);
      }
   }

   @Override
   protected Object clone() throws CloneNotSupportedException {
      return super.clone();
   }

   private void mineYoursChanged(TableRow<ObservableReplyRow> row, boolean updateRow) {
      if (row == null) return;

      // Setting row selection
      if (updateRow) {
         if (Objects.equals(selectedRowProperty.getValue(), row) && !row.isSelected()) {
            row.setUserData(false);
            row.setPrefHeight(NORMAL_ROW_HEIGHT);
            row.requestLayout();
            hideButton();
            prevSelectedRow = null;
            selectedRowProperty.setValue(null);
            return;
         }

         if (row.isSelected() && !Objects.equals(selectedRowProperty.getValue(), row)) {
            if (selectedRowProperty.getValue() != null) {
               row.setUserData(false);
               row.setPrefHeight(NORMAL_ROW_HEIGHT);
               row.requestLayout();
               hideButton();
               selectedRowProperty.setValue(null);
            }

            selectedRowProperty.setValue(row);
            return;
         }
      }

      if (Objects.equals(row, prevSelectedRow) && !row.isSelected()) {
         prevSelectedRow = null;
         return;
      }

      dynamicBidSize.getValue();
      dynamicImpBidSize.getValue();
      dynamicOfferSize.getValue();
      dynamicImpOfferSize.getValue();
      dynamicBidRate.getValue();
      dynamicImpBidRate.getValue();
      dynamicOfferRate.getValue();
      dynamicImpOfferRate.getValue();

      double existPrefHeight = row.getHeight();
      boolean b = row.isSelected();
      boolean b1 = isWatchlistVisible.get();
      boolean b2 = focusProp.get();
      boolean b3 = isExpanded.get();

      if (b3 && b && b1 && b2) {
         row.setPrefHeight(EXPANDED_ROW_HEIGHT);
         row.setUserData(true);
      } else {
         row.setUserData(false);
         row.setPrefHeight(NORMAL_ROW_HEIGHT);
         row.requestLayout();
         hideButton();
      }

      if (Math.abs(existPrefHeight - row.getPrefHeight()) > 20) {
         mineBtn.litProperty().set(false);
         yoursBtn.litProperty().set(false);
         row.autosize();
         relocatedButtons(row);
      } else {
         if (b && row.getPrefHeight() == EXPANDED_ROW_HEIGHT) {
            relocatedButtons(row);
         }
      }
   }

   private ReadOnlyObjectProperty<WatchlistSpec_v2> activeListProperty() {
      return activeTab;
   }

   private void expandWatchlist() {
      expandColWidths.set(true);
      isExpanded.set(true);
      updateStageWidth();

      //	We want to ensure the expanded watchlist is fully visible on the screen it's
      //	currently displayed on (we're just going to check the top-left corner)
      ObservableList<Screen> listScreens = Screen.getScreensForRectangle(WatchlistStage.this.getX(),
         WatchlistStage.this.getY(), 1, 1);
      Rectangle2D currentScreenBounds = listScreens.get(0).getVisualBounds();
      if (WatchlistStage.this.getX() + WatchlistStage.this.getWidth() > currentScreenBounds.getMaxX()) {
         WatchlistStage.this.setX(currentScreenBounds.getMaxX() - WatchlistStage.this.getWidth());
      }
   }

   //TODO for zoomable feature
   private void updateStageWidth() {
      //	We use sizeToScene to get the width right, but it doesn't account for the vertical scrollbar.
      //	Also it messes with the height so we have to explicitly check and set that.
//	   double height = ZoomableDecorator.getHeight(this);
      appContainer.setPrefHeight(getHeight());
      WatchlistStage.this.sizeToScene();
      double width = WatchlistStage.this.getWidth();
      WatchlistStage.this.setWidth(width);
//      WatchlistStage.this.setHeight(WatchlistStage.this.getHeight());
   }

   private void setColWidths(TableColumn<ObservableReplyRow, String> col, double width) {
      col.setMinWidth(width);
      col.setMaxWidth(width);
      col.setPrefWidth(width);
   }

   private void onMine() {
      if (mineBtn.litProperty().get()) {
         AbstractOrderTrans orderTrans;
         orderTrans = new OrderTrans(notifier);
         if (populateTransactionData(orderTrans, true))
            orderTrans.executeBuySell(session.getUnderlyingSession(), AmpOrderVerb.buy);
         mineBtn.litProperty().set(false);
      } else if (activeTableViewProperty.get().getSelectionModel().getSelectedItem() != null) {
         mineBtn.litProperty().set(true);
         yoursBtn.litProperty().set(false);
      }
   }

   private void onYours() {
      if (yoursBtn.litProperty().get()) {
         AbstractOrderTrans orderTrans;
         orderTrans = new OrderTrans(notifier);
         if (populateTransactionData(orderTrans, false))
            orderTrans.executeBuySell(session.getUnderlyingSession(), AmpOrderVerb.sell);
         yoursBtn.litProperty().set(false);

      } else if (activeTableViewProperty.get().getSelectionModel().getSelectedItem() != null) {
         yoursBtn.litProperty().set(true);
         mineBtn.litProperty().set(false);
      }
   }

   private boolean populateTransactionData(AbstractOrderTrans orderTrans, boolean isMine) {

      if (isMine ? effectiveMineRate.getValue() == null || effectiveMineQuantity.getValue() == null : effectiveYoursRate.getValue() == null || effectiveYoursQuantity.getValue() == null)
         return false;

      ObservableReplyRow row = activeTableViewProperty.get().getSelectionModel().getSelectedItem();
      if (row != null) {
         orderTrans.setSecCode(row.getValue(AmpIcapSecBoardTrim2.secCode));
         orderTrans.setBoardId(row.getValue(AmpIcapSecBoardTrim2.boardId));
         orderTrans.setPrice(isMine ? effectiveMineRate.getValue() : effectiveYoursRate.getValue());
         orderTrans.setQuantity(isMine ? effectiveMineQuantity.getValue() : effectiveYoursQuantity.getValue());
         orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
         orderTrans.setOnLogOffAction(settingsData.onLogoffActionProperty().get());
         orderTrans.setShared(settingsData.sharedOrdersProperty().get());

         return true;
      }

      return false;
   }

   private void hideButton() {
      mineBtn.translateYProperty().unbind();
      mineBtn.translateYProperty().set(10000);
      yoursBtn.translateYProperty().unbind();
      yoursBtn.translateYProperty().set(10000);
   }

   private void clearSelectionLis() {
      for(ReadOnlyBooleanProperty ro:tableRowSelectionProperty.keySet()){
         ChangeLisForTableRow lis = tableRowSelectionProperty.get(ro);
         if(ro!=null){
            ro.removeListener(lis);
         }
      }
      tableRowSelectionProperty.clear();
   }

   private void relocateButton(boolean isOfferCell, TableCell<ObservableReplyRow, ?> cell, TableRow<ObservableReplyRow> row) {
      double x = cell.getLayoutX() + row.getLayoutX();
      CommandButton button = isOfferCell ? yoursBtn : mineBtn;
      button.translateXProperty().set(x);
      button.translateYProperty().bind(Bindings.add(30, row.layoutYProperty()));
   }

   private void relocatedButtons(TableRow<ObservableReplyRow> row) {
      Fx.runLater(() -> {
         if (!(Boolean)row.getUserData()) {
            return;
         }

         boolean bBidSide = false;
         boolean bOfferSide = false;
         boolean bNotBidOrOffer = false;
         TableView<ObservableReplyRow> activeTableView;
         if (activeView.get().getId() == Constants.PRICE_TIGHTNESS_ID)
            activeTableView = asnTableViewForPT;
         else
            activeTableView = asnTableView;

         List<TablePosition> selectedCells = activeTableView.getSelectionModel().getSelectedCells();
         if (selectedCells.size() > 0) {
            TablePosition tablePosition = selectedCells.get(0);
            TableColumn tc = tablePosition.getTableColumn();
            /*if ((tc == bidPriceCol || tc == bidTotalCol || tc == bidOrImpliedPriceCol || tc == bidOrImpliedTotalCol) &&
                    !mineBtn.litProperty().get()) {
               bBidSide = true;
            } else if ((tc == offerPriceCol || tc == offerTotalCol || tc == offerOrImpliedPriceCol || tc == offerOrImpliedTotalCol) &&
                    !yoursBtn.litProperty().get()) {
               bOfferSide = true;
            } else */
            bNotBidOrOffer = true;
         }
         // align the buttons
         ObservableReplyRow replyRow = row.itemProperty().get();
         boolean isBidIndicative = OrderSpecialTypeDecorator.isIndicativePrice(replyRow.getValue(AmpIcapSecBoardTrim2.bidSpecialOrderType));
         boolean isOfferIndicative = OrderSpecialTypeDecorator.isIndicativePrice(replyRow.getValue(AmpIcapSecBoardTrim2.offerSpecialOrderType));
         for (Node ignored : row.getChildrenUnmodifiable()) {
            Skin<?> skin = row.getSkin();
            Node skinNode = skin.getNode();
            List<Node> cells = ((javafx.scene.Parent)skinNode).getChildrenUnmodifiable();
            try {
               TableCell secondColumnCell = (TableCell) cells.get(1);
               boolean isOfferCell = isOfferCell(secondColumnCell.getStyleClass());
               relocateButton(isOfferCell, secondColumnCell, row);
               TableCell fourthColumnCell = (TableCell) cells.get(3);
               isOfferCell = isOfferCell(fourthColumnCell.getStyleClass());
               relocateButton(isOfferCell, fourthColumnCell, row);
            } catch (Exception e) {
               logger.error("can't relocate mine/yours button", e);
            }


            // if this cell is bid/total then we must label YOURS button with bid info

            boolean orImplied = settingsData.mergeImpliedMiniWatchlistProperty().get();

            Double yoursPrice=null;
            Double minePrice=null;

            String sYoursPrice;
            if (orImplied)
               sYoursPrice = columnContextOrImpliedPrice.get(true).call(row.getItem()).getValue();
            else
               sYoursPrice = columnContextPrice.get(true).call(row.getItem()).getValue();
            if (sYoursPrice != null)
               try {
                  yoursPrice = sYoursPrice.isEmpty() ? null : NumberFormat.getInstance().parse(sYoursPrice).doubleValue();
               } catch (ParseException e) {
                  e.printStackTrace();
               }
            else
               sYoursPrice = "";
            sYoursRate.setValue(sYoursPrice);

            String sMinePrice;
            if (orImplied)
               sMinePrice = columnContextOrImpliedPrice.get(false).call(row.getItem()).getValue();
            else
               sMinePrice = columnContextPrice.get(false).call(row.getItem()).getValue();
            if (sMinePrice!=null)
               try {
                  minePrice = sMinePrice.isEmpty() ? null : NumberFormat.getInstance().parse(sMinePrice).doubleValue();
               } catch (ParseException e) {
                  e.printStackTrace();
               }
            else
               sMinePrice = "";
            sMineRate.setValue(sMinePrice);

            if (bBidSide) {
               if (isBidIndicative){
                  yoursBtn.disableProperty().set(true);
                  mineBtn.disableProperty().set(true);
               } else {
                  mineBtn.disableProperty().set(true);
                  mineBtn.litProperty().set(false);

                  yoursBtn.disableProperty().set(false);
                  if(yoursPrice==null){
                     yoursBtn.disableProperty().set(true);
                  } else {
                     yoursRate.set(yoursPrice);
                     double quantity = getDefaultQty();
                     sYoursQuantity.setValue(String.valueOf(quantity));
                     if (!settings.prefs.yoursMineDefaultAmount().get() && row.getItem()!=null) {
                        String sQty;
                        if (orImplied)
                           sQty = columnContextOrImpliedQuantity.get(true).call(row.getItem()).getValue();
                        else
                           sQty = columnContextQuantity.get(true).call(row.getItem()).getValue();
                        sQty = sQty.replaceAll(",","");
                        sYoursQuantity.setValue(sQty);
                        try {
                           quantity = sQty.isEmpty() ? null : NumberFormat.getInstance().parse(sQty).doubleValue();
                        } catch (ParseException e) {
                           e.printStackTrace();
                        }
                     }
                     yoursQuantity.set(quantity);
                  }
               }
            }
            if (bOfferSide) {
               if (isOfferIndicative){
                  mineBtn.disableProperty().set(true);
                  yoursBtn.disableProperty().set(true);
               } else {
                  yoursBtn.disableProperty().set(true);
                  yoursBtn.litProperty().set(false);

                  mineBtn.disableProperty().set(false);
                  if(minePrice==null){
                     mineBtn.disableProperty().set(true);
                  } else {
                     mineRate.set(minePrice);
                     double quantity = getDefaultQty();
                     sMineQuantity.setValue(String.valueOf(quantity));
                     if (!settings.prefs.yoursMineDefaultAmount().get() && row.getItem()!=null) {
                        String sQty;
                        if (orImplied)
                           sQty = columnContextOrImpliedQuantity.get(false).call(row.getItem()).getValue();
                        else
                           sQty = columnContextQuantity.get(false).call(row.getItem()).getValue();
                        sQty = sQty.replaceAll(",","");
                        sMineQuantity.setValue(sQty);
                        try {
                           quantity = sQty.isEmpty() ? null : NumberFormat.getInstance().parse(sQty).doubleValue();
                        } catch (ParseException e) {
                           e.printStackTrace();
                        }
                     }
                     mineQuantity.set(quantity);
                  }
               }
            }
            if (bNotBidOrOffer) {
               if (!mineBtn.litProperty().get()) {
                  if (minePrice == null || isOfferIndicative) {
                     mineBtn.disableProperty().set(true);
                  } else {
                     mineBtn.disableProperty().set(false);
                     mineRate.set(minePrice);
                     double quantity = getDefaultQty();
                     sMineQuantity.setValue(String.valueOf(quantity));
                     if (!settings.prefs.yoursMineDefaultAmount().get() && row.getItem()!=null) {
                        String sQty;
                        if (orImplied)
                           sQty = columnContextOrImpliedQuantity.get(false).call(row.getItem()).getValue();
                        else
                           sQty = columnContextQuantity.get(false).call(row.getItem()).getValue();
                        sQty = sQty.replaceAll(",","");
                        sMineQuantity.setValue(sQty);
                        try {
                           quantity = sQty.isEmpty() ? null : NumberFormat.getInstance().parse(sQty).doubleValue();
                        } catch (ParseException e) {
                           e.printStackTrace();
                        }
                     }
                     mineQuantity.set(quantity);

                  }
               }
               if (!yoursBtn.litProperty().get()) {
                  if (yoursPrice==null || isBidIndicative) {
                     yoursBtn.disableProperty().set(true);
                  } else {
                     yoursBtn.disableProperty().set(false);
                     yoursRate.set(yoursPrice);
                     double quantity = getDefaultQty();
                     sYoursQuantity.setValue(String.valueOf(quantity));
                     if (!settings.prefs.yoursMineDefaultAmount().get() && row.getItem()!=null) {
                        String sQty;
                        if (orImplied)
                           sQty = columnContextOrImpliedQuantity.get(true).call(row.getItem()).getValue();
                        else
                           sQty = columnContextQuantity.get(true).call(row.getItem()).getValue();
                        sQty = sQty.replaceAll(",","");
                        sYoursQuantity.setValue(sQty);
                        try {
                           quantity = sQty.isEmpty()?null:NumberFormat.getInstance().parse(sQty).doubleValue();
                        } catch (ParseException e) {
                           quantity = 0;
                           logger.error("quantity format is wrong.");
                        }
                     }
                     yoursQuantity.set(quantity);
                  }
               }
            }
         }
      });
   }
   private final String extraStyle;
   private final Property<Runnable> interrogationActionProperty = new SimpleObjectProperty<>(Functions.NOOP_RUNNABLE);
   private final ComboBox<WatchlistView> watchCombo = new ComboBox<>();
   private final StringProperty subtitleProperty = new SimpleStringProperty();
   private final StringProperty titleProperty = new SimpleStringProperty();
   private final StringProperty mineLitDescription = new SimpleStringProperty("");
   private final StringProperty yoursLitDescription = new SimpleStringProperty("");
   private final DoubleProperty yoursQuantity = new SimpleDoubleProperty();
   private final DoubleProperty yoursRate = new SimpleDoubleProperty();
   private final DoubleProperty mineQuantity = new SimpleDoubleProperty();
   private final DoubleProperty mineRate = new SimpleDoubleProperty();
   private final DoubleProperty effectiveYoursQuantity =  new SimpleDoubleProperty();
   private final DoubleProperty effectiveYoursRate = new SimpleDoubleProperty();
   private final DoubleProperty effectiveMineQuantity = new SimpleDoubleProperty();
   private final DoubleProperty effectiveMineRate = new SimpleDoubleProperty();
   private final StringProperty sYoursQuantity = new SimpleStringProperty("");
   private final StringProperty sYoursRate = new SimpleStringProperty("");
   private final StringProperty sMineQuantity = new SimpleStringProperty("");
   private final StringProperty sMineRate = new SimpleStringProperty("");
   private final ObjectProperty<WatchlistSpec_v2> activeTab = new SimpleObjectProperty<>();
   private final ObjectProperty<WatchlistView> activeView = new SimpleObjectProperty<>();
   private final BooleanProperty priceTightnessProperty = new SimpleBooleanProperty();
   private final WeakHashMap<Boolean, Callback<ObservableReplyRow, ObservableValue<String>>> columnContextPrice = new WeakHashMap<>();
   private final WeakHashMap<Boolean, Fun1<ObservableReplyRow, ObservableValue<String>>> columnContextQuantity = new WeakHashMap<>();
   private final WeakHashMap<Boolean, Callback<ObservableReplyRow, ObservableValue<String>>> columnContextOrImpliedPrice = new WeakHashMap<>();
   private final WeakHashMap<Boolean, Fun1<ObservableReplyRow, ObservableValue<String>>> columnContextOrImpliedQuantity = new WeakHashMap<>();
   private final CommandButton mineBtn = new CommandButton(BID_LIT_ACTION_STYLE);
   private final CommandButton yoursBtn = new CommandButton(OFFER_LIT_ACTION_STYLE) ;
   private final BooleanProperty expandColWidths = new SimpleBooleanProperty(false);
   private final BooleanProperty isExpanded = new SimpleBooleanProperty(false);
   private final BooleanProperty isWatchlistVisible = new SimpleBooleanProperty(false);
   private final BooleanProperty focusProp = new SimpleBooleanProperty(false);
   private final ReadOnlyObjectWrapper<Double> dynamicBidSize = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> dynamicImpBidSize = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> dynamicOfferSize = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> dynamicImpOfferSize = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> dynamicBidRate = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> dynamicImpBidRate = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> dynamicOfferRate = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> dynamicImpOfferRate = new ReadOnlyObjectWrapper<>();
   private final ObjectProperty<TableRow<ObservableReplyRow>> selectedRowProperty = new SimpleObjectProperty<TableRow<ObservableReplyRow>>(null)
   {
      {
         this.addListener((observable, oldValue, newValue) -> {
            if (!Objects.equals(oldValue, newValue)) {
               if (oldValue != null) {
                  // unbinding dynamic values from previous row
                  dynamicBidSize.unbind();
                  dynamicImpBidSize.unbind();
                  dynamicOfferSize.unbind();
                  dynamicImpOfferSize.unbind();
                  dynamicBidRate.unbind();
                  dynamicImpBidRate.unbind();
                  dynamicOfferRate.unbind();
                  dynamicImpOfferRate.unbind();

                  /*dynamicBidSizeUpdater.unbind();
                  dynamicImpBidSizeUpdater.unbind();
                  dynamicOfferSizeUpdater.unbind();
                  dynamicImpOfferSizeUpdater.unbind();
                  dynamicBidRateUpdater.unbind();
                  dynamicImpBidRateUpdater.unbind();
                  dynamicOfferRateUpdater.unbind();
                  dynamicImpOfferRateUpdater.unbind();*/
               }

               if (newValue != null) {
                  // binding dynamic values to current row
                  dynamicBidSize.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.bidDepth_d));
                  dynamicImpBidSize.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpBidQuantity));
                  dynamicOfferSize.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.offerDepth_d));
                  dynamicImpOfferSize.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferQuantity));
                  dynamicBidRate.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.bidPrice_d));
                  dynamicImpBidRate.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d));
                  dynamicOfferRate.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.offerPrice_d));
                  dynamicImpOfferRate.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d));

                  /*dynamicBidSizeUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.bidDepth));
                  dynamicImpBidSizeUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpBidQuantity));
                  dynamicOfferSizeUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.offerDepth));
                  dynamicImpOfferSizeUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferQuantity));
                  dynamicBidRateUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.bidPrice));
                  dynamicImpBidRateUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice));
                  dynamicOfferRateUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.offerPrice));
                  dynamicImpOfferRateUpdater.bind(newValue.getItem().getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice));*/
               }
            }
         });
      }
   };
   private final WeakHashMap<ReadOnlyBooleanProperty,ChangeLisForTableRow> tableRowSelectionProperty = new WeakHashMap<>(100);
   VerticalAppContainer appContainer;
   private TableView<ObservableReplyRow> asnTableView;
   private TableView<ObservableReplyRow> asnTableViewForPT;
   private final ObjectProperty<TableView<ObservableReplyRow>> activeTableViewProperty =
      new SimpleObjectProperty<>(asnTableView);
   private ModalAlertModule notifier;
   private XfeSession session;
   private Watchlist watchlist;
   private InstrumentsFilters filters;
   private ObservableList<WatchlistSpec_v2> specs;
   private SettingsData settingsData;
   private SettingsUIModule settings;
   private LayoutManager<Node> layoutManager;
   private InstrumentsPane instrumentsPane;
   private SelectionContextModule selectionContextModule;
   private ListenerTracker tracker;
   private ObservableBooleanValue showingInfoPopups;
   private TradesFlashModule tradesFlashModule;
   private ObjectProperty<UUID> selectedTabIdProp;
   private final InvalidationListener activeMiniWatchListInvalidationListener = new InvalidationListener() {
      @Override
      public void invalidated(Observable ob) {
         hideButton();
         WatchlistView view = activeView.get();
         if (view != null) {
            UUID id = view.getId();
            WatchlistSpec_v2 item = view.getSpec(); //for 0069014. Has to be activeTab.get().
            if (item != null) {
               priceTightnessProperty.set(item.priceTight);
               titleProperty.set(item.getTitle());
               subtitleProperty.set(item.getSubtitle());
               if (!id.equals(selectedTabIdProp.getValue())) {
                  selectedTabIdProp.set(id);
               }
               watchlist.setOnSecBoardsReady(session.secBoards.get(),
                  () -> item.populateInto(watchlist, session.secBoards.get()));
            } else {
               selectedTabIdProp.set(id);
            }
         }
      }
   };
   private boolean priceTightnessChanged;
   private final InvalidationListener specsInvalidationLis = new InvalidationListener() {
      @Override
      public void invalidated(Observable ob) {
         // Finding all visible tabs
         List<WatchlistSpec_v2> visSpecs = new ArrayList<>(WatchlistStage.this.specs.size());

         visSpecs.addAll(WatchlistStage.this.specs.stream().filter(WatchlistSpec_v2::isVisible).collect(Collectors.toList()));

         // If the only change was the visibility of the filter bar, we just return
         boolean refresh = false;
         if (priceTightnessChanged)
            refresh = true;
         priceTightnessChanged = false;

         int addedTabs = settings.getData().displayPTTabProperty().get() ? 1: 0;

         refresh = (refresh || visSpecs.size() != (watchCombo.getItems().size() - addedTabs));

         if (!refresh) {
            int index = 0;
            for (; index < visSpecs.size(); ++index) {
               WatchlistSpec_v2 currSpec = watchCombo.getItems().get(index).getSpec();
               WatchlistSpec_v2 newSpec = visSpecs.get(index);
               if (currSpec == null || !currSpec.specialEqualIgnore_filterVisible(newSpec)) {
                  refresh = true;
                  break;
               }
            }
         }

         if (!refresh) return;

         // Refreshing mini watchlist combo
         List<WatchlistView> newList = new ArrayList<>(visSpecs.size());
         newList.addAll(visSpecs.stream().map(WatchlistView::new).collect(Collectors.toList()));
         watchCombo.getItems().setAll(newList);

         if (settings.getData().displayPTTabProperty().get()) {
            watchCombo.getItems().add(new WatchlistView(Constants.PRICE_TIGHTNESS_LABEL.getKey(),
               Constants.PRICE_TIGHTNESS_LABEL.getValue(),
               Constants.PRICE_TIGHTNESS_ID));
         }

         // Setting active spec
         Object o = selectedTabIdProp.getValue();
         UUID prevSelectedSpecId;
         if (o != null) {
            prevSelectedSpecId = (UUID)o;
         } else {
            prevSelectedSpecId = null;
         }

         // If the previous active spec is still visible then it should stay selected
         // otherwise, if the active became invisible or null, selecting spec 0 (or maybe in future the one in main watchlist instead?!)
         boolean activeSpecSet = false;
         for (WatchlistView wv: watchCombo.getItems()) {
            if (wv.getId() != null && wv.getId().equals(prevSelectedSpecId)) {
               activeSpecSet = true;
               setActiveView(wv);
               break;
            }
         }

         if (!activeSpecSet && !watchCombo.getItems().isEmpty()) {
            setActiveView(watchCombo.getItems().get(0));
         }
      }
   };
   private TableRow<ObservableReplyRow> prevSelectedRow;
}

