package xfe.icap.modules.iswaptrades;

import javafx.event.Event;

public class TradeIdEvent extends Event {
	private static final long serialVersionUID = 1L;

	public final Object tradeId;

	public TradeIdEvent(Object tradeId) {
		super(null);
		this.tradeId = tradeId;
	}
}
