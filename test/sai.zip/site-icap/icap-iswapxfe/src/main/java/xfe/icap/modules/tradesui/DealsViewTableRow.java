package xfe.icap.modules.tradesui;

import com.omxgroup.xstream.amp.AmpDealType;
import javafx.beans.value.ChangeListener;
import javafx.scene.control.TableRow;
import xfe.icap.amp.AmpDeal;
import xfe.types.RowHighlight;
import xstr.session.ObservableReplyRow;

/**
 * TableRow for DealsView table.
 */
@SuppressWarnings("java:S115")
public class DealsViewTableRow extends TableRow<ObservableReplyRow> {
   private final ChangeListener<Number> dealTypeListener = (obs, oldVal, dealType) -> setStrategyPseudoClassState(dealType.intValue());

   DealsViewTableRow(){
      itemProperty().addListener((obs, previousRow, currentRow) -> {
         if (previousRow != null) {
            setStrategyPseudoClassState(null);
            previousRow.getProperty(AmpDeal.dealType).removeListener(dealTypeListener);
            /* Setting the information for TestFX test cases */
            DealIdData.clearDealData(getProperties());
         }
         if (currentRow != null) {
            currentRow.getProperty(AmpDeal.dealType).addListener(dealTypeListener);
            setStrategyPseudoClassState(currentRow.getValue(AmpDeal.dealType));

            /* Setting the information for TestFX test cases */
            DealIdData.setDealData(getProperties(), currentRow);
         }
      });
   }

   private void setStrategyPseudoClassState(Integer dealType){
      pseudoClassStateChanged(RowHighlight.FULL.getStyle(),
              dealType != null && dealType.intValue() == AmpDealType.dealStrategy);
   }
}
