package xfe.icap.modules.tradesui;

import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableCell;
import javafx.scene.layout.BorderPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.AmpMarketTrade;
import xfe.icap.amp.AmpActions;
import xfe.icap.amp.AmpDeal;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.actionsdata.ActionsDataModule;
import xfe.icap.modules.dealsdata.DealsDataModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.tradesdata.TradesDataModule;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;
import xfe.module.Module;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.modules.session.SessionScopeModule;

import java.math.BigDecimal;

@Module.Autostart
public class TradesUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradesUIModule.class);

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public TradesDataModule tradesDataModule;

   @ModuleDependency
   public DealsDataModule dealsDataModule;

   @ModuleDependency
   public ActionsDataModule actionsDataModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   private MarketTradesTable marketTradesTable;
   private DealsTable dealsTable;
   private TradesTable tradesTable;
   private TradeStatsTable tradeStatsTable;
   private TabPane tabPane;

   @Override
   public Future<Void> startModule() {
      BorderPane root = new BorderPane();
      tabPane = new TabPane();
      tabPane.setId("trades-tab-pane");
      root.setCenter(tabPane);

      Tab marketTradesTab = new Tab("Market Trades");
      marketTradesTab.setClosable(false);
      tabPane.getTabs().add(marketTradesTab);

      Tab dealsTab = new Tab("ICAP Gilts Trades");
      dealsTab.setClosable(false);
      tabPane.getTabs().add(dealsTab);

      Tab statsTab = new Tab("Trade Stats");
      statsTab.setClosable(false);
      tabPane.getTabs().add(statsTab);

      Tab tradesTab = new Tab("i-Swap Trades");
      tradesTab.setClosable(false);
      tabPane.getTabs().add(tradesTab);

      marketTradesTable = new MarketTradesTable();
      marketTradesTable.setPriceFormatter(this::applyPriceFormatter);
      marketTradesTable.setItems(tradesDataModule.getOutrightsAndStrategyForMarketTrade(tradesDataModule.getMarketTradeData()));
      marketTradesTab.setContent(marketTradesTable);
      tabPane.getSelectionModel().select(marketTradesTab); //select by object

      // setup deals table
      dealsTable = new DealsTable();
      dealsTable.setId("dealsTable");
      dealsTable.setPriceFormatter(this::applyPriceFormatter);
      dealsTable.setItems(dealsDataModule.getAllDeals());
      dealsTab.setContent(dealsTable);

      // setup trades table
      tradesTable = new TradesTable();
      tradesTable.setItems(tradesDataModule.getISwapTradeData());
      tradesTable.setPriceFormatter(this::applyPriceFormatter);
      tradesTable.setSideFactory(this::sideValueFactoryImpl);
      tradesTable.setCounterpartyFactory(this::counterpartyValueFactoryImpl);
      tradesTab.setContent(tradesTable);

      // setup actions table
      tradeStatsTable = new TradeStatsTable();
      tradeStatsTable.setItems(actionsDataModule.getStats());
      tradeStatsTable.setPriceFormatter(this::applyPriceFormatter);
      statsTab.setContent(tradeStatsTable);

      TradesUIModule.this.uiRoot = root;
      uiRoot.setId(MidiLayoutViews.TRADES_UI);
      midiLayoutModule.addView(uiRoot);

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      if (tabPane != null) {
         tabPane.getTabs().forEach(tab -> tab.setContent(null));
         tabPane.getTabs().clear();
         tabPane = null;
      }

      if (marketTradesTable != null) {
         marketTradesTable.setItems(null);
         /*marketTradesTable.getColumns().forEach( col -> {
            col.setCellValueFactory(null);
         });*/
         marketTradesTable.setPriceFormatter(null);
         marketTradesTable = null;
      }
      if (dealsTable != null) {
         dealsTable.setItems(null);
         dealsTable.setPriceFormatter(null);
         dealsTable = null;
      }
      if (tradesTable != null) {
         tradesTable.setItems(null);
         tradesTable.setPriceFormatter(null);
         tradesTable.setSideFactory(null);
         tradesTable.setCounterpartyFactory(null);
         tradesTable = null;
      }
      if (tradeStatsTable != null) {
         tradeStatsTable.setItems(null);
         tradeStatsTable.setPriceFormatter(null);
         tradeStatsTable = null;
      }
      return Future.SUCCESS;
   }

   /**
    * Fetches the appropriate price formatter for the provided row's secCode.
    *
    * @param cell  Table cell
    * @param price Value of the cell
    */
   private void applyPriceFormatter(TableCell<ObservableReplyRow, ?> cell, BigDecimal price) {
      if (cell.getTableRow() != null && cell.getTableRow().getItem() != null) {
         final ObservableReplyRow rowItem = (ObservableReplyRow) cell.getTableRow().getItem();
         securitiesDataModule.getStaticInfo(getSecCode(rowItem), getBoardId(rowItem)).map(info -> {
            try {
               if (cell.getTableRow() != null && cell.getTableRow().getItem() != null) {
                  final ObservableReplyRow newRowItem = (ObservableReplyRow) cell.getTableRow().getItem();
                  if (rowItem == newRowItem) {
                     cell.setText(info.priceFormatter.apply(price));
                  }
               }
            } catch (Exception e) {
               logger.error("Exception while formatting price in TradesUIModule !!!");
            }
            return Future.SUCCESS;
         });
      } else {
         cell.setText(null);
      }
   }

   private String getSecCode(ObservableReplyRow row) {
      if (row.getValue(AmpTrade.secCode) != null) {
         return row.getValue(AmpTrade.secCode);

      } else if (row.getValue(AmpMarketTrade.secCode) != null) {
         return row.getValue(AmpMarketTrade.secCode);

      } else if (row.getValue(AmpDeal.secCode) != null) {
         return row.getValue(AmpDeal.secCode);

      } else {
         return row.getValue(AmpActions.secCode);
      }
   }

   private String getBoardId(ObservableReplyRow row) {
      if (row.getValue(AmpTrade.boardId) != null) {
         return row.getValue(AmpTrade.boardId);

      } else if (row.getValue(AmpMarketTrade.boardId) != null) {
         return row.getValue(AmpMarketTrade.boardId);

      } else if (row.getValue(AmpDeal.boardId) != null) {
         return row.getValue(AmpDeal.boardId);

      } else {
         return row.getValue(AmpActions.boardId);
      }
   }

   private ObservableValue<OrderSide> sideValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getSide(row), row.rowProperty());
   }

   public static OrderSide getSide(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return OrderSide.BUY;

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return OrderSide.SELL;

      return null;
   }

   private ObservableValue<String> counterpartyValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getCounterparty(row), row.rowProperty());
   }

   public static String getCounterparty(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.sellFirmId);

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.buyFirmId);

      return null;
   }

   protected Node uiRoot;
}
