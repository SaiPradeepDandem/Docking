package xfe.icap.modules.historyui;

import javafx.scene.control.TableView;
import xfe.modules.history.HistoricalEvent;
import xfe.ui.table.Tables;

public class HistoryViewTable extends TableView<HistoricalEvent> {

   public HistoryViewTable(HistoryViewUIModule historyViewUIModule) {
      this.historyViewUIModule = historyViewUIModule;
      setPlaceholder(Tables.stripedRowCSSPlaceholder());
      getStyleClass().add("history-view-table");
      initializeTableColumns();
   }

   private void initializeTableColumns() {
   }

   private HistoryViewUIModule historyViewUIModule;
}
