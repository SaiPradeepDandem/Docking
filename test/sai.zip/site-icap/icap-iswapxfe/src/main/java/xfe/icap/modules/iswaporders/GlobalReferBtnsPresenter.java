package xfe.icap.modules.iswaporders;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;

import xfe.types.OrdersTrans;
import xfe.types.UiSession;
import xfe.util.XfeAction;
import xfe.modules.ordersui.GlobalReferBtnsView;
import xfe.modules.ordersui.GlobalReferBtnsView.Presenter;

public class GlobalReferBtnsPresenter  implements Presenter<Node> {
	@SuppressWarnings("unused")
	private GlobalReferBtnsView<Node> view;
	private final UiSession session;
	private final BooleanProperty locked = new SimpleBooleanProperty(false);
	private XfeAction referMineAction;
	private XfeAction referAllAction;

	public GlobalReferBtnsPresenter(UiSession session, ObservableBooleanValue locked) {
		this.session = session;
		this.locked.bind(locked);
	}

	private void onReferMine() {
      OrdersTrans.deactivateAll(session.getUnderlyingSession(), true);
   }

	private void onReferAll() {
      OrdersTrans.deactivateAll(session.getUnderlyingSession(), false);
   }

	public void setView(GlobalReferBtnsView<Node> view) {
		this.view = view;
		view.setPresenter(this);
	}

	public void resetView() {
		this.view = null;
	}

	@Override
	public XfeAction referMineAction() {
		if (this.referMineAction == null) {
			referMineAction = new XfeAction();
			referMineAction.getStyleClass().addAll("xfe-icon-refer-mine");
			referMineAction.textProperty().set("REFER\nMINE");
         referMineAction.setActionId("referMine");
			referMineAction.onActionProperty().set(e -> onReferMine());
			this.referMineAction.disableProperty().bind(locked);
		}
		return this.referMineAction;
	}

	@Override
	public XfeAction referAllAction() {
		if (this.referAllAction == null) {
			this.referAllAction = new XfeAction();
			this.referAllAction.getStyleClass().addAll("xfe-icon-refer-all");
			this.referAllAction.textProperty().set("REFER\nALL");
         referAllAction.setActionId("referAll");
			this.referAllAction.onActionProperty().set(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent paramT) {
					onReferAll();
				}
			});
			this.referAllAction.disableProperty().bind(locked);
		}
		return this.referAllAction;
	}
}
