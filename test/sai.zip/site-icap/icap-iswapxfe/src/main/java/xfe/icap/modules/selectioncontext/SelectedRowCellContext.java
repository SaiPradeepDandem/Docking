package xfe.icap.modules.selectioncontext;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

import xstr.amp.AsnAccessor;
import xstr.session.ObservableReplyRow;

public class SelectedRowCellContext {
   public final ObservableReplyRow selectedRow;
   private final ObjectProperty<AsnAccessor> selectedField = new SimpleObjectProperty<AsnAccessor>(null);

   public SelectedRowCellContext(ObservableReplyRow selectedRow, AsnAccessor selectedField) {
      this.selectedRow = selectedRow;
      this.selectedField.set(selectedField);
   }

   public ObjectProperty<AsnAccessor> getSelectedField() {
      return selectedField;
   }

   public void setSelectedField(AsnAccessor selectedField) {
      this.selectedField.set(selectedField);
   }

   public ObjectProperty<AsnAccessor> selectedFieldProperty() {
      return selectedField;
   }
}
