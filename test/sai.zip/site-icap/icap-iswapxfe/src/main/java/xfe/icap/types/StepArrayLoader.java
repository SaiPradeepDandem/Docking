package xfe.icap.types;

import com.objsys.asn1j.runtime.Asn1Choice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.StepArrayAcc;
import xfe.types.StepArray;
import xstr.session.ServerSession;
import xstr.session.XtrQueryReply;
import xstr.session.XtrQueryRequest;
import xstr.util.Fun1Throws;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StepArrayLoader {
   private static final Logger logger = LoggerFactory.getLogger(StepArrays.class);
   private final ServerSession session;

   public StepArrayLoader(ServerSession session) {
      this.session = session;
   }

   public Future<Map<Long, StepArray>> getPriceArrayMap() {
      StepArrayLoader loader = new StepArrayLoader(session);
      return loader.load(StepArrayAcc.PRICE_STEP_ACC);
   }

   public Future<Map<Long, StepArray>> getQtyArrayMap() {
      StepArrayLoader loader = new StepArrayLoader(session);
      return loader.load(StepArrayAcc.QTY_STEP_ACC);
   }

   Future<Map<Long, StepArray>> load(StepArrayAcc.StepAccess acc) {
      try {
         return session.queryAll(new XtrQueryRequest(acc.getReq())).onSuccess((Fun1Throws<List<XtrQueryReply>, Map<Long, StepArray>>) rows -> {
            Map<Long, StepArray> stepMap = new HashMap<>();
            for (XtrQueryReply ev: rows) {
               switch (ev.getCommand()) {
                  case CREATE:
                     Asn1Choice row = ev.getData();
                     long id = acc.getIdAcc().getValueFromBase(row);
                     double from = acc.getFromAcc().getValueFromBase(row);
                     double value = acc.getStepSizeAcc().getValueFromBase(row);

                     logger.trace("Adding step info: {}: From: {} Step: {}", id, from, value);

                     StepArray stepArray = stepMap.get(id);

                     if (stepArray == null) {
                        stepArray = new StepArray();
                        stepMap.put(id, stepArray);
                     }

                     stepArray.addStep(from, value);

                     break;
                  default:
                     // Ignore
               }
            }
            return stepMap;
         });
      } catch (Exception e) {
         logger.error("Error loading step arrays:", e);
         return Futures.error(e);
      }
   }

}
