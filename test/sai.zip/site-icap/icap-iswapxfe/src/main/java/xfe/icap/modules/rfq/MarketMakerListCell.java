package xfe.icap.modules.rfq;

import com.nomx.persist.rfq.MarketMaker;
import xfe.ui.list.ReorderableListCell;
import xfe.ui.list.ReorderableListView;
import xfe.ui.list.XfeGroup;
import xfe.ui.list.XfeItem;

import javafx.beans.*;
import javafx.beans.property.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class MarketMakerListCell extends ReorderableListCell<MarketMaker> {

//   private final ObjectProperty<? extends XfeGroup<? extends XfeItem>> selectedGroupProp;

   private final GridPane cell = new GridPane();
   private final Button delButton = new Button();
   private final StackPane namePane = new StackPane();
   private final TextField name = new TextField();
   private final TextField ib = new TextField();


   public MarketMakerListCell(ReorderableListView<MarketMaker> view,
                              StringProperty selectedGroupId,
                              ObjectProperty<? extends XfeGroup<? extends XfeItem>> selectedGroupProp){
      super(view,selectedGroupId);
//      this.selectedGroupProp = selectedGroupProp;
      cell.getStyleClass().add("xfe-group-selected-item");
      name.setMaxWidth(200);
      name.setEditable(false);
      name.setOnDragDetected(this.getOnDragDetected());
      name.getStyleClass().add("xfe-hotkey-text");
      StackPane.setAlignment(name, Pos.CENTER_LEFT);
      StackPane.setAlignment(ib, Pos.TOP_RIGHT);
      namePane.getChildren().addAll(ib,name);
      ib.setEditable(false);
      ib.getStyleClass().addAll("xfe-hotkey-text","xfe-ib-text");
      InvalidationListener focusLis = paramObservable -> {
         if (name.isFocused()) {
            MarketMakerListCell.this.getListView().getSelectionModel().select(MarketMakerListCell.this.getItem());
         }
      };
      name.focusedProperty().addListener(focusLis);

      ColumnConstraints nameColumn = new ColumnConstraints();
      nameColumn.setHgrow(Priority.ALWAYS);
      cell.getColumnConstraints().add(nameColumn);
      cell.getColumnConstraints().add(new ColumnConstraints());
      cell.getColumnConstraints().add(new ColumnConstraints());
      cell.getColumnConstraints().add(new ColumnConstraints());

      delButton.getStyleClass().addAll("xfe-grid-tab-close-button","xfe-button-del-participant");
      delButton.setOnAction(arg0 -> {
         MarketMaker par = getItem();
         if(par != null){
            if(par.getGroup()!=null) {
               par.removeFromGroup();
            }else{
               view.getItems().remove(par);
            }
         }
      });
   }

   @Override
   protected void updateItem(MarketMaker item, boolean empty) {
      super.updateItem(item, empty);
      if(isEmpty() || item==null) {
         setGraphic(null);
      }else{
         cell.getChildren().clear();
         cell.add(namePane, 0, 0);
         cell.add(delButton, 2, 0);
         name.setText(item.getId());
         ib.setText(item.getSubTitle()==null?"":item.getSubTitle());
         this.setGraphic(cell);
      }
   }

}
