package xfe.icap.modules.rfq;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import xstr.util.Fun0;

import xfe.util.scene.control.VerticalAppContainer;
import xfe.layout.LayoutManager;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import xstr.util.concurrent.Future;

public class RfqTradeRemainingStage extends Stage {

   public static final double PREFWIDTH = 430;
   public static final double PREFHEIGHT = 190;
   public static final String BID_CONTENT_STYLE = "xfe-bid-content-trade";
   public static final String ASK_CONTENT_STYLE = "xfe-ask-content-trade";

   private static final Set<RfqTradeRemainingStage> openedStages = new HashSet<RfqTradeRemainingStage>();

   private final String sideStyle;
   private final BooleanProperty submitOrder = new SimpleBooleanProperty(false);

   final Stage stage = new Stage(StageStyle.TRANSPARENT); // dummy stage for really workup dialog

   final VBox vbox_root = new VBox() {
      {
         this.setAlignment(Pos.CENTER);
         this.setId("vbox_root");
      }
   };

   final Label message;

   final Button button_yes = new Button("Yes"){
      {
         this.getStyleClass().add("xfe-workup-button");
      }
   };
   final Button button_no = new Button("No"){
      {
         this.getStyleClass().add("xfe-workup-button");
         this.requestFocus();
      }
   };

   public RfqTradeRemainingStage(String boardId, String instrumentCode, int[] sides, double[] quantity, String[] prices, LayoutManager<Node> layoutManager) {
      super(StageStyle.TRANSPARENT);
//      ZoomableDecorator.makeWindowZoomable(this);
      sideStyle = quantity[AmpOrderVerb.buy]>0 ? BID_CONTENT_STYLE: ASK_CONTENT_STYLE;
      VerticalAppContainer appContainer = new VerticalAppContainer(sideStyle, PREFWIDTH, PREFHEIGHT, false,null,true);
      message = new Label() {
         {
            getStyleClass().addAll("xfe-rfq-remaining-quantity-notifier",sideStyle);
            HBox.setHgrow(this, Priority.ALWAYS);
            this.setMaxHeight(1000L);
            appContainer.setPrefHeight(PREFHEIGHT + (prices.length - 1) * 20);
            StringBuilder sb = new StringBuilder(100);
            int size = sides.length;
            for(int index = 0; index<size; index++) {
               if (sides[index] == AmpOrderVerb.buy)
                  sb.append('\t').append(quantity[index]).append(" with bid price at ").append(prices[index]).append(".\n");
               else{
                  sb.append('\t').append(quantity[index]).append(" with offer price at ").append(prices[index]).append(".\n");
               }
            }

            this.setText(String.format("\tWould you like to move the following remaining balance into %s in the regular orderbook?\n%s ", instrumentCode, sb.toString()));

            this.wrapTextProperty().set(true);
         }
      };


      setTitle("i-Swap - RFQ Remaining Order");
      layoutContentPane();

      stage.initModality(Modality.NONE);

      stage.setTitle("i-Swap - RFQ Remaining Order");

      stage.setScene(new Scene(new VBox()));
      stage.getScene().setFill(null);

      stage.focusedProperty().addListener(new ChangeListener<Boolean>() {

         @Override
         public void changed(ObservableValue<? extends Boolean> arg0, Boolean arg1, Boolean arg2) {
            if (!stage.isFocused()) {
               stage.setIconified(false);
               stage.toFront();
            }
         }
      });

      stage.setOnShowing(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent windowEvent) {
            stage.setIconified(true);
            stage.setIconified(false);
         }
      });

      stage.setOnShown(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent windowEvent) {
            stage.toFront();
            RfqTradeRemainingStage.this.requestFocus();
            RfqTradeRemainingStage.this.show();
            RfqTradeRemainingStage.this.toFront();
         }
      });

      // spec does not say so , leave it

      // this.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
      //
      // @Override
      // public void handle(KeyEvent event) {
      // if(event.getCode() == KeyCode.ESCAPE)
      // TradeWorkupStage.this.close();
      // }
      //
      // });

      initOwner(stage);


      appContainer.setContent(new VBox() {
         {
            this.setPrefWidth(PREFWIDTH);
            this.setPrefHeight(PREFWIDTH);
            this.getChildren().add(new StackPane() {
               {
                  // Header outer
                  StackPane headerOuter = this;
                  this.getStyleClass().addAll(sideStyle, "xfe-trade-notifications-header");
                  this.setMinWidth(PREFWIDTH);
                  this.getChildren().add(new HBox() {
                     {
                        this.prefWidthProperty().bind(headerOuter.widthProperty());
                        this.getStyleClass().addAll("xfe-trade-notifications-header-content");
                        this.setFillHeight(true);
                        this.getChildren().setAll(new ImageView() {
                           {
                              // Logo
                              this.getStyleClass().addAll("xfe-icon-app-title");
                           }
                        }, new Pane() {
                           {
                              // Spacer
                              HBox.setHgrow(this, Priority.ALWAYS);
                           }
                        }, new Label() {
                           {
                              // Right Caption
                              this.getStyleClass().addAll("xfe-title");
                              this.setText("RFQ Remaining Order");
                           }
                        });
                     }
                  });
                  VBox.setVgrow(this, Priority.NEVER);
               }
            });
            this.getChildren().add(vbox_root);
            VBox.setVgrow(vbox_root, Priority.ALWAYS);
         }
      });

      appContainer.setAllowIconified(false);
      appContainer.setOnClose(() -> {
         // items.clear();
         // TradeNotificationsStage.this.hide();
         // JIANG seems in icap tw5, close the tradeup dialog does nothing
         close();
         return Future.valueOf(true);
      });
      this.setScene(new Scene(appContainer.getRoot()));

      this.setOnCloseRequest(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent windowEvent) {
            windowEvent.consume();
         }
      });

      layoutManager.register(this,appContainer);
      layoutManager.register(stage,null);
      openedStages.add(this);
   }

   private void layoutContentPane() {
      VBox vbox_content = new VBox() {
         {
            this.setAlignment(Pos.CENTER);
            this.getStyleClass().add("xfe-workup-container");
         }
      };
      AnchorPane content_pane = new AnchorPane() {
         {
            this.setPrefHeight(PREFHEIGHT);
            this.setPrefWidth(PREFWIDTH);
            this.setId("content_pane");
            this.getStyleClass().add("xfe-workup-border");
         }
      };
      vbox_root.getChildren().add(content_pane);
      VBox.setVgrow(content_pane, Priority.ALWAYS);

      AnchorPane.setTopAnchor(vbox_content, 0.0);
      AnchorPane.setLeftAnchor(vbox_content, 0.0);
      AnchorPane.setRightAnchor(vbox_content, 0.0);
      AnchorPane.setBottomAnchor(vbox_content, 0.0);
      content_pane.getChildren().add(vbox_content);

      AnchorPane pane_counterparty = new AnchorPane() { // for the border
         {
            this.getStyleClass().add("xfe-workup-border");
            VBox.setVgrow(this, Priority.ALWAYS);
            getChildren().add(new HBox() {
               {
                  this.setAlignment(Pos.CENTER);
                  AnchorPane.setBottomAnchor(this, 0.0);
                  AnchorPane.setTopAnchor(this, 0.0);
                  AnchorPane.setLeftAnchor(this, 0.0);
                  AnchorPane.setRightAnchor(this, 0.0);

                  getChildren().add(message);
               }
            });
         }
      };
      vbox_content.getChildren().add(pane_counterparty);
      HBox hbox_button = new HBox() {
         {
            this.setAlignment(Pos.BOTTOM_RIGHT);
            VBox.setVgrow(this, Priority.NEVER);

            HBox.setMargin(button_yes, new Insets(2.0, 10.0, 2.0, 0.0));
            this.getChildren().add(button_yes);

            HBox.setMargin(button_no, new Insets(2.0, 50.0, 2.0, 80.0));
            this.getChildren().add(button_no);

            this.setPadding(new Insets(2.0, 0.0, 2.0, 0.0));
            VBox.setMargin(this, new Insets(4.0, 0.0, 0.0, 0.0));
         }
      };
      vbox_content.getChildren().add(hbox_button);

      button_no.getStyleClass().add(sideStyle);
      button_no.setOnAction(new EventHandler<ActionEvent>() {

         @Override
         public void handle(ActionEvent paramT) {
            close();
         }
      });

      button_yes.getStyleClass().add(sideStyle);
      button_yes.setOnAction(new EventHandler<ActionEvent>() {

         @Override
         public void handle(ActionEvent event) {
            submitOrder.set(true);
            close();
         }
      });

   }



   @Override
   public void close() {
      super.close();
      stage.close();
      openedStages.remove(RfqTradeRemainingStage.this);
   }

   public static void closeAll(){
      Iterator<RfqTradeRemainingStage> stages =  openedStages.iterator();
      while(stages.hasNext()){
         RfqTradeRemainingStage  aStage = stages.next();
         aStage.close();
      }
   }

   public BooleanProperty getSubmitProperty(){
      return submitOrder;
   }
}
