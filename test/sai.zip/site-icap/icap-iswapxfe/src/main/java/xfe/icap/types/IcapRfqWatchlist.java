package xfe.icap.types;

import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.*;
import javafx.beans.value.*;
import javafx.collections.*;

import org.slf4j.*;

import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xfe.types.Watchlist;
import xstr.util.*;
import xstr.util.filter.DynamicFilter;
import xfe.icap.XfeSession;
import xstr.session.ObservableReplyRow;

public class IcapRfqWatchlist implements Watchlist {
   private static final Logger logger = LoggerFactory.getLogger(IcapRfqWatchlist.class);
   private final StringProperty titleProperty = new SimpleStringProperty();
   private final StringProperty subtitleProperty = new SimpleStringProperty();
   private final BooleanProperty visibleProperty = new SimpleBooleanProperty(true);
   private final ObjectBinding<ObservableList<ObservableReplyRow>> watchedItemsProperty;

   public IcapRfqWatchlist(XfeSession xfeSession) {
      ObservableList<ObservableReplyRow> visibleItems = Fx.dynamicObservableFilterBy(xfeSession.rfqs.get().activeRfqWithoutRfsSession.get(), itemsFilterProperty);

      this.watchedItemsProperty = new ObjectBinding<ObservableList<ObservableReplyRow>>() {
         @Override
         protected ObservableList<ObservableReplyRow> computeValue() {
            return FXCollections.unmodifiableObservableList(visibleItems);
         }
      };

   }


   @Override
   public ObservableList<SecBoard> getSpecWatchedSecboards() {
      return null;
   }

   /* (non-Javadoc)
    * @see com.nomx.domain.Watchlist#getItems()
    */
   @Override
   public ObservableList<ObservableReplyRow> getItems() {
      return watchedItemsProperty.get();
   }

   private final ObjectProperty<Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue>> itemsFilterProperty =
         new SimpleObjectProperty<>(DynamicFilter.alwaysTrue);

   @Override
   public ObjectProperty<Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue>> itemsFilterProperty() {
      return itemsFilterProperty;
   }

   @Override
   public void setHidden(boolean hidden) {
   }

   @Override
   public void setTitle(String title) {
      this.titleProperty.set(title);
   }

   @Override
   public void setSubtitle(String subtitle) {
      this.subtitleProperty.set(subtitle);
   }

   @Override
   public void setVisible(boolean isVisible) {
      this.visibleProperty.set(isVisible);
   }

   @Override
   public void dispose() {
   }

   @Override
   public void setOnSecBoardsReady(SecBoards secBoards, Runnable runnable) {

      secBoards.ready().onSuccess(new Fun1<Boolean, Void>(){

         @Override
         public Void call(Boolean a) {
            runnable.run();
            return null;
         }
      });
   }

   private final BooleanProperty isItemReady = new SimpleBooleanProperty(true);
   @Override
   public ObservableBooleanValue itemsReadyProperty() {
      return isItemReady;
   }
}
