package xfe.icap.modules.orderentry;

import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.ui.notifications.ConfirmView;
import xfe.ui.notifications.ModalAlertModule;
import xstr.util.Util;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;

/**
 * Created by jiadin on 23/03/2017.
 */
public class BestPriceCheck {

   private final boolean isBid;
   final SelectionContextModule selectionContextModule;
   final ModalAlertModule modalEvents;

   public BestPriceCheck(ModalAlertModule modalEvents, SelectionContextModule selectionContextModule, boolean isBid) {
      this.selectionContextModule = selectionContextModule;
      this.modalEvents = modalEvents;
      this.isBid = isBid;
   }

   public Future<Boolean> execute(double checkPrice) {
      SecBoardContext context = selectionContextModule.secBoardContext.get();
      Future<Double> bestOpsitePrice = selectionContextModule.xfeSession.retrieveBestPrice(context.getBoardId(), context.getSecCode(), !isBid);
      Promise<Boolean> confirmPromise = Futures.newPromise("confirm");

      try {
         Double oppoPrice = bestOpsitePrice.get();
         if (oppoPrice == null) {
            confirmPromise.setSuccess(true);
         } if (Util.isBestPrice(isBid, checkPrice, bestOpsitePrice.get())) {
            ConfirmView confirmView = new ConfirmView(confirmPromise);
            confirmView.setTitle("Order Trade Warning");
            confirmView.setDesc("This order will most likely trade at " + checkPrice + ". Proceed?");
            modalEvents.showConfirm(confirmView);
         } else {
            confirmPromise.setSuccess(true);
         }
      } catch (Exception e) {
         e.printStackTrace();
         confirmPromise.setSuccess(true);
      }
      return confirmPromise;
   }
}
