package xfe.icap.modules.tabeditorview;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableIntegerValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.collections.ObservableSet;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.util.Callback;
import xfe.modules.watchlist.InstrumentSecurityTreeNode;
import xfe.types.DomainDataFormat;
import xfe.types.Instrument;
import xfe.types.SecBoard;
import xfe.ui.Component;
import xfe.util.scene.control.CheckTreeCell;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.util.*;
import xstr.util.concurrent.Disposable;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Future;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class ProductsComponent extends DisposableBase implements Component {
   private Disposable rootBinding;

   private final TreeView<InstrumentSecurityTreeNode> treeView;
   private final ObservableMap<String, ObservableSet<SecBoard>> products;
   private final ObservableSet<SecBoard> selectedInstruments;

   ProductsComponent(
      ObservableList<SecBoard> secBoards,
      ObservableList<Instrument> instruments,
      ObservableList<SecBoard> includedInstruments,
      ObservableSet<SecBoard> selectedInstruments,
      ObservableBooleanValue visibleBinding) {
      this.selectedInstruments = selectedInstruments;

      ObservableSet<SecBoard> hashedIncludedInstruments = Fx.hashed(includedInstruments);
      ObservableSet<SecBoard> hashedSecBoards = Fx.hashed(secBoards);


      ObservableMap<String, Instrument> instrumentsMap = Fx.keyBy(instruments, new Fun1<Instrument,String>(){

         @Override
         public String call(Instrument inst) {
            return inst.getInstrumentId();
         }
      });

      ObservableSet<SecBoard> available = Fx.minus(hashedSecBoards, hashedIncludedInstruments);

      ObservableMap<String, ObservableIntegerValue> instrumentCount = Fx.countBy(available, new Fun1<SecBoard, String>() {
         @Override
         public String call(SecBoard secBoard) {
            return secBoard.getInstrumentId();
         }
      });

      this.products = Fx.groupBy(available, new Fun1<SecBoard, String>() {
         @Override
         public String call(SecBoard secBoard) {
            return secBoard.getInstrumentId();
         }
      });

      ObservableSet<MapEntry<String, ObservableSet<SecBoard>>> entries = Fx.entrySet(products);

      ObservableSet<InstrumentSecurityTreeNode> nodes = Fx.map(entries, new Fun1<MapEntry<String, ObservableSet<SecBoard>>, InstrumentSecurityTreeNode>() {
         @Override
         public InstrumentSecurityTreeNode call(MapEntry<String, ObservableSet<SecBoard>> entry) {
            return new InstrumentTreeNode(instrumentsMap.get(entry.key), entry.value, selectedInstruments, instrumentCount.get(entry.key));
         }
      });

      ObservableList<InstrumentSecurityTreeNode> sortedProducts = Fx.sortBy(nodes, (o1, o2) -> {
         Long inst1SortOrder = o1.getSortOrder();
         Long inst2SortOrder = o2.getSortOrder();

         if (inst1SortOrder != null && inst2SortOrder != null) {
            int compareOrder = Long.compare(inst1SortOrder, inst2SortOrder);

            if (compareOrder == 0) return o1.toString().compareTo(o1.toString());

            return compareOrder;
         }

         if (inst1SortOrder == null && inst2SortOrder == null) {
            return o1.toString().compareTo(o2.toString());
         }

         if (inst1SortOrder == null)
            return 1;

         return -1;

      });

      ObservableList < TreeItem < InstrumentSecurityTreeNode >> items = Fx.map(sortedProducts, new Fun1<InstrumentSecurityTreeNode, TreeItem<InstrumentSecurityTreeNode>>() {
         @Override
         public TreeItem<InstrumentSecurityTreeNode> call(InstrumentSecurityTreeNode node) {
            return new TreeItem<InstrumentSecurityTreeNode>(node) {
               {
                  this.expandedProperty().addListener(new InvalidationListener() {
                     @Override
                     public void invalidated(Observable observable) {
                        if (expandedProperty().get()) {
                           lazyChildren.get();
                           expandedProperty().removeListener(this);
                        }
                     }
                  });
               }

               final Lazy<Object> lazyChildren = new Lazy<Object>() {
                  @Override
                  protected Object initialize() {
                     ObservableList<TreeItem<InstrumentSecurityTreeNode>> children = Fx.map(node.getChildrenUnmodifiable(), new Fun1<InstrumentSecurityTreeNode, TreeItem<InstrumentSecurityTreeNode>>() {
                        @Override
                        public TreeItem<InstrumentSecurityTreeNode> call(InstrumentSecurityTreeNode node) {
                           return new TreeItem<>(node);
                        }
                     });

                     return Fx.bind(getChildren(), children);
                  }
               };

               @Override
               public boolean isLeaf() {
                  return false;
               }
            };
         }
      });

      TreeItem<InstrumentSecurityTreeNode> rootProductNode = new TreeItem<>();

      rootBinding = Fx.bind(rootProductNode.getChildren(), items);

      this.treeView = new TreeView<InstrumentSecurityTreeNode>() {
         {
            TreeView<InstrumentSecurityTreeNode> self = this;
            this.addEventHandler(KeyEvent.KEY_PRESSED, keyEvent -> {
               boolean noModKeys =
                  !keyEvent.isAltDown() &&
                     !keyEvent.isControlDown() &&
                     !keyEvent.isShiftDown() &&
                     !keyEvent.isShortcutDown();

               if (keyEvent.getCode() == KeyCode.SPACE && noModKeys) {
                  TreeItem<InstrumentSecurityTreeNode> selectedItem = self.getSelectionModel().getSelectedItem();

                  if (selectedItem == null) {
                     return;
                  }

                  InstrumentSecurityTreeNode selectedNode = selectedItem.getValue();

                  if (selectedNode == null) {
                     return;
                  }

                  selectedNode.toggleSelected();
               }
            });
            this.setId("xfe-iswap-secseditview-products");
            this.getStyleClass().addAll("xfe-list-view", "xfe-tree-view");
            this.setShowRoot(false);
            this.setEditable(false);
            XfeTooltipFactory.setTooltip(this);
            this.setCellFactory(new Callback<TreeView<InstrumentSecurityTreeNode>, TreeCell<InstrumentSecurityTreeNode>>() {
               @Override
               public TreeCell<InstrumentSecurityTreeNode> call(TreeView<InstrumentSecurityTreeNode> treeView) {
                  return new CheckTreeCell<InstrumentSecurityTreeNode>() {



                     @Override
                     protected void updateItem(InstrumentSecurityTreeNode node,
                                               boolean isEmpty) {
                        super.updateItem(node, isEmpty);

                        textProperty().unbind();
                        tooltipProperty().unbind();
                        checkedProperty().unbind();
                        indeterminateProperty().unbind();

                        ObservableValue<String> displayText = Fx.flatMap(itemProperty(), new Fun1<InstrumentSecurityTreeNode, ObservableValue<String>>() {
                           @Override
                           public ObservableValue<String> call(InstrumentSecurityTreeNode node) {
                              return node.displayProperty();
                           }
                        }, Fx.objectValueOf(""));

                        textProperty().bind(displayText);

                        checkedProperty().bind(Fx.flatMap(this.itemProperty(), new Fun1<InstrumentSecurityTreeNode, ObservableValue<Boolean>>() {
                           @Override
                           public ObservableValue<Boolean> call(InstrumentSecurityTreeNode node) {
                              return node.allSelectedProperty();
                           }
                        }, Fx.valueOf(false)));

                        indeterminateProperty().bind(Fx.flatMap(this.itemProperty(), new Fun1<InstrumentSecurityTreeNode, ObservableValue<Boolean>>() {
                           @Override
                           public ObservableValue<Boolean> call(InstrumentSecurityTreeNode node) {
                              return node.someSelectedProperty();
                           }
                        }, Fx.valueOf(false)));

                        tooltipProperty().bind(new ObjectBinding<Tooltip>() {
                           {
                              bind(itemProperty());
                           }

                           @Override
                           protected Tooltip computeValue() {
                              InstrumentSecurityTreeNode item = getItem();

                              if (item == null) {
                                 return null;
                              }

                              String infoText = item.getInfoText();

                              if (infoText == null) {
                                 return null;
                              }

                              return new Tooltip(infoText);
                           }
                        });
                     }
                     {
                        CheckTreeCell<InstrumentSecurityTreeNode> cell = this;

                        setOnAction(actionEvent -> {
                           InstrumentSecurityTreeNode item = getItem();

                           if (item != null) {
                              item.toggleSelected();
                           }

                           actionEvent.consume();
                        });

                        setOnAction(actionEvent -> {
                           InstrumentSecurityTreeNode item = getItem();

                           if (item != null) {
                              item.toggleSelected();
                           }

                           actionEvent.consume();
                        });

                        setOnDragDetected(mouseEvent -> {
                           if (!cell.getChecked()) {
                              InstrumentSecurityTreeNode node = cell.getItem();

                              selectedInstruments.clear();
                              selectedInstruments.addAll(node.getSecurities());
                           }

                           Dragboard dragBoard = treeView.startDragAndDrop(TransferMode.MOVE);
                           ClipboardContent content = new ClipboardContent();
                           StringBuilder builder = new StringBuilder();

                           for (SecBoard checkedSecBoard: checkedSecBoards()) {
                              builder.append(checkedSecBoard.getSecCode());
                              builder.append("\n");
                           }

                           content.put(DomainDataFormat.SECBOARDS, builder.toString());

                           dragBoard.setContent(content);
                           mouseEvent.consume();
                        });

                        setOnDragOver(new EventHandler<DragEvent>() {
                           @Override
                           public void handle(DragEvent dragEvent) {
                              if (dragEvent.getGestureSource() != this && dragEvent.getDragboard().hasContent(DomainDataFormat.SECBOARDS)) {
                                 dragEvent.acceptTransferModes(TransferMode.MOVE);
                              }

                              dragEvent.consume();
                           }
                        });

                        setOnDragDropped(dragEvent -> {
                           Dragboard dragboard = dragEvent.getDragboard();

                           if (dragboard.hasContent(DomainDataFormat.SECBOARDS)) {
                              dragEvent.setDropCompleted(true);
                           }

                           dragEvent.consume();
                        });
                     }
                  };
               }
            });

            this.setRoot(rootProductNode);

            visibleBinding.addListener((observableValue, oldVisible, newVisible) -> setRoot(newVisible ? rootProductNode : null));

            MultipleSelectionModel<TreeItem<InstrumentSecurityTreeNode>> productsSelectionModel = this.getSelectionModel();

            productsSelectionModel.setSelectionMode(SelectionMode.SINGLE);
         }
      };
   }

   List<SecBoard> checkedSecBoards() {
      ArrayList<SecBoard> checkedSecBoards = new ArrayList<>();

      for (Entry<String, ObservableSet<SecBoard>> entry: products.entrySet()) {
         Collection<SecBoard> secBoards = Util.sortBy(entry.getValue(), Comparator.comparingLong(SecBoard::getMaturityDateAsLong).thenComparing(SecBoard::getSecCode));

         checkedSecBoards.addAll(secBoards.stream().filter(selectedInstruments::contains).collect(Collectors.toList()));
      }

      return checkedSecBoards;
   }

   @Override
   protected Future<Void> dispose(boolean disposing) {
      this.treeView.setRoot(null);

      if (rootBinding != null) {
         rootBinding.dispose();
         rootBinding = null;
      }

      return super.dispose(disposing);
   }

   @Override
   public Node getNode() {
      return treeView;
   }
}
