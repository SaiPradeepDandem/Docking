/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xfe.icap.types;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.syssrv.Duration;
import com.omxgroup.xstream.amp.AmpOrderDuration;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpManagedOrder;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.session.XtrTransReply;
import xfe.types.StepArray;
import xstr.util.Fun1;
import xstr.util.ReplyHandler;
import xstr.util.exception.XtrException;

import java.text.NumberFormat;
import java.text.ParseException;

import static xfe.icap.modules.iswaporders.OrderStatusDecorator.*;

public class ManagedOrder extends Order implements Comparable<ManagedOrder> {
   @SuppressWarnings("unused")
   private static final Logger logger = LoggerFactory.getLogger(ManagedOrder.class);
   public ManagedOrder(ObservableReplyRow data) {
      super(data.getAsn(AmpManagedOrder.currentOrderId));
      this.data = data;
   }

   public ManagedOrder(QueryReplyRow data) {
      super(data.getAsn(AmpManagedOrder.currentOrderId));
      this.data = data;
   }

   public QueryReplyRow getData() {
      return data;
   }

   public int getStatus() {
      return data.getValue(AmpManagedOrder.orderStatus);
   }

   public Double getPrice() {
      String str =  data.getValue(AmpManagedOrder.priceStr);
      try {
         return  nf.parse(str).doubleValue();
      } catch (ParseException e) {
         return data.getValue(AmpManagedOrder.price_d);
      }
   }

   public Double getQuantity() {
      return data.getValue(AmpManagedOrder.quantity_d);
   }

   public Double getBalance() {
      return data.getValue(AmpManagedOrder.balance_d);
   }

   public Duration getDuration() {
      return data.getValue(AmpManagedOrder.durationTime);
   }

   public Integer getDurationType() {
      return data.getValue(AmpManagedOrder.durationType);
   }

   private Integer getOnLogoff() {
      return data.getValue(AmpManagedOrder.actionOnLogoff);
   }

   public Double getVisibleQuantity() {
      return data.getValue(AmpManagedOrder.visibleQuantity);
   }

   public final boolean isIceberg() {
      return getVisibleQuantity() != null;
   }

   public Double getMinFillQuantity() {
      return data.getValue(AmpManagedOrder.minFillQuantity);
   }

   public Boolean getAllowMultiMinFill() {
      return data.getValue(AmpManagedOrder.allowMultiMinFill);
   }

   public Boolean getShared() {
      return data.getValue(AmpManagedOrder.shared);
   }

   public Boolean getIsTopcut() {
      return data.getValue(AmpManagedOrder.isTopcut);
   }

   public String getSecCode() {
      return data.getValue(AmpManagedOrder.secCode);
   }

   public String getBoardId() {
      return data.getValue(AmpManagedOrder.boardId);
   }

   public String getFirmId(){
      return data.getValue(AmpManagedOrder.firmId);
   }

   public Asn1Type getSecBoardId() {
      return data.getAsn(AmpManagedOrder.secBoardId);
   }

   public boolean isBid() {
      return ((AmpOrderVerb) data.getAsn(AmpManagedOrder.buySell)).value == AmpOrderVerb.buy;
   }

   public boolean isDoneIfTouched() {
      Boolean ret = data.getValue(AmpManagedOrder.isDoneIfTouched);
      return ret != null && ret;
   }

   public boolean isPublic() {
      return data.getValue(AmpManagedOrder.isPublic);
   }

   public boolean isCloneToTS() {
      return data.getValue(AmpManagedOrder.cloneIntoRFS);
   }

   public boolean isImmediate() {
      return ((AmpOrderDuration) data.getAsn(AmpManagedOrder.durationType)).value == AmpOrderDuration.immediate;
   }

   public boolean isPrivate() {
      return getStatus() == PRIVATE_ORDER;
   }

   public int getBuySell(){
      return data.getValue(AmpManagedOrder.buySell);
   }

   public boolean canAmendPrice(String loggedInUser) {
      return loggedInUser.equals(getUserId());
   }

   @Override
   public void tickUpDown(
      ServerSession session,
      StepArrays stepArrays,
      Integer tickValue,
      ReplyHandler<XtrTransReply> handler) throws XtrException {
      if (isManaged()) {
         stepArrays.getSpinPriceStepArray(getSecCode(), getBoardId()).onSuccess(new Fun1<StepArray, Void>(){

            @Override
            public Void call(StepArray stepArray) {
               Double newPrice = stepArray.notch(getPrice(), tickValue);
               if (data.getValue(AmpManagedOrder.price_d).equals(newPrice)) {
                  return null;
               }

               ManagedOrderTrans txn = new ManagedOrderTrans(null);

               txn.setCloneIntoRFS(isCloneToTS());
               txn.setSecCode(getSecCode());
               txn.setBoardId(getBoardId());
               txn.setPrice(newPrice);
               txn.setQuantity(getBalance());
               txn.setShared(getShared());
               txn.setTopCut(getIsTopcut());
               txn.setAnonymous(!isPublic());
               txn.setUnderRef(canRenew());
               txn.setDoneIfTouched(isDoneIfTouched());

               if (getDurationType() != null) {
                  txn.setDefaultDurationType(getDurationType());
               }

               if (getDuration() != null) {
                  txn.setDuration(getDuration());
               }

               if (getOnLogoff() != null) {
                  txn.setOnLogOffAction(getOnLogoff());
               }

               if (getMinFillQuantity() != null) {
                  txn.setMinFill(getMinFillQuantity());
               }

               if (getAllowMultiMinFill() != null) {
                  txn.setAllowMultiMinFill(getAllowMultiMinFill());
               }

               if (getVisibleQuantity() != null) {
                  txn.setVisibleQty(getVisibleQuantity());
               }

               if (isBid()) {
                  txn.execute(AmpOrderVerb.buy, session, getUserId(), getIntroBrokerId());
               } else {
                  txn.execute(AmpOrderVerb.sell, session, getUserId(), getIntroBrokerId());
               }

               return null;
            }

         });
      } else {
         super.tickUpDown(session, stepArrays, tickValue, handler);
      }
   }

   @Override
   public String getUserId() {
      return data.getValue(AmpManagedOrder.userId);
   }

   @Override
   public String getOperatorId() {
      return data.getValue(AmpManagedOrder.operatorId);
   }

   @Override
   public String getIntroBrokerId(){
      return data.getValue(AmpManagedOrder.introBrokerId);
   }

   @Override
   public String getOrderType() {
      return data.getValue(AmpManagedOrder.orderType);
   }

   @Override
   public boolean canRenew() {
      return isManaged() && (getStatus() == PRIVATE_ORDER);
   }

   @Override
   public boolean canWithdraw() {
      int status = getStatus();

      return isManaged() && (
         status == OPEN ||
            status == INACTIVE_STOP ||
            status ==  UNPLACED ||
            status == UNPLACED_STOP ||
            status ==  UNAPPROVED ||
            status == UNCONFIRMED ||
            status == EMBARGOED||
            status ==  CONDIRMED||
            status ==  PENDING ||
            status == CLEARING_QUEUED ||
            status == PRIVATE_ORDER);
   }

   @Override
   public boolean isManaged() {
      return data.getAsn(AmpManagedOrder.managedOrderId) != null;
   }

   @Override
   public int compareTo(ManagedOrder managedOrder) {
      // Using object's equal
      return getData().compareTo(managedOrder.getData());
   }

   @Override
   public String toString() {
      return "ManagedOrder{" +
         "data=" + data +
         '}';
   }

   private final QueryReplyRow data;
   private final NumberFormat nf = NumberFormat.getNumberInstance();
}
