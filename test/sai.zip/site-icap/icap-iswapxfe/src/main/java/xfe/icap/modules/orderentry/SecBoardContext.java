package xfe.icap.modules.orderentry;

import com.google.common.base.Strings;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.nomx.persist.watchlist.WatchlistSpec_v2.Security;
import com.omxgroup.xstream.amp.AmpSecClassId;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.binding.NumberBinding;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.*;
import javafx.beans.value.ObservableNumberValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpRfq;
import xfe.icap.amp.Util;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.securities.SecurityWatchlist;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.watchlist.InstrumentsFilters;
import xfe.types.SecBoard;
import xfe.types.SecBoardStaticInfo;
import xfe.types.SecBoards;
import xfe.types.StepArray;
import xstr.session.ObservableReplyRow;
import xstr.session.ServerSession;
import xstr.util.Fun1;
import xstr.util.Fx;
import xstr.util.Lazy;
import xstr.util.Tuple;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SecBoardContext {
   private static final Logger logger = LoggerFactory.getLogger(SecBoardContext.class);
   private static final int DEFAULT_PRICE_DECIMALS = 4;
   private static final int DEFAULT_QTY_DECIMALS = 0;

   private static final StepArray DEFAULT_PRICE_SPIN_STEPS = new StepArray() {{
      addStep(0.0, 0.0005);
   }};

   private static final StepArray DEFAULT_QTY_SPIN_STEPS = new StepArray() {{
      addStep(0.0, 25.0);
   }};

   private static final StepArray DEFAULT_PRICE_STEPS = new StepArray() {{
      addStep(0.0, 0.00005);
   }};

   private static final StepArray DEFAULT_QTY_STEPS = new StepArray() {{
      addStep(0.0, 1.0);
   }};

   private final DoubleProperty defaultOutrightQty = new SimpleDoubleProperty(50.0);
   private final DoubleProperty defaultStrategyQty = new SimpleDoubleProperty(50.0);
   private final BooleanProperty marketSize = new SimpleBooleanProperty(false);

   private final ReadOnlyObjectWrapper<Integer> secClassId = new ReadOnlyObjectWrapper<>();
   private final BooleanProperty isStrategyProperty = new SimpleBooleanProperty(this, "isStrategyProperty", false);
   final BooleanProperty isStrategyPropertyRO = isStrategyProperty;
   private final ReadOnlyObjectWrapper<String> secCode = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<String> parentSecCode = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<String> parentBoardId = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> bestBid = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> bestOffer = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> b_nPrice = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> o_nPrice = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> b_nQty = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> o_nQty = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> bidSize = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<Double> offerSize = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<String> sessionName = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<BigDecimal> workupPrice = new ReadOnlyObjectWrapper<>();
   private final ReadOnlyObjectWrapper<StepArray> spinPriceSteps = new ReadOnlyObjectWrapper<>(DEFAULT_PRICE_SPIN_STEPS);
   private final ReadOnlyObjectWrapper<StepArray> spinQtySteps = new ReadOnlyObjectWrapper<>(DEFAULT_QTY_SPIN_STEPS);
   private final ReadOnlyObjectWrapper<StepArray> priceSteps = new ReadOnlyObjectWrapper<>(DEFAULT_PRICE_STEPS);
   private final ReadOnlyObjectWrapper<StepArray> qtySteps = new ReadOnlyObjectWrapper<>(DEFAULT_QTY_STEPS);
   private final ReadOnlyIntegerWrapper priceDecimals = new ReadOnlyIntegerWrapper(DEFAULT_PRICE_DECIMALS);
   private final ReadOnlyIntegerWrapper qtyDecimals = new ReadOnlyIntegerWrapper(DEFAULT_QTY_DECIMALS);


   private final ReadOnlyBooleanWrapper bidIsIndicative = new ReadOnlyBooleanWrapper(false);
   private final ReadOnlyBooleanWrapper offerIsIndicative = new ReadOnlyBooleanWrapper(false);

   private final ObjectProperty<Double> defaultQty = new SimpleObjectProperty<>();
   private final NumberBinding defaultQtyBinding = new DoubleBinding() {
      {
         bind(secClassId, defaultOutrightQty, defaultStrategyQty, marketSize, defaultQty);
      }
      @Override
      protected double computeValue() {
         return calculateDefaultQty();
      }
   };

   private double calculateDefaultQty() {
      if(marketSize.get() && defaultQty.get() != null)
         return defaultQty.get();

      if(secClassId.get() != null && secClassId.get() == AmpSecClassId.strategy)
         return defaultStrategyQty.get();

      return defaultOutrightQty.get();
   }

   private final ReadOnlyObjectWrapper<ObservableReplyRow> row = new ReadOnlyObjectWrapper<>();
   private final ObjectProperty<SelectionContext> selectionContext = new SimpleObjectProperty<>();

   private final SecurityWatchlist activeSecboard;

   public SecBoardContext(SecuritiesDataModule securitiesDataModule, ServerSession session) {
      this.securitiesDataModule = securitiesDataModule;
      isStrategyProperty.bind(Bindings.when(Bindings.equal(AmpSecClassId.strategy, secClassIdProperty())).then(true).otherwise(false));
      activeSecboard = securitiesDataModule.createWatchlist(SecBoardContext.class.getName());

      selectionContext.addListener((obsVal, oldVal, newVal) -> {
         activeSecboard.setSpec(new WatchlistSpec_v2());
         if (newVal == null || newVal == SelectionContextModule.NULL_CONTEXT) {
            clear();
            return;
         }

         if (newVal.row == null) {
            return;
         }

         switch (newVal.grid) {
            case Watchlist:
               setRow(newVal.row);
               break;
            case Rfq:
               // for rfq, if it is expired, the newVal.row can be null
               requestActiveSecboard(
                  securitiesDataModule.getSecboards(),
                  newVal.row.getValue(AmpRfq.secCode),
                  newVal.row.getValue(AmpRfq.boardId));
               break;
            case Orders:
               requestActiveSecboard(
                  securitiesDataModule.getSecboards(),
                  newVal.row.getValue(AmpManagedOrder.secCode),
                  newVal.row.getValue(AmpManagedOrder.boardId));
               break;
            case OBBO_BUY:
            case OBBO_SELL:
               requestActiveSecboard(
                  securitiesDataModule.getSecboards(),
                  Util.getSecCodeFromObboReplyRow(newVal.row),
                  Util.getBoardIdFromObboReplyRow(newVal.row));
               break;
            default:
               clear();
         }
      });

      activeSecboard.getItems().addListener((ListChangeListener<ObservableReplyRow>) change -> {
         while (change.next()) {
            if (change.wasAdded() && change.getList().size() == 1) {
               setRow(change.getList().get(0));
            }
         }
      });
   }

   private void clear() {
      secClassId.set(null);
      secCode.set(null);
      parentSecCode.set(null);
      parentBoardId.set(null);
      bestBid.unbind();
      bestBid.set(null);
      bestOffer.unbind();
      bestOffer.set(null);
      b_nPrice.unbind();
      b_nPrice.set(null);
      o_nPrice.unbind();
      o_nPrice.set(null);
      b_nQty.unbind();
      b_nQty.set(null);
      o_nQty.unbind();
      o_nQty.set(null);
      bidSize.unbind();
      bidSize.set(null);
      offerSize.unbind();
      offerSize.set(null);
      sessionName.unbind();
      sessionName.set(null);
      workupPrice.unbind();
      workupPrice.set(null);
      bidIsIndicative.unbind();
      bidIsIndicative.set(false);
      offerIsIndicative.unbind();
      offerIsIndicative.set(false);
      if (row.get() == null) {
         priceDecimals.set(DEFAULT_PRICE_DECIMALS);
         qtyDecimals.set(DEFAULT_QTY_DECIMALS);
         spinPriceSteps.set(DEFAULT_PRICE_SPIN_STEPS);
         spinQtySteps.set(DEFAULT_QTY_SPIN_STEPS);
         qtySteps.set(DEFAULT_QTY_SPIN_STEPS);
      }

      isStrategyProperty.unbind();
   }

   private void requestActiveSecboard(SecBoards secBoards, String secCode, String boardId) {
      List<Security> secs = new ArrayList<>();
      secs.add(new Security(null, secCode));
      activeSecboard.setSpec(new WatchlistSpec_v2().withSecurities(secs));
   }

   private void updateStepArrays(ObservableReplyRow secBoardRow) {
      SecBoardStaticInfo info = securitiesDataModule.getStaticInfo(secBoardRow);
      if (info != null) {
         spinPriceSteps.set(info.priceContext.getSpinStepArray());
         spinQtySteps.set(info.qtyContext.getSpinStepArray());
         priceSteps.set(info.priceContext.getStepArray());
         qtySteps.set(info.qtyContext.getStepArray());
         priceDecimals.set(info.priceContext.getDecimals());
         qtyDecimals.set(info.qtyContext.getDecimals());
         parentSecCode.set(info.parentSecCode);
         parentBoardId.set(info.parentBoardId);
      }
   }

   private void setRow(ObservableReplyRow secBoardRow) {
      logger.debug("select row is {}",secBoardRow);
      Double defaultQuantity = secBoardRow.getProperty(AmpIcapSecBoardTrim2.defaultQty_d).getValue();
      if (marketSize.get() && defaultQuantity != null)
         defaultQty.set(defaultQuantity);
      else
         defaultQty.set(null);

      row.set(secBoardRow);

      secClassId.set(secBoardRow.getValue(AmpIcapSecBoardTrim2.secClassId));
      secCode.set(secBoardRow.getValue(AmpIcapSecBoardTrim2.secCode));
      bestBid.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.bidPrice_d));
      bestOffer.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.offerPrice_d));
      b_nPrice.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d));
      o_nPrice.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d));
      b_nQty.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.nLevelImpBidQuantity));
      o_nQty.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.nLevelImpOfferQuantity));
      bidSize.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.bidDepth_d));
      offerSize.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.offerDepth_d));
      sessionName.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.sessionName));
      workupPrice.bind(secBoardRow.getProperty(AmpIcapSecBoardTrim2.workupPrice));
      bidIsIndicative.bind(InstrumentsFilters.isIndicativeBid.call(secBoardRow));
      offerIsIndicative.bind(InstrumentsFilters.isIndicativeOffer.call(secBoardRow));

      updateStepArrays(secBoardRow);
   }

   public ObjectProperty<SelectionContext> selectionContextProperty() {
      return selectionContext;
   }

   ReadOnlyBooleanProperty bidIsIndicativeProperty() {
      return bidIsIndicative.getReadOnlyProperty();
   }

   boolean bidIsIndicative() {
      return bidIsIndicative.get();
   }

   ReadOnlyBooleanProperty offerIsIndicativeProperty() {
      return offerIsIndicative.getReadOnlyProperty();
   }

   boolean offerIsIndicative() {
      return offerIsIndicative.get();
   }

   ReadOnlyObjectProperty<Double> bestBidProperty() {
      return bestBid.getReadOnlyProperty();
   }

   Double getBestBid() {
      return bestBid.get();
   }

   private ReadOnlyObjectProperty<Integer> secClassIdProperty() {
      return secClassId.getReadOnlyProperty();
   }

   public Integer getSecClassId() {
      return secClassId.get();
   }

   ReadOnlyObjectProperty<Double> bestOfferProperty() {
      return bestOffer.getReadOnlyProperty();
   }

   Double getBestOffer() {
      return bestOffer.get();
   }

   ReadOnlyObjectProperty<Double> b_nPriceProperty() {
      return b_nPrice.getReadOnlyProperty();
   }

   public Double getB_nPrice() {
      return b_nPrice.get();
   }

   ReadOnlyObjectProperty<Double> o_nPriceProperty() {
      return o_nPrice.getReadOnlyProperty();
   }

   public Double getO_nPrice() {
      return o_nPrice.get();
   }

   ReadOnlyObjectProperty<Double> b_nQtyProperty() {
      return b_nQty.getReadOnlyProperty();
   }

   public Double getB_nQty() {
      return b_nQty.get();
   }

   ReadOnlyObjectProperty<Double> o_nQtyProperty() {
      return o_nQty.getReadOnlyProperty();
   }

   public Double getO_nQty() {
      return o_nQty.get();
   }

   ReadOnlyObjectProperty<Double> bidSizeProperty() {
      return bidSize.getReadOnlyProperty();
   }

   public Double getBidSize() {
      return bidSize.get();
   }

   ReadOnlyObjectProperty<Double> offerSizeProperty() {
      return offerSize.getReadOnlyProperty();
   }

   public Double getOfferSize() {
      return offerSize.get();
   }

   public ReadOnlyObjectProperty<String> sessionNameProperty() {
      return sessionName.getReadOnlyProperty();
   }

   public String getSessionName() {
      return sessionName.get();
   }

   public ReadOnlyObjectProperty<BigDecimal> workupPriceProperty() {
      return workupPrice.getReadOnlyProperty();
   }

   public BigDecimal getWorkupPrice() {
      return workupPrice.get();
   }

   ReadOnlyObjectProperty<ObservableReplyRow> rowProperty() {
      return row.getReadOnlyProperty();
   }

   public ObservableReplyRow getRow() {
      return row.get();
   }

   ObservableNumberValue defaultQtyProperty() {
      return defaultQtyBinding;
   }

   double getDefaultQty() {
      return defaultQtyBinding.doubleValue();
   }

   DoubleProperty defaultStrategyQtyProperty() {
      return defaultStrategyQty;
   }

   public void setDefaultStrategyQty(double qty) {
      defaultStrategyQty.set(qty);
   }

   BooleanProperty marketSizePorperty(){
      return marketSize;
   }
   DoubleProperty defaultOutrightQtyProperty() {
      return defaultOutrightQty;
   }

   ReadOnlyIntegerProperty priceDecimalsProperty() {
      return priceDecimals.getReadOnlyProperty();
   }

   public double getPriceDecimals() {
      return priceDecimals.get();
   }

   ReadOnlyIntegerProperty spinQtyDecimalsProperty() {
      return qtyDecimals.getReadOnlyProperty();
   }

   public double getSpinQtyDecimals() {
      return qtyDecimals.get();
   }

   ReadOnlyObjectProperty<StepArray> spinPriceStepsProperty() {
      return spinPriceSteps.getReadOnlyProperty();
   }

   public StepArray getSpinPriceSteps() {
      return spinPriceSteps.get();
   }

   public ReadOnlyObjectProperty<StepArray> spinQtyStepsProperty() {
      return spinQtySteps.getReadOnlyProperty();
   }

   public StepArray getSpinQtySteps() {
      return spinQtySteps.get();
   }

   public ReadOnlyObjectProperty<StepArray> qtyStepsProperty() {
      return qtySteps.getReadOnlyProperty();
   }

   public StepArray getQtySteps() {
      return qtySteps.get();
   }

   //   private final ReadOnlyObjectWrapper<StepArray> priceSteps = new ReadOnlyObjectWrapper<StepArray>(DEFAULT_PRICE_STEPS);
   //   private final ReadOnlyObjectWrapper<StepArray> qtySteps = new ReadOnlyObjectWrapper<StepArray>(DEFAULT_QTY_STEPS);

   public String getSecCode() {
      if (row.get() == null) {
         return "";
      }

      return (row.get().getRow()).getValue(AmpIcapSecBoardTrim2.secCode);
   }

   public String getParentSecCode(){
      if (row.get() == null) {
         return null;
      } else {
         return parentSecCode.get();
      }
   }

   public String getParentBoardId(){
      if (row.get() == null) {
         return null;
      } else {
         return parentBoardId.get();
      }
   }

   public String getBoardId() {
      if (row.get() == null) {
         return "";
      }

      return row.get().getValue(AmpIcapSecBoardTrim2.boardId);
   }

   Lazy<ObservableValue<SecBoard>> liveSecBoard = new Lazy<ObservableValue<SecBoard>>() {
      @Override
      protected ObjectBinding<SecBoard> initialize() {
         return new ObjectBinding<SecBoard>() {
            {
               bind(row, securitiesDataModule.getSecboards().getSecBoardsByKey());
            }

            @Override
            protected SecBoard computeValue() {
               String secCode = getSecCode();
               String boardId = getBoardId();
               if(!Strings.isNullOrEmpty(secCode)){
                  logger.debug("secboard context is set to {}:{}",secCode, boardId);
               }
               return securitiesDataModule.getSecboards().getSecBoardsByKey().get(Tuple.of(secCode, boardId));
            }
         };
      }
   };

   @Override
   public String toString() {
      return "secCode:"+secCode.get()+" boardId:"+getBoardId();
   }

   private SecuritiesDataModule securitiesDataModule;
}
