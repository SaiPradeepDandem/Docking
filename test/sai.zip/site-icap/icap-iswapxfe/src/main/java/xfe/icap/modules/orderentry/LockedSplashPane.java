package xfe.icap.modules.orderentry;

import javafx.beans.binding.Bindings;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import xstr.session.Credentials;
import xstr.util.ListenerTracker;
import xfe.util.scene.control.PropertyValidator;
import xfe.ui.logon.UnlockView;

import java.util.Arrays;
import java.util.function.Consumer;

class LockedSplashPane implements UnlockView<Pane> {

   LockedSplashPane() {
      passwordEdit.setFocusTraversable(true);
   }

   @Override
   public Pane getRootElement() {
      if (rootNode == null) {
         rootNode = new StackPane();
         tracker = new ListenerTracker();
         rootNode.getStyleClass().add("xfe-modal-pane");
         GridPane node = new GridPane();
         node.getStyleClass().add("xfe-locked-pane");

         PropertyValidator.applyRegex(passwordEdit.textProperty(),
            Credentials.PASSWD_FORMAT);
         passwordEdit.setPromptText("Enter password");

         Runnable unlockRunner = () -> {
            if (unlockHandler != null) {
               char[] pwd = getPassword();
               unlockHandler.accept(pwd);
               Arrays.fill(pwd, '\u0000');
            }
         };
         passwordEdit.setOnAction(event -> unlockRunner.run());
         node.setFocusTraversable(true);
         node.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            switch(event.getCode()) {
               case ESCAPE:
                  break;
               default: return;
            }
            event.consume();
         });

         Label passwordLabel = new Label("Password:");
         Button acceptButton = new Button("");
         acceptButton.setDisable(true);
         acceptButton.getStyleClass().add("xfe-action-unlock-button");
         passwordEdit.textProperty().addListener((o, oldVal, newVal) -> {
            if (newVal != null && newVal.length() >= 1) {
               acceptButton.setDisable(false);
            } else {
               acceptButton.setDisable(true);
            }
         });
         acceptButton.setOnAction(ev -> unlockRunner.run());
         tracker.registerRollbackAction(() -> {
            passwordEdit.setOnAction(null);
            acceptButton.setOnAction(null);
         });

         Label lockedBanner = new Label("Locked");
         lockedBanner.getStyleClass().add("xfe-title");

         GridPane.setConstraints(lockedBanner, 0,0,3,1, HPos.CENTER, VPos.CENTER);
         GridPane.setConstraints(passwordLabel, 0,1,1,1, HPos.RIGHT, VPos.CENTER);
         GridPane.setConstraints(passwordEdit, 1,1,1,1, HPos.RIGHT, VPos.CENTER);
         GridPane.setConstraints(acceptButton, 2,1,1,1, HPos.LEFT, VPos.CENTER);
         node.getChildren().addAll(lockedBanner, passwordLabel, passwordEdit, acceptButton);
         node.setMaxWidth(Region.USE_PREF_SIZE);
         node.maxHeightProperty().bind(Bindings.add(lockedBanner.prefHeightProperty(),
            Bindings.max(Bindings.max(passwordLabel.prefHeightProperty(), passwordEdit.prefHeightProperty()), acceptButton.prefHeightProperty())));

         rootNode.getChildren().add(node);
      }
      return rootNode;
   }

   @Override
   public char[] getPassword() {
      return passwordEdit.getText().toCharArray();
   }

   @Override
   public void requestFocus() {
      passwordEdit.setText("");
      passwordEdit.requestFocus();
   }

   @Override
   public void setUnlockHandler(Consumer<char[]> handler) {
      this.unlockHandler = handler;
   }

   public void dispose(){
      tracker.rollback();
      tracker=null;
   }

   private final TextField passwordEdit = new PasswordField() ;
   private Pane rootNode;
   private ListenerTracker tracker;
   private Consumer<char[]> unlockHandler;
}
