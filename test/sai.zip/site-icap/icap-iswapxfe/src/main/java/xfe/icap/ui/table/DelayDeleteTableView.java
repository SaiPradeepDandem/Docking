package xfe.icap.ui.table;

import xstr.session.XtrRow;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.scene.control.TableView;

import java.util.*;

/**
 * Created by jiadin on 10/05/2016.
 */
public class DelayDeleteTableView<T extends XtrRow> extends TableView {
   private final FeedAggregator<T> aggregator;
   private final ObservableSet<T> delayDeleteItems = FXCollections.observableSet(new HashSet<T>(64));
   private final ObservableList<T> tableviewItems;
   private final Map<T, long[]> pendingDeleteList = new HashMap<>(1024);
   private final Timeline tl;

   public DelayDeleteTableView(FeedAggregator<T> aggregator, Comparator<T> comparator, long deplay) {
      this.aggregator = aggregator;
      tableviewItems = Fx.sortBy(delayDeleteItems, comparator);
      aggregator.items.addListener(new ListChangeListener<T>() {
         @Override
         public void onChanged(Change<? extends T> c) {
            if (!aggregator.busyProperty().get()) {
               while (c.next()) {
                  if (c.wasAdded()) {
                     for (T row : c.getAddedSubList()) {
                        if (pendingDeleteList.containsKey(row)) {
                           pendingDeleteList.remove(row);
                        }
                        delayDeleteItems.add(row);
                     }
                  }
                  if (c.wasRemoved()) {
                     for (T row : c.getRemoved()) {
                        pendingDeleteList.put(row, new long[]{deplay});
                     }
                  }
               }
            }
         }
      });

      tl = Fx.runPeriodically(1000D, new Runnable() {
         @Override
         public void run() {
            Set<T> keys = pendingDeleteList.keySet();
            for (T aKey : keys) {
               long[] exp = pendingDeleteList.get(aKey);
               if (exp[0] <= 1000) {
                  if(!aKey.equals(DelayDeleteTableView.this.getSelectionModel().getSelectedItem())) {
                     pendingDeleteList.remove(aKey);
                     delayDeleteItems.remove(aKey);
                  }
               } else {
                  exp[0] = exp[0] - 1000;
               }
            }
         }
      });
   }

   public void dispose() {
      tl.stop();
   }


//   public static void main(String[] args) {
//      final FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpGroupUser.rep , new ObservableReplyRow.ObservableRowFactory());
//      DelayDeleteTableView d = new DelayDeleteTableView(aggregator);
//   }

}
