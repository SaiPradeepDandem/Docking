package xfe.icap.modules.watchlist;

import com.nomx.domain.types.InstrumentKey;
import com.nomx.domain.types.InstrumentsFilter;
import com.nomx.persist.PersistantName;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Callback;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpRfq;
import xfe.icap.amp.AmpSecBoardTradeInfo;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.icap.modules.actionsui.ConfigActionsUIModule;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.rfq.RfqTableView;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settings.SettingsData;
import xfe.layout.LayoutManager;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.modules.watchlist.InstrumentsView;
import xfe.types.SecBoard;
import xfe.types.Security;
import xfe.types.Watchlist;
import xfe.ui.KeyEventFilter;
import xfe.ui.TabPaneSelector;
import xfe.ui.TabSelector;
import xfe.ui.TriStateButton;
import xfe.ui.TriStateButton.State;
import xfe.ui.splitpane.XfeSplitComponent;
import xfe.ui.table.RowSelector;
import xfe.ui.tabpane.XfeTabPane;
import xfe.util.*;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.session.XtrKey;
import xstr.types.OrderSide;
import xstr.util.*;
import xstr.util.concurrent.*;
import xstr.util.filter.RowFilters;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class InstrumentsPane extends DisposableBase implements InstrumentsView,Constants {
   private static final Logger logger = LoggerFactory.getLogger(InstrumentsPane.class);
   public final SelectionContextModule selectionContextModule;
   public static final double ROW_HEIGHT = 15;

   private class InstrumentsTableView2 extends TableViewHeaderUnmovable<ObservableReplyRow> {
      InstrumentsTableView2(boolean forPopup,
                            boolean forPriceTightness,
                            Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>> rowFactory,
                            ListenerTracker listenerTracker) {

         if (forPopup) {
            getStyleClass().addAll("xfe-has-bid-offer-color");
         } else {
            getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
         }

         if (forPriceTightness) {
            setRowFactory(rowFactory);
         }
         else {
            setRowFactory(new Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>>() {
               @Override
               public TableRow<ObservableReplyRow> call(TableView<ObservableReplyRow> param) {
                  HighLightTableRow row = new HighLightTableRow(columns, activeSpec) {
                     {
                        _this = this;
                     }

                     @Override
                     protected void updateItem(ObservableReplyRow item, boolean empty) {
                        super.updateItem(item, empty);
                        tradesFlashModule.blinkNeutralToOffProp.removeListener(tradePropLis);
                        columns.settingsData.strategyPriceTight().removeListener(ptListener);
                        columns.settingsData.outrightPriceTight().removeListener(ptListener);

                        if (item == null || empty) {
                           List<String> styles = getStyleClass();
                           styles.remove(INSTRUMENT_FULL_HIGHTLIGHT);
                           styles.remove(INSTRUMENT_HALF_HIGHTLIGHT);
                           styles.remove(PRICE_TIGHTNESS_STYLE);
                           styles.remove(PRIVATE_WORKUP_STYLE);
                           styles.remove(PUBLIC_WORKUP_STYLE);
                           styles.remove(FLASH_NEUTRAL);
                           styles.remove(FLASH_BUY);
                           styles.remove(FLASH_SELL);
                        } else {
                           tradesFlashModule.blinkNeutralToOffProp.addListener(tradePropLis);
                           columns.settingsData.strategyPriceTight().addListener(ptListener);
                           columns.settingsData.outrightPriceTight().addListener(ptListener);
                           // decide the highlight state
                           boolean isPriceTightness = columns.isPriceTight(item, priceTightnessPropertyRO);
                           turnOnStyle(isPriceTightness, PRICE_TIGHTNESS_STYLE);

//                        boolean isPriceTightnessHivis = columns.isPriceTight(item, priceTightnessPropertyRO);
//                        turnOnStyle(isPriceTightnessHivis,PRICE_HIVIS_TIGHTNESS_STYLE);

                           turnOnStyle(AmpIcapSecBoardTrim2.sessionName, "Private", PRIVATE_WORKUP_STYLE);
                           turnOnStyle(AmpIcapSecBoardTrim2.sessionName, "Public", PUBLIC_WORKUP_STYLE);

                           //turnOnStyle(item.getCustomPropertyValue(PT_DELETE_TIME) != null, "faded");
                        }
                     }
                     private final HighLightTableRow _this;
                     private final InvalidationListener ptListener = (new InvalidationListener() {
                        @Override
                        public void invalidated(Observable observable) {
                           ObservableReplyRow row = _this.getRowData();
                           if (row == null) {
                              List<String> styles = getStyleClass();
                              styles.remove(PRICE_TIGHTNESS_STYLE);
                           } else {
                              boolean isPriceTightness = columns.isPriceTight(row, priceTightnessPropertyRO);
                              turnOnStyle(isPriceTightness, PRICE_TIGHTNESS_STYLE);
                           }
                        }
                     });
                     private final InvalidationListener tradePropLis = new TradeFlashPropInvalidationListener(this.getStyleClass(),Fx.valueOf(true)){
                        @Override
                        protected boolean isNeedUpdateStyle(TradeBlinkObservableObject tradeBlinkObservableObject) {
                           ObservableReplyRow row = _this.getItem();
                           if (row == null) return false;
                           String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
                           String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
                           return tradeBlinkObservableObject.getSecCode().equals(secCode) &&
                              tradeBlinkObservableObject.getBoardId().equals(boardId) &&
                              super.isNeedUpdateStyle(tradeBlinkObservableObject);
                        }
                     };
                  };

                  return row;
               }
               @Override
               public String toString() { return "InstrumentsTableView RowFactory@" + Objects.hashCode(this); }
            });
         }


         WeakHashMap<XtrKey, List<Duration>> lastTradeTimesByKey = new WeakHashMap<>();

         instrColumn = columns.createInstrumentColumn(
            interrogationActionProperty,
            new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
               @Override
               public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
                  WatchlistInfoPopup infoPopup = new WatchlistInfoPopup(
                     cell, session, selectionContextModule, row, settingsData, filters, showingInfoPopups, columns);

                  layoutManager.register(infoPopup, null);
                  infoPopup.show(cell.getScene().getWindow());
               }
            });
         TableColumn<ObservableReplyRow, String> bidTypeCol = columns.createTypeCol(true, false);
         TableColumn<ObservableReplyRow, String> bidOrImpliedTypeCol = columns.createTypeCol(true, true);
         TableColumn<ObservableReplyRow, String> bidTotalCol = columns.createTotalColumn(true, false);
         TableColumn<ObservableReplyRow, String> bidOrImpliedTotalCol = columns.createTotalColumn(true, true);
         TableColumn<ObservableReplyRow, String> bnCol = columns.createImpliedColumn(interrogationActionProperty, true, showingInfoPopups, session.secBoards.get().getSecBoardsByKey());
         TableColumn<ObservableReplyRow, String> payFirmCol = columns.createFirmColumn(true, session);
         TableColumn<ObservableReplyRow, String> priceTightnessCol = columns.createPriceTightnessColumn();
         TableColumn<ObservableReplyRow, String> bidPriceCol = columns.createPriceOrImpliedColumn(interrogationActionProperty, true, showingInfoPopups, false, session.secBoards.get().getSecBoardsByKey());
         TableColumn<ObservableReplyRow, String> bidOrImpliedPriceCol = columns.createPriceOrImpliedColumn(interrogationActionProperty, true, showingInfoPopups, true, session.secBoards.get().getSecBoardsByKey());
         TableColumn<ObservableReplyRow, String> bidOfferSepCol = columns.createBidOfferSeparatorColumn();
         TableColumn<ObservableReplyRow, String> offerPriceCol = columns.createPriceOrImpliedColumn(interrogationActionProperty, false, showingInfoPopups, false, session.secBoards.get().getSecBoardsByKey());
         TableColumn<ObservableReplyRow, String> offerOrImpliedPriceCol = columns.createPriceOrImpliedColumn(interrogationActionProperty, false, showingInfoPopups, true, session.secBoards.get().getSecBoardsByKey());
         TableColumn<ObservableReplyRow, String> onCol = columns.createImpliedColumn(interrogationActionProperty, false, showingInfoPopups, session.secBoards.get().getSecBoardsByKey());
         TableColumn<ObservableReplyRow, String> recFirmCol = columns.createFirmColumn(false, session);
         TableColumn<ObservableReplyRow, String> offerTotalCol = columns.createTotalColumn(false, false);
         TableColumn<ObservableReplyRow, String> offerOrImpliedTotalCol = columns.createTotalColumn(false, true);
         TableColumn<ObservableReplyRow, String> offerTypeCol = columns.createTypeCol(false, false);
         TableColumn<ObservableReplyRow, String> offerOrImpliedTypeCol = columns.createTypeCol(false, true);
         TableColumn<ObservableReplyRow, String> lastPriceCol = columns.createLastPriceColumn(forPopup, session.secBoards.get().getSecBoardsByKey());
         TableColumn<ObservableReplyRow, String> lastAmountCol = columns.createLastQuantityColumn();
         TableColumn<ObservableReplyRow, XfeAction> referCol = columns.createReferColumn();

         boolean isBroker = session.getUnderlyingSession().isLoggedOnUserBroker();

         InvalidationListener columnSwitchListener = arg0 -> {
            List<TableColumn<ObservableReplyRow, ?>> columns1 = getColumns();
            columns1.clear();
            columnContext.clear();

            boolean isPriceMerged = isBroker || forPriceTightness || settingsData.mergeImpliedMainWatchlistProperty().get();
            double scale4MergedL = !isBroker && isPriceMerged ? GetScalingFactor(true, forPriceTightness) : 1;
            double scale4MergedR = !isBroker && isPriceMerged ? GetScalingFactor(false, forPriceTightness) : 1;
            double scale4PriceTightness = forPriceTightness ? GetPriceTightnessFactor() : 1;
            scale4MergedL *= scale4PriceTightness;
            scale4MergedR *= scale4PriceTightness;


            columns1.add(instrColumn);
            instrColumn.setPrefWidth(COLUMN_SECCODE_SIZE * scale * scale4MergedL);
            columnContext.put(instrColumn, AmpIcapSecBoardTrim2.secCode);

            if (settingsData.bidOnLeftProperty().get()) {
               if (isPriceMerged) {
                  columns1.add(bidOrImpliedTypeCol);
                  columnContext.put(bidOrImpliedTypeCol, AmpIcapSecBoardTrim2.bidSpecialOrderType);
                  bidOrImpliedTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedL);
               } else {
                  columns1.add(bidTypeCol);
                  columnContext.put(bidTypeCol, AmpIcapSecBoardTrim2.bidSpecialOrderType);
                  bidTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedL);
               }
               if (isPriceMerged) {
                  columns1.add(bidOrImpliedTotalCol);
                  columnContext.put(bidOrImpliedTotalCol, AmpIcapSecBoardTrim2.bidDepth);
                  bidOrImpliedTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedL);
               } else {
                  columns1.add(bidTotalCol);
                  columnContext.put(bidTotalCol, AmpIcapSecBoardTrim2.bidDepth);
                  bidTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedL);
               }

               if (isBroker) {
                  columns1.add(payFirmCol);
                  payFirmCol.setPrefWidth(COLUMN_FIRM_SIZE * scale * scale4MergedL);
                  columnContext.put(payFirmCol, AmpIcapSecBoardTrim2.bidUserId);
                  columns1.add(bidOrImpliedPriceCol);
                  columnContext.put(bidOrImpliedPriceCol, AmpIcapSecBoardTrim2.bidPrice_d);
                  bidOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
               } else {
                  if (isPriceMerged) {
                     columns1.add(bidOrImpliedPriceCol);
                     columnContext.put(bidOrImpliedPriceCol, AmpIcapSecBoardTrim2.bidPrice_d);
                     bidOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  } else {
                     columns1.add(bnCol);
                     columnContext.put(bnCol, AmpIcapSecBoardTrim2.nLevelImpBidPrice_d);
                     bnCol.setPrefWidth(COLUMN_IMPLIED_PRICE_SIZE * scale);
                     columns1.add(bidPriceCol);
                     columnContext.put(bidPriceCol, AmpIcapSecBoardTrim2.bidPrice_d);
                     bidPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  }
               }
               if (forPriceTightness) {
                  columns1.add(priceTightnessCol);
                  columnContext.put(priceTightnessCol, AmpIcapSecBoardTrim2.priceTightness);
                  priceTightnessCol.setPrefWidth(COLUMN_PRICE_TIGHTNESS_SIZE * scale * ((scale4MergedL + scale4MergedR) / 2));
               } else {
                  columns1.add(bidOfferSepCol);
               }

               if (isBroker) {
                  columns1.add(offerOrImpliedPriceCol);
                  columnContext.put(offerOrImpliedPriceCol, AmpIcapSecBoardTrim2.offerPrice_d);
                  offerOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  columns1.add(recFirmCol);
                  columnContext.put(recFirmCol, AmpIcapSecBoardTrim2.offerUserId);
                  recFirmCol.setPrefWidth(COLUMN_FIRM_SIZE * scale * scale4MergedR);
               } else {
                  if (isPriceMerged) {
                     columns1.add(offerOrImpliedPriceCol);
                     columnContext.put(offerOrImpliedPriceCol, AmpIcapSecBoardTrim2.offerPrice_d);
                     offerOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  } else {
                     columns1.add(offerPriceCol);
                     columnContext.put(offerPriceCol, AmpIcapSecBoardTrim2.offerPrice_d);
                     offerPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                     columns1.add(onCol);
                     columnContext.put(onCol, AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
                     onCol.setPrefWidth(COLUMN_IMPLIED_PRICE_SIZE * scale);
                  }
               }

               if (isPriceMerged) {
                  columns1.add(offerOrImpliedTotalCol);
                  columnContext.put(offerOrImpliedTotalCol, AmpIcapSecBoardTrim2.offerDepth);
                  offerOrImpliedTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedR);
               } else {
                  columns1.add(offerTotalCol);
                  columnContext.put(offerTotalCol, AmpIcapSecBoardTrim2.offerDepth);
                  offerTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedR);
               }

               if (isPriceMerged) {
                  columns1.add(offerOrImpliedTypeCol);
                  columnContext.put(offerOrImpliedTypeCol, AmpIcapSecBoardTrim2.offerSpecialOrderType);
                  offerOrImpliedTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedR);
               } else {
                  columns1.add(offerTypeCol);
                  columnContext.put(offerTypeCol, AmpIcapSecBoardTrim2.offerSpecialOrderType);
                  offerTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedR);
               }
            } else {
               if (isPriceMerged) {
                  columns1.add(offerOrImpliedTypeCol);
                  columnContext.put(offerOrImpliedTypeCol, AmpIcapSecBoardTrim2.offerSpecialOrderType);
                  offerOrImpliedTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedL);
               } else {
                  columns1.add(offerTypeCol);
                  columnContext.put(offerTypeCol, AmpIcapSecBoardTrim2.offerSpecialOrderType);
                  offerTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedL);
               }

               if (isPriceMerged) {
                  columns1.add(offerOrImpliedTotalCol);
                  columnContext.put(offerOrImpliedTotalCol, AmpIcapSecBoardTrim2.offerDepth);
                  offerOrImpliedTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedL);
               } else {
                  columns1.add(offerTotalCol);
                  columnContext.put(offerTotalCol, AmpIcapSecBoardTrim2.offerDepth);
                  offerTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedL);
               }

               if (isBroker) {
                  columns1.add(recFirmCol);
                  columnContext.put(recFirmCol, AmpIcapSecBoardTrim2.offerUserId);
                  recFirmCol.setPrefWidth(COLUMN_FIRM_SIZE * scale * scale4MergedL);
                  columns1.add(offerOrImpliedPriceCol);
                  columnContext.put(offerOrImpliedPriceCol, AmpIcapSecBoardTrim2.offerPrice_d);
                  offerOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
               } else {
                  if (isPriceMerged) {
                     columns1.add(offerOrImpliedPriceCol);
                     columnContext.put(offerOrImpliedPriceCol, AmpIcapSecBoardTrim2.offerPrice_d);
                     offerOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  } else {
                     columns1.add(onCol);
                     columnContext.put(onCol, AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
                     onCol.setPrefWidth(COLUMN_IMPLIED_PRICE_SIZE * scale);
                     columns1.add(offerPriceCol);
                     columnContext.put(offerPriceCol, AmpIcapSecBoardTrim2.offerPrice_d);
                     offerPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  }
               }

               if (forPriceTightness) {
                  columns1.add(priceTightnessCol);
                  columnContext.put(priceTightnessCol, AmpIcapSecBoardTrim2.priceTightness);
                  priceTightnessCol.setPrefWidth(COLUMN_PRICE_TIGHTNESS_SIZE * scale * ((scale4MergedL + scale4MergedR) / 2));
               } else {
                  columns1.add(bidOfferSepCol);
               }

               if (isBroker) {
                  columns1.add(bidOrImpliedPriceCol);
                  columnContext.put(bidOrImpliedPriceCol, AmpIcapSecBoardTrim2.bidPrice_d);
                  bidOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  columns1.add(payFirmCol);
                  columnContext.put(payFirmCol, AmpIcapSecBoardTrim2.bidUserId);
                  payFirmCol.setPrefWidth(COLUMN_FIRM_SIZE * scale * scale4MergedR);
               } else {
                  if (isPriceMerged) {
                     columns1.add(bidOrImpliedPriceCol);
                     columnContext.put(bidOrImpliedPriceCol, AmpIcapSecBoardTrim2.bidPrice_d);
                     bidOrImpliedPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                  } else {
                     columns1.add(bidPriceCol);
                     columnContext.put(bidPriceCol, AmpIcapSecBoardTrim2.bidPrice_d);
                     bidPriceCol.setPrefWidth(COLUMN_PRICE_SIZE * scale);
                     columns1.add(bnCol);
                     columnContext.put(bnCol, AmpIcapSecBoardTrim2.nLevelImpBidPrice_d);
                     bnCol.setPrefWidth(COLUMN_IMPLIED_PRICE_SIZE * scale);
                  }
               }

               if (isPriceMerged) {
                  columns1.add(bidOrImpliedTotalCol);
                  columnContext.put(bidOrImpliedTotalCol, AmpIcapSecBoardTrim2.bidDepth);
                  bidOrImpliedTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedR);
               } else {
                  columns1.add(bidTotalCol);
                  columnContext.put(bidTotalCol, AmpIcapSecBoardTrim2.bidDepth);
                  bidTotalCol.setPrefWidth(COLUMN_QUANTITY_SIZE * scale * scale4MergedR);
               }

               if (isPriceMerged) {
                  columns1.add(bidOrImpliedTypeCol);
                  columnContext.put(bidOrImpliedTypeCol, AmpIcapSecBoardTrim2.bidSpecialOrderType);
                  bidOrImpliedTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedR);
               } else {
                  columns1.add(bidTypeCol);
                  columnContext.put(bidTypeCol, AmpIcapSecBoardTrim2.bidSpecialOrderType);
                  bidTypeCol.setPrefWidth(COLUMN_TYPE_SIZE * scale * scale4MergedR);
               }
            }

            columns1.add(lastPriceCol);
            columnContext.put(lastPriceCol, AmpIcapSecBoardTrim2.lastPrice_d);
            lastPriceCol.setPrefWidth(COLUMN_LASTPRICE_SIZE * scale * scale4MergedR);

            columns1.add(lastAmountCol);
            columnContext.put(lastAmountCol, AmpIcapSecBoardTrim2.lastQuantity);

            double lastColumnSize = forPopup ? COLUMN_LASTAMT_SIZE + COLUMN_REFER_SIZE / 2 : COLUMN_LASTAMT_SIZE;
            lastAmountCol.setPrefWidth(lastColumnSize * scale * scale4MergedR);

            if (!forPopup) {
               columns1.add(referCol);
               referCol.setPrefWidth(COLUMN_REFER_SIZE * scale * scale4MergedR);
            }
         };

         if (listenerTracker != null) {
            listenerTracker.addListener(settingsData.mergeImpliedMainWatchlistProperty(), columnSwitchListener);
            listenerTracker.addListener(settingsData.bidOnLeftProperty(), columnSwitchListener);
         } else {
            tracker.addListener(settingsData.mergeImpliedMainWatchlistProperty(), columnSwitchListener);
            tracker.addListener(settingsData.bidOnLeftProperty(), columnSwitchListener);
         }

         columnSwitchListener.invalidated(null);

         this.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
         this.getSelectionModel().setCellSelectionEnabled(true);

         ListChangeListener<ObservableReplyRow> itemsChangeListener = change -> {
            HashMap<XtrKey, Long> oldNumTradesMap = new HashMap<>();

            while (change.next()) {
               // Detecting changes to the selected row
               if (change.wasAdded() && selectedRowIndex != null) {
                  if (selectedRowIndex >= change.getFrom() && selectedRowIndex < change.getTo()) {
                     setGridContext(new SelectionContext(GridType.Watchlist, change.getList().get(selectedRowIndex), gridContext.get().field, selectedRowIndex));

                  }
               }

               oldNumTradesMap.clear();

               for (QueryReplyRow row : change.getRemoved()) {
                  Long oldNumTrades = row.getValue(AmpIcapSecBoardTrim2.numTrades);
                  oldNumTradesMap.put(row.getKey(), oldNumTrades != null ? oldNumTrades : 0);
               }

               Duration now = now();

               for (QueryReplyRow row : change.getAddedSubList()) {
                  Long oldNumTrades = oldNumTradesMap.get(row.getKey());

                  if (oldNumTrades != null) {
                     Long newNumTrades = row.getValue(AmpIcapSecBoardTrim2.numTrades);

                     if (newNumTrades != null) {
                        if (newNumTrades.longValue() != oldNumTrades) {
                           getOrInit(lastTradeTimesByKey, row.getKey()).add(now);
                        }
                     }
                  }
               }
            }
         };

         HandlerCompositeUtils.attachStickyListener(this.itemsProperty(), itemsChangeListener);
      }
      final WeakHashMap<TableColumn<?, ?>, AsnAccessor> columnContext = new WeakHashMap<>();
      final TableColumn instrColumn;
   }

   private class WatchListPane extends VBox implements XfeSplitComponent {
      @Override
      public BooleanProperty expandProperty() {
         return TRUE;
      }

      @Override
      public BooleanProperty fullSizeProperty() {
         return FALSE;
      }

      @Override
      public BooleanProperty displayProperty() {
         return TRUE;
      }

      @Override
      public Node getNode() {
         return this;
      }

      @Override
      public DoubleProperty sizeProperty() {
         return settingsData.watchListHeightProperty();
      }
   }
   static final double COLUMN_SECCODE_SIZE = 147;
   static final double COLUMN_QUANTITY_SIZE = 40;
   static final double COLUMN_PRICE_SIZE = 59;
   private static final String DAILY_VOLUME_TAB_NAME = "Daily Volume";
   private static final double COLUMN_TYPE_SIZE = 38;
   private static final double COLUMN_PRICE_TIGHTNESS_SIZE = 65;
   private static final double COLUMN_IMPLIED_PRICE_SIZE = 59;
   private static final double COLUMN_FIRM_SIZE = 53;
   private static final double COLUMN_LASTPRICE_SIZE = 57;
   private static final double COLUMN_LASTAMT_SIZE = 53;
   private static final double COLUMN_REFER_SIZE = 25;
   private static final double totalAvailWidth = FxApplicationModule.MAIN_STAGE_WIDTH - 12 - 3; //scrollbar and special separator column
   private static final double scale = totalAvailWidth / (totalAvailWidth); /*for demo, the two type column is removed*/
   private static final String VIEW_ID = "IP";
   private static volatile boolean internalSpecUpdate;

   public static Duration now() {
      return new Duration(System.nanoTime() / 1000000);
   }

   private static <T> List<T> getOrInit(WeakHashMap<XtrKey, List<T>> multimap, XtrKey rowKey) {
      List<T> list = multimap.get(rowKey);

      if (list != null) {
         return list;
      }

      List<T> newList = new ArrayList<>();

      multimap.put(rowKey, newList);

      return newList;
   }

   InstrumentsPane(
      DeadlineScheduler scheduler,
      ObservableList<ObservableReplyRow> tradeInfos,
      SelectionContextModule selectionContextModule,
      DataContextModule dataContextModule,
      XfeSession session,
      TradesFlashModule tradesFlashModule,
      WatchlistModule watchlistModule,
      ObjectProperty<WatchlistSpec_v2> activeSpec,
      LayoutManager<Node> layoutManager,
      XfeAction interrogationAction,
      Runnable onDoubleClicked,
      SettingsData settingsData,
      ConfigActionsUIModule configActions, InstrumentsFilters filters,
      TriStateButton buttonWatchHighlight,
      StackPane toolbarContainer,
      ListenerTracker tracker,
      ObservableList<WatchlistSpec_v2> specs,
      ObjectProperty<ObservableList<InstrumentKey>> fullHighlightedList,
      ObjectProperty<ObservableList<InstrumentKey>> halfHighlightedList,
      ConfigurationModule configurationModule) {

      this.activeSpec = activeSpec;
      this.watchlistModule = watchlistModule;
      this.dataContextModule = dataContextModule;
      this.tracker = tracker;
      this.toolbarContainer = toolbarContainer;
      this.halfHighlightedList = halfHighlightedList;
      this.fullHighlightedList = fullHighlightedList;
      this.scheduler = scheduler;
      this.session = session;
      this.configurationModule = configurationModule;
      this.tradesFlashModule = tradesFlashModule;
      this.settingsData = settingsData;
      this.columns = new InstrumentsColumns(session, tracker, selectionContextModule, layoutManager, filters, settingsData, priceTightnessProperty4MiniWatchList);
      this.filterPane.managedProperty().bind(filterBarVisibleProperty);

      filterButton.setId("xfe-iswap-settings-tg-filter");
      XfeTooltipFactory.setTooltip(filterButton);

      configActions.addNode(filterButton);
      configActions.addNode(buttonWatchHighlight);
      this.filterButton.disableProperty().bind(new BooleanBinding() {
         {
            bind(instrTabPane.getSelectionModel().selectedItemProperty());
         }

         @Override
         protected boolean computeValue() {
            Tab selectedTab = instrTabPane.getSelectionModel().selectedItemProperty().get();
            return selectedTab != null && Objects.equals(selectedTab.getUserData(), TabViewPair.EXTERNAL_TAB);
         }
      });
      this.filterPane.visibleProperty().bind(filterBarVisibleProperty);
      this.openOrdersBySecBoard = session.orders.get().openOrdersBySecBoard();
      watchlistModule.configActionsUIModule.addNode(headerSpring);
      this.specs = specs;
      ObservableObjectValue<Tab> selectedItem = instrTabPane.getSelectionModel().selectedItemProperty();

      ChangeListener<Tab> tabSelectionChangeListener = (observable, oldSelectedTab, newSelectedTab) -> handleNewTabSelection(newSelectedTab);
      tracker.addListener(selectedItem, tabSelectionChangeListener);

      tracker.addListener(externalTabViews, new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            Fx.runLater(()->{
               instrTabPane.getTabs().removeAll(allexternalTabs);
               List<Tab> visibleExternalTab = new ArrayList<>(3);
               externalTabViews.sorted(TabViewPair.comparator).stream().forEach(pair ->visibleExternalTab.add(pair.getTab()));
               instrTabPane.getTabs().addAll(visibleExternalTab);
            });
         }
      });

      switchPane.getChildren().addAll(instrTabPane);

      filterPane.setPrefHeight(25);
      filterPane.getStyleClass().add("filter-tool-bar");
      HBox h = new HBox();
      HBox.setHgrow(h, Priority.ALWAYS);
      filterPane.getItems().addAll(
         allFilterButton,
         myFirmsInterestFilterButton,
         myInterestFilterButton,
         h,
         priceTightness);

      filterPane.setMinHeight(FilterPane.USE_PREF_SIZE);
      filterPane.setMaxHeight(FilterPane.USE_PREF_SIZE);

      priceTightness.getStyleClass().add("xfe-watchlist-filter-checkbox");
      myInterestFilterButton.getStyleClass().add("xfe-watchlist-filter-radio");
      ToggleGroup filterToggleGroup = new ToggleGroup();
      myInterestFilterButton.setToggleGroup(filterToggleGroup);
      myFirmsInterestFilterButton.getStyleClass().add("xfe-watchlist-filter-radio");
      myFirmsInterestFilterButton.setToggleGroup(filterToggleGroup);
      if (session.getUnderlyingSession().isLoggedOnUserBroker()) {
         myFirmsInterestFilterButton.setDisable(true);
         myInterestFilterButton.setDisable(true);
      }
      allFilterButton.getStyleClass().add("xfe-watchlist-filter-radio");
      allFilterButton.setToggleGroup(filterToggleGroup);
      ChangeListener<Toggle> toggleLis = (paramObservableValue, oldToggle, newToggle) -> {

         Tab selected = instrTabPane.getSelectionModel().getSelectedItem();
         if (selected != null && selected instanceof InstrumentTab) {
            InstrumentsFilter filter = InstrumentsFilter.fromString(((RadioButton) newToggle).getText());
            WatchlistSpec_v2 theActiveSpec = ((InstrumentTab) selected).spec;
            WatchlistSpec_v2 newSpec = theActiveSpec.withInstrFilter(filter);
            setSpec2SettingData(newSpec);
            theActiveSpec.instrFilter = filter;
            filteredProperty.set(theActiveSpec.isAnyFilter());
            instrumentsFilterProperty.setValue(filter);
         }
      };
      tracker.addListener(filterToggleGroup.selectedToggleProperty(), toggleLis);
      HBox.setHgrow(instrTabPane, Priority.ALWAYS);
      instrTabPane.setMinHeight(Region.USE_PREF_SIZE);
      instrTabPane.getStylesheets().add(getClass().getResource("InstrumentsTabPane.css").toExternalForm());

      filterButton.getStyleClass().add("xfe-table-filter-graphic");
      filterButton.setText("F");
      EventHandler<MouseEvent> filterButtonOnMouseClick = mouseEvent -> {
         Tab selected = instrTabPane.getSelectionModel().getSelectedItem();

         if (selected != null && selected instanceof InstrumentTab) {
            WatchlistSpec_v2 theActiveSpec = ((InstrumentTab) selected).spec;
            boolean isVisible = !filterBarVisibleProperty.get();
            filterBarVisibleProperty.set(isVisible);
            theActiveSpec.setFilterVisible(isVisible);
            WatchlistSpec_v2 newSpec = theActiveSpec.withFilterVisible(isVisible);
            updateSpec_filterVisibility(newSpec);
         }
      };
      filterButton.setOnMouseClicked(filterButtonOnMouseClick);


      specs.addListener(Fx.coalesced(dummy -> {
         List<WatchlistSpec_v2> visSpecs = InstrumentsPane.this.specs.stream().filter(WatchlistSpec_v2::isVisible).collect(Collectors.toList());

         visibleSpecs.setAll(visSpecs);
      }));

      columns.setDoubleClickHandler(new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
         @Override
         public void call(ObservableReplyRow row, TableCell<ObservableReplyRow, ?> cell) {
            onDoubleClicked.run();
         }
      });

      tracker.addListener(visibleSpecs,new InvalidationListener() {
         @Override
         public void invalidated(Observable dummy) {
            logger.debug("Visible Specs are:");
            int ignoredTabsNum = 0;
            for (WatchlistSpec_v2 vSpec : visibleSpecs) {
               logger.debug(vSpec.getUUID() + ": " + vSpec.getTitle() + "|" + vSpec.getSubtitle() + " visibility(" + vSpec.isVisible() + ")");
            }

            List<Tab> currentTabs = instrTabPane.getTabs();
            for (Tab tab : currentTabs) {
               for (TabViewPair tabView : externalTabViews) {
                  if (tab.getId().equals(tabView.getTab().getId())) ++ignoredTabsNum;
               }
            }

            // If a spec was replaced due to filtering, we just set it unto the tab
            // Otherwise, we rebuild the list
            int currentTabsEffectiveSize = currentTabs.size() - ignoredTabsNum;

            WatchlistSpec_v2 replacedSpec = null;

            extremeAddRemove = false;

            if (currentTabsEffectiveSize == visibleSpecs.size()) {
               int index = 0;

               for (; index < currentTabsEffectiveSize; ++index) {
                  WatchlistSpec_v2 currentSpec = ((InstrumentTab) currentTabs.get(index)).spec;
                  WatchlistSpec_v2 visibleSpec = visibleSpecs.get(index);

                  if (currentSpec == visibleSpec) {
                     continue;
                  }

                  if (!currentSpec.getId().equals(visibleSpec.getId()) || replacedSpec != null) {
                     extremeAddRemove = true;
                     break;
                  }

                  replacedSpec = visibleSpec;
               }
            } else {
               extremeAddRemove = true;
            }

            if (replacedSpec != null && !extremeAddRemove) {
               replaceTabSpec(replacedSpec);
            }
         }
      });

      this.layoutManager = layoutManager;
      this.interrogationAction = interrogationAction;
      this.interrogationAction.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            SelectionContext selectionContext = InstrumentsPane.this.getGridContext();

            if (selectionContext == null) {
               return;
            }

            int rowIndex = instrumentsTableView.getItems().indexOf(selectionContext.row);

            if (rowIndex >= 0 && rowIndex < instrumentsTableView.getItems().size()) {
               instrumentsTableView.scrollTo(rowIndex);
            }

            instrumentsTableView.needsLayoutProperty().addListener(new ChangeListener<Boolean>() {
               @Override
               public void changed(
                  ObservableValue<? extends Boolean> paramObservableValue,
                  Boolean oldValue,
                  Boolean newValue) {
                  if (oldValue && !newValue) {
                     Fx.runLater(() -> interrogationActionProperty.getValue().run());

                     instrumentsTableView.needsLayoutProperty().removeListener(this);
                  }
               }
            });
            instrumentsTableView.requestLayout();
         }
      });

      // This should never happen
      if (fullHighlightedList.get() == null)
         logger.error("fullHighlightedList list is null!");

      for (InstrumentKey pair : fullHighlightedList.get()) {
         columns.toggleRowHighlight(pair, State.FINAL);
      }
      fullHighlightedList.get().addListener(fullHighlightedListListener);

      tracker.addListener(fullHighlightedList, (arg0, oldList, newList) -> {
         if (oldList != null) {
            oldList.removeListener(fullHighlightedListListener);

            for (InstrumentKey pair : oldList) {
               columns.toggleRowHighlight(pair, State.FINAL);
            }
         }

         if (newList != null) {

            newList.addListener(fullHighlightedListListener);

            for (InstrumentKey pair : newList) {
               columns.toggleRowHighlight(pair, State.FINAL);
            }
         }
      });

      tracker.addListener(paneProperty, (observable, oldValue, newValue) -> {
         switchPane(newValue);
      });

      paneProperty.setValue(instrTabPane);

      // This should never happen
      if (halfHighlightedList.get() == null)
         logger.error("halfHighlightedList list is null!");

      for (InstrumentKey pair : halfHighlightedList.get()) {
         columns.toggleRowHighlight(pair, State.INTERMEDIATE);
      }

      halfHighlightedList.get().addListener(halfHighlightedListListener);

      tracker.addListener(halfHighlightedList, (arg0, oldList, newList) -> {
         if (oldList != null) {
            oldList.removeListener(halfHighlightedListListener);

            for (InstrumentKey pair : oldList) {
               columns.toggleRowHighlight(pair, State.INIT);
            }
         }

         if (newList != null) {
            newList.addListener(halfHighlightedListListener);

            for (InstrumentKey pair : newList) {
               columns.toggleRowHighlight(pair, State.INTERMEDIATE);
            }
         }
      });

      tracker.registerRollbackAction(() -> {
         fullHighlightedList.get().removeListener(fullHighlightedListListener);
         halfHighlightedList.get().removeListener(halfHighlightedListListener);
      });

      this.buttonWatchHighlight = buttonWatchHighlight;
      this.filters = filters;
      this.selectionContextModule = selectionContextModule;
      intrumentTableViewFilter = row -> {
         switch (instrumentsFilterProperty.get()) {
            case ALL:
               return true;
            case MY_INTEREST:
               return filters.hasMyOpenOrder(row);
            case MY_FIRMS_INTEREST:
               return filters.hasMyFirmOpenOrder(row);
         }
         return true;
      };
      registRfqStatusListener();

//      itemsFilterProperty = new ObjectBinding<Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue>>() {
//          {
//             super.bind(instrumentsFilterProperty);
//          }
//
//          @Override
//          protected Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue> computeValue() {
//             return filterFor(filters, instrumentsFilterProperty);
//          }
//
//          private Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue> filterFor(
//                final InstrumentsFilters filters,
//                final ObjectProperty<InstrumentsFilter> instrumentsFilterProperty) {
//             switch (instrumentsFilterProperty.get()) {
//             case ALL:
//                return DynamicFilter.alwaysTrue;
//             case MY_FIRMS_INTEREST:
//                return filters.hasMyFirmsOpenOrders;
//             case MY_INTEREST:
//                return filters.hasMyOpenOrders;
//             default:
//                return DynamicFilter.alwaysTrue;
//             }
//          }
//       };

      setTableViews();

      tracker.addListener(gridContext, paramObservable -> {
         logger.trace("gridContext is " + gridContext.get());
         SelectionContext context = gridContext.get();
         QueryReplyRow gridRow;

         if (context != null && (gridRow = context.row) != null) {
            querySecCode.set(gridRow.getValue(AmpIcapSecBoardTrim2.secCode));
            queryBoardId.set(gridRow.getValue(AmpIcapSecBoardTrim2.boardId));
         } else {
            querySecCode.set(null);
            queryBoardId.set(null);
         }
      });

      tracker.registerRollbackAction(() -> {
         showingInfoPopups.set(false);
      });

      session.secBoards.get().ready().onSuccess(new Fun1<Boolean, Void>() {
         @Override
         public Void call(Boolean dummy) {
            ObservableList<ObservableReplyRow> sortedTradeInfos = Fx.sortBy(tradeInfos, (aRow, bRow) -> {
               SecBoard aSecBoard = secBoardOf(aRow);
               SecBoard bSecBoard = secBoardOf(bRow);

               String aInstrument = aSecBoard != null ? aSecBoard.getInstrumentId() : null;
               String bInstrument = bSecBoard != null ? bSecBoard.getInstrumentId() : null;

               if (aInstrument == null) {
                  return bInstrument == null ? 0 : -1;
               }

               if (bInstrument == null) {
                  return -1;
               }

               int instrumentComparison = aInstrument.compareTo(bInstrument);

               if (instrumentComparison != 0) {
                  return instrumentComparison;
               }

               Long aMaturityDate = aSecBoard.getMaturityDateAsLong();
               Long bMaturityDate = bSecBoard.getMaturityDateAsLong();

               return aMaturityDate.compareTo(bMaturityDate);
            });

            volumeTabView.getView().setItems(Fx.alwaysUnequal(sortedTradeInfos));
            return null;
         }

         SecBoard secBoardOf(ObservableReplyRow row) {
            String secCode = row.getString(AmpSecBoardTradeInfo.secCode);
            String boardId = row.getString(AmpSecBoardTradeInfo.boardId);
            Tuple2<String, String> key = Tuple.of(secCode, boardId);

            return session.secBoards.get().getSecBoardsByKey().get(key);
         }
      });

      createTabs(specs);

      tracker.addListener(settingsData.displayVolumeTabProperty(), (_0, _1, newDisplayVolumeTab) -> {
         if (newDisplayVolumeTab)
            addTabView(volumeTabView);
         else
            removeTabView(volumeTabView);
      });

      tracker.addListener(settingsData.displayRFQTabProperty(), (_0, _1, newDisplayRFQTab) -> {
         if (newDisplayRFQTab)
            addTabView(rfqTabView);
         else
            removeTabView(rfqTabView);

      });

      tracker.bindBidirectional(priceTightnessProperty4WatchList, priceTightness.selectedProperty());

      tracker.addListener(priceTightnessProperty4WatchList, arg0 -> {
         Tab selected = instrTabPane.getSelectionModel().getSelectedItem();
         if (selected != null && selected instanceof InstrumentTab) {
            WatchlistSpec_v2 theActiveSpec = ((InstrumentTab) selected).spec;
            boolean isPT = priceTightnessProperty4WatchList.get();
            theActiveSpec = theActiveSpec.withPriceTight(isPT);
            setSpec2SettingData(theActiveSpec);
            watchlistModule.setPTInMiniWatchlist(isPT, theActiveSpec);
         }
      });
   }

   StackPane getSwitchPane() {
      return toolbarContainer;
   }

   private SelectionContext getGridContext() {
      return gridContextProperty().get();
   }

   void setGridContext(SelectionContext selectionContext) {
      if (selectionContext == null) {
         selectedRowIndex = 0;
         gridContext.set(new SelectionContext(GridType.Watchlist, null, null, -1));
      } else {
         gridContext.set(selectionContext);
      }
   }

   InstrumentsColumns getColumns() {
      return columns;
   }

   /**
    * Get the root pane for this GUI component.
    *
    * @return the root pane for this GUI component
    */
   @Override
   public Node getRootElement() {
      if (rootWatchPane == null) {
         rootWatchPane = new WatchListPane();
         rootWatchPane.setMinHeight(60);
         // Set up watch list tab area that can display buttons in the same
         // row as the tabs.
         tabHeaderPaneAndFillterPane.getStyleClass().add("xfe-iswap-instr-background");
         tabHeaderPane.getStyleClass().add("xfe-iswap-instr-tabheaderpane");

         rootWatchPane.getChildren().add(tabHeaderPaneAndFillterPane);
         StackPane instrumentsPane = new StackPane();
         tracker.addListener(externalTabViews, (Observable observable) -> {
            updateView(instrumentsPane);
         });

         updateView(instrumentsPane);

         rootWatchPane.getChildren().add(instrumentsPane);
         VBox.setVgrow(instrumentsPane, Priority.ALWAYS);
         VBox.setVgrow(instrumentsTableView, Priority.ALWAYS);
         HBox.setHgrow(switchPane, Priority.ALWAYS);
         tabHeaderPaneAndFillterPane.getChildren().addAll(tabHeaderPane, filterPane);


         StyleToggleProperty.on("filtered", filterButton).bind(filteredProperty);
//         settingsToolbar.getItems().addAll(buttonWatchHighlight, buttonGroupEditor, filterButton);
//         settingsToolbar.getStyleClass().add("xfe-instrument-filter-toolbar");
//         settingsToolbar.setMaxHeight(100);
//         toolbarContainer.getChildren().addAll(settingsToolbar);
//         StackPane.setAlignment(settingsToolbar, Pos.CENTER_LEFT);
         tabHeaderPane.getChildren().addAll(switchPane, toolbarContainer);
         rootWatchPane.getStyleClass().add("xfe-table");
         rootWatchPane.getStyleClass().add("xfe-iswap-watchlist-tabs");
      }

      return rootWatchPane;
   }

   @Override
   public void requestFocus() {
      throw new AssertionError("Not Implemented yet!!");
   }

   public ReadOnlyObjectProperty<WatchlistSpec_v2> getActiveSpec() {
      return activeSpec;
   }

   boolean getExtremeAddRemove() {
      return extremeAddRemove;
   }

   static boolean getInternalSpecUpdate() {
      return internalSpecUpdate;
   }

   WatchlistSpec_v2 getSelectedSpec() {
      Tab tab = instrTabPane.getSelectionModel().getSelectedItem();
      if (tab instanceof InstrumentTab) {
         InstrumentTab new_name = (InstrumentTab) tab;
         return new_name.spec;
      }
      return null;
   }

   @Override
   public void setItems(Watchlist watchlist) {
      FilteredList<ObservableReplyRow> tableItems = new FilteredList<>(watchlist.getItems(), intrumentTableViewFilter);
      instrumentsTableView.setItems(tableItems);
      instrumentsSelector.selectMatchingRow(null);
      instrumentsSelector.bindReadyFlag(watchlist.itemsReadyProperty());
   }

   @Override
   public void selectTabAndRow(UUID tabUUID,
                               String secCode,
                               AsnConversionAccessor<String> secCodeAcc,
                               OrderSide side,
                               boolean implied) {

      selectTab(tabUUID);
      Fx.delay(100,()-> {
         TableColumn<ObservableReplyRow, ?> column = null;
         InstrumentsTableView2 tabTableView = null;
         if (tabUUID.equals(Constants.PRICE_TIGHTNESS_ID)) {
            tabTableView = priceTightnessTableView;
         }
         else
            tabTableView = instrumentsTableView;

         if (tabTableView != null) {
            if (side == OrderSide.BUY) {
               //  attempt to match initially
               for (TableColumn<ObservableReplyRow, ?> col : tabTableView.getColumns()) {
                  if (implied ? Objects.equals(col.getText(), "B/B^n") : Objects.equals(col.getText(), Constants.COLUMN_NAME_BID)) {
                     column = col;
                     break;
                  }
               }
               //  next best thing
               if (column == null) {
                  for (TableColumn<ObservableReplyRow, ?> col : tabTableView.getColumns()) {
                     if (Objects.equals(col.getText(), Constants.COLUMN_NAME_BID) ||
                        (Objects.equals(col.getText(), "B/B^n"))) {
                        column = col;
                        break;
                     }
                  }
               }
            } else if (side == OrderSide.SELL) {
               //  attempt to match initially
               for (TableColumn<ObservableReplyRow, ?> col : tabTableView.getColumns()) {
                  if (implied ? Objects.equals(col.getText(), "O/O^n") : Objects.equals(col.getText(), Constants.COLUMN_NAME_OFFER)) {
                     column = col;
                     break;
                  }
               }
               //  next best thing
               if (column == null) {
                  for (TableColumn<ObservableReplyRow, ?> col : tabTableView.getColumns()) {
                     if (Objects.equals(col.getText(), Constants.COLUMN_NAME_OFFER) ||
                        Objects.equals(col.getText(), "O/O^n")) {
                        column = col;
                        break;
                     }
                  }
               }
            } else {
               column = tabTableView.getColumns().get(0);
            }
         }

         if (column != null) {
            selectRow(tabUUID, secCode, secCodeAcc, column);
         }
      });
   }

   @Override
   public TableView getView() {
      return instrumentsTableView;
   }

   private void setSpec2SettingData(WatchlistSpec_v2 newSpec) {
      if (lockSpecUpdates) {
         return;
      }

      int index = 0;

      List<WatchlistSpec_v2> watchlist = configurationModule.getParametersStorage().getList(PersistantName.WatchlistTabs, WatchlistSpec_v2.class, null).get();

      for (; index < watchlist.size(); ++index) {
         WatchlistSpec_v2 spec = watchlist.get(index);

         if (spec.getId().equals(newSpec.getId())) {
            break;
         }
      }

      if (index != watchlist.size()) {
         WatchlistSpec_v2 currentSpec = watchlist.get(index);

         if (!currentSpec.equals(newSpec)) {
            internalSpecUpdate = true;
            watchlist.set(index, newSpec);
            internalSpecUpdate = false;
         }
      }
   }

   public void setDisable(boolean b) {
      instrTabPane.setDisable(b);
   }

   void setPriceTightnessGhost(String secCode, boolean isGhost) {
      columns.setPriceTightnessGhost(secCode + VIEW_ID, isGhost);
   }

   void setupPriceTightnessSelector(TableView view, ObservableBooleanValue readyFlag) {
      if (priceTightnessSelector == null) {
         priceTightnessSelector = new RowSelector<>(view);
      }
      priceTightnessSelector.selectMatchingRow(null);
      priceTightnessSelector.bindReadyFlag(readyFlag);
   }

   AsnAccessor getColAccessor(TableView view, TableColumn col) {
      if (view instanceof InstrumentsTableView2) {
         InstrumentsTableView2 convertView = ((InstrumentsTableView2) view);
         return convertView.columnContext.get(col);
      }
      else
         return null;
   }

   ReadOnlyObjectProperty<SelectionContext> gridContextProperty() {
      return gridContext;
   }

   ReadOnlyStringProperty querySecCodeProperty() {
      return querySecCode;
   }

   ReadOnlyStringProperty queryBoardIdProperty() {
      return queryBoardId;
   }

   void selectFirstRow() {
      instrumentsSelector.selectFirstRow();
   }

   void addTabView(TabViewPair tabView) {
      allexternalTabs.add(tabView.getTab());
      externalTabViews.add(tabView);
      if (PRICE_TIGHTNESS_ID.equals(tabView.getTabId())) {
         priceTightnessSelector = new RowSelector<>(tabView.getView());
      }
   }

   void removeTabView(TabViewPair tabView) {
      externalTabViews.remove(tabView);
   }

   @SuppressWarnings("rawtypes")
   void clearViewSelection() {
      instrumentsTableView.getSelectionModel().clearSelection();

      for (TablePosition pos : new LinkedList<>(instrumentsTableView.getSelectionModel().getSelectedCells())) {
         instrumentsTableView.getSelectionModel().clearSelection(pos.getRow());
      }
   }

   Future<Boolean> selectOrDefer(String secCode, String boardId) {
      selectedSecCode = secCode;
      List<ObservableReplyRow> items = instrumentsTableView.getItems();
      int maxIndex = items.size();
      TableColumn<ObservableReplyRow, ?> tc;
      if (selectionContextModule.getSelectionContext().tablePosition != null) {
         tc = selectionContextModule.getSelectionContext().tablePosition.getTableColumn();
      } else
         tc = selectedColumn;

      for (int i = 0; i < maxIndex; i++) {
         int index = i;
         ObservableReplyRow row = items.get(index);
         String rowSecCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         String rowBoardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
         if (secCode.equals(rowSecCode) /*&& boardId.equals(rowBoardId)*/) {
            logger.info("selectOrDefer: found {} at index {}", secCode, i);
            instrumentsTableView.getSelectionModel().select(index, tc);
            return Future.valueOf(true);
         }
      }

      Promise<Boolean> ret = Futures.newPromise("Select-" + secCode);
      logger.info("selectOrDefer: seccode {} not found deferring select.", secCode);

      ListChangeListener<ObservableReplyRow> listChangeListener = change -> {
         if (ret.isDone()) {
            logger.info("selectOrDefer: seccode {} not found deferring select.", secCode);
            return;
         }
         while (change.next()) {
            for (ObservableReplyRow row : change.getAddedSubList()) {
               String rowSecCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
               String rowBoardId = row.getValue(AmpIcapSecBoardTrim2.boardId);

               if (secCode.equals(rowSecCode) /*&& boardId.equals(rowBoardId)*/) {
                  int index = change.getFrom() + change.getAddedSubList().indexOf(row);
                  logger.info("selectOrDefer: seccode {} eventually found at index {}.", secCode, index);
                  instrumentsTableView.getSelectionModel().select(index, tc);
                  ret.setSuccess(true);
                  return;
               }
            }
            logger.info("selectOrDefer: seccode {} not found in this change", secCode);
         }
      };

      // Remove the listener after the selection changes
      selectionContextModule.selectionContextProperty().addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            selectionContextModule.selectionContextProperty().removeListener(this);
            instrumentsTableView.getSelectionModel().getTableView().getItems().removeListener(listChangeListener);
            if (!ret.isDone()) {
               ret.setSuccess(false);
            }
         }
      });
      instrumentsTableView.getSelectionModel().getTableView().getItems().addListener(listChangeListener);

      return ret;
   }

   void toggleSelection(TriStateButton buttonWatchHighlight) {
      for (TablePosition<?, ?> tablePosition : instrumentsTableView.getSelectionModel().getSelectedCells()) {
         if (activeSpec.get() == null) continue;
         ObservableReplyRow row = instrumentsTableView.getItems().get(tablePosition.getRow());
         InstrumentKey key = columns.createKey(activeSpec.get().getId(), row, false);
         ObservableList<InstrumentKey> halfList = halfHighlightedList.get();
         ObservableList<InstrumentKey> fullList = fullHighlightedList.get();
         if (halfList == null || fullList == null) {
            logger.error("High light list is null. half high light is null {}; of full high light is null {}.", halfList == null, fullList == null);
         }
         State state = buttonWatchHighlight.getState();
         if (state == State.INIT) {
            if (halfList != null) halfList.removeAll(key);
            if (fullList != null) fullList.removeAll(key);
         } else if (state == State.INTERMEDIATE) {
            if (!(halfList != null && halfList.contains(key))) {
               if (halfList != null) halfList.add(key);
            }
            if (fullList != null) fullList.removeAll(key);
         } else if (state == State.FINAL) {
            if (halfList != null) halfList.removeAll(key);
            if (!(fullList != null && fullList.contains(key))) {
               if (fullList != null) fullList.add(key);
            }
         }
         columns.toggleRowHighlight(key, state);
      }
   }

   void createTabs(List<WatchlistSpec_v2> specs) {
      extremeAddRemove = false;

      if (specs == null) {
         specs = visibleSpecs;
      }

      UUID selectedTab = activeSpec.get() == null ? null : activeSpec.get().getId();
      removeAllTabs();
      activeSpec.set(null);
      instrTabPane.getSelectionModel().clearSelection();

      List<Tab> visibleTabs = new ArrayList<>(this.visibleSpecs.size() + 1);

      specs.stream().filter(WatchlistSpec_v2::isVisible).forEach(watchlistSpec -> {

         logger.trace("Adding Instrument tab: {}", watchlistSpec);

         InstrumentTab newTab = new InstrumentTab(watchlistSpec);

         visibleTabs.add(newTab);
      });

      ArrayList<TabViewPair> sortedTabViews = new ArrayList<>(externalTabViews);
      sortedTabViews.sort(TabViewPair.comparator);
      visibleTabs.addAll(sortedTabViews.stream().map(TabViewPair::getTab).collect(Collectors.toList()));

      instrTabPane.getTabs().addAll(visibleTabs);
      instrTabPane.getSelectionModel().clearSelection();
      if (selectedTab != null)
         selectTab(selectedTab);
   }

   /**
    * for pupoplate spec information, which is selected from watchlist popup
    */
   void handleNewSpecSelection(WatchlistSpec_v2 selectedSpec) {
      FlashableTab rfqTab = ((FlashableTab) rfqTabView.getTab());
      if (rfqTab.spec.equals(selectedSpec)) {
         refreshPaneProperties(null);
         Fx.runLater(() -> {
            selectRow(rfqTab.spec.id, null, null, null);
            rfqTab.stopFlashWhenSelected();
         });
      } else {
         instrTabPane.getTabs().stream().filter(tab -> tab instanceof InstrumentTab).forEach(tab -> {
            InstrumentTab instrumentTab = (InstrumentTab) tab;
            if (instrumentTab.spec.equals(selectedSpec)) {
               refreshPaneProperties(selectedSpec);
               Fx.runLater(() -> {
                  selectRow(selectedSpec.id, null, null, null);
               });
            }
         });
      }
   }

   /**
    * @param id, UUID of the watchlistspec
    * @return true if the tab selected, false the tab is not selected, such as the tab is deleted in case of tab setting editing or invert to PRESET
    */
   boolean selectTab(UUID id) {
      if(id!=null) {
         //already selected, do nothing
         Tab selected = instrTabPane.getSelectionModel().getSelectedItem();

         InstrumentTab selectedSpec = null;

         if (selected != null) {
            if (selected instanceof InstrumentTab) {
               selectedSpec = ((InstrumentTab) selected);

               if (selectedSpec.getSpecUUID().equals(id) && selectedSpec.spec.isVisible()) {
                  logger.debug("Tab " + selected.getText() + " is already selected");
                  return false;
               }
            }
            else if (selected instanceof SubtitleTab) {
               if (selected.getId().equals(id.toString())) {
                  logger.debug("Tab " + selected.getText() + " is already selected");
                  return false;
               }
            }
         }

         List<Tab> visibleTabs = instrTabPane.getTabs();

         for (Tab aTab : visibleTabs) {
            if (aTab.getId().equals(id.toString())) {
               if (aTab instanceof InstrumentTab) {
                  logger.debug("Selecting tab " + aTab.getText());
                  instrTabPane.select(aTab);
                  return true;
               }
            }
         }

         // Trying to find an external tab with this id
         for (TabViewPair tabView : externalTabViews) {
            if (tabView.getTab().getId().equals(id.toString())) {
               logger.debug("Selecting tab " + tabView.getTab().getText());
               instrTabPane.select(tabView.getTab());
               return true;
            }
         }

         // If here, could not select requested tab (not visible or uuid does not exist)
         if (visibleTabs.size() > 0) {
            Tab aTab = visibleTabs.get(0);
            // Selecting first tab, unless it is already selected or if it is Volume tab
            if (selected == null || !(selectedSpec.getSpecUUID().equals(((InstrumentTab) aTab).getSpecUUID()))) {
               instrTabPane.select(0);
            }
         }
      }else{
         if(instrTabPane.getTabs().size()>0){
            instrTabPane.select(0);
            return true;
         }else{
            return false;
         }
      }
      return false;
   }

   void activateMainWindow() {
      Scene mainScene = getRootElement().getScene();

      if (mainScene != null) {
         Window window = mainScene.getWindow();

         if (window instanceof Stage) {
            Stage mainWindow = (Stage) window;

            if (mainWindow.isIconified()) {
               mainWindow.setIconified(false);
            }

            mainWindow.requestFocus();
            mainWindow.toFront();
         }
      }
   }

   void attachTabSelectorAccelerators() {
      Node rootElement = getRootElement();
      TabSelector tabSelector = new TabPaneSelector(paneProperty, WeakCompositeRef.valueOf(rootElement));
      rootElement.addEventFilter(
         KeyEvent.KEY_PRESSED, KeyEventFilter.filterBy(tabSelector.reverseEvent(),
            new KeyCodeCombination(KeyCode.PAGE_UP, KeyCombination.CONTROL_DOWN)));
      rootElement.addEventFilter(
         KeyEvent.KEY_PRESSED, KeyEventFilter.filterBy(tabSelector.forwardEvent(),
            new KeyCodeCombination(KeyCode.PAGE_DOWN, KeyCombination.CONTROL_DOWN)));
   }

   void switchPane(XfeTabPane pane) {
      if (pane != null) {
         if (!switchPane.getChildren().contains(pane)) {
            switchPane.getChildren().add(1, pane);
            watchlistPopup(true);
         }
      } else {
         if (switchPane.getChildren().size() == 2) {
            switchPane.getChildren().remove(1);
            watchlistPopup(false);
         }
      }
   }

   InstrumentsTableView2 generateInstrumentTableView(boolean forPopup, boolean forPT, Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>> rowFactory,ListenerTracker listenerTracker) {
      if (forPT) {
         priceTightnessTableView = new InstrumentsTableView2(forPopup, forPT, rowFactory, listenerTracker);
         return priceTightnessTableView;
      }
      return new InstrumentsTableView2(forPopup, forPT, rowFactory,listenerTracker);
   }

   void scrollToTab() {
      instrTabPane.scrollToSelectedTab();
   }

   void stopSaveBookmark() {
      saveBookmark = false;
   }

   void reselected() {
//	   selectRow(bookmarkUuid, bookmarkSecCode, bookmakrSecCodeAccessor, bookmarkSelectedColumn);
      if (activeSpec.get() == null ||
         selectionContextModule.getSelectionContext().grid != GridType.Watchlist) return;

      String secondOption;
      if (selectionContextModule.dataContextRfsSessionSec.get()) {
         secondOption = selectionContextModule.secBoardContext.get().getParentSecCode();
      } else {
         secondOption = session.rfqs.get().getRfqSecCodeByParent(selectedSecCode);
      }

      logger.debug("reselected tab id:{} selectedSecCode: {} selectedColumn: {}",
         activeSpec.get().id,
         selectedSecCode,
         selectedColumn);

      selectRow(activeSpec.get().id, selectedSecCode, secondOption, AmpIcapSecBoardTrim2.secCode, selectedColumn);
      resumeBookmark();
   }

   @Override
   protected Future<Void> dispose(boolean disposing) {
      endedRfqs = null;
      instrTabPane.getProperties().clear();
      instrTabPane.getTabs().clear();
      rfqTabView.dispose();
      rfqTabView = null;

      rootWatchPane.getChildren().clear();
      interrogationAction.setOnAction(null);

      if (instrumentsSelector != null) {
         instrumentsSelector.dispose();
         instrumentsSelector = null;
      }

      if (rfqInstrumentsSelector != null) {
         rfqInstrumentsSelector.dispose();
         rfqInstrumentsSelector = null;
      }

      if (priceTightnessSelector != null) {
         priceTightnessSelector.dispose();
         priceTightnessSelector = null;
      }

      volumeTabView.dispose();
      volumeTabView = null;

      instrumentsTableView.setItems(FXCollections.emptyObservableList());
      instrumentsTableView = null;

      externalTabViews.clear();

      filterButton.setOnMouseClicked(null);
      return disposer.dispose().onDone(new Fun1<Object, Future<Void>>() {
         @Override
         public Future<Void> call(Object dummy) {
            return InstrumentsPane.super.dispose(disposing);
         }
      });
   }

   /**
    * once an rfq is finished, it allows to flash again
    */
   private void registRfqStatusListener() {
      endedRfqs = session.rfqs.get().endedRfqs.get();
      tracker.addListener(endedRfqs, endRfqLis);
   }

   private double GetScalingFactor(boolean left, boolean forPriceTightness) {

      //	to keep Bid/Offer cols same width, we have to work out scaling factor separately for bid/offer side,
      //	and do not scale the Bid/Offer cols
      double w;
      w = left ?
         COLUMN_SECCODE_SIZE + COLUMN_TYPE_SIZE + COLUMN_QUANTITY_SIZE + COLUMN_IMPLIED_PRICE_SIZE :
         COLUMN_IMPLIED_PRICE_SIZE + COLUMN_QUANTITY_SIZE + COLUMN_TYPE_SIZE + COLUMN_LASTPRICE_SIZE + COLUMN_LASTAMT_SIZE + COLUMN_REFER_SIZE;

      if (forPriceTightness) {
         w += COLUMN_PRICE_TIGHTNESS_SIZE / 2;
      }

      double w2 = w - COLUMN_IMPLIED_PRICE_SIZE;
      return w / w2;
   }

   private double GetPriceTightnessFactor() {
      double totalSize = COLUMN_SECCODE_SIZE + 2 * (COLUMN_TYPE_SIZE + COLUMN_QUANTITY_SIZE + COLUMN_IMPLIED_PRICE_SIZE)
         + COLUMN_LASTPRICE_SIZE + COLUMN_LASTAMT_SIZE + COLUMN_REFER_SIZE;

      return totalSize / (totalSize + COLUMN_PRICE_TIGHTNESS_SIZE);
   }

   @SuppressWarnings("rawtypes")
   private void setTableViews() {
      allexternalTabs.add(watchlistModule.getRfqTab());
      allexternalTabs.add(volumnTab);
      rfqTabView = new TabViewPair(watchlistModule.getRfqTab(),
         new RfqTableView(columns, activeSpec, buttonWatchHighlight, gridContext), 0);
      rfqTabView.getView().setItems(watchlistModule.getRfqWatchlist().getItems());
      if (settingsData.displayRFQTabProperty().get()) {
         addTabView(rfqTabView);
      }

      tracker.bind(rfqTabView.getView().visibleProperty(),
         Bindings.equal(instrTabPane.getSelectionModel().selectedItemProperty(),
            rfqTabView.getTab()));

      TableView<ObservableReplyRow> volumeTableView = new TableViewHeaderUnmovable<>();
      volumeTabView = new TabViewPair(volumnTab, volumeTableView, 1);
      volumeTabView.getTab().setId(DAILY_VOLUME_TAB_NAME);

      tracker.bind(volumeTabView.getView().visibleProperty(),
         Bindings.equal(instrTabPane.getSelectionModel().selectedItemProperty(),
            volumeTabView.getTab()));

      volumeTableView.getColumns().add(TradeInfoColumns.createInstrumentColumn());
      volumeTableView.getColumns().add(TradeInfoColumns.createVolumeTodayColumn());
      volumeTableView.getColumns().add(TradeInfoColumns.createLastTimeColumn());
      volumeTableView.getColumns().add(TradeInfoColumns.createLastPriceColumn(session));
      volumeTableView.getColumns().add(TradeInfoColumns.createLastQuantityColumn());
      volumeTableView.getColumns().add(TradeInfoColumns.createChangeLTPColumn());
      volumeTableView.getColumns().add(TradeInfoColumns.createHighPriceColumn(session));
      volumeTableView.getColumns().add(TradeInfoColumns.createLowPriceColumn(session));

      if (settingsData.displayVolumeTabProperty().get()) {
         addTabView(volumeTabView);
      }

      if (instrumentsSelector != null) {
         instrumentsSelector.selectMatchingRow(null);
      }

      instrumentsTableView = new InstrumentsTableView2(false, false, null,null);
      instrumentsSelector = new RowSelector<>(instrumentsTableView);
      instrumentsSelector.selectFirstRow();

      rfqInstrumentsSelector = new RowSelector<>(rfqTabView.getView());
      // Adding a listener for cell selection
      // TODO: Do I need to add listener to volumesTableView selection model?
      tracker.addListener(instrumentsTableView.getSelectionModel().getSelectedCells(), selectedCellListener);
      tracker.addListener(instrumentsTableView.getSelectionModel().selectedIndexProperty(), tableRowSelectionListener);
   }

   private void updateView(StackPane instrumentsPane) {
      if (instrumentsTableView != null) {
         instrumentsPane.getChildren().clear();
         instrumentsPane.getChildren().addAll(instrumentsTableView);
         externalTabViews.stream().filter(tabView -> tabView.getView() != null)
            .forEach(tabView -> instrumentsPane.getChildren().add(tabView.getView()));
      }
   }

   private void removeAllTabs() {
      instrTabPane.getTabs().clear();
      instrTabPane.getSelectionModel().clearSelection();
   }

   private void replaceTabSpec(WatchlistSpec_v2 spec) {
      UUID tabId = spec.getId();
      List<Tab> tabs = instrTabPane.getTabs();

      for (int index = 0; index < tabs.size(); ++index) {
         Tab aTab = tabs.get(index);

         if (!(aTab instanceof InstrumentTab)) {
            continue;
         }

         InstrumentTab relevantTab = ((InstrumentTab) aTab);
         UUID theId = relevantTab.spec.getId();

         if (tabId.equals(theId) && relevantTab.spec != spec) {
            logger.debug("Replacing SPEC at index " + index);
            relevantTab.replaceSpec(spec);
            refreshPaneProperties(spec);
            return;
         }
      }

      logger.error("Tab id for new spec cannot be found in existing tabs");
   }

   private void selectScopeButton(WatchlistSpec_v2 spec) {
      InstrumentsFilter newFilter = spec.getInstrFilter();

      switch (newFilter) {
         case ALL:
            InstrumentsPane.this.allFilterButton.setSelected(true);
            break;
         case MY_FIRMS_INTEREST:
            InstrumentsPane.this.myFirmsInterestFilterButton.setSelected(true);
            break;
         case MY_INTEREST:
            InstrumentsPane.this.myInterestFilterButton.setSelected(true);
            break;
         default:
            InstrumentsPane.this.allFilterButton.setSelected(true);
            break;
      }
   }

   private void handleNewTabSelection(Tab newSelectedTab) {
      logger.trace("changing tab: (started) to {}",newSelectedTab);
      if (newSelectedTab == null) return;

      if (Objects.equals(newSelectedTab.getUserData(), TabViewPair.EXTERNAL_TAB)) {
         refreshPaneProperties(null);
         if (newSelectedTab == rfqTabView.getTab()) {
            Fx.runLater(() -> {
               selectRow(((FlashableTab) rfqTabView.getTab()).spec.id, null, null, null);
               ((FlashableTab) newSelectedTab).stopFlashWhenSelected();
            });
         }
         else if (newSelectedTab.getId().equals(Constants.PRICE_TIGHTNESS_ID.toString())) {
            Fx.runLater(() -> {
               selectRow(Constants.PRICE_TIGHTNESS_ID, null, null, null);
            });
         }
      } else {
         InstrumentTab theTab = (InstrumentTab) newSelectedTab;

         if (theTab.spec != null) {
            refreshPaneProperties(theTab.spec);
            Fx.runLater(() -> {
               selectRow(theTab.spec.id, null, null, selectedColumn);
            });
         }

         if (popup != null)
            popup.selectSpec();
      }
   }

   private void refreshPaneProperties(final WatchlistSpec_v2 spec) {
      lockSpecUpdates = true;

      if (spec == null) {
         filterBarVisibleProperty.set(false);
         filterButton.setSelected(true);
         filteredProperty.set(false);
         priceTightnessProperty4WatchList.set(false);
      } else {
         logger.trace("changing tab: updating filter bar");
         selectScopeButton(spec);
         filterBarVisibleProperty.set(spec.isFilterVisible());
         filterButton.setSelected(!spec.isFilterVisible());
         filteredProperty.set(spec.isAnyFilter());
         instrumentsFilterProperty.set(spec.getInstrFilter());
         priceTightness.setSelected(spec.isPriceTight());
      }

      logger.trace("changing tab: setting active spec");
      WatchlistSpec_v2 prevSpec = activeSpec.get();
      activeSpec.set(spec);
      Security sec = this.dataContextModule.selectedSecurity().getValue();
      if (spec != null && prevSpec != null && spec.id.equals(prevSpec.id)) {
         Fx.runLater(() -> {
            selectRow(spec.id, sec == null ? null : sec.getSecCode(), AmpIcapSecBoardTrim2.secCode, selectedColumn);
         });
      }

      lockSpecUpdates = false;
   }

   private void selectRow(RowSelector<ObservableReplyRow> selector, StaticFilter<ObservableReplyRow> r, TableColumn<ObservableReplyRow, ?> column){
      if(selector==null){
         return;
      }
      if (r == null)
         selector.selectFirstRow();
      else
         selector.selectMatchingRow(r, column);
   }

   private void selectRow(UUID tabUUID, String secCode, AsnConversionAccessor<String> acc, TableColumn<ObservableReplyRow, ?> column) {
      UUID rfqId = ((FlashableTab) rfqTabView.getTab()).spec.id;
      UUID priceTightnessId = Constants.PRICE_TIGHTNESS_ID;
      if (secCode != null) {
         StaticFilter<ObservableReplyRow> r = RowFilters.equalsStatic(acc, secCode);
         if (tabUUID.equals(rfqId)) {
            selectRow(rfqInstrumentsSelector, r, column);
         } else if (tabUUID.equals(priceTightnessId)) {
            selectRow(priceTightnessSelector, r, column==null ? priceTightnessTableView.instrColumn : column);
         } else {
            selectRow(instrumentsSelector, r, column==null ? instrumentsTableView.instrColumn : column);
         }
      } else {
         if (tabUUID.equals(rfqId)) {
            logger.debug("select rfq table FIRST row");
            selectRow(rfqInstrumentsSelector, null, null);
         } else if (tabUUID.equals(priceTightnessId)) {
            logger.debug("select price tightness table FIRST row");
            selectRow(priceTightnessSelector, null, column==null ? priceTightnessTableView.instrColumn : column);
         } else {
            logger.debug("select instrument table FIRST row");
            selectRow(instrumentsSelector, null, column==null ? instrumentsTableView.instrColumn : column);
         }
      }
   }

   private void selectRow(UUID tabUUID, String secCode, String secondOptionCode, AsnConversionAccessor<String> acc, TableColumn<ObservableReplyRow, ?> column) {
      UUID rfqId = ((FlashableTab) rfqTabView.getTab()).spec.id;
      UUID priceTightnessId = Constants.PRICE_TIGHTNESS_ID;
      if (secCode != null) {
         StaticFilter<ObservableReplyRow> r = RowFilters.equalsStatic(acc, secCode, secondOptionCode);
         if (tabUUID.equals(rfqId)) {
            selectRow(rfqInstrumentsSelector, r, column);
         } else if (tabUUID.equals(priceTightnessId)) {
            selectRow(priceTightnessSelector, r, column==null ? priceTightnessTableView.instrColumn : column);
         } else {
            selectRow(instrumentsSelector, r, column==null ? instrumentsTableView.instrColumn : column);
         }
      } else {
         if (tabUUID.equals(rfqId)) {
            logger.debug("select rfq table FIRST row");
            selectRow(rfqInstrumentsSelector, null, null);
         }
         if (tabUUID.equals(priceTightnessId)) {
            logger.debug("select price tightness table FIRST row");
            selectRow(priceTightnessSelector, null, column==null ? priceTightnessTableView.instrColumn : column);
         } else {
            logger.debug("select instrument table FIRST row");
            selectRow(instrumentsSelector, null, column==null ? instrumentsTableView.instrColumn : column);
         }
      }
   }

   private void handleFullHighlightChange(Change<? extends InstrumentKey> change) {
      while (change.next()) {
         if (change.wasAdded()) {
            for (InstrumentKey key : change.getAddedSubList()) {
               columns.toggleRowHighlight(key, State.FINAL);
            }
         }

         if (change.wasRemoved()) for (InstrumentKey ignored : change.getRemoved()) columns.toggleRowHighlightOff();
      }
   }

   private void handleHalfHighlightChange(Change<? extends InstrumentKey> change) {
      while (change.next()) {
         if (change.wasAdded()) {
            for (InstrumentKey key : change.getAddedSubList()) {
               columns.toggleRowHighlight(key, State.INTERMEDIATE);
            }
         }

         if (change.wasRemoved()) for (InstrumentKey ignored : change.getRemoved()) columns.toggleRowHighlightOff();
      }
   }

   private void updateSpec_filterVisibility(WatchlistSpec_v2 newSpec) {
      List<WatchlistSpec_v2> watchlist = configurationModule.getParametersStorage().getList(PersistantName.WatchlistTabs, WatchlistSpec_v2.class, null).get();
      int index = 0;
      UUID specUUID = newSpec.id;
      for (; index < watchlist.size(); ++index) {
         WatchlistSpec_v2 spec = watchlist.get(index);

         if (specUUID.equals(spec.id)) {
            break;
         }
      }

      if (index != watchlist.size()) {
         internalSpecUpdate = true;
         watchlist.set(index, newSpec);
         internalSpecUpdate = false;
      }
   }

   private void watchlistPopup(boolean isSelected) {
      if (isSelected) {
         if (popup != null) {
            headerSpring.getChildren().remove(popup.getMenuButton());
            popup.dispose();
         }

         popup = new WatchlistPopup(configurationModule.getParametersStorage().getList(PersistantName.WatchlistTabs, WatchlistSpec_v2.class, null).get(), this);
         StackPane.setAlignment(popup.getMenuButton(), Pos.CENTER);
         headerSpring.getChildren().add(popup.getMenuButton());

      } else {
         if (popup != null) {
            headerSpring.getChildren().remove(popup.getMenuButton());
            popup.dispose();
         }
      }
   }

   private void resumeBookmark() {
      saveBookmark = true;
   }
   public final InstrumentsColumns columns;
   final XfeTabPane instrTabPane = new XfeTabPane(false);
   final BooleanProperty priceTightnessProperty4MiniWatchList = new SimpleBooleanProperty(false);
   private final SubtitleTab volumnTab = new SubtitleTab("Daily", "Vol");
   private final XfeSession session;
   private final ConfigurationModule configurationModule;
   private final SettingsData settingsData;
   private final VBox tabHeaderPaneAndFillterPane = new VBox();
   private final HBox tabHeaderPane = new HBox();
   private final StackPane switchPane = new StackPane();
   private final Property<Runnable> interrogationActionProperty = new SimpleObjectProperty<>(Functions.NOOP_RUNNABLE);
   private final ObservableMap<Tuple2<String, String>, ObservableList<ObservableReplyRow>> openOrdersBySecBoard;
   //for instrument filter
//   private final ObservableValue<Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue>> itemsFilterProperty;
   private final BooleanProperty filteredProperty = new SimpleBooleanProperty(false);
   private final BooleanProperty filterBarVisibleProperty = new SimpleBooleanProperty(false);
   private final BooleanProperty priceTightnessProperty4WatchList = new SimpleBooleanProperty(false);
   private final ReadOnlyBooleanProperty priceTightnessPropertyRO = priceTightnessProperty4WatchList;
   private final ObjectProperty<InstrumentsFilter> instrumentsFilterProperty = new SimpleObjectProperty<>(InstrumentsFilter.ALL);
   private final Disposer disposer = new Disposer();
   private final ObservableList<TabViewPair> externalTabViews = FXCollections.observableArrayList();
   private final Set<Tab> allexternalTabs = new HashSet(3);
   private final InstrumentsFilters filters;
   // There is one and only one cell/row combination that can be selected at any point of time
   private final ObjectProperty<SelectionContext> gridContext = new SimpleObjectProperty<>();
   private final StringProperty querySecCode = new SimpleStringProperty();
   private final StringProperty queryBoardId = new SimpleStringProperty();
   private final BooleanProperty showingInfoPopups = new SimpleBooleanProperty(true);
   private final LayoutManager<Node> layoutManager;
   private final XfeAction interrogationAction;
   private final TriStateButton buttonWatchHighlight;
   private final DeadlineScheduler scheduler;
   private final RadioButton allFilterButton = new RadioButton(InstrumentsFilter.ALL.toString());
   private final RadioButton myFirmsInterestFilterButton = new RadioButton(InstrumentsFilter.MY_FIRMS_INTEREST.toString());
   private final RadioButton myInterestFilterButton = new RadioButton(InstrumentsFilter.MY_INTEREST.toString());
   private final CheckBox priceTightness = new CheckBox("Price Tightness");
   private final ToolBar filterPane = new ToolBar();
   private final ListChangeListener<InstrumentKey> fullHighlightedListListener = this::handleFullHighlightChange;
   private final ListChangeListener<InstrumentKey> halfHighlightedListListener = this::handleHalfHighlightChange;
   private final ObservableList<WatchlistSpec_v2> specs;
   private final ObservableList<WatchlistSpec_v2> visibleSpecs = FXCollections.observableArrayList();
   private final ObjectProperty<ObservableList<InstrumentKey>> fullHighlightedList;
   private final ObjectProperty<ObservableList<InstrumentKey>> halfHighlightedList;
   private final ListenerTracker tracker;
   private final ObjectProperty<XfeTabPane> paneProperty = new SimpleObjectProperty<>();
   private final StackPane toolbarContainer;
   private final Predicate<ObservableReplyRow> intrumentTableViewFilter;
   private final TradesFlashModule tradesFlashModule;
   private final WatchlistModule watchlistModule;
   private final DataContextModule dataContextModule;
   private final ObjectProperty<WatchlistSpec_v2> activeSpec;
   private final ListChangeListener<QueryReplyRow> endRfqLis = new ListChangeListener<QueryReplyRow>() {
      @Override
      public void onChanged(Change<? extends QueryReplyRow> change) {
         while (change.next()) {
            if (change.wasAdded()) {
               List<? extends QueryReplyRow> addedList = change.getAddedSubList();
               for (QueryReplyRow aRow : addedList) {
                  String secCode = aRow.getValue(AmpRfq.secCode);
                  String boardId = aRow.getValue(AmpRfq.boardId);
                  columns.enableFlash(secCode, boardId);
               }
            }
         }
      }
   };
   private final ToggleButton filterButton = new ToggleButton();
   private final StackPane headerSpring = new StackPane() {{
      this.setId("xfe-combobox-pane");
      HBox.setHgrow(this, Priority.SOMETIMES);
   }};
   private VBox rootWatchPane;
   private TabViewPair volumeTabView;
   private TabViewPair rfqTabView;
   private InstrumentsTableView2 instrumentsTableView;
   private InstrumentsTableView2 priceTightnessTableView;
   private final InvalidationListener tableRowSelectionListener = new InvalidationListener() {
      @Override
      public void invalidated(Observable observable) {
         if (session.loggedOnProperty().get()) {
            ObservableReplyRow selectedRow = instrumentsTableView.getSelectionModel().getSelectedItem();
            logger.debug("instrumentsTableView selected row changes to {}", selectedRow);
            if (selectedRow != null) {
               String secCode = selectedRow.getString(AmpIcapSecBoardTrim2.secCode);
               String boardId = selectedRow.getString(AmpIcapSecBoardTrim2.boardId);

               getColumns().disableFlash(secCode, boardId);
            }
         }
      }
   };
   private RowSelector<ObservableReplyRow> instrumentsSelector;
   private RowSelector<ObservableReplyRow> rfqInstrumentsSelector;
   private RowSelector<ObservableReplyRow> priceTightnessSelector;
   private Integer selectedRowIndex;
   private TableColumn selectedColumn;
   private String selectedSecCode;
   private boolean extremeAddRemove;
   private boolean lockSpecUpdates;
   private ObservableList<ObservableReplyRow> endedRfqs;
   private WatchlistPopup popup;
   //   private UUID bookmarkUuid;
//   private String bookmarkSecCode;
//   private AsnConversionAccessor<String> bookmakrSecCodeAccessor;
//   private TableColumn bookmarkSelectedColumn;
   private boolean saveBookmark = true;
   private final ListChangeListener<TablePosition> selectedCellListener = new ListChangeListener<TablePosition>() {
      @Override
      public void onChanged(Change<? extends TablePosition> tp) {
         logger.debug("instrumentsTableView selected cell changed to \n{}", tp);
         if (instrumentsTableView == null || !instrumentsTableView.isVisible()) {
            return;
         }
         while (tp.next()) {
            if (!tp.getList().isEmpty()) {
               TableColumn<?, ?> column = tp.getList().get(0).getTableColumn();
               AsnAccessor colAccessor = instrumentsTableView.columnContext.get(column);
               int currentRow = tp.getList().get(0).getRow();
               Integer currSelectedRowIndex = currentRow;
               ObservableReplyRow row = instrumentsTableView.getItems().get(currentRow);
               String secCode = row.getString(AmpIcapSecBoardTrim2.secCode);

               if (saveBookmark) {
                  selectedSecCode = secCode;
                  selectedColumn = column;
               }

               if ((currentRow >= 0) && (currentRow < instrumentsTableView.getItems().size()) && (activeSpec.get() != null)) {
                  InstrumentKey key = columns.createKey(activeSpec.get().getId(), row, false);
                  buttonWatchHighlight.setState(columns.rowHighlightValue(key));
               } else {
                  buttonWatchHighlight.setState(State.INIT);
               }

               selectedRowIndex = currSelectedRowIndex;

               logger.trace("Selected cell at (row,col)=({}, {})", selectedRowIndex, (tp.getList().size() > 0 ? tp.getList().get(0).getColumn() : "null"));

               if (currentRow >= 0 && currentRow < instrumentsTableView.getItems().size()) {
                  setGridContext(new SelectionContext(GridType.Watchlist, instrumentsTableView.getItems().get(currSelectedRowIndex), colAccessor, currSelectedRowIndex));
               }
            }
         }
      }
   };
}

