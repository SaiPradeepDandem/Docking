package xfe.icap.modules.tabeditorview;

import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.util.Fx;

public class WatchlistTabDetailsCell extends ListCell<WatchlistSpec_v2> {

	private static final Logger logger = LoggerFactory.getLogger(WatchlistTabDetailsCell.class);

	//This attribute is for making my drag n drop totally private
	public static final DataFormat dataFormat =  new DataFormat("WatchlistTabDetailsCell1");

	boolean editing;
	final Label titleLabel = new Label() {{
      setId("xfe-iswap-secseditview-titlelbl");
   }};
	final TextField titleEdit = new TextField() {{
      setId("xfe-iswap-secseditview-titletxt");
   }};
	final Label subtitleLabel = new Label() {{
      setId("xfe-iswap-secseditview-subtitlelbl");
   }};
	final TextField subtitleEdit = new TextField() {{
      setId("xfe-iswap-secseditview-subtitletxt");
   }};
	final Button deleteTabButton = new Button() {
      {
         setId("xfe-iswap-secseditview-deletetab");
      }
   };
	final CheckBox cb = new CheckBox() {
      {
         setId("xfe-iswap-secseditview-showhidetab");
      }
   };
	final GridPane gp = new GridPane();
	final Label dragHandle = new Label() {{
      setId("xfe-iswap-secseditview-draghandle");
   }};

	private boolean itemIsUpdating;

	static final Callback<ListView<WatchlistSpec_v2>, ListCell<WatchlistSpec_v2>> factory = lv -> new WatchlistTabDetailsCell(lv);

	public WatchlistTabDetailsCell(ListView<WatchlistSpec_v2> listView) {
      setId("xfe-iswap-secseditview-tab");
		setEditable(true);
      dragHandle.getStyleClass().add("xfe-icon-drag-handle");
      dragHandle.setCursor(Cursor.MOVE);
      dragHandle.setPickOnBounds(true);
      new ListCellDragHelper().initDrag(dragHandle,this,listView);

		this.getStyleClass().add("tab-edit-list-cell");
		gp.getStyleClass().add("tab-edit-list-cell-grid");
		Group titleStack = new Group();
		titleLabel.getStyleClass().add("xfe-title-2");
		subtitleLabel.getStyleClass().add("xfe-title-3");
		titleEdit.getStyleClass().addAll("xfe-title-2");
		subtitleEdit.getStyleClass().addAll("xfe-title-3");
		titleEdit.setPrefColumnCount(8);
      subtitleEdit.setPrefColumnCount(8);
		titleStack.getChildren().addAll(titleLabel, titleEdit);
		Group subtitleStack = new Group();
		subtitleStack.getChildren().addAll(subtitleLabel, subtitleEdit);
		EventHandler<KeyEvent> keyboardEventHandler = new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent arg0) {
				if (arg0.getCode() == KeyCode.ESCAPE) {
					ourCancelEdit();
				} else if (arg0.getCode() == KeyCode.ENTER) {
					commitEdit(getItem().withTitle(titleEdit.getText()).withSubtitle(subtitleEdit.getText()));
					requestFocus();
				}
         }
      };

      this.setOnKeyPressed(keyboardEventHandler);

		focusedProperty().addListener(new ChangeListener<Boolean>() {

			@Override
			public void changed(ObservableValue<? extends Boolean> arg0,
					Boolean oldVal, Boolean newVal) {
				if (!subtitleEdit.focusedProperty().get() && !titleEdit.focusedProperty().get() && editing) {
               commitEdit(getItem().withTitle(titleEdit.getText()).withSubtitle(subtitleEdit.getText()));
				}
			}
		});

		titleEdit.focusedProperty().addListener(new InvalidationListener() {

			@Override
			public void invalidated(Observable newVal) {
				if (!titleEdit.focusedProperty().get()) {
					Fx.runLater(() -> {
                        if (!subtitleEdit.focusedProperty().get() && !titleEdit.focusedProperty().get() && editing) {
                            commitEdit(getItem().withTitle(titleEdit.getText()).withSubtitle(subtitleEdit.getText()));
                        }
                    });
				}
			}
		});

      subtitleEdit.focusedProperty().addListener(new InvalidationListener() {

         @Override
         public void invalidated(Observable newVal) {
            if (!subtitleEdit.focusedProperty().get()) {
               Fx.runLater(() -> {
                  if (!subtitleEdit.focusedProperty().get() && !titleEdit.focusedProperty().get() && editing) {
                     commitEdit(getItem().withTitle(titleEdit.getText()).withSubtitle(subtitleEdit.getText()));
                  }
               });
            }
         }
      });

		deleteTabButton.getStyleClass().addAll("tab-edit-delete-button", "xfe-icon-delete");
      deleteTabButton.setOnAction(actionEvent -> getListView().getItems().remove(getIndex()));

		gp.add(titleStack, 1, 0);
		gp.add(cb, 0, 0);
		gp.add(subtitleStack, 1, 1);
		gp.add(deleteTabButton, 0, 1);
		gp.add(dragHandle, 2, 0, 1, 2);
		GridPane.setHgrow(titleStack, Priority.ALWAYS);
		GridPane.setHgrow(subtitleStack, Priority.ALWAYS);
		cb.selectedProperty().addListener((arg0, arg1, arg2) -> {
         if (!itemIsUpdating)
            updateMe(getItem().withVisible(arg2));
      });
	}

	private void updateMe(WatchlistSpec_v2 newSpec) {
		for (int i = 0; i < getListView().getItems().size(); ++i) {
			WatchlistSpec_v2 spec = getListView().getItems().get(i);
			if (spec != newSpec && spec.getId().equals(newSpec.getId())) {
				logger.debug("Setting new spec at index " + i);
				getListView().getItems().set(i, newSpec);
				return;
			}
		}
	}

	@Override
	protected void updateItem(WatchlistSpec_v2 wl, boolean empty) {

		super.updateItem(wl, empty);

		if (empty) {
			setGraphic(null);
         //XfeTooltipFactory.removeTooltip(this);
		} else {
			itemIsUpdating  = true;
			setGraphic(gp);
         //XfeTooltipFactory.setTooltip(this);
         titleLabel.setText(wl.getTitle());
			subtitleLabel.setText(wl.getSubtitle());
         cb.setSelected(wl.isVisible());
         XfeTooltipFactory.setTooltip(titleLabel);
         XfeTooltipFactory.setTooltip(subtitleLabel);
         XfeTooltipFactory.setTooltip(cb);
         XfeTooltipFactory.setTooltip(deleteTabButton);
         XfeTooltipFactory.setTooltip(dragHandle);
			titleEdit.setText(wl.getTitle());
			subtitleEdit.setText(wl.getSubtitle());
			titleLabel.setVisible(!isEditing());
			subtitleLabel.setVisible(!isEditing());
			titleEdit.setVisible(isEditing());
			subtitleEdit.setVisible(isEditing());
			itemIsUpdating = false;
		}
	}

	@Override
	public void startEdit() {
		editing = true;
		titleEdit.setText(getItem().getTitle());
		subtitleEdit.setText(getItem().getSubtitle());
		titleLabel.setVisible(false);
		titleEdit.setVisible(true);
		subtitleLabel.setVisible(false);
		subtitleEdit.setVisible(true);
		cb.setDisable(true);
		deleteTabButton.setDisable(true);
		dragHandle.setVisible(false);
		super.startEdit();
		Fx.runLater(new Runnable() {
			@Override
			public void run() {
				titleEdit.requestFocus();
			}
			@Override
			public String toString() {
				return "WatchlistTabDetailsCell.startEdit";
			}
		});
	}

	@Override
	public void cancelEdit() {
		super.cancelEdit();
	}

	public void ourCancelEdit() {

		titleLabel.setText(getItem().getTitle());
		subtitleLabel.setText(getItem().getSubtitle());
		titleLabel.setVisible(true);
		titleEdit.setVisible(false);
		subtitleLabel.setVisible(true);
		subtitleEdit.setVisible(false);
		dragHandle.setVisible(true);
		cb.setDisable(false);
		deleteTabButton.setDisable(false);
		editing = false;

		super.cancelEdit();
	}

	@Override
	public void commitEdit(WatchlistSpec_v2 spec) {
		titleLabel.setVisible(true);
		titleEdit.setVisible(false);
		subtitleLabel.setVisible(true);
		subtitleEdit.setVisible(false);
		dragHandle.setVisible(true);
		cb.setDisable(false);
		deleteTabButton.setDisable(false);
		editing = false;

		if (getItem() != spec) {
			updateMe(spec);
			titleLabel.setText(spec.getTitle());
			subtitleLabel.setText(spec.getSubtitle());
		}
		super.cancelEdit();
	}
}
