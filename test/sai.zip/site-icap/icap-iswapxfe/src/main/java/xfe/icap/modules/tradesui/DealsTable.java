package xfe.icap.modules.tradesui;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import xfe.icap.amp.AmpDeal;
import xfe.ui.table.AlignedTableColumn;
import xfe.ui.table.Tables;
import xfe.util.Util;
import xstr.session.ObservableReplyRow;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

public class DealsTable extends TableView<ObservableReplyRow> {
    private BiConsumer<TableCell<ObservableReplyRow, BigDecimal>, BigDecimal> priceFormatter;

    public DealsTable() {
        setPlaceholder(Tables.stripedRowCSSPlaceholder());
        setRowFactory(tableView -> new DealsTableRow());

        TableColumn<ObservableReplyRow, String> secCol = new AlignedTableColumn<>("Instrument", HPos.LEFT);
        secCol.setId("deals-instrument-column");
        secCol.getStyleClass().add("xfe-bold-text");
        secCol.setCellValueFactory(DealsTable::call);
        getColumns().add(secCol);

        TableColumn<ObservableReplyRow, BigDecimal> priceCol = new AlignedTableColumn<>("Price", HPos.RIGHT);
        priceCol.setId("deals-price-column");
        priceCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpDeal.price));
        priceCol.setCellFactory(param -> new TableCell<ObservableReplyRow, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal item, boolean empty) {
                super.updateItem(item, empty);
                setText(null);
                if (item != null && !empty) {
                    if (priceFormatter != null) {
                        priceFormatter.accept(this, item);
                    } else {
                        setText(item.toString());
                    }
                }
            }
        });
        getColumns().add(priceCol);

        TableColumn<ObservableReplyRow, Double> qtyCol = new AlignedTableColumn<>("Total", HPos.RIGHT);
        qtyCol.setId("deals-total-column");
        qtyCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpDeal.quantity));
        getColumns().add(qtyCol);

        TableColumn<ObservableReplyRow, Integer> buySellCol = new AlignedTableColumn<>("B/S", HPos.CENTER);
        buySellCol.setId("deals-bs-column");
        buySellCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpDeal.buySell));
        buySellCol.setCellFactory(param -> new TableCell<ObservableReplyRow, Integer>() {
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null) {
                    setText(null);
                } else {
                    setText(AmpDeal.getBuySell(item));
                }
            }
        });
        getColumns().add(buySellCol);

        TableColumn<ObservableReplyRow, Date> timeCol = new AlignedTableColumn<>("Time", HPos.RIGHT);
        timeCol.setId("deals-time-column");
        timeCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpDeal.dealTime));
        timeCol.setCellFactory(param -> new TableCell<ObservableReplyRow, Date>() {
            @Override
            protected void updateItem(Date item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null) {
                    setText(null);
                } else {
                    setText(Util.formatTime(item));
                }
            }
        });
        getColumns().add(timeCol);
    }

    private static ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableReplyRow, String> cd) {
        return new ReadOnlyObjectWrapper(Util.stripper(cd.getValue().getProperty(AmpDeal.secCode).get(), "UKT"));
    }

    public void setPriceFormatter(BiConsumer<TableCell<ObservableReplyRow, BigDecimal>, BigDecimal> priceFormatter) {
        this.priceFormatter = priceFormatter;
    }

    /**
     * Returns all the deals id data. Used for testing purpose.
     *
     * @return List of deal id data.
     */
    public List<DealIdData> getDealIds() {
        return getItems().stream().map(DealIdData::new).collect(Collectors.toList());
    }
}
