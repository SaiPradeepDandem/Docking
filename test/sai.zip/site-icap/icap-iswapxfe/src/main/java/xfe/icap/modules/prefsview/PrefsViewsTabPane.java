package xfe.icap.modules.prefsview;

import java.util.*;
import java.util.Map.Entry;

import xfe.ui.InitialisableView;
import xfe.ui.PrefsViewFactory;
import xfe.ui.SaveOnCloseView;
import xfe.ui.notifications.ModalAlertModule;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.layout.*;
import org.slf4j.*;

import javafx.scene.control.Tab;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;

class PrefsViewsTabPane {
   private static final Logger logger = LoggerFactory.getLogger(PrefsViewsTabPane.class);
   private final ModalAlertModule notifier;
   private final Runnable closeMe;
   private String modifiedTitle = "";
   private final Map<PrefsViewFactory, Tab> viewSpecsToTabs = new HashMap<>();
   private final Map<PrefsViewFactory, InitialisableView> viewSpecsToViews = new HashMap<>();
   private boolean justCreated;

   VBox root = new VBox() {{
      this.getStyleClass().add("xfe-prefs-views-container");
   }};

   private final TabPane tabPane = new TabPane() {
      {
         setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);
      }
   };

   PrefsViewsTabPane(ModalAlertModule notifier,
                     List<PrefsViewFactory> views,
                     PrefsViewFactory initiator,
                     Runnable closeMeHandler) {
      justCreated = true;
      this.notifier = notifier;
      closeMe = closeMeHandler;

      Collections.sort(views, (o1, o2) -> Integer.compare(o1.getLeftPriority(), o2.getLeftPriority()));
      for (PrefsViewFactory viewSpec : views) {
         Tab tab = new Tab();
         tab.setText(viewSpec.getViewName());
         tabPane.getTabs().add(tab);
         viewSpecsToTabs.put(viewSpec, tab);

         tab.selectedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue) {
               setTabContent(viewSpec, tab);
            }
         });
      }

      setTabContent(initiator, viewSpecsToTabs.get(initiator));

      HBox ok_cancel = new HBox();
      ok_cancel.setSpacing(10);
      ok_cancel.setAlignment(Pos.CENTER_RIGHT);
      Button okButton = new Button("OK");
      okButton.setPrefWidth(50);
      okButton.setOnAction(event -> {
         save();
         closeMe.run();
      });

      Button cancelButton = new Button("Cancel");
      cancelButton.setPrefWidth(100);
      cancelButton.setOnAction(event -> tryClosing());

      ok_cancel.getChildren().addAll(okButton, cancelButton);

      root.getChildren().addAll(tabPane, ok_cancel);
      VBox.setVgrow(tabPane, Priority.ALWAYS);
   }

   private void setTabContent(PrefsViewFactory viewSpec, Tab tab) {
      if (viewSpecsToViews.get(viewSpec) == null && tab != null) {
         InitialisableView createdView = viewSpec.create();
         viewSpecsToViews.put(viewSpec, createdView);
         tab.setContent(createdView.getRootElement());
      }
   }

   Future<Boolean> tryClosing() {

      Promise<Boolean> ret = Futures.newPromise("tryClose");

      if (!isModified()) {
         closeMe.run();
         ret.setSuccess(true);
      } else {
         notifier.showModalView(SaveOnCloseView.create(
            getModifiedTitle(),
            () -> { // SAVE
               save();
               closeMe.run();
               ret.setSuccess(true);
            },
            () -> {
               closeMe.run();
               ret.setSuccess(true);
            },
            () -> { // CANCEL
               ret.setSuccess(false);
            }
         ));
      }

      return ret;
   }

   public void removeView(PrefsViewFactory view) {
      Tab t = viewSpecsToTabs.get(view);
      if (t != null) {
         tabPane.getTabs().remove(t);
         viewSpecsToTabs.remove(view);
         viewSpecsToViews.remove(view);
      }
   }

   void showView(PrefsViewFactory view) {
      // Finding the tab to select
      Tab newTab = viewSpecsToTabs.get(view);

      if (newTab == null) {
         logger.error("No tab exists for this view");
         return;
      }

      Tab selectedTab = newTab.getTabPane().getSelectionModel().getSelectedItem();

      if (selectedTab == newTab && !justCreated)
         tryClosing();
      else
         newTab.getTabPane().getSelectionModel().select(newTab);

      justCreated = false;
   }

   boolean isModified() {
      boolean isModified = false;
      modifiedTitle = "";
      for (Entry<PrefsViewFactory, InitialisableView> entry: viewSpecsToViews.entrySet()) {
         InitialisableView view = entry.getValue();

         if (view.isModified()) {
            if (modifiedTitle.isEmpty())
               modifiedTitle += "\n";
            else
               modifiedTitle += ", ";
            modifiedTitle += entry.getKey().getViewName();
            isModified = true;
         }
      }

      return isModified;
   }

   private String getModifiedTitle() {
      return modifiedTitle;
   }

   public void save() {
      for (Entry<PrefsViewFactory, InitialisableView> entry: viewSpecsToViews.entrySet()) {
         InitialisableView view = entry.getValue();
         view.save();
      }
   }
}
