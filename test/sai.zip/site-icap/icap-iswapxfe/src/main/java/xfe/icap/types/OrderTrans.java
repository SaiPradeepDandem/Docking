package xfe.icap.types;


import java.util.Date;

import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnConversionAccessor;
import xfe.icap.amp.AmpOrderTAcc;
import xstr.types.MapWrapper;
import xfe.ui.notifications.ModalAlertModule;
import com.omxgroup.syssrv.Duration;



public class OrderTrans extends AbstractOrderTrans {

	private static class RegularOrderAcc implements OrderAcc {

      @Override
      public AmpTreq transaction() {
         return AmpOrderTAcc.txn;
      }

      @Override
      public AsnConversionAccessor<String> secCode() {
         return AmpOrderTAcc.secCode;
      }

      @Override
      public AsnConversionAccessor<String> boardId() {
         return AmpOrderTAcc.boardId;
      }

      @Override
      public AsnConversionAccessor<Integer> type() {
         return AmpOrderTAcc.type;
      }

      @Override
      public AsnConversionAccessor<Boolean> isPrivate() {
         return AmpOrderTAcc.isPrivate;
      }

      @Override
      public AsnConversionAccessor<Boolean> isDoneIfTouched() {
         return AmpOrderTAcc.isDoneIfTouched;
      }

      @Override
      public AsnConversionAccessor<Boolean> isTopCut() {
         return AmpOrderTAcc.isTopCut;
      }

      @Override
      public AsnConversionAccessor<Double> price() {
         return AmpOrderTAcc.price;
      }

      @Override
      public AsnConversionAccessor<Double> quantity() {
         return AmpOrderTAcc.quantity;
      }

      @Override
      public AsnConversionAccessor<Integer> duration() {
         return AmpOrderTAcc.durationType;
      }

      @Override
      public AsnConversionAccessor<Duration> durationTime() {
         return AmpOrderTAcc.durationTime;
      }

      @Override
      public AsnConversionAccessor<Double> visibleQuantity() {
         return AmpOrderTAcc.visibleQuantity;
      }

      @Override
      public AsnConversionAccessor<Boolean> allowMultiMinFill() {
         return AmpOrderTAcc.allowMultiMinFill;
      }

      @Override
      public AsnConversionAccessor<Double> minFillQuantity() {
         return AmpOrderTAcc.minFillQuantity;
      }

      @Override
      public AsnConversionAccessor<Integer> buySell() {
         return AmpOrderTAcc.buySell;
      }

      @Override
      public AsnConversionAccessor<Boolean> isPublic() {
         return AmpOrderTAcc.isPublic;
      }

      @Override
      public AsnConversionAccessor<Integer> actionOnLogoff() {
         return AmpOrderTAcc.actionOnLogoff;
      }

      @Override
      public AsnConversionAccessor<Boolean> isShared() {
         return AmpOrderTAcc.shared;
      }

		@Override
		public AsnConversionAccessor<Date> pickupOrderDate() {
			return AmpOrderTAcc.pickOrderDate;
		}

		@Override
		public AsnConversionAccessor<Long> pickupOrderNo() {
			return AmpOrderTAcc.pickOrderNo;
		}

		@Override
		public AsnConversionAccessor<Long> pickupOrderNoSuffix() {
			return AmpOrderTAcc.pickOrderNoSuffix;
		}

		@Override
		public AsnConversionAccessor<String> introBrokerId() {
			return AmpOrderTAcc.introBrokerId;
		}


		@Override
		public AsnConversionAccessor<Date> crossingOrderDate() {
			return AmpOrderTAcc.crossLinkedOrderDate;
		}

		@Override
		public AsnConversionAccessor<Long> crossingOrderNo() {
			return AmpOrderTAcc.crossLinkedOrderNo;
		}

		@Override
		public AsnConversionAccessor<Long> crossingOrderNoSuffix() {
			return AmpOrderTAcc.crossLinkedOrderNoSuffix;
		}

      @Override
      public AsnConversionAccessor<Boolean> isCloneIntoRFS() {
         return AmpOrderTAcc.cloneIntoRFS;
      }

      @Override
      public AsnConversionAccessor<MapWrapper> extraField() {
         return AmpOrderTAcc.extrafields;
      }
   }

	public OrderTrans(ModalAlertModule notifier) {
		super(notifier, new RegularOrderAcc());
	}
}
