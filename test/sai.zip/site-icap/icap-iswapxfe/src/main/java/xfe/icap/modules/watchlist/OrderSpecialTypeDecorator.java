package xfe.icap.modules.watchlist;

import javafx.scene.control.TableColumn.CellDataFeatures;
import xfe.util.Constants;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import javafx.util.Callback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.session.QueryReplyRow;
import xstr.amp.AsnConversionAccessor;
import xstr.util.Fx;
import xstr.session.ObservableReplyRow;

public abstract class OrderSpecialTypeDecorator {
	private static final Logger logger = LoggerFactory.getLogger(OrderSpecialTypeDecorator.class);

	public static class OrderSpecialType {
      static final String strRegular = ""; // Explicitly leave this blank to reduce visual noise
      static final String strImplied = "Imp";
      static final String strIndicative = "Ind";
      static final String strOCO = "OCO";
      static final String strN_Implied = "I^n";
      static final String strSpreadoverimplied = "EFI";
      static final String strEFPSpread = "EFC";
      static final String strSpreadover_N_Implied = "so^n";
      static final String strNonScaling = "NS";
      static final String strTracking = "Trk";
      static final String strUnknown = "";
		static final ObservableValue<String> Regular = Fx.constOf(strRegular); // Explicitly leave this blank to reduce visual noise
		static final ObservableValue<String> Implied = Fx.constOf(strImplied);
		static final ObservableValue<String> Indicative = Fx.constOf(strIndicative);
      static final ObservableValue<String> OCO = Fx.constOf(strOCO);
		static final ObservableValue<String> N_Implied = Fx.constOf(strN_Implied);
		static final ObservableValue<String> Spreadoverimplied = Fx.constOf(strSpreadoverimplied);
		static final ObservableValue<String> EFPSpread = Fx.constOf(strEFPSpread);
		static final ObservableValue<String> Spreadover_N_Implied = Fx.constOf(strSpreadover_N_Implied);
		static final ObservableValue<String> NonScaling = Fx.constOf(strNonScaling);
		static final ObservableValue<String> Tracking = Fx.constOf(strTracking);
		static final ObservableValue<String> Unknown = Fx.constOf(strUnknown);
	}

	public static ObservableValue<String> getObservable(String value) {
		if (value != null && !value.isEmpty()) {
			if ("Regular".equals(value))
				return OrderSpecialType.Regular;
			else if ("Implied".equals(value))
				return OrderSpecialType.Implied;
			else if (Constants.PRICE_TYPE_INDICATIVE.equals(value))
				return OrderSpecialType.Indicative;
			else if ("Auto OCO".equals(value))
				return OrderSpecialType.OCO;
			else if ("N Implied".equals(value))
				return OrderSpecialType.N_Implied;
			else if ("SpreadoverImplied".equals(value))
				return OrderSpecialType.Spreadoverimplied;
			else if ("EFPSpread".equals(value))
				return OrderSpecialType.EFPSpread;
			else if ("Spreadover N Implied".equals(value))
				return OrderSpecialType.Spreadover_N_Implied;
			else if ("NonScaling".equals(value))
				return OrderSpecialType.NonScaling;
			else if ("Tracking".equals(value))
				return OrderSpecialType.Tracking;
			logger.debug("Order type string not found: {} - Returning value as-is.", value);
			return Fx.constOf(value);
		} else {
			return OrderSpecialType.Unknown;
		}
	}

   public static String getOrderTypeDisplayString(String value) {
      if (value != null && !value.isEmpty()) {
         if ("Regular".equals(value))
            return OrderSpecialType.strRegular;
         else if ("Implied".equals(value))
            return OrderSpecialType.strImplied;
         else if (Constants.PRICE_TYPE_INDICATIVE.equals(value))
            return OrderSpecialType.strIndicative;
         else if ("Auto OCO".equals(value))
            return OrderSpecialType.strOCO;
         else if ("N Implied".equals(value))
            return OrderSpecialType.strN_Implied;
         else if ("SpreadoverImplied".equals(value))
            return OrderSpecialType.strSpreadoverimplied;
         else if ("EFPSpread".equals(value))
            return OrderSpecialType.strEFPSpread;
         else if ("Spreadover N Implied".equals(value))
            return OrderSpecialType.strSpreadover_N_Implied;
         else if ("NonScaling".equals(value))
            return OrderSpecialType.strNonScaling;
         else if ("Tracking".equals(value))
            return OrderSpecialType.strTracking;
         logger.debug("Order type string not found: {} - Returning value as-is.", value);
         return value;
      } else {
         return OrderSpecialType.strUnknown;
      }
   }

   public static String getString(String value) {
		if (value != null && !value.isEmpty()) {
			return getOrderTypeDisplayString(value);
		} else {
			return "";
		}
	}

	public static <T extends QueryReplyRow> Callback<CellDataFeatures<T, String>, ObservableValue<String>>
	orderSpecialType(AsnConversionAccessor<String> acc) {
		return paramP -> {
            QueryReplyRow row = paramP.getValue();
            if (row != null)
                return getObservable(row.getValue(acc));
            else
                return OrderSpecialType.Unknown;
        };
	}

	public static Callback<ObservableReplyRow, ObservableValue<String>>
	orderSpecialTypeObs(AsnConversionAccessor<String> acc) {
		return row -> {
            if (row != null) {
                return new OrderSpecialTypeBinding(row, acc);
            }
            return OrderSpecialType.Unknown;
        };
	}

	private static class OrderSpecialTypeBinding extends ObjectBinding<String> {
		private final ObservableObjectValue<String> val;
		public OrderSpecialTypeBinding(ObservableReplyRow row, AsnConversionAccessor<String> acc) {
			this.val = row.getProperty(acc);
			super.bind(val);
		}

		@Override
		protected String computeValue() {
			return getString(val.getValue());
		}

	}

	public static boolean isIndicativePrice(String priceType){
	   return Constants.PRICE_TYPE_INDICATIVE.equals(priceType);
	}
}
