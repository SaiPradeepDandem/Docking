package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.acc.AmpAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;

public class AmpGroupUser extends AmpAccessor{
   public static final  AmpQreq req = AMP.qREQ("groupUserReq");
   public static final  AmpQrep rep = AMP.qREP("groupUserRep");

   public static final String DESK = "creditDesk";

   public static final AsnConversionAccessor<String> groupType = acc(AMP.qREQ("groupUserReq.groupType"), String.class);

   public static final AsnConversionAccessor<String> groupId =     acc(AMP.qREP("groupUserRep.groupUserId.groupId"), String.class);
   public static final AsnConversionAccessor<String> userId = acc(AMP.qREP("groupUserRep.groupUserId.userId"), String.class);
}
