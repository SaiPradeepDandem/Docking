/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xfe.icap.types;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderMethods_v3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.types.Identifier;
import xfe.types.OrderMethods;
import xfe.types.Security;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AmpService;
import xstr.amp.AsnAccessor;
import xstr.session.QueryReplyRow;
import xstr.util.Tuple;
import xstr.util.Tuple2;

import java.util.Date;

/**
 * @author KEWA
 */
public class IcapSecurity implements Security {
   public static final String rep = "icapSecBoardTrim2Rep";

   public enum Member implements Identifier<AmpQrep> {
      SECCODE(rep + ".secBoardId.secCode"),
      SEC_CLASS_ID(rep + ".secClassId"),
      BOARD_ID(rep + ".secBoardId.boardId"),
      INDEX(rep + ".secBoardIdx"),

      PRICE_DECIMALS(rep + ".priceEntryDecimals"),
      QUANTITY_DECIMALS(rep + ".quantityDecimals"),

      PRICE_STEPARRAY_ID(rep + ".minSpinPriceStepArrayId"),
      QUANTITY_STEPARRAY_ID(rep + ".minSpinQtyStepArrayId"),

      BID_USER_ID(rep + ".bidUserId"),
      OFFER_USER_ID(rep + ".offerUserId"),
      // BID_OPERATOR_ID(AMP.qREP("icapSecBoardTrim2Rep.bidOperatorId")),
      // OFFER_OPERATOR_ID(AMP.qREP("icapSecBoardTrim2Rep.offerOperatorId")),
      BID_ORDER_ID(rep + ".bidOrderId"),
      OFFER_ORDER_ID(rep + ".offerOrderId"),
      BID_ORDERTYPE(rep + ".bidSpecialOrderType"),
      OFFER_ORDERTYPE(rep + ".offerSpecialOrderType"),
      // BID_ORDER_SHARED(AMP.qREP("icapSecBoardTrim2Rep.bidShared")),
      // OFFER_ORDER_SHARED(AMP.qREP("icapSecBoardTrim2Rep.offerShared")),
      BID_NIMPLY(rep + ".nLevelImpBidPrice"),
      OFFER_NIMPLY(rep + ".nLevelImpOfferPrice"),

      BID_DEPTH(rep + ".bidDepth"),
      OFFER_DEPTH(rep + ".offerDepth"),

      BID_PRICE(rep + ".bidPrice"),
      OFFER_PRICE(rep + ".offerPrice"),

      LAST_PRICE(rep + ".lastPrice"),
      LAST_QUANTITY(rep + ".lastQuantity"),
      UL_PRICE(rep + ".underlyingPrice"),

      NUM_TRADES(rep + ".numTrades"),

      BID_ORDER_DATE(rep + ".bidOrderId.orderDate"),
      OFFER_ORDER_DATE(rep + ".offerOrderId.orderDate"),

      ORDER_METHODS(rep + ".orderMethods");

      // private String fieldId;
      private final AmpQrep fieldId;
      private final AsnAccessor accessor;

      Member(String id) {
         fieldId = new AmpQrep(id);
         accessor = AmpService.INSTANCE.getAccessor(fieldId);
      }

      @Override
      public AmpQrep getId() {
         return fieldId;
      }
   }

   private static final Logger logger = LoggerFactory.getLogger(IcapSecurity.class);
   private final QueryReplyRow data;

   public IcapSecurity(QueryReplyRow data) {
      if (data == null) {
         throw new NullPointerException();
      }

      this.data = data;
   }

//    private Object getValue(Member field) throws AsnTypeException{
//        return data.getValue(field.accessor);
//    }

   private Asn1Type getAsn(Member field) {
      return data.getAsn(field.accessor);
   }

   public boolean isDoneIfTouchedSupported() {
      AmpOrderMethods_v3 orderMethods = (AmpOrderMethods_v3) getAsn(Member.ORDER_METHODS);
      return orderMethods.isSet(OrderMethods.DONEIFTOUCHED.ordinal());
   }

   public boolean isTopCutSupported() {
      AmpOrderMethods_v3 orderMethods = (AmpOrderMethods_v3) getAsn(Member.ORDER_METHODS);
      return orderMethods.isSet(OrderMethods.TOPCUT.ordinal());
   }

   /*
    * (non-Javadoc)
    *
    * @see com.nomx.domain.Security#getSecCode()
    */
   @Override
   public String getSecCode() {
      return data.getValue(AmpIcapSecBoardTrim2.secCode);
   }

   /*
    * (non-Javadoc)
    *
    * @see com.nomx.domain.Security#getBoardId()
    */
   @Override
   public String getBoardId() {
      return data.getValue(AmpIcapSecBoardTrim2.boardId);
   }

   public Long getSpinPriceStepArrayId() {
      return data.getValue(AmpIcapSecBoardTrim2.minSpinPriceStepArrayId);
   }

   public Long getSpinQuantityStepArrayId() {
      return data.getValue(AmpIcapSecBoardTrim2.minSpinQtyStepArrayId);
   }

   public Long getIndex() {
      return data.getValue(AmpIcapSecBoardTrim2.secBoardIdx);
   }

   public Double getBidPrice() {
      return data.getValue(AmpIcapSecBoardTrim2.bidPrice_d);
   }

   public Double getOfferPrice() {
      return data.getValue(AmpIcapSecBoardTrim2.offerPrice_d);
   }

   public Double getNImpOfferPrice() {
      return data.getValue(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d);
   }

   public Double getNImpBidPrice() {
      return data.getValue(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d);
   }

   public Double getBidQuantity() {
      return data.getValue(AmpIcapSecBoardTrim2.bidDepth_d);
   }

   public Double getOfferQuantity() {
      return data.getValue(AmpIcapSecBoardTrim2.offerDepth_d);
   }

   public Tuple2<String, String> getSecBoard() {
      return Tuple.of(getSecCode(), getBoardId());
   }

   @Override
   public double getDefualtQuantity() {
      return data.getValue(AmpIcapSecBoardTrim2.defaultQty_d);
   }

   @Override
   public Date getIssueDate() {
      return data.getValue(AmpIcapSecBoardTrim2.issueDate);
   }

   @Override
   public Date getMaturityDate() {
      return null;
   }

   @Override
   public String getParentSecCode() {
      return data.getString(AmpIcapSecBoardTrim2.parentSecCode);
   }

   @Override
   public String getParentBoardId() {
      return data.getString(AmpIcapSecBoardTrim2.parentBoardId);
   }
}
