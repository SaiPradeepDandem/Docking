package xfe.icap.modules.tabeditorview;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringExpression;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableIntegerValue;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import xfe.icap.modules.watchlist.VirtualReference;
import xfe.modules.watchlist.InstrumentSecurityTreeNode;
import xfe.types.Instrument;
import xfe.types.SecBoard;
import xfe.types.StrategyInfo;
import xstr.util.Fun1;
import xstr.util.Fx;

import java.util.Collections;
import java.util.Comparator;
import java.util.Set;

public class InstrumentTreeNode implements InstrumentSecurityTreeNode {
   private final Instrument instrument;
   private final BooleanProperty allSelectedProperty = new SimpleBooleanProperty();
   private final BooleanProperty someSelectedProperty = new SimpleBooleanProperty();
   private final ObservableSet<SecBoard> selectableInstruments;
   private final ObservableSet<SecBoard> selectedInstruments;
   private final BooleanProperty selectedInstrumentsGateOpen = new SimpleBooleanProperty(true);
   private final VirtualReference<ObservableList<InstrumentSecurityTreeNode>> securityNodeListRef;
   private final ObservableIntegerValue instrumentCount;

   InstrumentTreeNode(Instrument instrument, ObservableSet<SecBoard> selectableInstruments, ObservableSet<SecBoard> selectedInstruments, ObservableIntegerValue instrumentCount) {
      this.instrument = instrument;

      if (instrumentCount == null) {
         throw new NullPointerException();
      }

      this.instrumentCount = instrumentCount;
      this.selectableInstruments = selectableInstruments;
      this.selectedInstruments = selectedInstruments;
      VirtualReference<ObservableSet<InstrumentSecurityTreeNode>> securityNodesRef = new VirtualReference<ObservableSet<InstrumentSecurityTreeNode>>() {
         @Override
         protected ObservableSet<InstrumentSecurityTreeNode> materialize() {

            return Fx.map(selectableInstruments, new Fun1<SecBoard, InstrumentSecurityTreeNode>() {
               @Override
               public InstrumentSecurityTreeNode call(SecBoard secBoard) {
                  return new SecurityTreeNode(secBoard, selectedInstruments, selectedInstrumentsGateOpen);
               }
            });
         }
      };

      this.securityNodeListRef = new VirtualReference<ObservableList<InstrumentSecurityTreeNode>>() {
         @Override
         protected ObservableList<InstrumentSecurityTreeNode> materialize() {

            return Fx.sortBy(securityNodesRef.get(), (o1, o2) -> {

               // If these are not GILTs we still use sorting by maturity dates as before
               if (!(o1.isGiltsStrategy() && o2.isGiltsStrategy()))
                  return Comparator.comparingLong(InstrumentSecurityTreeNode::getMaturityDate).thenComparing(node -> node.displayProperty().get()).compare(o1, o2);
               else {
                  // handling sorting for all gits strategies

                  // In this case we need to sort based on the type of security
                  // It could be:
                  // Outright (eg ULTRA SHO	RTS, SHORTS, MEDIUMS, LONGS, INDEX-LINKED)
                  // Spread products (eg SWITCHES, LINKER SWITC, BREAK EVENS, BMK/ IL)
                  // Gross Basis products (eg GROSS BASIS)
                  // Butterfly products (eg WCLKBF, LINKER BFLY)
                  // Box Break even products (eg BOX BREAK EV)
                  // non-deliverable Gilt Basis products (eg GILTBASISND, ILBASISND)

                  // For lack of a better way, this comparison is based on number of legs
                  // Ii is assumed that two securities belonging to the same product would have the same number of legs
                  return Comparator.comparing(InstrumentSecurityTreeNode::getStrategyInfo).compare(o1, o2);
               }
            });

         }
      };

      ObservableSet<SecBoard> unselectedInstrumentsBinding = Fx.minus(selectableInstruments, selectedInstruments);
      ObservableIntegerValue unselectedSizeBinding = Fx.sizeOfSet(unselectedInstrumentsBinding);
      ObservableIntegerValue selectableSizeBinding = Fx.sizeOfSet(selectableInstruments);

      allSelectedProperty.bind(
         Bindings.and(
            Bindings.notEqual(selectableSizeBinding, 0),
            Bindings.equal(unselectedSizeBinding, 0)));
      someSelectedProperty.bind(
         Bindings.and(
            Bindings.notEqual(unselectedSizeBinding, selectableSizeBinding),
            Bindings.notEqual(unselectedSizeBinding, 0)));
   }

   @Override
   public StringExpression displayProperty() {
      String displayName = instrument.getDisplayName();
      String instrumentName = instrument.getInstrumentId();
      displayName = displayName == null ? instrumentName : displayName;
      return Bindings.format("%s (%d)", displayName, instrumentCount);
   }

   @Override
   public String getInfoText() {
      return null;
   }

   @Override
   public ObservableList<InstrumentSecurityTreeNode> getChildrenUnmodifiable() {
      return this.securityNodeListRef.get();
   }

   @Override
   public String toString() {
      return instrument.getInstrumentId();
   }

   @Override
   public int hashCode() {
      String instrumentName = instrument.getInstrumentId();
      return instrumentName != null ? instrumentName.hashCode() : 0;
   }

   @Override
   public boolean equals(Object other) {
      String instrumentName = instrument.getInstrumentId();
      if (instrumentName != null && other instanceof InstrumentTreeNode) {
         InstrumentTreeNode that = (InstrumentTreeNode)other;

         return instrumentName.equals(that.instrument.getInstrumentId());
      }

      return false;
   }

   public BooleanProperty allSelectedProperty() {
      return allSelectedProperty;
   }

   public BooleanProperty someSelectedProperty() {
      return someSelectedProperty;
   }

   @Override
   public void toggleSelected() {
      try {
         selectedInstrumentsGateOpen.setValue(false);

         if (allSelectedProperty.get()) {
            selectedInstruments.removeAll(selectableInstruments);
         } else {
            selectedInstruments.addAll(selectableInstruments);
         }
      } finally {
         selectedInstrumentsGateOpen.setValue(true);
      }
   }

   @Override
   public long getMaturityDate() {
      return 0;
   }

   @Override
   public Long getSortOrder() {
      return instrument.getSortOrder();
   }

   @Override
   public boolean isGiltsStrategy() {
      for (SecBoard s: selectableInstruments) {
         if (!s.isStrategy() || !s.isGilt()) return false;
      }

      for (SecBoard s: selectedInstruments) {
         if (!s.isStrategy() || !s.isGilt()) return false;
      }

      return true;
   }

   @Override
   public StrategyInfo getStrategyInfo() {
      return null;
   }

   @Override
   public Set<SecBoard> getSecurities() {
      return Collections.unmodifiableSet(selectableInstruments);
   }
}
