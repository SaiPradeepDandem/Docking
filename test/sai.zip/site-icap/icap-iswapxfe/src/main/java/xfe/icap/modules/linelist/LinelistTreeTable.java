package xfe.icap.modules.linelist;

import com.nomx.persist.linelist.LineList;
import com.nomx.persist.linelist.Participant;
import xstr.util.Fx;
import xfe.ui.list.XfeGroup;
import xfe.ui.list.XfeItem;
import xfe.ui.table.Tables;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static xfe.icap.modules.linelist.DragDropHandler.ADD_TO_SHORTCUT;

public class LinelistTreeTable extends TreeTableView<XfeItem> {

   private static final Logger logger = LoggerFactory.getLogger(LinelistTreeTable.class);
   private final LinelistModule module;
   private final TreeItem<XfeItem> root = new TreeItem(new XfeItem() {
      @Override
      public void setHK(String hotkey) {
      }

      @Override
      public void removeFromGroup() {
      }

      @Override
      public void setGroup(XfeGroup<? extends XfeItem> group) {
      }

      @Override
      public XfeGroup<? extends XfeItem> getGroup() {
         return null;
      }

      @Override
      public String getHK() {
         return null;
      }

      @Override
      public String getId() {
         return "root";
      }

      @Override
      public String getParentfirmId() {
         return null;
      }

      @Override
      public String getSubTitle() {
         return null;
      }

      @Override
      public XfeItem copy() {
         return null;
      }

      @Override
      public void setShortcut(boolean isAdd) {

      }

      @Override
      public boolean isShortcut() {
         return false;
      }

      @Override
      public boolean isDraggable() {
         return false;
      }

      @Override
      public boolean lineListRenamed(Object obj) {
         return false;
      }
   });

   void rebuildTree() {
      ObservableList<TreeItem<XfeItem>> children = root.getChildren();
      children.clear();
      if (module.getLinelist() != null) {
         List<LineList> lines = module.getLinelist().get();
         logger.info("Linelist's lines are: {}", lines);
         lines.stream().filter(LineList::isShortcut).forEach(aLine -> {
            TreeItem<XfeItem> lineListItem = new TreeItem<>(aLine);
            for (XfeItem trader : aLine.getItems()) {
               TreeItem traderItem = new TreeItem(trader);
               logger.info("Adding trader item: {}", traderItem);
               lineListItem.getChildren().add(traderItem);
            }
            children.add(lineListItem);
         });
      }
      this.select(module.xfeSessionModule.onBehalfTrader.get());
   }

   LinelistTreeTable(LinelistModule module) {
      this.module = module;
      this.setPlaceholder(Tables.stripedRowCSSPlaceholder());
      root.setExpanded(true);
      this.setRoot(root);
      this.setShowRoot(false);
      setupColumns();
      logger.info("Calling rebuildTree() from LinelistTreeTable ctor");
      rebuildTree();
      this.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
         if (newValue != null) {
            if(newValue.isLeaf()){
               if(module.isUpdatingLineList) return;
               XfeItem item = newValue.getValue();
               if (item instanceof Participant) {
                  Participant par = (Participant) item;
                  logger.debug(LinelistTreeTable.this+" selected "+par);
                  if (!par.equals(module.onBehalfTrader.get())) {
                     par.eventSource = LinelistTreeTable.this;
                     module.onBehalfTrader.set(par);
                  }
               }
            }else{
               Fx.runLater(()->LinelistTreeTable.this.select(module.onBehalfTrader.get()));
            }
         }
      });

      this.setOnDragDetected(dragEvent ->{
         TreeItem<XfeItem> item = LinelistTreeTable.this.getSelectionModel().getSelectedItem();
         Object obj;
         if(item!=null && (obj=item.getValue()) instanceof Participant) {
            Dragboard db = LinelistTreeTable.this.startDragAndDrop(ADD_TO_SHORTCUT);
            ClipboardContent content = new ClipboardContent();
            content.put(XfeItem.dataFormat, obj);
            content.put(XfeItem.dataFormat_linelistUUID,((Participant)obj).getGroup().getUuid());
            content.put(Participant.dataFormat_add,"");
            db.setContent(content);
            logger.info("Dragged {}", content);
         }
         dragEvent.consume();
      });


   }

   private void setupColumns() {
      TreeTableColumn<XfeItem, String> traderColumn =new TreeTableColumn<>("Trader");
      traderColumn.setPrefWidth(150);
      traderColumn.setCellValueFactory(param -> new ReadOnlyStringWrapper(param.getValue().getValue().getDisplayName()));

      TreeTableColumn<XfeItem, String> firmColumn =new TreeTableColumn<>("Firm");
      firmColumn.setPrefWidth(106);
      firmColumn.setCellValueFactory(param -> new ReadOnlyStringWrapper(param.getValue().getValue().getParentfirmId()));

      TreeTableColumn<XfeItem, String> hkColumn =new TreeTableColumn<>("HK");
      hkColumn.setCellValueFactory(param -> new ReadOnlyStringWrapper(param.getValue().getValue().getHK()));
      hkColumn.setPrefWidth(25);

      TreeTableColumn<XfeItem, String> ibColumn = new TreeTableColumn<>("IB");
      ibColumn.setCellValueFactory(param -> {
         if (param != null && param.getValue() != null && param.getValue().getValue() != null) {
            return new ReadOnlyStringWrapper(param.getValue().getValue().getSubTitle());
         }else{
            return new ReadOnlyStringWrapper("emptyNode!");
         }
      });
      ibColumn.setPrefWidth(75);

      this.getColumns().addAll(traderColumn, firmColumn, hkColumn, ibColumn);
   }

   public void select(Participant par) {
      TreeItem<XfeItem> currentSelection = this.getSelectionModel().getSelectedItem();
      for(TreeItem<XfeItem>  item: root.getChildren()){
         for(TreeItem<XfeItem> traderItem:item.getChildren()){
            if (traderItem.getValue().equals(par) || traderItem.getValue().lineListRenamed(par)) {
               item.setExpanded(true);
               if (currentSelection == null || !currentSelection.equals(traderItem))
               this.getSelectionModel().select(traderItem);
               return;
            }
         }
      }
      this.getSelectionModel().clearSelection();
   }

   void dispose(){
      root.getChildren().clear();
   }
}
