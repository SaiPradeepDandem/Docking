package xfe.icap.modules.settingsview;

import xstr.util.concurrent.Future;

public interface SettingsViewTab {
   boolean isModified();

   Future<Void> save();

   Future<Void> reset();

   void resetForTestFX();

   default void onShown(){}
}
