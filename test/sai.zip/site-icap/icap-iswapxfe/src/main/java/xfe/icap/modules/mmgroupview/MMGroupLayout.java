package xfe.icap.modules.mmgroupview;

import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import xfe.icap.modules.layout.midi.MidiLayoutViews;

/**
 * Controller for MMGroupLayout.fxml
 */
public class MMGroupLayout {

   @FXML
   private StackPane root;

   @FXML
   public void initialize(){
      root.setId(MidiLayoutViews.MMGROUPVIEW);
   }
   public StackPane getRoot() {
      return root;
   }
}
