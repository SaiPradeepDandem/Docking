package xfe.icap.ui;

import java.io.IOException;
import java.util.List;

import com.omxgroup.xstream.amp.AmpRFQStatus;
import javafx.beans.property.*;
import javafx.fxml.*;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class RfqTimerPane {

   @FXML private GridPane rfqTimerRoot;
   @FXML private Label rfqInstrument;
   @FXML private Label minutes;
   @FXML private Label seconds;
   @FXML private Label mLabel;

   private final boolean needPrefixSecCode;
   private String secCode;

   public RfqTimerPane(boolean needPrefixSecCode) {
      this.needPrefixSecCode = needPrefixSecCode;
   }

   public static RfqTimerPane load(boolean needPrefixSecCode){
      FXMLLoader ldr = new FXMLLoader(RfqTimerPane.class.getResource("RfqTimePane.fxml"));
      RfqTimerPane pane = new RfqTimerPane(needPrefixSecCode);
      ldr.setController(pane);
      try {
         ldr.load();
         return pane;
      } catch (IOException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      return null;
   }

   @FXML private void initialize(){
      rfqTimerRoot.setVisible(false);
   }

   public void addTextStyle(String style){
      List<String> styles = rfqInstrument.getStyleClass();
      if(!styles.contains(style)){
         styles.add(style);
      }
   }

   public void removeTextStyle(String style){
      rfqInstrument.getStyleClass().removeAll(style);
   }


   public Node getRootElement(){
      return rfqTimerRoot;
   }

   public void setTime(long timeInSeconds){
      long m = timeInSeconds / 60;
      if(m <= 0) {
         minutes.setVisible(false);
         mLabel.setVisible(false);
      } else {
         minutes.setVisible(true);
         mLabel.setVisible(true);
      }
      long s = timeInSeconds % 60;
      String mStr = (m < 10 ? "0" : "") + m;
      String sStr = (s < 10 ? "0" : "") + s;
      minutes.setText(mStr);
      seconds.setText(sStr);
   }

   public void setVisible(boolean b) {
      rfqTimerRoot.setVisible(b);
   }


   public StringProperty instrTextProperty(){
      return rfqInstrument.textProperty();
   }

   public BooleanProperty visibleProperty() {
      return rfqTimerRoot.visibleProperty();
   }

   public void setText(long endingTimeInsecond, Integer rfqStatus) {
      setTime(endingTimeInsecond);
      String msg="";
      if (rfqStatus == AmpRFQStatus.initial) {
         msg = needPrefixSecCode ? secCode: "" + " Waiting for quotes ";
         addTextStyle("xfe-rfq-active-instrument");
      } else if (rfqStatus == AmpRFQStatus.active) {
         if (endingTimeInsecond < 10L) {
            msg = needPrefixSecCode ? secCode: ""+" ending ";
            removeTextStyle("xfe-rfq-active-instrument");
            addTextStyle("xfe-rfq-ending-instrument");
         } else {
            addTextStyle("xfe-rfq-active-instrument");
            msg = needPrefixSecCode ? secCode: ""+" is active ";
         }
      }
      instrTextProperty().set(msg);

   }

   public void clearText(){
      instrTextProperty().setValue("");
   }
   public void setSecCode(String secCode) {
      this.secCode = secCode;
   }
}
