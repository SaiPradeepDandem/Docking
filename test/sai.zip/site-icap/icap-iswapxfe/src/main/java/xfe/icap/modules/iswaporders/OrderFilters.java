package xfe.icap.modules.iswaporders;

import java.util.Date;
import java.util.Objects;

import com.google.common.base.Strings;
import com.omxgroup.xstream.amp.AmpOrderDuration;
import com.omxgroup.xstream.amp.AmpOrderStatus_v2;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;

import xstr.amp.ASN;
import xstr.types.*;
import xstr.util.StaticFilter;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.ObservableRowFilter;
import xstr.util.filter.RowFilters;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpOrderBookByOrder;
import xstr.session.ObservableReplyRow;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import xstr.util.Util;

import static xfe.icap.modules.iswaporders.OrderStatusDecorator.*;

public class OrderFilters {

   final ObservableRowFilter brokerShareFilter;
   final ObservableRowFilter onBehalOfTraderFilterForBroker ;
   final ObservableRowFilter onBehalOfTraderFilterForIB ;
   final ObservableRowFilter introBrokerShareFilter;
   final ObservableRowFilter myTradersFilter;
   public final DynamicFilter<ObservableReplyRow> isAmendable;
   public final DynamicFilter<ObservableReplyRow> isWithdrewable;
   public final XfeSession xfeSession;
   public final ObservableRowFilter amendable;

   public OrderFilters(XfeSession xfeSession){
	   this.xfeSession = xfeSession;
      String loggedOnUserId = xfeSession.getUnderlyingSession().getLoggedOnUserId();
      User loggedOnUser = xfeSession.getUnderlyingSession().getLoggedOnUser();
      StringProperty onBehalfTraderId = xfeSession.getUnderlyingSession().onBehalfTraderId;
      StringProperty onBehalfIB = xfeSession.getUnderlyingSession().onBehalfTraderIB;

      /**
       * Desk � Containing all orders entered by all brokers from the brokers firm (for ICAP brokers this means all ICAP brokers.
       * For Introducing Brokers this means all IBs from his firm).
       * Also a checkbox �My Traders� will be displayed in the title bar of the orders view to allow the broker to filter for orders entered by brokers on-behalf-of traders on his broker desk (ie those he can enter orders on-behalf-of).
       */
      brokerShareFilter = xfeSession.traderFirmMap == null ?
         ObservableRowFilter.alwaysFalse() :
         new ObservableRowFilter() {
            public ObservableBooleanValue accept(ObservableReplyRow row) {
               return new fxext.BooleanBinding() {
                  {
                     bind(xfeSession.traderFirmMap.readyPropertyRO);
                  }
                  @Override
                  protected boolean computeValue() {
                     String operatorId = row.getString(AmpManagedOrder.operatorId);
                     String operatorFirm = xfeSession.traderFirmMap.getFirmId(operatorId);
                     return xfeSession.getUnderlyingSession().getLoggedOnUserFirmId().equals(operatorFirm);
                  }
               };
            }
         };

      introBrokerShareFilter = xfeSession.traderFirmMap == null ?
         ObservableRowFilter.alwaysFalse() :
         new ObservableRowFilter() {
            public ObservableBooleanValue accept(ObservableReplyRow row) {
               return new fxext.BooleanBinding() {
                  {
                     bind(xfeSession.traderFirmMap.readyPropertyRO);
                  }
                  @Override
                  protected boolean computeValue() {
                     String operatorId = row.getString(AmpManagedOrder.operatorId);
                     String introBrokerId = row.getString(AmpManagedOrder.introBrokerId);
                     if (operatorId != null || introBrokerId == null)
                        return false;

                     String ibFirm = xfeSession.traderFirmMap.getFirmId(introBrokerId);
                     return xfeSession.getUnderlyingSession().getLoggedOnUserFirmId().equals(ibFirm);
                  }
               };
            }
         };

      myTradersFilter = xfeSession.traderFirmMap == null ?
         ObservableRowFilter.alwaysFalse() :
         new ObservableRowFilter() {
            public ObservableBooleanValue accept(ObservableReplyRow row) {
               return new fxext.BooleanBinding() {
                  {
                     bind(xfeSession.traderFirmMap.readyPropertyRO);
                  }
                  @Override
                  protected boolean computeValue() {
                     return xfeSession.traderFirmMap.isTraderCanOnBehalfof(row.getString(AmpManagedOrder.userId));
                  }
               };
            }
      };

      onBehalOfTraderFilterForBroker = new ObservableRowFilter() {
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {

               {
                  bind(xfeSession.getUnderlyingSession().onBehalfTraderId);
               }

               @Override
               protected boolean computeValue() {
                  String userId = row.getString(AmpManagedOrder.userId);
                  return userId!=null && userId.equals(xfeSession.getUnderlyingSession().onBehalfTraderId.get());
               }
            };
         }
      };

      onBehalOfTraderFilterForIB = new ObservableRowFilter() {
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {

               {
                  bind(xfeSession.getUnderlyingSession().onBehalfTraderId);
               }

               @Override
               protected boolean computeValue() {
                  if(row.getString(AmpManagedOrder.operatorId)!=null){
                     return false;
                  }
                  String userId = row.getString(AmpManagedOrder.userId);
                  return userId!=null && userId.equals(xfeSession.getUnderlyingSession().onBehalfTraderId.get());
               }
            };
         }
      };

      /*
       * If a broker selects an order that he entered himself then the order amendment buttons (eg tick up/down, refer, renew, off) will be enabled (even if the order was entered for someone other than the selected trader). Also, if a broker selects an order that
       * was entered by another broker then the broker must select the trader first before being able to amend it (ie traders must match or brokers must match)
       */
      if (loggedOnUser.isBroker()) {
         if (loggedOnUser.isIB()) {
            isAmendable = new ObservableRowFilter() {

               @Override
               public ObservableBooleanValue accept(ObservableReplyRow row) {
                  return new fxext.BooleanBinding() {
                     {
                        bind(xfeSession.getUnderlyingSession().onBehalfTraderId);
                     }

                     @Override
                     protected boolean computeValue() {
                        String ibId;
                        if(row.getValue(AmpManagedOrder.operatorId) != null || (ibId=row.getValue(AmpManagedOrder.introBrokerId)) == null){
                           return false;
                        }
                        if(loggedOnUserId.equals(ibId)){
                           return true;
                        }
                        String trader = xfeSession.getUnderlyingSession().onBehalfTraderId.get();
                        String userId = row.getValue(AmpManagedOrder.userId);
                        return   Objects.equals(trader, userId);
                     }
                  };
               }
            };
         } else {
            isAmendable = new ObservableRowFilter() {

               @Override
               public ObservableBooleanValue accept(ObservableReplyRow row) {
                  return new fxext.BooleanBinding() {
                     {
                        bind(xfeSession.getUnderlyingSession().onBehalfTraderId);
                     }

                     @Override
                     protected boolean computeValue() {
                        String opId = row.getValue(AmpManagedOrder.operatorId);
                        if(loggedOnUserId.equals(opId)){
                           return true;
                        }
                        if(opId == null && row.getValue(AmpManagedOrder.introBrokerId) == null){
                           return false;
                        }
                        String trader = xfeSession.getUnderlyingSession().onBehalfTraderId.get();
                        String userId = row.getValue(AmpManagedOrder.userId);
                        return  Objects.equals(trader, userId);
                     }
                  };
               }
            };
         }
      } else {
         isAmendable = isTraderSubmitOrder(loggedOnUserId);
      }

      if (loggedOnUser.isBroker()) {
         if (loggedOnUser.isIB()) {
            isWithdrewable = new ObservableRowFilter() {

               @Override
               public ObservableBooleanValue accept(ObservableReplyRow row) {
                  return new fxext.BooleanBinding() {

                     @Override
                     protected boolean computeValue() {
                        return   Objects.equals(loggedOnUserId,row.getValue(AmpManagedOrder.introBrokerId));
                     }
                  };
               }
            };
         } else { // for non-IB broker
            isWithdrewable = new ObservableRowFilter() {

               @Override
               public ObservableBooleanValue accept(ObservableReplyRow row) {
                  return new fxext.BooleanBinding() {
                     {
                     }

                     @Override
                     protected boolean computeValue() {
                        return  Objects.equals(loggedOnUserId, row.getValue(AmpManagedOrder.operatorId));
                     }
                  };
               }
            };
         }
      } else {
         isWithdrewable = isTraderOrder(loggedOnUserId);
      }

      amendable = new ObservableRowFilter() {
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               final ObservableObjectValue<Integer> prop = row.getProperty(AmpManagedOrder.orderStatus);

               {
                  super.bind(prop,onBehalfTraderId,onBehalfIB);
               }

               @Override
               protected boolean computeValue() {
                  Integer status = prop.getValue();

                  boolean statusMatch =  status != AmpOrderStatus_v2.withdrawn &&
                     status != AmpOrderStatus_v2.amended &&
                     status != AmpOrderStatus_v2.matched &&
                     status != AmpOrderStatus_v2.expired;
                  if(statusMatch) {
                     if (loggedOnUser.isTrader()) {
                        return row.getString(AmpManagedOrder.introBrokerId)==null && row.getString(AmpManagedOrder.operatorId)==null && loggedOnUserId.equals(row.getString(AmpManagedOrder.userId));
                     }else{
                        String opId = row.getString(AmpManagedOrder.operatorId);
                        String introId = row.getString(AmpManagedOrder.introBrokerId);
                        if(Strings.isNullOrEmpty(opId) && Strings.isNullOrEmpty(introId)){
                           return false;
                        }
                        if(loggedOnUser.isIB()){
                           return Strings.isNullOrEmpty(opId) && ( Objects.equals(row.getString(AmpManagedOrder.userId),onBehalfTraderId.get()) || Objects.equals(loggedOnUserId,row.getString(AmpManagedOrder.introBrokerId)));
                        }else if(loggedOnUser.isBroker()){
                           return Objects.equals(loggedOnUserId,row.getString(AmpManagedOrder.operatorId)) || (Objects.equals(onBehalfIB.get(),row.getString(AmpManagedOrder.introBrokerId)) && Objects.equals(onBehalfTraderId.get(),row.getString(AmpManagedOrder.userId)));
                        }
                     }
                  }
                  return false;
               }
            };
         }
      };

   }



   public static final DynamicFilter<ObservableReplyRow> isBid = RowFilters.equals(AmpManagedOrder.buySell, AmpOrderVerb.buy);
   public static final DynamicFilter<ObservableReplyRow> isOffer = RowFilters.equals(AmpManagedOrder.buySell, AmpOrderVerb.sell);
   public static final DynamicFilter<ObservableReplyRow> isBrokerOrder = RowFilters.notEmpty(AmpManagedOrder.operatorId).or(RowFilters.notEmpty(AmpManagedOrder.introBrokerId));
   public static final StaticFilter<ObservableReplyRow> isManaged = RowFilters.staticNotNull(AmpManagedOrder.managedOrderId);
   public static final DynamicFilter<ObservableReplyRow> isReferred = RowFilters.equals(AmpManagedOrder.orderStatus, PRIVATE_ORDER);
   public static final DynamicFilter<ObservableReplyRow> isWithdrawn = RowFilters.equals(AmpManagedOrder.orderStatus, WITHDRAWN);
   public static final DynamicFilter<ObservableReplyRow> isOpen = RowFilters.equals(AmpManagedOrder.orderStatus, OPEN);
   public static final DynamicFilter<ObservableReplyRow> isExpired = RowFilters.equals(AmpManagedOrder.orderStatus, EXPIRED);
   public static final DynamicFilter<ObservableReplyRow> isRfqFinished = RowFilters.equals(AmpManagedOrder.orderEvent,OrderEvent.rfqfinished);
   public static final DynamicFilter<ObservableReplyRow> isImmediateOrder = RowFilters.equals(AmpManagedOrder.durationType, AmpOrderDuration.immediate);
   public static final DynamicFilter<ObservableReplyRow> withBalance = RowFilters.greaterThan(AmpManagedOrder.balance_d,0);
   public static final DynamicFilter<ObservableReplyRow> isRfqExpiredOrder = isRfqFinished.and(isImmediateOrder.not().and(isExpired.and(withBalance)));
   public static final DynamicFilter<ObservableReplyRow> isEmbargoed = RowFilters.equals(AmpManagedOrder.orderStatus, EMBARGOED);
   public static final DynamicFilter<ObservableReplyRow> isOpenOrEmbargoed = isOpen.or(isEmbargoed);

   @SuppressWarnings("unchecked")
   public static DynamicFilter<ObservableReplyRow> isTraderSubmitOrder(String userId) {
      return DynamicFilter.of(Filters.and(
            RowFilters.equals(AmpManagedOrder.userId, userId),
            RowFilters.equals(AmpManagedOrder.operatorId, null),
            RowFilters.equals(AmpManagedOrder.introBrokerId, null)
            ));
   }

   public static DynamicFilter<ObservableReplyRow> isTraderOrder(String userId) {
      return RowFilters.equals(AmpManagedOrder.userId, userId);
   }

   public static DynamicFilter<ObservableReplyRow> isIntroBrokerOrder(String userId) {
      return RowFilters.equals(AmpManagedOrder.introBrokerId, userId);
   }

   public static DynamicFilter<ObservableReplyRow> isBrokerOrder(String userId) {
      return DynamicFilter.of(RowFilters.equals(AmpManagedOrder.operatorId, userId));
   }

   public static DynamicFilter<ObservableReplyRow> isFirmOrder(String firmId) {
      return DynamicFilter.of(RowFilters.equals(AmpManagedOrder.firmId, firmId));
   }


   public static DynamicFilter<ObservableReplyRow> isBrokerOrderForTrader(String traderId) {
      return DynamicFilter.of(Filters.and(isBrokerOrder, RowFilters.equals(AmpManagedOrder.userId, traderId)));
   }

   public static final DynamicFilter<ObservableReplyRow> isShared = DynamicFilter.of(Filters.and(
         RowFilters.notNull(AmpManagedOrder.shared),
         RowFilters.equals(AmpManagedOrder.shared, true)));

   public static final DynamicFilter<ObservableReplyRow> hasPermission = RowFilters.notEmpty(AmpManagedOrder.userId);

   public static final DynamicFilter<ObservableReplyRow> canRenew = DynamicFilter.of(Filters.and(
         hasPermission,
         RowFilters.equals(AmpManagedOrder.orderStatus, PRIVATE_ORDER)));


   public static final DynamicFilter<ObservableReplyRow> isStatusReferable =  DynamicFilter.of(Filters.and(
         hasPermission,
         Filters.or(
               RowFilters.equals(AmpManagedOrder.orderStatus, OPEN),
               RowFilters.equals(AmpManagedOrder.orderStatus, CLEARING_QUEUED))));


   public static final ObservableRowFilter canWithdraw = new ObservableRowFilter() {
      public javafx.beans.value.ObservableBooleanValue accept(ObservableReplyRow row) {
         return new fxext.BooleanBinding() {
            final ObservableObjectValue<Integer> prop = row.getProperty(AmpManagedOrder.orderStatus);

            {
               super.bind(prop);
            }

            @Override
            protected boolean computeValue() {
               Integer status = prop.getValue();
               return   status == OPEN
                     || status == INACTIVE_STOP
                     || status == UNPLACED
                     || status == UNPLACED_STOP
                     || status == UNAPPROVED
                     || status == UNCONFIRMED
                     || status == EMBARGOED
                     || status == CONDIRMED
                     || status == PENDING
                     || status == CLEARING_QUEUED
                     || status == PRIVATE_ORDER;
            }
         };
      }
   };

   public static StaticFilter<ObservableReplyRow> withTrader(String userId) {
      return new StaticFilter<ObservableReplyRow>() {
         @Override
         public boolean accept(ObservableReplyRow row) {
            return userId.equals(row.getValue(AmpManagedOrder.userId));
         }
      };
   }

   public static StaticFilter<ObservableReplyRow> withSecurity(String secCode, String boardId) {
      return new StaticFilter<ObservableReplyRow>() {
         @Override
         public boolean accept(ObservableReplyRow row) {
            return row.getValue(AmpManagedOrder.secCode).equals(secCode) &&
                  row.getValue(AmpManagedOrder.boardId).equals(boardId);
         }
      };
   }

   public static StaticFilter<ObservableReplyRow> withinTimeFrameWithBalance(Date startTime, Date endTime) {
      return new StaticFilter<ObservableReplyRow>() {
         @Override
         public boolean accept(ObservableReplyRow row) {
            Date orderTime = row.getValue(AmpManagedOrder.entryTime);
            Double balance  = row.getValue(AmpManagedOrder.balance_d);
            return balance!=null && balance>0 && orderTime.after(startTime) && orderTime.before(endTime);
         }
      };
   }

   public static StaticFilter<ObservableReplyRow> withSide(int side) {
      return new StaticFilter<ObservableReplyRow>() {
         @Override
         public boolean accept(ObservableReplyRow row) {
            return row.getValue(AmpManagedOrder.buySell).equals(side);
         }
      };
   }


   public static DynamicFilter<ObservableReplyRow> clonedOrder = new DynamicFilter<ObservableReplyRow>() {
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         return new BooleanBinding() {
            @Override
            protected boolean computeValue() {
               return  "Clone".equals(row.getValue(AmpManagedOrder.orderType));
            }
         };
      }
   };

   public static DynamicFilter<ObservableReplyRow> notClonedOrder = new DynamicFilter<ObservableReplyRow>() {
      @Override
      public ObservableBooleanValue accept(ObservableReplyRow row) {
         return new BooleanBinding() {
            @Override
            protected boolean computeValue() {
               return  !"Clone".equals(row.getValue(AmpManagedOrder.orderType));
            }
         };
      }
   };

   public DynamicFilter<ObservableReplyRow> withOrderId(ObservableObjectValue<Asn1Type> bidOrderId) {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               {
                  bind(bidOrderId,xfeSession.orders.get().dataUpdateProperty());
               }

               @Override
               protected boolean computeValue() {
	                  Asn1Type val = bidOrderId.get();
	                  if (val == null){
	                     return false;
	                  }
	                  Asn1Type rowOrderId = row.getAsn(AmpManagedOrder.currentOrderId);
//	                  System.out.println("xfeSessionModule.ordersModule.get().openOrdersUpdatedRO is "+xfeSessionModule.ordersModule.get().dataUpdateProperty().get() +" bidOrderId is "+bidOrderId.get() +" to ShortString is "+AsnPrintFormatter.toShortString(bidOrderId.get())+ " rowOrderId is "+rowOrderId+" is equal "+ASN.equals(val, rowOrderId)+" to shortString is "+AsnPrintFormatter.toShortString(rowOrderId));
	                  return ASN.equals(val, rowOrderId);
               }
            };
         }
      };
  }

   public DynamicFilter<ObservableReplyRow> isPriceBetterThanNlevelPrice(boolean isBid, ObservableObjectValue<Double> price, ObservableObjectValue<Double> nlevelPrice) {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               {
                  bind(price,nlevelPrice);
               }

               @Override
               protected boolean computeValue() {
                  return Util.isBestPrice(isBid,price.get(),nlevelPrice.get());
               }
            };
         }
      };
   }


   public static DynamicFilter<ObservableReplyRow> atBidPrice(
         String secCode,
         String boardId,
         ObservableObjectValue<String> observableObjectValue) {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               private final ObservableValue<String> bUser = observableObjectValue;
               private final ObservableValue<String> oUser = row.getProperty(AmpManagedOrder.userId);
               private final boolean isBuy = row.getValue(AmpManagedOrder.buySell) == AmpOrderVerb.buy;

               {
                  super.bind(oUser, bUser);
               }

               @Override
               protected boolean computeValue() {
                  return isBuy &&
                     withSecurity(secCode, boardId).accept(row) &&
                     oUser.getValue().equals(bUser.getValue());

               }
            };
         }
      };
   }

   public static DynamicFilter<ObservableReplyRow> atOfferPrice(
         String secCode,
         String boardId,
         ObservableObjectValue<String> observableObjectValue) {
      return new ObservableRowFilter() {
         @Override
         public ObservableBooleanValue accept(ObservableReplyRow row) {
            return new fxext.BooleanBinding() {
               private final ObservableValue<String> sUser = observableObjectValue;
               private final ObservableValue<String> oUser = row.getProperty(AmpManagedOrder.userId);
               private final boolean isSell = row.getValue(AmpManagedOrder.buySell) == AmpOrderVerb.sell;

               {
                  super.bind(oUser, sUser);
               }

               @Override
               protected boolean computeValue() {
                  if (isSell && withSecurity(secCode, boardId).accept(row)) {
                     return oUser.getValue().equals(sUser.getValue());
                  }

                  return false;
               }
            };
         }
      };
   }

   public static StaticFilter<ObservableReplyRow> withSecBoard(Asn1Type asnVal) {
      return RowFilters.equalsAsnStatic(AmpManagedOrder.secBoardId, asnVal);
   }

   public static StaticFilter<ObservableReplyRow> sideEquals(Asn1Type asn) {
      return RowFilters.equalsAsnStatic(AmpManagedOrder.buySell, asn);
   }

   public static StaticFilter<ObservableReplyRow> matchObboRow(ObservableReplyRow row) {
      if (row.getAsn(AmpOrderBookByOrder.orderId) == null) {
         return Filters.fixedStatic(false);
      } else if (row.getAsn(AmpOrderBookByOrder.managedOrderId) == null) {
         return RowFilters.equalsAsnStatic(AmpManagedOrder.currentOrderId, row.getAsn(AmpOrderBookByOrder.orderId));
      }
      else {
         return RowFilters.equalsAsnStatic(AmpManagedOrder.managedOrderId, row.getAsn(AmpOrderBookByOrder.managedOrderId));
      }
   }

   public static StaticFilter<ObservableReplyRow> matchOrdersRow(ObservableReplyRow ordersRow) {
      Asn1Type orderId = ordersRow.getAsn(AmpManagedOrder.managedOrderIdAcc);
      if (orderId != null) {
         return RowFilters.equalsAsnStatic(AmpManagedOrder.managedOrderIdAcc, orderId);
      } else {
         orderId = ordersRow.getAsn(AmpManagedOrder.currentOrderId);
         return orderId==null ? Filters.fixedStatic(false) : RowFilters.equalsAsnStatic(AmpManagedOrder.currentOrderId,orderId);
      }
   }

}
