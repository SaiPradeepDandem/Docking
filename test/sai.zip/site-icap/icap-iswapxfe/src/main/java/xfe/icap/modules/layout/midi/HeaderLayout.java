package xfe.icap.modules.layout.midi;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import org.controlsfx.glyphfont.Glyph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.ui.control.GlyphButton;
import xfe.util.scene.control.XfeTooltipFactory;

import java.io.IOException;
import java.util.function.Consumer;

public class HeaderLayout {
   private static final Logger logger = LoggerFactory.getLogger(HeaderLayout.class);

   @FXML
   private HBox headerPane;

   @FXML
   private StackPane userMenuPane;

   @FXML
   private Pane lockedLabelPane;

   @FXML
   private Pane safeModeLabelPane;

   private LockedLabel lockedLabel;

   private MenuBar userMenuBar;

   @FXML
   public void initialize() {
      lockedLabel = new LockedLabel("Locked");
      lockedLabelPane.getChildren().add(lockedLabel);
   }

   public void setUnlockHandler(Consumer<Node> unlockHandler) {
      lockedLabel.setUnlockHandler(unlockHandler);
   }

   public void setUserMenu(MenuBar menuBar) {
      this.userMenuBar = menuBar;
      userMenuPane.getChildren().add(menuBar);
   }

   ObservableList<MenuItem> menuItems() {
      return userMenuBar.getMenus().get(0).getItems();
   }

   static HeaderLayout load() {
      FXMLLoader ldr = new FXMLLoader(HeaderLayout.class.getResource("HeaderLayout.fxml"));
      try {
         ldr.load();
         return ldr.getController();
      } catch (IOException e) {
         throw new RuntimeException(e);
      }
   }

   public void displayLocked(boolean show) {
      lockedLabelPane.setVisible(show);
   }

   public void displaySafeModeLabel(Label label) {
      safeModeLabelPane.getChildren().clear();
      if (label != null) {
         safeModeLabelPane.getChildren().add(label);
      }
   }

   public Node getRoot(){
      return headerPane;
   }

}
