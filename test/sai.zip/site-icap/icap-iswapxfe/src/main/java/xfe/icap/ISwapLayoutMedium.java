package xfe.icap;

import javafx.beans.InvalidationListener;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.collections.SetChangeListener;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Window;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.ui.AboutInfoPopup;
import xfe.icap.ui.HBoxComponent;
import xfe.icap.ui.VBoxComponent;
import xfe.layout.FxAbstractLayout;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.modules.localsettings.LocalSettingsModule;
import xfe.modules.skin.XfeSkin;
import xfe.ui.ModalWindowContext;
import xfe.ui.splitpane.XfeSplitComponent;
import xfe.ui.splitpane.XfeSplitPane;
import xfe.util.Constants;
import xfe.util.scene.MonitorWindow;
import xfe.util.scene.control.AppContainer;
import xfe.util.scene.control.AutoHider;
import xfe.util.scene.control.DecoratedTitledPane;
import xfe.util.scene.control.VerticalAppContainer;
import xstr.util.Duration;
import xstr.util.Fx;
import xstr.util.Time;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ISwapLayoutMedium extends FxAbstractLayout implements Constants {
   private static final Logger logger = LoggerFactory.getLogger(ISwapLayoutMedium.class);

   private static final String LOGGED_OFF_STYLE = "xfe-logged-off";
   // It is used to identify the "content" of SplitPane, then to identify the contentDivider.
   private static final String ID_SUFFIX_SPLITPANE_CONTENT = "-split-content";
   private static final String ID_WATCHLIST = "watchlist" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes the settings toolbar, tradeticker and watchlist
   private static final String ID_DEPTH = "depth" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes the depth
   private static final String ID_TRADES = "trades" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes trades
   private static final String ID_ORDERS = "orders" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes orders
   private static final String ID_HISTORIES = "historyModule" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes historyModule
   @ModuleDependency
   public LocalSettingsModule localSettingsModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public XfeSkin skinModule;
   @ModuleDependency
   public FxApplicationModule fxAppModule;

   public ISwapLayoutMedium() {
      super("Standard");
   }

   @Override
   public void addView(Node view) {
      keyboardNavigation.addView(view);
      String id = defaultToIfNull(view.getId(), "");
      logger.debug("adding view which id is " + id);
      switch (id) {
         case "connection-status":
            logonWidget.getChildren().set(0, view);
            break;
         case "xfe-watchlist-view":
            watchlistNode.getChildren().setAll(view);
            HBox.setHgrow(view, Priority.ALWAYS);
            keyboardNavigation.getContext(view).cycleFocus = true;
            VBox.setVgrow(watchlistNode, Priority.ALWAYS);
            if (view instanceof XfeSplitComponent) {
               XfeSplitComponent new_name = (XfeSplitComponent) view;
               splitpane_firstContent.setOperatableComponent(new_name,splitPane);
            }else{
               logger.warn("Instruments view only accepts XfeSplitComponents. Cannot add view {}", view.getId());
            }
            break;
         case "xfe-iswap-toolbar":
            toolbarNode.getChildren().setAll(view);
            HBox.setHgrow(view, Priority.ALWAYS);
            keyboardNavigation.getContext(view).cycleFocus = false;
            break;
         case "xfe-depth-view":
            HBox.setHgrow(view, Priority.ALWAYS);
            depthNode.getChildren().setAll(view);
            keyboardNavigation.getContext(view).cycleFocus = false;
            if (view instanceof XfeSplitComponent) {
               XfeSplitComponent new_name = (XfeSplitComponent) view;
               depthNode.setOperatableComponent(new_name,splitPane);
            }else{
               logger.warn("Depth view only accepts XfeSplitComponents. Cannot add view {}", view.getId());
            }
            break;
         case "xfe-managed-order-entry-view":
            orderEntryNode.getChildren().setAll(view);
            HBox.setHgrow(view, Priority.ALWAYS);
            keyboardNavigation.getContext(view).cycleFocus = false;
            break;
         case "history-provider-view":
            historyNode.getChildren().setAll(view);
            if (view instanceof XfeSplitComponent) {
               XfeSplitComponent new_name = (XfeSplitComponent) view;
               historyNode.setOperatableComponent(new_name, splitPane);
            }else{
               logger.warn("History view only accepts XfeSplitComponents. Cannot add view {}", view.getId());
            }
            HBox.setHgrow(view, Priority.ALWAYS);
            keyboardNavigation.getContext(view).cycleFocus = false;
            break;
         case "xfe-orders-view":
            if (view instanceof XfeSplitComponent) {
               XfeSplitComponent new_name = (XfeSplitComponent) view;
               ordersNode.setOperatableComponent(new_name,splitPane);
            }else{
               logger.warn("Orders view only accepts XfeSplitComponents. Cannot add view {}", view.getId());
            }
            HBox.setHgrow(view, Priority.ALWAYS);
            ordersNode.getChildren().setAll(view);
            keyboardNavigation.getContext(view).cycleFocus = false;
            break;
         case "xfe-trades-view":
            tradesNode.getChildren().setAll(view);
            HBox.setHgrow(view, Priority.ALWAYS);
            keyboardNavigation.getContext(view).cycleFocus = true;
            if (view instanceof XfeSplitComponent) {
               XfeSplitComponent new_name = (XfeSplitComponent) view;
               tradesNode.setOperatableComponent(new_name, splitPane);
            }else{
               logger.warn("Trades view only accepts XfeSplitComponents. Cannot add view {}", view.getId());
            }
            break;
         case "xfe-trades-ticker-view":
            if (view instanceof XfeSplitComponent) {
               XfeSplitComponent new_name = (XfeSplitComponent) view;
               tradesNode.setOperatableComponent(new_name,splitPane);
            }else{
               logger.warn("Ticker view only accepts XfeSplitComponents. Cannot add view {}", view.getId());
            }
            tradesTickerNode.getChildren().setAll(view);
            HBox.setHgrow(view, Priority.ALWAYS);
            break;
         case "xfe-actions-view":
            actionsNode.getChildren().setAll(view);
            HBox.setHgrow(view, Priority.ALWAYS);
            keyboardNavigation.getContext(view).cycleFocus = false;
            break;
         case "xfe-global-refer-btns-view":
            //int index = banner.getChildren().indexOf(globalReferBtnsNode);
            globalReferBtnsNode = view;
           // banner.getChildren().set(index, globalReferBtnsNode);
            headerPane.setCenter(null);
            headerPane.setCenter(globalReferBtnsNode);
            BorderPane.setAlignment(globalReferBtnsNode, Pos.CENTER_RIGHT);
            break;
         default:
            if (view.getStyleClass().contains("xfe-popup")) {
               splitPane.setDisable(true);
               logonWidget.setDisable(true);
               splitPane.getStyleClass().add(LOGGED_OFF_STYLE);
               splitPane.setEffect(new GaussianBlur());
               popupGroup.getChildren().add(view);
               StackPane.setAlignment(view, Pos.CENTER);
            } else {
               logger.warn("Unable to add view - View not recognised: {}", view.getId());
            }
      }
      splitPane.requestLayout();
   }

   @Override
   public void removeView(Node view) {
      if(keyboardNavigation!=null){
         keyboardNavigation.removeView(view);
      }

      Node replaceNode = createPlaceholder();

      String id = defaultToIfNull(view.getId(), "");
      logger.debug("remove node "+id);
      if (id.equals("connection-status")) {
         logonWidget.getChildren().set(0, replaceNode);
      } else if (id.equals("xfe-orders-view")) {
      } else if (id.equals("xfe-global-refer-btns-view")) {
         //int index = banner.getChildren().indexOf(globalReferBtnsNode);
         globalReferBtnsNode = replaceNode;
         //banner.getChildren().set(index, globalReferBtnsNode);
         headerPane.setCenter(null);
         headerPane.setCenter(globalReferBtnsNode);
         BorderPane.setAlignment(globalReferBtnsNode, Pos.CENTER_RIGHT);
      } else if (id.equals("xfe-watchlist-view")) {
      } else if (id.equals("xfe-iswap-toolbar")) {
         toolbarNode.getChildren().setAll(replaceNode);
         HBox.setHgrow(view, Priority.ALWAYS);
      } else if (id.equals("xfe-depth-view")) {
      } else if (id.equals("xfe-managed-order-entry-view")) {
      } else if (id.equals("history-provider-view")) {
      } else if (id.equals("xfe-trades-view")) {
      } else if (id.equals("xfe-trades-ticker-view")) {
         tradesTickerNode.getChildren().setAll(replaceNode);
         HBox.setHgrow(view, Priority.ALWAYS);
      } else if (id.equals("xfe-actions-view")) {
         actionsNode.getChildren().setAll(replaceNode);
         HBox.setHgrow(view, Priority.ALWAYS);
      } else if (view.getStyleClass().contains("xfe-popup")) {
         popupGroup.getChildren().remove(view);
         splitPane.setDisable(false);
         logonWidget.setDisable(false);
         splitPane.getStyleClass().remove(LOGGED_OFF_STYLE);
         splitPane.setEffect(null);
      }
   }

   private static Region createPlaceholder() {
      Region r = new Region();
      r.setMaxSize(0, 0);
      return r;
   }

   @Override
   public AppContainer getLayoutRootElement() {
      if (root == null) {
         BorderPane content = new BorderPane();
         content.setId("scalableNode");

         headerPane = new BorderPane();
         HBox.setHgrow(headerPane,Priority.ALWAYS);
         headerPane.setLeft(logonWidget);
         BorderPane.setMargin(logonWidget, new Insets(3,0,0,10));
         BorderPane.setAlignment(logonWidget, Pos.CENTER_LEFT);
         headerPane.setCenter(globalReferBtnsNode);
         appModule.getXfeWindow().getHeaderPane().getChildren().add(headerPane);
//         banner = new HBox();
//         banner.setId("xfe-app-header");
//         banner.getChildren().addAll(applicationTitleLogo, logonWidget, new Pane() {
//            {
//               HBox.setHgrow(this, Priority.ALWAYS);
//            }
//         }, globalReferBtnsNode, applicationBrandLogo);
         popupGroup.getStyleClass().add("popup-group");
         popupGroup.setId("popup-group");

         StackPane body = new StackPane() {
            {
               this.getChildren().addAll(splitPane, popupGroup);
            }

            @Override
            protected double computeMinHeight(double width) {
               return splitPane.computeMinHeight(width);
            }
         };

         body.setId("xfe-app-body");
         body.getStyleClass().addAll("xfe-content-pane");
         new AutoHider(popupGroup);
//         popupGroup.setClip(clipRect);
//         clipRect.widthProperty().bind(body.widthProperty());
//         clipRect.heightProperty().bind(body.heightProperty());

         header.setId("app-header");
         header.getChildren().addAll(/*banner, */toolbarNode);
         content.setTop(header);
         content.setCenter(body);
         applicationTitleLogo.setPickOnBounds(true);
         final Node titleNode = appModule.getXfeWindow().getLabelTitle();
         titleNode.setOnMousePressed(mouseEvent -> lastLogoPressedTime = Time.now());
         titleNode.setOnMouseReleased(mouseEvent -> {
            Duration clickDuration = Time.now().minus(lastLogoPressedTime);
            if (clickDuration.compareTo(Duration.ZERO) >= 0 && clickDuration.compareTo(Duration.of(250, TimeUnit.MILLISECONDS)) < 0) {
               new AboutInfoPopup(localSettingsModule.getLastSite(),
                  titleNode,
                  showingInfoPopups).show(getScene().getWindow());
            }
         });

         root = new VerticalAppContainer(localSettingsModule.getHiVis() ?
            STYLE_HIVIS :
            "",
            FxApplicationModule.MAIN_STAGE_WIDTH,
            FxApplicationModule.MAIN_STAGE_HEIGHT,
            true,
            this,false) {
            @Override
            public void onScaled(double factor) {
               splitPane.setComponentSizeChanged();
               splitPane.layout();
               super.onScaled(factor);
            }
         };
         root.setContent(content);
         root.setId("iswap-vlayout");
         root.setAllowIconified(true);
         root.getCloseButton().addEventFilter(MouseEvent.MOUSE_CLICKED, event -> MonitorWindow.close());
         layoutManager.register(appModule.getStage(),root);
      }

      // Without this hack nothing is displayed!!
      root.getRoot().sceneProperty().addListener(s -> {
         if (root.getRoot().getScene() != null) {
            root.getRoot().getScene().getWindow().sizeToScene();
         }
      });

      return root;
   }

   @Override
   public Pane getPopupGroup() {
      return popupGroup;
   }

   @Override
   public void goModal(Node modalNode, Runnable runnable) {
      ModalWindowContext.registerHideEvent(modalNode, null, splitPane, headerPane/*banner*/);
   }

   @Override
   public void reLayout() {
      splitPane.setComponentChanged();
      splitPane.requestLayout();
   }

   @Override
   public void startResizing(MouseEvent event) {
      splitPane.setManaged(false);
      splitPane.startResizing(event);
   }

   @Override
   public void resizing(MouseEvent event) {
      splitPane.resizing(event);
   }

   @Override
   public void finishResizing(MouseEvent event) {
      splitPane.setManaged(true);
      splitPane.finishResizing(event);
   }

   private static String defaultToIfNull(String value, String defaultValue) {
      return value != null ? value : defaultValue;
   }

   @Override
   public Future<Void> startModule() {
      return super.startModule().flatMap(x -> handleLogon()).map(x -> {
         ObservableSet<Window> windows = layoutManager.getOpenedWindows();
         InvalidationListener vihisPropLis = observable -> {
            logger.info("hi-vis: value changed.");
            localSettingsModule.setHiVis(configurationModule.getData().hiVisProperty().get());
            List<Future<Void>> styleUpdateFutureList = new ArrayList<>(20);
            windows.stream().filter(win -> win != null && win.getScene() != null && win.getScene().getRoot() != null).forEach(
               win -> {
                  Parent p = win.getScene().getRoot();
                  ObservableList<String> rootStyle = p.getStyleClass();
                  if (configurationModule.getData().hiVisProperty().get()) {
                     if (!rootStyle.contains(Constants.STYLE_HIVIS)) {
                        logger.info("hi-vis: node {}'s root style changed. ",p.getId());
                        styleUpdateFutureList.add(Fx.runLater(() -> rootStyle.add(Constants.STYLE_HIVIS)));
                     }
                  } else {
                     if (rootStyle.contains(Constants.STYLE_HIVIS)) {
                        logger.info("hi-vis: node {}'s root style changed. ",p.getId());
                        styleUpdateFutureList.add(Fx.runLater(() -> rootStyle.removeAll(Constants.STYLE_HIVIS)));
                     }
                  }

               });
            if (styleUpdateFutureList.size()>0) {
               Futures.collect(styleUpdateFutureList).map(voids -> {
                  logger.info("hi-vis: style updated.");
                  return null;
               });
            } else {
               logger.info("hi-vis style updated. No changes actually made.");
            }

         };
         vihisPropLis.invalidated(null);
         configurationModule.getData().hiVisProperty().addListener(vihisPropLis);
         skinModule.switchToSkin(configurationModule.getData().skinNameProperty().get());
         windows.addListener((SetChangeListener<Window>) change -> {
            if (change.wasAdded()) {
               Window win = change.getElementAdded();
//               System.out.println("window registered:"+win);
               if (win != null && win.getScene() != null && win.getScene().getRoot() != null) {
                  Parent p = win.getScene().getRoot();
                  ObservableList<String> rootStyle = p.getStyleClass();
                  if (configurationModule.getData().hiVisProperty().get()) {
                     if (!rootStyle.contains(Constants.STYLE_HIVIS)) {
                        rootStyle.add(Constants.STYLE_HIVIS);
                     }
                  } else {
                     rootStyle.removeAll(Constants.STYLE_HIVIS);
                  }
               }
            }
         });

         return null;
      });
   }

   @Override
   public Future<Void> handleLogon() {
      depthNode = new HBoxComponent();
      depthNode.setId(ID_DEPTH);

      historyNode = new HBoxComponent();
      historyNode.setId(ID_HISTORIES);
      historyNode.setMaxWidth(FxApplicationModule.MAIN_STAGE_WIDTH);

      ordersNode = new HBoxComponent();
      ordersNode.setId(ID_ORDERS);
      ordersNode.setMaxWidth(FxApplicationModule.MAIN_STAGE_WIDTH);

      tradesNode = new HBoxComponent();
      tradesNode.setId(ID_TRADES);
      tradesNode.setMaxWidth(FxApplicationModule.MAIN_STAGE_WIDTH);

      splitpane_firstContent = new VBoxComponent() {
         {
            this.getChildren().addAll(tradesTickerNode, watchlistNode);
         }

         @Override
         public Node getNode() {
            return this;
         }

         @Override
         public double resizingMin() {
            return tradesTickerNode.minHeight(-1)+watchlistNode.minHeight(-1);
         }
      };
      splitpane_firstContent.setId(ID_WATCHLIST);
      splitpane_firstContent.setMaxWidth(FxApplicationModule.MAIN_STAGE_WIDTH);

      splitpane_secondContent = new VBoxComponent(){
         {
            setVgrow(depthNode, Priority.ALWAYS);
            setVgrow(orderEntryNode, Priority.NEVER);
            setVgrow(actionsNode, Priority.NEVER);
            this.setId("secondPane");
            this.getChildren().addAll(depthNode,orderEntryNode,actionsNode);
            this.setComponent(depthNode);

         }

         @Override
         public Node getNode() {
            return this;
         }

         @Override
         public double resizingMin() {
            return DecoratedTitledPane.HEIGHT_THREE_ROW_VISIBLE + orderEntryNode.minHeight(-1)+actionsNode.minHeight(-1);
         }

      };
      splitpane_secondContent.setPrefWidth(FxApplicationModule.MAIN_STAGE_WIDTH);

      splitPane.setItems(splitpane_firstContent, splitpane_secondContent, historyNode, ordersNode, tradesNode);

      return super.handleLogon();
   }

   @Override
   public void handleLogoff() {
      splitPane.clearItems();
      watchlistNode.getChildren().clear();
      orderEntryNode.getChildren().clear();
      tradesTickerNode.getChildren().clear();
      toolbarNode.getChildren().clear();
      if(depthNode!=null){
         depthNode.clearComponent();
      }
      if(historyNode!=null) {
         historyNode.clearComponent();
      }
      if(ordersNode!=null){
         ordersNode.clearComponent();
      }
      if(tradesNode!=null){
         tradesNode.clearComponent();
      }

      if(splitpane_firstContent!=null) {
         splitpane_firstContent.setComponent(null);
         splitpane_firstContent = null;
      }

      splitpane_secondContent = null;
      historyNode = null;
      ordersNode = null;
      tradesNode = null;
      depthNode = null;
      super.handleLogoff();
   }

   @Override
   public Future<Void> stopModule() {
      return super.stopModule();
   }

   @Override
   protected Scene getScene() {
      return splitPane.getScene();
   }
   //   private ListenerTracker tracker = new ListenerTracker();
   private VerticalAppContainer root;
   private final StackPane popupGroup = new StackPane();
   private final Group logonWidget = new Group() {
      {
         getChildren().add(new Region());
      }
   };
   //private HBox banner;
   private BorderPane headerPane;
   private final VBox header = new VBox();
   private final HBox toolbarNode = new HBox();
   private final HBox tradesTickerNode = new HBox();
   private final HBox watchlistNode = new HBox();
   private VBoxComponent splitpane_firstContent ;
   private HBoxComponent depthNode ;
   private final HBox orderEntryNode = new HBox();
   private final HBox actionsNode = new HBox() {
      {
         this.getStyleClass().add("xfe-action-buttons-holder");
      }
   };
   private VBoxComponent splitpane_secondContent ;
   private HBoxComponent historyNode;
   private HBoxComponent ordersNode ;
   private HBoxComponent tradesNode ;
   private Node globalReferBtnsNode = new Region();
   private final XfeSplitPane<XfeSplitComponent> splitPane = new XfeSplitPane<>();
   private final StackPane applicationBrandLogo = new StackPane() {
      {
//         this.getChildren().add(new ImageView());
//         this.setId("xfe-header-logo-pane");
         this.setMinWidth(55.0);
      }
   };
   private final StackPane applicationTitleLogo = new StackPane() {
      {
         this.getChildren().add(new ImageView());
         this.setId("xfe-header-title-pane");
      }
   };
   private final BooleanProperty showingInfoPopups = new SimpleBooleanProperty(true);
   private Time lastLogoPressedTime = Time.now();
}
