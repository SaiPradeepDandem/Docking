package xfe.icap.modules.watchlist;

import java.util.UUID;


import com.nomx.persist.watchlist.WatchlistSpec_v2;

class  InstrumentTab extends SubtitleTab {
   public WatchlistSpec_v2 spec;

   InstrumentTab(){
      super("","");
   }

   InstrumentTab(WatchlistSpec_v2 spec) {
      super(spec.getTitle(), spec.getSubtitle());

      setContents(spec);
   }

   private void setContents(WatchlistSpec_v2 spec) {
      this.spec = spec;
      this.setId(spec.getUUID());// set the id to the uuid;
   }

   UUID getSpecUUID() {
      return spec.getId();
   }

   @Override
   public String toString() {
      return "Tab-" + spec.getTitle() + " - " + spec.getSubtitle();
   }

   void replaceSpec(WatchlistSpec_v2 spec) {
      setContents(spec);
   }
}
