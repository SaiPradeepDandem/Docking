package xfe.icap.modules.settings;

import java.util.Iterator;

public abstract class Verification<T> implements Iterable<T> {
   public static final Verification<Object> INDETERMINATE = new Verification<Object>() {
      @Override
      public Iterator<Object> iterator() {
         return new Iterator<Object>() {
            @Override
            public boolean hasNext() {
               return false;
            }

            @Override
            public Object next() {
               throw new UnsupportedOperationException();
            }

            @Override
            public void remove() {
               throw new UnsupportedOperationException();
            }
         };
      }

      public boolean isIndeterminate() {
         return true;
      }

      public boolean isInvalid() {
         return false;
      }
   };

   @SuppressWarnings("unchecked")
   public static <V> Verification<V> indeterminate() {
      return (Verification<V>)INDETERMINATE;
   }

   public static final Verification<Object> INVALID = new Verification<Object>() {
      @Override
      public Iterator<Object> iterator() {
         return new Iterator<Object>() {
            @Override
            public boolean hasNext() {
               return false;
            }

            @Override
            public Object next() {
               throw new UnsupportedOperationException();
            }

            @Override
            public void remove() {
               throw new UnsupportedOperationException();
            }
         };
      }

      public boolean isInvalid() {
         return true;
      }
   };

   @SuppressWarnings("unchecked")
   public static <V> Verification<V> invalid() {
      return (Verification<V>)INVALID;
   }

   public static <V> Verification<V> of(V value) {
      return new Verification<V>() {
         @Override
         public Iterator<V> iterator() {
            return new Iterator<V>() {
               boolean done;

               @Override
               public boolean hasNext() {
                  return !done;
               }

               @Override
               public V next() {
                  done = true;
                  return value;
               }

               @Override
               public void remove() {
                  throw new UnsupportedOperationException();
               }
            };
         }

         public boolean hasValue() {
            return true;
         }
      };
   }

   public boolean isIndeterminate() {
      return false;
   }

   public boolean isInvalid() {
      return false;
   }

   public boolean hasValue() {
      return false;
   }
}
