package xfe.icap.modules.watchlist;

import javafx.scene.layout.Pane;

public class FilterPane extends Pane {
   public FilterPane() {
   }
}
