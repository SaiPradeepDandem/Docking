package xfe.icap.client;

import com.google.protobuf.ByteString;
import xmp.message.XMP.XmpLogonReply;
import xmp.message.XMP.XmpLogonRequest;
import xmp.message.XMP.XmpLogonRequest.Builder;
import xmp.message.XMP.XmpPassword;
import xmp.message.XMP.XmpQueryReply;
import xmp.message.XMP.XmpQueryRequest;
import xmp.message.XMP.XmpSubscriptionReply;
import xmp.message.XMP.XmpSubscriptionRequest;
import xmp.message.XMP.XmpTransactionRequest;
import xstr.session.Credentials;
import com.omxgroup.xstream.api.QueryRequest;
import io.netty.buffer.ByteBuf;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.ssl.SslHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xmp.message.XMP.XmpTransactionReply;
import xmp.message.XmpUtil;
import xstr.util.Duration;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;
import xstr.util.exception.AsnTypeException;
import xstr.util.exception.Exceptions;
import xstr.util.exception.XtrLogonException;
import xstr.util.exception.XtrSessionException;
import xstr.netty.Netty;
import xstr.util.ssl.XstrSslContextFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import java.util.concurrent.TimeUnit;

public abstract class XstrWebConnection extends DisposableBase {
   private static final Logger logger = LoggerFactory.getLogger(XstrWebConnection.class);

   // Used as an event object to indicate that a logon request should be sent
   public static String LOGON_REQUIRED = "Logon Required";

   protected final ClientBootstrap clientBootstrap;
   protected final EventLoopGroup eventLoopGroup = new NioEventLoopGroup();
   private boolean requiresPasswordChange;
   private String sessionMessage = "";
   protected final IcapWebSession sessionWrapper;
   protected final LogoffHandler logoffHandler = new LogoffHandler(this);

   protected final ReRequestingMessageHandler<XmpTransactionRequest, XmpTransactionReply> transactionHandler = new ReRequestingMessageHandler<XmpTransactionRequest, XmpTransactionReply>(this) {
      @Override
      protected MessageData setID(XmpTransactionRequest request) {
         XmpTransactionRequest r2 = request.toBuilder().setSeqNo(nextSeq.incrementAndGet()).build();
         return new MessageData(r2.getSeqNo(), r2);
      }

      @Override
      protected long getRepID(XmpTransactionReply reply) {
         return reply.getSeqNo();
      }
   };

   protected final ReRequestingMessageHandler<XmpQueryRequest, XmpQueryReply> queryHandler = new ReRequestingMessageHandler<XmpQueryRequest, XmpQueryReply>(this) {
      @Override
      protected MessageData setID(XmpQueryRequest request) {
         XmpQueryRequest r2 = request.toBuilder().setId((nextSeq.incrementAndGet())).build();
         return new MessageData(r2.getId(), r2);
      }

      @Override
      protected long getRepID(XmpQueryReply reply) {
         return reply.getId();
      }
   };

   protected final ReRequestingMessageHandler<XmpSubscriptionRequest, XmpSubscriptionReply> subscriptionHandler = new ReRequestingMessageHandler<XmpSubscriptionRequest, XmpSubscriptionReply>(this) {
      @Override
      protected MessageData setID(XmpSubscriptionRequest request) {
         XmpSubscriptionRequest r2 = request.toBuilder().setSeqNo(nextSeq.incrementAndGet()).build();
         return new MessageData(r2.getSeqNo(), r2);
      }

      @Override
      protected long getRepID(XmpSubscriptionReply reply) {
         return reply.getSeqNo();
      }
   };

   String getSessionMessage() {
      return sessionMessage;
   }

   protected ChannelHandler logonHandler(Credentials cred, Promise<Channel> logonPromise) {
      return new SimpleChannelInboundHandler<XmpLogonReply>() {
         @Override
         public void channelRead0(ChannelHandlerContext ctx, XmpLogonReply reply) throws Exception {
            logger.info("Logon reply received: {}", reply);
            if (reply.getSuccess()) {
               if (sessionWrapper.getTESessionId() != null && !reply.getSessionId().equals(sessionWrapper.getTESessionId())) {
                  logonPromise.setFailure(new XtrLogonException(reply.getMessage()));
               } else {
                  sessionWrapper.setSessionID(reply.getSessionId());
               }
               if (!reply.getSuccess()) {
                  logger.info("Logon failed. Server reply: {}", reply.getMessage());
                  throw new XtrSessionException(reply.getMessage());
               }
               if (reply.getChangePassword()) {
                  logger.info("Password change required");
                  setPasswordChangeRequired(true);
               }
               sessionMessage = reply.getMessage();
               logonPromise.setSuccess(ctx.channel());
            } else {
               logonPromise.setFailure(new XtrLogonException(reply.getMessage()));
            }
         }

         @Override
         public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
            if (evt == LOGON_REQUIRED) {
               logger.debug("LOGON_REQUIRED event received");
               Builder builder = XmpLogonRequest.newBuilder();
               if (cred != null) {
                  builder.setUsername(cred.getUsername())
                     .setPassword(XmpPassword.newBuilder().setValue(ByteString.copyFrom(XmpUtil.hashPassword(cred.getPasswordBytes()))))
                     .setClientToken(cred.getClientToken()).setSecurityCode(cred.getSecurityCode());
               } else {
                  builder.setUsername("");
               }
               String sessionID = sessionWrapper.getTESessionId();
               if (sessionID != null && !sessionID.isEmpty()) {
                  builder.setSessionId(sessionID);
               }

               ctx.writeAndFlush(builder.build());
               logger.info("Logon request sent.");
            }
         }
      };
   }


   public XstrWebConnection(IcapWebSession sessionWrapper) {
      this.sessionWrapper = sessionWrapper;
      this.clientBootstrap = new ClientBootstrap(sessionWrapper.config);
   }

   public void schedule(Duration delay, Runnable fn) {
      eventLoopGroup.schedule(fn, delay.in(TimeUnit.MILLISECONDS), TimeUnit.MILLISECONDS);
   }

   public XstrReplyIterator newIterator(QueryRequest req) throws AsnTypeException {
      return newIterator(req, null);
   }

   public XstrReplyIterator newIterator(QueryRequest req, byte[] cookie) throws AsnTypeException {
      return new XstrReplyIterator(req, cookie, this);
   }

   public Future<XmpTransactionReply> execute(XmpTransactionRequest request, String reqName) {
      logger.debug("execute {}", reqName);
      return transactionHandler.request(request);
   }

   public Future<Channel> channel() {
      return channel(null);
   }

   public abstract Future<Channel> channel(Credentials cred);

   public boolean requiresPasswordChange() {
      return requiresPasswordChange;
   }

   @Override
   protected Future<Void> dispose(boolean disposing) {
      logger.debug("Disposing Web connection.");
      transactionHandler.disposeMessages();
      queryHandler.disposeMessages();
      subscriptionHandler.disposeMessages();
      return logoffHandler.logoff().onDone(f -> {
         try {
            f.get();
            logger.info("Succesfully logged off from server.");
         } catch (Exception e) {
            logger.info("Sending Logoff request failed: {}", Exceptions.format(e));
         }
         return Futures.wrap(eventLoopGroup.shutdownGracefully());
      }).map(x -> null);
   }

   protected void setPasswordChangeRequired(boolean isRequired) {
      requiresPasswordChange = isRequired;
   }

   public abstract Future<Void> closeFuture();

   public HttpRequest createHttpReq(HttpMethod httpMethod, String path, ByteBuf retain) {
      return clientBootstrap.createHttpReq(httpMethod, path, retain);
   }

   protected void installSslHandler(ChannelPipeline p) {
      if (clientBootstrap.isSSL()) {
         logger.trace("Secure connection. Installing SSL/TLS handler");
         SSLContext context = XstrSslContextFactory.client.get();
         SSLEngine ssl_engine = Netty.createSSLEngine(context);
         ssl_engine.setUseClientMode(true);
         SslHandler sslHandler = new SslHandler(ssl_engine);
         p.addLast("ssl-handler", sslHandler);
         sslHandler.handshakeFuture().addListener(future -> {
            try {
               future.get();
               logger.trace("SSL Handshake complete.");
            } catch (Exception e) {
               logger.debug("SSL Handshake failed.", e);
               p.fireExceptionCaught(e);
            }
         });
      }
   }

   protected void installProxyHandler(ChannelPipeline p){
      // The proxy handler is used in case of SSL connections where we need to send an
      // unencrypted "CONNECT" message to the proxy before we send any encrypted messages.
      if (clientBootstrap.isViaProxy()) {
         logger.trace("Proxy connection. Installing proxy handler");
         ProxyHandler tunnellingHandler;
         if (clientBootstrap.isProxyAut())
            tunnellingHandler = new ProxyHandler(clientBootstrap.getUri(), clientBootstrap.getProxyCred());
         else
            tunnellingHandler = new ProxyHandler(clientBootstrap.getUri());
         p.addLast(ProxyHandler.CONNECT_PROXY, tunnellingHandler);
      }
   }

}
