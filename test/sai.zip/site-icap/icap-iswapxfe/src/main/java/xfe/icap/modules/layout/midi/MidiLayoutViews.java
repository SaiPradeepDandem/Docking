package xfe.icap.modules.layout.midi;

public class MidiLayoutViews {
   public static final String RENEW_PREFIX = "Renew";
   public static final String RENEW_CM_PREFIX = RENEW_PREFIX + " " + "CM";
   public static final String RENEW_BID_POSTFIX = "Order Bid";
   public static final String RENEW_OFFER_POSTFIX = "Order Offer";

   public static final String ACTION_TOOLBAR = "action-toolbar";
   public static final String INSTR_TABS = "instr-tabs";
   public static final String TRADER_TOOLBAR = "trader-toolbar";
   public static final String TRADES_UI = "trades-ui";
   public static final String ORDERSVIEW = "orders-view";
   public static final String TRADESVIEW = "trades-view";
   public static final String HISTORYVIEW = "history-view";
   public static final String SETTINGSVIEW = "settings-view";
   public static final String MMGROUPVIEW = "mmgroup-view";
   public static final String LINELISTVIEW = "linelist-view";
   public static final String TAB_EDITORVIEW = "tabeditor-view";
   public static final String TRADES_WORKUP = "trades-workup";
   public static final String SHORTLIST_PANE = "shortlist-pane";
   public static final String ORDER_RENEW_BID = RENEW_PREFIX + " " + RENEW_BID_POSTFIX;
   public static final String ORDER_RENEW_OFFER = RENEW_PREFIX + " " + RENEW_OFFER_POSTFIX;
   public static final String CM_ORDER_RENEW_BID = RENEW_CM_PREFIX + " " + RENEW_BID_POSTFIX;
   public static final String CM_ORDER_RENEW_OFFER = RENEW_CM_PREFIX + " " + RENEW_OFFER_POSTFIX;
   public static final String INSTRUMENT_SETTINGSVIEW = "instrument-settingss-view";
   public static final String SPRINGBOARD_VIEW = "springboard-view";
}
