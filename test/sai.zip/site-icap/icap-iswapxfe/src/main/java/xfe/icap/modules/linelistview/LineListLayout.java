package xfe.icap.modules.linelistview;

import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import xfe.icap.modules.layout.midi.MidiLayoutViews;

/**
 * Controller for LineListLayout.fxml
 */
public class LineListLayout {
   @FXML
   private StackPane root;

   @FXML
   public void initialize() {
      root.setId(MidiLayoutViews.LINELISTVIEW);
   }

   public StackPane getRoot() {
      return root;
   }
}
