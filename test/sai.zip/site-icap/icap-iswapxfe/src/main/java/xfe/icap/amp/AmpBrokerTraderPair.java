package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.acc.AmpAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;

public class AmpBrokerTraderPair extends AmpAccessor{
   public static final  AmpQreq req = AMP.qREQ("brokerTraderPairReq");
   public static final  AmpQrep rep = AMP.qREP("brokerTraderPairRep");

   public static final AsnConversionAccessor<String> brokerId =     acc(AMP.qREP("brokerTraderPairRep.brokerTraderPair.brokerId"), String.class);
   public static final AsnConversionAccessor<String> traderId =     acc(AMP.qREP("brokerTraderPairRep.brokerTraderPair.traderId"), String.class);
   public static final AsnConversionAccessor<Boolean> isAuto =      acc(AMP.qREP("brokerTraderPairRep.isAuto"), Boolean.class);
   public static final AsnConversionAccessor<String> traderFirmId = acc(AMP.qREP("brokerTraderPairRep.traderFirmId"), String.class);

}
