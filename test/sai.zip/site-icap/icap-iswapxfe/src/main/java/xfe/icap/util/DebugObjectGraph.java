package xfe.icap.util;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DebugObjectGraph {
	public static void inspectMap(Map<Object, String> map, String name, Object o) {
		System.out.println("--> contains " + name + ": " + (map.containsKey(o) ? map.get(o) + " ==> " + o : "<missing>"));
	}

	public static Map<Object, String> explore(Object o, int depth, boolean followWeak) {
		HashMap<Object, String> map = new HashMap<>();

		explore(map, "", o, depth, followWeak);

		return map;
	}

	public static boolean register(Map<Object, String> map, String path, Object o, int depth, boolean followWeak) {
		Class<?> clazz = o.getClass();

		if (clazz == WeakReference.class && !followWeak) {
			return false;
		}

		if (map.containsKey(o)) {
			return false;
		}

		System.out.println(">>> " + path + "[" + depth + "]: " + clazz.getName());
		map.put(o, path);

      return clazz != String.class;
   }

	private static void explore(Map<Object, String> map, String path, Object o, int depth, boolean followWeak) {
		if (depth <= 0 || o == null) {
			return;
		}

		Class<?> clazz = o.getClass();

		if (clazz == String.class) {
			// Don't follow.
		} else if (clazz.isArray()) {
			System.out.println("--> ARRAY ARRAY ARRAY ARRAY ARRAY ARRAY ARRAY ARRAY: " + o);

			if (clazz.getComponentType().isPrimitive()) {
				return;
			}

			Object[] array = (Object[])o;

			for (int i = 0; i < array.length; ++i) {
				Object item = array[i];

				if (item == null) {
					System.out.println("--> item null");
					continue;
				}

				if (!register(map, path, o, depth, followWeak)) {
					continue;
				}

				explore(map, path + "[" + i + "]", item, depth - 1, followWeak);
			}
		} else {
			exploreFields(map, path, o, depth, clazz, followWeak);
		}
	}

	private static void exploreFields(Map<Object, String> map, String path, Object o, int depth, Class<?> clazz, boolean followWeak) {
		if (clazz == null || clazz == Object.class) {
			return;
		}

		List<Runnable> runnables = new ArrayList<>();

		for (Field field: clazz.getDeclaredFields()) {
			Object value = exploreFieldValue(o, field);

			if (value != null) {
				if (!map.containsKey(value)) {
					String newPath = path + "." + field.getName();

					if (!register(map, newPath, value, depth - 1, followWeak)) {
						continue;
					}

					runnables.add(() -> explore(map, newPath, value, depth - 1, followWeak));
				}
			}
		}

      runnables.forEach(java.lang.Runnable::run);

		Class<?> superClass = clazz.getSuperclass();

		exploreFields(map, path, o, depth, superClass, followWeak);
	}

	private static Object exploreFieldValue(Object o, Field field) {
		try {
			field.setAccessible(true);

			if ((field.getModifiers() & Modifier.STATIC) != 0) {
				return null;
			}

			return field.get(o);
		} catch (IllegalArgumentException e) {
			System.out.println("--> illegal: " + field.getName());
			return null;
		} catch (IllegalAccessException e) {
			System.out.println("--> illegal: " + field.getName());
			return null;
		}
	}
}
