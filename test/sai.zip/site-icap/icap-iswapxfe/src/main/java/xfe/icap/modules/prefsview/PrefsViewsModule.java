package xfe.icap.modules.prefsview;

import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.Observable;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.shape.Rectangle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.modules.actionsui.ConfigActionsUIModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.tabeditorview.WatchlistEditView;
import xfe.icap.modules.watchlist.RfqFinalStageCounterDown;
import xfe.icap.ui.DigitalClockPane;
import xfe.icap.ui.RfqTimerPane;
import xfe.layout.FxAbstractLayout;
import xfe.module.Module;
import xfe.modules.logon.LogonModule;
import xfe.modules.session.SessionModule;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.ConfirmView;
import xfe.ui.InitialisableView;
import xfe.ui.PrefsViewFactory;
import xfe.ui.SlidePaneManager;
import xfe.ui.notifications.ModalAlertModule;
import xfe.util.scene.control.AppContainer;
import xfe.util.scene.control.AutoHider;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.util.Fun1;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.Future;

import java.util.*;
import java.util.Map.Entry;

@Module.Autostart
public class PrefsViewsModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(PrefsViewsModule.class);

   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public ConfigActionsUIModule configActionsModule;
   @ModuleDependency
   public ModalAlertModule alertModule;
   @ModuleDependency
   public LogonModule logonModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;

   public void addView(PrefsViewFactory viewFactory, ToggleButton toggleBtn) {
      views.add(viewFactory);
      if (toggleBtn != null) {
         togglesToViews.put(toggleBtn, viewFactory);
         toggleBtn.setToggleGroup(editorViewGroup);
      }
   }

   public void removeView(PrefsViewFactory view) {
      if (view != null) {
         //viewModule.dispose();
         views.remove(view);
         Object keyToRemove = null;
         for (Entry<Toggle, PrefsViewFactory> entry : togglesToViews.entrySet()) {
            if (Objects.equals(entry.getValue(), view)) {
               keyToRemove = entry.getKey();
               break;
            }
         }

         if (keyToRemove != null)
            togglesToViews.remove(keyToRemove);

         if (editorsTabPane != null)
            editorsTabPane.removeView(view);
      }

      if (views.isEmpty() && editorsTabPane != null)
         editorsTabPane = null;
   }

   @Override
   public Future<Void> startModule() {
      editorViewGroup.selectedToggleProperty().addListener((ov, oldToggle, newToggle) -> {

         if (Objects.equals(oldToggle, newToggle)) {
            logger.error("Toggling from {} to {} not expected", oldToggle, newToggle);
            return;
         }

         if (newToggle != null) {
            activeToggle = newToggle;
            editorViewGroup.selectToggle(null);
            logger.info("Opening {}", newToggle);
            return;
         }

         if (activeToggle != null) {
            PrefsViewFactory viewFactory = togglesToViews.get(activeToggle);
            if (viewFactory == null) {
               logger.error("Cannot find view for button {}", activeToggle);
               return;
            }

            if (editorsTabPane == null) {
               editorsTabPane = new PrefsViewsTabPane(alertModule, views, viewFactory, () -> {
                  editorsTabPane = null;
                  showView(null);
                  // Enable the safe mode button and allowing the locked menu item
                  sessionModule.setLockingDisabled(false);
               });
            }

            editorsTabPane.showView(viewFactory);
            if (editorsTabPane != null) {
               showView(editorsTabPane.root);
               // Disable the safe mode button and disallowing the locked menu item
               sessionModule.setLockingDisabled(true);
            }
         }
      });

      ibMeButton.visibleProperty().bind(xfeSessionModule.loggedOnProperty());
      callMeButton.visibleProperty().bind(xfeSessionModule.loggedOnProperty());
      sessionModule.lockedProperty().addListener(this::handleLockInvalidated);
      logonModule.addVetoLogoffTask(this::handleVetoLogoff);
      sliderPane = new AnchorPane() {{
         setId("xfe-slidepane");
      }};
      slidePaneManager = new SlidePaneManager(sliderPane);
      AppContainer layoutRoot = layoutModule.getLayoutRootElement();
      sliderPane.disableProperty().bind(layoutRoot.getRoot().disabledProperty());

      Rectangle slidePaneClip = new Rectangle();

      slidePaneClip.widthProperty().bind(sliderPane.widthProperty());
      slidePaneClip.heightProperty().bind(sliderPane.heightProperty());
      sliderPane.setClip(slidePaneClip);

      new AutoHider(sliderPane);

      ObservableList<Node> rootChildren = layoutModule.getPopupGroup().getChildren();
      rootChildren.add(0, sliderPane); //the sliderPane.toBack() causes runtime exception.
      tracker.registerRollbackAction(() -> rootChildren.remove(sliderPane));

      ObservableList<Node> toolsbarItems = toolbar.getItems();
      rfqCounterDown = new RfqFinalStageCounterDown(rfqInstr, xfeSessionModule);
      if (!xfeSessionModule.getUnderlyingSession().getLoggedOnUser().isBroker()) {
         configActionsModule.addNode(callMeButton);
         configActionsModule.addNode(ibMeButton);
      }


      toolsbarItems.add(rfqInstr.getRootElement());
      toolsbarItems.add(new Label(" "));
      toolsbarItems.add(clockPane);
      configActionsModule.addNode(toolbar);
      HBox.setHgrow(toolbar, Priority.SOMETIMES);
      clockPane.init(xfeSessionModule.getUnderlyingSession().getStats());

      tracker.addListener(xfeSessionModule.rfqs.get().sortByEndingFinalPhaseRfqs.get(), (Observable observable) -> {
         logger.debug("sortByEndingFinalPhaseRfqs is invalidated. the list is: {}",
            xfeSessionModule.rfqs.get().sortByEndingFinalPhaseRfqs.get());
         if (xfeSessionModule.rfqs.get().sortByEndingFinalPhaseRfqs.get().size() == 0) {
            rfqCounterDown.cancel();
         } else {
            rfqCounterDown.startEndingSoonestRfqCountDown();
         }
      });

      tabEditorPrefsViewFactory = new PrefsViewFactory() {
         @Override
         public InitialisableView create() {
            WatchlistEditView view = new WatchlistEditView(xfeSessionModule.secBoards.get(), alertModule::showError) {
               @Override
               public void applyChanges(List<WatchlistSpec_v2> instrSpecs) {
                  // Marking the current selected tab in listview.
                  final WatchlistSpec_v2 currentWL = getCurrentTab();
                  instrSpecs.forEach(instrSpec -> {
                     boolean selected = currentWL != null && instrSpec.getId().equals(currentWL.getId());
                     instrSpec.setSelectedInTabListView(selected);
                  });

                  xfeSessionModule.secBoards.get().findAll(secBoards -> {
                     List<WatchlistSpec_v2> newSpecs = WatchlistSpec_v2.updateFullProducts(instrSpecs, secBoards);
                     configurationModule.getWatchlists().setAll(newSpecs);
                     return null;
                  });
                  buttonGroupEditor.setSelected(false);
               }
            };

            xfeSessionModule.secBoards.get().ready().onSuccess(new Fun1<Boolean, Void>() {
               @Override
               public Void call(Boolean a) {
                  view.populateFrom(configurationModule.getWatchlists());
                  return null;
               }
            });

            // Selecting the current selected watchlist in the listview.
            try {
               final Optional<WatchlistSpec_v2> activeTab = configurationModule.getWatchlists().stream().filter(WatchlistSpec_v2::isSelectedInTabListView).findFirst();
               activeTab.ifPresent(view::setActiveTab);
            } catch (NullPointerException e) {
               e.printStackTrace();
            }

            return view;
         }

         @Override
         public String getViewName() {
            return "Tab Editor";
         }

         @Override
         public int getLeftPriority() {
            return 40;
         }
      };

      addView(tabEditorPrefsViewFactory, buttonGroupEditor);

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      toolbar.getItems().clear();
      clockPane.dispose();
      if (rfqCounterDown != null)
         rfqCounterDown.cancel();
      layoutModule.removeView(toolbar);
      sliderPane.getChildren().clear();
      removeView(tabEditorPrefsViewFactory);
      return Future.SUCCESS;
   }

   private void showView(Node view) {
//      Stage stage = jfxContextModule.getStage();
//      ZoomableDecorator.setHeight(stage, ZoomableDecorator.getHeight(stage) + 1);
      slidePaneManager.setView(view);
   }

   private void handleLockInvalidated(Observable observable) {
      for (Entry entry : togglesToViews.entrySet()) {
         ((ToggleButton) (entry.getKey())).disableProperty().set(sessionModule.lockedProperty().get());
      }
   }

   private Future<Boolean> handleVetoLogoff() {
      if (editorsTabPane != null && editorsTabPane.isModified())
         return editorsTabPane.tryClosing().map(a -> !a);
      else return Future.valueOf(Boolean.FALSE);
   }

   private final ToggleGroup editorViewGroup = new ToggleGroup();
   private final List<PrefsViewFactory> views = new ArrayList<>();
   // TODO: a map from factory to created products
   private final Map<Toggle, PrefsViewFactory> togglesToViews = new HashMap<>();
   private final RfqTimerPane rfqInstr = RfqTimerPane.load(true);
   private final DigitalClockPane clockPane = new DigitalClockPane();
   private final ToolBar toolbar = new ToolBar() {{
      this.setId("xfe-iswap-toolbar");
      this.setPrefHeight(24);
      this.setMaxHeight(24);
      this.setMinHeight(24);
   }};
   private final ListenerTracker tracker = new ListenerTracker();
   private final Button callMeButton = new Button() {{
      setId("xfe-iswap-callme-btn");
      getStyleClass().add("xfe-icon-call-me");
      XfeTooltipFactory.setTooltip(this);
      setText("Call");

      setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            alertModule.showModalView(ConfirmView.create("Do you wish i-Swap to contact you by phone?", () -> {
               try {
                  xfeSessionModule.callMe();
               } catch (Exception e) {
                  logger.error("call me error.", e);
               }
            }));
         }
      });
   }};
   private final Button ibMeButton = new Button() {{
      setId("xfe-iswap-ibme-btn");
      getStyleClass().add("xfe-icon-ib-me");
      XfeTooltipFactory.setTooltip(this);
      setText("IB");
      setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            alertModule.showModalView(ConfirmView.create("Do you wish i-Swap to contact you by IB?", () -> {
               try {
                  xfeSessionModule.ibMe();
               } catch (Exception e) {
                  logger.error("ib me error.", e);
               }
            }));
         }
      });
   }};
   private PrefsViewsTabPane editorsTabPane;
   private AnchorPane sliderPane;
   private SlidePaneManager slidePaneManager;
   private Toggle activeToggle;
   private RfqFinalStageCounterDown rfqCounterDown;

   private PrefsViewFactory tabEditorPrefsViewFactory;
   private final ToggleButton buttonGroupEditor = new ToggleButton() {{
      this.getStyleClass().add("toggle-button");
      this.setText("T");
      this.setId("xfe-iswap-settings-tg-tabeditor");
      XfeTooltipFactory.setTooltip(this);
      // Set up watch list buttons with positioning, images and tooltips
      this.getStyleClass().add("xfe-icon-list-edit");
      this.setMaxSize(35.0, 20.0);
   }};
}
