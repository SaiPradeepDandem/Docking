package xfe.icap.modules.sectabsui;

import javafx.scene.control.Tab;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

class WatchListTab extends Tab {

   WatchListTab(String title, String subTitle) {
      super();
      String tabText = title;
      final Text tabTitle = new Text();
      tabTitle.setText(title);
      tabTitle.getStyleClass().add("tab-title");
      final TextFlow textFlow = new TextFlow(tabTitle);

      if (subTitle != null && !subTitle.equals("")) {
         final Text tabSubtitle = new Text("\n" + subTitle);
         tabSubtitle.getStyleClass().add("tab-sub-title");
         textFlow.getChildren().add(tabSubtitle);
         tabText = tabText+"\n" + subTitle;
      }

      setText(tabText);
      setGraphic(textFlow);
      setClosable(false);
   }
}
