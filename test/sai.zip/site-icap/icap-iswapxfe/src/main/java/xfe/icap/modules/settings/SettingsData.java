package xfe.icap.modules.settings;

import com.nomx.domain.types.*;
import com.nomx.instrumentsettings.InstrumentSettingsSpec;
import com.nomx.persist.ParametersStorage;
import com.nomx.persist.PersistantName;
import com.nomx.persist.Types.Rect;
import com.nomx.persist.UnmodifiableListProperty;
import com.nomx.persist.rfq.MarketMakerGroup;
import com.nomx.persist.watchlist.ColumnsSpec;
import com.nomx.persist.watchlist.HeadingSpec;
import com.nomx.persist.watchlist.ShortlistButtonSpec;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import xfe.modules.settings.SettingsComponent;
import xfe.modules.settings.SettingsInstance;
import xfe.ui.table.TableRowFactory;
import xfe.util.scene.control.DurationTextField;
import xfe.util.scene.control.RightAlignedCheckBox;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xstr.types.User;
import xstr.util.Fx;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Future;

import java.util.*;

public class SettingsData extends DisposableBase {
   public static final DoubleComponent textfieldDouble = DoubleComponent.DEFAULT;
   public static final IntegerComponent textfieldInteger = IntegerComponent.DEFAULT;
   private static final Set<PersistantName> names = new HashSet<>(Arrays.asList(PersistantName.BidOnLeft, PersistantName.DisplayOrders,
      PersistantName.DisplayTrades, PersistantName.DisplayActions, PersistantName.DisplayMiniWatchlist, PersistantName.TradeAlerts, PersistantName.AlertSoundForAll, PersistantName.AlertSoundForMine,
      PersistantName.MarketSizeOnOrderEnter, PersistantName.OutrightDefaultQty, PersistantName.StrategyDefaultQty,
      PersistantName.OutrightPriceTight, PersistantName.StrategyPriceTight,
      PersistantName.DefaultDuration, PersistantName.DefaultDurationType,
      PersistantName.OnLogoffAction, PersistantName.TradeAlertPopupExpiry, PersistantName.TradeAlertPopupExpiryBoolean, PersistantName.AutoLogonEnabled, PersistantName.AutoLogonTimeout,
      PersistantName.YoursMineDefaultAmount, PersistantName.AutoSaveWorkspace, PersistantName.LeftQtyBtn, PersistantName.MiddleQtyBtn,
      PersistantName.RightQtyBtn, PersistantName.YoursMineLitDelay, PersistantName.SharedOrders, PersistantName.AlertsShowLegs,
      PersistantName.YoursMineOrderWithdraw, PersistantName.DisplayHistory, PersistantName.HistoryHeaderNotificationTimeout,
      PersistantName.CellFlash, PersistantName.CellFlashTimeout, PersistantName.CellFlashInterval, PersistantName.PriceCellFlashDuration, PersistantName.HiVis,
      PersistantName.DisplayTicker, PersistantName.MergeImplied, PersistantName.MergeWatchListImplied,
      PersistantName.ManagedOrders, PersistantName.Clone2EFS, PersistantName.IsAnon,
      PersistantName.DisplayVolumeTab, PersistantName.DisplayRFQTab, PersistantName.RfqInitiatorOrderAon,
      PersistantName.AutoPopupWorkup, PersistantName.TradeSound, PersistantName.SelectedMMFirms, PersistantName.TradeShowBroker, PersistantName.AutomatchInMainMarket,
      PersistantName.SkinName, PersistantName.WatchListContentHeight, PersistantName.rfqMMAdvSetting, PersistantName.rfqAnonymous, PersistantName.rfqNotification,
      PersistantName.LaunchFusion, PersistantName.HideRfqPane, PersistantName.HideNonAutoAccept, PersistantName.DisplayPTTab,
      PersistantName.OutrightPTForTab, PersistantName.StrategyPTForTab, PersistantName.ButterflyPTForTab, PersistantName.OrderConfirm,
      PersistantName.ActivesTab, PersistantName.OneClickTrading, PersistantName.AutoPopupTrades, PersistantName.OrdersColsSpecification,
      PersistantName.TradesColsSpecification, PersistantName.TopCut, PersistantName.UnlockOnAutoLogon, PersistantName.PopupOnWorkupEnding, PersistantName.PopupOnCMPriceChange,
      PersistantName.OneClickHitTake
   ));
   private static final ObjectProperty<EventHandler<ActionEvent>> openTradeNotificationProp = new SimpleObjectProperty<>();
   /*
    * has to be static, since setting editing clones everything non-static
    */
   private static final ObjectProperty<EventHandler<ActionEvent>> openMMActionProp = new SimpleObjectProperty<>();

   public SettingsData(ParametersStorage parametersStorage,
                       User user,
                       ObservableSet<String> allFirms) {
      this.storage = parametersStorage;
      this.user = user;
      this.allFirms = allFirms;
      this.autoOCOProperty.set(user.getAutoOCO());
   }

   public DoubleProperty ordersHeightProperty() {
      DoubleProperty dp = (DoubleProperty) PersistantName.OrdersContentHeight.get(getStorage());
      assert dp != null;
      double d = dp.get();
      if (d > 0 && d < 1) {
         d = positionCompatible(0.15);
         dp.set(d);
      }
      return dp;
   }

   public ObjectProperty<ColumnsSpec> ordersColsSpecificationProperty() {
      return (ObjectProperty<ColumnsSpec>) PersistantName.OrdersColsSpecification.get(getStorage());
   }

   public ObjectProperty<ColumnsSpec> tradesColsSpecificationProperty() {
      return (ObjectProperty<ColumnsSpec>) PersistantName.TradesColsSpecification.get(getStorage());
   }

   public ParametersStorage getStorage() {
      if (!storage.live()) throw new IllegalStateException();

      return storage;
   }

   private double positionCompatible(double proportion) {
      assert PersistantName.ApplicationHeight.get(getStorage()) != null;
      return ((DoubleProperty) PersistantName.ApplicationHeight.get(getStorage())).get() * proportion;
   }

   public BooleanProperty ordersExpandProperty() {
      return (BooleanProperty) PersistantName.OrdersPaneExpand.get(getStorage());
   }

   public DoubleProperty tradesHeightProperty() {
      DoubleProperty dp = (DoubleProperty) PersistantName.TradesContentHeight.get(getStorage());
      assert dp != null;
      double d = dp.get();
      if (d > 0 && d < 1) {
         d = positionCompatible(0.15);
         dp.set(d);
      }
      return dp;
   }

   public BooleanProperty tradesExpandProperty() {
      return (BooleanProperty) PersistantName.TradesPaneExpand.get(getStorage());
   }

   public ObjectProperty<Rect> miniWatchListPostionProperty() {
      return (ObjectProperty<Rect>) PersistantName.MiniWatchlistPosition.get(getStorage());
   }

   public DoubleProperty midiLayoutDividerPosition() {
      return (DoubleProperty) PersistantName.MidiLayoutDividerPosition.get(getStorage());
   }

   public ObjectProperty<Rect> tradesViewPosition() {
      return (ObjectProperty<Rect>) PersistantName.TradesViewPosition.get(getStorage());
   }

   public ObjectProperty<Rect> orderRenewPosition() {
      return (ObjectProperty<Rect>) PersistantName.OrderRenewPosition.get(getStorage());
   }

   /**
    * If true, the trades dialog will popup on logon.
    */
   public BooleanProperty tradesViewOpened() {
      return (BooleanProperty) PersistantName.TradesViewOpened.get(getStorage());
   }

   public BooleanProperty springBoardOpened() {
      return (BooleanProperty) PersistantName.SpringBoardOpened.get(getStorage());
   }

   public ObjectProperty<Rect> ordersViewPosition() {
      return (ObjectProperty<Rect>) PersistantName.OrdersViewPosition.get(getStorage());
   }

   public ObjectProperty<Rect> springBoardPosition() {
      return (ObjectProperty<Rect>) PersistantName.SpringBoardPosition.get(getStorage());
   }

   public BooleanProperty stockSelectionExpanded() {
      return (BooleanProperty) PersistantName.StockSelectionExpanded.get(getStorage());
   }

   public BooleanProperty tooltipOn() {
      return (BooleanProperty) PersistantName.TooltipOn.get(getStorage());
   }

   /**
    * If true, the orders dialog will popup on logon.
    */
   public BooleanProperty ordersViewOpened() {
      return (BooleanProperty) PersistantName.OrdersViewOpened.get(getStorage());
   }

   public DoubleProperty watchListHeightProperty() {
      DoubleProperty dp = (DoubleProperty) PersistantName.WatchListContentHeight.get(getStorage());
      assert dp != null;
      double d = dp.get();
      if (d > 0 && d < 1) {
         d = positionCompatible(0.15);
         dp.set(d);
      }
      return dp;
   }

   public DoubleProperty marketDepthHeightProperty() {
      DoubleProperty dp = (DoubleProperty) PersistantName.MarketDepthContentHeight.get(getStorage());
      assert dp != null;
      double d = dp.get();
      if (d > 0 && d < 1) {
         d = positionCompatible(0.20);
         dp.set(d);
      }
      return dp;
   }

   public BooleanProperty marketDepthExpandProperty() {
      return (BooleanProperty) PersistantName.MarketDepthPaneExpand.get(getStorage());
   }

   public DoubleProperty applicationHeightProperty() {
      return (DoubleProperty) PersistantName.ApplicationHeight.get(getStorage());
   }

   public IntegerProperty instrumentsTableZoomLevelProperty() {
      return (IntegerProperty) PersistantName.InstrumentsTableZoomLevel.get(getStorage());
   }

   public ObjectProperty<Rect> applicationPositionProperty() {
      return (ObjectProperty<Rect>) PersistantName.ApplicationPosition.get(getStorage());
   }

   public DoubleProperty historyHeightProperty() {
      DoubleProperty dp = (DoubleProperty) PersistantName.HistoryContentHeight.get(getStorage());
      assert dp != null;
      double d = dp.get();
      if (d > 0 && d < 1) {
         d = positionCompatible(0.15);
         dp.set(d);
      }
      return dp;
   }

   public BooleanProperty historyExpandProperty() {
      return (BooleanProperty) PersistantName.HistoryPaneExpand.get(getStorage());
   }

   public DoubleProperty tradeAlertsNotificationPosXProperty() {
      return (DoubleProperty) PersistantName.TradeAlertsNotificationPosX.get(getStorage());
   }

   public DoubleProperty tradeAlertsNotificationPosYProperty() {
      return (DoubleProperty) PersistantName.TradeAlertsNotificationPosY.get(getStorage());
   }

   public DoubleProperty rfqNotificationPosXProperty() {
      return (DoubleProperty) PersistantName.RFQNotificationPosX.get(getStorage());
   }

   public DoubleProperty rfqNotificationPosYProperty() {
      return (DoubleProperty) PersistantName.RFQNotificationPosY.get(getStorage());
   }

   public DoubleProperty lineListPosXProperty() {
      return (DoubleProperty) PersistantName.LineListPosX.get(getStorage());
   }

   public DoubleProperty lineListPosYProperty() {
      return (DoubleProperty) PersistantName.LineListPosY.get(getStorage());
   }

   public BooleanProperty displayPTTabProperty() {
      return (BooleanProperty) PersistantName.DisplayPTTab.get(getStorage());
   }

   public DoubleProperty outrightPTForTabProperty() {
      return (DoubleProperty) PersistantName.OutrightPTForTab.get(getStorage());
   }

   public DoubleProperty strategyPTForTabProperty() {
      return (DoubleProperty) PersistantName.StrategyPTForTab.get(getStorage());
   }

   public DoubleProperty butterflyPTForTabProperty() {
      return (DoubleProperty) PersistantName.ButterflyPTForTab.get(getStorage());
   }

   /**
    * If True the volume tab is displayed.
    */
   public StringProperty skinNameProperty() {
      return (StringProperty) PersistantName.SkinName.get(getStorage());
   }

   public ObjectProperty<AlertSound> alertSoundForMineProperty() {
      return (ObjectProperty<AlertSound>) PersistantName.AlertSoundForMine.get(getStorage());
   }

   public ObjectProperty<AlertSound> alertSoundForAllProperty() {
      return (ObjectProperty<AlertSound>) PersistantName.AlertSoundForAll.get(getStorage());
   }

   public BooleanProperty showBrokerTradeProperty() {
      return (BooleanProperty) PersistantName.TradeShowBroker.get(getStorage());
   }

   public BooleanProperty openTradeNotificationProperty() {
      return triggerTradeNotificationProp;
   }

   /**
    * Specifies the set of selected firms
    */
   public ObjectProperty<List<String>> selectedMMFirmsProperty() {
      return (UnmodifiableListProperty) PersistantName.SelectedMMFirms.get(getStorage());
   }

   /**
    * Specifies the set of stock selection buttons.
    */
   public ObjectProperty<ObservableList<ShortlistButtonSpec>> shortlistButtonsProperty() {
      return getStorage().getList(PersistantName.ShortlistButtons, ShortlistButtonSpec.class, null);
   }

   public ObjectProperty<WatchlistSpec_v2> activesSpecProperty() {
      return (ObjectProperty<WatchlistSpec_v2>) PersistantName.ActivesSpec.get(getStorage());
   }

   public ObjectProperty<WatchlistSpec_v2> selectedWatchListTabProperty() {
      return (ObjectProperty<WatchlistSpec_v2>) PersistantName.SelectedWatchListTab.get(getStorage());
   }

   /**
    * Specifies the list of instrument settings spec.
    */
   public ObjectProperty<ObservableList<InstrumentSettingsSpec>> instrumentSettingsProperty() {
      return getStorage().getList(PersistantName.InstrumentSettings, InstrumentSettingsSpec.class, null);
   }

   /**
    * Specifies the list of header spec.
    */
   public ObjectProperty<ObservableList<HeadingSpec>> headingsSpecProperty() {
      return getStorage().getList(PersistantName.HeadingsSpec, HeadingSpec.class, null);
   }

   /**
    * Specifies the set of selected market maker group
    */
   public ObjectProperty<ObservableList<MarketMakerGroup>> selectedMMGroupProperty() {
      return getStorage().getList(PersistantName.mmGroup, MarketMakerGroup.class, null);
   }

   public BooleanProperty launchFusionProperty() {
      return (BooleanProperty) PersistantName.LaunchFusion.get(getStorage());
   }

   public BooleanProperty orderConfirmProperty() {
      return (BooleanProperty) PersistantName.OrderConfirm.get(getStorage());
   }

   public BooleanProperty automatchInMainMarketProperty() {
      return (BooleanProperty) PersistantName.AutomatchInMainMarket.get(getStorage());
   }

   public ObjectProperty<InstrumentKey> selectedInstrumentKeyProperty() {
      return getStorage().get(PersistantName.SelectedInstrumentKey, InstrumentKey.class, (InstrumentKey) null);
   }

   public IntegerProperty selectedOrdersTabProperty() {
      return (IntegerProperty) PersistantName.SelectedOrdersTab.get(getStorage());
   }

   public IntegerProperty selectedTradesTabProperty() {
      return (IntegerProperty) PersistantName.SelectedTradesTab.get(getStorage());
   }

   public void setAutoOCO(boolean currAutoOCO) {
      autoOCOProperty.set(currAutoOCO);
      user.setAutoOCO(currAutoOCO);
   }

   public void revertAutoOCO() {
      autoOCOProperty.set(user.getAutoOCO());
   }

   public static String getKey() {
		/*
	  The key of this information set
	 */
      return "Settings";
   }

   /**
    * If True the volume tab is displayed.
    */
   public BooleanProperty rfqInitiatorOrderAon() {
      return Fx.FalseProp;
      //return (BooleanProperty) PersistantName.RfqInitiatorOrderAon.get(getStorage());
   }

   public List<SettingsComponent> getViewSettings() {
      if (user.isBroker()) {
         mergeImpliedMainWatchlistProperty().set(true);
         return Arrays.asList(
            describe("Switch the order of Bid/Offer columns and buttons throughout i-Swap",
               hbox(gap(5.0), radiobox("BID/OFFER", bidOnLeftProperty(), true), gap(20.0), radiobox("OFFER/BID", bidOnLeftProperty(), false))),
            describe("Merge i^n in Mini Watch List Table", checkbox("Merge i^n into price (Mini Watch List)", 20.0, mergeImpliedMiniWatchlistProperty())),
            describe("Toggle Orders Window Visibility", checkbox("Orders Window", 20.0, displayOrdersProperty())),
            describe("Toggle Trades Window Visibility", checkbox("Trades Window", 19.0, displayTradesProperty())),
            describe("Toggle Shortcut Panel Visibility", checkbox("Shortcut Panel", 23.0, displayActionsProperty())),
            describe("Toggle History Window Visibility", hbox(checkbox("History Window     ", 1.0, displayHistoryProperty()), label("  secs"), gap(1.0), textfieldInteger.restrictRange(0, 5000).value(historyHeaderNotificationTimeoutProperty()).digits(3).disabled(displayHistoryProperty().not()))),
            describe("Watchlist Change Flash Notification", hbox(checkbox("Flash Cells     ", 1.0, cellFlashProperty()), label("  msecs"), gap(1.0), textfieldInteger.restrictRange(0, 5000).value(cellFlashTimeoutProperty()).digits(3).disabled(cellFlashProperty().not()))),
            describe("Toggle flash if traded", checkbox("Hi-Vis", 50.0, hiVisProperty())),
            describe("Toggle Watchlist Visibility", checkbox("Watchlist", 50.0, displayMiniWatchlistProperty())),
            describe("Toggle Ticker Visibility", checkbox("Ticker", 50.0, displayTickerProperty())),
            describe("Show daily volume tab", checkbox("Volume Tab", 50.0, displayVolumeTabProperty()))
//                     describe("Launch fusion on startup", checkbox("Launch Fusion", 50.0, launchFusionProperty(),webStartModeProp))

         );

      } else {
         return Arrays.asList(
            describe("Toggle Bid and Offer Sides",
               hbox(gap(5.0), radiobox("BID/OFFER", bidOnLeftProperty(), true), gap(20.0), radiobox("OFFER/BID", bidOnLeftProperty(), false))),
            describe("Merge i^n in Mini Watch List Table", checkbox("Merge i^n into price (Mini Watch List)", 20.0, mergeImpliedMiniWatchlistProperty())),
            describe("Merge i^n in Mini Watch  Table", checkbox("Merge i^n into price (Watch List)", 20.0, mergeImpliedMainWatchlistProperty())),
            describe("Toggle Orders Window Visibility", checkbox("Orders Window", 20.0, displayOrdersProperty())),
            describe("Toggle Trades Window Visibility", checkbox("Trades Window", 19.0, displayTradesProperty())),
            describe("Toggle Shortcut Panel Visibility", checkbox("Shortcut Panel", 23.0, displayActionsProperty())),
            describe("Toggle History Window Visibility", hbox(checkbox("History Window     ", 1.0, displayHistoryProperty()), label("  secs"), gap(1.0), textfieldInteger.restrictRange(0, 5000).value(historyHeaderNotificationTimeoutProperty()).digits(3).disabled(displayHistoryProperty().not()))),
            describe("Watchlist Change Flash Notification", hbox(checkbox("Flash Cells     ", 1.0, cellFlashProperty()), label("  msecs"), gap(1.0), textfieldInteger.restrictRange(0, 5000).value(cellFlashTimeoutProperty()).digits(3).disabled(cellFlashProperty().not()))),
            describe("Toggle flash if traded", checkbox("Hi-Vis", 50.0, hiVisProperty())),
            describe("Toggle Watchlist Visibility", checkbox("Watchlist", 50.0, displayMiniWatchlistProperty())),
            describe("Toggle Ticker Visibility", checkbox("Ticker", 50.0, displayTickerProperty())),
            describe("Show daily volume tab", checkbox("Volume Tab", 50.0, displayVolumeTabProperty()))
//                 describe("Launch fusion on startup", checkbox("Launch Fusion", 50.0, launchFusionProperty(),webStartModeProp))
         );
      }
   }

   public BooleanProperty mergeImpliedMainWatchlistProperty() {
      return (BooleanProperty) PersistantName.MergeWatchListImplied.get(getStorage());
   }

   private static SettingsComponent describe(String info, SettingsComponent component) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return underlying.getNode();
               }

               final SettingsInstance underlying = component.create(toggleGroup);

               @Override
               public void reset() {
                  underlying.reset();
               }

               @Override
               public String getInfo() {
                  return info;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
                  super.addToolTip(pane, yIndex);
               }
            };
         }
      };
   }

   public static SettingsComponent hbox(SettingsComponent... descriptors) {
      return hbox(Fx.valueOf(false), descriptors);
   }

   public static SettingsComponent gap(double width) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            HBox hbox = new HBox();
            hbox.setMinWidth(width);

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return hbox;
               }

               @Override
               public void reset() {
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   public static <T> SettingsComponent radiobox(String description, Property<T> property, T selection) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            RadioButton radioButton = new RadioButton(description) {
               {
                  property.addListener(observable -> {
                     selectedProperty().set(property.getValue().equals(selection));
                  });
                  this.selectedProperty().addListener(observable -> {
                     if (selectedProperty().get()) property.setValue(selection);
                  });

                  this.setToggleGroup(toggleGroup);
               }
            };

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return radioButton;
               }

               @Override
               public void reset() {
                  radioButton.selectedProperty().set(property.getValue().equals(selection));
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   /**
    * Determines the left/right view of the Order Book, that is, Bid|Offer view or Offer|Bid view.
    */
   public BooleanProperty bidOnLeftProperty() {
      return (BooleanProperty) PersistantName.BidOnLeft.get(getStorage());
   }

   public static SettingsComponent checkbox(String description, Double gap, Property<Boolean> property) {

      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            RightAlignedCheckBox checkBox = new RightAlignedCheckBox() {
               {
                  this.setText(description);
                  this.getStyleClass().addAll("xfe-settings-chk");
                  this.selectedProperty().bindBidirectional(property);
               }
            };

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return checkBox;
               }

               @Override
               public void reset() {
                  checkBox.selectedProperty().set(property.getValue());
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   public BooleanProperty mergeImpliedMiniWatchlistProperty() {
      return (BooleanProperty) PersistantName.MergeImplied.get(getStorage());
   }

   /**
    * IFF True the orders grid is displayed.
    */
   public BooleanProperty displayOrdersProperty() {
      return (BooleanProperty) PersistantName.DisplayOrders.get(getStorage());
   }

   /**
    * IFF True the trades grid is displayed.
    */
   public BooleanProperty displayTradesProperty() {
      return (BooleanProperty) PersistantName.DisplayTrades.get(getStorage());
   }

   /**
    * IFF True the actions bar is displayed.
    */
   public BooleanProperty displayActionsProperty() {
      return (BooleanProperty) PersistantName.DisplayActions.get(getStorage());
   }

   /**
    * IFF True the historyModule bar is displayed.
    */
   public BooleanProperty displayHistoryProperty() {
      return (BooleanProperty) PersistantName.DisplayHistory.get(getStorage());
   }

   public static SettingsComponent label(String text) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            Label label = new Label(text);

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return label;
               }

               @Override
               public void reset() {
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   /**
    * History header notification timeout.
    */
   public IntegerProperty historyHeaderNotificationTimeoutProperty() {
      return (IntegerProperty) PersistantName.HistoryHeaderNotificationTimeout.get(getStorage());
   }

   /**
    * IF True, the price cell will flash if the price is updated.
    */
   public BooleanProperty cellFlashProperty() {
      return (BooleanProperty) PersistantName.CellFlash.get(getStorage());
   }

   /**
    * define the time how long the price cell in watchlist flashes.
    */
   public IntegerProperty cellFlashTimeoutProperty() {
      return (IntegerProperty) PersistantName.CellFlashTimeout.get(getStorage());
   }

   /**
    * IF True, flash on trades. refer to mantis 0076318
    */
   public BooleanProperty hiVisProperty() {
      return (BooleanProperty) PersistantName.HiVis.get(getStorage());
   }

   /**
    * IFF True the mini watchlist is displayed.
    */
   public BooleanProperty displayMiniWatchlistProperty() {
      return (BooleanProperty) PersistantName.DisplayMiniWatchlist.get(getStorage());
   }

   /**
    * If True the ticker is displayed.
    */
   public BooleanProperty displayTickerProperty() {
      return (BooleanProperty) PersistantName.DisplayTicker.get(getStorage());
   }

   /**
    * If True the volume tab is displayed.
    */
   public BooleanProperty displayVolumeTabProperty() {
      return (BooleanProperty) PersistantName.DisplayVolumeTab.get(getStorage());
   }

   public static SettingsComponent hbox(ObservableBooleanValue disable, SettingsComponent... descriptors) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            HBox hbox = new HBox();
            hbox.getStyleClass().add("xfe-flow-pane");
            hbox.setAlignment(Pos.TOP_LEFT);
            hbox.disableProperty().bind(disable);

            List<SettingsInstance> instances = new ArrayList<>();

            for (SettingsComponent descriptor : descriptors) {
               instances.add(descriptor.create(toggleGroup));
            }

            for (SettingsInstance instance : instances) {
               hbox.getChildren().add(instance.getNode());
            }

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return hbox;
               }

               @Override
               public void reset() {
                  instances.forEach(SettingsInstance::reset);
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   public static EventHandler<ActionEvent> getOpenTradeNotificationProp() {
      return openTradeNotificationProp.get();
   }

   public void setOpenTradeNotificationProp(EventHandler<ActionEvent> handler) {
      openTradeNotificationProp.set(handler);
   }

   @SuppressWarnings("unchecked")
   public List<SettingsComponent> getAlertsSettings() {

      BooleanProperty showTradeAlertsProperty = new SimpleBooleanProperty(tradeAlertsProperty().get() != AlertsGroup.NONE);
      ObjectProperty<AlertsGroup> prevValProperty = new SimpleObjectProperty<>(tradeAlertsProperty().get());
//		final BooleanProperty showTradeAlertsPopupExpiryProperty = new SimpleBooleanProperty(tradeAlertPopupExpiryProperty().get());
      //final IntegerProperty prevExpiryValProperty = new SimpleIntegerProperty(tradeAlertPopupExpiryValueProperty().get());

      if (tradeAlertsListener != null) tradeAlertsProperty().removeListener(tradeAlertsListener);
      else tradeAlertsListener = (arg0, oldVal, newVal) -> {
         if (newVal != AlertsGroup.NONE) prevValProperty.set(newVal);
         else showTradeAlertsProperty.set(false);

         if (oldVal == AlertsGroup.NONE) showTradeAlertsProperty.set(true);
      };

      if (showTradeAlertsListener != null) {
         showTradeAlertsProperty.removeListener(showTradeAlertsListener);
      } else {
         showTradeAlertsListener = arg0 -> tradeAlertsProperty().set(!showTradeAlertsProperty.get() ?
            AlertsGroup.NONE :
            (prevValProperty.get() == null ||
               prevValProperty.get() == AlertsGroup.NONE ?
               AlertsGroup.ALL :
               prevValProperty.get()));
      }

      tradeAlertsProperty().addListener(tradeAlertsListener);
      showTradeAlertsProperty.addListener(showTradeAlertsListener);

      return Arrays.asList(
         describe("Show Trade Alerts", checkbox("Show Trade Alerts", 14.0, showTradeAlertsProperty)),
         checkGrp(showTradeAlertsProperty.not(),
            describe("Select Trade Alerts Type to Show", hbox(gap(15.0), label("on"), gap(15.0), choicebox(tradeAlertsProperty(), choice("All", AlertsGroup.ALL), choice(user.getUserId(), AlertsGroup.MINE)))),
            describe("Determines If Alerts are Shown for Leg Trades", hbox(checkbox("Show Legs", 15.0, alertsShowLegsProperty()))),
            describe("Determines If Trade Alerts Expire", hbox(checkbox("Trade Alerts Expire", 10.0, tradeAlertPopupExpiryProperty()))),
            checkGrp(tradeAlertPopupExpiryProperty().not(), describe("Set the Trade Alerts Popup Expiry Time", hbox(gap(15.0), label("after"), gap(5.0),
               textfieldInteger.value(tradeAlertPopupExpiryValueProperty()).digits(2).restrictRange(0, 1200), gap(3.0), label("seconds"))))),
         describe("Play a Sound when a trade happens", checkbox("Trade Alert Sound", 20.0, tradeSoundProperty())),
         describe("Show trade workup dialog automatically", checkbox("Show Trade Workup", 20.0, autoPopupWorkupProperty())),
         gap(10.0), openTradeNotificationBtn
      );
   }

   /**
    * Determines for what trades the user will receive alerts: All those he/she can see in the iswap/voice tabs (ALL) Only trades where he/she is the buy/sell trader (Mine) or no trade alerts at all (None).
    */
   public ObjectProperty<AlertsGroup> tradeAlertsProperty() {
      return (ObjectProperty<AlertsGroup>) PersistantName.TradeAlerts.get(getStorage());
   }

   private static SettingsComponent checkGrp(ObservableBooleanValue disable, SettingsComponent... descriptors) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            GridPane thisPane = new GridPane() {{
               this.getStyleClass().add("xfe-alertsettings-content-list");
               this.getColumnConstraints().addAll(
                  new ColumnConstraints() {{
                     this.setHgrow(Priority.ALWAYS);
                  }},
                  new ColumnConstraints() {{
                  }});
               disableProperty().bind(disable);
            }};

            List<SettingsInstance> instances = new ArrayList<>();

            for (SettingsComponent descriptor : descriptors) {
               instances.add(descriptor.create(toggleGroup));
            }

            for (int i = 0; i < instances.size(); ++i) {
               Node currentChild = instances.get(i).getNode();
               thisPane.add(currentChild, 0, i);
            }

            return new SettingsInstance() {

               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return thisPane;
               }

               @Override
               public void reset() {
                  instances.forEach(SettingsInstance::reset);
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public List<SettingsInstance> getInstances() {
                  return instances;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
                  for (int i = 0; i < instances.size(); ++i) {
                     instances.get(i).internalAddToolTip(thisPane, i);
                  }
               }
            };
         }
      };
   }

   @SafeVarargs
   public static <T> SettingsComponent choicebox(Property<T> selected, SettingsChoice<T>... choices) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            ChoiceBox<SettingsChoice<T>> choiceBox = new ChoiceBox<>();

            Map<T, SettingsChoice<T>> map = new HashMap<>();

            for (SettingsChoice<T> choice : choices) {
               choiceBox.getItems().add(choice);
               map.put(choice.value, choice);
            }

            choiceBox.getSelectionModel().selectedItemProperty().addListener(observable -> {
               SettingsChoice<T> selectedItem = choiceBox.getSelectionModel().getSelectedItem();

               if (selectedItem == null) return;

               selected.setValue(selectedItem.value);
            });

            selected.addListener(observable -> {
               if (map.containsKey(selected.getValue()))
                  choiceBox.getSelectionModel().select(map.get(selected.getValue()));
               else
                  choiceBox.getSelectionModel().clearSelection();
            });

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return choiceBox;
               }

               @Override
               public void reset() {
                  T value = selected.getValue();
                  if (map.containsKey(value))
                     choiceBox.getSelectionModel().select(map.get(value));
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   public static <T> SettingsChoice<T> choice(String text, T value) {
      return new SettingsChoice<>(text, value);
   }

   /**
    * Do we show legs in alerts?
    */
   public BooleanProperty alertsShowLegsProperty() {
      return (BooleanProperty) PersistantName.AlertsShowLegs.get(getStorage());
   }

   /**
    * Specifies for whether the alert popup will be expiered or not.
    */
   public BooleanProperty tradeAlertPopupExpiryProperty() {
      return (BooleanProperty) PersistantName.TradeAlertPopupExpiryBoolean.get(getStorage());
   }

   /**
    * Specifies for how long (in seconds) the trade alert popup will display.
    */
   public IntegerProperty tradeAlertPopupExpiryValueProperty() {
      return (IntegerProperty) PersistantName.TradeAlertPopupExpiry.get(getStorage());
   }

   /**
    * If true, a sound will be raised if a trade occurs
    */
   public BooleanProperty tradeSoundProperty() {
      return (BooleanProperty) PersistantName.TradeSound.get(getStorage());
   }

   /**
    * If true, the trade workup dialog will popup.
    */
   public BooleanProperty autoPopupWorkupProperty() {
      return (BooleanProperty) PersistantName.AutoPopupWorkup.get(getStorage());
   }

   /**
    * If true, the trades dialog will popup.
    */
   public BooleanProperty tradeAutoPopupProperty() {
      return (BooleanProperty) PersistantName.AutoPopupTrades.get(getStorage());
   }

   /**
    * If true, active tabs will be displayed.
    */
   public BooleanProperty activesTabProperty() {
      return (BooleanProperty) PersistantName.ActivesTab.get(getStorage());
   }

   /**
    * If true, the application would be unlocked after auto logging in
    */
   public BooleanProperty unlockOnAutoLogonProperty() {
      return (BooleanProperty) PersistantName.UnlockOnAutoLogon.get(getStorage());
   }

   /**
    * If true, an order entry dialog would popup for orders referred due to workup ending
    */
   public BooleanProperty popupOnWorkupEndingProperty() {
      return (BooleanProperty) PersistantName.PopupOnWorkupEnding.get(getStorage());
   }

   /**
    * If true, a CM order entry dialog would popup for referred CM orders due to a change in the CM price
    */
   public BooleanProperty popupOnCMPriceChangeProperty() {
      return (BooleanProperty) PersistantName.PopupOnCMPriceChange.get(getStorage());
   }

   /**
    * If true, one click trading is enabled.
    */
   public BooleanProperty tradeOneClickProperty() {
      return (BooleanProperty) PersistantName.OneClickTrading.get(getStorage());
   }

   /**
    * If true, top cut is enabled.
    */
   public BooleanProperty topCutProperty() {
      return (BooleanProperty) PersistantName.TopCut.get(getStorage());
   }

   /**
    * If true, one click hit/take is enabled.
    */
   public BooleanProperty oneClickHitTakeProperty() {
      return (BooleanProperty) PersistantName.OneClickHitTake.get(getStorage());
   }

   public static EventHandler<ActionEvent> getMMOpenAction() {
      return openMMActionProp.get();
   }

   void setMMOpenAction(EventHandler<ActionEvent> handler) {
      openMMActionProp.set(handler);
   }

   @SuppressWarnings("unchecked")
   public List<SettingsComponent> getOrderEntryDefaultSettings() {

      DoubleComponent outrightQuantity = textfieldDouble.value(outrightDefaultQtyProperty(), new SimpleBooleanProperty());
      DoubleComponent strategyQuantity = textfieldDouble.value(strategyDefaultQtyProperty(), new SimpleBooleanProperty());
      SettingsComponent marketSizeCh = checkbox("Market Size", 110.0, marketSizeOnOrderEnterProperty());
      InvalidationListener list = paramObservable -> {
         if (marketSizeOnOrderEnterProperty().get()) {
            outrightQuantity.disabledProp().set(true);
            strategyQuantity.disabledProp().set(true);
         } else {
            outrightQuantity.disabledProp().set(false);
            strategyQuantity.disabledProp().set(false);
         }
      };
      marketSizeOnOrderEnterProperty().addListener(list);
      list.invalidated(null);


      return Arrays.asList(
         describe("If enabled, order size will be default to market size", marketSizeCh),
         describe("Set the Quantity to Populate for non-Strategy Orders",
            hbox(gap(3.0), outrightQuantity.digits(5).restrictRange(0.d, 999.d).setDecimals(0), gap(2.0),
               label("Outright Quantity"))),
         describe("Set the Quantity to Populate for Strategy Orders",
            hbox(gap(3.0), strategyQuantity.digits(5).restrictRange(0.d, 999.d).setDecimals(0), gap(2.0),
               label("Strategy Quantity"))), describe("Set the Price Tightness Highlighting for non-Strategy Orders",
            hbox(gap(3.0), textfieldDouble.value(outrightPriceTight()).digits(5).restrictRange(0.d, 999999.d), gap(2.0),
               label("Outright Price Tightness Highlighting"))), describe("Set the Price Tightness Highlighting for Strategy Orders",
            hbox(gap(3.0), textfieldDouble.value(strategyPriceTight()).digits(5).restrictRange(0.d, 999999.d), gap(2.0),
               label("Strategy  Price Tightness Highlighting"))), describe("Set the Duration Time to Populate in Minutes",
            hbox(gap(3.0), durationEditor.value(defaultDurationProperty()), gap(2.0),
               label("Duration (HH:MM:SS)"))), describe("Select the Default Duration Type",
            hbox(gap(3.0), label("Duration Type"), gap(30.0),
               choicebox(defaultDurationTypeProperty(),
                  choice("Good Till Day", DefaultDurationType.GOOD_TILL_DAY),
                  choice("Good Till Duration", DefaultDurationType.GOOD_TILL_DURATION),
                  choice("Good Till Cancelled", DefaultDurationType.GOOD_TILL_CANCELLED)))), describe("Select the Action on Orders when Logging Off",
            hbox(gap(3.0), label("Action On Logoff"), gap(30.0),
               choicebox(onLogoffActionProperty(),
                  choice("Refer", OnLogoffAction.REFER),
                  choice("Persist", OnLogoffAction.NONE),
                  choice("Withdraw Orders", OnLogoffAction.WITHDRAW)))), describe("Set the Time Delay for the Yours/Mine Buttons",
            hbox(gap(3.0), textfieldInteger.value(yoursMineLitDelayProperty()).digits(5).restrictRange(0, 20000), gap(2.0),
               label("Yours/Mine Lit Delay (milli-seconds)"))), describe("Set the Value for the Order Entry's Left Quantity Button",
            hbox(gap(3.0), textfieldInteger.value(leftQtyBtnProperty()).digits(5).restrictRange(0, 999999), gap(2.0),
               label("Left Quantity Button Value"))), describe("Set the Value for the Order Entry's Middle Quantity Button",
            hbox(gap(3.0), textfieldInteger.value(middleQtyBtnProperty()).digits(5).restrictRange(0, 999999), gap(2.0),
               label("Middle Quantity Button Value"))), describe("Set the Value for the Order Entry's Right Quantity Button", hbox(gap(3.0),
            textfieldInteger.value(rightQtyBtnProperty()).digits(5).restrictRange(0, 999999), gap(2.0),
            label("Right Quantity Button Value"))), describe("Changing the Auto OCO property",
            checkbox("Auto OCO", 131.0, autoOCOProperty())), describe("If enabled, orders will appear anonymous to brokers",
            checkbox("Anon.", 155.0, anonOrdersProperty())), describe("Toggle Orders' 'Shared' Property",
            checkbox("Shared", 148.0, sharedOrdersProperty())),
         describe("Enter managed instead of non-managed orders", checkbox("Managed", 136.0, managedOrdersProperty())),
         describe("Clone orders into RFS", checkbox("Clone to TS", 136.0, clone2RFSProperty())),
         describe("If set, clicking on Yours/Mine will populate Order Entry quantity field with the default amount", checkbox("Yours/Mine Default Amount", 31.0, yoursMineDefaultAmountProperty(), AmountType.DEFAULT, AmountType.ORDER)),
         describe("If Set submitting a Yours/Mine order will withdraw existing resting managed orders",
            checkbox("Yours/Mine Order Withdraw", 30.0, yoursMineOrderWithdrawProperty())), describe("Toggle Automatic Logon Behaviour",
            hbox(checkbox("Auto Logon - ", 5.0, autoLogonEnabledProperty()), gap(12.0), label("timeout (secs)"), gap(5.0),
               textfieldInteger.value(autoLogonTimeoutProperty()).digits(3).disabled(autoLogonEnabledProperty().not()))),
         describe("Toggle Automatic Saving of Changes to the Workspace", checkbox("Auto Save", 130.0, autoSaveWorkspaceProperty()))
      );
   }

   /**
    * Specifies the default Amount for when clicking Bid/Offer or Mine/Yours on n^ implied prices.
    */
   public DoubleProperty outrightDefaultQtyProperty() {
      return (DoubleProperty) PersistantName.OutrightDefaultQty.get(getStorage());
   }

   /**
    * Specifies the default Amount for when clicking Bid/Offer or Mine/Yours on n^ implied prices.
    */
   public DoubleProperty strategyDefaultQtyProperty() {
      return (DoubleProperty) PersistantName.StrategyDefaultQty.get(getStorage());
   }

   /**
    * Specifies the default Amount for when clicking Bid/Offer or Mine/Yours on n^ implied prices.
    */
   public BooleanProperty marketSizeOnOrderEnterProperty() {
      return (BooleanProperty) PersistantName.MarketSizeOnOrderEnter.get(getStorage());
   }

   /**
    * Specifies the default Amount for highlighting outright price tightness
    */
   public DoubleProperty outrightPriceTight() {
      return (DoubleProperty) PersistantName.OutrightPriceTight.get(getStorage());
   }

   /**
    * Specifies the default flash interval
    */
   public IntegerProperty cellFlashInterval() {
      return (IntegerProperty) PersistantName.CellFlashInterval.get(getStorage());
   }

   /**
    * Specifies the default flash interval
    */
   public IntegerProperty priceCellFlashDuration() {
      return (IntegerProperty) PersistantName.PriceCellFlashDuration.get(getStorage());
   }

   /**
    * Specifies the default Amount for highlighting strategy price tightness
    */
   public DoubleProperty strategyPriceTight() {
      return (DoubleProperty) PersistantName.StrategyPriceTight.get(getStorage());
   }

   /**
    * Specifies the default duration (in minutes) for all orders.
    */
   public IntegerProperty defaultDurationProperty() {
      return (IntegerProperty) PersistantName.DefaultDuration.get(getStorage());
   }

   /**
    * Specifies the default duration type (GoodTillDay or GoodTillCancel).
    */
   @SuppressWarnings("unchecked")
   public ObjectProperty<DefaultDurationType> defaultDurationTypeProperty() {
      return (ObjectProperty<DefaultDurationType>) PersistantName.DefaultDurationType.get(getStorage());
   }

   /**
    * Specifies the on logoff action (None or Withdraw).
    */
   @SuppressWarnings("unchecked")
   public ObjectProperty<OnLogoffAction> onLogoffActionProperty() {
      return (ObjectProperty<OnLogoffAction>) PersistantName.OnLogoffAction.get(getStorage());
   }

   /**
    * Specifies for how long (in milliseconds) the Yours/Mine buttons will stay unlit after being triggered.
    */
   public IntegerProperty yoursMineLitDelayProperty() {
      return (IntegerProperty) PersistantName.YoursMineLitDelay.get(getStorage());
   }

   /**
    * Determines the value on/of the left quantity button of the order entry.
    */
   public IntegerProperty leftQtyBtnProperty() {
      return (IntegerProperty) PersistantName.LeftQtyBtn.get(getStorage());
   }

   /**
    * Determines the value on/of the middle quantity button of the order entry.
    */
   public IntegerProperty middleQtyBtnProperty() {
      return (IntegerProperty) PersistantName.MiddleQtyBtn.get(getStorage());
   }

   /**
    * Determines the value on/of the right quantity button of the order entry.
    */
   public IntegerProperty rightQtyBtnProperty() {
      return (IntegerProperty) PersistantName.RightQtyBtn.get(getStorage());
   }

   /**
    * Saving this value will send the userSetAutoOCO transaction
    */
   public BooleanProperty autoOCOProperty() {
      return autoOCOProperty;
   }

   public BooleanProperty anonOrdersProperty() {
      return (BooleanProperty) PersistantName.IsAnon.get(getStorage());
   }

   /**
    * Are orders 'shared' ?
    */
   public BooleanProperty sharedOrdersProperty() {
      return (BooleanProperty) PersistantName.SharedOrders.get(getStorage());
   }

   /**
    * Are orders managed ?
    */
   public BooleanProperty managedOrdersProperty() {
      return (BooleanProperty) PersistantName.ManagedOrders.get(getStorage());
   }

   /**
    * are orders clone to RFS automatically?
    */
   public BooleanProperty clone2RFSProperty() {
      return (BooleanProperty) PersistantName.Clone2EFS.get(getStorage());
   }

   public static <T> SettingsComponent checkbox(String description, Double gap, Property<T> property, T trueValue, T falseValue) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            RightAlignedCheckBox checkBox = new RightAlignedCheckBox() {
               {
                  this.setText(description);
                  this.getStyleClass().addAll("xfe-settings-chk");

                  property.addListener(observable -> selectedProperty().set(property.getValue().equals(trueValue)));

                  this.selectedProperty().addListener(observable -> property.setValue(selectedProperty().get() ? trueValue : falseValue));
               }
            };

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return checkBox;
               }

               @Override
               public void reset() {
                  checkBox.selectedProperty().set(property.getValue().equals(trueValue));
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   /**
    * Specifies whether clicking on Yours/Mine will automatically populate the Qty field in the Order Entry box with the default Amount or with the resting order qty.
    */
   @SuppressWarnings("unchecked")
   public ObjectProperty<AmountType> yoursMineDefaultAmountProperty() {
      return (ObjectProperty<AmountType>) PersistantName.YoursMineDefaultAmount.get(getStorage());
   }

   /**
    * IFF true clicking on Yours/Mine will automatically withdraw an existing resting order in that instrument.
    */
   public BooleanProperty yoursMineOrderWithdrawProperty() {
      return (BooleanProperty) PersistantName.YoursMineOrderWithdraw.get(getStorage());
   }

   /**
    * Specifies whether or not auto login server once disconnected
    */
   public BooleanProperty autoLogonEnabledProperty() {
      return (BooleanProperty) PersistantName.AutoLogonEnabled.get(getStorage());
   }

   /**
    * Specifies for how long (in seconds) autologon waits before attempt to reconnect.
    */
   public IntegerProperty autoLogonTimeoutProperty() {
      return (IntegerProperty) PersistantName.AutoLogonTimeout.get(getStorage());
   }

   /**
    * IFF True changes to user workspace will be saved automatically upon logoff.
    */
   public BooleanProperty autoSaveWorkspaceProperty() {
      return (BooleanProperty) PersistantName.AutoSaveWorkspace.get(getStorage());
   }

   public static <RS extends TableRowFactory<RS, T, TR>, T, TR extends TableRow<T>> SettingsComponent table(
      BooleanProperty disabledPropety,
      ObservableList<T> data,
      ObservableList<TableColumn<T, ?>> cols,
      double maxHeight,
      TableRowFactory<RS, T, TR> rowFactory) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            TableView<T> table = new TableViewHeaderUnmovable<T>() {{
               this.disableProperty().bind(disabledPropety);
               this.setEditable(true);
               this.getColumns().addAll(cols);
               this.setItems(data);
               ObservableList<TableColumn<T, ?>> columns = this.getColumns();

               double maxWidth = 0;

               for (TableColumn<T, ?> column : columns) {
                  maxWidth += column.getWidth();
               }


               this.setPrefSize(maxWidth + 15, maxHeight);

               rowFactory.setRowFactoryIn(this);
            }};

            return new SettingsInstance() {
               @Override
               public Node getNode() {
                  return table;
               }

               @Override
               public void reset() {
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   public SettingsComponent button(String text, BooleanProperty enabledProperty, ObjectProperty<EventHandler<ActionEvent>> actionProp) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            javafx.scene.control.Button button = new javafx.scene.control.Button(text);
            button.setOnAction(event -> {
               if (actionProp.get() != null) {
                  actionProp.get().handle(event);
               }
            });
            if (enabledProperty != null) {
               button.disableProperty().bind(Bindings.not(enabledProperty));
            }
            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return button;
               }

               @Override
               public void reset() {
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   public static SettingsComponent checkbox(String description, Double gap, Property<Boolean> property, BooleanProperty enableProperty) {

      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            RightAlignedCheckBox checkBox = new RightAlignedCheckBox() {
               {
                  this.setText(description);
                  this.getStyleClass().addAll("xfe-settings-chk");
                  this.selectedProperty().bindBidirectional(property);
                  this.disableProperty().bind(enableProperty);
               }
            };

            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return checkBox;
               }

               @Override
               public void reset() {
                  checkBox.selectedProperty().set(property.getValue());
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   public SettingsData copy() {
      return new SettingsData(getStorage().clone(getNames()), user, allFirms);
   }

   public static Set<PersistantName> getNames() {
      return names;
   }

   public List<SettingsComponent> getRfqSettings() {

      SettingsComponent rfqMMAdvChk = checkbox("ADV", 5.0, rfqMMAdvSettingAEnabledProperty());
      rfqMMAdvSettingAEnabledProperty().addListener((observable, oldValue, newValue) -> Fx.delay(100L, () -> {
         if (!oldValue && newValue && openMMActionProp.get() != null) openMMActionProp.get().handle(null);
      }));

      SettingsComponent openMMSetupBtn = button("Open", rfqMMAdvSettingAEnabledProperty());

      return Arrays.asList(
         describe("Show daily RFQ tab", checkbox("RFQ Tab", 173.0, displayRFQTabProperty())),
         describe("Show RFQ instrument tab", checkbox("RFQ notification", 130.0, rfqNotificationProperty())),
         describe("Initiate RFQ Anonymousely", checkbox("Anonymous RFQs", 120.0, rfqAnonymousProperty())),
         //describe("RFQ Initiator orders to be AON", checkbox("Initiator orders AON", 173.0, rfqInitiatorOrderAon())),
         describe("Hide RFQ initiation pane", checkbox("Hide RFQ initiation pane", 85.0, hideRfqPaneProperty())),
         describe("If enabled, non-AutoAccept orders will be hidden from the orderbook", checkbox("Hide non-AutoAccept", 100.0, hideNonAutoAcceptProperty())),
         describe("RFQ Market Maker Setting", hbox(label("RFQ Market Maker Setting")))

      );
   }

   /**
    * Specifies whether or not using advanced rfq market maker setting
    */
   public BooleanProperty rfqMMAdvSettingAEnabledProperty() {
      return (BooleanProperty) PersistantName.rfqMMAdvSetting.get(getStorage());
   }

   public SettingsComponent button(String text, BooleanProperty enabledProperty) {
      return new SettingsComponent() {
         @Override
         public SettingsInstance create(ToggleGroup toggleGroup) {
            Button button = new Button(text);
            button.setOnAction(event -> {
               if (openMMActionProp.get() != null) {
                  openMMActionProp.get().handle(event);
               }
            });
            button.disableProperty().bind(Bindings.not(enabledProperty));
            return new SettingsInstance() {
               {
                  this.reset();
               }

               @Override
               public Node getNode() {
                  return button;
               }

               @Override
               public void reset() {
               }

               @Override
               public String getInfo() {
                  return null;
               }

               @Override
               public void internalAddToolTip(GridPane pane, int yIndex) {
               }
            };
         }
      };
   }

   /**
    * If True the volume tab is displayed.
    */
   public BooleanProperty displayRFQTabProperty() {
      return (BooleanProperty) PersistantName.DisplayRFQTab.get(getStorage());
   }

   /**
    * Specifies whether or not alert on RFQ
    */
   public BooleanProperty rfqNotificationProperty() {
      return (BooleanProperty) PersistantName.rfqNotification.get(getStorage());
   }

   /**
    * Specifies whether or not initiate RFQ anonymously.
    */
   public BooleanProperty rfqAnonymousProperty() {
      return (BooleanProperty) PersistantName.rfqAnonymous.get(getStorage());
   }

   public BooleanProperty hideRfqPaneProperty() {
      return (BooleanProperty) PersistantName.HideRfqPane.get(getStorage());
   }

   public BooleanProperty hideNonAutoAcceptProperty() {
      return (BooleanProperty) PersistantName.HideNonAutoAccept.get(getStorage());
   }

   public ObservableSet<String> getAllFirms() {
      return allFirms;
   }

   @Override
   protected Future<Void> dispose(boolean disposing) {

      storage.dispose();
      return super.dispose(disposing);
   }

   @SuppressWarnings("unchecked")
   private ObservableList<TableColumn<MMFirm, ?>> createRfqTableCols() {
      ObservableList<TableColumn<MMFirm, ?>> cols = FXCollections.observableArrayList();

      // mmFirmSel column
      TableColumn<MMFirm, Boolean> mmFirmSelCol = new TableColumn<>("");
      mmFirmSelCol.setCellValueFactory(new PropertyValueFactory<>("isSelected"));
      mmFirmSelCol.setCellFactory(CheckBoxTableCell.forTableColumn(mmFirmSelCol));
      mmFirmSelCol.setEditable(true);
      mmFirmSelCol.setResizable(false);
      mmFirmSelCol.setMaxWidth(20);


      // mmFirmName column
      TableColumn<MMFirm, String> mmFirmNameCol = new TableColumn<>("MM Firm Name");
      mmFirmNameCol.setCellValueFactory(new PropertyValueFactory<>("firmName"));
      mmFirmNameCol.setEditable(false);
      mmFirmNameCol.setResizable(false);
      mmFirmNameCol.setMinWidth(150);

      cols.addAll(mmFirmSelCol, mmFirmNameCol);

      return cols;
   }

   private final SettingsComponent openTradeNotificationBtn = button("Open Trade Notification Window", null, openTradeNotificationProp);
   private final ParametersStorage storage;
   private final User user;
   private final ObservableSet<String> allFirms;
   private final BooleanProperty autoOCOProperty = new SimpleBooleanProperty(false);
   /*
    * a trigger to open the trade notification
    */
   private final BooleanProperty triggerTradeNotificationProp = new SimpleBooleanProperty(false);
   private final DurationTextField durationEditor = new DurationTextField();
   private ChangeListener<AlertsGroup> tradeAlertsListener;
   private InvalidationListener showTradeAlertsListener;
}
