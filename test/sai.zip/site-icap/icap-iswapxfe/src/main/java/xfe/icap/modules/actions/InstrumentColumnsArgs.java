package xfe.icap.modules.actions;

/**
 * Arguments object to hold the visibility details of columns in Instrument table.
 */
public class InstrumentColumnsArgs {
   private boolean instrumentColumnVisible;
   private boolean totalColumnVisible;
   private boolean actionColumnVisible;
   private boolean priceColumnVisible;
   private boolean cmReferColumnVisible;
   private boolean matchColumnVisible;

   public boolean isInstrumentColumnVisible() {
      return instrumentColumnVisible;
   }

   public void setInstrumentColumnVisible(boolean instrumentColumnVisible) {
      this.instrumentColumnVisible = instrumentColumnVisible;
   }

   public boolean isTotalColumnVisible() {
      return totalColumnVisible;
   }

   public void setTotalColumnVisible(boolean totalColumnVisible) {
      this.totalColumnVisible = totalColumnVisible;
   }

   public boolean isActionColumnVisible() {
      return actionColumnVisible;
   }

   public void setActionColumnVisible(boolean actionColumnVisible) {
      this.actionColumnVisible = actionColumnVisible;
   }

   public boolean isPriceColumnVisible() {
      return priceColumnVisible;
   }

   public void setPriceColumnVisible(boolean priceColumnVisible) {
      this.priceColumnVisible = priceColumnVisible;
   }

   public boolean isCmReferColumnVisible() {
      return cmReferColumnVisible;
   }

   public void setCmReferColumnVisible(boolean cmReferColumnVisible) {
      this.cmReferColumnVisible = cmReferColumnVisible;
   }

   public boolean isMatchColumnVisible() {
      return matchColumnVisible;
   }

   public void setMatchColumnVisible(boolean matchColumnVisible) {
      this.matchColumnVisible = matchColumnVisible;
   }
}
