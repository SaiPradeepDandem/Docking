package xfe.icap.modules.watchlist;

import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.*;
import xstr.util.concurrent.Future;

import xfe.util.XfeFocusModel;
import xfe.modules.settings.SettingsComponent;
import xfe.modules.settings.SettingsInstance;
import xfe.ui.InitialisableView;

public abstract class SettingsView  implements InitialisableView<Region> {
	private List<SettingsInstance> viewInstances;
	private List<SettingsInstance> alertsInstances;
	private List<SettingsInstance> orderEntryDefaultInstances;
	private final List<SettingsInstance> rfqSettingInstances = new ArrayList<>(50);
	private Region root;

	private EventHandler<ActionEvent> cancelAction;
   private EventHandler<ActionEvent> okAction;
	public SettingsView(){
      initialise();
	}
	public SettingsView(
			List<SettingsComponent> viewSettings,
			List<SettingsComponent> alertsSettings,
			List<SettingsComponent> orderEntryDefaultSettings,
			List<SettingsComponent> rfqSettings) {
		this.viewInstances = new ArrayList<>();
		for (SettingsComponent descriptor: viewSettings) {
			ToggleGroup toggleGroup = new ToggleGroup();
			this.viewInstances.add(descriptor.create(toggleGroup));
		}

		this.alertsInstances = new ArrayList<>();
		for (SettingsComponent descriptor: alertsSettings) {
			ToggleGroup toggleGroup = new ToggleGroup();
			this.alertsInstances.add(descriptor.create(toggleGroup));
		}

		this.orderEntryDefaultInstances = new ArrayList<>();
		for (SettingsComponent descriptor: orderEntryDefaultSettings) {
			ToggleGroup toggleGroup = new ToggleGroup();
			this.orderEntryDefaultInstances.add(descriptor.create(toggleGroup));
		}

	      for (SettingsComponent descriptor: rfqSettings) {
	         ToggleGroup toggleGroup = new ToggleGroup();
	         this.rfqSettingInstances.add(descriptor.create(toggleGroup));
	      }
}

	public void reset() {
		if(viewInstances!=null) {
			viewInstances.forEach(SettingsInstance::reset);
		}
		if(orderEntryDefaultInstances!=null) {
			orderEntryDefaultInstances.forEach(SettingsInstance::reset);
		}
	}

	@Override
	public Region getRootElement() {
		if (root == null) {
			root = new VBox() {{
				this.getStyleClass().add("xfe-content-pane");

				HBox titlePane = new HBox() {{
					Label titleLabel = new Label("Settings");
					this.getStyleClass().add("xfe-panel-title");
					this.getChildren().add(titleLabel);
				}};

				GridPane grid = new GridPane() {{
					VBox.setVgrow(this, Priority.ALWAYS);
					this.getStyleClass().add("xfe-settings-grid");

					Label viewLabel = new Label("View") {{
						this.getStyleClass().add("xfe-panel-group-label");
					}};

					ScrollPane viewPane = new ScrollPane() {{
						this.getStyleClass().add("xfe-settings-content-grid");
						this.setContent(new GridPane() {{
							int yIndex = 0;
							this.getStyleClass().add("xfe-settings-content-list");
							this.getColumnConstraints().addAll(
									new ColumnConstraints() {{ this.setHgrow(Priority.ALWAYS); }},
									new ColumnConstraints() {{ }});

							for (SettingsInstance instance: SettingsView.this.viewInstances) {
								this.add(instance.getNode(), 0, yIndex);
								instance.internalAddToolTip(this, yIndex);
								++yIndex;
							}
						}

						});
					}};

					Label alertsLabel = new Label("Alerts") {{
						this.getStyleClass().add("xfe-panel-group-label");
					}};

					ScrollPane alertsPane = new ScrollPane() {{
						this.getStyleClass().add("xfe-settings-content-grid");
						this.setContent(new GridPane() {{
							int yIndex = 0;
							this.getStyleClass().add("xfe-settings-content-list");
							this.getColumnConstraints().addAll(
									new ColumnConstraints() {{ this.setHgrow(Priority.ALWAYS); }},
									new ColumnConstraints() {{ }});

							for (SettingsInstance instance: SettingsView.this.alertsInstances) {
								List<SettingsInstance> listInstances = instance.getInstances();
								this.add(instance.getNode(), 0, yIndex, 1, (listInstances != null) ? instance.getInstances().size()+1 : 1);
								yIndex = AddInstance(instance, this, yIndex);
							}
						}});
					}};

					Label settingsLabel = new Label("Order Entry Defaults") {{
						this.getStyleClass().add("xfe-panel-group-label");
					}};

					ScrollPane settingsPane = new ScrollPane() {{
						this.getStyleClass().add("xfe-settings-content-grid");
						this.setContent(new GridPane() {{
							int yIndex = 0;
							this.getStyleClass().add("xfe-settings-content-list");
							this.getColumnConstraints().addAll(
									new ColumnConstraints() {{ this.setHgrow(Priority.ALWAYS); }},
									new ColumnConstraints() {{ }});

							for (SettingsInstance instance: SettingsView.this.orderEntryDefaultInstances) {
								this.add(instance.getNode(), 0, yIndex);
								instance.internalAddToolTip(this, yIndex);
								++yIndex;
							}
						}});
					}};

               Label rfqLabel = new Label("RFQ Settings") {{
                  this.getStyleClass().add("xfe-panel-group-label");
               }};

               ScrollPane rfqSettingsPane = new ScrollPane() {{
                  this.getStyleClass().add("xfe-settings-content-grid");
                  this.setContent(new GridPane() {{
                     int yIndex = 0;
                     this.getStyleClass().add("xfe-settings-content-list");
                     this.getColumnConstraints().addAll(
                           new ColumnConstraints() {{ this.setHgrow(Priority.ALWAYS); }},
                           new ColumnConstraints() {{ }});

                     for (SettingsInstance instance: SettingsView.this.rfqSettingInstances) {
                        this.add(instance.getNode(), 0, yIndex);
                        instance.internalAddToolTip(this, yIndex);
                        ++yIndex;
                     }
                  }});
               }};

               GridPane.setValignment(viewPane, VPos.TOP);
					GridPane.setValignment(alertsPane, VPos.TOP);
					GridPane.setValignment(settingsPane, VPos.TOP);
					GridPane.setValignment(rfqSettingsPane, VPos.TOP);

					GridPane.setVgrow(viewPane, Priority.ALWAYS);
					GridPane.setVgrow(alertsPane, Priority.ALWAYS);
					GridPane.setVgrow(settingsPane, Priority.ALWAYS);
					GridPane.setVgrow(rfqSettingsPane, Priority.ALWAYS);

					GridPane.setHgrow(viewPane, Priority.ALWAYS);
					GridPane.setHgrow(alertsPane, Priority.ALWAYS);
					GridPane.setHgrow(settingsPane, Priority.ALWAYS);
					GridPane.setHgrow(rfqSettingsPane, Priority.ALWAYS);

					this.getColumnConstraints().addAll(
							new ColumnConstraints() {{ this.setPercentWidth(45.0); }},
							new ColumnConstraints() {{ this.setPercentWidth(55.0); }}
					);

					this.getRowConstraints().addAll(
					   new RowConstraints(){{this.setMinHeight(20);}},
					   new RowConstraints(){{this.setPercentHeight(60);}},
					   new RowConstraints(){{this.setMinHeight(20);}},
					   new RowConstraints(){{this.setPercentHeight(30);}}
					);

					this.add(viewLabel, 0, 0);
					this.add(viewPane, 0, 1);

					this.add(alertsLabel, 0, 2);
					this.add(alertsPane, 0, 3);

					this.add(settingsLabel, 1, 0);
					this.add(settingsPane, 1, 1);

					this.add(rfqLabel, 1, 2);
               this.add(rfqSettingsPane, 1, 3);
				}};

				HBox panelButtons = new HBox() {{
					HBox loadDefaultsButtonBox = new HBox() {{
						HBox.setHgrow(this, Priority.ALWAYS);
						Button loadDefaultsButton = new Button("Load Default Settings");
						loadDefaultsButton.setAlignment(Pos.TOP_LEFT);
						loadDefaultsButton.setOnAction(actionEvent -> loadDefaults());
						this.getChildren().add(loadDefaultsButton);
					}};

					Button saveButton = new Button("OK");
               saveButton.setOnAction(actionEvent -> {
                  EventHandler<ActionEvent> handler = okAction;
                  if (handler != null)
                     handler.handle(actionEvent);
               });

					Button closeButton = new Button("Cancel");
					closeButton.setOnAction(actionEvent -> {
						EventHandler<ActionEvent> handler = cancelAction;
						if (handler != null)
							handler.handle(actionEvent);
					});
					this.getChildren().addAll(loadDefaultsButtonBox, saveButton, closeButton);
					this.getStyleClass().add("xfe-panel-buttons");
				}};

				this.setFillWidth(true);
				this.getChildren().addAll(titlePane, grid, panelButtons);
			}};
		}

		return root;
	}

	//	recursively add tooltips to subInstances
	private int AddInstance(SettingsInstance instance, GridPane pane, int counter) {
		List<SettingsInstance> listInstances = instance.getInstances();
		if (listInstances != null && listInstances.size() > 0) {
			for (SettingsInstance subInstance: listInstances) {
				counter = AddInstance(subInstance, pane, counter);
			}
		} else {
			instance.internalAddToolTip(pane, counter);
			return counter + 1;
		}
		return counter;
	}

	public void setOnCancel(EventHandler<ActionEvent> eventHandler) {
		cancelAction = eventHandler;
	}

	public EventHandler<ActionEvent> getOnCancel(){
		return cancelAction;
	}

   public void setOnOK(EventHandler<ActionEvent> eventHandler) {
      okAction = eventHandler;
   }

   public EventHandler<ActionEvent> getOnOK(){
      return okAction;
   }

	@Override
	public void requestFocus() {
		XfeFocusModel.setViewFocus(getRootElement());
	}

	public abstract Future<Void> applyChanges();

	protected abstract void loadDefaults();
}
