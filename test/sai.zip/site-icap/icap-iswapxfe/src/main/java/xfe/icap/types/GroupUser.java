package xfe.icap.types;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.beans.property.*;
import javafx.collections.ObservableSet;

import xfe.icap.amp.AmpGroupUser;
import xstr.session.QueryFeed;
import xstr.session.ServerSession;
import xstr.session.XtrQueryRequestBuilder;
import xstr.util.*;
import xstr.session.ObservableReplyRow;
import xstr.session.ObservableReplyRow.ObservableRowFactory;

import java.util.HashSet;

public class GroupUser {
   private final QueryFeed feed;
   private final FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpGroupUser.rep , new ObservableRowFactory());
   public final BooleanProperty readyProperty = new SimpleBooleanProperty(false);
   private final ObservableSet<Tuple2<String,String>> userGroups;
   private final ObservableSet<String> loggedOnUserGroups = FXCollections.observableSet(new HashSet<String>(100));

   public GroupUser(ServerSession session) throws Exception{
      XtrQueryRequestBuilder reqBuilder = XtrQueryRequestBuilder.create(AmpGroupUser.req, session).set(AmpGroupUser.groupType, AmpGroupUser.DESK);
      String loggedUserId = session.getLoggedOnUserId();
      feed = session.queries.getFeedSource(reqBuilder.build());
      feed.addListener(aggregator);
      readyProperty.bind(aggregator.busyProperty().not());
      userGroups = Fx.tuple2SetBy(true,aggregator.items, new Fun1<ObservableReplyRow, String>() {

         @Override
         public String call(ObservableReplyRow a) {
            return a.getValue(AmpGroupUser.userId);
         }
      }, new Fun1<ObservableReplyRow, String>() {

         @Override
         public String call(ObservableReplyRow a) {
            return a.getValue(AmpGroupUser.groupId);
         }
      });

      aggregator.items.addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            loggedOnUserGroups.clear();
            for(ObservableReplyRow row: aggregator.items){
               String userId = row.getValue(AmpGroupUser.userId);
//               System.out.println("userId="+userId);
               if(loggedUserId.equals(userId)) {
                  loggedOnUserGroups.add(row.getValue(AmpGroupUser.groupId));
//                  System.out.println("loggedOnUserGroups="+loggedOnUserGroups);
               }
            }
         }
      });

   }

   public boolean isUserInGroup(String userId, String groupId){
      Tuple2<String,String> temp = Tuple.of(userId, groupId);
      return userGroups.contains(temp);
   }

   public  ObservableSet<String> getLoggedOnUserGroups(){
      return loggedOnUserGroups;
   }

   public void dispose() {
      feed.removeListener(aggregator);
      readyProperty.unbind();
      userGroups.clear();
      feed.dispose();
   }
}
