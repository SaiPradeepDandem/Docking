package xfe.icap.modules.sectabsui;

import com.sun.javafx.scene.control.skin.VirtualFlow;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Bounds;
import javafx.scene.control.TableCell;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.util.Duration;

import java.util.function.Consumer;

/**
 * Util class to perform the tick up down for the given region.
 */
public class TickUpDown {

    /**
     * Specifies whether the action is performed by clicking the arrow. The need for this variable is to not show
     * the arrows of underlying cell when either of the arrow(s) is clicked. This will be reset when moused entered
     * on the source node.
     */
    private static boolean clickedOnArrow = false;
    private TableCell<?, ?> tableCell;
    private VirtualFlow<?> virtualFlow;
    private Consumer<Boolean> callBack;

    private BooleanProperty showing = new SimpleBooleanProperty();
    private Timeline hidingTimer = new Timeline();
    private boolean onRegion = false;
    private boolean onPopup = false;
    private DoubleProperty arrowHeight;
    private boolean enabled = false;

    public TickUpDown(TableCell<?, ?> tableCell) {
        this.tableCell = tableCell;
        tableCell.tableViewProperty().addListener((obs, old, val) -> {
            if (virtualFlow == null && val != null) {
                virtualFlow = (VirtualFlow<?>) tableCell.getTableView().lookup(".virtual-flow");
            }
        });
        init();
    }

    public void hide(){
        showing.set(false);
    }
    
    private static boolean isClickedOnArrow() {
        return TickUpDown.clickedOnArrow;
    }

    private static void setClickedOnArrow(boolean clickedOnArrow) {
        TickUpDown.clickedOnArrow = clickedOnArrow;
    }

    public void setCallBack(Consumer<Boolean> callBack) {
        this.callBack = callBack;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if(!enabled){
            hide();
        }
    }

    private void init() {
        hidingTimer.getKeyFrames().add(new KeyFrame(new Duration(0)));
        hidingTimer.setOnFinished(event -> {
            if (!onRegion && !onPopup) {
                showing.set(false);
            }
        });

        arrowHeight = new SimpleDoubleProperty();
        arrowHeight.bind(tableCell.heightProperty().divide(4).multiply(3));

        Popup upPop = new Popup();
        upPop.setAutoHide(true);
        Popup downPop = new Popup();
        downPop.setAutoHide(true);

        StackPane upArrowPane = new StackPane();
        upArrowPane.prefHeightProperty().bind(arrowHeight);
        upArrowPane.prefWidthProperty().bind(tableCell.widthProperty());
        upArrowPane.getStyleClass().add("tickupdown-arrow-btn-up");
        upArrowPane.getChildren().add(createArrow(false));
        upArrowPane.setOnMouseEntered(e -> {
            onPopup = true;
            showing.set(true);
        });
        upArrowPane.setOnMouseClicked(e -> {
            int rowIndex = tableCell.getTableRow().getIndex();
            if (rowIndex > virtualFlow.getFirstVisibleCellWithinViewPort().getIndex()) {
                setClickedOnArrow(true);
            }
            if (callBack != null) {
                callBack.accept(true);
            }
            onPopup = false;
            hidingTimer.playFromStart();
        });

        StackPane downArrowPane = new StackPane();
        downArrowPane.prefHeightProperty().bind(arrowHeight);
        downArrowPane.prefWidthProperty().bind(tableCell.widthProperty());
        downArrowPane.getStyleClass().add("tickupdown-arrow-btn-down");
        downArrowPane.getChildren().add(createArrow(true));
        downArrowPane.setOnMouseEntered(e -> {
            onPopup = true;
            showing.set(true);
        });
        downArrowPane.setOnMouseClicked(e -> {
            int rowIndex = tableCell.getTableRow().getIndex();
            if (rowIndex < virtualFlow.getLastVisibleCellWithinViewPort().getIndex()) {
                setClickedOnArrow(true);
            }
            if (callBack != null) {
                callBack.accept(false);
            }
            onPopup = false;
            hidingTimer.playFromStart();
        });

        VBox upPane = new VBox();
        upPane.getChildren().addAll(upArrowPane);
        upPane.setOnMouseEntered(e -> {
            onPopup = true;
            showing.set(true);
        });
        upPane.setOnMouseExited(e -> {
            onPopup = false;
            if (!onRegion) {
                hidingTimer.playFromStart();
            } else {
                realignPopup(upPop, true);
            }
        });

        VBox downPane = new VBox();
        downPane.getChildren().addAll(downArrowPane);
        downPane.setOnMouseEntered(e -> {
            onPopup = true;
            showing.set(true);
        });
        downPane.setOnMouseExited(e -> {
            onPopup = false;
            if (!onRegion) {
                hidingTimer.playFromStart();
            } else {
                realignPopup(downPop, false);
            }
        });

        upPop.getContent().add(upPane);
        downPop.getContent().add(downPane);
        addListeners(upPop, downPop);
    }

    private void addListeners(Popup upPopup, Popup downPopup) {
        showing.addListener((obs, oldVal, show) -> {
            if (show.booleanValue()) {
                realignPopup(upPopup, true);
                realignPopup(downPopup, false);
                tableCell.getScene().getWindow().requestFocus();
            } else {
                upPopup.hide();
                downPopup.hide();
            }
        });
        tableCell.setOnMouseEntered(e -> {
            if (enabled && !isClickedOnArrow()) {
                onRegion = true;
                showing.set(true);
            }
            setClickedOnArrow(false);
        });
        tableCell.setOnMouseExited(e -> {
            if (enabled) {
                onRegion = false;
                hidingTimer.playFromStart();
            }
        });
    }

    private void realignPopup(Popup popup, boolean isUp) {
        final Bounds bounds = tableCell.localToScreen(tableCell.getBoundsInLocal());
        final double x = bounds.getMinX();
        final double y = bounds.getMinY();
        final double hgt = arrowHeight.get();
        final double anchorY = isUp ? y - hgt : y + bounds.getHeight();
        popup.show(tableCell, x, anchorY);
    }

    private StackPane createArrow(boolean isDown) {
        final StackPane arrow = new StackPane();
        arrow.maxHeightProperty().bind(tableCell.heightProperty().divide(3.5));
        arrow.maxWidthProperty().bind(arrow.maxHeightProperty());
        arrow.getStyleClass().add(isDown ? "tickupdown-arrow-down" : "tickupdown-arrow-up");
        return arrow;
    }

}
