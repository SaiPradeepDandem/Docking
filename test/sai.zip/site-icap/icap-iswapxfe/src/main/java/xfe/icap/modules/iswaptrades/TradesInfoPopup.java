package xfe.icap.modules.iswaptrades;

import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableBooleanValue;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.types.TradeSide;
import xstr.session.ServerSession;
import xstr.util.XfeVersionInfo;
import xfe.util.scene.control.Builders.LabelBuilder;
import xfe.util.scene.control.EnhancedTableView;
import xfe.util.scene.control.InfoPopup;
import xfe.icap.amp.AmpTrade;
import xstr.session.ObservableReplyRow;
import xfe.ui.table.AsnObservableColumn;

public final class TradesInfoPopup extends InfoPopup {
   private static final Logger logger = LoggerFactory.getLogger(TradesInfoPopup.class);
   private final ServerSession session;

   public TradesInfoPopup(
         Node node,
         ObservableList<ObservableReplyRow> rows,
         TradesFilters filters,
         ServerSession session,
         ObservableBooleanValue showing) {
      super(node, showing, false);
      this.session = session;
      contentProperty().bind(new ObjectBinding<Region>() {
         { bind(detachedProperty()); }
         @Override
         protected Region computeValue() {
            boolean detached = detachedProperty().get();
            TableView<ObservableReplyRow> tableView;
            tableView = createTableView(rows, filters);
            VBox vbox = createDecorationPaneAttached(detached, tableView, rows.get(0));
            vbox.getChildren().add(0, createDraggableHeaderPane("Trade Info"));
            return vbox;
         }});
   }

   private VBox createDecorationPaneAttached(boolean detached, TableView<ObservableReplyRow> asnTableView, ObservableReplyRow row) {
		if (detached)
			asnTableView.getStyleClass().add("detached");

      ColumnConstraints colConstr0 = new ColumnConstraints();
      colConstr0.setHgrow(Priority.ALWAYS);
      ColumnConstraints colConstr1 = new ColumnConstraints();
      colConstr1.setHgrow(Priority.SOMETIMES);
      ColumnConstraints colConstr2 = new ColumnConstraints();
      colConstr2.setPrefWidth(10);
      ColumnConstraints colConstr3 = new ColumnConstraints();
      colConstr1.setHgrow(Priority.SOMETIMES);
      GridPane gridPane = new GridPane();
      gridPane.getStyleClass().add("xfe-info-grid");
      gridPane.getColumnConstraints().addAll(colConstr0, colConstr1, colConstr2, colConstr3);

		LabelBuilder infoLabelBuilder = LabelBuilder.create();
		if (detached)
			infoLabelBuilder.styleClass("label", "xfe-grid-instrument-label");

		gridPane.add(infoLabelBuilder.text(row.getValue(AmpTrade.secCode) + "    " + row.getValue(AmpTrade.tradeNo)).build(), 0, 0);

		VBox infoContent = new VBox();
		if (!detached) {
			infoContent.getChildren().setAll(gridPane, asnTableView);
			infoContent.getStyleClass().add("xfe-info-content");
		} else {

         StackPane detachedGridWrapper = new StackPane();
         detachedGridWrapper.getStyleClass().add("detached-grid-wrapper");
         detachedGridWrapper.getChildren().add(gridPane);

         StackPane detachedTableWrapper = new StackPane();
         detachedTableWrapper.getStyleClass().add("detached-table-wrapper");
         detachedTableWrapper.getChildren().add(asnTableView);

         infoContent.getStyleClass().add("xfe-info-detached-content");
         infoContent.getChildren().setAll(detachedGridWrapper, detachedTableWrapper);
		}

      VBox decoration = new VBox();
      decoration.getStyleClass().add(!detached ? "xfe-info-decoration" : "xfe-info-detached-decoration");
      decoration.getChildren().add(infoContent);
      return decoration;
	}

   @SuppressWarnings("unchecked")
   private TableView<ObservableReplyRow> createTableView(ObservableList<ObservableReplyRow> rows, TradesFilters filters) {
      return new EnhancedTableView<ObservableReplyRow>() {{
         ObservableList<TableColumn<ObservableReplyRow, ?>> columns = this.getColumns();
         TradeSide side = filters.tradeSideValueFactory().call(rows.get(0)).get();
         String buySidePrefix = side == TradeSide.BUY ? "Pay " : "";
         String sellSidePrefix = side == TradeSide.SELL ? "Rec " : "";

         if(session.isLoggedOnUserBroker()){
            columns.add(TradesColumns.createTraderColumn(session,TradeSide.BUY,null));
            columns.add(TradesColumns.createTraderColumn(session,TradeSide.SELL,null));
            columns.add(TradesColumns.createPayBrokerColumn(session,null));
            columns.add(TradesColumns.createRecBrokerColumn(session,null));
         }else{
            columns.add(TradesColumns.createTraderColumn(session,null));
            columns.add(TradesColumns.createBrokerColumn(session,null));
         }




         if(!session.isLoggedOnUserBroker()){
            columns.add(TradesColumns.createPayRecColumn(session));
         }
         columns.add(TradesColumns.createBuyStpStatusColumn());
         columns.add(TradesColumns.createSellStpStatusColumn());


         if (XfeVersionInfo.isDevelopmentVersion())
            columns.add(new AsnObservableColumn<String>() {{
               this.setPrefWidth(150);
               this.setAccessor(AmpTrade.tradeNo);
            }});

         // -------------------------------------------------------------------------
         if (side != TradeSide.SELL)
            columns.add(TradesColumns.createBackOfficeRefColumn(TradeSide.BUY, buySidePrefix));
         if (side != TradeSide.BUY)
            columns.add(TradesColumns.createBackOfficeRefColumn(TradeSide.SELL, sellSidePrefix));
         if (side != TradeSide.SELL)
            columns.add(TradesColumns.createMarkitWireIdColumn(TradeSide.BUY, buySidePrefix));
         if (side != TradeSide.BUY)
            columns.add(TradesColumns.createMarkitWireIdColumn(TradeSide.SELL, sellSidePrefix));

         if (side != TradeSide.SELL)
            columns.add(TradesColumns.createTradeTypeColumn(TradeSide.BUY, buySidePrefix));
         if (side != TradeSide.BUY)
            columns.add(TradesColumns.createTradeTypeColumn(TradeSide.SELL, sellSidePrefix));

         this.setItems(rows);
         this.getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
      }};
   }
}
