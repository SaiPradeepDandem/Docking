package xfe.icap.modules.watchlist;

import javafx.scene.Group;
import javafx.scene.Scene;

public class WatchlistScene extends Scene {
	public WatchlistScene() {
		this(new Group());
	}

	public WatchlistScene(Group root) {
		super(root);
	}

	public Group getRootGroup() {
		return (Group)this.getRoot();
	}
}
