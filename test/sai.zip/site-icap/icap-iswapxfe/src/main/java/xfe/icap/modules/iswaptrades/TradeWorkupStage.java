package xfe.icap.modules.iswaptrades;

import java.util.Date;

import xfe.util.scene.control.AppContainer;
import xfe.icap.ui.ExpireStage;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

import xstr.types.TradeSide;
import xfe.util.scene.control.VerticalAppContainer;
import xstr.util.concurrent.Future;

public class TradeWorkupStage extends ExpireStage{

   public static final String BID_CONTENT_STYLE = "xfe-bid-content-trade";
   public static final String ASK_CONTENT_STYLE = "xfe-ask-content-trade";

   private final TradeWorkupPane contentPane;
   private final VerticalAppContainer appContainer;
   private final ObservableList<TradeAlert> workupTrades;
   private final TradeAlert tradeAlert;
   public TradeWorkupStage(TradeAlert trade, ObservableList<TradeAlert> workupTrades, Date engineTime) {
      super(StageStyle.TRANSPARENT,trade.workupExpTime.getTime() - engineTime.getTime());
      setTitle("i-Swap - Bilateral Trade Workup");
      this.workupTrades = workupTrades;
      this.tradeAlert = trade;
      initModality(Modality.NONE);

      setTitle("i-Swap - Bilateral Trade Workup");

      setScene(new Scene(new VBox()));
      getScene().setFill(null);

      focusedProperty().addListener(new ChangeListener<Boolean>() {

         @Override
         public void changed(ObservableValue<? extends Boolean> arg0, Boolean arg1, Boolean arg2) {
            if (!TradeWorkupStage.this.isFocused()) {
               TradeWorkupStage.this.setIconified(false);
               TradeWorkupStage.this.toFront();
            }
         }
      });

      setOnShowing(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent windowEvent) {
            TradeWorkupStage.this.setIconified(true);
            TradeWorkupStage.this.setIconified(false);
         }
      });

      setOnShown(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent windowEvent) {
            TradeWorkupStage.this.toFront();
            TradeWorkupStage.this.requestFocus();
            TradeWorkupStage.this.show();
            TradeWorkupStage.this.toFront();
         }
      });

      //spec does not say so , leave it

//      this.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
//
//         @Override
//         public void handle(KeyEvent event) {
//              if(event.getCode() == KeyCode.ESCAPE)
//                 TradeWorkupStage.this.close();
//         }
//
//      });

      String sideStyle = trade.side == TradeSide.BUY ? BID_CONTENT_STYLE : ASK_CONTENT_STYLE;
      contentPane = TradeWorkupPane.load(null, trade);
      appContainer = new VerticalAppContainer(sideStyle, TradeWorkupPane.PREFWIDTH, TradeWorkupPane.PREFHEIGHT, false,null,true);
      appContainer.setContent(new VBox() {
         {
            this.setPrefWidth(TradeWorkupPane.PREFWIDTH);
            this.getChildren().add(new StackPane() {
               {
                  // Header outer
                  StackPane headerOuter = this;
                  this.getStyleClass().addAll(sideStyle, "xfe-trade-notifications-header");
                  this.setMinWidth(TradeWorkupPane.PREFWIDTH);
                  this.getChildren().add(new HBox() {
                     {
                        this.prefWidthProperty().bind(headerOuter.widthProperty());
                        this.getStyleClass().addAll("xfe-trade-notifications-header-content");
                        this.setFillHeight(true);
                        this.getChildren().setAll(new ImageView() {
                           {
                              // Logo
                              this.getStyleClass().addAll("xfe-icon-app-title");
                           }
                        }, new Pane() {
                           {
                              // Spacer
                              HBox.setHgrow(this, Priority.ALWAYS);
                           }
                        }, new Label() {
                           {
                              // Right Caption
                              this.getStyleClass().add( "xfe-title");
                              this.setText("Bilateral Trade Workup");
                           }
                        });
                     }
                  });
                  VBox.setVgrow(this, Priority.NEVER);
               }
            });
            Node node = contentPane.getRootNode();
            this.getChildren().add(node);
            VBox.setVgrow(node, Priority.ALWAYS);
         }
      });
      contentPane.displayTrade(engineTime);
      appContainer.setAllowIconified(false);
      appContainer.setOnClose(() -> {
         // items.clear();
         // TradeNotificationsStage.this.hide();
         // JIANG seems in icap tw5, close the tradeup dialog does nothing
         TradeWorkupStage.this.close();
         return Future.valueOf(true);
      });
      this.setScene(new Scene(appContainer.getRoot()));

      this.setOnCloseRequest(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent windowEvent) {
            TradeWorkupStageFactory.workupStageClosed(trade);
            windowEvent.consume();
         }
      });
   }

   public void disableInputAndShowFinalSize() {
      contentPane.disableInputAndShowFinalSize();
   }


   @Override
   public String toString() {
      return "stage : "+this.getTitle();
   }

   @Override
   protected void stageExpired() {
      workupTrades.remove(tradeAlert);
   }

   AppContainer getAppContainer(){
      return appContainer;
   }
}
