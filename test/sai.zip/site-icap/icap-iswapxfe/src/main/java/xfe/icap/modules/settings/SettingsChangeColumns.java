package xfe.icap.modules.settings;

import java.util.UUID;

import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.util.Callback;
import xstr.util.Strings;

import xstr.util.Fx;

public class SettingsChangeColumns {

	//CheckBoxTableCell for creating a CheckBox in a table cell
	public static class CheckBoxTableCell extends TableCell<SettingsChange, Boolean> {
		private final CheckBox checkBox;
		private BooleanProperty ov;

		public CheckBoxTableCell() {
			this.checkBox = new CheckBox();
			this.checkBox.setAlignment(Pos.CENTER);

			setAlignment(Pos.CENTER);
		}

		@Override public void updateItem(Boolean item, boolean empty) {
			super.updateItem(item, empty);
			if (ov != null) {
				checkBox.selectedProperty().unbindBidirectional(ov);
				ov = null;
			}

			if (!empty) {
				setGraphic(checkBox);
				ov = getTableView().getItems().get(getIndex()).appliedStatusProperty();
				checkBox.selectedProperty().bindBidirectional(ov);
			}
		}
	}

	public static TableColumn<SettingsChange, Boolean> createApplyColumn() {

		TableColumn<SettingsChange, Boolean> col = new TableColumn<SettingsChange, Boolean>("Apply");
		col.setCellFactory(new Callback<TableColumn<SettingsChange,Boolean>, TableCell<SettingsChange,Boolean>>() {

			@Override
			public TableCell<SettingsChange, Boolean> call(
					TableColumn<SettingsChange, Boolean> arg0) {
				return new CheckBoxTableCell();
			}
		});
		col.setCellValueFactory(new Callback<CellDataFeatures<SettingsChange,Boolean>, ObservableValue<Boolean>>() {
			public ObservableValue<Boolean> call(CellDataFeatures<SettingsChange, Boolean> p) {
				return Fx.valueOf(p.getValue().getAppliedStatus());
			}
		});
		col.setSortable(false);
		col.setPrefWidth(50);
		col.setResizable(false);

		return col;
	}

	public static TableColumn<SettingsChange, String> createDescriptionColumn() {

		TableColumn<SettingsChange, String> col = new TableColumn<SettingsChange, String>("Description");
		col.setCellValueFactory(new Callback<CellDataFeatures<SettingsChange,String>, ObservableValue<String>>() {
			public ObservableValue<String> call(CellDataFeatures<SettingsChange, String> p) {
				return Fx.objectValueOf(indent(p.getValue().getLevel()) + p.getValue().getDescription());
			}

			private String indent(int level) {
				String indentation = "";
				for (int i = 0; i < level; ++i)
					indentation += "  ";
				return indentation;
			}
		});
		col.setSortable(false);
		col.setPrefWidth(250);
		col.setResizable(true);

		return col;
	}

	public static TableColumn<SettingsChange, String> createMineTheirColumn(boolean isMine) {
		TableColumn<SettingsChange, String> col = new TableColumn<SettingsChange, String>(isMine ? "Local" : "PRESET");
		col.setCellValueFactory(new Callback<CellDataFeatures<SettingsChange,String>, ObservableValue<String>>() {
			public ObservableValue<String> call(CellDataFeatures<SettingsChange, String> p) {
				Object theValue = isMine ? p.getValue().getMyValue() :
					p.getValue().getTheirValue();
				if (theValue == null) return Fx.objectValueOf("");

				return Fx.objectValueOf(asString(theValue));
			}

			private String asString(Object o) {
				String result;

				if (o instanceof ObservableValue) {
					result = asString(((ObservableValue<?>) o).getValue());
				} else if (o instanceof Enum) {
					result = Strings.formatEnumerated(o.toString());
				} else if (o instanceof Boolean) {
					result = ((Boolean) o) ? "Yes" : "No";
				} else if (o instanceof UUID) {
					result = "";
				} else if (o != null) {
					result = o.toString();
				} else {
					result = null;
				}

				return result != null ? result : "NULL";
			}
		});
		col.setSortable(false);
		col.setPrefWidth(100);
		col.setResizable(true);

		return col;
	}
}
