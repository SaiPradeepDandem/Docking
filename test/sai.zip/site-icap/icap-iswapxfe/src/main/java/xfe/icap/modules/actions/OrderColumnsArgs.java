package xfe.icap.modules.actions;

/**
 * Arguments object to hold the visibility details of columns in Orders table.
 */
public class OrderColumnsArgs {
   private boolean timeColumnVisible;
   private boolean orderNoColumnVisible;
   private boolean sideColumnVisible;
   private boolean instrumentColumnVisible;
   private boolean productColumnVisible;
   private boolean priceColumnVisible;
   private boolean sizeColumnVisible;
   private boolean balanceColumnVisible;

   public void setTimeColumnVisible(boolean timeColumnVisible) {
      this.timeColumnVisible = timeColumnVisible;
   }

   public void setOrderNoColumnVisible(boolean orderNoColumnVisible) {
      this.orderNoColumnVisible = orderNoColumnVisible;
   }

   public void setSideColumnVisible(boolean sideColumnVisible) {
      this.sideColumnVisible = sideColumnVisible;
   }

   public void setInstrumentColumnVisible(boolean instrumentColumnVisible) {
      this.instrumentColumnVisible = instrumentColumnVisible;
   }

   public void setProductColumnVisible(boolean productColumnVisible) {
      this.productColumnVisible = productColumnVisible;
   }

   public void setPriceColumnVisible(boolean priceColumnVisible) {
      this.priceColumnVisible = priceColumnVisible;
   }

   public void setSizeColumnVisible(boolean sizeColumnVisible) {
      this.sizeColumnVisible = sizeColumnVisible;
   }

   public void setBalanceColumnVisible(boolean balanceColumnVisible) {
      this.balanceColumnVisible = balanceColumnVisible;
   }

   public void setTraderColumnVisible(boolean traderColumnVisible) {
      this.traderColumnVisible = traderColumnVisible;
   }

   public void setBrokerColumnVisible(boolean brokerColumnVisible) {
      this.brokerColumnVisible = brokerColumnVisible;
   }

   public void setStatusColumnVisible(boolean statusColumnVisible) {
      this.statusColumnVisible = statusColumnVisible;
   }

   private boolean traderColumnVisible;
   private boolean brokerColumnVisible;
   private boolean statusColumnVisible;

   public boolean isTimeColumnVisible() {
      return timeColumnVisible;
   }

   public boolean isOrderNoColumnVisible() {
      return orderNoColumnVisible;
   }

   public boolean isSideColumnVisible() {
      return sideColumnVisible;
   }

   public boolean isInstrumentColumnVisible() {
      return instrumentColumnVisible;
   }

   public boolean isProductColumnVisible() {
      return productColumnVisible;
   }

   public boolean isPriceColumnVisible() {
      return priceColumnVisible;
   }

   public boolean isSizeColumnVisible() {
      return sizeColumnVisible;
   }

   public boolean isBalanceColumnVisible() {
      return balanceColumnVisible;
   }

   public boolean isTraderColumnVisible() {
      return traderColumnVisible;
   }

   public boolean isBrokerColumnVisible() {
      return brokerColumnVisible;
   }

   public boolean isStatusColumnVisible() {
      return statusColumnVisible;
   }
}
