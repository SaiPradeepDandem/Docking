package xfe.icap.modules.tabeditorview;

import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.EventHandler;
import javafx.scene.control.ListView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import xfe.types.DomainDataFormat;
import xfe.types.SecBoard;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.util.Fun1;
import xstr.util.Fx;
import xstr.util.Util;
import xstr.util.concurrent.Disposable;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Future;

import java.util.*;
import java.util.function.Consumer;

class IncludedSecuritiesView extends ListView<SecBoard> implements Disposable {
	private final StringProperty selectedProduct = new SimpleStringProperty();
	private final ObservableSet<SecBoard> checkedSecurities = FXCollections.observableSet(new HashSet<>());
	private final ObservableSet<Integer> allIndices = Fx.map(
			checkedSecurities,
			new Fun1<SecBoard, Integer>() {
				@Override
				public Integer call(SecBoard value) {
					return value != null ? getItems().indexOf(value) : -1;
				}
			});
	private final ObservableSet<Integer> filteredIndices = Fx.filterBy(
			allIndices,
			new Fun1<Integer, Boolean>() {
				@Override
				public Boolean call(Integer e) {
					return e >= 0;
				}
			});
	private final ObservableList<Integer> indices = Fx.sortBy(
			filteredIndices,
      Integer::compare);

	private final ListView<WatchlistSpec_v2> tabsListView;
	IncludedSecuritiesView(ObservableList<SecBoard> allSecurities, Consumer<String> notifier,
                          ListView<WatchlistSpec_v2> tabsListView,
                          int instMaxCount) {
	   this.setId("xfe-iswap-secseditview-selected");
	   this.tabsListView = tabsListView;
	   setNotifier(notifier);
		this.getStyleClass().add("xfe-list-view");
      XfeTooltipFactory.setTooltip(this);
      EventHandler<DragEvent> dragOver = new EventHandler<DragEvent>() {
         @Override
         public void handle(DragEvent dragEvent) {
            if (dragEvent.getGestureSource() != this && dragEvent.getDragboard().hasContent(DomainDataFormat.SECBOARDS)) {
               dragEvent.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }

            dragEvent.consume();
         }
      };


      EventHandler<DragEvent> dragDropEvent = dragEvent -> {
         Dragboard dragboard = dragEvent.getDragboard();

         Object sourceObject = dragEvent.getGestureSource();
         int rawDropIndex;
         if(getItems().size()==0){
            rawDropIndex = 0;
         } else {
            Object targetObject = dragEvent.getGestureTarget();
            if (targetObject instanceof IncludedSecurityCell) {
               IncludedSecurityCell object = (IncludedSecurityCell) targetObject;
               rawDropIndex = getItems().indexOf(object.getItem());
            }else{
               rawDropIndex = 0;
            }
         }

         if (sourceObject instanceof IncludedSecurityCell) {
            List<SecBoard> items1 = getItems();
            List<SecBoard> copyOfItems = new ArrayList<>(items1);
            copyOfItems.retainAll(checkedSecurities);

            int dropIndex = rawDropIndex != -1 ? rawDropIndex : items1.size();
            List<SecBoard> afterList = new ArrayList<>(items1.subList(dropIndex, items1.size()));

            items1.removeAll(checkedSecurities);

            boolean done = false;

            for (SecBoard secBoardBefore: afterList) {
               int insertionPoint = items1.indexOf(secBoardBefore);

               if (insertionPoint >= 0) {
                  items1.addAll(insertionPoint, copyOfItems);
                  done = true;
                  break;
               }
            }

            if (!done) {
               items1.addAll(copyOfItems);
            }

            dragboard.setContent(new ClipboardContent());
            dragEvent.setDropCompleted(true);
            dragEvent.consume();

            return;
         }

         if (dragboard.hasContent(DomainDataFormat.SECBOARDS)) {
            Object content = dragboard.getContent(DomainDataFormat.SECBOARDS);

            if (content instanceof String) {
               String text = (String) content;
               Collection<String> droppedSecBoardNames = new LinkedHashSet<>(Arrays.asList(trimAll(text.split("\n"))));
               Collection<String> includedSecBoardNames = Util.mapUnordered(getItems(), SecBoard.GET_SEC_CODE);
               Collection<String> newSecBoardNames = Util.minus(droppedSecBoardNames, includedSecBoardNames);

               if (includedSecBoardNames.size() + newSecBoardNames.size() > instMaxCount) {
                  String message = String.format(
                     "Please make sure the number of instruments for the tab does not exceed (%d).", instMaxCount);
                  getNotifier().accept(message);
                  return;
               }

               Map<String, SecBoard> allSecBoardsByName = Util.groupBy(allSecurities, new Fun1<SecBoard, String>() {
                  @Override
                  public String call(SecBoard secBoard) {
                     return secBoard.getSecCode();
                  }
               });

               Collection<SecBoard> newSecBoards = Util.mapKeepsOrder(newSecBoardNames, allSecBoardsByName);

               if (rawDropIndex>= 0) {
                  getItems().addAll(rawDropIndex, newSecBoards);
               } else {
                  getItems().addAll(newSecBoards);
               }

            }

            dragEvent.setDropCompleted(true);
            dragEvent.consume();
         }
      };

      this.setOnDragOver(dragOver);
      this.setOnDragDropped(dragDropEvent);
		this.selectedProduct.bind(new StringBinding() {
			{
				bind(getFocusModel().focusedItemProperty());
			}

			@Override
			protected String computeValue() {
				SecBoard secBoard = getFocusModel().focusedItemProperty().get();

				return secBoard != null ? secBoard.getInstrumentId() : null;
			}
		});

		this.setCellFactory(listView -> new IncludedSecurityCell(IncludedSecuritiesView.this, checkedSecurities, selectedProduct, dragOver,dragDropEvent));
   }

	void moveCheckedUp() {
		ObservableList<SecBoard> instrs = this.getItems();
		ArrayList<Integer> selection = new ArrayList<>(indices);

		if (!selection.isEmpty()) {
			checkedSecurities.clear();

			for (int idx : selection) {
				SecBoard item = instrs.remove(idx);
				instrs.add(idx - 1, item);
				checkedSecurities.add(item);
			}

			int scrollIndex = indices.get(0);

			this.getFocusModel().focus(scrollIndex);
			this.scrollTo(scrollIndex);
		}
	}

	void moveCheckedDown() {
		ObservableList<SecBoard> instrs = this.getItems();
		ArrayList<Integer> selection = new ArrayList<>(indices);

		if (!selection.isEmpty()) {
			checkedSecurities.clear();
			Collections.reverse(selection);

			for (int idx : selection) {
				SecBoard item = instrs.get(idx);
				instrs.add(idx, instrs.remove(idx + 1));
				checkedSecurities.add(item);
			}

			int scrollIndex = indices.get(indices.size() - 1);

			this.getFocusModel().focus(scrollIndex);
			this.scrollTo(scrollIndex);
		}
	}

	ObservableSet<SecBoard> getCheckedSecurities() {
		return checkedSecurities;
	}

	void removeChecked() {
      WatchlistSpec_v2 currentEditingSpec = tabsListView.getSelectionModel().getSelectedItem();
      if(currentEditingSpec==null){
         System.err.println("current spec is null, how can you edit?");
         return;
      }
		int sel = !indices.isEmpty() ? indices.get(indices.size() - 1) : -1;

		//0071070, have to update the fullProducts of the editing spec, otherwise,
		// all the instruments in the fullProducts will be added back.
      // FIXME : [SAI] Check what is the need of removeFullProduct. Temporarily commented.
		//removeFullProduct(currentEditingSpec, new ArrayList<>(checkedSecurities));

		getItems().removeAll(checkedSecurities);

		if (sel >= 0 && sel < getItems().size()) {
			getFocusModel().focus(sel);
		}
      getCheckedSecurities().clear();
	}

	void removeFullProduct(WatchlistSpec_v2 currentEditingSpec, ArrayList<SecBoard> securities) {
		List<String> existFull = new LinkedList<>(Arrays.asList(currentEditingSpec.fullProducts));
		for(SecBoard aRemoved: securities) {
			String removedProduct = aRemoved.getInstrumentId();
			existFull.remove(removedProduct);
			if (existFull.size() == 0) break;
		}
		currentEditingSpec.fullProducts = existFull.toArray(new String[existFull.size()]);
	}

	ObservableBooleanValue canMoveUpProperty() {
		return new BooleanBinding() {
			{
				bind(indices);
			}

			@Override
			protected boolean computeValue() {
				return !indices.isEmpty() && indices.get(0) != 0;
			}
		};
	}

	ObservableBooleanValue canMoveDownProperty() {
		return new BooleanBinding() {
			{
				bind(indices, getItems());
			}

			@Override
			protected boolean computeValue() {
				if (indices.isEmpty()) {
					return false;
				}

				int lastCheckedIndex = indices.get(indices.size() - 1);
				int lastIncludedIndex = getItems().size() - 1;

				return lastCheckedIndex != lastIncludedIndex;
			}
		};
	}

	ObservableValue<Boolean> hasCheckedProperty() {
		return Bindings.equal(0, Fx.sizeOfList(indices));
	}


	private Consumer<String> notifier;

   public Consumer<String> getNotifier() {
      return notifier;
   }

   public void setNotifier(Consumer<String> notifierConsumer) {
      this.notifier = notifierConsumer;
   }

   private final Disposable disposableDelegate = new DisposableBase() {
      @Override
      protected Future<Void> dispose(boolean disposing) {
         // TODO
         return super.dispose(disposing);
      }
   };

   @Override
   public boolean live() {
      return disposableDelegate.live();
   }

   @Override
   public Future<Void> disposed() {
      return disposableDelegate.disposed();
   }

   @Override
   public Future<Void> dispose() {
      return disposableDelegate.dispose();
   }


   static String[] trimAll(String[] list) {
      String[] newList = new String[list.length];

      for (int i = 0; i < list.length; ++i) {
         newList[i] = list[i].trim();
      }

      return newList;
   }

}
