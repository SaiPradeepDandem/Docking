package xfe.icap.modules.TradesFlash;

import com.nomx.domain.types.AlertsGroup;
import com.omxgroup.xstream.amp.AmpTradeStatus_v2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.AmpMarketTrade;
import xfe.icap.amp.AmpTrade;
import xstr.session.*;
import xstr.types.TradeSide;
import xfe.util.FlashTradeSide;
import xstr.util.Fx;
import xstr.util.TickTask;
import xfe.util.TradeBlinkObservableObject;
import xstr.util.concurrent.Future;
import xfe.icap.XfeSession;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.iswaptrades.TradeNotificationsModule;
import xfe.icap.modules.iswaptrades.TradesFilters;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;

import static xfe.util.FlashTradeSide.Neutral;
import static xfe.util.FlashTradeSide.Off;

@Module.Autostart
public class TradesFlashModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradesFlashModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   private static class TradesFlashInfo{
      TradesFlashInfo(String tradeId, FlashTradeSide newValue, String secCode, String boardId, boolean isMarketTrade) {
         this.tradeId = tradeId;
         this.flashTradeSide = newValue;
         this.secCode = secCode;
         this.boardId = boardId;
         this.isMarketTrade = isMarketTrade;
      }

      @Override
      public String toString() {
         return "TradesFlashInfo{" +
            "tradeId=" + tradeId +
            ", flashTradeSide=" + flashTradeSide +
            ", secCode='" + secCode + '\'' +
            ", boardId='" + boardId + '\'' +
            ", isMarketTrade=" + isMarketTrade +
            '}';
      }
      final String tradeId;
      final FlashTradeSide flashTradeSide;
      final String secCode;
      final String boardId;
      final boolean isMarketTrade;
   }

   @Override
   public Future<Void> startModule() {
      xfeSessionModule.getUnderlyingSession().teClock.addTickTask(dequeTask);
      pendingTradeFlash.clear();
      connectedTime = xfeSessionModule.getUnderlyingSession().getConnectTime();
      logger.debug("connectedTime is set to : {}", connectedTime);
      userId = xfeSessionModule.getUnderlyingSession().getLoggedOnUserId();
      firmId  = xfeSessionModule.getUnderlyingSession().getLoggedOnUserFirmId();
      tradesFeed = xfeSessionModule.getUnderlyingSession().getFeedSource(AmpTrade.req);
      tradesFeed.addListener(tradeFeedListener);
      marketTradesFeed = xfeSessionModule.getUnderlyingSession().getFeedSource(AmpMarketTrade.req);
      marketTradesFeed.addListener(marketTradeFeedListener);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      blinkTradeSideToOffProp.clearListeners();
      blinkNeutralToOffProp.clearListeners();
      blinkTradeSideToInitProp.clearListeners();
      flashDeque.clear();
      flashedTradeIdSet.clear();
      pendingTradeFlash.clear();

      tradesFeed.removeListener(tradeFeedListener);
      marketTradesFeed.removeListener(marketTradeFeedListener);
      activeSessionModule.getSession().ifPresent(serverSession -> serverSession.teClock.removeTask(dequeTask));
      dequeTask.clear();
      tradeFeedListener = null;
      marketTradeFeedListener = null;
      return Future.SUCCESS;
   }
   /**
    * 1) if marketTradeReq received
    *    a) if the tradeId is in "flashedList", ignore it.
    *    b) put the trade in pending list
    *    c) after "a second", get the trade from pending list flash and put it in "flashedList"
    * 2) if tradeRep received,
    *    a) if the tradeId already in "flashedList", ignore it. (how can this happen?);
    *    b) if tradeId exists in pendingTradeFlash, update the FlashTraderSide to Pay/Receive
    */
   public final TradeBlinkObservableObject blinkTradeSideToOffProp = new TradeBlinkObservableObject(3, 500);
   public final TradeBlinkObservableObject blinkNeutralToOffProp = new TradeBlinkObservableObject(3, 500);
   public final TradeBlinkObservableObject blinkTradeSideToInitProp = new TradeBlinkObservableObject(3, 500) ;
   private final Deque<TradesFlashInfo> flashDeque = new ConcurrentLinkedDeque<>();
   private final Map<String,QueryReplyRow> pendingTradeFlash = new HashMap<>(31); //markettradereply, since by the time the event received, we may not able to identify what to do: to flash or to ignore. It depends on the tradesFeed.
   private final Set<String> flashedTradeIdSet = new HashSet<>(1023);
   private final TickTask dequeTask = new TickTask("tradeDequeTask", () -> {
      if (blinkTradeSideToOffProp.isBlink()) return;

      TradesFlashInfo tradeEvent = flashDeque.poll();
      if (tradeEvent != null && !flashedTradeIdSet.contains(tradeEvent.tradeId)) {
         flashedTradeIdSet.add(tradeEvent.tradeId);
         logger.debug("flashing {}",tradeEvent);
         //to flash instrument column in mini watchlist. The final status of the column will be its original one
         blinkTradeSideToOffProp.setTradeSide(tradeEvent.flashTradeSide, Off, Off,tradeEvent.secCode, tradeEvent.boardId);


         if (!tradeEvent.isMarketTrade ||
            (xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker()) &&
               configurationModule.getData().tradeAlertsProperty().get().equals(AlertsGroup.ALL)) {
            blinkTradeSideToInitProp.setTradeSide(Off,tradeEvent.flashTradeSide, tradeEvent.flashTradeSide,tradeEvent.secCode, tradeEvent.boardId);
         } else {
            blinkNeutralToOffProp.setTradeSide(Neutral, Off, Off, tradeEvent.secCode, tradeEvent.boardId);
         }
      }
   }, null, null);
   private String userId;
   private String firmId;
   private Date connectedTime;
   private QueryFeedListener tradeFeedListener = new QueryFeedListener() {

      @Override
      public void handleEvent(List<QueryRowEvent> feedEvents) {
         if (feedEvents.isEmpty()) return;

         logger.debug("****Trade Event Received****");
         Fx.runLater(() -> {
            logger.debug("Processing Alert Event. logon time is " + connectedTime);
            for (QueryRowEvent rev : feedEvents) {
               XtrQueryReplyCommand eventType = rev.getEventType();

               if (eventType == XtrQueryReplyCommand.CREATE) {
//                     final boolean isNewTradeEvent = eventType == XtrQueryReplyCommand.CREATE;
                  QueryReplyRow r = rev.getNewRow();
                  Date tradeTime = r.getValue(AmpTrade.time);
                  int intStatus = r.getValue(AmpTrade.status);
                  logger.debug("Trade event type {} tradeTime is {} logon Time is {} status is {}",eventType,tradeTime.getTime(),connectedTime ,intStatus );
                  if (tradeTime.before(connectedTime)) {
                     continue;
                  }

                  if(xfeSessionModule.getUnderlyingSession().isLoggedOnTrader()){
                     if(!configurationModule.getData().showBrokerTradeProperty().get() && TradeNotificationsModule.isBrokerEntered(r,userId,firmId)){
                        logger.debug("entered by broker - NO POPPING UP ALERT");
                        continue;
                     }
                  }else {
                     String userId = xfeSessionModule.getUnderlyingSession().getLoggedOnUserId();
                     if (xfeSessionModule.getUnderlyingSession().isLoggedOnUserIB()){
                        if(!Objects.equals(userId,r.getString(AmpTrade.sellIntroBrokerId)) && ! Objects.equals(userId,r.getString(AmpTrade.buyIntroBrokerId))){
                           logger.debug("not intro broker entered trades - NO POPPING UP ALERT");
                           continue;
                        }
                     }else{
                        if(!Objects.equals(userId,r.getString(AmpTrade.sellOperatorId)) && ! Objects.equals(userId,r.getString(AmpTrade.buyOperatorId))){
                           logger.debug("not broker entered trades - NO POPPING UP ALERT");
                           continue;
                        }
                     }
                  }

                  boolean isLeg = TradesFilters.isLeg.accept(r);
                  String tradeId = r.getString(AmpTrade.tradeNo);
                  if (isLeg) {
                     flashedTradeIdSet.add(tradeId); //skip legs.
                     logger.debug("tradeId {} is skipped since it is a leg.",tradeId);
                     continue;
                  }
                  if (AmpTradeStatus_v2.matched == intStatus) {
                     TradeSide tradeSide = TradesFilters.getTradeSide(r);
                     FlashTradeSide side;
                     if (Objects.equals(tradeSide, TradeSide.BUY)) {
                        side = FlashTradeSide.Pay;
                     } else if (Objects.equals(tradeSide, TradeSide.SELL)) {
                        side = FlashTradeSide.Receive;
                     } else {
                        side = Neutral;
                     }
                     pendingTradeFlash.remove(tradeId);
                     TradesFlashInfo aTrade = new TradesFlashInfo(tradeId, side, r.getString(AmpTrade.secCode), r.getString(AmpTrade.boardId), false);
                     flashDeque.add(aTrade);
                     logger.debug("TradesFlashInfo added into queue {}" ,aTrade);
                  }
               }
            }
         });
      }
   };
   private QueryFeedListener marketTradeFeedListener = new QueryFeedListener() {

      @Override
      public void handleEvent(List<QueryRowEvent> feedEvents) {
         if (feedEvents.isEmpty()) return;

         logger.debug("****Market Trade Event Received****");
         Fx.runLater(() -> {
            logger.debug("Processing Market Trade Event. logon time is " + connectedTime);
            for (QueryRowEvent rev : feedEvents) {
               XtrQueryReplyCommand eventType = rev.getEventType();

               if (eventType == XtrQueryReplyCommand.CREATE) {
//                     final boolean isNewTradeEvent = eventType == XtrQueryReplyCommand.CREATE;
                  QueryReplyRow r = rev.getNewRow();
                  Date tradeTime = r.getValue(AmpMarketTrade.tradeTime);
                  logger.debug("Market event type is {}, tradeTime is {} logon Time is {}", eventType, new Date(tradeTime.getTime()), connectedTime);

                  if (tradeTime.before(connectedTime)) {
                     continue;
                  }

                  String tradeId = r.getString(AmpMarketTrade.tradeNo);
                  if (flashedTradeIdSet.contains(tradeId)) {
                     continue;
                  }

                  pendingTradeFlash.put(tradeId, r);

                  Fx.delay(1000L, () -> {
                     QueryReplyRow r1 = null;
                     if ((r1 = pendingTradeFlash.remove(tradeId)) != null) {
                        TradesFlashInfo aTrade = new TradesFlashInfo(tradeId, Neutral, r1.getString(AmpMarketTrade.secCode), r1.getString(AmpMarketTrade.boardId), true);
                        flashDeque.add(aTrade);
                        logger.debug("trade added into queue {}", aTrade);
                     }
                  });
               }
            }
         });
      }
   };
   private QueryFeed tradesFeed;
   private QueryFeed marketTradesFeed;

}
