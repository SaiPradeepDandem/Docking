package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnConversionAccessor;

import java.util.Date;

/**
 * Created by jiadin on 20/10/2015.
 */
public class AmpCreateCustomSecBoard extends AmpAccessor {
   public static final  AmpTreq txn = AMP.tREQ("createCustomSecBoard");

   public static final AsnConversionAccessor<String> parentSecCode  = acc(AMP.tREQ("createCustomSecBoard.parentSecBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> parentBoardId  = acc(AMP.tREQ("createCustomSecBoard.parentSecBoardId.boardId"), String.class);
   public static final AsnConversionAccessor<Date> startDate        = acc(AMP.tREQ("createCustomSecBoard.customSecBoardDetails.bespokedDetails.startDate"), Date.class);
   public static final AsnConversionAccessor<Date> endDate          = acc(AMP.tREQ("createCustomSecBoard.customSecBoardDetails.bespokedDetails.endDate"), Date.class);
}
