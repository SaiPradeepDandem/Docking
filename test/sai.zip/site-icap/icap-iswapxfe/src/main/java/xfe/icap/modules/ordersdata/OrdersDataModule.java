package xfe.icap.modules.ordersdata;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import xfe.icap.amp.AmpManagedOrder;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryFeed;
import xstr.session.ServerSession;
import xstr.types.OrderSide;
import xstr.util.FeedAggregator;
import xstr.util.Tuple2;
import xstr.util.concurrent.Future;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Created by soopot on 8/6/2019.
 *
 * @author Sooraj Pottekat
 */
@Module.Autostart
public class OrdersDataModule extends SessionScopeModule {
  private ObservableList<ObservableReplyRow> allOrders;
  private ObservableList<ObservableReplyRow> openOrders;
  private ObservableList<ObservableReplyRow> systemReferredOrders;
  private String userId;
  private String firmId;
  private Map<Tuple2<String, String>, ObservableList<ObservableReplyRow>> allOrdersBySecBoard =
      new HashMap<>();
  private Map<Tuple2<String, String>, ObservableList<ObservableReplyRow>> openOrdersBySecBoard =
      new HashMap<>();
  private Map<Tuple2<String, String>, ObservableList<ObservableReplyRow>>
      withdrawableOrdersBySecBoard = new HashMap<>();

  public ObservableList<ObservableReplyRow> getAllOrders() {
    return allOrders;
  }

  public ObservableList<ObservableReplyRow> getOpenOrders() {
    return openOrders;
  }

  @Override
  public Future<Void> startModule() {

    FeedAggregator<ObservableReplyRow> aggregator =
        new FeedAggregator<>(AmpManagedOrder.rep, new ObservableReplyRow.ObservableRowFactory());
    activeSessionModule
        .getSession()
        .ifPresent(
            session -> {
              QueryFeed srcFeed = session.getFeedSource(AmpManagedOrder.req);
              srcFeed.addListener(aggregator);
            });

    allOrders = aggregator.items;
    allOrders.addListener(
        (ListChangeListener<ObservableReplyRow>) c -> handleOrderUpdates(c, allOrdersBySecBoard));

    openOrders = getFilteredOrders(OrderFilters.matchOpenOrder());
    openOrders.addListener(
        (ListChangeListener<ObservableReplyRow>) c -> handleOrderUpdates(c, openOrdersBySecBoard));

    final ObservableList<ObservableReplyRow>  withdrawableOrders =
            getFilteredOrders(OrderFilters.matchIsWithdrawable());
    withdrawableOrders.addListener(
        (ListChangeListener<ObservableReplyRow>)
            c -> handleOrderUpdates(c, withdrawableOrdersBySecBoard));

    systemReferredOrders = getFilteredOrders(OrderFilters.matchSystemReferredOrder());

     userId = activeSessionModule.getSession().map(ServerSession::getLoggedOnUserId).orElse(null);
     firmId = activeSessionModule.getSession().map(ServerSession::getLoggedOnUserFirmId).orElse(null);
     return Future.SUCCESS;
  }

    /**
     * Return all the orders to withdraw based on the provided secCode and order side.
     * @param secCode Sec code of the instrument
     * @param side Order side
     * @return ObservableList of AmpManagedOrder row objects.
     */
  public ObservableList<ObservableReplyRow> ordersToWithdraw(String secCode, OrderSide side){
      // Fetching all my open orders
      ObservableList<ObservableReplyRow> ordersToWithdraw =
              getOpenOrdersBuilder().ofSec(secCode).own().inSide(side).notCM().build();
      // If my open orders are empty, then fetch all colleagues orders
      if (ordersToWithdraw.isEmpty()) {
          ordersToWithdraw = getOpenOrdersBuilder().ofSec(secCode).colleagues().inSide(side).notCM().build();
      }
      return ordersToWithdraw;
  }

  private void handleOrderUpdates(
      ListChangeListener.Change<? extends ObservableReplyRow> c,
      Map<Tuple2<String, String>, ObservableList<ObservableReplyRow>> ordersMap) {
    while (c.next()) {
      if (c.wasRemoved()) {
        c.getRemoved()
            .forEach(
                row -> {
                  String s = row.getValue(AmpManagedOrder.secCode);
                  String b = row.getValue(AmpManagedOrder.boardId);
                  Tuple2<String, String> secBoardKey = new Tuple2<>(s, b);
                  ObservableList<ObservableReplyRow> obsList = ordersMap.get(secBoardKey);
                  if (obsList != null) obsList.remove(row);
                });
      } else if (c.wasAdded()) {
        c.getAddedSubList()
            .forEach(
                row -> {
                  String s = row.getValue(AmpManagedOrder.secCode);
                  String b = row.getValue(AmpManagedOrder.boardId);
                  Tuple2<String, String> secBoardKey = new Tuple2<>(s, b);
                  ObservableList<ObservableReplyRow> obsList =
                      ordersMap.computeIfAbsent(
                          secBoardKey, k -> FXCollections.observableArrayList());
                  obsList.add(row);
                });
      }
    }
  }
  /**
   * Returns the filtered list of orders by applying the provided predicate to all orders. The
   * orders are sorted by descending order of entry time.
   *
   * @param filter Predicate to apply for filtering the orders.
   * @return FilteredList<ObservableReplyRow>
   */
  public ObservableList<ObservableReplyRow> getFilteredOrders(
      Predicate<ObservableReplyRow> filter) {
    return new FilteredList<>(getSortedOrdersByEntryTime(), filter);
  }

  public ObservableList<ObservableReplyRow> getSystemReferredOrders() {
    return systemReferredOrders;
  }

  /**
   * Returns the sorted list of all orders which are sorted by descending order of entry time.
   *
   * @return SortedList<ObservableReplyRow>
   */
  private ObservableList<ObservableReplyRow> getSortedOrdersByEntryTime() {
    return new SortedList<>(
        allOrders,
        (row1, row2) -> {
          final Date entryTime1 = row1.getValue(AmpManagedOrder.entryTime);
          final Date entryTime2 = row2.getValue(AmpManagedOrder.entryTime);
          return entryTime2.compareTo(entryTime1);
        });
  }

   public OrderListBuilder getOpenOrdersBuilder() {
      return new OrderListBuilder(openOrders,userId,firmId);
   }

  public ObservableList<ObservableReplyRow> getOpenOrdersBySec(Tuple2<String, String> secBoardKey) {
    if (!openOrdersBySecBoard.containsKey(secBoardKey))
      openOrdersBySecBoard.put(secBoardKey, FXCollections.observableArrayList());
    return openOrdersBySecBoard.get(secBoardKey);
  }

  public ObservableList<ObservableReplyRow> getAllOrdersBySec(Tuple2<String, String> secBoardKey) {
    if (!allOrdersBySecBoard.containsKey(secBoardKey))
      allOrdersBySecBoard.put(secBoardKey, FXCollections.observableArrayList());
    return allOrdersBySecBoard.get(secBoardKey);
  }

   public OrderListBuilder getSysRefOrdersBuilder() {
      return new OrderListBuilder(systemReferredOrders, userId,firmId);
   }
}
