package xfe.icap.amp;

import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.util.Callback;
import xfe.icap.modules.watchlist.OrderSpecialTypeDecorator;
import xfe.types.SecBoard;
import xfe.ui.table.AsnValueFactory;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.acc.AmpAccessor;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.*;
import xstr.util.Util;

import java.math.BigDecimal;
import java.util.*;

public class AmpIcapSecBoardTrim2 extends AmpAccessor {
   public static final AmpQreq req = AMP.qREQ("icapSecBoardTrim2Req");
   public static final AmpQrep rep = AMP.qREP("icapSecBoardTrim2Rep");

   public static final AsnAccessor secBoardId = acc(AMP.qREP("icapSecBoardTrim2Rep.secBoardId"));
   public static final AsnAccessor offerOrderId = acc(AMP.qREP("icapSecBoardTrim2Rep.offerOrderId"));
   public static final AsnAccessor bidOrderId = acc(AMP.qREP("icapSecBoardTrim2Rep.bidOrderId"));

   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("icapSecBoardTrim2Rep.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("icapSecBoardTrim2Rep.secBoardId.boardId"), String.class);

   public static final AsnConversionAccessor<String> parentSecCode = acc(AMP.qREP("icapSecBoardTrim2Rep.parentSecBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> parentBoardId = acc(AMP.qREP("icapSecBoardTrim2Rep.parentSecBoardId.boardId"), String.class);

   public static final AsnConversionAccessor<Long> secBoardIdx = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.secBoardIdx"), Long.class);
   public static final AsnConversionAccessor<Double> nLevelImpBidPrice_d = acc(AMP.qREP("icapSecBoardTrim2Rep.nLevelImpBidPrice"), Double.class);
   public static final AsnConversionAccessor<Double> nLevelImpOfferPrice_d = acc(AMP.qREP("icapSecBoardTrim2Rep.nLevelImpOfferPrice"), Double.class);
   public static final AsnConversionAccessor<Double> nLevelImpBidQuantity = acc(AMP.qREP("icapSecBoardTrim2Rep.nLevelImpBidQuantity"), Double.class);
   public static final AsnConversionAccessor<Double> nLevelImpOfferQuantity = acc(AMP.qREP("icapSecBoardTrim2Rep.nLevelImpOfferQuantity"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> prvlgdTrdngPrice = acc(AMP.qREP("icapSecBoardTrim2Rep.prvlgdTrdngPrice"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> bidPrice_d = acc(AMP.qREP("icapSecBoardTrim2Rep.bidPrice"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> bidPrice = acc(AMP.qREP("icapSecBoardTrim2Rep.bidPrice"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> offerPrice_d = acc(AMP.qREP("icapSecBoardTrim2Rep.offerPrice"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> offerPrice = acc(AMP.qREP("icapSecBoardTrim2Rep.offerPrice"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> bidNonIndicPrice_d = acc(AMP.qREP("icapSecBoardTrim2Rep.bidNonIndicPrice"), Double.class);
   public static final AsnConversionAccessor<Double> offerNonIndicPrice_d = acc(AMP.qREP("icapSecBoardTrim2Rep.offerNonIndicPrice"), Double.class);
   public static final AsnConversionAccessor<Double> bidDepth_d = acc(AMP.qREP("icapSecBoardTrim2Rep.bidDepth"), Double.class);
   public static final AsnConversionAccessor<Double> offerDepth_d = acc(AMP.qREP("icapSecBoardTrim2Rep.offerDepth"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> bidDepth = acc(AMP.qREP("icapSecBoardTrim2Rep.bidDepth"), BigDecimal.class);
   public static final AsnConversionAccessor<BigDecimal> offerDepth = acc(AMP.qREP("icapSecBoardTrim2Rep.offerDepth"), BigDecimal.class);
   public static final AsnConversionAccessor<String> bidSpecialOrderType = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.bidSpecialOrderType"), String.class);
   public static final AsnConversionAccessor<String> offerSpecialOrderType = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.offerSpecialOrderType"), String.class);
   public static final AsnConversionAccessor<String> bidUserId = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.bidUserId"), String.class);
   public static final AsnConversionAccessor<String> offerUserId = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.offerUserId"), String.class);
   public static final AsnConversionAccessor<String> offerOperatorId = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.offerOperatorId"), String.class);
   public static final AsnConversionAccessor<String> bidOperatorId = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.bidOperatorId"), String.class);
   public static final AsnConversionAccessor<Long> numTrades = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.numTrades"), Long.class);
   public static final AsnConversionAccessor<Integer> secClassId = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.secClassId"), Integer.class);
   //   public final static AsnConversionAccessor<Long> priceEntryDecimals = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.priceEntryDecimals"), Long.class);
//   public final static AsnConversionAccessor<Long> quantityDecimals = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.quantityDecimals"), Long.class);
   public static final AsnConversionAccessor<Long> minSpinPriceStepArrayId = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.minSpinPriceStepArrayId"), Long.class);
   public static final AsnConversionAccessor<Long> minSpinQtyStepArrayId = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.minSpinQtyStepArrayId"), Long.class);
   //   public static final AsnConversionAccessor<Double> priceTightness = acc(AMP.qREP("icapSecBoardTrim2Rep.priceTightness"), Double.class);
   public static final AsnConversionAccessor<Double> lastPrice_d = acc(AMP.qREP("icapSecBoardTrim2Rep.lastPrice"), Double.class);
   public static final AsnConversionAccessor<Double> lastQuantity = acc(AMP.qREP("icapSecBoardTrim2Rep.lastQuantity"), Double.class);
   public static final AsnConversionAccessor<String> secBoardState = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.secBoardState"), String.class);
   public static final AsnConversionAccessor<String> inheritedState = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.inheritedState"), String.class);
   public static final AsnConversionAccessor<Integer> offerClearingStatus = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.offerClearingStatus"), Integer.class);
   public static final AsnConversionAccessor<Integer> bidClearingStatus = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.bidClearingStatus"), Integer.class);
   public static final AsnConversionAccessor<String> sessionName = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.sessionName"), String.class);
   public static final AsnConversionAccessor<BigDecimal> workupPrice = AmpAccessor.acc(AMP.qREP("icapSecBoardTrim2Rep.prvlgdTrdngPrice"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> defaultQty_d = acc(AMP.qREP("icapSecBoardTrim2Rep.defaultQty"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> defaultQty = acc(AMP.qREP("icapSecBoardTrim2Rep.defaultQty"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> priceTightness = acc(AMP.qREP("icapSecBoardTrim2Rep.priceTightness"), Double.class);
   public static final AsnConversionAccessor<Date> issueDate = acc(AMP.qREP("icapSecBoardTrim2Rep.issueDate"), Date.class);
   public static final AsnConversionAccessor<BitSet> orderMethods = acc(AMP.qREP("icapSecBoardTrim2Rep.orderMethods"), BitSet.class);

   public static final AsnConversionAccessor<BigDecimal> darkMatchPrice = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "darkMatchPrice",
      BigDecimal.class);

   public static final AsnConversionAccessor<String> aggressiveSide = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "aggressiveSide",
      String.class);

   public static final AsnConversionAccessor<String> bidFirmId = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "bidFirmId",
      String.class);

   public static final AsnConversionAccessor<String> offerFirmId = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "offerFirmId",
      String.class);

   public static final AsnConversionAccessor<String> displayPriceDecimals = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "displayPriceDecimals",
      String.class);

   public static final AsnConversionAccessor<String> prvlgdTrdngEndTime = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "prvlgdTrdngEndTime",
      String.class);

   public static final AsnConversionAccessor<String> prvlgdTradingQty = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "prvlgdTradingQty",
      String.class);

   public static final AsnConversionAccessor<Boolean> showPricePolarity = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "showPricePolarity",
      Boolean.class);

   public static final AsnConversionAccessor<Boolean> doPriceReversal = acc(AMP.qREP(
      "icapSecBoardTrim2Rep.extraFieldsList"),
      "doPriceReversal",
      Boolean.class);

   public static int getAggressiveSide(String orderSideString) {
      if ("buy".equalsIgnoreCase(orderSideString)) return AmpOrderVerb.buy;
      if ("sell".equalsIgnoreCase(orderSideString)) return AmpOrderVerb.sell;
      if ("buyorsell".equalsIgnoreCase(orderSideString)) return AmpOrderVerb.buyorsell;
      return AmpOrderVerb.UNDEFINED;
   }

   public static int getAggressiveSide(Integer orderSideInteger) {
      return orderSideInteger;
   }

   public static final List<AsnAccessor> offerSide = Collections.unmodifiableList(Arrays.<AsnAccessor>asList(offerPrice_d, nLevelImpOfferPrice_d, offerDepth_d, offerSpecialOrderType, secCode, lastPrice_d));
   public static final List<AsnAccessor> bidSide = Collections.unmodifiableList(Arrays.<AsnAccessor>asList(bidPrice_d, nLevelImpBidPrice_d, bidDepth_d, bidSpecialOrderType));
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> realBidTypeGetter = Fx.lift(row -> {
      if (row != null) {
         return Bindings.createStringBinding(new Fun0<String>() {
            @Override
            public String call() {
               return OrderSpecialTypeDecorator.getString(row.getValue(bidSpecialOrderType));
            }
         }, row.getProperty(bidSpecialOrderType));
      } else {
         return Fx.constOf("");
      }
   });
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> realOfferTypeGetter = Fx.lift(row -> {
      if (row != null) {
         return Bindings.createStringBinding(new Fun0<String>() {
            @Override
            public String call() {
               return OrderSpecialTypeDecorator.getString(row.getValue(offerSpecialOrderType));
            }
         }, row.getProperty(offerSpecialOrderType));
      } else {
         return Fx.constOf("");
      }
   });
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> realBidTotalStringGetter = AsnValueFactory.asXfeStringValueFun1(bidDepth_d);
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> realOfferTotalStringGetter = AsnValueFactory.asXfeStringValueFun1(offerDepth_d);
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> realBidGetter = AsnValueFactory.asXfeValue(bidPrice_d);
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> realBidTotalGetter = AsnValueFactory.asXfeValue(bidDepth_d);
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> realOfferGetter = AsnValueFactory.asXfeValue(offerPrice_d);
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> realOfferTotalGetter = AsnValueFactory.asXfeValue(offerDepth_d);
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> impliedBidGetter = AsnValueFactory.asXfeValue(nLevelImpBidPrice_d);
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> impliedBidTotalGetter = AsnValueFactory.asXfeValue(nLevelImpBidQuantity);
   private static final Fun1<ObservableReplyRow, ObservableValue<String>> impliedBidTypeGetter = Fx.lift(row -> Fx.constOf("B^n"));
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> impliedOfferGetter = AsnValueFactory.asXfeValue(nLevelImpOfferPrice_d);
   //   public static final Fun1<ObservableReplyRow, ObservableValue<Double>> impliedOffTotalGetter = AsnValueFactory.asXfeValue(AmpIcapSecBoardTrim2.nLevelImpOfferQuantity);
   private static final Fun1<ObservableReplyRow, ObservableValue<String>> impliedOfferTypeGetter = Fx.lift(arg0 -> Fx.constOf("O^n"));
   private static final Callback<ObservableReplyRow, ObservableValue<String>> impliedBidStringGetter = AsnValueFactory.asXfeStringValue(nLevelImpBidPrice_d);
   private static final Fun1<ObservableReplyRow, ObservableValue<Double>> impliedOfferTotalGetter = AsnValueFactory.asXfeDoubleValue(nLevelImpOfferQuantity);
   private static final Fun2<ObservableValue<Double>, ObservableValue<Double>, ObservableValue<Integer>> betterBidGetter = Fx.lift(betterPrice(true));
   public static final Fun1<ObservableReplyRow, ObservableValue<Integer>> impliedBidBetterGetter = Fun1.compose(betterBidGetter, realBidGetter, impliedBidGetter);
   private static final Fun2<ObservableValue<Double>, ObservableValue<Double>, ObservableValue<Integer>> betterOfferGetter = Fx.lift(betterPrice(false));
   public static final Fun1<ObservableReplyRow, ObservableValue<Integer>> impliedOfferBetterGetter = Fun1.compose(betterOfferGetter, realOfferGetter, impliedOfferGetter);
   private static final Fun3<ObservableValue<Integer>, ObservableValue<String>, ObservableValue<String>, ObservableValue<String>> chooseBetterPriceAsString = Fx.lift(new Fun3<Integer, String, String, String>() {
      @Override
      public String call(Integer impliedBetter, String realPrice, String impliedPrice) {
         return impliedBetter > 0 ? impliedPrice : realPrice;
      }
   });
   private static final Fun3<ObservableValue<Integer>, ObservableValue<Double>, ObservableValue<Double>, ObservableValue<String>> chooseBetterTotalAsString = Fx.lift(new Fun3<Integer, Double, Double,String>() {
      @Override
      public String call(Integer impliedBetter, Double real, Double implied) {
         int maxDecimals = 2;
         if (impliedBetter > 0) {
            return Util.double2String(implied, maxDecimals);
         } else if(impliedBetter < 0){
            return Util.double2String(real, maxDecimals);
         } else {
            Double sum = Ops.safeAdd(real, implied);
            if(sum == null){
               return "";
            }
            else {
               return Util.double2String(sum, maxDecimals);
            }
         }

      }
   });
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> betterBidTotalGetter = Fun1.compose(chooseBetterTotalAsString, impliedBidBetterGetter, realBidTotalGetter, impliedBidTotalGetter);
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> betterOfferTotalGetter = Fun1.compose(chooseBetterTotalAsString, impliedOfferBetterGetter, realOfferTotalGetter, impliedOfferTotalGetter);
   private static final Fun3<ObservableValue<Integer>, ObservableValue<String>, ObservableValue<String>, ObservableValue<String>> getOrderType = Fx.lift(new Fun3<Integer, String, String, String>() {
      @Override
      public String call(Integer impliedIsBetter, String realType, String impliedType) {
         return impliedIsBetter>0 ? impliedType : realType;
      }
   });
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> bidOrderTypeGetter = Fun1.compose(getOrderType, impliedBidBetterGetter, realBidTypeGetter, impliedBidTypeGetter);
   public static final Fun1<ObservableReplyRow, ObservableValue<String>> offerOrderTypeGetter = Fun1.compose(getOrderType, impliedOfferBetterGetter, realOfferTypeGetter, impliedOfferTypeGetter);

   public static AsnConversionAccessor<Double> nLevelPriceOn(OrderSide orderSide) {
      return orderSide == OrderSide.BUY ? nLevelImpBidPrice_d : nLevelImpOfferPrice_d;
   }

   public static AsnConversionAccessor<Double> nLevelQuantityOn(OrderSide orderSide) {
      return orderSide == OrderSide.BUY ? nLevelImpBidQuantity : nLevelImpOfferQuantity;
   }

   public static AsnConversionAccessor<Double> priceOn(OrderSide orderSide) {
      return orderSide == OrderSide.BUY ? bidPrice_d : offerPrice_d;
   }

   public static AsnConversionAccessor<Double> quantityOn(OrderSide orderSide) {
      return orderSide == OrderSide.BUY ? bidDepth_d : offerDepth_d;
   }

   public static boolean isBidRelated(AsnAccessor accessedField) {
      return bidPrice.hasEqualAccess(accessedField) ||
         bidDepth_d.hasEqualAccess(accessedField) ||
         bidSpecialOrderType.hasEqualAccess(accessedField) ||
         nLevelImpBidPrice_d.hasEqualAccess(accessedField) ||
         bidUserId.hasEqualAccess(accessedField);
   }

   public static boolean isOfferRelated(AsnAccessor accessedField) {
      return offerPrice.hasEqualAccess(accessedField) ||
         offerDepth_d.hasEqualAccess(accessedField) ||
         offerSpecialOrderType.hasEqualAccess(accessedField) ||
         nLevelImpOfferPrice_d.hasEqualAccess(accessedField) ||
         offerUserId.hasEqualAccess(accessedField);
   }

   public static Callback<ObservableReplyRow, ObservableValue<String>> realBidStringGetter(Map<Tuple2<String, String>, SecBoard> secBoardMap){
      return AsnValueFactory.asUsdBondPriceString(bidPrice_d, secCode, boardId,secBoardMap);
   }

   public static Callback<ObservableReplyRow,ObservableValue<String>> realOfferStringGetter(Map<Tuple2<String, String>, SecBoard> secBoardMap) {
      return AsnValueFactory.asUsdBondPriceString(offerPrice_d, secCode, boardId,secBoardMap);
   }

   private static Callback<ObservableReplyRow, ObservableValue<String>> impliedOfferStringGetter(Map<Tuple2<String, String>, SecBoard> secBoardMap) {
      return AsnValueFactory.asUsdBondPriceString(nLevelImpOfferPrice_d, secCode, boardId,secBoardMap);
   }

   private static Fun2<Double, Double, Integer> betterPrice(boolean isBid) {
      /*
       * return positive, if best price is implied price
       * return negative, if best price is real price
       * return 0, if best price equal implied price
       */
      return new Fun2<Double, Double, Integer>() {
         @Override
         public Integer call(Double realPrice, Double impliedPrice) {
            if (impliedPrice == null && realPrice==null){
               return 0;
            }
            if (impliedPrice != null && realPrice==null){
               return 1;
            }
            if (impliedPrice == null){
               return -1;
            }
            if (realPrice.equals(impliedPrice)){
               return 0;
            }

            return isBid ? (impliedPrice >realPrice ? 1 : -1) : (impliedPrice < realPrice  ? 1 : -1);
         }
      };
   }

   public static Callback<ObservableReplyRow, ObservableValue<String>> betterBidStringGetter(Map<Tuple2<String, String>, SecBoard> secBoardMap){
      return Fun1.composeViaCallback(chooseBetterPriceAsString, impliedBidBetterGetter, realBidStringGetter(secBoardMap), impliedBidStringGetter);
   }

   public static Callback<ObservableReplyRow, ObservableValue<String>> betterOfferStringGetter(Map<Tuple2<String, String>, SecBoard> secBoardMap) {
      return Fun1.composeViaCallback(chooseBetterPriceAsString, impliedOfferBetterGetter, realOfferStringGetter(secBoardMap), impliedOfferStringGetter(secBoardMap));
   }
}
