package xfe.icap.amp;

import java.util.Date;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import com.omxgroup.syssrv.Duration;

/**
 * Accessors for AmpOrderAmend_v5
 * @author absw
 *
 */
public class AmpOrderAmendAcc extends AmpAccessor {
   public static final AmpTreq txn = AMP.tREQ("orderAmend");

   public static final AsnAccessor orderId =  acc(AMP.tREQ("orderAmend.orderId"));

   public static final AsnConversionAccessor<Double> currentBalance = acc(AMP.tREQ("orderAmend.currentBalance"), Double.class);
   public static final AsnConversionAccessor<Double> price = acc(AMP.tREQ("orderAmend.amendable.price"), Double.class);
   public static final AsnConversionAccessor<Double> quantity = acc(AMP.tREQ("orderAmend.amendable.quantity"), Double.class);
   public static final AsnConversionAccessor<Duration> durationTime = acc(AMP.tREQ("orderAmend.amendable.durationTime"), Duration.class);
   public static final AsnConversionAccessor<Date> expiryTime = acc(AMP.tREQ("orderAmend.amendable.expiryTime"), Date.class);
   public static final AsnConversionAccessor<Integer> durationType = acc(AMP.tREQ("orderAmend.amendable.duration"), Integer.class);
   public static final AsnConversionAccessor<Double> minFillQuantity = acc(AMP.tREQ("orderAmend.amendable.minFillQuantity"), Double.class);
   public static final AsnConversionAccessor<Boolean> shared = acc(AMP.tREQ("orderAmend.amendable.shared"), Boolean.class);
   public static final AsnConversionAccessor<Integer> actionOnLogoff = acc(AMP.tREQ("orderAmend.amendable.actionOnLogoff"), Integer.class);
   public static final AsnConversionAccessor<Double> visibleQuantity = acc(AMP.tREQ("orderAmend.amendable.visibleQuantity"), Double.class);
   public static final AsnConversionAccessor<Boolean> isPublic = acc(AMP.tREQ("orderAmend.siteSpecific.icap.isPublic"), Boolean.class);
   public static final AsnConversionAccessor<Integer> trackingType = acc(AMP.tREQ("orderAmend.amendable.trackingType"), Integer.class);
   public static final AsnAccessor trackedSecBoardId =  acc(AMP.tREQ("orderAmend.amendable.trackedSecBoardId"));
   public static final AsnConversionAccessor<Boolean> isTopcut = acc(AMP.tREQ("orderAmend.amendable.isTopcut"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> cloneIntoRFS = acc(AMP.tREQ("orderAmend.amendable.cloneIntoRFS"), Boolean.class);
   public static final AsnAccessor clearingMemberFirmTrdAccId =  acc(AMP.tREQ("orderAmend.amendable.clearingMemberFirmTrdAccId"));
   public static final AsnConversionAccessor<Double> doddFrankMidMkt = acc(AMP.tREQ("orderAmend.amendable.doddFrankMidMkt"), Double.class);
   public static final AsnConversionAccessor<Boolean> allowMultiMinFill = acc(AMP.tREQ("orderAmend.amendable.allowMultiMinFill"), Boolean.class);
   public static final AsnConversionAccessor<String> introBrokerId = acc(AMP.tREQ("orderAmend.introBrokerId"), String.class);
   public static final AsnConversionAccessor<String> brokerId = acc(AMP.tREQ("orderAmend.brokerId"), String.class);

   // Other amendable fields not yet accessed:
//   protected AmpTrdAccChoice trdAccChoice;  // optional
//   protected AmpBrokerRef brokerRef;  // optional
//   protected AmpSessDurationId sessDurationId;  // optional
//   protected AmpPositionType positionType;  // optional
//   protected AmpTradeRef tradeReference;  // optional
//   protected AmpBoolean allowSoftQtyLimit;  // optional
//   protected AmpBoolean allowSoftPriceLimit;  // optional
//   protected AmpExternalSequenceNum extSeqNum;  // optional
//   protected AmpInteger range;  // optional



}
