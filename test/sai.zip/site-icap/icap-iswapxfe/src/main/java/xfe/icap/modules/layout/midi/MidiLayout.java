package xfe.icap.modules.layout.midi;

import javafx.beans.property.BooleanProperty;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TitledPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import org.controlsfx.glyphfont.Glyph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.ui.control.GlyphButton;
import xfe.util.scene.control.XfeTooltipFactory;

import java.io.IOException;
import java.util.function.Consumer;

public class MidiLayout {
   private static final Logger logger = LoggerFactory.getLogger(MidiLayout.class);
   public static final String ROOT_ID = "midiLayoutRoot";
   @FXML
   public void initialize() {

   }

   public void setInstrTabs(Node view) {
      if (view != null) {
         AnchorPane.setTopAnchor(view, 0.0);
         AnchorPane.setRightAnchor(view, 0.0);
         AnchorPane.setBottomAnchor(view, 0.0);
         AnchorPane.setLeftAnchor(view, 0.0);
         instrTabs.getChildren().add(view);
      } else {
         instrTabs.getChildren().clear();
      }
   }

   public AnchorPane getRoot() {
      return midiLayoutRoot;
   }

   static MidiLayout load() {
      FXMLLoader ldr = new FXMLLoader(MidiLayout.class.getResource("MidiLayout.fxml"));
      try {
         ldr.load();
         return ldr.getController();
      } catch (IOException e) {
         throw new RuntimeException(e);
      }
   }

   @FXML
   private AnchorPane midiLayoutRoot;
   @FXML
   private AnchorPane instrTabs;
   @FXML
   private SplitPane mainSplit;
   @FXML
   private StackPane toolbarPane;
   @FXML
   private StackPane actionBarPane;
   @FXML
   private TitledPane stockSelectionPane;
   @FXML
   private StackPane shortlistPane;
   @FXML
   private AnchorPane tradesUIPane;


   public void setToolbar(Node view) {
      if (view != null) {
         toolbarPane.getChildren().add(view);
      } else {
         toolbarPane.getChildren().clear();
      }
   }

   public void setTradesUI(Node view) {
      if (view != null) {
         tradesUIPane.setTopAnchor(view, 0.0);
         tradesUIPane.setRightAnchor(view, 0.0);
         tradesUIPane.setBottomAnchor(view, 0.0);
         tradesUIPane.setLeftAnchor(view, 0.0);
         tradesUIPane.getChildren().add(view);
      } else {
         tradesUIPane.getChildren().clear();
      }
   }

   /**
    * Sets the action toolbar view in the actions pane.
    *
    * @param view ToolBar instance containing action buttons.
    */
   public void setActionToolBar(Node view) {
      actionBarPane.getChildren().clear();
      if (view != null) {
         actionBarPane.getChildren().add(view);
      }
   }

   public void setStockSelectionExpandedState(BooleanProperty wsExpandedProperty) {
      if (wsExpandedProperty != null) {
         stockSelectionPane.setExpanded(wsExpandedProperty.get());
         stockSelectionPane.expandedProperty().addListener((observable, oldValue, newValue) -> {
            wsExpandedProperty.set(newValue);
         });
      }
   }

   /**
    * Sets the stock selection view in the placeholder.
    *
    * @param view FlowPane instance containing stock selection buttons.
    */
   public void setShortlistButtonsPane(Node view) {
      shortlistPane.getChildren().clear();
      if (view != null) {
         shortlistPane.getChildren().add(view);
      }
   }

   public void setDividerPosition(Double pos) {
      mainSplit.setDividerPositions(pos);
   }

   public SplitPane.Divider getDivider() {
      return mainSplit.getDividers().get(0);
   }
}
