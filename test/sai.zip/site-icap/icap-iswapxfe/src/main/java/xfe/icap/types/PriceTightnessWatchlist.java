package xfe.icap.types;

import xstr.session.QueryFeed;
import xstr.session.XtrQueryRequestBuilder;
import xstr.amp.AMP;
import xstr.session.XtrQueryRequest;
import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xfe.types.Watchlist;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import xstr.util.TickTask;
import xstr.util.filter.DynamicFilter;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xstr.session.ObservableReplyRow;
import javafx.beans.InvalidationListener;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.Fun1;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;
import xstr.session.ObservableReplyRow.ObservableRowFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PriceTightnessWatchlist implements Watchlist {
   private static final Logger logger = LoggerFactory.getLogger(PriceTightnessWatchlist.class);
   private final XfeSession session;

   private QueryFeed feedSrc;
   private final FeedAggregator<ObservableReplyRow> aggregator = new FeedAggregator<>(AmpIcapSecBoardTrim2.rep, new ObservableRowFactory());
   private final BooleanProperty isItemsDownload = new SimpleBooleanProperty(false);

  //There are two sets of SecBoard being watched. One set from watchlistSpec, the other from active rfq.
   private final ObservableList<SecBoard> specWatchedSecboards = FXCollections.observableArrayList();
   private final Map<Long, Date> maturityDateMap = new HashMap<>(50);
   private final Map<SecBoard, Long> lostPriceTightMap = new ConcurrentHashMap<>(50);
   private final Map<String, Long> selectedMainMap = new ConcurrentHashMap<>(50);
   private final Map<String, Long> selectedMiniMap = new ConcurrentHashMap<>(50);
   private final ObservableList<ObservableReplyRow> readOnlyWatchedItems;

   private int maxShowingNumber;

   private boolean hidden = false;
   private final StringProperty titleProperty = new SimpleStringProperty();
   private final StringProperty subtitleProperty = new SimpleStringProperty();
   private final BooleanProperty visibleProperty = new SimpleBooleanProperty(true);

   private TickTask task;

   private final Comparator<SecBoard> comparatorSecBoard  = (sec1, sec2) -> {
      Long position1 = sec1.getMaturityDateAsLong();
      Long position2 = sec2.getMaturityDateAsLong();
      return position1.compareTo(position2);
   };

   private StringProperty selectedSecCodeMain;
   private StringProperty selectedSecCodeMini;
   private ChangeListener<String> selectedMainListener;
   private ChangeListener<String> selectedMiniListener;
   private ChangeListener<Boolean> aggregatorBusyLis;

   public PriceTightnessWatchlist(XfeSession session, StringProperty selectedSecCodeMain, StringProperty selectedSecCodeMini) {
      this.session = session;
      this.maxShowingNumber = 50;

      //if price tightness lost, the instrument still need to stay for this time long in nano second
      long stayTimeNano = 60000000000L;

      this.selectedSecCodeMain = selectedSecCodeMain;
      this.selectedMainListener = (observable, oldValue, newValue) -> {
         if (newValue != null) {
            // For selected instrument, no matter how long it lost price tightness, it should stay in watchlist.
            // Adding to selected rows map
            selectedMainMap.put(newValue, System.nanoTime());
         }
      };
      this.selectedSecCodeMain.addListener(selectedMainListener);

      this.selectedSecCodeMini = selectedSecCodeMini;
      this.selectedMiniListener = (observable, oldValue, newValue) -> {
         if (newValue != null) {
            // For selected instrument, no matter how long it lost price tightness, it should stay in watchlist.
            // Adding to selected rows map
            selectedMiniMap.put(newValue, System.nanoTime());
         }
      };
      this.selectedSecCodeMini.addListener(selectedMiniListener);

      this.aggregatorBusyLis = (observableVal, oldVal, newVal) -> {
         if (newVal == false) {
            isItemsDownload.setValue(true);
            logger.trace("finished downloading");
         }
      };
      aggregator.busyProperty().addListener(aggregatorBusyLis);

      // These should be potentially removed
      // If a security is selected in either the mini-watchlist or the main watchlist then it cannot get removed
      // Also, any of the above that has been selected sometime in the last 60 secs would not get removed at this point
      Runnable cleanExpired = () -> {
         long now = System.nanoTime();
         List<SecBoard> toBeRemoved = new ArrayList<>(maxShowingNumber);

         // We first reset the selected securities to 60 secs
         if (selectedSecCodeMain.get() != null)
            selectedMainMap.put(selectedSecCodeMain.get(), now);
         if (selectedSecCodeMini.get() != null)
            selectedMiniMap.put(selectedSecCodeMini.get(), now);

         // These should be potentially get removed
         for (SecBoard sec : lostPriceTightMap.keySet()) {
            long expiredTime = lostPriceTightMap.get(sec);
            if (now - expiredTime >= stayTimeNano) {
               toBeRemoved.add(sec);
            }
         }

         // If a security is selected in either the mini-watchlist or the main watchlist then it cannot get removed
         // Also, any of the above that has been selected sometime in the last 60 secs would not get removed at this point
         List<SecBoard> toGetRestated = new ArrayList<>(maxShowingNumber);
         toBeRemoved.forEach(secBoard -> {
            String secCode = secBoard.getSecCode();

            Long selectedTime = selectedMainMap.get(secCode);
            if (selectedTime != null && now - selectedTime < stayTimeNano) {
               toGetRestated.add(secBoard);
               return;
            }

            selectedTime = selectedMiniMap.get(secCode);
            if (selectedTime != null && now - selectedTime < stayTimeNano) {
               toGetRestated.add(secBoard);
            }
         });

         toBeRemoved.removeAll(toGetRestated);

         if (toBeRemoved.size() > 0) {
            logger.debug("removing following sec from list: {}", toBeRemoved);
            for (SecBoard sec : toBeRemoved) {
               lostPriceTightMap.remove(sec);
            }
            specWatchedSecboards.removeAll(toBeRemoved);
         }
      };
      task = new TickTask("PriceTightness", cleanExpired, null, null);
      session.getUnderlyingSession().teClock.addTickTask(task);
      specWatchedSecboards.addListener(specWatchedSecboardsLis);
      Comparator<ObservableReplyRow> comparatorReplyRow = (row1, row2) -> {
         Long idx1 = row1.getValue(AmpIcapSecBoardTrim2.secBoardIdx);
         Long idx2 = row2.getValue(AmpIcapSecBoardTrim2.secBoardIdx);
         Date position1 = maturityDateMap.get(idx1);
         if (position1 == null) return -1;
         Date position2 = maturityDateMap.get(idx2);
         if (position2 == null) return 1;
         return position1.compareTo(position2);
      };
      //there are two sets of ObservableReplyRow being displayed in watchlist. One set from watchlist spec. the other from active rfq
      ObservableList<ObservableReplyRow> sortedWatchedItems = Fx.sortBy(aggregator.items, comparatorReplyRow);
      this.readOnlyWatchedItems =  FXCollections.unmodifiableObservableList(sortedWatchedItems);
      updateList();
   }

   private final InvalidationListener specWatchedSecboardsLis = observable -> {
      logger.info("watchlist spec changed(Tab selection)");
      updateList();
   };

   @Override
   public ObservableList<SecBoard> getSpecWatchedSecboards() {
      return specWatchedSecboards;
   }

   @Override
   public ObservableList<ObservableReplyRow> getItems() {
      return readOnlyWatchedItems;
   }

   @Override
   public ObjectProperty<Fun1<? super ObservableReplyRow, ? extends ObservableBooleanValue>> itemsFilterProperty() {
      return new SimpleObjectProperty<>(DynamicFilter.alwaysTrue);
   }

   private void updateList() {
      cleanUpFeedSrc();
      if (!maturityDateMap.isEmpty())
         maturityDateMap.clear();

      int size = specWatchedSecboards.size();
      logger.trace("updating watchlist. Size is {}",size);
      Long[] sortedIndices;
      if (specWatchedSecboards.size() > maxShowingNumber) {
         List<SecBoard> sortedSecBoard = specWatchedSecboards.sorted(comparatorSecBoard);
         size = maxShowingNumber;
         sortedIndices = new Long[size];
         for (int i = 0; i < size; i++) {
            SecBoard secBoard = sortedSecBoard.get(i);
            sortedIndices[i] = secBoard.getIndex();
            maturityDateMap.put(secBoard.getIndex(), secBoard.getMaturityDate());
         }
      } else {
         sortedIndices = new Long[size];
         for (int i=0; i < size; i++) {
            SecBoard secBoard = specWatchedSecboards.get(i);
            sortedIndices[i] = secBoard.getIndex();
            maturityDateMap.put(secBoard.getIndex(), secBoard.getMaturityDate());
         }
      }

      logger.trace("sortedIndices is {}", Arrays.toString(sortedIndices));

      if (!session.getUnderlyingSession().isLoggedOn()) {
         return;
      }
      // IGDLXT-1542 : For updating View, you have to send the request so the request should happen even specWatchedSecboards is empty.
      if (sortedIndices.length >= 0 && !hidden) {
         try {
            logger.trace("building request");
            isItemsDownload.setValue(false);
            XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req, session.getUnderlyingSession())
                  .set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), sortedIndices)
                  .build();
            logger.debug("{}|{} new request: {}", titleProperty.get(), subtitleProperty.get(), req);
            feedSrc = session.getUnderlyingSession().queries.getFeedSource(req);
            feedSrc.addListener(aggregator);
         } catch (AsnTypeException | AmpPermissionException ex) {
            logger.error(ex.getMessage(), ex);
         }
      }

      if (sortedIndices.length == 0){
         clear();
      }
   }

   private void cleanUpFeedSrc() {
      if (feedSrc != null) {
         feedSrc.removeListener(aggregator);
         feedSrc = null;
      }
   }

   @Override
   public void setHidden(boolean hidden) {
      if (this.hidden != hidden) {
         //	We should stop polling if this watchlist belongs to the watchlistStage and that is hidden
         // When that is not hidden, we should start polling again so call updateList.
         this.hidden = hidden;
         if (hidden) {
            cleanUpFeedSrc();
            selectedMainMap.clear();
            selectedMiniMap.clear();
         } else {
            updateList();
         }
      }
   }

   @Override
   public void setTitle(String title) {
      this.titleProperty.set(title);
   }

   @Override
   public void setSubtitle(String subtitle) {
      this.subtitleProperty.set(subtitle);
   }

   @Override
   public void setVisible(boolean isVisible) {
      this.visibleProperty.set(isVisible);
   }

   @Override
   public void dispose() {
      if (session.getUnderlyingSession().teClock != null)
         session.getUnderlyingSession().teClock.removeTask(task);
      specWatchedSecboards.removeListener(specWatchedSecboardsLis);
      selectedSecCodeMain.removeListener(selectedMainListener);
      selectedSecCodeMini.removeListener(selectedMiniListener);
      aggregator.busyProperty().removeListener(aggregatorBusyLis);
      clear();
   }

   @Override
   public void setOnSecBoardsReady(SecBoards secBoards, Runnable runnable) {

      secBoards.ready().onSuccess(new Fun1<Boolean, Void>(){

         @Override
         public Void call(Boolean a) {
            runnable.run();
            return null;
         }
      });
   }

   @Override
   public ObservableBooleanValue itemsReadyProperty() {
      return isItemsDownload;
   }

   public void addSecBoard(SecBoard secBoard) {
      logger.trace("adding secboard: {}",secBoard);
      if(!specWatchedSecboards.contains(secBoard)){
         specWatchedSecboards.add(secBoard);
      }
      lostPriceTightMap.remove(secBoard);
   }

   public void removeSecBoard(SecBoard sec){
      logger.trace("remove secboard: {}",sec);
      lostPriceTightMap.put(sec,System.nanoTime());
   }

   public void clear() {
      cleanUpFeedSrc();
      if (!lostPriceTightMap.isEmpty())
         lostPriceTightMap.clear();
      if (!specWatchedSecboards.isEmpty())
         specWatchedSecboards.clear();
      if (!maturityDateMap.isEmpty())
         maturityDateMap.clear();
      if (!selectedMainMap.isEmpty())
         selectedMainMap.clear();
      if (!selectedMiniMap.isEmpty())
         selectedMiniMap.clear();
   }
}
