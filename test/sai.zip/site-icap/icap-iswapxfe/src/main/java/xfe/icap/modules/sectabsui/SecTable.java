package xfe.icap.modules.sectabsui;

import com.nomx.persist.watchlist.ColumnSpec;
import com.nomx.persist.watchlist.ColumnsSpec;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumnBase;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import javafx.util.Pair;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.modules.actions.PopupOrderEntryArgs;
import xfe.modules.actions.TickUpDownAmendArgs;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.modules.actions.WorkupArgs;
import xfe.types.RowHighlight;
import xfe.types.StepArray;
import xfe.ui.table.AlignedTableColumn;
import xfe.ui.table.ConfigurableTableView;
import xfe.ui.table.XfeActionCell;
import xfe.util.Util;
import xfe.util.XfeAction;
import xfe.util.scene.control.SimpleSelectionTracker;
import xstr.session.ObservableReplyRow;
import xstr.session.WatchlistRow;
import xstr.session.XtrTransReply;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static xstr.types.OrderSide.BUY;
import static xstr.types.OrderSide.SELL;


public class SecTable extends ConfigurableTableView<WatchlistRow> {

   static final String HIGHLIGHT_PROP_NAME = "highlighting";
   public static final Duration TRADE_FLASH_TIME = Duration.seconds(5);
   public static final String ZOOM_STYLE = "instruments-tab-pane-zoom";
   public static final String XFE_DARK_COLUMN = "xfe-table-view-col-dark-background-colour";

   private static final double ACTION_COL_DEFAULT_WIDTH = 20.0;
   private static final double COL_MIN_WIDTH = 48.0;
   private static final double COL_MAX_WIDTH = 150.0;
   private static final double INS_COL_MIN_WIDTH = 80.0;

   private final ObjectProperty<ColumnsSpec> specProperty = new SimpleObjectProperty<>();
   private TableColumn<WatchlistRow, String> instrCol;
   private boolean oneClickTrading;
   private SimpleSelectionTracker<WatchlistRow> selectionTracker;
   private BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> actionFactory;
   private BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> cmActionfactory;
   private Function<WatchlistRow, ObservableValue<PriceCellValue<BigDecimal>>> matchColFactory;
   private BiFunction<WatchlistRow, OrderSide, ObservableValue<PriceCellValue<BigDecimal>>> priceColFactory;
   private BiFunction<ObservableReplyRow, OrderSide, ObservableValue<Double>> totalColFactory;
   private BiFunction<ObservableReplyRow, Pair<OrderSide, Double>, Future<XtrTransReply>> sendDefaultOrderClbk;
   private BiConsumer<ObservableReplyRow, RowHighlight> saveToggle;
   private BiFunction<String, String, StepArray> stepArrayCallBack;
   private Consumer<PopupOrderEntryArgs> totalColDblClickAction;
   private Consumer<PopupOrderEntryArgs> priceColDblClickAction;
   private Consumer<PopupOrderEntryArgs> doCMPriceColEntry;
   private Consumer<PopupOrderEntryArgs> doCMPriceColAmend;
   private Consumer<TickUpDownAmendArgs> doTickUpDownPriceAmend;
   private Consumer<WorkupArgs> priceColWorkupAction;
   private Consumer<WorkupArgs> doCMPriceColWorkupAction;
   private Consumer<ColumnsSpec> columnsVisibilityAction;
   private Consumer<WatchlistRow> toggleExpandCollapseAction;
   private Consumer<TradesAggregateArgs> tradesAggregatePopupAction;
   private Supplier<Boolean> isLocked;
   private Supplier<Integer> zoomLevel;
   private Supplier<Integer> priceCellFlashDuration;
   private InvalidationListener widthListener = p -> enableHBar();

   /**
    * Constructor.
    *
    * @param colsSpec
    */
   public SecTable(ColumnsSpec colsSpec) {
      this.specProperty.setValue(colsSpec == null ? new ColumnsSpec() : colsSpec);
      init();
   }

    /**
    * Initializes the SecTable.
    */
   private void init() {
      // When column label is empty or duplicated, you need to define SETTING_TEXT property.
      /* Instrument column: Displays the SecCode without the leading “UKT” */
      instrCol = new AlignedTableColumn<>("Instrument", HPos.LEFT);
      instrCol.setId("instrument-tablecolumn");
      instrCol.setSortable(false);
      instrCol.getStyleClass().add("xfe-bold-text");
      instrCol.setCellValueFactory(this::getInstrumentName);
      instrCol.setCellFactory(p -> new InstrumentCell());
      getColumns().add(instrCol);

      /* Bid Quantity column: Displays the total bid quantity at the best bid price */
      final TableColumn<WatchlistRow, Double> bidQuantityCol = new AlignedTableColumn<>("Size", HPos.CENTER);
      bidQuantityCol.setId("bidsize-tablecolumn");
      bidQuantityCol.getProperties().put(SETTING_TEXT,"Bid Total");
      bidQuantityCol.setSortable(false);
      bidQuantityCol.setCellValueFactory(param -> getTotal(param, BUY));
      bidQuantityCol.setCellFactory(param -> new TotalCell(BUY));
      getColumns().add(bidQuantityCol);

      /* Bid Action Button column: When the user has an open order (which may not be the best order at that price, but excluding constant match orders)
       * a *REFER ALL* icon will be displayed,
       * otherwise, if there is a best bid price, then a *HIT/TAKE* icon will be displayed,
       * otherwise (if there are no bids) the cell will be empty*/
      final TableColumn<WatchlistRow, XfeAction> bidActionCol = new AlignedTableColumn<>();
      bidActionCol.setId("bidaction-tablecolumn");
      bidActionCol.getProperties().put(SETTING_TEXT,"Bid Action");
      bidActionCol.getStyleClass().addAll(XfeActionCell.DEFAULT_STYLE, XFE_DARK_COLUMN);
      bidActionCol.setResizable(false);
      bidActionCol.setSortable(false);
      bidActionCol.setCellValueFactory(param -> getCLOBXfeAction(param, BUY));
      bidActionCol.setCellFactory(param -> new XfeActionCell<>());
      getColumns().add(bidActionCol);

      /* Bid Price column: Displays the best (visible) bid price, otherwise displays the indicative bid price, otherwise is blank.*/
      final TableColumn<WatchlistRow, PriceCellValue<BigDecimal>> bidPriceCol = new AlignedTableColumn<>("Bid", HPos.RIGHT);
      bidPriceCol.setId("bidprice-tablecolumn");
      bidPriceCol.getStyleClass().add(XFE_DARK_COLUMN);
      bidPriceCol.setSortable(false);
      bidPriceCol.setCellValueFactory(param -> getCLOBPrice(param, BUY));
      bidPriceCol.setCellFactory(param -> new CLOBPriceCell(BUY));
      getColumns().add(bidPriceCol);

      /* Constant Match Bid Action column: Displays a refer icon when the user has an open Constant Match bid order. */
      final TableColumn<WatchlistRow, XfeAction> bidCMActionCol = new AlignedTableColumn<>();
      bidCMActionCol.setId("bidcmaction-tablecolumn");
      bidCMActionCol.getProperties().put(SETTING_TEXT,"Bid CM Action");
      bidCMActionCol.getStyleClass().add(XfeActionCell.DEFAULT_STYLE);
      bidCMActionCol.setResizable(false);
      bidCMActionCol.setSortable(false);
      bidCMActionCol.setCellValueFactory(param -> getCMXfeAction(param, BUY));
      bidCMActionCol.setCellFactory(param -> new XfeActionCell<>());
      getColumns().add(bidCMActionCol);

      /* Constant Match Price column: Displays the best (visible) bid CM price, otherwise is blank.*/
      final TableColumn<WatchlistRow, PriceCellValue<BigDecimal>> cmPriceCol = new AlignedTableColumn<>("Match", HPos.CENTER);
      cmPriceCol.setId("cmprice-tablecolumn");
      cmPriceCol.setSortable(false);
      cmPriceCol.setCellValueFactory(param -> getCMPrice(param.getValue()));
      cmPriceCol.setCellFactory(param -> new CMPriceCell());
      getColumns().add(cmPriceCol);

      /* Constant Match Offer Action column: Displays an offer icon when the user has an open Constant Match offer order. */
      TableColumn<WatchlistRow, XfeAction> offerCMActionCol = new AlignedTableColumn<>(); // need to be replaced by icons
      offerCMActionCol.setId("offercmaction-tablecolumn");
      offerCMActionCol.getProperties().put(SETTING_TEXT,"Offer CM Action");
      offerCMActionCol.getStyleClass().add(XfeActionCell.DEFAULT_STYLE);
      offerCMActionCol.setResizable(false);
      offerCMActionCol.setSortable(false);
      offerCMActionCol.setCellValueFactory(param -> getCMXfeAction(param, SELL));
      offerCMActionCol.setCellFactory(p -> new XfeActionCell<>());
      getColumns().add(offerCMActionCol);

      /* Offer Price column: Displays the best (visible) offer price, otherwise displays the indicative offer price, otherwise is blank.*/
      TableColumn<WatchlistRow, PriceCellValue<BigDecimal>> offerPriceCol = new AlignedTableColumn<>("Offer", HPos.LEFT);
      offerPriceCol.setId("offerprice-tablecolumn");
      offerPriceCol.getStyleClass().add(XFE_DARK_COLUMN);
      offerPriceCol.setSortable(false);
      offerPriceCol.setCellValueFactory(param -> getCLOBPrice(param, SELL));
      offerPriceCol.setCellFactory(param -> new CLOBPriceCell(SELL));
      getColumns().add(offerPriceCol);

      /* Offer Action Button column: When the user has an open order (which may not be the best order at that price, but excluding constant match orders)
       * a *REFER ALL* icon will be displayed,
       * otherwise, if there is a best offer price, then a *HIT/TAKE* icon will be displayed,
       * otherwise (if there are no offers) the cell will be empty. */
      TableColumn<WatchlistRow, XfeAction> offerActionCol = new AlignedTableColumn<>();
      offerActionCol.setId("offeraction-tablecolumn");
      offerActionCol.getProperties().put(SETTING_TEXT,"Offer Action");
      offerActionCol.getStyleClass().addAll(XfeActionCell.DEFAULT_STYLE, XFE_DARK_COLUMN);
      offerActionCol.setResizable(false);
      offerActionCol.setSortable(false);
      offerActionCol.setCellValueFactory(param -> getCLOBXfeAction(param, SELL));
      offerActionCol.setCellFactory(param -> new XfeActionCell<>());
      getColumns().add(offerActionCol);

      /* Offer Quantity column: Displays the total offer quantity at the best bid price */
      TableColumn<WatchlistRow, Double> offerQuantityCol = new AlignedTableColumn<>("Size", HPos.CENTER);
      offerQuantityCol.setSortable(false);
      offerQuantityCol.setId("offersize-tablecolumn");
      offerQuantityCol.getProperties().put(SETTING_TEXT,"Offer Total");
      offerQuantityCol.setCellValueFactory(param -> getTotal(param, SELL));
      offerQuantityCol.setCellFactory(p -> new TotalCell(SELL));
      getColumns().add(offerQuantityCol);

      // Setting min & max widths of all columns.
      instrCol.setMinWidth(INS_COL_MIN_WIDTH);
      Stream.of(bidActionCol, offerActionCol, bidCMActionCol, offerCMActionCol).forEach(column -> {
         column.setMinWidth(ACTION_COL_DEFAULT_WIDTH);
         column.setMaxWidth(ACTION_COL_DEFAULT_WIDTH);
      });
      Stream.of(bidQuantityCol, offerQuantityCol, bidPriceCol, offerPriceCol, cmPriceCol).forEach(column -> {
         column.setMinWidth(COL_MIN_WIDTH);
         column.setMaxWidth(COL_MAX_WIDTH);
      });

      setEditable(true);
      getStyleClass().add("instrument-table-view");
      setupColsMenu();
      selectionTracker = new SimpleSelectionTracker<>(this, row -> {
         if (row.isHeading())
            return row.toString();
         else
            return (row.getRow()).getString(AmpIcapSecBoardTrim2.secCode);
      });

      /* Custom resize policy when the table width is changed. */
      widthProperty().addListener((obs, oldVal, newVal) -> {
         double tableWidth = newVal.doubleValue();
         double diff = newVal.doubleValue() - oldVal.doubleValue();
         resizeColumns(tableWidth, diff);
      });

       /* Adding width listener to all columns */
       getColumns().forEach(column -> column.widthProperty().addListener(widthListener));
   }

   /**
    * Gets the instrument name from the WatchListRow object.
    *
    * @param cellDataFeatures Table column cell data features
    * @return Observable value of instrument name
    */
   private ObservableValue<String> getInstrumentName(TableColumn.CellDataFeatures<WatchlistRow, String> cellDataFeatures) {
      final WatchlistRow watchlistRow = cellDataFeatures.getValue();
      if (watchlistRow.isHeading()) {
         return new ReadOnlyObjectWrapper<>(cellDataFeatures.getValue().getHeading());
      } else {
         return new ReadOnlyObjectWrapper<>(Util.stripper((cellDataFeatures.getValue().getRow()).getProperty(AmpIcapSecBoardTrim2.secCode).get(), "UKT"));
      }
   }

   public Consumer<TickUpDownAmendArgs> getDoTickUpDownPriceAmend() {
      return doTickUpDownPriceAmend;
   }

   public void setDoTickUpDownPriceAmend(Consumer<TickUpDownAmendArgs> doTickUpDownPriceAmend) {
      this.doTickUpDownPriceAmend = doTickUpDownPriceAmend;
   }

   /**
    * Gets the total value from the WatchListRow object for the provided order side.
    *
    * @param cellDataFeatures Table column cell data features
    * @param side             Order side
    * @return Observable value of total
    */
   private ObservableValue<Double> getTotal(TableColumn.CellDataFeatures<WatchlistRow, Double> cellDataFeatures, OrderSide side) {
      final ReadOnlyObjectWrapper<Double> nullObj = new ReadOnlyObjectWrapper<>(null);
      final WatchlistRow watchlistRow = cellDataFeatures.getValue();
      if (watchlistRow.isHeading()) {
         return nullObj;
      } else {
         return totalColFactory == null ? nullObj : totalColFactory.apply(watchlistRow.getRow(), side);
      }
   }

   /**
    * Gets the CLOB price value from the WatchListRow object for the provided order side.
    *
    * @param cellDataFeatures Table column cell data features
    * @param side             Order side
    * @return Observable value of price
    */
   private ObservableValue<PriceCellValue<BigDecimal>> getCLOBPrice(TableColumn.CellDataFeatures<WatchlistRow, PriceCellValue<BigDecimal>> cellDataFeatures, OrderSide side) {
      final ReadOnlyObjectWrapper<PriceCellValue<BigDecimal>> nullObj = new ReadOnlyObjectWrapper<>(null);
      final WatchlistRow watchlistRow = cellDataFeatures.getValue();
      if (watchlistRow.isHeading()) {
         return nullObj;
      } else {
         return priceColFactory == null ? nullObj : priceColFactory.apply(watchlistRow, side);
      }
   }

   /**
    * Gets the XfeAction for the CLOB price from the WatchListRow object for the provided order side.
    *
    * @param cellDataFeatures Table column cell data features
    * @param side             Order side
    * @return Observable value of XfeAction
    */
   private ObservableValue<XfeAction> getCLOBXfeAction(TableColumn.CellDataFeatures<WatchlistRow, XfeAction> cellDataFeatures, OrderSide side) {
      final ReadOnlyObjectWrapper<XfeAction> nullObj = new ReadOnlyObjectWrapper<>(null);
      final WatchlistRow watchlistRow = cellDataFeatures.getValue();
      if (watchlistRow.isHeading()) {
         return nullObj;
      } else {
         return actionFactory == null ? nullObj : actionFactory.apply(watchlistRow.getRow(), side);
      }
   }

   /**
    * Gets the XfeAction for the CM price from the WatchListRow object for the provided order side.
    *
    * @param cellDataFeatures Table column cell data features
    * @param side             Order side
    * @return Observable value of XfeAction
    */
   private ObservableValue<XfeAction> getCMXfeAction(TableColumn.CellDataFeatures<WatchlistRow, XfeAction> cellDataFeatures, OrderSide side) {
      final ReadOnlyObjectWrapper<XfeAction> nullObj = new ReadOnlyObjectWrapper<>(null);
      final WatchlistRow watchlistRow = cellDataFeatures.getValue();
      if (watchlistRow.isHeading()) {
         return nullObj;
      } else {
         return cmActionfactory == null ? nullObj : cmActionfactory.apply(watchlistRow.getRow(), side);
      }
   }

   /**
    * Gets the CM price value from the WatchListRow object for the provided order side.
    *
    * @param row WatchlistRow
    * @return Observable value of price
    */
   private ObservableValue<PriceCellValue<BigDecimal>> getCMPrice(WatchlistRow row) {
      final ReadOnlyObjectWrapper<PriceCellValue<BigDecimal>> nullObj = new ReadOnlyObjectWrapper<>(null);
      if (row.isHeading()) {
         return nullObj;
      } else {
         return matchColFactory == null ? nullObj : matchColFactory.apply(row);
      }
   }

   private void resizeColumns(double tableWidth, double diff) {
      if (instrCol.isVisible()) {
         enableHBar();
         double totalMinVisibleColWidth = getColumns().stream().filter(col -> col != instrCol && col.isVisible()).mapToDouble(TableColumnBase::getMinWidth).sum();
         double totalVisibleColWidth = getColumns().stream().filter(col -> col != instrCol && col.isVisible()).mapToDouble(TableColumnBase::getWidth).sum();
         if (instrCol.getMinWidth() + totalVisibleColWidth < tableWidth) {
            instrCol.setPrefWidth(tableWidth - totalVisibleColWidth + COLUMN_FILL_BUFFER);
            hideHBar();
         } else if (totalMinVisibleColWidth < totalVisibleColWidth && diff < 0) {
            final List<TableColumn<?, ?>> visibleColumns = getColumns().stream().filter(col -> col != instrCol && col.isVisible()).collect(Collectors.toList());
            Collections.reverse(visibleColumns);
            for (TableColumn<?, ?> col : visibleColumns) {
               if (col.getWidth() > col.getMinWidth()) {
                  col.setPrefWidth(col.getWidth() + diff - 1); // here diff is -ve value
                  break;
               }
            }
         }
      }
   }

   private void setupColsMenu() {
      // setting up the menu for showing/hiding columns
      VBox settingsPane = new VBox();
      settingsPane.setPadding(new Insets(15));
      settingsPane.setSpacing(10);
      settingsPane.setPrefWidth(150);
      getColumns().forEach(col -> {
         String cbTitle = (String) col.getProperties().getOrDefault(SETTING_TEXT, col.getText());
         Double colWidth = col.getWidth();
         if (!cbTitle.isEmpty()) {
            CheckBox cb = new CheckBox(cbTitle);
            cb.selectedProperty().bindBidirectional(col.visibleProperty());
            cb.selectedProperty().addListener((observable, oldValue, newValue) -> {
               specProperty.set(specProperty.get().editColumnSpec(cbTitle, newValue));
               resizeColumns(getWidth(), 0);
            });
            col.widthProperty().addListener((observable, oldValue, newValue) -> specProperty.set(specProperty.get().editColumnSpec(cbTitle, (Double) newValue)));
            settingsPane.getChildren().add(cb);
            specProperty.set(specProperty.get().setColumnSpec(cbTitle, colWidth));
            ColumnSpec spec = specProperty.get().getColumnSpec(cbTitle);
            col.setPrefWidth(spec.getWidth());
            col.setVisible(spec.isVisible());
         }
      });

      if (columnsVisibilityAction != null) {
         Button applyAll = new Button("Apply All");
         settingsPane.getChildren().add(applyAll);
         applyAll.setOnAction(e -> columnsVisibilityAction.accept(specProperty.get()));
      }

      setSettingsContent(settingsPane);
      setTableMenuButtonVisible(true);
   }

   void applyColumnsVisibility(ColumnsSpec specs) {
      specProperty.set(specProperty.get().editColumnSpec(specs));
      getColumns().forEach(col -> {
         String cbTitle = (String) col.getProperties().getOrDefault(SETTING_TEXT, col.getText());
         if (!cbTitle.isEmpty()) {
            ColumnSpec spec = specProperty.get().getColumnSpec(cbTitle);
            col.setPrefWidth(spec.getWidth());
            col.setVisible(spec.isVisible());
         }
      });
   }

   public void setOneClickTrading(boolean oneClickTrading) {
      this.oneClickTrading = oneClickTrading;
   }

   public boolean isOneClickTrading() {
      return oneClickTrading;
   }

   public void setActionFactory(BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> actionFactory) {
      this.actionFactory = actionFactory;
   }

   public void setCMActionFactory(BiFunction<ObservableReplyRow, OrderSide, ObservableValue<XfeAction>> cmActionFactory) {
      this.cmActionfactory = cmActionFactory;
   }

   public void setMatchColFactory(Function<WatchlistRow, ObservableValue<PriceCellValue<BigDecimal>>> matchColFactory) {
      this.matchColFactory = matchColFactory;
   }

   public void setPriceColFactory(BiFunction<WatchlistRow, OrderSide, ObservableValue<PriceCellValue<BigDecimal>>> priceColFactory) {
      this.priceColFactory = priceColFactory;
   }

   public void setTotalColFactory(BiFunction<ObservableReplyRow, OrderSide, ObservableValue<Double>> totalColFactory) {
      this.totalColFactory = totalColFactory;
   }

   public void setColumnsVisibilityAction(Consumer<ColumnsSpec> columnsVisibilityAction) {
      this.columnsVisibilityAction = columnsVisibilityAction;
   }

   public void setTotalColDblClickAction(Consumer<PopupOrderEntryArgs> totalColDblClickAction) {
      this.totalColDblClickAction = totalColDblClickAction;
   }

   public Consumer<PopupOrderEntryArgs> getTotalColDblClickAction() {
      return totalColDblClickAction;
   }

   public void setPriceColDblClickAction(Consumer<PopupOrderEntryArgs> priceColDblClickAction) {
      this.priceColDblClickAction = priceColDblClickAction;
   }

   public Consumer<PopupOrderEntryArgs> getPriceColDblClickAction() {
      return priceColDblClickAction;
   }

   public void setSaveToggleClbk(BiConsumer<ObservableReplyRow, RowHighlight> saveToggle) {
      this.saveToggle = saveToggle;
   }

   public BiConsumer<ObservableReplyRow, RowHighlight> getSaveToggle() {
      return saveToggle;
   }

   public void setCMPriceColEntry(Consumer<PopupOrderEntryArgs> doCMPriceColEntry) {
      this.doCMPriceColEntry = doCMPriceColEntry;
   }

   public Consumer<PopupOrderEntryArgs> getCMPriceColEntry() {
      return doCMPriceColEntry;
   }

   public void setCMPriceColAmend(Consumer<PopupOrderEntryArgs> doCMPriceColAmend) {
      this.doCMPriceColAmend = doCMPriceColAmend;
   }

   public Consumer<PopupOrderEntryArgs> getCMPriceColAmend() {
      return doCMPriceColAmend;
   }

   public void setPriceColWorkupAction(Consumer<WorkupArgs> priceColWorkupAction) {
      this.priceColWorkupAction = priceColWorkupAction;
   }

   public Consumer<WorkupArgs> getPriceColWorkupAction() {
      return priceColWorkupAction;
   }

   public void setCMPriceColWorkupAction(Consumer<WorkupArgs> doCMPriceColWorkupAction) {
      this.doCMPriceColWorkupAction = doCMPriceColWorkupAction;
   }

   public Consumer<WorkupArgs> getCMPriceColWorkupAction() {
      return doCMPriceColWorkupAction;
   }

   public void setToggleExpandCollapseAction(Consumer<WatchlistRow> toggleExpandCollapseAction) {
      this.toggleExpandCollapseAction = toggleExpandCollapseAction;
   }

   public Consumer<WatchlistRow> getToggleExpandCollapseAction() {
      return toggleExpandCollapseAction;
   }

   public void setSendDefaultOrderClbk(BiFunction<ObservableReplyRow, Pair<OrderSide, Double>, Future<XtrTransReply>> sendDefaultOrderClbk) {
      this.sendDefaultOrderClbk = sendDefaultOrderClbk;
   }

   public BiFunction<ObservableReplyRow, Pair<OrderSide, Double>, Future<XtrTransReply>> getSendDefaultOrderClbk() {
      return sendDefaultOrderClbk;
   }

   public void setIsLockedClbk(Supplier<Boolean> isLockedClbk) {
      this.isLocked = isLockedClbk;
   }

   public Supplier<Boolean> getIsLocked() {
      return isLocked;
   }

   public void setTradesAggregatePopupAction(Consumer<TradesAggregateArgs> tradesAggregatePopupAction) {
      this.tradesAggregatePopupAction = tradesAggregatePopupAction;
   }

   public Consumer<TradesAggregateArgs> getTradesAggregatePopupAction() {
      return tradesAggregatePopupAction;
   }

   public Supplier<Integer> getZoomLevel() {
      return zoomLevel;
   }

   public void setZoomLevel(Supplier<Integer> zoomLevel) {
      this.zoomLevel = zoomLevel;
   }

   public void setPriceCellFlashDuration(Supplier<Integer> priceCellFlashDuration) {
      this.priceCellFlashDuration = priceCellFlashDuration;
   }

   public Supplier<Integer> getPriceCellFlashDuration() {
      return priceCellFlashDuration;
   }

   public ObjectProperty<ColumnsSpec> columnsSpecProperty() {
      return specProperty;
   }

   public SimpleSelectionTracker<WatchlistRow> getSelectionTracker() {
      return selectionTracker;
   }

   public BiFunction<String, String, StepArray> getStepArrayCallBack() {
      return stepArrayCallBack;
   }

   public void setStepArrayCallBack(BiFunction<String, String, StepArray> stepArrayCallBack) {
      this.stepArrayCallBack = stepArrayCallBack;
   }
}
