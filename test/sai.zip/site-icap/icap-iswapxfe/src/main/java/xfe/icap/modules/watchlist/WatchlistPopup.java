package xfe.icap.modules.watchlist;


import javafx.beans.*;
import javafx.collections.*;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.util.*;

import com.nomx.persist.watchlist.WatchlistSpec_v2;
import xstr.util.Fx;

import java.util.List;
import java.util.UUID;

public class WatchlistPopup {

   private final InstrumentsPane instrumentsPane;
//   private final MenuButton menuButton = new MenuButton("Tabs");
   private final ComboBox<WatchlistSpec_v2> comboBox = new ComboBox<>();


//   private final InvalidationListener watchlistLis = new InvalidationListener() {
//
//      @Override
//      public void invalidated(Observable arg0) {
//         generateMenuItems();
//      }
//   };


   private final InvalidationListener selectionLis = new InvalidationListener() {

      @Override
      public void invalidated(Observable arg0) {
         if(InstrumentsPane.getInternalSpecUpdate()){
            return;
         }

         WatchlistSpec_v2 spec = comboBox.getSelectionModel().getSelectedItem();
         if (spec != null) {
            instrumentsPane.selectTab(spec.id);
         }
      }
   };

   private final ObservableList<WatchlistSpec_v2> wholeList;

   private final InvalidationListener originalListLis = new InvalidationListener() {
      @Override
      public void invalidated(Observable observable) {
         comboBox.setItems(wholeList.filtered(spec->spec.isVisible()));
      }
   };

   public WatchlistPopup(ObservableList<WatchlistSpec_v2> wholeList , InstrumentsPane instrumentsPane) {
      this.wholeList = wholeList;

      class SpecHBox extends HBox {
         Label title = new Label();
         Label subTitle = new Label();

         SpecHBox() {
            title.getStyleClass().add("xfe-title-2");
            subTitle.getStyleClass().add("xfe-title-3");
            super.getChildren().addAll(title, subTitle);
         }

         public void setSpecInfo(String title, String subTitle) {
            this.title.setText(title);
            this.subTitle.setText(subTitle);
         }
      }

      this.instrumentsPane = instrumentsPane;


      originalListLis.invalidated(null);
      wholeList.addListener(originalListLis);

      comboBox.setMaxWidth(150);
      Callback<ListView<WatchlistSpec_v2>, ListCell<WatchlistSpec_v2>> specFactory = new Callback<ListView<WatchlistSpec_v2>, ListCell<WatchlistSpec_v2>>() {

         @Override
         public ListCell<WatchlistSpec_v2> call(ListView<WatchlistSpec_v2> spec) {
            return new ListCell<WatchlistSpec_v2>() {
               private final SpecHBox hbox;

               {
                  setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                  hbox = new SpecHBox();
               }

               @Override
               protected void updateItem(WatchlistSpec_v2 item, boolean empty) {
                  super.updateItem(item, empty);

                  if (item == null || empty) {
                     setGraphic(new Label());
                  } else {
                     hbox.setSpecInfo(item.getTitle(), item.getSubtitle());
                     setGraphic(hbox);
                  }
               }
            };
         }
      };
      comboBox.setCellFactory(specFactory);
      comboBox.setButtonCell(specFactory.call(null));
      comboBox.getItems().addListener((Observable paramObservable) -> {
         Fx.run(this::selectSpec);
      });
      selectSpec();
      comboBox.getSelectionModel().selectedItemProperty().addListener(selectionLis);
   }

//   private void generateMenuItems(){
//      comboBox.getItems().clear();
//      for(WatchlistSpec_v2 aspec: watchlist){
//         final MenuItem menuItem = new MenuItem();
//         Label title = new Label(aspec.getTitle());
//         title.getStyleClass().add("xfe-title-2");
//         Label subTitle = new Label(aspec.getSubtitle());
//         subTitle.getStyleClass().add("xfe-title-3");
//         HBox hbox = new HBox();
//         hbox.getChildren().addAll(title,subTitle);
//         menuItem.setGraphic(hbox);
//         menuItem.setUserData(aspec.id);
//         menuItem.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent arg0) {
//               WatchlistSpec_v2 spec = comboBox.getSelectionModel().getSelectedItem();
//               if(spec!=null){
//                  instrumentsPane.selectTab(spec.id);
//               }
//            }
//         });
//      }
//   }

   public void dispose(){
//      watchlist.removeListener(watchlistLis);
      comboBox.getSelectionModel().selectedItemProperty().removeListener(selectionLis);
      wholeList.removeListener(originalListLis);

//      comboBox.setItems(null);
   }

   public Node getMenuButton(){
      return comboBox;
   }

   public void selectSpec() {
      WatchlistSpec_v2 instrumentsPaneSpec = instrumentsPane.getSelectedSpec();
      List<WatchlistSpec_v2> list = comboBox.getItems();

      if(instrumentsPaneSpec==null || list.isEmpty()) return;
      int size = list.size();
      UUID selectedUUID = instrumentsPaneSpec.getId();
      for(int i=0;i<size;i++){
         if(selectedUUID.equals(list.get(i).getId())){
            comboBox.getSelectionModel().select(i);
            break;
         }
      }
   }
}
