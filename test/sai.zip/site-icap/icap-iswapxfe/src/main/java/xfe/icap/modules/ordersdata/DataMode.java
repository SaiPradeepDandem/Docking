package xfe.icap.modules.ordersdata;

public enum DataMode {
   ENTRY,
   AMEND,
   RENEW
}
