package xfe.icap.modules.settings;

import com.nomx.domain.types.*;

import xstr.util.Fx;
import xfe.util.scene.control.DurationTextField;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.util.scene.layout.FxmlPane;
import xfe.util.Util;
import xfe.icap.XfeSession;
import xfe.icap.ui.Sounds;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;

import javax.sound.sampled.*;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.LineEvent.Type;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class SettingsPane implements FxmlPane {

   @FXML public VBox rootNode;
   @FXML public ScrollPane scrollPane;
   @FXML public VBox vbox_titlePaneContainer;
   @FXML public TitledPane settings_general;
   @FXML public Label general_lbl;
   @FXML public TitledPane settings_pricesettings;
   @FXML public Label pricesettings_lbl;
   @FXML public TitledPane settings_orderentrydefaults;
   @FXML public Label orderentrydefaults_lbl;
   @FXML public TitledPane settings_tradealerts;
   @FXML public Label tradealerts_lbl;
   @FXML public TitledPane settings_rfqsettings;
   @FXML public Label rfqsettings_lbl;

   @FXML public VBox pricesettings_vbox;
   @FXML public CheckBox general_chk_hivis;
   @FXML public CheckBox general_chk_autoSave;
   @FXML public CheckBox general_chk_orderConfirm;
   @FXML public CheckBox general_chk_volumeTab;
   @FXML public ChoiceBox<OnLogoffAction> general_choice_actionOnLogoff;
   @FXML public Label general_lbl_actionOnLogoff;
   @FXML public CheckBox general_chk_autoLogon;
   @FXML public TextField general_tf_autoLogon_timeout;
   @FXML public Label general_lbl_autoLogon_timeout;
   @FXML public CheckBox general_chk_ptTab;
   @FXML public TextField general_tf_pt_outright;
   @FXML public Label general_lbl_pt_outright;
   @FXML public TextField general_tf_pt_strategy;
   @FXML public Label general_lbl_pt_strategy;
   @FXML public TextField general_tf_pt_butterfly;
   @FXML public Label general_lbl_pt_butterfly;

   @FXML public CheckBox pricesettings_chk_priceMerge_watchlist;
   @FXML public CheckBox pricesettings_chk_priceMerge_mini;
   @FXML public CheckBox pricesettings_chk_history;
   @FXML public CheckBox pricesettings_chk_flashCell;
   @FXML public RadioButton pricesettings_rb_bidOffer;
   @FXML public RadioButton pricesettings_rb_offerBid;
   @FXML public TextField pricesettings_tf_outright_HL;
   @FXML public Label pricesettings_lbl_outright_HL;
   @FXML public TextField pricesettings_tf_strategy_HL;
   @FXML public Label pricesettings_lbl_strategy_HL;
   @FXML public TextField pricesettings_tf_flashCell_time;
   @FXML public Label pricesettings_lbl_flashCell_time;
   @FXML public TextField pricesettings_tf_history_time;
   @FXML public Label pricesettings_lbl_history_time;
   @FXML public TextField ordersize_tf_outrightQuantity;
   @FXML public Label ordersize_lbl_outrightQuantity;
   @FXML public TextField ordersize_tf_strategyQuantity;
   @FXML public Label ordersize_lbl_strategyQuantity;
   @FXML public CheckBox ordersize_chk_marketSize;
   @FXML public CheckBox ordersize_chk_yoursMine_defaultSize;
   @FXML public TextField ordersize_tf_leftQuantity;
   @FXML public Label ordersize_lbl_leftQuantity;
   @FXML public TextField ordersize_tf_middleQuantity;
   @FXML public Label ordersize_lbl_middleQuantity;
   @FXML public TextField ordersize_tf_rightQuantity;
   @FXML public Label ordersize_lbl_rightQuantity;
   @FXML public TextField ordersize_tf_yoursMine_litDelay;
   @FXML public Label ordersize_lbl_yoursMine_litDelay;
   @FXML public ChoiceBox<DefaultDurationType> ordersize_combo_durationType;
   @FXML public Label ordersize_lbl_durationType;
   @FXML public DurationTextField ordersize_tf_duration;
   @FXML public Label ordersize_lbl_duration;
   @FXML public CheckBox ordersize_chk_anonymous;
   @FXML public CheckBox ordersize_chk_autoOCO;
   @FXML public CheckBox ordersize_chk_shared;
   @FXML public CheckBox ordersize_chk_managed;
   @FXML public CheckBox ordersize_chk_yoursMine_orderWithdraw;
   @FXML public CheckBox ordersize_chk_cloneToTS;

   @FXML public CheckBox tradeAlert_chk_show;
   @FXML public CheckBox tradeAlert_chk_displayLegs;
   @FXML public CheckBox tradeAlert_chk_expire;
   @FXML public CheckBox tradeAlert_chk_sound;
   @FXML public CheckBox tradeAlert_chk_workup;
   @FXML public ChoiceBox<AlertsGroup> tradeAlert_combo_for;
   @FXML public CheckBox tradeAlert_cb_broker;
   @FXML public TextField tradeAlert_tf_expire;
   @FXML public CheckBox tradeAlert_chk_tradeWorkup;
   @FXML public Button tradeAlert_button_allTradeSound;
   @FXML public Label tradeAlert_lbl_allTradeSound;
   @FXML public ChoiceBox<AlertSound> tradeAlert_combo_allTradeSound;
   @FXML public Button tradeAlert_button_myTradeSound;
   @FXML public Label tradeAlert_lbl_myTradeSound;
   @FXML public ChoiceBox<AlertSound> tradeAlert_combo_myTradeSound;
   @FXML public Button tradeAlert_button_testAlert;
   @FXML public CheckBox rfq_chk_rfqNotification;
   @FXML public CheckBox rfq_chk_tab;
   @FXML public CheckBox rfq_chk_anonymous;
   @FXML public CheckBox rfq_chk_hidePane;
   @FXML public CheckBox rfq_chk_hideLastLookOrders;
   @FXML public ScrollPane rfq_mmPane;
   @FXML public VBox rfq_mmVbox;
   @FXML public Button rfq_button_mmGroup;
   @FXML public CheckBox rfq_chk_useGroup;
   @FXML public Label rfq_lbl_marketMaker;

   @FXML public Label tradeAlert_lbl_for;
   @FXML public Label label_after;
   @FXML public Label label_seconds;

   @FXML public Button btn_load;

   private static XfeSession xfeSession;
   private final List<TitledPane> panels = new ArrayList<>();
   private final ObjectProperty<BitSet> expandedSetProperty = new SimpleObjectProperty<>();

   public static SettingsPane load(XfeSession xfeSession) {
      SettingsPane.xfeSession = xfeSession;
      FXMLLoader ldr = new FXMLLoader(SettingsPane.class.getResource("Settings.fxml"));
      SettingsPane pane = new SettingsPane();
      ldr.setController(pane);
      try {
         ldr.load();
         return pane;
      } catch (IOException e) {
         e.printStackTrace();
      }
      return null;
   }

   void setExpandedStates(BitSet expandStates) {
      for (int i = 0; i < panels.size(); ++i)
         panels.get(i).setExpanded(expandStates.get(i));
   }

   private void addExpandedListener(TitledPane pane) {
      pane.expandedProperty().addListener((observable, oldValue, newValue) -> {
         int index = panels.indexOf(pane);
         BitSet bs = (BitSet) getExpandedSet().clone();
         if (index != -1)
            bs.set(index, newValue);
         expandedSetProperty().setValue(bs);
      });
   }

   private final ToggleGroup tgBidSide = new ToggleGroup();

   @FXML private void initialize() {

      panels.addAll(Arrays.asList(
         settings_general,
         settings_pricesettings,
         settings_orderentrydefaults,
         settings_tradealerts,
         settings_rfqsettings));

      BitSet expandedStates = new BitSet(panels.size());
      expandedStates.set(0, true);
      setExpandedStates(expandedStates);
      expandedSetProperty().setValue(expandedStates);

      panels.forEach(this::addExpandedListener);

      tgBidSide.getToggles().addAll(pricesettings_rb_bidOffer, pricesettings_rb_offerBid);

      ordersize_combo_durationType.getItems().addAll(DefaultDurationType.GOOD_TILL_DAY, DefaultDurationType.GOOD_TILL_DURATION, DefaultDurationType.GOOD_TILL_CANCELLED);

      general_choice_actionOnLogoff.getItems().addAll(OnLogoffAction.REFER, OnLogoffAction.NONE, OnLogoffAction.WITHDRAW);

      tradeAlert_combo_for.getItems().add(AlertsGroup.ALL);
      if (xfeSession.getUnderlyingSession().isLoggedOnUserBroker()) {
         tradeAlert_cb_broker.setSelected(false);
         tradeAlert_cb_broker.setVisible(false);
      } else {
         tradeAlert_combo_for.getItems().add(AlertsGroup.DESK);
      }

      tradeAlert_combo_for.getItems().add(AlertsGroup.MINE);

      AlertSound.setitems(tradeAlert_combo_allTradeSound);
      AlertSound.setitems(tradeAlert_combo_myTradeSound);

      tradeAlert_combo_for.setConverter(new StringConverter<AlertsGroup>() {
         @Override
         public String toString(AlertsGroup alertVal) {
            String strVal = "Un Supported";
            switch (alertVal) {
               case ALL:
                  strVal = "ALL";
                  break;
               case MINE:
                  strVal = xfeSession.getUnderlyingSession().getLoggedOnUser().getUserId();
                  break;
               case DESK:
                  strVal = "DESK";
                  break;
               case NONE:
                  strVal = "";
                  break;
               default:
                  break;
            }

            return strVal;
         }

         @Override
         public AlertsGroup fromString(String string) {
            return null;
         }
      });

      tradeAlert_button_testAlert.setOnAction(event -> {
         EventHandler<ActionEvent> handler = SettingsData.getOpenTradeNotificationProp();
         if (handler != null) {
            handler.handle(event);
         }
      });

      rfq_button_mmGroup.setOnAction(event -> {
         EventHandler<ActionEvent> handler = SettingsData.getMMOpenAction();
         if (handler != null) {
            handler.handle(event);
         }
      });

      XfeTooltipFactory.setTooltip(this);
   }


   private <T> void bindVariable(Property<T> listener, Property<T> observable){
      observable.addListener((ob -> listener.setValue(observable.getValue())));
      listener.addListener(ob -> observable.setValue(listener.getValue()));
   }

   void bounds(SettingsData data) {
      //SettingsData data1 = data;
      general_chk_hivis.selectedProperty().set(data.hiVisProperty().get());
      bindVariable(data.hiVisProperty(), general_chk_hivis.selectedProperty());

      setupEditControl(data.autoLogonTimeoutProperty(), 0, 999, general_tf_autoLogon_timeout);

      general_chk_autoSave.setSelected(data.autoSaveWorkspaceProperty().get());
      bindVariable(data.autoSaveWorkspaceProperty(), general_chk_autoSave.selectedProperty());

      general_chk_orderConfirm.setSelected(data.orderConfirmProperty().get());
      bindVariable(data.orderConfirmProperty(),general_chk_orderConfirm.selectedProperty());
      general_chk_volumeTab.setSelected(data.displayVolumeTabProperty().get());
      bindVariable(data.displayVolumeTabProperty(), general_chk_volumeTab.selectedProperty());

      general_choice_actionOnLogoff.getSelectionModel().select(data.onLogoffActionProperty().get());
      bindVariable(data.onLogoffActionProperty(), general_choice_actionOnLogoff.valueProperty());

      general_chk_autoLogon.setSelected(data.autoLogonEnabledProperty().get());
      bindVariable(data.autoLogonEnabledProperty(), general_chk_autoLogon.selectedProperty());

      general_chk_ptTab.setSelected(data.displayPTTabProperty().get());
      bindVariable(data.displayPTTabProperty(), general_chk_ptTab.selectedProperty());

      setupEditControl(data.outrightPTForTabProperty(), 0., 100., -1, general_tf_pt_outright);
      setupEditControl(data.strategyPTForTabProperty(), 0., 100., -1, general_tf_pt_strategy);
      setupEditControl(data.butterflyPTForTabProperty(), 0. , 100., -1, general_tf_pt_butterfly);
      BooleanBinding tabHidden = general_chk_ptTab.selectedProperty().not();
      general_tf_pt_outright.disableProperty().bind(tabHidden);
      general_tf_pt_strategy.disableProperty().bind(tabHidden);
      general_tf_pt_butterfly.disableProperty().bind(tabHidden);

      pricesettings_chk_priceMerge_watchlist.setSelected(data.mergeImpliedMainWatchlistProperty().get());
      bindVariable(data.mergeImpliedMainWatchlistProperty(), pricesettings_chk_priceMerge_watchlist.selectedProperty());

      pricesettings_chk_priceMerge_mini.setSelected(data.mergeImpliedMiniWatchlistProperty().get());
      bindVariable(data.mergeImpliedMiniWatchlistProperty(), pricesettings_chk_priceMerge_mini.selectedProperty());

      pricesettings_chk_history.setSelected(data.displayHistoryProperty().get());
      bindVariable(data.displayHistoryProperty(), pricesettings_chk_history.selectedProperty());

      pricesettings_chk_flashCell.setSelected(data.cellFlashProperty().get());
      bindVariable(data.cellFlashProperty(), pricesettings_chk_flashCell.selectedProperty());

      setupEditControl(data.cellFlashTimeoutProperty(), 0, 999, pricesettings_tf_flashCell_time);

      tgBidSide.selectToggle(data.bidOnLeftProperty().get() ? pricesettings_rb_bidOffer : pricesettings_rb_offerBid);
      bindVariable(data.bidOnLeftProperty(), pricesettings_rb_bidOffer.selectedProperty());

      setupEditControl(data.outrightPriceTight(), 0., 999., -1, pricesettings_tf_outright_HL);
      setupEditControl(data.strategyPriceTight(), 0., 999., -1, pricesettings_tf_strategy_HL);
      setupEditControl(data.historyHeaderNotificationTimeoutProperty(), 0, 999, pricesettings_tf_history_time);
      setupEditControl(data.outrightDefaultQtyProperty(), 0., 9999., 0, ordersize_tf_outrightQuantity);
      setupEditControl(data.strategyDefaultQtyProperty(), 0., 9999., 0, ordersize_tf_strategyQuantity);

      ordersize_chk_marketSize.setSelected(data.marketSizeOnOrderEnterProperty().get());
      bindVariable(data.marketSizeOnOrderEnterProperty(), ordersize_chk_marketSize.selectedProperty());

      ordersize_chk_yoursMine_defaultSize.setSelected(data.yoursMineDefaultAmountProperty().get().equals(AmountType.DEFAULT));
      ordersize_chk_yoursMine_defaultSize.selectedProperty().addListener(observable -> {
         data.yoursMineDefaultAmountProperty().setValue(ordersize_chk_yoursMine_defaultSize.isSelected() ?
            AmountType.DEFAULT :
            AmountType.ORDER);
      });
      data.yoursMineDefaultAmountProperty().addListener(observable -> {
         ordersize_chk_yoursMine_defaultSize.setSelected(data.yoursMineDefaultAmountProperty().get().equals(AmountType.DEFAULT));
      });

      setupEditControl(data.leftQtyBtnProperty(), 0, 999, ordersize_tf_leftQuantity);
      setupEditControl(data.middleQtyBtnProperty(), 0, 999, ordersize_tf_middleQuantity);
      setupEditControl(data.rightQtyBtnProperty(), 0, 999, ordersize_tf_rightQuantity);
      setupEditControl(data.yoursMineLitDelayProperty(), 0, 999, ordersize_tf_yoursMine_litDelay);

      ordersize_combo_durationType.getSelectionModel().select(data.defaultDurationTypeProperty().get());
      bindVariable(data.defaultDurationTypeProperty(), ordersize_combo_durationType.getSelectionModel());

      ordersize_tf_duration.setValue(data.defaultDurationProperty().get());
      bindVariable(data.defaultDurationProperty(), ordersize_tf_duration.valueProperty());

      ordersize_chk_anonymous.setSelected(data.anonOrdersProperty().get());
      bindVariable(data.anonOrdersProperty(), ordersize_chk_anonymous.selectedProperty());

      ordersize_chk_autoOCO.setSelected(data.autoOCOProperty().get());
      data.autoOCOProperty().bindBidirectional(ordersize_chk_autoOCO.selectedProperty());
      //bindVariable(data.autoOCOProperty(), ordersize_chk_autoOCO.selectedProperty());

      ordersize_chk_shared.setSelected(data.sharedOrdersProperty().getValue());
      bindVariable(data.sharedOrdersProperty(), ordersize_chk_shared.selectedProperty());

      if(xfeSession.getUnderlyingSession().isLoggedOnUserBroker()) {
         data.managedOrdersProperty().setValue(false);
         ordersize_chk_managed.setSelected(false);
         ordersize_chk_managed.setDisable(true);
      }else{
         ordersize_chk_managed.setSelected(data.managedOrdersProperty().get());
         bindVariable(data.managedOrdersProperty(), ordersize_chk_managed.selectedProperty());

      }

      ordersize_chk_yoursMine_orderWithdraw.setSelected(data.yoursMineOrderWithdrawProperty().get());
      bindVariable(data.yoursMineOrderWithdrawProperty(), ordersize_chk_yoursMine_orderWithdraw.selectedProperty());

      ordersize_chk_cloneToTS.setSelected(data.clone2RFSProperty().get());
      bindVariable(data.clone2RFSProperty(), ordersize_chk_cloneToTS.selectedProperty());

      // Trade Alerts

      tradeAlert_cb_broker.setSelected(data.showBrokerTradeProperty().get());
      bindVariable(data.showBrokerTradeProperty(),tradeAlert_cb_broker.selectedProperty());

      if (xfeSession.getUnderlyingSession().isLoggedOnTrader()) {
         AlertsGroup value = data.tradeAlertsProperty().get();
         tradeAlert_combo_for.setValue(value);
         enableDiasbleBrokerCB(value);
      } else {
         tradeAlert_combo_for.getSelectionModel().select(1);
      }

      tradeAlert_chk_show.setSelected(!Objects.equals(data.tradeAlertsProperty().get(), AlertsGroup.NONE));
      InvalidationListener showTradeAlertsListener = observable -> {
         boolean notSelected = !tradeAlert_chk_show.isSelected();
         tradeAlert_lbl_for.setDisable(notSelected);
         tradeAlert_chk_displayLegs.setDisable(notSelected);
         tradeAlert_chk_expire.setDisable(notSelected);
         tradeAlert_combo_for.setDisable(notSelected);
         tradeAlert_combo_for.getSelectionModel().select(tradeAlert_chk_show.isSelected() ? (data.tradeAlertsProperty().getValue()==AlertsGroup.NONE ? AlertsGroup.MINE : data.tradeAlertsProperty().get()) : AlertsGroup.NONE);
      };

      showTradeAlertsListener.invalidated(null);
      tradeAlert_chk_show.selectedProperty().addListener(showTradeAlertsListener);
      data.tradeAlertsProperty().addListener(observable -> {
         tradeAlert_chk_show.setSelected(!Objects.equals(data.tradeAlertsProperty().get(), AlertsGroup.NONE));
         AlertsGroup value = data.tradeAlertsProperty().get();
         tradeAlert_combo_for.setValue(value);
         enableDiasbleBrokerCB(value);
      });
      tradeAlert_combo_for.getSelectionModel().selectedItemProperty().addListener(observable -> {
         AlertsGroup value = tradeAlert_combo_for.getSelectionModel().selectedItemProperty().getValue();
         data.tradeAlertsProperty().setValue(value);
         enableDiasbleBrokerCB(value);
      });

      tradeAlert_chk_expire.setSelected(data.tradeAlertPopupExpiryProperty().get());
      bindVariable(data.tradeAlertPopupExpiryProperty(), tradeAlert_chk_expire.selectedProperty());
      label_after.disableProperty().bind(tradeAlert_chk_show.selectedProperty().not().or(tradeAlert_chk_expire.selectedProperty().not()));
      label_seconds.disableProperty().bind(tradeAlert_chk_show.selectedProperty().not().or(tradeAlert_chk_expire.selectedProperty().not()));
      tradeAlert_tf_expire.disableProperty().bind(tradeAlert_chk_show.selectedProperty().not().or(tradeAlert_chk_expire.selectedProperty().not()));

      tradeAlert_chk_sound.setSelected(data.tradeSoundProperty().get());
      InvalidationListener showTradeAlertSoundsListener = observable -> {
         tradeAlert_combo_myTradeSound.setDisable(!tradeAlert_chk_sound.isSelected());
         tradeAlert_lbl_myTradeSound.setDisable(!tradeAlert_chk_sound.isSelected());
         tradeAlert_button_myTradeSound.setDisable(!tradeAlert_chk_sound.isSelected());

         tradeAlert_combo_allTradeSound.setDisable(!tradeAlert_chk_sound.isSelected());
         tradeAlert_lbl_allTradeSound.setDisable(!tradeAlert_chk_sound.isSelected());
         tradeAlert_button_allTradeSound.setDisable(!tradeAlert_chk_sound.isSelected());

         data.tradeSoundProperty().setValue(tradeAlert_chk_sound.isSelected());
      };
      showTradeAlertSoundsListener.invalidated(null);
      tradeAlert_chk_sound.selectedProperty().addListener(showTradeAlertSoundsListener);

      data.tradeSoundProperty().addListener(observable -> {
         tradeAlert_chk_sound.setSelected(data.tradeSoundProperty().get());
      });

      tradeAlert_chk_displayLegs.setSelected(data.alertsShowLegsProperty().get());
      bindVariable(data.alertsShowLegsProperty(), tradeAlert_chk_displayLegs.selectedProperty());

      setupEditControl(data.tradeAlertPopupExpiryValueProperty(), 0, 999, tradeAlert_tf_expire);

      tradeAlert_combo_myTradeSound.getSelectionModel().select(data.alertSoundForMineProperty().get());
      bindVariable(data.alertSoundForMineProperty(), tradeAlert_combo_myTradeSound.getSelectionModel());
      tradeAlert_button_myTradeSound.setOnAction(event -> play(tradeAlert_combo_myTradeSound, tradeAlert_button_myTradeSound));

      tradeAlert_combo_allTradeSound.getSelectionModel().select(data.alertSoundForAllProperty().get());
      bindVariable(data.alertSoundForAllProperty(), tradeAlert_combo_allTradeSound.getSelectionModel());
      tradeAlert_button_allTradeSound.setOnAction(event -> play(tradeAlert_combo_allTradeSound, tradeAlert_button_allTradeSound));

      tradeAlert_chk_tradeWorkup.setSelected(data.autoPopupWorkupProperty().get());
      bindVariable(data.autoPopupWorkupProperty(), tradeAlert_chk_tradeWorkup.selectedProperty());

      rfq_chk_tab.setSelected(data.displayRFQTabProperty().get());
      bindVariable(data.displayRFQTabProperty(), rfq_chk_tab.selectedProperty());

      rfq_chk_rfqNotification.setSelected(data.rfqNotificationProperty().get());
      bindVariable(data.rfqNotificationProperty(), rfq_chk_rfqNotification.selectedProperty());

      rfq_chk_anonymous.setSelected(data.rfqAnonymousProperty().get());
      bindVariable(data.rfqAnonymousProperty(), rfq_chk_anonymous.selectedProperty());

      //rfq_chk_aonOrder.setSelected(data.rfqInitiatorOrderAon().get());
      bindVariable(data.rfqInitiatorOrderAon(), Fx.FalseProp/*rfq_chk_aonOrder.selectedProperty()*/);

      rfq_chk_hidePane.setSelected(data.hideRfqPaneProperty().get());
      bindVariable(data.hideRfqPaneProperty(), rfq_chk_hidePane.selectedProperty());

      rfq_chk_hideLastLookOrders.setSelected(data.hideNonAutoAcceptProperty().get());
      bindVariable(data.hideNonAutoAcceptProperty(), rfq_chk_hideLastLookOrders.selectedProperty());

      rfq_chk_useGroup.setSelected(data.rfqMMAdvSettingAEnabledProperty().get());
      bindVariable(data.rfqMMAdvSettingAEnabledProperty(), rfq_chk_useGroup.selectedProperty());

      rfq_mmPane.disableProperty().bind(rfq_chk_useGroup.selectedProperty());
      rfq_button_mmGroup.disableProperty().bind(rfq_chk_useGroup.selectedProperty().not());

      List<String> wholeList = new ArrayList(data.getAllFirms());
      ObjectProperty<List<String>> mmEffectiveListProp = data.selectedMMFirmsProperty();
      List<String> changedMM = new ArrayList(mmEffectiveListProp.get());
      changedMM.retainAll(wholeList);
      for (String str: wholeList.stream().sorted().collect(Collectors.toList())) {
         CheckBox checkBox = new CheckBox(str);
         if (changedMM.contains(str)) {
            checkBox.setSelected(true);
         }
         rfq_mmVbox.getChildren().add(checkBox);
         checkBox.selectedProperty().addListener(observable -> {
            if (checkBox.selectedProperty().get()) {
               if (!changedMM.contains(str)) {
                  changedMM.add(str);
                  mmEffectiveListProp.setValue(changedMM.stream().sorted().collect(Collectors.toList()));
               }
            } else {
               changedMM.remove(str);
               mmEffectiveListProp.setValue(changedMM.stream().sorted().collect(Collectors.toList()));
            }
         });
      }
   }

   private void enableDiasbleBrokerCB(AlertsGroup value) {
      if ((xfeSession.getUnderlyingSession().isLoggedOnUserBroker()) || value != AlertsGroup.MINE) {
         tradeAlert_cb_broker.setSelected(false);
         tradeAlert_cb_broker.setVisible(false);
      } else {
         tradeAlert_cb_broker.setVisible(true);
      }
   }

   private <T> void bindVariable(ObjectProperty<T> objectProperty, SingleSelectionModel<T> selectionModel) {
      selectionModel.selectedItemProperty().addListener(observable -> {
         objectProperty.setValue(selectionModel.getSelectedItem());
      });

      objectProperty.addListener(observable -> {
         selectionModel.select(objectProperty.get());
      });
   }

   private void play(ChoiceBox<AlertSound> combo_tradeSound, Button testButton) {
      if(testButton.getText().contains("Test")) {
         AlertSound as = combo_tradeSound.getSelectionModel().getSelectedItem();
         if (as.equals(AlertSound.NONE)) {
            return;
         }
         try {
            URL url = SettingsPane.class.getResource("/css/" + as.getFile());
            AudioInputStream sound = AudioSystem.getAudioInputStream(url);
            Info info = new Info(Clip.class, sound.getFormat());

            Clip clip;
            try {
               clip = (Clip) AudioSystem.getLine(info);
            } catch (Exception e) {
               new Sounds(as.getFile()).play();
               return;
            }

            clip.open(sound);
            testButton.setUserData(clip);
            testButton.setText("Stop");
            clip.start();
            clip.addLineListener(new LineListener() {
               public void update(LineEvent event) {
                  if (event.getType() == Type.STOP) {
                     clip.removeLineListener(this);
                     event.getLine().close();
                     testButton.setUserData(null);
                  }
               }
            });
         } catch (Exception e) {
            e.printStackTrace();
         }
      }else{
         testButton.setText("Test");
         Object o = testButton.getUserData();
         if(o!=null){
            ((Clip) o).stop();
         }
      }

   }

   public Region getRoot(){
      return rootNode;
   }

   BitSet getExpandedSet() {
      return this.expandedSetProperty.get();
   }

   ObjectProperty<BitSet> expandedSetProperty() {
      return this.expandedSetProperty;
   }

   private class CellCheckBox extends CheckBox{

      public CellCheckBox(ListView<String> listView){
         MultipleSelectionModel<String> selectionModel = listView.getSelectionModel();
         List<String> items = listView.getItems();
         List<String> selectedItems = selectionModel.getSelectedItems();
         selectedProperty().addListener(observable -> {
            String item = CellCheckBox.this.getText();
            if (CellCheckBox.this.isSelected()) {
               listView.getSelectionModel().select(item);
            } else {
               try {
                  listView.getSelectionModel().clearSelection(listView.getItems().indexOf(item));
               } catch (Error ignored) {
               }
            }
         });

         selectionModel.getSelectedItems().addListener((Observable observable) -> {
            CellCheckBox.this.setSelected(selectedItems.contains(CellCheckBox.this.getText()));
         });
      }
   }

   private void setupEditControl(IntegerProperty dataProperty, Integer minValue, Integer maxValue, TextField control) {
      control.setTextFormatter(Util.getFormatter(dataProperty.getValue(), minValue, maxValue));
      dataProperty.bindBidirectional((Property<Number>) control.textFormatterProperty().getValue().valueProperty());
   }

   private void setupEditControl(DoubleProperty dataProperty, Double minValue, Double maxValue, int decimals, TextField control) {
      control.setTextFormatter(Util.getFormatter(dataProperty.getValue(), minValue, maxValue, decimals));
      dataProperty.bindBidirectional((Property<Number>) control.textFormatterProperty().getValue().valueProperty());
   }

   void tailorForRole(){
      if(xfeSession.getUnderlyingSession().isLoggedOnUserBroker()) {
         pricesettings_vbox.getChildren().remove(pricesettings_chk_priceMerge_watchlist);
      }
   }
}
