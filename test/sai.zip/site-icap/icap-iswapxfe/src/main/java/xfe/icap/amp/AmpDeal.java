package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.acc.AmpAccessor;

import java.math.BigDecimal;
import java.util.Date;

public class AmpDeal extends AmpAccessor {
   public static final AMP.AmpQreq req = AMP.qREQ("dealReq");
   public static final AMP.AmpQrep rep = AMP.qREP("dealRep");

   public static final AsnAccessor dealId = acc(AMP.qREP("dealRep.dealId"));
   public static final AsnConversionAccessor<Long> dealNo = acc(AMP.qREP("dealRep.dealId.dealNo"), Long.class);
   public static final AsnConversionAccessor<Long> dealNoSuffix = acc(AMP.qREP("dealRep.dealId.dealNoSuffix"), Long.class);
   public static final AsnConversionAccessor<BigDecimal> adjustedPrice = acc(AMP.qREP("dealRep.dynamics.adjustedPrice"), BigDecimal.class);
   public static final AsnConversionAccessor<String> commissionType = acc(AMP.qREP("dealRep.dynamics.commissionType"), String.class);
   public static final AsnConversionAccessor<String> operatorId = acc(AMP.qREP("dealRep.dynamics.operatorId"), String.class);
   public static final AsnConversionAccessor<BigDecimal> price = acc(AMP.qREP("dealRep.dynamics.price"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> quantity = acc(AMP.qREP("dealRep.dynamics.quantity"), Double.class);
   public static final AsnConversionAccessor<Integer> status = acc(AMP.qREP("dealRep.dynamics.status"), Integer.class);
   public static final AsnConversionAccessor<String> traderId = acc(AMP.qREP("dealRep.dynamics.traderId"), String.class);
   public static final AsnConversionAccessor<Integer> buySell = acc(AMP.qREP("dealRep.statics.buySell"), Integer.class);
   public static final AsnConversionAccessor<Date> dealTime = acc(AMP.qREP("dealRep.statics.dealTime"), Date.class);
   public static final AsnConversionAccessor<Integer> dealType = acc(AMP.qREP("dealRep.statics.dealType"), Integer.class);
   public static final AsnConversionAccessor<String> extDealId = acc(AMP.qREP("dealRep.statics.extDealId"), String.class);
   public static final AsnConversionAccessor<String> firmId = acc(AMP.qREP("dealRep.statics.firmId"), String.class);
   public static final AsnAccessor strategyDealId = acc(AMP.qREP("dealRep.statics.strategyDealId"));
   public static final AsnConversionAccessor<Boolean> historical = acc(AMP.qREP("dealRep.statics.historical"), Boolean.class);
   public static final AsnAccessor secBoard = acc(AMP.qREP("dealRep.statics.secBoard"));
   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("dealRep.statics.secBoard.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("dealRep.statics.secBoard.boardId"), String.class);

   public static String getBuySell(Integer buySell) {
      switch (buySell.intValue()) {
         case 0:
            return "B";
         case 1:
            return "S";
         default:
            return "";
      }
   }

   public static String getStatusAsString(Integer status){
      switch(status) {
         case 0:
            return "No Status";
         case 1:
            return "Approved";
         case 2:
            return "Broker Approved";
         case 3:
            return "Pending Approval";
         case 4:
            return "Cancelled";
         default:
            return "UNDEFINED";
      }
   }
}
