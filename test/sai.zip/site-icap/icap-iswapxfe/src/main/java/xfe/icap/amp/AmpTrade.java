package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.acc.AmpAccessor;
import xstr.session.QueryReplyRow;
import xstr.types.OrderSide;
import xstr.util.Strings;

import java.math.BigDecimal;
import java.util.*;

public class AmpTrade extends AmpAccessor {

   public static final AmpQreq req = AMP.qREQ("tradeReq");
   public static final AmpQrep rep = AMP.qREP("tradeRep");

   public static final AsnAccessor tradeId = acc(AMP.qREP("tradeRep.tradeId"));
   public static final AsnAccessor buyStrategyTradeId = acc(AMP.qREP("tradeRep.dynamics.buyStrategyTradeId"));
   public static final AsnAccessor sellStrategyTradeId = acc(AMP.qREP("tradeRep.dynamics.sellStrategyTradeId"));
   public static final AsnConversionAccessor<String> buyStrategyTradeNo = acc(AMP.qREP("tradeRep.dynamics.buyStrategyTradeId.tradeNo"), String.class);
   public static final AsnConversionAccessor<String> sellStrategyTradeNo = acc(AMP.qREP("tradeRep.dynamics.sellStrategyTradeId.tradeNo"), String.class);


   public static final AsnConversionAccessor<String> secBoardId = acc(AMP.qREP("tradeRep.statics.secBoardId"), String.class);
   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("tradeRep.statics.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("tradeRep.statics.secBoardId.boardId"), String.class);
   public static final AsnConversionAccessor<Double> price_d = acc(AMP.qREP("tradeRep.dynamics.price"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> price = acc(AMP.qREP("tradeRep.dynamics.price"), BigDecimal.class);
   public static final AsnConversionAccessor<Double> quantity_d = acc(AMP.qREP("tradeRep.dynamics.quantity"), Double.class);
   public static final AsnConversionAccessor<BigDecimal> quantity = acc(AMP.qREP("tradeRep.dynamics.quantity"), BigDecimal.class);
   //public static final AsnConversionAccessor<Double> buyWorkupQuantity = acc(AMP.qREP("tradeRep.dynamics.buyWorkUpQuantity"), Double.class);
   //public static final AsnConversionAccessor<Double> sellWorkupQuantity = acc(AMP.qREP("tradeRep.dynamics.sellWorkUpQuantity"), Double.class);
   public static final AsnConversionAccessor<Date> time = acc(AMP.qREP("tradeRep.statics.time"), Date.class);
   public static final AsnConversionAccessor<String> timeAsString = acc(AMP.qREP("tradeRep.statics.time"), String.class);
   //public static final AsnConversionAccessor<XtrTime> workupExpTime = acc(AMP.qREP("tradeRep.statics.workUpExpTime"), XtrTime.class);
   public static final AsnConversionAccessor<Integer> status = acc(AMP.qREP("tradeRep.dynamics.status"), Integer.class);
   public static final AsnConversionAccessor<String> buyFirmId = acc(AMP.qREP("tradeRep.statics.buyFirmId"), String.class);
   public static final AsnConversionAccessor<String> sellFirmId = acc(AMP.qREP("tradeRep.statics.sellFirmId"), String.class);
   // public static final AsnConversionAccessor<String> buyBrokerId = acc(AMP.qREP("tradeRep.statics.buyBrokerUserName"), String.class);
   // public static final AsnConversionAccessor<String> sellBrokerId = acc(AMP.qREP("tradeRep.statics.sellBrokerUserName"), String.class);
   public static final AsnConversionAccessor<String> buyTraderId = acc(AMP.qREP("tradeRep.statics.buyTraderId"), String.class);
   public static final AsnConversionAccessor<String> sellTraderId = acc(AMP.qREP("tradeRep.statics.sellTraderId"), String.class);
   public static final AsnConversionAccessor<String> buyAccountName = acc(AMP.qREP("tradeRep.statics.buyTrdAccName"), String.class);
   public static final AsnConversionAccessor<String> sellAccountName = acc(AMP.qREP("tradeRep.statics.sellTrdAccName"), String.class);
   public static final AsnConversionAccessor<String> buyOperatorId = acc(AMP.qREP("tradeRep.statics.buyOperatorId"), String.class);
   public static final AsnConversionAccessor<String> sellOperatorId = acc(AMP.qREP("tradeRep.statics.sellOperatorId"), String.class);
   public static final AsnConversionAccessor<String> buyIntroBrokerId = acc(AMP.qREP("tradeRep.statics.buyIntroBrokerId"), String.class);
   public static final AsnConversionAccessor<String> sellIntroBrokerId = acc(AMP.qREP("tradeRep.statics.sellIntroBrokerId"), String.class);
   public static final AsnConversionAccessor<String> buyIntroBrokerFirmId = acc(AMP.qREP("tradeRep.statics.buyIntroBrokerFirmId"), String.class);
   public static final AsnConversionAccessor<String> sellIntroBrokerFirmId = acc(AMP.qREP("tradeRep.statics.sellIntroBrokerFirmId"), String.class);
   public static final AsnConversionAccessor<Integer> buyStrategyTradeType = acc(AMP.qREP("tradeRep.statics.buyStrategyTradeType"), Integer.class);
   public static final AsnConversionAccessor<String> buyStrategyTradeTypeAsString = acc(AMP.qREP("tradeRep.statics.buyStrategyTradeType"), String.class);
   public static final AsnConversionAccessor<Integer> sellStrategyTradeType = acc(AMP.qREP("tradeRep.statics.sellStrategyTradeType"), Integer.class);
   public static final AsnConversionAccessor<String> sellStrategyTradeTypeAsString = acc(AMP.qREP("tradeRep.statics.sellStrategyTradeType"), String.class);
   public static final AsnConversionAccessor<Boolean> isAutoTrade = acc(AMP.qREP("tradeRep.statics.isAutoTrade"), Boolean.class);
   public static final AsnConversionAccessor<Long> numLegTrades = acc(AMP.qREP("tradeRep.statics.numLegTrades"), Long.class);
   public static final AsnConversionAccessor<String> tradeNo = acc(AMP.qREP("tradeRep.tradeId.tradeNo"), String.class);
   public static final AsnConversionAccessor<Integer> buySTPStatus = acc(AMP.qREP("tradeRep.dynamics.buySTPStatus"), Integer.class);
   public static final AsnConversionAccessor<String> buySTPStatusAsString = acc(AMP.qREP("tradeRep.dynamics.buySTPStatus"), String.class);
   public static final AsnConversionAccessor<Integer> sellSTPStatus = acc(AMP.qREP("tradeRep.dynamics.sellSTPStatus"), Integer.class);
   public static final AsnConversionAccessor<String> sellSTPStatusAsString = acc(AMP.qREP("tradeRep.dynamics.sellSTPStatus"), String.class);
   public static final AsnConversionAccessor<String> buyMarkitWireId = acc(AMP.qREP("tradeRep.statics.buyMarkitWireId"), String.class);
   public static final AsnConversionAccessor<String> sellMarkitWireId = acc(AMP.qREP("tradeRep.statics.sellMarkitWireId"), String.class);
   public static final AsnConversionAccessor<String> buyGuiReference = acc(AMP.qREP("tradeRep.tradeDetails.buyGuiReference"), String.class);
   public static final AsnConversionAccessor<String> sellGuiReference = acc(AMP.qREP("tradeRep.tradeDetails.sellGuiReference"), String.class);
   public static final AsnConversionAccessor<String> buyTraderUserName = acc(AMP.qREP("tradeRep.tradeDetails.buyTraderUserName"), String.class);
   public static final AsnConversionAccessor<String> sellTraderUserName = acc(AMP.qREP("tradeRep.tradeDetails.sellTraderUserName"), String.class);
   public static final AsnConversionAccessor<Double> spreadoverBP = acc(AMP.qREP("tradeRep.tradeDetails.bond1Details.basisPoints"), Double.class);
   public static final AsnConversionAccessor<String> aggressiveSide = acc(AMP.qREP("tradeRep.tradeDetails.aggressiveSide"), String.class);
   public static AsnConversionAccessor<String> externalTradeId = acc(AMP.qREP("tradeRep.tradeDetails.externalTradeId"), String.class);
   public static AsnConversionAccessor<Date> amendTime = acc(AMP.qREP("tradeRep.dynamics.amendTime"), Date.class);
   ;
   public static final AsnConversionAccessor<Boolean> prvlgdWorkUpTriggered = acc(AMP.qREP("tradeRep.statics.prvlgdWorkUpTriggered"), Boolean.class);
   public static final AsnConversionAccessor<String> prvlgdTrdngSessionNo = acc(AMP.qREP("tradeRep.statics.prvlgdTrdngSessionNo"), String.class);

   // Extra Fields accessors
   public static final AsnConversionAccessor<String> buyDealStatus = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "buyDealStatus",
      String.class);

   public static final AsnConversionAccessor<String> sellDealStatus = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "sellDealStatus",
      String.class);

   private static final AsnConversionAccessor<String> buyDealId = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "buyDealId",
      String.class);

   private static final AsnConversionAccessor<String> sellDealId = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "sellDealId",
      String.class);

   public static final AsnConversionAccessor<BigDecimal> buyCommission = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "buyCommission",
      BigDecimal.class);

   public static final AsnConversionAccessor<BigDecimal> sellCommission = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "sellCommission",
      BigDecimal.class);

   public static final AsnConversionAccessor<BigDecimal> buyAdjustedPrice = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "buyAdjustedPrice",
      BigDecimal.class);

   public static final AsnConversionAccessor<BigDecimal> sellAdjustedPrice = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "sellAdjustedPrice",
      BigDecimal.class);

   public static final AsnConversionAccessor<String> buyCommissionType = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "buyCommissionType",
      String.class);

   public static final AsnConversionAccessor<String> sellCommissionType = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "sellCommissionType",
      String.class);

   public static final AsnConversionAccessor<String> buyExtDealId = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "buyExtDealId",
      String.class);

   public static final AsnConversionAccessor<String> sellExtDealId = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "sellExtDealId",
      String.class);

   public static final AsnConversionAccessor<Boolean> isCMTrade = acc(AMP.qREP(
      "tradeRep.dynamics.extraFieldsList"),
      "isCMTrade",
      Boolean.class);


   public static String getAggressiveSide(QueryReplyRow row) {
      return row.getString(aggressiveSide);
   }

   public static String toShortString(Optional<QueryReplyRow> row) {
      return row.map(AmpTrade::toShortString).orElse("NULL Row (trade)");
   }

   public static String getStatus(int status) {
      switch (status) {
         case 1:
            return "Done";
         case 2:
            return "Withdrawn";
         case 3:
            return "Unapproved";
         case 4:
            return "Uncnf Buy";
         case 5:
            return "Uncnf Sell";
         case 6:
            return "Pending";
         case 7:
            return "Amended";
         case 9:
            return "LL Pending";
         default:
            return "";
      }
   }

   private static String toShortString(QueryReplyRow row) {
      if (row == null) return "NULL Row (trade)";
      return String.format(
         "[%s:%s] Trade %s/%s %s/%s buy %s@%s from %s/%s",
         row.getString(tradeNo),
         row.getString(time),
         row.getString(secCode),
         row.getString(boardId),
         row.getString(buyFirmId),
         row.getString(buyTraderId),
         row.getString(price),
         row.getString(quantity_d),
         row.getString(sellFirmId),
         row.getString(sellTraderId)
      );
   }

   public static String abbreviate(QueryReplyRow row) {
      if (row == null) return "NULL Row (trade)";
      String tn = row.getString(tradeNo);
      if (tn != null) tn = Strings.takeRight(tn, 4);
      return String.format("[%s:%s] Trade", tn, row.getString(time));
   }

   public static List<AsnAccessor> getOneSideAccessors(OrderSide side) {
      return side == OrderSide.BUY ? buyAccessors : sellAccessors;
   }

   static {
      List<AsnAccessor> buyAccs = new ArrayList<>();
      List<AsnAccessor> sellAccs = new ArrayList<>();

      buyAccs.add(AmpTrade.buyFirmId);
      buyAccs.add(AmpTrade.buyTraderId);
      buyAccs.add(AmpTrade.buyAccountName);
      buyAccs.add(AmpTrade.buyOperatorId);
      buyAccs.add(AmpTrade.buyIntroBrokerId);
      buyAccs.add(AmpTrade.buyIntroBrokerFirmId);
      buyAccs.add(AmpTrade.buyStrategyTradeType);
      buyAccs.add(AmpTrade.buyStrategyTradeTypeAsString);
      buyAccs.add(AmpTrade.buySTPStatus);
      buyAccs.add(AmpTrade.buySTPStatusAsString);
      buyAccs.add(AmpTrade.buyMarkitWireId);
      buyAccs.add(AmpTrade.buyGuiReference);
      buyAccs.add(AmpTrade.buyTraderUserName);
      // buyAccs.add(AmpTrade.buyDealStatus);
      buyAccs.add(AmpTrade.buyDealId);
      buyAccs.add(AmpTrade.buyCommission);
      buyAccs.add(AmpTrade.buyAdjustedPrice);
      buyAccs.add(AmpTrade.buyCommissionType);

      buyAccessors = Collections.unmodifiableList(buyAccs);

      sellAccs.add(AmpTrade.sellFirmId);
      sellAccs.add(AmpTrade.sellTraderId);
      sellAccs.add(AmpTrade.sellAccountName);
      sellAccs.add(AmpTrade.sellOperatorId);
      sellAccs.add(AmpTrade.sellIntroBrokerId);
      sellAccs.add(AmpTrade.sellIntroBrokerFirmId);
      sellAccs.add(AmpTrade.sellStrategyTradeType);
      sellAccs.add(AmpTrade.sellStrategyTradeTypeAsString);
      sellAccs.add(AmpTrade.sellSTPStatus);
      sellAccs.add(AmpTrade.sellSTPStatusAsString);
      sellAccs.add(AmpTrade.sellMarkitWireId);
      sellAccs.add(AmpTrade.sellGuiReference);
      sellAccs.add(AmpTrade.sellTraderUserName);
      // sellAccs.add(AmpTrade.sellDealStatus);
      sellAccs.add(AmpTrade.sellDealId);
      sellAccs.add(AmpTrade.sellCommission);
      sellAccs.add(AmpTrade.sellAdjustedPrice);
      sellAccs.add(AmpTrade.sellCommissionType);

      sellAccessors = Collections.unmodifiableList(sellAccs);
   }

   private static final List<AsnAccessor> buyAccessors;
   private static final List<AsnAccessor> sellAccessors;
}


