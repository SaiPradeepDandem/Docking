package xfe.icap.types;


import java.util.Date;

import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnConversionAccessor;
import xfe.icap.amp.AmpManagedOrderTAcc;
import xstr.types.MapWrapper;
import xfe.ui.notifications.ModalAlertModule;
import com.omxgroup.syssrv.Duration;

public class ManagedOrderTrans extends AbstractOrderTrans {
   private static class ManagedOrderAcc implements OrderAcc {
      @Override
      public AmpTreq transaction() {
         return AmpManagedOrderTAcc.txn;
      }

      @Override
      public AsnConversionAccessor<String> secCode() {
         return AmpManagedOrderTAcc.secCode;
      }

      @Override
      public AsnConversionAccessor<String> boardId() {
         return AmpManagedOrderTAcc.boardId;
      }

      @Override
      public AsnConversionAccessor<Integer> type() {
         return AmpManagedOrderTAcc.type;
      }

      @Override
      public AsnConversionAccessor<Boolean> isPrivate() {
         return AmpManagedOrderTAcc.isPrivate;
      }

      @Override
      public AsnConversionAccessor<Boolean> isDoneIfTouched() {
         return AmpManagedOrderTAcc.isDoneIfTouched;
      }

      @Override
      public AsnConversionAccessor<Boolean> isTopCut() {
         return AmpManagedOrderTAcc.isTopCut;
      }

      @Override
      public AsnConversionAccessor<Double> price() {
         return AmpManagedOrderTAcc.price;
      }

      @Override
      public AsnConversionAccessor<Double> quantity() {
         return AmpManagedOrderTAcc.quantity;
      }

      @Override
      public AsnConversionAccessor<Integer> duration() {
         return AmpManagedOrderTAcc.durationType;
      }

      @Override
      public AsnConversionAccessor<Duration> durationTime() {
         return AmpManagedOrderTAcc.durationTime;
      }

      @Override
      public AsnConversionAccessor<Double> visibleQuantity() {
         return AmpManagedOrderTAcc.visibleQuantity;
      }

      @Override
      public AsnConversionAccessor<Double> minFillQuantity() {
         return AmpManagedOrderTAcc.minFillQuantity;
      }

      @Override
      public AsnConversionAccessor<Boolean> allowMultiMinFill() {
         return AmpManagedOrderTAcc.allowMultiMinFill;
      }

      @Override
      public AsnConversionAccessor<Integer> buySell() {
         return AmpManagedOrderTAcc.buySell;
      }

      @Override
      public AsnConversionAccessor<Boolean> isPublic() {
         return AmpManagedOrderTAcc.isPublic;
      }

      @Override
      public AsnConversionAccessor<Integer> actionOnLogoff() {
         return AmpManagedOrderTAcc.actionOnLogoff;
      }

      @Override
      public AsnConversionAccessor<Boolean> isShared() {
         return AmpManagedOrderTAcc.shared;
      }

		@Override
		public AsnConversionAccessor<Date> pickupOrderDate() {
			return AmpManagedOrderTAcc.pickOrderDate;
		}

		@Override
		public AsnConversionAccessor<Long> pickupOrderNo() {
			return AmpManagedOrderTAcc.pickOrderNo;
		}

		@Override
		public AsnConversionAccessor<Long> pickupOrderNoSuffix() {
			return AmpManagedOrderTAcc.pickOrderNoSuffix;
		}

		@Override
		public AsnConversionAccessor<String> introBrokerId() {
			return AmpManagedOrderTAcc.introBrokerId;
		}

		@Override
		public AsnConversionAccessor<Date> crossingOrderDate() {
			return AmpManagedOrderTAcc.crossLinkedOrderDate;
		}

		@Override
		public AsnConversionAccessor<Long> crossingOrderNo() {
			return AmpManagedOrderTAcc.crossLinkedOrderNo;
		}

		@Override
		public AsnConversionAccessor<Long> crossingOrderNoSuffix() {
			return AmpManagedOrderTAcc.crossLinkedOrderNoSuffix;
		}

      @Override
      public AsnConversionAccessor<Boolean> isCloneIntoRFS() {
         return AmpManagedOrderTAcc.cloneIntoRFS;
      }

      @Override
      public AsnConversionAccessor<MapWrapper> extraField() {
         return AmpManagedOrderTAcc.extrafields;
      }
   }

   public ManagedOrderTrans(ModalAlertModule notifier) {
      super(notifier, new ManagedOrderAcc());
   }
}
