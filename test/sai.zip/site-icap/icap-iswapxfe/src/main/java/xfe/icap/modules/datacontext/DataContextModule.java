package xfe.icap.modules.datacontext;

import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpRfq;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.types.IcapRfqSecurity;
import xfe.icap.types.IcapSecurity;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import xfe.types.Security;
import xstr.types.User;
import xfe.util.Constants;
import xstr.util.IcapBooleanProperty;
import xstr.util.ListenerTracker;
import xstr.util.collection.FilteredStaticSorter;
import xstr.util.concurrent.Future;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.RowFilters;
import xfe.icap.XfeSession;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.module.Module;
import xfe.icap.modules.iswaporders.OrderFilters;
import xfe.modules.session.SessionScopeModule;

@Module.Autostart
public class DataContextModule extends SessionScopeModule implements Constants {
   private static final Logger logger = LoggerFactory.getLogger(DataContextModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public SelectionContextModule selectionContextModule;

   public ObservableList<ObservableReplyRow> getReferrableOrders() {
      return referrableOrdersFilter.getItems();
   }

   public ObservableList<ObservableReplyRow> getRenewableOrders() {
      return renewableOrdersFilter.getItems();
   }

   public ObservableList<ObservableReplyRow> getWithdrawableOrders() {
      return withdrawableOrdersFilter.getItems();
   }

   public ObservableList<ObservableReplyRow> getAmendableOrders() {
      // NOTE: For securities this will always return nothing, because
      // is is meant to be used for non-managed orders.
      return amendableOrdersFilter.getItems();
   }

   public BooleanBinding getPickableBinding(){
      return pickableBinding;
   }

   public ObservableValue<Security> selectedSecurity() {
      return security;
   }

   public ObservableBooleanValue hasReferrableOrders() {
      return Bindings.isEmpty(referrableOrdersFilter.getItems()).not();
   }

   public ObservableBooleanValue hasRenewableOrders() {
      return Bindings.isEmpty(renewableOrdersFilter.getItems()).not();
   }

   public ObservableBooleanValue hasWithdrawableOrders() {
      return Bindings.isEmpty(withdrawableOrdersFilter.getItems()).not();
   }

   @Override
   public Future<Void> startModule() {
      dataContextIsNeedPickupColumn = selectionContextModule.dataContextRfqSec.or(selectionContextModule.dataContextRfsSec);
      isAllowRfsSession = xfeSessionModule.getUnderlyingSession().getStats().isRfsSessionAllowed ?
         new BooleanBinding() {
            {
               bind(selectionContextModule.isLoggedUserMarketMaker,selectionContextModule.dataContextRfsSec);
            }

            @Override
            public void dispose() {
               unbind(selectionContextModule.isLoggedUserMarketMaker,selectionContextModule.dataContextRfsSec);
               super.dispose();
            }

            @Override
            protected boolean computeValue() {

               //if(isLoggedUserMarketMaker.get()) return false;

               boolean rtn = false;
               if(!selectionContextModule.isLoggedUserMarketMaker.get()) {
                  SelectionContext contecContext = selectionContextModule.selectionContextProperty().get();
                  if (contecContext.grid == GridType.Watchlist || contecContext.grid== GridType.NONE) {
                     rtn =  selectionContextModule.dataContextRfsSec.get();
                  }
               }
               logger.trace("isAllowRfsSession is {}. dataContextRfsSec is {}; isLoggedUserMarketMaker is {}; contecContext is {}",rtn,selectionContextModule.dataContextRfsSec.get(),selectionContextModule.isLoggedUserMarketMaker.get(),selectionContextModule.selectionContextProperty().get());
               return rtn;
            }
         }
         :
         new BooleanBinding() {
            @Override
            protected boolean computeValue() {
               return false;
            }
         }
      ;


      dataContextRfsOrRfqSec.bind(selectionContextModule.dataContextRfsSec.or(Bindings.notEqual(NOTRFQ, rfqAllowedVerb)));
      allOrders = xfeSessionModule.orders.get().allOrders;

      referrableOrdersFilter = FilteredStaticSorter.create(allOrders, RowFilters.alwaysReject,tracker);
      renewableOrdersFilter = FilteredStaticSorter.create(allOrders, RowFilters.alwaysReject,tracker);
      withdrawableOrdersFilter = FilteredStaticSorter.create(allOrders, RowFilters.alwaysReject,tracker);
      amendableOrdersFilter = FilteredStaticSorter.create(allOrders, RowFilters.alwaysReject,tracker);
      tracker.addListener(selectionContextModule.selectionContextProperty(), selectionContextListener);
      pickableBinding = new BooleanBinding() {
         {
            bind(selectedSecurity(), xfeSessionModule.rfqs.get().finalPhaseRfqs.get(),selectionContextModule.dataContextRfsSec,selectionContextModule.dataContextRfsSessionSec);
         }
         @Override
         protected boolean computeValue() {
            if(selectionContextModule.dataContextRfsSec.get() || selectionContextModule.dataContextRfsSessionSec.get()){
               return true;
            }
            Security sec = selectedSecurity().getValue();
            if(sec==null) return false;
            String secCode = sec.getSecCode();
            String boardId = sec.getBoardId();
            for(ObservableReplyRow activeRfqRow: xfeSessionModule.rfqs.get().finalPhaseRfqs.get()){
               if(activeRfqRow.getValue(AmpRfq.secCode).equals(secCode) &&  activeRfqRow.getValue(AmpRfq.boardId).equals(boardId)){
                  return true;
               }
            }
            return false;
         }
      };
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      pickableBinding.dispose();
      dataContextRfsOrRfqSec.unbind();
      dataContextRfsOrRfqSec.clearListeners();
      referrableOrdersFilter = null;
      renewableOrdersFilter = null;
      withdrawableOrdersFilter = null;
      amendableOrdersFilter = null;
      allOrders = null;
      security.set(null);
      selectionContextModule.dataContextRfsSec.clearListeners();
      selectionContextModule.dataContextRfsSessionSec.clearListeners();
      selectionContextModule.dataContextRfqSessionSec.clearListeners();
      selectionContextModule.dataContextRfqSec.clearListeners();
      isAllowRfsSession.dispose();
      return Future.SUCCESS;
   }

   private void updateselectedOrderbook(ObservableReplyRow row) {
      if (row != null) {
         referrableOrdersFilter.setFilter(referrableOrdersForObboRow(row));
         renewableOrdersFilter.setFilter(renewableOrdersForObboRow(row));
         withdrawableOrdersFilter.setFilter(withdrawableOrdersForObboRow(row));
         amendableOrdersFilter.setFilter(amendableOrdersForObboRow(row));
      } else {
         referrableOrdersFilter.setFilter(RowFilters.alwaysReject);
         renewableOrdersFilter.setFilter(RowFilters.alwaysReject);
         withdrawableOrdersFilter.setFilter(RowFilters.alwaysReject);
         amendableOrdersFilter.setFilter(RowFilters.alwaysReject);
      }
   }

   private void updateselectedOrder(ObservableReplyRow row) {
      // Setting the filter for the dynamically updated list of orders
      if (row != null) {
         referrableOrdersFilter.setFilter(referrableOrdersForOrderRow(row));
         renewableOrdersFilter.setFilter(renewableOrdersForOrderRow(row));
         withdrawableOrdersFilter.setFilter(withdrawableOrdersForOrderRow(row));
         amendableOrdersFilter.setFilter(amendableOrdersForOrderRow(row));
         String secCode = row.getValue(AmpManagedOrder.secCode);
         String secBoard = row.getValue(AmpManagedOrder.boardId);
         int rfqRequest = xfeSessionModule.rfqs.get().getRfqRequest(secCode,secBoard);
         rfqAllowedVerb.set(rfqRequest);
      } else {
         referrableOrdersFilter.setFilter(RowFilters.alwaysReject);
         renewableOrdersFilter.setFilter(RowFilters.alwaysReject);
         withdrawableOrdersFilter.setFilter(RowFilters.alwaysReject);
         amendableOrdersFilter.setFilter(RowFilters.alwaysReject);
         rfqAllowedVerb.set(NOTRFQ);
      }
   }

   private void updateselectedTrade(ObservableReplyRow row) {
      referrableOrdersFilter.setFilter(RowFilters.alwaysReject);
      renewableOrdersFilter.setFilter(RowFilters.alwaysReject);
      withdrawableOrdersFilter.setFilter(RowFilters.alwaysReject);
      amendableOrdersFilter.setFilter(RowFilters.alwaysReject);
   }

   private void updateselectedSecurity(ObservableReplyRow row, AsnAccessor field) {
      renewableOrdersFilter.setFilter(RowFilters.alwaysReject); // Never support renew from securities
      referrableOrdersFilter.setFilter(referrableOrdersForSecRow(row, field));
      withdrawableOrdersFilter.setFilter(withdrawableOrdersForSecRow(row, field));
      amendableOrdersFilter.setFilter(RowFilters.alwaysReject); // Regular orders cannot be amended from securities

      if (row != null) {
         Security icapSec = new IcapSecurity(row);
         security.set(icapSec);
         String secCode = security.get().getSecCode();
         String secBoard = security.get().getBoardId();
         int rfqRequest = xfeSessionModule.rfqs.get().getRfqRequest(secCode,secBoard);
         rfqAllowedVerb.set(rfqRequest);
      } else {
         security.set(null);
         rfqAllowedVerb.set(NOTRFQ);
      }
   }

   private void updateSelectedRfq(ObservableReplyRow row) {
      amendableOrdersFilter.setFilter(RowFilters.alwaysReject);
      renewableOrdersFilter.setFilter(RowFilters.alwaysReject);
      referrableOrdersFilter.setFilter(RowFilters.alwaysReject);
      withdrawableOrdersFilter.setFilter(RowFilters.alwaysReject);

      if (row != null) {
         Security icapSec = new IcapRfqSecurity(row);
         security.set(icapSec);
         int rfqRequest = xfeSessionModule.rfqs.get().getRfqRequest(row);
         rfqAllowedVerb.set(rfqRequest);
      }
   }

   @SuppressWarnings("unchecked")
   private DynamicFilter<ObservableReplyRow> referrableOrdersForSecRow(ObservableReplyRow row, AsnAccessor field) {
      if (row == null || field == null)
         return RowFilters.alwaysReject;
      if (AmpIcapSecBoardTrim2.isBidRelated(field)) {
         return DynamicFilter.of(Filters.and(
            OrderFilters.clonedOrder.not(),
            OrderFilters.isStatusReferable,
            xfeSessionModule.getOrderFilters().isAmendable,
            Filters.dynamic(OrderFilters.withSide(AmpOrderVerb.buy)),
            Filters.dynamic(OrderFilters.withSecurity(row.getValue(AmpIcapSecBoardTrim2.secCode), row.getValue(AmpIcapSecBoardTrim2.boardId)))));
      } else if (AmpIcapSecBoardTrim2.isOfferRelated(field)) {
         return DynamicFilter.of(Filters.and(
            OrderFilters.clonedOrder.not(),
            OrderFilters.isStatusReferable,
            xfeSessionModule.getOrderFilters().isAmendable,
            Filters.dynamic(OrderFilters.withSide(AmpOrderVerb.sell)),
            Filters.dynamic(OrderFilters.withSecurity(row.getValue(AmpIcapSecBoardTrim2.secCode), row.getValue(AmpIcapSecBoardTrim2.boardId)))));
      }
      else
         return RowFilters.alwaysReject;
   }

   @SuppressWarnings("unchecked")
   private DynamicFilter<ObservableReplyRow> withdrawableOrdersForSecRow(ObservableReplyRow row, AsnAccessor field) {
      if (row == null || field == null)
         return RowFilters.alwaysReject;

      if (AmpIcapSecBoardTrim2.isBidRelated(field)) {
         return DynamicFilter.of(Filters.and(
            OrderFilters.clonedOrder.not(),
            OrderFilters.canWithdraw,
            Filters.dynamic(OrderFilters.withSide(AmpOrderVerb.buy)),
            Filters.dynamic(OrderFilters.withSecurity(row.getValue(AmpIcapSecBoardTrim2.secCode), row.getValue(AmpIcapSecBoardTrim2.boardId))),
            xfeSessionModule.getOrderFilters().isWithdrewable));
      } else if (AmpIcapSecBoardTrim2.isOfferRelated(field)) {
         return DynamicFilter.of(Filters.and(
            OrderFilters.canWithdraw,
            OrderFilters.clonedOrder.not(),
            Filters.dynamic(OrderFilters.withSide(AmpOrderVerb.sell)),
            Filters.dynamic(OrderFilters.withSecurity(row.getValue(AmpIcapSecBoardTrim2.secCode), row.getValue(AmpIcapSecBoardTrim2.boardId))),
            xfeSessionModule.getOrderFilters().isWithdrewable));
      }
      else
         return RowFilters.alwaysReject;
   }

   @SuppressWarnings("unchecked")
   private DynamicFilter<ObservableReplyRow> referrableOrdersForObboRow(ObservableReplyRow row) {
      return DynamicFilter.of(Filters.and(OrderFilters.clonedOrder.not(),OrderFilters.isStatusReferable, xfeSessionModule.getOrderFilters().isAmendable, Filters.dynamic(OrderFilters.matchObboRow(row))));
   }

   private DynamicFilter<ObservableReplyRow> renewableOrdersForObboRow(ObservableReplyRow row) {
      // Cannot renew orders from OBBO
      return RowFilters.alwaysReject;
   }

   @SuppressWarnings("unchecked")
   private DynamicFilter<ObservableReplyRow> withdrawableOrdersForObboRow(ObservableReplyRow row) {
      return DynamicFilter.of(Filters.and(OrderFilters.clonedOrder.not(),OrderFilters.canWithdraw,Filters.dynamic(OrderFilters.matchObboRow(row)),OrderFilters.isStatusReferable, xfeSessionModule.getOrderFilters().isWithdrewable));
   }

   // This is meant to be used externally for non-managed orders
   private DynamicFilter<ObservableReplyRow> amendableOrdersForObboRow(ObservableReplyRow row) {
      return xfeSessionModule.getOrderFilters().amendable
         .and(Filters.dynamic(OrderFilters.matchObboRow(row)));
   }

   private DynamicFilter<ObservableReplyRow> referrableOrdersForOrderRow(ObservableReplyRow row) {
      AsnAccessor acc;
      if (OrderFilters.isManaged.accept(row))
         acc = AmpManagedOrder.managedOrderId;
      else
         acc = AmpManagedOrder.currentOrderId;
      return DynamicFilter.of(Filters.and(OrderFilters.clonedOrder.not(),OrderFilters.isStatusReferable, xfeSessionModule.getOrderFilters().isAmendable,RowFilters.equalsAsn(acc, row.getAsn(acc))));
   }

   private DynamicFilter<ObservableReplyRow> renewableOrdersForOrderRow(ObservableReplyRow row) {
      AsnAccessor acc;
      if (OrderFilters.isManaged.accept(row))
         acc = AmpManagedOrder.managedOrderId;
      else
         acc = AmpManagedOrder.currentOrderId;
      return DynamicFilter.of(Filters.and(OrderFilters.canRenew, xfeSessionModule.getOrderFilters().isAmendable,RowFilters.equalsAsn(acc, row.getAsn(acc))));
   }

   private DynamicFilter<ObservableReplyRow> withdrawableOrdersForOrderRow(ObservableReplyRow row) {
      // The managed Order table can also contain regular orders. If the order is not
      // managed we need to match the row based on the current order Id
      User user = xfeSessionModule.getUnderlyingSession().getLoggedOnUser();
      String userId = user.getUserId();
      AsnConversionAccessor<String> asnAcc = user.isTrader() ? AmpManagedOrder.userId : (user.isIB() ? AmpManagedOrder.introBrokerId : AmpManagedOrder.operatorId);

      Asn1Type orderId = row.getAsn(AmpManagedOrder.managedOrderId);
      if (orderId != null)
         return RowFilters.equalsAsn(AmpManagedOrder.managedOrderId, orderId).and(RowFilters.equals(asnAcc,userId)).and(OrderFilters.clonedOrder.not());
      else {
         orderId = row.getAsn(AmpManagedOrder.currentOrderId);
         if (orderId != null)
            return RowFilters.equalsAsn(AmpManagedOrder.currentOrderId, orderId).and(RowFilters.equals(asnAcc,userId)).and(OrderFilters.clonedOrder.not());
         else
            return RowFilters.alwaysReject;
      }

   }

   // This is meant to be used externally for non-managed orders
   private DynamicFilter<ObservableReplyRow> amendableOrdersForOrderRow(ObservableReplyRow row) {
      AsnAccessor acc;
      if (OrderFilters.isManaged.accept(row))
         acc = AmpManagedOrder.managedOrderId;
      else
         acc = AmpManagedOrder.currentOrderId;
      return DynamicFilter.of(Filters.and(xfeSessionModule.getOrderFilters().amendable, RowFilters.equalsAsn(acc, row.getAsn(acc))));
   }
   /*
   RFQ:   include rfq session and rfs session.
   Rfq session:  (rfq)instrument created from “A” instruments.
   Rfs session:  (rfq)instrument created from “R” instrument,
    */
   public final IntegerProperty rfqAllowedVerb = new SimpleIntegerProperty(NOTRFQ);
   public final IcapBooleanProperty dataContextRfsOrRfqSec = new IcapBooleanProperty(this, "dataContextRfsOrRfqSec", false); //indicate the selected instrument is an RFS or RFQ
   private final ObjectProperty<Security> security = new SimpleObjectProperty<>();
   private final ListenerTracker tracker = new ListenerTracker();
   public BooleanBinding dataContextIsNeedPickupColumn;
   public BooleanBinding isAllowRfsSession ;
   private ObservableList<ObservableReplyRow> allOrders;
   private FilteredStaticSorter<ObservableReplyRow> referrableOrdersFilter;
   private FilteredStaticSorter<ObservableReplyRow> renewableOrdersFilter;
   private FilteredStaticSorter<ObservableReplyRow> withdrawableOrdersFilter;
   private FilteredStaticSorter<ObservableReplyRow> amendableOrdersFilter;
   private final ChangeListener<SelectionContext> selectionContextListener = (observableCtx, oldCtx, newCtx) -> {
      logger.debug("selectionContextModule.selectionContextProperty() is changed from\n{} to\n{}" ,oldCtx,newCtx);
      switch(newCtx.grid) {
         case Watchlist:
            updateselectedSecurity(newCtx.row, newCtx.field);
            break;
         case Orders:
            updateselectedOrder(newCtx.row);
            break;
         case Trades:
            updateselectedTrade(newCtx.row);
            break;
         case Rfq:
            updateSelectedRfq(newCtx.row);
            break;
         case OBBO_BUY:
         case OBBO_SELL:
            updateselectedOrderbook(newCtx.row);
         default:
            break;
      }
   };
   private BooleanBinding pickableBinding;
}
