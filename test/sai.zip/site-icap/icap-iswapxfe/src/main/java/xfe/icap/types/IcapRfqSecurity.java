package xfe.icap.types;

import org.slf4j.*;

import xstr.session.QueryReplyRow;
import xfe.icap.amp.AmpRfq;
import xfe.types.Security;

import java.util.Date;

public class IcapRfqSecurity implements Security {

   private static final Logger logger = LoggerFactory.getLogger(IcapRfqSecurity.class);
   private final QueryReplyRow data;

   public IcapRfqSecurity(QueryReplyRow data) {
      if (data == null) {
         throw new NullPointerException();
      }
      this.data = data;
   }

   @Override
   public String getSecCode() {
      return data.getValue(AmpRfq.secCode);
   }

   @Override
   public String getBoardId() {
      return data.getValue(AmpRfq.boardId);
   }

   @Override
   public Double getBidPrice() {
      return 0D;
   }

   @Override
   public Double getOfferPrice() {
      return 0D;
   }

   @Override
   public Double getNImpOfferPrice() {
      return 0D;
   }

   @Override
   public Double getNImpBidPrice() {
      return 0D;
   }

   @Override
   public Double getBidQuantity() {
      return 0D;
   }

   @Override
   public Double getOfferQuantity() {
      return 0D;
   }


   @Override
   public double getDefualtQuantity() {
      return 0;
   }

   @Override
   public boolean isDoneIfTouchedSupported() {
      return false;
   }

   @Override
   public Date getIssueDate() {
      return data.getValue(AmpRfq.startTime);
   }

   @Override
   public Date getMaturityDate() {
      return data.getValue(AmpRfq.endTime);
   }

   @Override
   public String getParentSecCode() {
      return data.getString(AmpRfq.parentSecCode);
   }

   @Override
   public String getParentBoardId() {
      return data.getString(AmpRfq.parentBoardId);
   }
}
