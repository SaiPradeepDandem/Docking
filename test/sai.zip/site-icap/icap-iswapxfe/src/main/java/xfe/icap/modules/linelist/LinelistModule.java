package xfe.icap.modules.linelist;

import com.nomx.persist.PersistantName;
import com.nomx.persist.linelist.LineList;
import com.nomx.persist.linelist.Participant;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.TextAlignment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.util.Dictionary;
import xstr.util.Fx;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.Future;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.icap.XfeSession;
import xfe.layout.LayoutManager;
import xfe.module.Module;
import xfe.icap.modules.actionsui.ConfigActionsUIModule;
import xfe.icap.modules.prefsview.PrefsViewsModule;
import xfe.modules.session.SessionModule;
import xfe.modules.session.ActiveSessionModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.watchlist.WatchlistModule;
import xfe.ui.InitialisableView;
import xfe.ui.PrefsViewFactory;
import xfe.ui.list.XfeGroup;
import xfe.ui.list.XfeItem;
import xfe.ui.tabpane.XfeTabPane;

import java.util.*;
import java.util.stream.Collectors;

@Module.Autostart
public class LinelistModule implements Module {
   static final Logger logger = LoggerFactory.getLogger(LinelistModule.class);

   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public ActiveSessionModule activeSessionModule;
   @ModuleDependency
   public LayoutManager<Node> layoutModule;
   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public PrefsViewsModule prefsViewsModule;
   @ModuleDependency
   public ConfigActionsUIModule configActionsModule;
   @ModuleDependency
   public WatchlistModule watchlistModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;

   public ObjectProperty<ObservableList<LineList>> getLinelist() {
      return configurationModule.getParametersStorage().getList(PersistantName.Linelist, LineList.class, new ArrayList<>(20));
   }

   ObservableList<LineList> getLinelistForEditing() {
      ObjectProperty<ObservableList<LineList>> existingList = getLinelist();
      LinkedList<LineList> temp = existingList.get().stream().map(LineList::copy).collect(Collectors.toCollection(LinkedList::new));
      return FXCollections.observableList(temp);
   }

   @Override
   public Future<Void> startModule() {
      showLinelistButton.selectedProperty().addListener(linelistLis);
      sessionModule.fxApplicationModule.getStage().addEventFilter(KeyEvent.KEY_PRESSED, keyPressLis);
      myTraderFirmMap = xfeSessionModule.traderFirmMap;

      if (myTraderFirmMap == null) {
         logger.info("No trader-Firm Map available. Skipping Line-list initialisation.");
         return Future.SUCCESS;
      }
      if (xfeSessionModule.getUnderlyingSession().getLoggedOnUser().isBroker()) {

         lineListPrefsViewFactory = new PrefsViewFactory() {
            @Override
            public InitialisableView create() {
               LineListEditView view = new LineListEditView(LinelistModule.this);
               view.initialise();
               return view;
            }

            @Override
            public String getViewName() {
               return "Line List";
            }

            @Override
            public int getLeftPriority() {
               return 20;
            }
         };

         prefsViewsModule.addView(lineListPrefsViewFactory, buttonLinelistEditorClone);
         if (xfeSessionModule.getUnderlyingSession().getLoggedOnUser().isBroker()) {
            configActionsModule.addNode(showLinelistShortcutButton);
            configActionsModule.addNode(showLinelistButton);
         }
      }

      boolean isTrader = xfeSessionModule.getUnderlyingSession().isLoggedOnTrader();
      onBehalfTrader = isTrader ? new SimpleObjectProperty<>(null) : configurationModule.getParametersStorage().get(PersistantName.OnbehalfOfTrader, Participant.class, (Participant) null);
      shortcutTraders  = isTrader ? new SimpleObjectProperty<>(null) : configurationModule.getParametersStorage().getList(PersistantName.ShortcutTraders,Participant.class,null);
      displayLinelist = isTrader ? new SimpleBooleanProperty(false) : configurationModule.getParametersStorage().get(PersistantName.DisplayLinstlist, true);
      displayLinelistShortcut = isTrader ? new SimpleBooleanProperty(false) : configurationModule.getParametersStorage().get(PersistantName.DisplayLinstlistShortcut, false);
      if (!isTrader) {
         tracker.addListener(onBehalfTrader, onBehalfTraderListener);
         onBehalfTraderListener.invalidated(null);
         if (logger.isTraceEnabled()) {
            onBehalfTrader.addListener(arg0 -> {
               logger.debug("now I am on behalf of: {}", onBehalfTrader.get());
            });

            xfeSessionModule.onBehalfTrader.addListener(arg0 -> {
               logger.debug("OnBehalf of: {}", xfeSessionModule.onBehalfTrader.get());
            });

         }
         tracker.addListener(getLinelist().get(), linelistInvalidListener);

         tracker.addListener(getLinelist(), observable -> {
            tracker.addListener(getLinelist().get(),linelistInvalidListener);
         });

         tracker.addListener(shortcutTraders.get(),shortcutInvalidationListener);
         tracker.addListener(shortcutPane.getSelectionModel().selectedItemProperty(), shortcutPaneSelectionLis);
         linelistInvalidListener.invalidated(null);
         shortcutInvalidationListener.invalidated(null);
         selectTab(onBehalfTrader.get());

         tracker.addListener(displayLinelist, linelistLis);
         linelistLis.invalidated(null);
         xfeSessionModule.traderFirmMap.readyPropertyRO.addListener(new InvalidationListener() {
            @Override
            public void invalidated(Observable observable) {
               xfeSessionModule.traderFirmMap.readyPropertyRO.removeListener(this);
               if(stage!=null) {
                  synchronizeLinelist();
                  stage.show();
               }
            }
         });
         tracker.addListener(displayLinelistShortcut, linelistShortcutLis);
         linelistShortcutLis.invalidated(null);
         checkAvailShortcut();
         showLinelistButton.selectedProperty().bindBidirectional(displayLinelist);
         showLinelistShortcutButton.selectedProperty().bindBidirectional(displayLinelistShortcut);
         dragDropHandler = new DragDropHandler(LinelistModule.this);
         dragDropHandler.setShortcutPane(tracker, shortcutPane, watchlistModule.getSwitchPane());

         if (!displayLinelist.get() && !displayLinelistShortcut.get()) {
            displayLinelist.set(true);
         }

         BooleanBinding shortcutButtonDisable = new BooleanBinding() {
            {
               bind(displayLinelistShortcut, displayLinelist);
            }

            @Override
            protected boolean computeValue() {
               return displayLinelistShortcut.get() && !displayLinelist.get();
            }

         };

         BooleanBinding linelistButtonDisable = new BooleanBinding() {
            {
               bind(displayLinelistShortcut, displayLinelist);
            }

            @Override
            protected boolean computeValue() {
               return !displayLinelistShortcut.get() && displayLinelist.get();
            }

         };
         showLinelistButton.disableProperty().bind(linelistButtonDisable);
         showLinelistShortcutButton.disableProperty().bind(shortcutButtonDisable);
      }


      return Future.SUCCESS;
   }

   // ParametersStorage.equals compares the storage between uisession and settingsdata.
   // But it seems it is not deep copy.  Need to deep copy here

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      if(linelistTreeTable!=null){
         linelistTreeTable.dispose();
         linelistTreeTable = null;
      }
      if (myTraderFirmMap == null) {
         return Future.SUCCESS;
      }
      if (stage != null) {
         stage.dispose();
         stage = null;
      }
      prefsViewsModule.removeView(lineListPrefsViewFactory);
      if (displayLinelist != null) {
         showLinelistButton.selectedProperty().unbindBidirectional(displayLinelist);
      }
      showLinelistShortcutButton.selectedProperty().unbindBidirectional(displayLinelistShortcut);
      displayLinelist = null;
      displayLinelistShortcut = null;
      shortcutPane.getTabs().clear();
      dragDropHandler = null;
      myTraderFirmMap = null;
      showLinelistButton.selectedProperty().removeListener(linelistLis);
      sessionModule.fxApplicationModule.getStage().removeEventFilter(KeyEvent.KEY_PRESSED, keyPressLis);
      return Future.SUCCESS;
   }

   void removeShortcut(Participant participant){
      shortcutTraders.get().remove(participant);
   }

   void addShortcut(Participant insertedParticipant, Participant overParticipant, boolean isRight) {
      List<Participant> exist = shortcutTraders.get();
      logger.debug("insert participant {} in shortcut list {} to the {} of {}.", insertedParticipant, exist, isRight ? "right":"left",overParticipant );
      int index = exist.indexOf(overParticipant);
      if (index == -1) {
         logger.warn("can't locate participant {} in shortcut list {}. The {} is appended.", overParticipant, exist, insertedParticipant);
         exist.add(insertedParticipant);
      } else {
         if(exist.indexOf(insertedParticipant)>=0){
            logger.debug("{} already in shortcut list.");
            arrangeShortcut(insertedParticipant, overParticipant,isRight);
         }else {
            index = isRight ? index + 1 : index;
            exist.add(index, insertedParticipant);
         }
      }
   }

   void arrangeShortcut(Participant insertedParticipant, Participant overParticipant, boolean isRight) {
      if (insertedParticipant.equals(overParticipant)) {
         logger.debug("participant {} over to itself {}.", insertedParticipant, overParticipant);
         return;
      }
      ObservableList<Participant> exist = shortcutTraders.get();
      logger.debug("arrange participant {} in shortcut list {} to the {} of {}.", insertedParticipant, exist, isRight ? "right" : "left", overParticipant);
      int index = exist.indexOf(insertedParticipant);
      if (index == -1) {
         logger.warn("can't locate participant {} in shortcut list {}. unchanged.", insertedParticipant, exist);
         return;
      }
      int index2;
      exist.indexOf(overParticipant);
      List<Participant> targetList = new LinkedList<>(exist);

      targetList.remove(index);
      index2 = targetList.indexOf(overParticipant);
      index2 = isRight ? index2 + 1 : index2;
      targetList.add(index2, insertedParticipant);
      exist.setAll(targetList);
   }

   void saveLineList(List<? extends XfeGroup<? extends XfeItem>> newList) {
      isUpdatingLineList = true;
      List<LineList> targetList = new ArrayList<>(newList.size());
      targetList.addAll(newList.stream().filter(line -> line.getItems().size() > 0).map(aline -> (LineList) aline.copy()).collect(Collectors.toList()));
      getLinelist().get().setAll(targetList);

      HashSet<Participant> newParticipants = new HashSet<>();
      targetList.stream().forEach(lineList -> newParticipants.addAll(lineList.getItems()));

      List<Participant> toBeRemoved = new LinkedList<>();
      shortcutTraders.get().stream().forEach(participant -> {
         if (!newParticipants.stream().anyMatch(newParticipant -> Objects.equals(newParticipant.id, participant.id) && Objects.equals(newParticipant.ib, participant.ib))) {
            toBeRemoved.add(participant);
         }
      });
      shortcutTraders.get().removeAll(toBeRemoved);
      isUpdatingLineList = false;

      Participant currentTrader = xfeSessionModule.onBehalfTrader.get();
      if (currentTrader != null && !shortcutTraders.get().isEmpty()) {
         if (!shortcutTraders.get().stream().anyMatch(participant -> Objects.equals(currentTrader.id, participant.id) && Objects.equals(currentTrader.ib, participant.ib))) {
            onBehalfTrader.setValue(shortcutTraders.get().stream().findFirst().orElse(null));
         }
      }
   }

   private void synchronizeLinelist() {
      logger.info("traderFirmMap loaded - synching linelist");
      ObservableList<LineList> linelist = getLinelist().get();

      List<LineList> newList = new ArrayList<>(linelist.size());
      linelist.stream().forEach(lineList -> {
            lineList.getItems().removeIf(participant -> {
               boolean ret = !xfeSessionModule.traderFirmMap.isTraderCanOnBehalfof(participant.getId(), participant.ib);
               if (ret)
                  logger.info("Removed trader {} from linelist due to missing OnBehalf permissions", participant);
               return ret;
            });

            lineList.getItems().stream().forEach(participant -> participant.displayName =
               xfeSessionModule.traderFirmMap.getUserFullName(participant.id));
            newList.add(lineList);
         }
      );

      getLinelist().get().setAll(newList);

      shortcutTraders.get().removeIf(participant -> !xfeSessionModule.traderFirmMap.isTraderCanOnBehalfof(participant.id,participant.ib));
      Participant participant = xfeSessionModule.onBehalfTrader.get();
      if (participant != null ) {
         if (!xfeSessionModule.traderFirmMap.isTraderCanOnBehalfof(participant.id, participant.ib))
            onBehalfTrader.setValue(shortcutTraders.get().stream().findFirst().orElse(null));
      }
   }

   private synchronized void openLineList() {
      if (xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker() && xfeSessionModule.traderFirmMap != null) {
         if (stage == null) {
            linelistTreeTable = new LinelistTreeTable(this);
            stage = new LinelistStage(layoutModule,
               xfeSessionModule,
               buttonLinelistEditorClone,
               this, linelistTreeTable);
         }
         if (!stage.isShowing() && xfeSessionModule.traderFirmMap.readyPropertyRO.get()) {
            stage.show();
         }
         selectRow(onBehalfTrader.get());
         stage.toFront();
      }
   }

   private synchronized void closeLineList() {
      if (xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker()) {
         if (stage != null && stage.isShowing()) {
            stage.hide();
            stage = null;
         }
      }
   }

   private void reSelectTrader(){
      checkAvailShortcut();
      selectTab(onBehalfTrader.get());
      selectRow(onBehalfTrader.get());
   }

   private void selectRow(Participant par) {
      if (par != null && Objects.equals(par.getId(), xfeSessionModule.getUnderlyingSession().getLoggedOnUserId())) return;
      if (linelistTreeTable != null) {
         linelistTreeTable.select(par);
      }
   }

   private void selectTab(Participant par) {
      if (par != null) {
         List<Tab> tabs = shortcutPane.getTabs();
         for (Tab tab : tabs) {
            Object o = tab.getUserData();
            if (o != null && o instanceof Participant) {
               Participant new_name = (Participant) o;
               if (Objects.equals(new_name.getId(),par.getId()) && Objects.equals(par.ib, new_name.ib) && new_name.getGroup()!=null && par.getGroup()!=null && Objects.equals(new_name.getGroup().getUuid(), par.getGroup().getUuid())) {
                  shortcutPane.select(tab);
                  return;
               }
            }
         }
      }

      Fx.delay(100L, () -> shortcutPane.getSelectionModel().select(null));
   }

   private boolean checkAvailShortcut() {
      boolean isEmpty = shortcutPane.getTabs().isEmpty();
      if (isEmpty) {
         shortcutPane.getTabs().add(showDragHintTab);
      }

      if (shortcutPane.getTabs().contains(showDragHintTab) && displayLinelist != null)
         displayLinelist.set(true);

      return !isEmpty;
   }

   private final ListenerTracker tracker = new ListenerTracker();
   private final XfeTabPane shortcutPane = new XfeTabPane(false,true);
   private final ToggleButton showLinelistButton = new ToggleButton() {
      {
         setId("xfe-iswap-linelist-btnid");
         getStyleClass().add("xfe-icon-show-linelist");
         XfeTooltipFactory.setTooltip(this);
      }
   };
   private final ToggleButton showLinelistShortcutButton = new ToggleButton() {
      {
         setId("xfe-iswap-linelist-sc-btnid");
         getStyleClass().add("xfe-icon-show-linelistshortcut");
         XfeTooltipFactory.setTooltip(this);
      }
   };
   private final ToggleButton buttonLinelistEditorClone = new ToggleButton() {{  //same node can't be added to more than two control.  need to clone one.
      setId("xfe-iswap-linelist-editor-btnid");
      getStyleClass().add("toggle-button");
      getStyleClass().add("xfe-icon-settings");
      setMaxSize(35.0, 20.0);
      XfeTooltipFactory.setTooltip(this);
   }};
   private final Tab showDragHintTab = new Tab() {{
      Label label = new Label("Drag Traders from Line list here");
      label.setTextAlignment(TextAlignment.CENTER);
      label.setPrefWidth(300);
      label.setMinHeight(36);
      setGraphic(label);
      setClosable(false);
   }};
   ObjectProperty<Participant> onBehalfTrader;
   boolean isUpdatingLineList;
   private final InvalidationListener shortcutPaneSelectionLis = new InvalidationListener() {

      @Override
      public void invalidated(Observable arg0) {
         if (isUpdatingLineList) {
            return;
         }

         Tab selectedTab = shortcutPane.getSelectionModel().getSelectedItem();

         if (selectedTab != null && selectedTab.getUserData() != null) {
            Participant par = (Participant) selectedTab.getUserData();
            par.eventSource = shortcutPane;
            if (!par.equals(onBehalfTrader.get())) {
               onBehalfTrader.set(par);
            }
         }
      }
   };
   private Dictionary myTraderFirmMap;
   private ObjectProperty<ObservableList<Participant>> shortcutTraders;
   private DragDropHandler dragDropHandler;
   private PrefsViewFactory lineListPrefsViewFactory;
   private LinelistStage stage;
   private LinelistTreeTable linelistTreeTable;
   EventHandler<KeyEvent> keyPressLis = keyEvt -> {
      if (showLinelistButton.isSelected()) {

         KeyCode kCode = keyEvt.getCode();
         if (kCode.isFunctionKey() &&
            !keyEvt.isShiftDown() &&
            !keyEvt.isControlDown() &&
            !keyEvt.isAltDown() &&
            !keyEvt.isMetaDown()) {
            LineList lineList;
            XfeItem selectedItem = linelistTreeTable.getSelectionModel().getSelectedItem().getValue();
            if(selectedItem instanceof Participant){
               lineList = (LineList) (((Participant) selectedItem).getGroup());
            }else{
               lineList = (LineList)selectedItem;
            }
            List<Participant> pars = lineList.getItems();
            for (Participant par : pars) {
               if (par.getHK() != null && par.getHK().equalsIgnoreCase(kCode.getName())) {
                  linelistTreeTable.select(par);
                  break;
               }
            }
         }
      }
   };
   private final InvalidationListener linelistLis = arg0 -> {
      if (myTraderFirmMap == null) {
         logger.warn("Unable to process event: Linelist disabled.");
         return;
      }
      if (showLinelistButton.isSelected()) {
         openLineList();
      } else {
         closeLineList();
      }
   };
   private final InvalidationListener onBehalfTraderListener = arg0 -> {
      if (onBehalfTrader.get() != null) {
         Participant par = onBehalfTrader.get();
         logger.info("Switching on-behalf-of trader to : {}...", par.toFullString());
         xfeSessionModule.onBehalfTrader.set(par);
         xfeSessionModule.getUnderlyingSession().onBehalfTraderId.set(par.getId());  //put tradeId to be last updated.
         xfeSessionModule.getUnderlyingSession().onBehalfTraderIB.set(par.getSubTitle());
         logger.info("Switching done", par.toFullString());

         Fx.runLater(() -> {
               if (par.eventSource == shortcutPane) {
                  selectRow(par);
               } else if (par.eventSource == linelistTreeTable) {
                  selectTab(par);
               }
            }
         );
         if (stage != null) {
            stage.setOnHalfTraderId(par.getId());
         }
      } else {
         if (stage != null) {
            stage.setOnHalfTraderId(xfeSessionModule.getUnderlyingSession().getLoggedOnUserId());
         }
         xfeSessionModule.onBehalfTrader.set(null);
         xfeSessionModule.getUnderlyingSession().onBehalfTraderId.set(null);  //put tradeId to be last updated.
         xfeSessionModule.getUnderlyingSession().onBehalfTraderIB.set(null);
      }
   };
   private BooleanProperty displayLinelist;
   private final InvalidationListener linelistInvalidListener = new InvalidationListener() {

      @Override
      public void invalidated(Observable arg0) {
         logger.info("line list changed. updating the treetable view");
         if(linelistTreeTable!=null){
            linelistTreeTable.rebuildTree();
         }
         Fx.runLater(()->reSelectTrader());
      }
   };
   private final InvalidationListener shortcutInvalidationListener = new InvalidationListener() {
      @Override
      public void invalidated(Observable observable) {
         shortcutPane.getTabs().clear();
         ObservableList<Participant> lists = shortcutTraders.get();
         List<Tab> toBeAdded = new ArrayList<>(lists.size());
         toBeAdded.addAll(lists.stream().map(SubtitleTab::new).collect(Collectors.toList()));
         shortcutPane.getTabs().setAll(toBeAdded);
         Fx.runLater(()->reSelectTrader());
      }
   };
   private BooleanProperty displayLinelistShortcut;
   private final InvalidationListener linelistShortcutLis = new InvalidationListener() {

      @Override
      public void invalidated(Observable arg0) {
         boolean isShortcutSelected = displayLinelistShortcut.get();

         if (isShortcutSelected) {
            watchlistModule.switchPane(shortcutPane);
         } else {
            watchlistModule.switchPane(null);
         }

         if (isShortcutSelected) {
            checkAvailShortcut();
         }
      }
   };
}
