package xfe.icap.modules.watchlist;

import com.nomx.domain.types.InstrumentKey;
import com.nomx.persist.PersistantName;
import com.nomx.persist.Types.Rect;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpRfq;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.icap.modules.actionsui.ActionsUIModule;
import xfe.icap.modules.actionsui.ConfigActionsUIModule;
import xfe.icap.modules.datacontext.DataContextModule;
import xfe.icap.modules.prefsview.PrefsViewsModule;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settings.SettingsUIModule;
import xfe.icap.types.IcapRfqWatchlist;
import xfe.icap.types.IcapSecBoardTrim2Watchlist;
import xfe.layout.FxAbstractLayout;
import xfe.layout.LayoutManager;
import xfe.module.Module;
import xfe.module.SchedulerModule;
import xfe.modules.actionsui.ActionButton;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.modules.appcontext.FxContext;
import xfe.modules.localsettings.LocalSettingsModule;
import xfe.modules.session.SessionModule;
import xfe.modules.session.SessionScopeModule;
import xfe.modules.watchlist.InstrumentsView.Presenter;
import xfe.types.SecBoard;
import xfe.types.Watchlist;
import xfe.ui.TriStateButton;
import xfe.ui.notifications.ModalAlertModule;
import xfe.ui.tabpane.XfeTabPane;
import xfe.util.Pair;
import xfe.util.UiUtil;
import xfe.util.XfeAction;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.amp.AMP;
import xstr.session.ObservableReplyRow;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xstr.session.QueryFeed;
import xstr.session.QueryReplyRow;
import xstr.types.OrderSide;
import xstr.util.*;
import xstr.util.concurrent.Future;

import java.util.*;

import static xfe.util.Constants.STYLE_HIVIS;

@Module.Autostart
public class WatchlistModule extends SessionScopeModule {
   public static final Logger logger = LoggerFactory.getLogger(WatchlistModule.class);
   static boolean includeWatchlistMineYours = true;
   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public DataContextModule dataContextModule;
   @ModuleDependency
   public SchedulerModule schedulerModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   private final ListChangeListener<ObservableReplyRow> itemsListener = new ListChangeListener<ObservableReplyRow>() {
      @Override
      public void onChanged(Change<? extends ObservableReplyRow> change) {

         // We handle in here rows that are added to the Main Watchlist
         // 1. If a generated rfs is added for a parent that was previously selected and removed
         // Then we need to select it.
         // 2. If an rfq's parent is added back for a generated rfs that was selected (since
         // the rfs session ended)
         // Then we need to select it.
         if (removedRSec.get() == null) return;
         boolean selected = false;
         while (change.next()) {
            for (ObservableReplyRow addedRow : change.getAddedSubList()) {
               String addedSecCode = addedRow.getString(AmpIcapSecBoardTrim2.secCode);
               Pair<String, String> secBoard = Pair.create(addedSecCode, addedRow.getString(AmpIcapSecBoardTrim2.boardId));
               if (!selected) {
                  String removed = removedRSec.get();
                  if (removed.contains(addedSecCode) || addedSecCode.contains(removed)) {
                     selected = true;
                     logger.trace("Selecting {}", secBoard);
                     selectOrDefer(secBoard.getKey(), secBoard.getValue());
                     removedRSec.setValue(null);
                  }
               }

               if (!xfeSessionModule.getUnderlyingSession().isLoggedOn())
                  break;
               xfeSessionModule.secBoards.get().updateStaticInfo(addedRow);
            }
         }
      }
   };
   @ModuleDependency
   public ActionsUIModule actionsUIModule;
   @ModuleDependency
   public ConfigurationModule settingsModule;
   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public ModalAlertModule modalAlertModule;
   @ModuleDependency
   public LayoutManager<Node> layoutManagerModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public SettingsUIModule settingsUIModule;
   private final InvalidationListener miniWatchlistVisibleListener = new InvalidationListener() {

      @Override
      public void invalidated(Observable arg0) {
         if (instrumentsPane != null && watchlistStage != null) {
            watchlistStage.showWatchlist(settingsUIModule.getData().displayMiniWatchlistProperty().get());
         }
      }
   };
   @ModuleDependency
   public PrefsViewsModule prefsViewsModule;
   @ModuleDependency
   public ConfigActionsUIModule configActionsUIModule;
   @ModuleDependency
   public TradesFlashModule tradesFlashModule;
   @ModuleDependency
   public FxContext jfxContextModule;
   @ModuleDependency
   public LocalSettingsModule localSettingsModule;

   private class InstrumentsViewPresenter implements Presenter {
      @Override
      public void onSelectSpec(WatchlistSpec_v2 watchlistSpec) {
         //System.out.println("populating from onSelectSpec");
         initCurrentSpec(watchlistSpec);
      }

      void initCurrentSpec(WatchlistSpec_v2 watchlistSpec) {

         //System.out.println("populating from initCurrentSpec for " + watchlistSpec.getTitle());
         if (xfeSessionModule == null || !xfeSessionModule.getUnderlyingSession().isLoggedOn() || updatingWatchlistTab.get()) {
            return;
         }

         currentWatchlistSpec = watchlistSpec;
         //switching tabing

         clearingFormerTab = true;
         currentWatchlist.getSpecWatchedSecboards().clear();
         clearingFormerTab = false;
         xfeSessionModule.secBoards.get().ready().onSuccess(new Fun1<Boolean, Void>() {

            @Override
            public Void call(Boolean dummy) {
               removedRSec.setValue(null);
               if (watchlistSpec == currentWatchlistSpec && watchlistSpec != null)
                  watchlistSpec.populateInto(currentWatchlist, xfeSessionModule.secBoards.get());
               return null;
            }

         });

         // Setting the current selected watchlist flag to identify when loading PrefsViewsModule->TabEditor.
         if(watchlistSpec!=null) {
            configurationModule.getWatchlists().forEach(wl -> {
               wl.setSelectedInTabListView(wl.getId().equals(watchlistSpec.getId()));
            });
         }
      }
   }

   public WatchlistModule() {
      buttonWatchHighlight.setText("H");
      buttonWatchHighlight.setId("xfe-iswap-settings-tg-highlight");
      XfeTooltipFactory.setTooltip(buttonWatchHighlight);
      buttonWatchHighlight.getStyleClass().add("xfe-icon-highlight");
      GridPane.setConstraints(buttonWatchHighlight, 1, 2, 1, 1, HPos.LEFT, VPos.TOP, Priority.ALWAYS, Priority.ALWAYS);
      buttonWatchHighlight.setMaxSize(35.0, 20.0);

//      removedRSec.addListener((observable, oldValue, newValue) -> {
//            if (oldValue == null) {
//
//               logger.trace("Selecting {}", newValue);
//               selectOrDefer(newValue, null);
//               removedRSec.setValue(null);
//
//
//            }
//         }
//      );
   }

   public StackPane getSwitchPane() {
      return instrumentsPane.getSwitchPane();

   }

   public Node getUIRoot() {
      if (instrumentsPane != null) {
         return instrumentsPane.getRootElement();
      } else {
         return null;
      }
   }

   Watchlist getRfqWatchlist() {
      return rfqWatchlist;
   }

   FlashableTab getRfqTab() {
      if (rfqTab == null) {
         rfqWatchSpec = new WatchlistSpec_v2("RFQ", "rfq", new com.nomx.persist.watchlist.WatchlistSpec_v2.Security[0]);
         rfqWatchSpec.isRfqOnly = true;
         rfqTab = new FlashableTab(rfqWatchSpec, xfeSessionModule);
      }
      return rfqTab;
   }

   public ObservableList<ObservableReplyRow> getExtraWatchlist() {
      return extraWatchList;
   }

   public ReadOnlyObjectProperty<WatchlistSpec_v2> getActiveSpec() {
      return activeSpecProperty;
   }

   public ObservableSet<SecBoard> getExtraSecBoardList() {
      return extraSecBoardList;
   }

   void setMiniWatchlistPTView(TableView<ObservableReplyRow> miniWatchlistPTView) {
      watchlistStage.setActiveTableViewProperty(miniWatchlistPTView);
   }

   public void setTabFlash(long timeToStop) {
      if (rfqTab != null) {
         rfqTab.setFlash(timeToStop);
      }
   }

   public void switchPane(XfeTabPane pane) {
      instrumentsPane.switchPane(pane);
   }

   @Override
   public Future<Void> startModule() {
//      xfeSessionModule.getUnderlyingSession().addPreLogoffTask(preLogoffAction);

      rfqWatchlist = new IcapRfqWatchlist(xfeSessionModule);
      currentWatchlist = new IcapSecBoardTrim2Watchlist(xfeSessionModule,
         extraSecBoardList,
         extraWatchList,
         selectionContextModule,
         removedRSec);
      currentWatchlist.getItems().addListener(itemsListener);
      buttonWatchHighlight.setOnStateChangeHandler(buttonWatchHighlightAction);

      fullHighlightedList = configurationModule.getParametersStorage().getList(PersistantName.InstrumentsHighlightData, InstrumentKey.class, FXCollections.observableArrayList());
      halfHighlightedList = configurationModule.getParametersStorage().getList(PersistantName.InstrumentsHighlightData2, InstrumentKey.class, FXCollections.observableArrayList());

      final ObservableList<WatchlistSpec_v2> watchLists = configurationModule.getWatchlists();
      watchLists.addListener((ListChangeListener.Change<? extends WatchlistSpec_v2> c) -> {
         while (c.next()) {
            if (c.getAddedSize() > 0) {
               List<WatchlistSpec_v2> instrSpecs = (List<WatchlistSpec_v2>) c.getAddedSubList();
               Fx.runLater(() -> {
                  if (instrumentsPane.getExtremeAddRemove()) {
                     instrumentsPane.createTabs(null);
                  }
                  // Implementing selection of tab, based on current section in settings->tabeditor->listview selection.
                  Optional<WatchlistSpec_v2> currentTab = instrSpecs.stream().filter(WatchlistSpec_v2::isSelectedInTabListView).findFirst();
                  currentTab.ifPresent(wl->instrumentsPane.selectTab(wl.getId()));
               });
            }
         }
      });



      tracker.disposes(Fx.bind(watchlistSpecList, settingsModule.getWatchlists()));
      tracker.addListener(watchlistSpecList, (Observable arg0) -> {
         // TODO: Handle buttonGroupEditor alternate implementation.
         if (/*buttonGroupEditor.getToggleGroup().getSelectedToggle() != buttonGroupEditor &&*/ !InstrumentsPane.getInternalSpecUpdate()) {
            // Refresh InstrumentsPane (can happen through the preset diffs or through Revert to a Preset)
            WatchlistSpec_v2 activeSpec = activeSpecProperty.get() == null ? (watchlistSpecList.isEmpty() ? null : watchlistSpecList.get(0)) : activeSpecProperty.get();
            instrumentsPane.createTabs(watchlistSpecList);
            instrumentsPane.selectTab(activeSpec.id);
         }
      });

      FeedAggregator<ObservableReplyRow> tradeInfoAggregator = new FeedAggregator<>(
         AMP.qREP("secBoardTradeInfoRep"), new ObservableRowFactory());
      QueryFeed tradeInfoFeed = xfeSessionModule.getUnderlyingSession().getFeedSource(AMP.qREQ("secBoardTradeInfoReq"));
      tracker.addFeedListener(tradeInfoFeed, tradeInfoAggregator);

      Rect position = settingsUIModule.getData().applicationPositionProperty().get();
      Stage applicationStge = sessionModule.fxApplicationModule.getStage();
      if (Double.isNaN(position.getX())) {
         position.setHeight(settingsUIModule.getData().applicationHeightProperty().get());
         position.setWidth(FxApplicationModule.MAIN_STAGE_WIDTH);
      }
      UiUtil.setPosition(applicationStge, position);
//      ZoomableDecorator.setHeight(applicationStge, height);

//      ZoomableDecorator decorator = ZoomableDecorator.getZoomableDecorator(applicationStge);
//      if(decorator==null) {
      Fx.runLater(() -> {
         tracker.addListener(applicationStge.heightProperty(), observable -> savePostion(settingsUIModule.getData().applicationPositionProperty(), applicationStge));
         tracker.addListener(applicationStge.widthProperty(), observable -> savePostion(settingsUIModule.getData().applicationPositionProperty(), applicationStge));
         tracker.addListener(applicationStge.xProperty(), observable -> savePostion(settingsUIModule.getData().applicationPositionProperty(), applicationStge));
         tracker.addListener(applicationStge.yProperty(), observable -> savePostion(settingsUIModule.getData().applicationPositionProperty(), applicationStge));
      });

      createFilters();

      ActionButton miniWatchListButton = new ActionButton() {{
         setId("xfe-show-watchlist-button");
         getStyleClass().add("xfe-icon-watchlist");
         setText("Mini\nWatchlist");
         setId("xfe-iswap-btn-action-watchlist");
         XfeTooltipFactory.setTooltip(this);
      }};
      actionsUIModule.addCustomButton(3, miniWatchListButton);
      tracker.addListener(miniWatchListButton.selectedProperty(), observable -> settingsUIModule.getData().displayMiniWatchlistProperty().set(miniWatchListButton.selectedProperty().get()));

      actionsUIModule.addAction(4, interrogationAction);
      interrogationAction.setDisable(true);
      createInstrumentsView(tradeInfoAggregator.items);
      tracker.disposes(Fx.addWeakListener(selectionContextModule.selectionContextProperty(), (obsContext, oldContext, newContext) -> interrogationAction.setDisable(newContext == null || !isImpliedSelection(newContext))));

      ObjectProperty<InstrumentKey> selectedInstrumentKey = settingsModule.getData().selectedInstrumentKeyProperty();
      InstrumentKey selectedInstrumentKeyValue = selectedInstrumentKey.get();

      if (selectedInstrumentKeyValue != null) {
         logger.debug("selecting instrument(from workspace): {}", selectedInstrumentKey);
         instrumentsPane.selectTabAndRow(selectedInstrumentKeyValue.getTabId(),
            selectedInstrumentKeyValue.getSecCode(), AmpIcapSecBoardTrim2.secCode,
            null, false);
      } else {
         Fx.runLater(() -> instrumentsPane.selectTab(null));
      }

      InvalidationListener instrListener = dummy -> {
         WatchlistSpec_v2 wl = activeSpecProperty.getValue();

         if (wl == null) return;

         UUID tabId = wl.getId();
         String secCode = instrumentsPane.querySecCodeProperty().get();
         String boardId = instrumentsPane.queryBoardIdProperty().get();

         if (tabId == null || secCode == null || boardId == null || secCode.isEmpty() || boardId.isEmpty()) return;

         selectedInstrumentKey.set(InstrumentKey.create(activeSpecProperty.getValue().getId(),
            instrumentsPane.querySecCodeProperty().get(),
            instrumentsPane.queryBoardIdProperty().get()));

      };

      tracker.addListener(activeSpecProperty, instrListener);
      tracker.addListener(instrumentsPane.querySecCodeProperty(), instrListener);
      tracker.addListener(instrumentsPane.queryBoardIdProperty(), instrListener);

      if (logger.isDebugEnabled()) {
         tracker.addListener(settingsUIModule.getData().displayMiniWatchlistProperty(), observable -> logger.debug("mini watchlist visible is {}", settingsUIModule.getData().displayMiniWatchlistProperty().get()));
      }
      initializeWatchlistStage();
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      extraSecBoardList.clear();
      extraWatchList.clear();
      if (rfqTab != null) {
         rfqTab.dispose();
         rfqTab = null;
         rfqWatchSpec = null;
         rfqWatchlist.dispose();
         rfqWatchlist = null;
      }
      tracker.rollback();

      toolbarContainer.getChildren().clear();
      refs.clear();
      if (currentWatchlist != null) {
         currentWatchlist.getSpecWatchedSecboards().clear();
         currentWatchlist.getItems().removeListener(itemsListener);
         currentWatchlist = null;
      }

      buttonWatchHighlight.setOnStateChangeHandler(null);

      actionsUIModule.removeAction(interrogationAction);
      disposeInstrumentsView();
      disposeFilters();
      watchlistSpecList = FXCollections.observableArrayList();
      currentWatchlistSpec = null;

      StyleTogglePropertyFactory.clear();
      watchlistStage = null;

//      xfeSessionModule.getUnderlyingSession().removePreLogoffTask(preLogoffAction);
      return Future.SUCCESS;
   }

   private void disposeFilters() {
      if (instrumentsFilters != null) {
         instrumentsFilters = null;
      }
   }

   private void savePostion(ObjectProperty<Rect> property, Stage stage) {
      Rect newPosition = new Rect(stage.getX(), stage.getY(), stage.getWidth(), stage.getHeight());
      property.set(newPosition);
      logger.debug("{}'s positioni is set to {}", stage.getTitle(), newPosition);
   }

   private void createFilters() {
      instrumentsFilters = new InstrumentsFilters(xfeSessionModule, configurationModule);
   }

   private void createInstrumentsView(ObservableList<ObservableReplyRow> tradeInfos) {
      disposeInstrumentsView();
      instrumentsPane = new InstrumentsPane(
         schedulerModule.scheduler(),
         tradeInfos,
         selectionContextModule,
         dataContextModule,
         xfeSessionModule,
         tradesFlashModule,
         this,
         activeSpecProperty,
         layoutManagerModule,
         interrogationAction,
         selectionContextModule.getOnDoubleClicked(),
         settingsUIModule.getData(),
         configActionsUIModule,
         instrumentsFilters,
         buttonWatchHighlight,
         toolbarContainer,
         tracker,
         watchlistSpecList,
         fullHighlightedList,
         halfHighlightedList,
         configurationModule);

      instrViewPresenter = new InstrumentsViewPresenter();
      instrumentsPane.setItems(currentWatchlist);

      tracker.disposes(Fx.addWeakListener(activeSpecProperty, dummy -> instrViewPresenter.onSelectSpec(activeSpecProperty.get())));
      instrumentsPane.selectFirstRow();

      instrViewPresenter.initCurrentSpec(activeSpecProperty.get());


      instrumentsPane.getRootElement().setId("xfe-watchlist-view");
      layoutModule.addView(instrumentsPane.getRootElement());

      tracker.addListener(instrumentsPane.gridContextProperty(), (observableValue, oldSelectionContext, newSelectionContext) -> {
         logger.trace("instrumentsPane.gridContextProperty() {}", newSelectionContext);
         if (clearingFormerTab) {
            logger.trace("clearingFormerTab is TRUE - returning");
            return;
         }
         if (newSelectionContext.grid == GridType.Rfq) {
            selectionContextModule.setSelectionContext(newSelectionContext);
         }
         if (isActive || newSelectionContext.row != null) {
            isActive = true;
            selectionContextModule.setSelectionContext(newSelectionContext);
         }
      });

      // Listening on other grids' selection change
      tracker.disposes(Fx.addWeakListener(selectionContextModule.selectionContextProperty(), (observableVal, oldVal, newVal) -> {
         logger.trace("selectionContextModule.selectionContextProperty() {}", newVal);
         if (newVal.grid != GridType.Watchlist && isActive) {
            // We need to reset our selection
            isActive = false;
            logger.debug("isActive is set to false");
            if (instrumentsPane != null) {
               instrumentsPane.clearViewSelection();
               instrumentsPane.setGridContext(null);
            }
         }
      }));

      instrumentsPane.attachTabSelectorAccelerators();
//      Fx.delay(1500L,()->instrumentsPane.scrollToTab());
   }

   private boolean isImpliedSelection(SelectionContext ctx) {
      if (ctx.grid == GridType.Watchlist && ctx.field != null) {
         boolean isBidColumn = ctx.field.hasEqualAccess(AmpIcapSecBoardTrim2.bidPrice);
         boolean isOfferColumn = ctx.field.hasEqualAccess(AmpIcapSecBoardTrim2.offerPrice_d);
         boolean isColumnMerged = settingsUIModule.getData().mergeImpliedMainWatchlistProperty().get();
         if (isBidColumn && InstrumentsFilters.isImpliedBid.accept(ctx.row).get())
            return true;
         if (isOfferColumn && InstrumentsFilters.isImpliedOffer.accept(ctx.row).get())
            return true;
         if (ctx.row.getAsn(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d) != null && (ctx.field.hasEqualAccess(AmpIcapSecBoardTrim2.nLevelImpBidPrice_d) || (isColumnMerged && isBidColumn)))
            return true;
         return ctx.row.getAsn(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d) != null && (ctx.field.hasEqualAccess(AmpIcapSecBoardTrim2.nLevelImpOfferPrice_d) || (isColumnMerged && isOfferColumn));
      }

      return false;
   }

   private void initializeWatchlistStage() {
      watchlistStage = new WatchlistStage(localSettingsModule.getHiVis() ? STYLE_HIVIS : "", tracker);
      ObjectProperty<Rect> positionProperty = configurationModule.getParametersStorage().get(
         PersistantName.MiniWatchlistPosition,
         Rect.class,
         new Rect(Double.NaN, Double.NaN, 0, 400));
      watchlistStage.init(
         layoutManagerModule,
         xfeSessionModule,
         tradesFlashModule,
         selectionContextModule,
         settingsUIModule,
         instrumentsFilters,
         instrumentsPane,
         watchlistSpecList,
         sessionModule.connectedProperty(),
         modalAlertModule, configurationModule);


      Rect position = positionProperty.get();

      if (position != null) {
         watchlistStage.setX(position.getX());
         watchlistStage.setY(position.getY());
         watchlistStage.setHeight(position.getHeight());
//         ZoomableDecorator.setHeight(watchlistStage, position.getHeight());
         watchlistStage.contractWatchlist();
      } else {
//         watchlistStage.setHeight(400.0);
//         ZoomableDecorator.setHeight(watchlistStage,400D);
      }

      InvalidationListener positionListener = (observableValue) -> {
         positionProperty.set(new Rect(watchlistStage.getX(), watchlistStage.getY(), 0, watchlistStage.getHeight()));
         watchlistStage.appContainer.setPrefHeight(watchlistStage.getHeight());
      };
      tracker.addListener(watchlistStage.xProperty(), positionListener);
      tracker.addListener(watchlistStage.yProperty(), positionListener);

      tracker.addListener(watchlistStage.heightProperty(), positionListener);
      tracker.addListener(settingsUIModule.getData().displayMiniWatchlistProperty(), miniWatchlistVisibleListener);
      miniWatchlistVisibleListener.invalidated(null);
   }

   private void disposeInstrumentsView() {
      instrViewPresenter = null;

      if (instrumentsPane == null) return;

      layoutModule.removeView(instrumentsPane.getRootElement());
      instrumentsPane.dispose();
      instrumentsPane = null;

      watchlistStage.close();
   }

   public Future<Boolean> selectOrDefer(String secCode, String boardId) {
      if (instrumentsPane == null) {
         return Future.valueOf(false);
      }
      return instrumentsPane.selectOrDefer(secCode, boardId);
   }

   public TableView<ObservableReplyRow> createInstrumentTableView(boolean forPopup, ListenerTracker listenerTracker) throws Exception {
      return createInstrumentTableView(forPopup, false, null, listenerTracker);
   }

   TableView<ObservableReplyRow> createInstrumentTableView(boolean forPopup, boolean forPriceTightness, Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>> rowFactory, ListenerTracker listenerTracker) throws Exception {
      if (instrumentsPane != null) {
         return instrumentsPane.generateInstrumentTableView(forPopup, forPriceTightness, rowFactory, listenerTracker);
      } else {
         throw new Exception("InstrumentPane is not avail");
      }
   }

   public Future<QueryReplyRow> retrieveSecBoardTrim2(String boardId, String secId) {
      List<ObservableReplyRow> list = currentWatchlist.getItems();
      for (ObservableReplyRow row : list) {
         String code = row.getString(AmpIcapSecBoardTrim2.secCode);
         String board = row.getString(AmpIcapSecBoardTrim2.boardId);
         if (secId.equals(code) && boardId.equals(board)) {
            return Future.valueOf(row);
         }
      }
      return xfeSessionModule.retrieveSecBoardTrim2(boardId, secId);
   }

   public void stopTabFlash() {
      if (rfqTab != null) rfqTab.stopFlash();
   }

   public void selectedRfq(String secCode) {
      instrumentsPane.selectTabAndRow(rfqWatchSpec.id, secCode, AmpRfq.parentSecCode, OrderSide.BUY, false);
      jfxContextModule.getStage().toFront();
   }

   void addTabView(TabViewPair tabView) {
      instrumentsPane.addTabView(tabView);
   }

   void removeTabView(TabViewPair tabView) {
      instrumentsPane.removeTabView(tabView);
   }

   void setPTInMiniWatchlist(boolean isPriceTightness, WatchlistSpec_v2 ActiveSpecInWatchlist) {
      if (watchlistStage != null) {
         watchlistStage.setPriceTightness(isPriceTightness, ActiveSpecInWatchlist);
      }
   }

   TableView<ObservableReplyRow> createMiniWatchlistTableViewForPT(ListenerTracker listenerTracker) throws Exception {
      if (watchlistStage != null) {
         return watchlistStage.createTableViewForPT(listenerTracker);
      } else {
         throw new Exception("WatchlistStage is not avail");
      }
   }

   private void preUninitializeContents() {
      tracker.rollback();
   }

   InstrumentsPane instrumentsPane;
   WatchlistStage watchlistStage;
   private final ArrayList<Object> refs = new ArrayList<>();
   private final ObservableSet<SecBoard> extraSecBoardList = FXCollections.observableSet(new HashSet<>());
   private final ObjectProperty<WatchlistSpec_v2> activeSpecProperty = new SimpleObjectProperty<>();
   private final ObservableList<ObservableReplyRow> extraWatchList = FXCollections.observableList(new ArrayList<>(20));
   /**
    * We are adding/removing all watchlist tabs. It triggers "tab selection" event. We do not want code to deal with "tab selection" during adding/removing tabs.
    */
   private final BooleanProperty updatingWatchlistTab = new SimpleBooleanProperty(false);
   private final StackPane toolbarContainer = new StackPane();
   private final StringProperty removedRSec = new SimpleStringProperty();
   private final TriStateButton buttonWatchHighlight = new TriStateButton();
   private final XfeAction interrogationAction = new XfeAction() {{
      getStyleClass().add("xfe-action-i-button");
      setText("Inter-\nrogate");
      setActionId("interrogate");
   }};
   private final ListenerTracker tracker = new ListenerTracker();
   private final Fun0Throws<Future<Void>> preLogoffAction = () -> {
      preUninitializeContents();
      return Future.SUCCESS;
   };
   private final EventHandler<ActionEvent> buttonWatchHighlightAction = new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent actionEvent) {
         instrumentsPane.toggleSelection(buttonWatchHighlight);
      }
   };
   private Watchlist currentWatchlist;
   private WatchlistSpec_v2 currentWatchlistSpec;
   private InstrumentsFilters instrumentsFilters;
   private boolean isActive;
   private ObjectProperty<ObservableList<InstrumentKey>> fullHighlightedList;
   private ObjectProperty<ObservableList<InstrumentKey>> halfHighlightedList;
   private ObservableList<WatchlistSpec_v2> watchlistSpecList = FXCollections.observableArrayList();
   private boolean clearingFormerTab;
   private InstrumentsViewPresenter instrViewPresenter;
   private Watchlist rfqWatchlist;
   private FlashableTab rfqTab;
   private WatchlistSpec_v2 rfqWatchSpec;
}
