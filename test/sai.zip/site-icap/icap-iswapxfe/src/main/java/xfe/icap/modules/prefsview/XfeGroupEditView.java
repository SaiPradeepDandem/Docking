package xfe.icap.modules.prefsview;

import com.nomx.persist.Searchable;
import xfe.ui.InitialisableView;
import xfe.ui.SearchTextField;
import xfe.ui.SearchableTreeView;
import xfe.ui.list.ReorderableListCell;
import xfe.ui.list.ReorderableListView;
import xfe.ui.list.XfeGroup;
import xfe.ui.list.XfeItem;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.Dragboard;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.VBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * This generic editor has three columns.
 * the left column is the list of XfeGroup. which contains a list of XfeItem
 * the middle column is a list of all available items.
 * the right column is the list of items which is contained in the selected group.
 * @author jiadin
 *
 * @param <T>
 * @param <S>
 * @param <I>
 */
public abstract class XfeGroupEditView<T extends XfeGroup<I>, S extends Searchable, I extends XfeItem> implements InitialisableView<Node> {
    private static final Logger logger = LoggerFactory.getLogger(XfeGroupEditView.class);

    @FXML protected VBox xfe_group_editor_root;
    @FXML protected Button add;
    @FXML protected ReorderableListView<T> xfeGroupListView;
    @FXML protected SearchTextField searchText;
    @FXML protected SearchableTreeView<S> xfeItemsTreeView;
    @FXML protected ReorderableListView<I> selectedListView;
    @FXML protected Label xfe_group_label;
    @FXML protected Label xfe_items_label;

    private final EventHandler<KeyEvent> keyPressedHandler = new EventHandler<KeyEvent>() {

        @Override
        public void handle(KeyEvent keyEvent) {
            XfeItem par = selectedListView.getSelectionModel().getSelectedItem();
            if (par != null && keyEvent.getCode() == ACTIVE_KEY) {
            }
        }
    };


   private final ChangeListener<T> groupSelectionChangedLis = new ChangeListener<T>() {

      @Override
      public void changed(ObservableValue<? extends T> paramObservableValue, T oldValue, T newValue) {
         if (newValue == null) {
            selectedGroupProp.set(null);
            selectedListView.setItems(FXCollections.emptyObservableList());
         } else {
            selectedListView.setItems(newValue.getItems());
            selectedGroupProp.set(newValue);
         }
      }
   };

    @SuppressWarnings("unchecked")
    protected StringProperty selectedGroupId = new SimpleStringProperty("null");
    protected ObjectProperty<T> selectedGroupProp = new SimpleObjectProperty<>();
    @SuppressWarnings("unchecked")
    protected static final StringProperty dummy = new SimpleStringProperty("null");

    protected XfeGroupEditView(){
    }


    private static final KeyCode ACTIVE_KEY=KeyCode.F;

    @FXML
    void initialize(){
        init();

        searchText.attach(xfeItemsTreeView);

        xfeGroupListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        setCellFactory();

        selectedListView.addEventFilter(KeyEvent.KEY_PRESSED, keyPressedHandler);

        xfeGroupListView.getSelectionModel().selectedItemProperty().addListener(groupSelectionChangedLis);
        T t = xfeGroupListView.getSelectionModel().selectedItemProperty().getValue();
        groupSelectionChangedLis.changed(null, null, t);

        add.setOnAction(arg0 -> createNewGroup());

        selectedListView.setOnDragOver(dragEvt -> {
            XfeGroup<? extends XfeItem> linelist = xfeGroupListView.getSelectionModel().getSelectedItem();
            if(linelist!=null){
                dragEvt.acceptTransferModes(TransferMode.ANY);  //Has to be any for reorderable cell to work.
            }
        });

        selectedListView.setOnDragDropped(dragEvt -> {
           /**
            * if there is items. it will be insert. it is being done ib {@link ReorderableListCell}
            */
           if(selectedListView.getItems().size()>0){
              return;
           }
            XfeGroup<I> group = xfeGroupListView.getSelectionModel().getSelectedItem();
            if (group == null) {
                logger.debug("please select a line list first.");
            } else {
                Dragboard db = dragEvt.getDragboard();
                if (db.hasContent(XfeItem.dataFormat)) {
                    @SuppressWarnings("unchecked")
                    List<I> selectedItems = (List<I>) db.getContent(XfeItem.dataFormat);
                    selectedListView.getItems().addAll(selectedItems);
                }
            }
           dragEvt.consume();
        });
    }

   protected void createNewGroup() {
      T group = createXfeGroup();
      xfeGroupListView.getItems().add(group);
      xfeGroupListView.getSelectionModel().select(group);
   }

   protected void init() {

    }

    protected abstract void setCellFactory() ;

    protected abstract T createXfeGroup();

    protected abstract void populate();
    protected abstract void applyChanges();
    //protected abstract boolean isModified();

    @Override
    public Node getRootElement() {
        return xfe_group_editor_root;
    }

    @Override
    public void requestFocus() {
        // TODO Auto-generated method stub

    }

    @Override
    public void initialise() {
        populate();
    }

//    @Override
//    public void uninitialise(Runnable finishOperation, Runnable unfinishedOperation) {
//        // TODO Auto-generated method stub
//
//    }

    public void dispose() {
        selectedGroupProp.set(null);
        selectedListView.removeEventFilter(KeyEvent.KEY_PRESSED, keyPressedHandler);
        xfeGroupListView.getSelectionModel().selectedItemProperty().removeListener(groupSelectionChangedLis);
        add.setOnAction(null);
        selectedListView.setOnDragOver(null);
        selectedListView.setOnDragDropped(null);
        xfeGroupListView.setCellFactory(null);
        selectedListView.setCellFactory(null);
    }
}
