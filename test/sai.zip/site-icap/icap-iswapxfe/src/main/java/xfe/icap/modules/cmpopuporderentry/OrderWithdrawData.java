package xfe.icap.modules.cmpopuporderentry;

import xstr.types.OrderSide;

import java.math.BigDecimal;

public class OrderWithdrawData {
   public String getSecCode() {
      return secCode;
   }

   public OrderWithdrawData(String secCode, BigDecimal cmPrice, OrderSide side, boolean autoWithdraw) {
      this.secCode = secCode;
      this.cmPrice = cmPrice;
      this.side = side;
      this.autoWithdraw = autoWithdraw;
   }

   public BigDecimal getCmPrice() {
      return cmPrice;
   }

   public boolean getAutoWithdraw() {
      return autoWithdraw;
   }

   public OrderSide getSide() {
      return side;
   }

   private String secCode;
   private BigDecimal cmPrice;
   private OrderSide side;
   private boolean autoWithdraw;
}
