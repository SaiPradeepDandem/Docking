package xfe.icap.modules.settings;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nomx.persist.watchlist.WatchlistSpec_v2.Security;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.ui.GenericView;

public class PresetNotificationView implements GenericView<Parent> {
	static final Logger logger = LoggerFactory.getLogger(PresetNotificationView.class);
	static final Security RemoveTabSec = new Security(null, "REMOVE EMPTY TAB");

	private VBox rootNode;
	private final StringProperty caption = new SimpleStringProperty();
	private final ButtonBase okBtn = new Button("OK");
	private final ButtonBase closeBtn = new Button("Remind me later");

	private final ScrollPane clientView = new ScrollPane() {{
		getStyleClass().add("xfe-client-view");
	}};

	private final DoubleProperty width = new SimpleDoubleProperty(this, "width", 420);
	private final DoubleProperty height = new SimpleDoubleProperty(this, "height", 380);

	private final SettingsChange changeTree;

	public PresetNotificationView(SettingsChange changeTree) {
		this.changeTree = changeTree;
	}

	@Override
	public final Parent getRootElement() {
		if (rootNode == null) {
			Label label = new Label();
			label.textProperty().bind(caption);
			label.getStyleClass().add("xfe-title");

         VBox vbox = new VBox();
         vbox.maxWidthProperty().bind(width);
         vbox.minWidthProperty().bind(width);
         vbox.maxHeightProperty().bind(height);
         vbox.minHeightProperty().bind(height);
         vbox.setFillWidth(true);
			vbox.getChildren().setAll(label, clientView);
         VBox.setVgrow(clientView, Priority.ALWAYS);

         clientView.prefWidthProperty().bind(width.subtract(10.f));
			clientView.setMaxWidth(Region.USE_PREF_SIZE);

			generateChangeTable();
			this.rootNode = vbox;
		}
		return rootNode;
	}

	private void generateChangeTable() {
		ObservableList<SettingsChange> changeList = FXCollections.observableArrayList();
		changeList.add(changeTree);
		addSomething(changeList, changeTree);

		TableView<SettingsChange> table = new TableViewHeaderUnmovable<SettingsChange>() {{
			this.getColumns().addAll(SettingsChangeColumns.createApplyColumn(),
					SettingsChangeColumns.createDescriptionColumn(),
					SettingsChangeColumns.createMineTheirColumn(true),
					SettingsChangeColumns.createMineTheirColumn(false));
			this.setItems(changeList);
			this.getStyleClass().add("xfe-diff-table-view");
		}};

		clientView.setFitToWidth(true);
		clientView.setFitToHeight(true);
		clientView.setContent(table);
	}

	private void addSomething(ObservableList<SettingsChange> changeList,
                             SettingsChange currentRoot) {
		for (Object change: currentRoot.getChildren()) {
			SettingsChange child = (SettingsChange)change;
			changeList.add(child);
			addSomething(changeList, child);
		}
	}

	@Override
	public final void requestFocus() {
		clientView.requestFocus();
	}

	public final StringProperty captionProperty() {
		return caption;
	}

	public final DoubleProperty widthProperty() {
		return width;
	}

	public final DoubleProperty heightProperty() {
		return height;
	}
}
