package xfe.icap.modules.selectioncontext;

import javafx.scene.control.TablePosition;

import xstr.amp.AsnAccessor;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xstr.session.ObservableReplyRow;

import java.util.Objects;

public class SelectionContext {
   public final GridType grid;
   public final ObservableReplyRow row;
   public final AsnAccessor field;
   public final TablePosition tablePosition;
   public final int rowIndex;

   public SelectionContext(GridType grid, ObservableReplyRow row, AsnAccessor field, int rowIndex) {
      this(grid, row, field, null, rowIndex);
   }

   public SelectionContext(GridType grid, ObservableReplyRow row, AsnAccessor field, TablePosition tablePosition, int rowIndex) {
      this.grid = grid;
      this.row = row;
      this.field = field;
      this.tablePosition = tablePosition;
      this.rowIndex = rowIndex;
   }

   @Override
   public String toString() {
      return String.format("Grid: %s, Field: %s, Row: %s, tablePosition: %s", grid, field, row, tablePosition);
   }

   @Override
   public int hashCode() {
      return Objects.hash(grid, row.getKey(), field.getAccessSpec());
   }

   @Override
   public boolean equals(Object other) {
      if (other instanceof SelectionContext) {
         SelectionContext otherCtx = (SelectionContext) other;

         return
               grid == otherCtx.grid && row == otherCtx.row &&
                  (field == otherCtx.field || (field == null && otherCtx.field == null) || (field!=null && field.hasEqualAccess(otherCtx.field)) );
                     // instead of of hasEqualAccess one could also use:
                     // field.getAccessSpec().equals(otherCtx.field.getAccessSpec())
      }

      return false;
   }

}
