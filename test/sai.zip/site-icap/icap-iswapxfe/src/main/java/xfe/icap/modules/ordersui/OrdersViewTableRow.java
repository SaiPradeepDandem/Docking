package xfe.icap.modules.ordersui;

import javafx.beans.value.ChangeListener;
import javafx.scene.control.TableRow;
import xfe.icap.amp.AmpManagedOrder;
import xfe.modules.actions.ActionName;
import xfe.modules.actions.OrderActionArgs;
import xfe.types.RowHighlight;
import xfe.ui.popover.PopOverOwner;
import xstr.session.ObservableReplyRow;

/**
 * Customized TableRow for OrdersView table. The main functionality of this customization is to set the row styling based on the order status.
 */
class OrdersViewTableRow extends TableRow<ObservableReplyRow> implements PopOverOwner {

   private final ChangeListener<Number> changeListener = (obs, oldStatus, newStatus) -> {
      int buySell = getItem().getProperty(AmpManagedOrder.buySell).get();
      pseudoClassStateChanged(OrdersViewTable.OPENED_BID_PSEUDO_CLASS, newStatus.intValue() == AmpManagedOrder.OPENED && buySell == 0);
      pseudoClassStateChanged(OrdersViewTable.OPENED_OFFER_PSEUDO_CLASS, newStatus.intValue() == AmpManagedOrder.OPENED && buySell == 1);
      pseudoClassStateChanged(OrdersViewTable.REFERRED_PSEUDO_CLASS, newStatus.intValue() == AmpManagedOrder.REFERRED);
   };

   private final ChangeListener<Boolean> isDoneChangeListener = (obs, oldVal, isDoneIfTouched) -> pseudoClassStateChanged(RowHighlight.FULL.getStyle(), isDoneIfTouched != null ? isDoneIfTouched : false);

   OrdersViewTableRow() {
      itemProperty().addListener((obs, previousRow, currentRow) -> {
         if (previousRow != null) {
            previousRow.getProperty(AmpManagedOrder.orderStatus).removeListener(changeListener);
            previousRow.getProperty(AmpManagedOrder.isDoneIfTouched).removeListener(isDoneChangeListener);
         }
         if (currentRow != null) {
            currentRow.getProperty(AmpManagedOrder.orderStatus).addListener(changeListener);
            currentRow.getProperty(AmpManagedOrder.isDoneIfTouched).addListener(isDoneChangeListener);
            final int orderStatus = currentRow.getProperty(AmpManagedOrder.orderStatus).get();
            final int buySell = getItem().getProperty(AmpManagedOrder.buySell).get();
            pseudoClassStateChanged(OrdersViewTable.OPENED_BID_PSEUDO_CLASS, orderStatus == AmpManagedOrder.OPENED && buySell == 0);
            pseudoClassStateChanged(OrdersViewTable.OPENED_OFFER_PSEUDO_CLASS, orderStatus == AmpManagedOrder.OPENED && buySell == 1);
            pseudoClassStateChanged(OrdersViewTable.REFERRED_PSEUDO_CLASS, orderStatus == AmpManagedOrder.REFERRED);
            if (currentRow.getValue(AmpManagedOrder.isDoneIfTouched) != null) {
               pseudoClassStateChanged(RowHighlight.FULL.getStyle(), currentRow.getValue(AmpManagedOrder.isDoneIfTouched));
            }
         } else {
            pseudoClassStateChanged(RowHighlight.FULL.getStyle(), false);
            pseudoClassStateChanged(OrdersViewTable.OPENED_BID_PSEUDO_CLASS, false);
            pseudoClassStateChanged(OrdersViewTable.OPENED_OFFER_PSEUDO_CLASS, false);
            pseudoClassStateChanged(OrdersViewTable.REFERRED_PSEUDO_CLASS, false);
         }
      });

      setOnMouseClicked(e -> {
         if (getItem()!=null
            && e.getClickCount() == 1
            && getItem().getProperty(AmpManagedOrder.orderStatus).get().intValue() == AmpManagedOrder.OPENED
            && !isPopOverShowing()) {
            final Boolean isDoneIfTouched = getItem().getValue(AmpManagedOrder.isDoneIfTouched);
            final OrderActionArgs args;
            if (Boolean.TRUE.equals(isDoneIfTouched)) {
               args = new OrderActionArgs(ActionName.AmendCMOrder, getItem(), this);
            } else {
               args = new OrderActionArgs(ActionName.AmendOrder, getItem(), this);
            }
            ((OrdersViewTable) getTableView()).getOrderActionConsumer().accept(args);
         }
      });
   }
}
