package xfe.icap.modules.watchlist;

import java.util.List;

import xfe.icap.types.IcapSecBoardTrim2Watchlist;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import xfe.icap.XfeSession;

public class Presets {
   public static void load(List<IcapSecBoardTrim2Watchlist> watchLists, XfeSession session) {
      watchLists.clear();


      for (WatchlistSpec_v2 spec : PRESETS) {
         IcapSecBoardTrim2Watchlist watchlist = new IcapSecBoardTrim2Watchlist(session);

         watchlist.setOnSecBoardsReady(session.secBoards.get(), new Runnable() {
            @Override
            public void run() {
               spec.populateInto(watchlist, session.secBoards.get());
            }
         });

         watchLists.add(watchlist);
      }
   }

	private static final WatchlistSpec_v2 SP_BMK = new WatchlistSpec_v2(
			"Spreads",
			"bmk",
			new String[] { "A-EUR 2Y-3Y.sp", "A-EUR 3Y-4Y.sp",
					"A-EUR 2Y-5Y.sp", "A-EUR 3Y-5Y.sp", "A-EUR 4Y-5Y.sp",
					"A-EUR 5Y-6Y.sp", "A-EUR 6Y-7Y.sp", "A-EUR 7Y-8Y.sp",
					"A-EUR 2Y-10Y.sp", "A-EUR 5Y-10Y.sp", "A-EUR 7Y-10Y.sp",
					"A-EUR 9Y-10Y.sp", "A-EUR 10Y-11Y.sp", "A-EUR 10Y-12Y.sp",
					"A-EUR 10Y-15Y.sp", "A-EUR 12Y-15Y.sp", "A-EUR 10Y-20Y.sp",
					"A-EUR 15Y-20Y.sp", "A-EUR 10Y-25Y.sp", "A-EUR 10Y-30Y.sp",
					"A-EUR 15Y-30Y.sp", "A-EUR 20Y-30Y.sp", "A-EUR 25Y-30Y.sp", });

	private static final WatchlistSpec_v2 SP_NON_BMK = new WatchlistSpec_v2(
			"Spreads", "no bmk", new String[] { "A-EUR 1Y-2Y.sp",
					"A-EUR 3Y-6Y.sp", "A-EUR 5Y-7Y.sp", "A-EUR 5Y-8Y.sp",
					"A-EUR 6Y-8Y.sp", "A-EUR 3Y-9Y.sp", "A-EUR 5Y-9Y.sp",
					"A-EUR 7Y-9Y.sp", "A-EUR 8Y-9Y.sp", "A-EUR 8Y-10Y.sp",
					"A-EUR 9Y-11Y.sp", "A-EUR 11Y-12Y.sp", "A-EUR 6Y-12Y.sp",
					"A-EUR 12Y-13Y.sp", "A-EUR 13Y-14Y.sp", "A-EUR 20Y-25Y.sp",

			});

	private static final WatchlistSpec_v2 FL_BMK = new WatchlistSpec_v2("Flies",
			"bmk", new String[] { "A-EUR 2Y-3Y-4Y.bf", "A-EUR 2Y-3Y-5Y.bf",
					"A-EUR 3Y-4Y-5Y.bf", "A-EUR 4Y-5Y-6Y.bf",
					"A-EUR 5Y-6Y-7Y.bf", "A-EUR 6Y-7Y-8Y.bf",
					"A-EUR 7Y-8Y-9Y.bf", "A-EUR 2Y-5Y-10Y.bf",
					"A-EUR 5Y-7Y-10Y.bf", "A-EUR 8Y-9Y-10Y.bf",
					"A-EUR 9Y-10Y-11Y.bf", "A-EUR 10Y-11Y-12Y.bf",
					"A-EUR 11Y-12Y-13Y.bf", "A-EUR 12Y-13Y-14Y.bf",
					"A-EUR 10Y-12Y-15Y.bf", "A-EUR 13Y-14Y-15Y.bf",
					"A-EUR 10Y-15Y-20Y.bf", "A-EUR 12Y-15Y-20Y.bf",
					"A-EUR 15Y-20Y-25Y.bf", "A-EUR 10Y-15Y-30Y.bf",
					"A-EUR 10Y-20Y-30Y.bf", "A-EUR 15Y-20Y-30Y.bf",
					"A-EUR 20Y-25Y-30Y.bf", "A-EUR 5Y-10Y-30Y.bf", });

	private static final WatchlistSpec_v2 FL_NON_BMK = new WatchlistSpec_v2("Flies",
			"no bmk", new String[] { "A-EUR 1Y-2Y-3Y.bf", "A-EUR 3Y-5Y-6Y.bf",
					"A-EUR 2Y-5Y-7Y.bf", "A-EUR 3Y-5Y-7Y.bf",
					"A-EUR 3Y-5Y-8Y.bf", "A-EUR 5Y-6Y-8Y.bf",
					"A-EUR 3Y-5Y-9Y.bf", "A-EUR 5Y-7Y-9Y.bf",
					"A-EUR 3Y-5Y-10Y.bf", "A-EUR 5Y-8Y-10Y.bf",
					"A-EUR 7Y-8Y-10Y.bf", "A-EUR 7Y-9Y-10Y.bf",
					"A-EUR 7Y-10Y-12Y.bf", "A-EUR 8Y-10Y-12Y.bf",
					"A-EUR 9Y-10Y-12Y.bf", "A-EUR 7Y-10Y-15Y.bf",
					"A-EUR 2Y-10Y-30Y.bf", });

	private static final WatchlistSpec_v2 FUT_X_MAT = new WatchlistSpec_v2("Fut X",
			"m. mat", new String[] { "A-EUR 2Y SchatzU.sofc",
					"A-EUR 5Y BoblU.sofc", "A-EUR 9Y BundU.sofc",
					"A-EUR 2Y SchatzZ.sofc", "A-EUR 5Y BoblZ.sofc",
					"A-EUR 9Y BundZ.sofc", "A-EUR 2Y SchatzU-5Y BoblU.sofc.sp",
					"A-EUR 2Y SchatzU-9Y BundU.sofc.sp",
					"A-EUR 5Y BoblU-9Y BundU.sofc.sp",
					"A-EUR 2Y SchatzU-5Y BoblU-9Y BundU.sofc.bf", });

	private static final WatchlistSpec_v2 FUT_X_SPOT = new WatchlistSpec_v2("Fut X",
			"spot", new String[] { "A-EUR 4Y spot BoblU.sofc",
					"A-EUR 5Y spot BoblU.sofc", "A-EUR 9Y spot BundU.sofc",
					"A-EUR 10Y spot BundU.sofc",
					"A-EUR 4Y spot BoblU-5Y spot BoblU.sofc.sp",
					"A-EUR 4Y spot BoblU-9Y spot BundU.sofc.sp",
					"A-EUR 5Y spot BoblU-9Y spot BundU.sofc.sp",
					"A-EUR 4Y spot BoblU-10Y spot BundU.sofc.sp",
					"A-EUR 5Y spot BoblU-10Y spot BundU.sofc.sp",
					"A-EUR 9Y spot BundU-10Y spot BundU.sofc.sp",
					"A-EUR spot 4Y BoblU-5Y BoblU-9Y BundU.sofc.bf",
					"A-EUR spot 4Y BoblU-5Y BoblU-10Y BundU.sofc.bf",
					"A-EUR spot 4Y BoblU-9Y BundU-10Y BundU.sofc.bf",
					"A-EUR spot 5Y BoblU-9Y BundU-10Y BundU.sofc.bf",

			});

	private static final WatchlistSpec_v2 OUTR_V6 = new WatchlistSpec_v2("Outrights",
			"v6", new String[] { "A-EUR 1Y", "A-EUR 1Yv3", "A-EUR 18M",
					"A-EUR 18Mv3", "A-EUR 2Y", "A-EUR 2Yv3", "A-EUR 3Y",
					"A-EUR 4Y", "A-EUR 5Y", "A-EUR 6Y", "A-EUR 7Y", "A-EUR 8Y",
					"A-EUR 9Y", "A-EUR 10Y", "A-EUR 11Y", "A-EUR 12Y",
					"A-EUR 15Y", "A-EUR 20Y", "A-EUR 25Y", "A-EUR 30Y", });

	private static final WatchlistSpec_v2 OUTR_V3 = new WatchlistSpec_v2("Outrights",
			"v3", new String[] { "A-EUR 1Yv3", "A-EUR 18Mv3", "A-EUR 2Yv3",
					"A-EUR 3Yv3", "A-EUR 4Yv3", "A-EUR 5Yv3", "A-EUR 6Yv3",
					"A-EUR 7Yv3", "A-EUR 8Yv3", "A-EUR 9Yv3", "A-EUR 10Yv3",
					"A-EUR 11Yv3", "A-EUR 12Yv3", "A-EUR 15Yv3", "A-EUR 20Yv3",
					"A-EUR 25Yv3", "A-EUR 30Yv3", });

	private static final WatchlistSpec_v2 OUTR_3_6 = new WatchlistSpec_v2(
			"Basis", "3/6", new String[] { "A-EUR 1Yv3-1Y.sp",
					"A-EUR 18Mv3-18M.sp", "A-EUR 2Yv3-2Y.sp",
					"A-EUR 3Yv3-3Y.sp", "A-EUR 4Yv3-4Y.sp", "A-EUR 5Yv3-5Y.sp",
					"A-EUR 6Yv3-6Y.sp", "A-EUR 7Yv3-7Y.sp", "A-EUR 8Yv3-8Y.sp",
					"A-EUR 9Yv3-9Y.sp", "A-EUR 10Yv3-10Y.sp",
					"A-EUR 11Yv3-11Y.sp", "A-EUR 12Yv3-12Y.sp",
					"A-EUR 15Yv3-15Y.sp", "A-EUR 20Yv3-20Y.sp",
					"A-EUR 25Yv3-25Y.sp", "A-EUR 30Yv3-30Y.sp", });

	private static final WatchlistSpec_v2 GILTS = new WatchlistSpec_v2(
      "GILTS", "iSwap", new String[] { "A-EUR 10Y", "UKT T47", "UKT FE40" });

   private static final WatchlistSpec_v2  UKT_OR = new WatchlistSpec_v2(
      "UKT OR",
      "outright",
      new String[] { "UKT 1Q18",
         "UKT 4H19",
         "UKT 1T19",
         "UKT 3T19",
         "UKT 4T20",
         "UKT 2 20",
         "UKT 3T20",
         "UKT 1H21",
         "UKT 8 21",
         "UKT 3T21",
         "UKT 4 22",
         "UKT H22",
         "UKT 1T22",
         "UKT T23",
         "UKT 2Q23",
         "UKT 2T24",
         "UKT 5 25",
         "UKT 2 25",
         "UKT 1H26", });


   private static final WatchlistSpec_v2  UKT_SW = new WatchlistSpec_v2(
      "UKT SW",
      "outright",
      new String[] { "4H19< 3T21",
         "4H19< 4 22",
         "4H19< H22",
         "4H19< 1T22",
         "4H19< 2Q23",
         "4H19< 2T24",
         "4H19< 2 25",
         "4H19< 1H26",
         "1T19< 3T19",
         "1T19< 4T20",
         "1T19< 2 20",
         "1T19< 3T20",
         "1T19< 1H21",});

	public static final WatchlistSpec_v2 PRESETS[] = { UKT_OR, UKT_SW, SP_BMK, SP_NON_BMK,
			FL_BMK, FL_NON_BMK, FUT_X_MAT, FUT_X_SPOT, OUTR_V6, OUTR_V3,
			OUTR_3_6, GILTS };

}
