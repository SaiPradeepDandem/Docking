package xfe.icap.ui;

import xstr.util.Fx;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * Created by jiadin on 2015-03-26.
 */
public abstract class ExpireStage extends Stage{
   private final long expireTime;

   public ExpireStage(StageStyle style, long expireTime) {
      super(style);
//      ZoomableDecorator.makeWindowZoomable(this);
      this.expireTime = expireTime;
      Fx.delay(expireTime, new Runnable() {
         @Override
         public void run() {
            if(ExpireStage.this.isShowing()){
               stageExpired();
            }
         }
      });
   }


   protected abstract  void stageExpired();
}
