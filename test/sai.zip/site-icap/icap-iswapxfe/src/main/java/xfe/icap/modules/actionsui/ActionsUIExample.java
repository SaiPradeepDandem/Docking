package xfe.icap.modules.actionsui;

import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

import xfe.icap.SimpleLogonApplicationModule;
import xfe.icap.XfeSession;
import xfe.util.XfeAction;
import xfe.module.Module;

public class ActionsUIExample extends SimpleLogonApplicationModule {
   private final ActionsUIModule thisModule = new ActionsUIModule();

   @Override
   public List<Module> getModules() {
      List<Module> modulesList = new ArrayList<>(super.getModules());

      modulesList.add(thisModule);

      return modulesList;
   }

   @Override
   public List<Class<? extends Module>> getModuleClasses() {
      List<Class<? extends Module>> modulesList = new ArrayList<>(super.getModuleClasses());

//      modulesList.add(thisModule);
      throw new RuntimeException("Fix this!!!");
//      return modulesList;
   }

   @Override
   protected void initApp() {
      onLogoff();
   }

//   public static void main(String[] args) {
//      launch(args);
//   }

   @Override
   protected void onLogon(XfeSession session) {
      XfeAction circ_action = new XfeAction();
      circ_action.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            // TODO Auto-generated method stub
            System.out.println("ON ACTION2");
         }
      });
//      circ_action.setIcon(new Circle(16));

      // ** Example of adding an action **//
      XfeAction rect_action = new XfeAction();
      rect_action.setOnAction(new EventHandler<ActionEvent>() {
         @Override
         public void handle(ActionEvent actionEvent) {
            // TODO Auto-generated method stub
            System.out.println("ON RECT ACTION");
         }
      });

//      rect_action.setIcon(new Rectangle(16, 16));

      thisModule.addAction(3, circ_action);
      thisModule.addAction(6, rect_action);
      thisModule.removeAction(circ_action);
   }

   @Override
   protected void onLogoff() {
      setApplicationRootNode(new Label("Actions Example - Logged off"));
   }

   public List<Image> getIcons() {
      // TODO Auto-generated method stub
      return null;
   }
}

