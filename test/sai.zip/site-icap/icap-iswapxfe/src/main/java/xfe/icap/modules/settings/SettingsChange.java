package xfe.icap.modules.settings;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.util.Breadcrumbs;

public abstract class SettingsChange<V> {
	private static final Logger logger = LoggerFactory.getLogger(SettingsChange.class);
	static final Breadcrumbs<Object> direction = new Breadcrumbs<Object>();
	static final Object up = new Object();
	static final Object down = new Object();
	private final SettingsChange<?> parent;
	private final List<SettingsChange<?>> children = new ArrayList<>();
	private final String description;
	private final V myValue;
	private final V theirValue;
	private int level;
	private final BooleanProperty appliedStatusProperty = new SimpleBooleanProperty(false);
	private boolean isChangeAgent = true;

	public SettingsChange(SettingsChange<?> parent,
                         String description,
                         V myValue,
                         V theirValue,
                         boolean isChangeAgent) {
		this.parent = parent;
		this.description = description;
		this.myValue = myValue;
		this.theirValue = theirValue;
		this.isChangeAgent = isChangeAgent;

		if (parent != null) {
			level = parent.level + 1;
		}

		appliedStatusProperty.addListener((arg0, oldVal, newVal) -> {

         if (!direction.getTrail().contains(up)) {
            direction.run(down, () -> updateProgeny());
         }

         if (!direction.getTrail().contains(down)) {
            direction.run(up, () -> updateProgenitor());
         }
      });
	}

	protected abstract void applyChanges(SettingsChange<?> changeAgent);

	public void doApplyChanges() {
		// Returning the root's sub-trees that require changes
		if (appliedStatusProperty.get()) {
			applyFromHere();
		}
		else { // Need to drill down to find the relevant root to apply
			for (SettingsChange<?> change: children) {
				change.doApplyChanges();
			}
		}
	}

	private void applyFromHere() {
		if (isChangeAgent) {
			logger.debug("Applying change for " + description);
			applyChanges(null);
		} else {
			// Find an ancestor that is a change agent
			SettingsChange<?> parentAgent = parent;
			while (parentAgent != null && !parentAgent.isChangeAgent) {
				parentAgent = parentAgent.parent;
			}

			if (parentAgent != null && parentAgent.isChangeAgent) {
				logger.debug("Applying change for " + description + " via " + parentAgent.description);
				applyChanges(parentAgent);
			}
		}
	}

	public String getDescription() {
		return description;
	}

	public V getMyValue() {
		return myValue;
	}

	public V getTheirValue() {
		return theirValue;
	}

	public int getLevel() {
		return level;
	}

	public boolean getAppliedStatus() {
		return appliedStatusProperty.get();
	}

	public void setAppliedStatus(boolean appliaedStatus) {
		appliedStatusProperty.set(appliaedStatus);
	}

	public BooleanProperty appliedStatusProperty() {
		return appliedStatusProperty;
	}

	public List<SettingsChange<?>> getChildren() {
		return children;
	}

	public void debugPrint(int level) {
		for (int i = 0; i < level; ++i) {
			System.out.print("   ");
		}
		System.out.print(description == null ? "NULL DESC" : description);
		System.out.print(" --> ");
		System.out.print(myValue == null ? "(M)NULL " : "(M)" + myValue + " ");
		System.out.println(theirValue == null ? "(T)NULL " : "(T)" + theirValue);
		for (SettingsChange<?> change: children) {
			change.debugPrint(level + 1);
		}
	}

	public void debugLog(int level) {
		for (int i = 0; i < level; ++i) {
			logger.debug("   ");
		}
		logger.debug(description == null ? "NULL DESC" : description);
		logger.debug(" --> ");
		logger.debug(myValue == null ? "(M)NULL " : "(M)" + myValue + " ");
		logger.debug(theirValue == null ? "(T)NULL " : "(T)" + theirValue);
		for (SettingsChange<?> change: children) {
			change.debugPrint(level + 1);
		}
	}

	private void updateProgenitor() {
		if (parent == null) return;

		// checking if children are all in applied status or not
		boolean allApplied = true;
		for (SettingsChange<?> change: parent.getChildren()) {
			if (!change.getAppliedStatus()) {
				allApplied = false;
				break;
			}
		}

		if (allApplied && !parent.getAppliedStatus())
			parent.setAppliedStatus(true);

		if (!allApplied && parent.getAppliedStatus())
			parent.setAppliedStatus(false);
	}

	private void updateProgeny() {
		for (SettingsChange<?> change: children) {
			change.setAppliedStatus(appliedStatusProperty.get());
		}
	}
}
