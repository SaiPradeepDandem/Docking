package xfe.icap.types;

import xfe.types.UiSession;
import xstr.types.User;
import xstr.util.Fun1;
import xstr.util.ReplyHandler;
import xstr.util.exception.AsnTypeException;
import xstr.util.exception.XtrException;

import xstr.amp.AMP;
import xstr.session.ServerSession;
import xstr.session.XtrTransRequestBuilder;
import xstr.session.XtrTransReply;
import xstr.session.XtrTransRequest;
import xfe.icap.amp.AmpOrderTickUpDownAcc;
import com.objsys.asn1j.runtime.Asn1Type;

public abstract class Order {
   private final Asn1Type orderId;

   public Order(Asn1Type orderId) {
      this.orderId = orderId;
   }

   public Asn1Type getOrderId() {
      return orderId;
   }

   public void tickUpDown(ServerSession session,
                          StepArrays stepArrays,
                          Integer tickValue,
                          ReplyHandler<XtrTransReply> handler) throws XtrException {
      User currentUser = session.getLoggedOnUser();
      String subjectUser  = null;
      if(currentUser.isBroker()){
         subjectUser = this.getUserId();
      }

      XtrTransRequest req = XtrTransRequestBuilder.create(AmpOrderTickUpDownAcc.txn, session)
            .setAsn(AmpOrderTickUpDownAcc.orderId, orderId)
            .set(AmpOrderTickUpDownAcc.numTicks, (long)tickValue)
            .subjectUser(subjectUser)
            .build();
      session.execute(req, handler);
   }

   public void tickUp(ServerSession session, StepArrays stepArrays, ReplyHandler<XtrTransReply> handler) throws XtrException {
      tickUpDown(session, stepArrays, 1, handler);
   }

   public void tickDown(ServerSession session, StepArrays stepArrays, ReplyHandler<XtrTransReply> handler) throws XtrException {
      tickUpDown(session, stepArrays, -1, handler);
   }

   public void refer(UiSession session, ReplyHandler<XtrTransReply> handler) throws XtrException {
      User currentUser = session.getUnderlyingSession().getLoggedOnUser();
      String subjectUser  = null;
      if(currentUser.isBroker()){
         subjectUser = this.getUserId();
      }
      XtrTransRequest req = XtrTransRequestBuilder.create(AMP.tREQ(("orderDeactivate")), session.getUnderlyingSession())
            .setAsn(AMP.tREQ("orderDeactivate.orderId"), orderId)
            .set(AMP.tREQ("orderDeactivate.introBrokerId"), this.getIntroBrokerId())
            .subjectUser(subjectUser)
            .build();
      session.getUnderlyingSession().execute(req, handler);
   }

   public abstract String getUserId();
   public abstract String getOperatorId() throws AsnTypeException;
   public abstract String getIntroBrokerId() throws AsnTypeException;
   public abstract String getOrderType() throws AsnTypeException;
   //    public abstract boolean isSharedOrder() throws AsnTypeException;

   public abstract boolean canRenew() throws AsnTypeException;

   public abstract boolean canWithdraw() throws AsnTypeException;

   public abstract boolean isManaged() throws AsnTypeException;

   public static final Fun1<String,Boolean> isImplied = new Fun1<String,Boolean>() {
      @Override
      public Boolean call(String orderType) {
         return orderType != null && (orderType.contains("Implied") || orderType.contains("implied"));
      }
   };

   public boolean isTrader(ServerSession session) throws AsnTypeException {
      return (session.getLoggedOnUserId().equals(getUserId()) && getOperatorId() == null);
   }
}
