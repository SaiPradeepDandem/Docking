package xfe.icap.client;

import io.netty.channel.ChannelHandler.Sharable;
import xmp.message.XMP.XmpSessionReply;
import xmp.message.XMP.XmpTransactionRequest;
import xstr.session.XtrQueryRequestContext;
import xstr.session.*;
import com.omxgroup.xstream.amp.AmpTransReqChoice;
import com.omxgroup.xstream.api.TransRequest;
import com.omxgroup.xstream.api.cometheader.UserId;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.util.internal.logging.InternalLoggerFactory;
import io.netty.util.internal.logging.Slf4JLoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.Duration;
import xstr.util.Time;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.FutureListener;
import xstr.util.concurrent.Futures;
import xstr.util.exception.*;
import xstr.icap.csdk.ICAP;
import xstr.util.LoggerUtil;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class IcapWebSession extends SessionWrapper {
   private static final Logger logger = LoggerFactory.getLogger(IcapWebSession.class);
   private final AtomicInteger nextTransId = new AtomicInteger(0);
   private final Timer timer = new Timer(true);
   private XstrWebConnection connection;
   private volatile String teSessionId;
   private boolean isDelayed;

   public void setSessionID(String sessionID) {
      logger.info("Setting session ID to {}", sessionID);
      this.teSessionId = sessionID;
   }

   @Sharable
   public class SessionMessageHandler extends SimpleChannelInboundHandler<XmpSessionReply> {
      @Override
      public void channelRead0(ChannelHandlerContext ctx, XmpSessionReply msg) {
         logger.info("Session logoff received from the server: {}", msg.getErrorMessage());
         evalError(new XtrSessionException("Server terminated session: " + msg.getErrorMessage()));
      }

      @Override
      public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
         logger.error("Channel error:", Exceptions.format(cause));
         logger.error("Channel error:", cause);
         ctx.close();
      }
   }

   public ChannelHandler sessionMessageHandler = new SessionMessageHandler();

   static {
      InternalLoggerFactory.setDefaultFactory(new Slf4JLoggerFactory());
   }

   @Override
   public String getSessionMessage() {
      return connection == null ? "" : connection.getSessionMessage();
   }

   private final FutureListener<Void> reconnectListener = fn -> {
      try {
         fn.get();
         logger.info("Connection closed unexpectedly.");
      } catch (Exception e) {
         logger.info("Connection with error: ", Exceptions.format(e));
      }
   };


   protected IcapWebSession(XstrClientConfig config) {
      super(config);
      TimerTask inactivityTask = new TimerTask() {
         @Override
         public void run() {
            Duration inactiveTime = Time.now().minus(getLastReceiveTime()).nonNegative();
            if (isDelayed && inactiveTime.compareTo(getReceiveTimeout()) < 0) {
               logger.info("Connection restored");
               isDelayed = false;
               handleConnectionRestored();
            } else if (inactiveTime.compareTo(getReceiveTimeout()) >= 0) {
               logger.debug("Connection interrupted");
               isDelayed = true;
               handleConnectionInterrupted(inactiveTime.in(TimeUnit.SECONDS));
            }
         }
      };
      timer.scheduleAtFixedRate(inactivityTask, 400, 400);
   }

   protected XstrWebConnection getRawSession() {
      return connection;
   }

   protected abstract Future<? extends XstrWebConnection> connect(Credentials cred);

   @Override
   public XtrSingleIterator query(XtrQueryRequestContext request) throws AsnTypeException {
      logger.debug("New Single Query: {}", request);
      return new XstrWebIterator(this, getRawSession(), request);
   }

   protected Future<Boolean> doLogon(Credentials credentials) {
      logger.debug("Initiating web logon.");
      LoggerUtil.alterLogLevel("TRACE");
      Future<Void> connectionFuture = Future.SUCCESS;
      if (connection != null) {
         logger.debug("Clean up old connection before reconnecting");
         connection.closeFuture().removeListener(reconnectListener);
         connectionFuture = connection.dispose();
      }
      return connectionFuture.flatMap(x -> connect(credentials).map(session -> {
         connection = session;
         connection.closeFuture().addListener(reconnectListener);
         resetLastReceiveTime();
         logger.info("Web session logon succeeded for {} with session ID {}", credentials.getUsername(), teSessionId);
         return true;
      })).addListener(x -> LoggerUtil.restoreLogLevel());
   }

   public Future<XtrTransReply> execute(XtrTransRequest req) {
      TransRequest realReq = new TransRequest((AmpTransReqChoice) req.getData());
      try {
         realReq.subject_user(new UserId(req.getSubjectUser()));
         XmpTransactionRequest txn = ICAP.tsmrToXmp(realReq, nextTransId.incrementAndGet());
         resetLastSendTime();
         return getRawSession()
            .execute(txn, realReq.message().getElemName())
            .map(reply -> {
               resetLastReceiveTime();
               return ICAP.xmpToLocal(reply);
            });
      } catch (Exception t) {
         logger.error("Exception while executing transaction: ", t);
         Exception e = new XtrMessageException(realReq.message()+" failed due to " + Exceptions.format(t));
         return Futures.error(e);
      }
   }

   @Override
   protected boolean requiresPasswordChange() {
      return getRawSession().requiresPasswordChange();
   }

   @Override
   public boolean isLoggedOn() {
      return getRawSession() != null && getRawSession().live();
   }

   @Override
   protected Future<Void> dispose(boolean disposing) {
      logger.info("Disposing Web session");
      if (connection != null)
         connection.closeFuture().removeListener(reconnectListener);
      return super.dispose(disposing).onDone(x -> {
         timer.cancel();
         Future<Void> connectionFuture = Future.SUCCESS;
         if (connection != null && connection.live()) {
            connectionFuture = connection.dispose();
         }
         return connectionFuture;
      });
   }

   @Override
   public XtrCombinedIterator query(List<XtrQueryRequestContext> reqList) throws XtrMessageException {
      logger.debug("New subscription of {}", reqList);
      return new XstrWebSubscription(this, getRawSession(), reqList);
   }

   @Override
   public String getTESessionId() {
      return teSessionId;
   }

}
