package xfe.icap;

import java.util.*;
import java.util.concurrent.TimeUnit;

import org.slf4j.*;

import javafx.beans.*;

import javafx.beans.property.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.SplitPane;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;

import com.nomx.persist.*;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.modules.appcontext.FxApplicationModule;
import xfe.icap.ui.AboutInfoPopup;
import xfe.ui.ModalWindowContext;
import xfe.util.scene.control.AppContainer;
import xfe.util.scene.control.AutoHider;
import xfe.util.scene.control.VerticalAppContainer;
import xfe.layout.FxAbstractLayout;

import xfe.icap.modules.actionsui.ActionsUIModule;
import xstr.util.Duration;
import xstr.util.Time;

public class DemoLayoutMedium extends FxAbstractLayout {

   private static final Logger logger = LoggerFactory.getLogger(DemoLayoutMedium.class);
   private static final String LOGGED_OFF_STYLE = "xfe-logged-off";

   public static final String ID_SUFFIX_SPLITPANE_CONTENT = "-split-content";
   public static final String ID_WATCHLIST = "watchlist" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes the settings toolbar, tradeticker and watchlist
   public static final String ID_DEPTH = "depth" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes the depth
   public static final String ID_ORDERENTER = "orderEnter" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes orderenter and action
   public static final String ID_TRADES = "trades" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes trades
   public static final String ID_ORDERS = "orders" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes orders
   public static final String ID_HISTORYS = "historyModule" + ID_SUFFIX_SPLITPANE_CONTENT;// it includes historyModule

   @ModuleDependency
   public XfeSession xfeSession;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   public DemoLayoutMedium() {
      super("Demo");
   }

   public DemoLayoutMedium(String layoutName) {
      super(layoutName);
   }

   private VerticalAppContainer root;
   private final HBox watchlistNode = new HBox();
   private final HBox depthNode = new HBox();
   private final HBox orderEntryNode = new HBox();

   private final HBox ordersNode = new HBox();
   private final HBox tradesNode = new HBox();
   private final HBox historyNode = new HBox();

   private final HBox actionsNode = new HBox() {{
      this.getStyleClass().add("xfe-action-buttons-holder");
   }};

   private final HBox banner = new HBox();
   private final SplitPane splitPane_right = new SplitPane();
   private final SplitPane splitPane_left = new SplitPane();

   private final double[] pos_left = {0.5,0.9};
   private final double[] pos_right = {0.33,0.66};

//   @ModuleDependency
   public ActionsUIModule actions;


   private final InvalidationListener watchlistHeightLis = paramObservable -> saveLocation(PersistantName.WatchListContentHeight, splitPane_left.getDividers().get(0).positionProperty().doubleValue());

   private final InvalidationListener tradesHeightLis = paramObservable -> saveLocation(PersistantName.TradesContentHeight, splitPane_right.getDividers().get(0).positionProperty().doubleValue());

   private final InvalidationListener historyHeightLis = paramObservable -> saveLocation(PersistantName.HistoryContentHeight, splitPane_right.getDividers().get(1).positionProperty().doubleValue());



   private final HBox hbox_content = new HBox(){{
      splitPane_right.setOrientation(Orientation.VERTICAL);
      splitPane_left.setOrientation(Orientation.VERTICAL);
      this.getChildren().addAll(splitPane_left,splitPane_right);

      splitPane_right.setPrefWidth(512);
      splitPane_right.getItems().addAll(ordersNode,tradesNode,historyNode);
      splitPane_left.setPrefWidth(512);
      splitPane_left.getItems().addAll(watchlistNode,depthNode,orderEntryNode);

      HBox.setHgrow(splitPane_left, Priority.ALWAYS);
      HBox.setHgrow(splitPane_right, Priority.ALWAYS);
      splitPane_left.setDividerPositions(pos_left);
      splitPane_right.setDividerPositions(pos_right);
//      watchlistNode.setPrefHeight(FxApplicationModule.MAIN_STAGE_HEIGHT/2);
//      depthNode.setPrefHeight(FxApplicationModule.MAIN_STAGE_HEIGHT/2);
//      ordersNode.setPrefHeight(FxApplicationModule.MAIN_STAGE_HEIGHT/3);
//      tradesNode.setPrefHeight(FxApplicationModule.MAIN_STAGE_HEIGHT/3);
//      historyNode.setPrefHeight(FxApplicationModule.MAIN_STAGE_HEIGHT/3);
      SplitPane.setResizableWithParent(watchlistNode, true);
      SplitPane.setResizableWithParent(depthNode, true);
      SplitPane.setResizableWithParent(orderEntryNode, false);
      SplitPane.setResizableWithParent(historyNode, true);
      SplitPane.setResizableWithParent(tradesNode, true);
      SplitPane.setResizableWithParent(ordersNode, true);
      watchlistNode.setId(ID_WATCHLIST);
      depthNode.setId(ID_DEPTH);
      orderEntryNode.setId(ID_ORDERENTER);
      historyNode.setId(ID_HISTORYS);
      tradesNode.setId(ID_TRADES);
      ordersNode.setId(ID_ORDERS);

      splitPane_left.getDividers().get(0).positionProperty().addListener(watchlistHeightLis);

      splitPane_right.getDividers().get(0).positionProperty().addListener(tradesHeightLis);

      splitPane_right.getDividers().get(1).positionProperty().addListener(historyHeightLis);

   }};

   private void saveLocation(PersistantName pName, double newPosition) {
//      if (IcapSplitPaneSkin.isUserAdjustingHeight()) {
//         xfeSessionModule.getParametersStorage().get(pName, 0.2).set(newPosition);
//         logger.debug("setting config of locatoin for {} divider is set to {}", pName, xfeSessionModule.getParametersStorage().get(pName, 0.2).get());
//      }
   }


   private Time lastLogoPressedTime = Time.now();
   private final BooleanProperty showingInfoPopups = new SimpleBooleanProperty(true);
   private final Rectangle clipRect = new Rectangle();
   private final StackPane applicationTitleLogo = new StackPane() {
      {
         this.getChildren().add(new ImageView());
         this.setId("xfe-header-title-pane");
      }
   };
   private StackPane popupGroup;

   private final Group logonWidget = new Group() {
      {
         getChildren().add(new Region());
      }
   };

//   private Node globalReferBtnsNode = new Region();


   @Override
   public AppContainer getLayoutRootElement() {
      if (root == null) {
         BorderPane content = new BorderPane();
         banner.setId("xfe-app-header");
         banner.getChildren().addAll(applicationTitleLogo, logonWidget, new Pane() {
            {
               HBox.setHgrow(this, Priority.ALWAYS);
            }
         }, new Pane() {
        	 {
                 HBox.setHgrow(this, Priority.ALWAYS);
        	 }
         });
         this.popupGroup = new StackPane();
         this.popupGroup.getStyleClass().add("popup-group");

         StackPane body = new StackPane() {
            {
               this.getChildren().addAll(hbox_content, popupGroup);
            }
         };

         new AutoHider(popupGroup);
//         popupGroup.setClip(clipRect);
//         clipRect.widthProperty().bind(body.widthProperty());
//         clipRect.heightProperty().bind(body.heightProperty());

         content.setTop(banner);
         content.setCenter(body);
         content.setBottom(actionsNode);
         applicationTitleLogo.setPickOnBounds(true);
         applicationTitleLogo.setOnMousePressed(mouseEvent -> lastLogoPressedTime = Time.now());
         applicationTitleLogo.setOnMouseReleased(mouseEvent -> {
            Duration clickDuration = Time.now().minus(lastLogoPressedTime);
            if (clickDuration.compareTo(Duration.ZERO) >= 0 && clickDuration.compareTo(Duration.of(250, TimeUnit.MILLISECONDS)) < 0) {
               new AboutInfoPopup("", applicationTitleLogo, showingInfoPopups).show(getScene().getWindow());
            }
         });

         root = new VerticalAppContainer(null, FxApplicationModule.MAIN_STAGE_WIDTH, FxApplicationModule.MAIN_STAGE_HEIGHT, true, this,true);
         root.setContent(content);
         root.setAllowIconified(true);
         hbox_content.getStyleClass().add("xfe-content-pane");
      }

      return root;
   }

   @Override
   public Pane getPopupGroup() {
      return popupGroup;
   }

   @Override
   public void goModal(Node modalNode, Runnable runnable) {
      ModalWindowContext.registerHideEvent(modalNode, null, hbox_content, banner);
   }

   @Override
   protected Scene getScene() {
      return hbox_content.getScene();
   }

   public static String defaultToIfNull(String value, String defaultValue) {
      return value != null ? value : defaultValue;
   }

   @Override
   public void addView(Node view) {

      keyboardNavigation.addView(view);
      String id = defaultToIfNull(view.getId(), "");
      logger.debug("adding view which id is " + id);
      if (id.equals("connection-status")) {
         logonWidget.getChildren().set(0, view);
      } else if (id.equals("xfe-watchlist-view")) {
         watchlistNode.getChildren().setAll(view);
//         splitPane_left.getItems().add(0, view);
         HBox.setHgrow(view, Priority.ALWAYS);
         keyboardNavigation.getContext(view).cycleFocus = true;
      } else if (id.equals("xfe-iswap-toolbar")) {
         // DockPane.setSide(view, javafx.geometry.Side.TOP);
         // replaceIndex = splitPane.getItems().indexOf(toolbarNode);
         // toolbarNode.getChildren().setAll(view);
         // HBox.setHgrow(view, Priority.ALWAYS);
         // keyboardNavigation.getContext(view).cycleFocus = false;
      } else if (id.equals("xfe-depth-view")) {
         HBox.setHgrow(view, Priority.ALWAYS);
//         splitPane_left.getItems().add(1, view);
         depthNode.getChildren().setAll(view);
         keyboardNavigation.getContext(view).cycleFocus = true;
      } else if (id.equals("xfe-managed-order-entry-view")) {
         orderEntryNode.getChildren().setAll(view);
//         splitPane_left.getItems().add(2, view);
         HBox.setHgrow(view, Priority.ALWAYS);
         keyboardNavigation.getContext(view).cycleFocus = true;
      } else if (id.equals("historyModule-provider-view")) {
         HBox.setHgrow(view, Priority.ALWAYS);
         historyNode.getChildren().setAll(view);
//         splitPane_right.getItems().add(2, view);
         keyboardNavigation.getContext(view).cycleFocus = false;
      } else if (id.equals("xfe-orders-view")) {
         HBox.setHgrow(view, Priority.ALWAYS);
         ordersNode.getChildren().setAll(view);
//         splitPane_right.getItems().add(0, view);
         keyboardNavigation.getContext(view).cycleFocus = true;
      } else if (id.equals("xfe-trades-view")) {
//         splitPane_right.getItems().add(1, view);
         tradesNode.getChildren().setAll(view);
         HBox.setHgrow(view, Priority.ALWAYS);
//         restorePosition();
         keyboardNavigation.getContext(view).cycleFocus = true;
      } else if (id.equals("xfe-trades-ticker-view")) {
         // replaceIndex = splitPane.getItems().indexOf(tradesTickerNode);
         // tradesTickerNode.getChildren().setAll(view);
         // HBox.setHgrow(view, Priority.ALWAYS);
         // keyboardNavigation.getContext(view).cycleFocus = false;
      } else if (id.equals("xfe-actions-view")) {
         actionsNode.getChildren().setAll(view);
         HBox.setHgrow(view, Priority.ALWAYS);
         keyboardNavigation.getContext(view).cycleFocus = true;
      } else if (id.equals("xfe-global-refer-btns-view")) {
//         final int index = banner.getChildren().indexOf(globalReferBtnsNode);
//         globalReferBtnsNode = view;
//         banner.getChildren().set(index, globalReferBtnsNode);
      } else if (view.getStyleClass().contains("xfe-popup")) {
         hbox_content.setDisable(true);
         logonWidget.setDisable(true);
         hbox_content.getStyleClass().add(LOGGED_OFF_STYLE);
         hbox_content.setEffect(new GaussianBlur());
         popupGroup.getChildren().add(view);
         StackPane.setAlignment(view, Pos.CENTER);
      }

      hbox_content.requestLayout();
   }

   private static Region createPlaceholder() {
      Region r = new Region();
      r.setMaxSize(0, 0);
      return r;
   }

   @Override
   public void removeView(Node view) {
      keyboardNavigation.removeView(view);

      Node replaceNode = createPlaceholder();

      String id = defaultToIfNull(view.getId(), "");

      if (id.equals("connection-status")) {
         logonWidget.getChildren().set(0, replaceNode);
      } else if (id.equals("xfe-orders-view")) {
         ordersNode.getChildren().clear();
//         splitPane_right.getItems().remove(ordersNode);
      } else if (id.equals("xfe-global-refer-btns-view")) {
//         int index = banner.getChildren().indexOf(globalReferBtnsNode);
//         globalReferBtnsNode = replaceNode;
//         banner.getChildren().set(index, globalReferBtnsNode);
      } else if (id.equals("xfe-watchlist-view")) {
         watchlistNode.getChildren().clear();
//         splitPane_left.getItems().remove(watchlistNode);
      } else if (id.equals("xfe-iswap-toolbar")) {
         // toolbarNode.getChildren().setAll(replaceNode);
      } else if (id.equals("xfe-depth-view")) {
         depthNode.getChildren().clear();
//         splitPane_left.getItems().remove(depthNode);
      } else if (id.equals("xfe-managed-order-entry-view")) {
         orderEntryNode.getChildren().clear();
//         splitPane_left.getItems().remove(orderEntryNode);
      } else if (id.equals("historyModule-provider-view")) {
         historyNode.getChildren().clear();
//         splitPane_right.getItems().remove(historyNode);
      } else if (id.equals("xfe-trades-view")) {
         tradesNode.getChildren().clear();
//         splitPane_right.getItems().remove(tradesNode);
      } else if (id.equals("xfe-trades-ticker-view")) {
         // tradesTickerNode.getChildren().setAll(replaceNode);
         HBox.setHgrow(view, Priority.ALWAYS);
      } else if (id.equals("xfe-actions-view")) {
         actionsNode.getChildren().setAll(replaceNode);
         HBox.setHgrow(view, Priority.ALWAYS);
      } else if (view.getStyleClass().contains("xfe-popup")) {
         popupGroup.getChildren().remove(view);
         hbox_content.setDisable(false);
         logonWidget.setDisable(false);
         hbox_content.getStyleClass().remove(LOGGED_OFF_STYLE);
         hbox_content.setEffect(null);
      }
   }

   SplitPane splitPane;


   public boolean layoutPane(Node node, LayoutActon action) {
      String nodeId = node.getId();
      if(nodeId.equalsIgnoreCase("xfe-depth-view")){
         splitPane = splitPane_left;
      }else
         splitPane = splitPane_right;
      boolean rtn = false;
      Node parent = node.getParent();
      parent = parent.getParent();
         switch (action) {
         case collapse:
            collapse(node);
            break;
         case expand:
//            String nodeId = node.getId();
//            expand(nodeId, contentDividerList, index);
            restorePosition( );
            break;
         case fullScreen:
            if(splitPane==splitPane_left){
               splitPane_left.getDividers().get(0).positionProperty().removeListener(watchlistHeightLis);
            }else if(splitPane==splitPane_right){
               splitPane_right.getDividers().get(0).positionProperty().removeListener(tradesHeightLis);
               splitPane_right.getDividers().get(1).positionProperty().removeListener(historyHeightLis);
            }
            List<Node> allNodes = splitPane.getItems();
            List<Node> tobeRemoved = new ArrayList<>(allNodes.size());
            for (Node existNode : allNodes) {
               if (!existNode.getId().equals(parent.getId())) {
                  tobeRemoved.add(existNode);
               }
            }
            allNodes.removeAll(tobeRemoved);
            break;
         case exitFullScreen:
            exitFullScreen();
            break;
         default:
            break;
         }

      return rtn;
   }


   private void collapse(Node node) {
      if(splitPane==splitPane_left)
         splitPane.setDividerPositions(1);
      else if(splitPane==splitPane_right){
         ParametersStorage data = configurationModule.getParametersStorage();
         double historyHeight = data.get(PersistantName.HistoryContentHeight, 0.33).get();
         double tradesHeight = data.get(PersistantName.TradesContentHeight, 0.66).get();
         String id = node.getId();
         if(id.equalsIgnoreCase("xfe-orders-view")){
            splitPane.setDividerPositions(0,historyHeight);
         }else if(id.equalsIgnoreCase("xfe-trades-view")){
            splitPane.setDividerPositions(historyHeight,historyHeight);
         }else if(id.equalsIgnoreCase("historyModule-provider-view")){
            splitPane.setDividerPositions(tradesHeight,1);
         }

      }

   }

   public void exitFullScreen() {
      splitPane.getItems().clear();
      restorePosition( );
   }

   public void restorePosition(){
      ParametersStorage data = configurationModule.getParametersStorage();
      double watchListHeight = data.get(PersistantName.WatchListContentHeight, 0.5).get();
      double tradessHeight = data.get(PersistantName.TradesContentHeight, 0.33).get();
      double historyHeight = data.get(PersistantName.HistoryContentHeight, 0.66).get();
      if(splitPane==splitPane_left){
         splitPane_left.getItems().setAll(watchlistNode,depthNode,orderEntryNode);
         splitPane_left.getDividers().get(0).positionProperty().addListener(watchlistHeightLis);
         splitPane.setDividerPositions(watchListHeight,0.9);
      }
      else if(splitPane==splitPane_right){
         splitPane_right.getItems().setAll(ordersNode, tradesNode, historyNode);
         splitPane.setDividerPositions(tradessHeight,historyHeight);
         splitPane_right.getDividers().get(0).positionProperty().addListener(tradesHeightLis);
         splitPane_right.getDividers().get(1).positionProperty().addListener(historyHeightLis);
      }

   }



}
