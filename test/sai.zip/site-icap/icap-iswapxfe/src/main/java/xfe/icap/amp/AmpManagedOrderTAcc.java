package xfe.icap.amp;

import java.util.Date;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP.AmpTreq;
import xstr.types.MapWrapper;
import xstr.amp.AMP;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import com.omxgroup.syssrv.Duration;

/**
 * Accessors for AmpOrderAmend_v5
 * @author absw
 *
 */
public class AmpManagedOrderTAcc extends AmpAccessor {
   public static final AmpTreq txn = AMP.tREQ("managedOrder");

   public static final AsnAccessor orderId =  acc(AMP.tREQ("orderAmend.orderId"));

   public static final AsnConversionAccessor<String> secCode = acc(AMP.tREQ("managedOrder.order.fixed.secBoardId.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.tREQ("managedOrder.order.fixed.secBoardId.boardId"), String.class);
   public static final AsnConversionAccessor<Integer> type = acc(AMP.tREQ("managedOrder.order.fixed.type"), Integer.class);
   public static final AsnConversionAccessor<Boolean> isPrivate = acc(AMP.tREQ("managedOrder.order.fixed.isPrivate"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> isDoneIfTouched = acc(AMP.tREQ("managedOrder.order.fixed.isDoneIfTouched"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> isTopCut = acc(AMP.tREQ("managedOrder.order.amendable.isTopcut"), Boolean.class);
   public static final AsnConversionAccessor<Date> pickOrderDate = acc(AMP.tREQ("managedOrder.order.fixed.pickOrderId.orderDate"), Date.class);
   public static final AsnConversionAccessor<Long> pickOrderNo = acc(AMP.tREQ("managedOrder.order.fixed.pickOrderId.orderNo"), Long.class);
   public static final AsnConversionAccessor<Long> pickOrderNoSuffix = acc(AMP.tREQ("managedOrder.order.fixed.pickOrderId.orderNoSuffix"), Long.class);
   public static final AsnConversionAccessor<Date> crossLinkedOrderDate = acc(AMP.tREQ("managedOrder.order.fixed.crossLinkedOrderId.orderDate"), Date.class);
   public static final AsnConversionAccessor<Long> crossLinkedOrderNo = acc(AMP.tREQ("managedOrder.order.fixed.crossLinkedOrderId.orderNo"), Long.class);
   public static final AsnConversionAccessor<Long> crossLinkedOrderNoSuffix = acc(AMP.tREQ("managedOrder.order.fixed.crossLinkedOrderId.orderNoSuffix"), Long.class);
   public static final AsnConversionAccessor<Boolean> isPublic = acc(AMP.tREQ("managedOrder.order.siteSpecific.icap.isPublic"), Boolean.class);
   public static final AsnConversionAccessor<Double> price = acc(AMP.tREQ("managedOrder.order.amendable.price"), Double.class);
   public static final AsnConversionAccessor<Long> price_decimals = acc(AMP.tREQ("managedOrder.order.amendable.price.decimals"), Long.class);
   public static final AsnConversionAccessor<Double> quantity = acc(AMP.tREQ("managedOrder.order.amendable.quantity"), Double.class);
   public static final AsnConversionAccessor<Long> quantity_decimals = acc(AMP.tREQ("managedOrder.order.amendable.quantity.decimals"), Long.class);
   public static final AsnConversionAccessor<Duration> durationTime = acc(AMP.tREQ("managedOrder.order.amendable.durationTime"), Duration.class);
   public static final AsnConversionAccessor<Integer> durationType = acc(AMP.tREQ("managedOrder.order.amendable.duration"), Integer.class);
   public static final AsnConversionAccessor<Double> visibleQuantity = acc(AMP.tREQ("managedOrder.order.amendable.visibleQuantity"), Double.class);
   public static final AsnConversionAccessor<Double> minFillQuantity = acc(AMP.tREQ("managedOrder.order.amendable.minFillQuantity"), Double.class);
   public static final AsnConversionAccessor<Integer> buySell = acc(AMP.tREQ("managedOrder.order.fixed.buySell"), Integer.class);
   public static final AsnConversionAccessor<Boolean> shared = acc(AMP.tREQ("managedOrder.order.amendable.shared"), Boolean.class);
   public static final AsnConversionAccessor<Integer> actionOnLogoff = acc(AMP.tREQ("managedOrder.order.amendable.actionOnLogoff"), Integer.class);
   public static final AsnConversionAccessor<Boolean> allowMultiMinFill = acc(AMP.tREQ("managedOrder.order.amendable.allowMultiMinFill"), Boolean.class);
   public static final AsnConversionAccessor<Boolean> cloneIntoRFS = acc(AMP.tREQ("managedOrder.order.amendable.cloneIntoRFS"), Boolean.class);
   public static final AsnConversionAccessor<MapWrapper> extrafields = acc(AMP.tREQ("managedOrder.order.fixed.extraFieldsList"), MapWrapper.class);
   public static final AsnConversionAccessor<String> introBrokerId = acc(AMP.tREQ("managedOrder.introBrokerId"), String.class);
}
