package xfe.icap.modules.tradesdata;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import xfe.amp.AmpMarketTrade;
import xfe.icap.amp.AmpDeal;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.tradesui.DealsViewUIModule;
import xfe.icap.modules.tradesui.TradesViewUIModule;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class TradesOrDealsPriceAggregateData {
    private final BigDecimal price;
    private final String loggedOnUserId;
    private final String loggedOnUserFirmId;
    private final Map<String, PriceAggregateData> dealsOrTrades = new HashMap<>();
    private final Map<String, PriceAggregateData> marketTrades = new HashMap<>();

    public TradesOrDealsPriceAggregateData(BigDecimal price, String userId, String firmId) {
        this.price = price;
        this.loggedOnUserId = userId;
        this.loggedOnUserFirmId = firmId;
    }

    public void addDeal(ObservableReplyRow row) {
        if (row.getValue(AmpDeal.dealNoSuffix) > 0 || DealsViewUIModule.getSide(row) == null) {
            return; // Dont consider deals with suffix value > 0
        }
        long dealNo = row.getValue(AmpDeal.dealNo);
        int factor = DealsViewUIModule.getSide(row) == OrderSide.SELL ? -1 : 1;
        boolean isMyDeal = row.getValue(AmpDeal.traderId).equals(loggedOnUserId);
        boolean isMyFirm = row.getValue(AmpDeal.firmId).equals(loggedOnUserFirmId);
        double quantity = row.getValue(AmpDeal.quantity);
        dealsOrTrades.put(dealNo + "", new PriceAggregateData(isMyDeal, isMyFirm, factor, quantity));
    }

    public void addMarketTrade(ObservableReplyRow row) {
        marketTrades.put(row.getValue(AmpMarketTrade.tradeNo),
                new PriceAggregateData(row.getValue(AmpMarketTrade.quantity)));
    }

    public void addTrade(ObservableReplyRow row) {
        OrderSide side = TradesViewUIModule.getSide(row);
        if (side == null) {
            return;
        }
        String tradeNo = row.getValue(AmpTrade.tradeNo);
        int factor = 1;
        boolean isMyTrade = false;
        boolean isMyFirm = false;
        switch (side) {
            case BUY:
                if (row.getValue(AmpTrade.buyTraderId).equals(loggedOnUserId)) {
                    isMyTrade = true;
                }
                if (row.getValue(AmpTrade.buyFirmId).equals(loggedOnUserFirmId)) {
                    isMyFirm = true;
                }
                break;
            case SELL:
                factor = -1;
                if (row.getValue(AmpTrade.sellTraderId).equals(loggedOnUserId)) {
                    isMyTrade = true;
                }
                if (row.getValue(AmpTrade.sellFirmId).equals(loggedOnUserFirmId)) {
                    isMyFirm = true;
                }
                break;
            default:
                throw new IllegalArgumentException("Not a valid Trade row");
        }
        dealsOrTrades.put(tradeNo, new PriceAggregateData(isMyTrade, isMyFirm, factor,
                row.getValue(AmpTrade.quantity).doubleValue()));
    }

    public BigDecimal getMarketQuantity() {
        ObjectProperty<BigDecimal> quantity = new SimpleObjectProperty<>(BigDecimal.ZERO);
        marketTrades.forEach((key, data) -> quantity.set(quantity.get().add(BigDecimal.valueOf(data.quantity))));
        return quantity.get();
    }

    public BigDecimal getMyFirmQuantity() {
        ObjectProperty<BigDecimal> quantity = new SimpleObjectProperty<>(BigDecimal.ZERO);
        dealsOrTrades.forEach((key, data) -> {
            if (data.isMyFirm) {
                quantity.set(quantity.get().add(BigDecimal.valueOf(data.quantity).multiply(BigDecimal.valueOf(data.factor))));
            }
        });
        return quantity.get();
    }

    public BigDecimal getMyQuantity() {
        ObjectProperty<BigDecimal> quantity = new SimpleObjectProperty<>(BigDecimal.ZERO);
        dealsOrTrades.forEach((key, data) -> {
            if (data.isMyDealOrTrade) {
                quantity.set(quantity.get().add(BigDecimal.valueOf(data.quantity).multiply(BigDecimal.valueOf(data.factor))));
            }
        });
        return quantity.get();
    }

    public BigDecimal getPrice() {
        return price;
    }

    public boolean removeDeal(ObservableReplyRow row) {
        dealsOrTrades.remove(row.getValue(AmpDeal.dealNo) + "");
        return dealsOrTrades.isEmpty();
    }

    public boolean removeTrade(ObservableReplyRow row) {
        dealsOrTrades.remove(row.getValue(AmpTrade.tradeNo));
        return dealsOrTrades.isEmpty();
    }

    public boolean removeMarketTrade(ObservableReplyRow row) {
        marketTrades.remove(row.getValue(AmpMarketTrade.tradeNo));
        return marketTrades.isEmpty();
    }

    class PriceAggregateData {
        private boolean isMyDealOrTrade;
        private boolean isMyFirm;
        private int factor = 1;
        private double quantity;

        public PriceAggregateData(boolean isMyDealOrTrade, boolean isMyFirm, int factor, double quantity) {
            this.isMyDealOrTrade = isMyDealOrTrade;
            this.isMyFirm = isMyFirm;
            this.factor = factor;
            this.quantity = quantity;
        }

        public PriceAggregateData(double quantity) {
            this.quantity = quantity;
        }
    }
}
