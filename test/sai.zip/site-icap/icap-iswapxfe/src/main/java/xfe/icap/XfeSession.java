package xfe.icap;

import com.nomx.persist.linelist.Participant;
import com.omxgroup.xstream.amp.AmpContactMethod;
import javafx.beans.InvalidationListener;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.types.*;
import xfe.icap.util.Dictionary;
import xfe.types.SecBoards;
import xfe.types.UiSession;
import xstr.amp.AMP;
import xfe.icap.amp.AmpContactMe;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xstr.session.*;
import xstr.util.Fun1Throws;
import xstr.util.Lazy;
import xstr.util.Resetter;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;
import xfe.module.Module;
import xfe.icap.modules.orderentry.EntryModule;
import xfe.icap.modules.iswaporders.OrderFilters;
import xfe.icap.ui.table.ColumnsUtil;

@Module.Autostart
public class XfeSession extends UiSession {
   static final Logger logger = LoggerFactory.getLogger(XfeSession.class);

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   public ObboFilters getObboFilters() {
      return obboFilters;
   }

   public OrderFilters getOrderFilters(){
      return orderFilters;
   }

   public ColumnsUtil getColumnsUtil() {
      return columnsUtil;
   }

   public ObjectProperty<EntryModule> getEntryModule() {
      return entryModuleProperty;
   }

   public void setEntryModule(EntryModule entryModule){
      entryModuleProperty.set(entryModule);
   }

   @Override
   protected void handleLogon(ServerSession session) {
      super.handleLogon(session);
         try {
            traderFirmMap = new Dictionary(session);
         } catch (Exception e) {
            if (session.isLoggedOnUserBroker()) {
               logger.error("Failed to initialise Broker/Trader Pairs: {}", e.toString());
            } else {
               logger.info("Failed to initialise Broker/Trader Pairs: {}", e.toString());
            }
         }
         //secBoards.get();
         obboFilters = new ObboFilters(XfeSession.this);
         orderFilters = new OrderFilters(XfeSession.this);
         columnsUtil = new ColumnsUtil(XfeSession.this);
   }

   @Override
   protected void handleLogoff() {
      super.handleLogoff();
      tracker.rollback();
      resetter.reset();
      if (traderFirmMap != null) {
         traderFirmMap.dispose();
         traderFirmMap = null;
         onBehalfTrader.set(null);
      }
   }

   public Future<XtrTransReply> callMe() throws AsnTypeException, AmpPermissionException {

      XtrTransRequest req = XtrTransRequestBuilder.create(AmpContactMe.txn, getUnderlyingSession())
         .set(AmpContactMe.contactMethod, AmpContactMethod.phone)
         .build();
      // TODO: FIX Mantis 63326 in case we are in Websocket mode and the session is locked
      // In this case we want the timeout error to log the original exception error to screen
      // instead of logging us off
      return getUnderlyingSession().execute(req);
   }

   public Future<XtrTransReply> ibMe() throws AsnTypeException, AmpPermissionException {
      XtrTransRequest req = XtrTransRequestBuilder.create(AmpContactMe.txn, getUnderlyingSession())
         .set(AmpContactMe.contactMethod, AmpContactMethod.instantMessage)
         .build();
      // TODO: FIX Mantis 63326 in case we are in Websocket mode and the session is locked
      // In this case we want the timeout error to log the original exception error to screen
      // instead of logging us off
      return getUnderlyingSession().execute(req);
   }

   public Future<Double> retrieveBestPrice(String boardId,String secId,boolean isBid){
      return retrieveSecBoardTrim2(boardId,secId).map(new Fun1Throws<QueryReplyRow, Double>() {
         @Override
         public Double call(QueryReplyRow queryReplyRow) {
            return isBid ? queryReplyRow.getValue(AmpIcapSecBoardTrim2.bidNonIndicPrice_d) : queryReplyRow.getValue(AmpIcapSecBoardTrim2.offerNonIndicPrice_d);
         }
      });
   }

   public Future<QueryReplyRow> retrieveSecBoardTrim2(String boardId, String secId){
      return secBoards.get().getSecBoard(secId,boardId).flatMap(secBoard -> {
         Long[] sortedIndexArray = {secBoard.getIndex()};
         XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req, getUnderlyingSession())
            .set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), sortedIndexArray)
            .build();
         return getUnderlyingSession().querySingleRow(req);
      });
   }

   public final BooleanProperty rfsPickup = new SimpleBooleanProperty(false);
   public final ObjectProperty<ObservableReplyRow> pickedUpRow = new fxext.SimpleObjectProperty<>();
   public final ObjectProperty<Participant> onBehalfTrader = new SimpleObjectProperty<Participant>(){
      @Override
      public void addListener(InvalidationListener l) {
//         Observables.logListeners(onBehalfTrader);
//         System.out.println("XfeSession.onBehalfTrader - Adding Listener: " + l);
//         if (l instanceof BindingHelperObserver) {
//            try {
//               Field field = BindingHelperObserver.class.getDeclaredField("ref");
//               field.setAccessible(true);
//               WeakReference ref = (WeakReference) field.get(l);
//
//               System.out.println("XfeSession.onBehalfTrader - With ref: " + ref.get());
//            } catch (NoSuchFieldException e) {
//               e.printStackTrace();
//            } catch (IllegalAccessException e) {
//               e.printStackTrace();
//            }
//         }
         super.addListener(l);
      }
   };
   private final Resetter resetter = new Resetter();

   public final Lazy<RfqMarketMakers> mmFirms = resetter.resets(new Lazy<RfqMarketMakers>() {
      @Override
      protected RfqMarketMakers initialize() {
         return new RfqMarketMakers(getUnderlyingSession());
      }
   });
   public final Lazy<Orders> orders = resetter.resets(new Lazy<Orders>() {
      @Override
      protected Orders initialize() {
         return new Orders(getUnderlyingSession(), tracker);
      }
   });
   public final Lazy<SecBoards> secBoards = resetter.resets(new Lazy<SecBoards>() {
      @Override
      protected SecBoards initialize() {
         return securitiesDataModule.getSecboards();
      }
   });
   public final Lazy<Rfqs> rfqs = resetter.resets(new Lazy<Rfqs>() {
      @Override
      protected Rfqs initialize() {
         return new Rfqs(getUnderlyingSession(),tracker);
      }
   });
   public final Lazy<FirmsAmp> firms = resetter.resets(new Lazy<FirmsAmp>() {
      @Override
      protected FirmsAmp initialize() {
         return new FirmsAmp(getUnderlyingSession());
      }
   });
   public Dictionary traderFirmMap;
   private final ObjectProperty<EntryModule> entryModuleProperty = new SimpleObjectProperty<>();
   private ObboFilters obboFilters;
   private OrderFilters orderFilters;
   private ColumnsUtil columnsUtil;
}
