package xfe.icap.modules.ordersdata;

import com.nomx.domain.types.OnLogoffAction;
import xfe.types.SecBoardStaticInfo;
import xstr.types.OrderSide;

import java.math.BigDecimal;

public class OrderEntryData {

   private DataMode dataMode;
   private String secCode;
   private String boardId;
   private OrderSide side;
   private BigDecimal price;
   private BigDecimal orderPrice;
   private String priceFormatted;
   private boolean allOrNone;
   private boolean iceberg;
   private boolean shared;
   private BigDecimal balance;
   private BigDecimal quantity;
   private BigDecimal defaultQuantity;
   private OnLogoffAction onLogoffAction;
   private boolean isDark;
   private boolean isPriceReversal = false;
   private boolean isTopcut;
   private Long orderId;
   private SecBoardStaticInfo staticInfo;
   private String orderTag;

   public void setSecCode(String secCode) {
      this.secCode = secCode;
   }

   public void setBoardId(String boardId) {
      this.boardId = boardId;
   }

   public String getSecCode() {
      return secCode;
   }

   public String getBoardId() {
      return boardId;
   }

   public void setSide(OrderSide side) { this.side = side; }

   public OrderSide getSide() { return side; }

   public BigDecimal getPrice() {
      return price;
   }

   public BigDecimal getOrderPrice() {
      return orderPrice;
   }

   public BigDecimal getQty() {
      return quantity;
   }

   boolean isAllOrNone() { return allOrNone; }

   boolean isIceberg() {
      return iceberg;
   }

   public DataMode getDataMode() {
      return dataMode;
   }

   public void setDataMode(DataMode dataMode) {
      this.dataMode = dataMode;
   }

   public boolean isShared() {
      return shared;
   }

   public boolean isTopcut() {
      return isTopcut;
   }

   public BigDecimal getBalance() {
      return balance;
   }

   public OnLogoffAction getOnLogoffAction() {
      return onLogoffAction;
   }

   public boolean isDark() { return isDark; }

   public void setPrice(BigDecimal price) { this.price = price; }

   public void setOrderPrice(BigDecimal orderPrice) { this.orderPrice = orderPrice; }

   public void setQty(BigDecimal quantity) { this.quantity = quantity; }

   public void setIsAllOrNone(boolean allOrNone) {
      this.allOrNone = allOrNone;
   }

   public void setIsIceberg(boolean iceberg) {
      this.iceberg = iceberg;
   }

   public void setIsShared(boolean shared) {
      this.shared = shared;
   }

   public void setBalance(BigDecimal balance) {
      this.balance = balance;
   }

   public void setActionOnLogoff(OnLogoffAction onLogoffAction) {
      this.onLogoffAction = onLogoffAction;
   }

   public void setIsDark(boolean isDark) { this.isDark = isDark; }

   public void setIsTopcut(boolean isTopcut) {
      this.isTopcut = isTopcut;
   }

   public String getPriceFormatted() {
      return priceFormatted;
   }

   public void setPriceFormatted(String priceFormatted) {
      this.priceFormatted = priceFormatted;
   }

   public void setIsPriceReversal(boolean b){ this.isPriceReversal = b; }

   public boolean isPriceReversal() { return isPriceReversal; }

   public Long getOrderId() {
      return orderId;
   }

   public void setOrderId(Long orderId) {
      this.orderId = orderId;
   }

   public BigDecimal getDefaultQuantity() {
      return defaultQuantity;
   }

   public void setDefaultQuantity(BigDecimal defaultQuantity) {
      this.defaultQuantity = defaultQuantity;
   }

   public SecBoardStaticInfo getStaticInfo() {
      return staticInfo;
   }

   public void setStaticInfo(SecBoardStaticInfo staticInfo) {
      this.staticInfo = staticInfo;
   }

   public String getOrderTag() {
      return orderTag;
   }

   public void setOrderTag(String orderTag) {
      this.orderTag = orderTag;
   }
}
