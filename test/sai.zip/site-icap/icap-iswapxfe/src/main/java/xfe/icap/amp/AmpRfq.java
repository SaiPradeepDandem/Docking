package xfe.icap.amp;

import java.util.Date;

import xstr.amp.AMP;
import xstr.amp.acc.AmpAccessor;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;

public class AmpRfq extends AmpAccessor {
   public static final  AmpQreq req = AMP.qREQ("rfqReq");
   public static final  AmpQrep rep = AMP.qREP("rfqRep");

   public static final AsnConversionAccessor<Long> rfqNo          = acc(AMP.qREP("rfqRep.rfqId.rfqNo"), Long.class);
   public static final AsnConversionAccessor<Date>    rfqDate        = acc(AMP.qREP("rfqRep.rfqId.rfqDate"), Date.class);
   public static final AsnAccessor secBoardId     = acc(AMP.qREP("rfqRep.secBoardId"           ));
   public static final AsnConversionAccessor<String>  secCode        = acc(AMP.qREP("rfqRep.secBoardId.secCode"   ), String.class);
   public static final AsnConversionAccessor<String>  boardId        = acc(AMP.qREP("rfqRep.secBoardId.boardId"   ), String.class);
   public static final AsnConversionAccessor<String>  parentSecCode        = acc(AMP.qREP("rfqRep.parentSecBoardId.secCode"   ), String.class);
   public static final AsnConversionAccessor<String>  parentBoardId        = acc(AMP.qREP("rfqRep.parentSecBoardId.boardId"   ), String.class);
   public static final AsnConversionAccessor<String>  userId         = acc(AMP.qREP("rfqRep.userId"               ), String.class);
   public static final AsnConversionAccessor<String>  groupId        = acc(AMP.qREP("rfqRep.groupId"              ), String.class);
   public static final AsnConversionAccessor<Double>  completionPct  = acc(AMP.qREP("rfqRep.completionPct"        ), Double.class);
   public static final AsnConversionAccessor<String>  swiftCode      = acc(AMP.qREP("rfqRep.swiftCode"            ), String.class);
   public static final AsnConversionAccessor<Double>  minQuantity    = acc(AMP.qREP("rfqRep.minQuantity"          ), Double.class);
   public static final AsnConversionAccessor<Double>  maxQuantity    = acc(AMP.qREP("rfqRep.maxQuantity"          ), Double.class);
   public static final AsnConversionAccessor<Integer> buySell        = acc(AMP.qREP("rfqRep.buySell"              ), Integer.class);
   public static final AsnConversionAccessor<Boolean> fullAmount     = acc(AMP.qREP("rfqRep.fullAmount"           ), Boolean.class);
   public static final AsnConversionAccessor<Integer> tradability    = acc(AMP.qREP("rfqRep.tradability"          ), Integer.class);
   public static final AsnConversionAccessor<Date>    startTime      = acc(AMP.qREP("rfqRep.startTime"            ), Date.class);
   public static final AsnConversionAccessor<Date>    endTime        = acc(AMP.qREP("rfqRep.endTime"              ), Date.class);
   public static final AsnConversionAccessor<Integer> status         = acc(AMP.qREP("rfqRep.status"               ), Integer.class);
   public static final AsnConversionAccessor<Boolean> isPublic         = acc(AMP.qREP("rfqRep.isPublicRFQ"        ), Boolean.class);
   public static final AsnConversionAccessor<Boolean> isAnonymous         = acc(AMP.qREP("rfqRep.anonymous"        ), Boolean.class);
   public static final AsnConversionAccessor<String>  mmFirmList         = acc(AMP.qREP("rfqRep.mmGroupList"       ), String.class);
   public static final AsnConversionAccessor<Date> bespokeIssueDate = acc(AMP.qREP("rfqRep.bespokeIssueDate"), Date.class);
   public static final AsnConversionAccessor<Date> bespokeMaturityDate = acc(AMP.qREP("rfqRep.bespokeMaturityDate"), Date.class);
}

