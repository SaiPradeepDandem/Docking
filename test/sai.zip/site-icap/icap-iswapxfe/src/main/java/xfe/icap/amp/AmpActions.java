package xfe.icap.amp;

import xstr.amp.AMP;
import xstr.amp.AsnAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.acc.AmpAccessor;

import java.util.Date;

public class AmpActions  extends AmpAccessor {
   public static final AMP.AmpQreq req = AMP.qREQ("actionsReq");
   public static final AMP.AmpQrep rep = AMP.qREP("actionsRep");

   public static final AsnConversionAccessor<String> actionId = acc(AMP.qREP("actionsRep.actionId"), String.class);
   public static final AsnConversionAccessor<Integer> msgType = acc(AMP.qREP("actionsRep.msgType"), Integer.class);
   public static final AsnConversionAccessor<String> message = acc(AMP.qREP("actionsRep.message"), String.class);
   public static final AsnAccessor secBoard = acc(AMP.qREP("actionsRep.secBoard"));
   public static final AsnConversionAccessor<String> secCode = acc(AMP.qREP("actionsRep.secBoard.secCode"), String.class);
   public static final AsnConversionAccessor<String> boardId = acc(AMP.qREP("actionsRep.secBoard.boardId"), String.class);
   public static final AsnConversionAccessor<String> groupId = acc(AMP.qREP("actionsRep.groupId"), String.class);
   public static final AsnConversionAccessor<String> userId = acc(AMP.qREP("actionsRep.userId"), String.class);
   public static final AsnConversionAccessor<Date> actionTime = acc(AMP.qREP("actionsRep.actionTime"), Date.class);

   public static String getMsgTypeAsString(Integer msgType){
      switch(msgType) {
         case 0:
            return "privatePhaseStarted";
         case 1:
            return "privatePhasePassiveOwner";
         case 2:
            return "privatePhaseAggressorOwner";
         case 3:
            return "publicPhaseStarted";
         case 4:
            return "publicPhasePassiveOwner";
         case 5:
            return "publicPhaseAgressorOwner";
         case 6:
            return "tradeOver";
         case 7:
            return "hitWhenClear";
         case 8:
            return "liftedWhenClear";
         case 9:
            return "topped";
         case 10:
            return "cut";
         case 11:
            return "workuptrade";
         case 12:
            return "stats";
         default:
            return "UNDEFINED";
      }
   }
}


