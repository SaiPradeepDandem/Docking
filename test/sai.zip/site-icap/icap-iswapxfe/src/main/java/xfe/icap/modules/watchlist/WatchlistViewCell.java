package xfe.icap.modules.watchlist;

import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;

class WatchlistViewCell extends ListCell<WatchlistView> {
   WatchlistViewCell() {
      getStyleClass().add("watchlist-select-cell");
      setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
   }

   @Override
   protected void updateItem(WatchlistView wv, boolean isEmpty) {
      super.updateItem(wv, isEmpty);

      if (!isEmpty && wv != null) {
         HBox menuItemHBox = new HBox();
         Label title = new Label(wv.getTitle());

         title.getStyleClass().add("xfe-title-2");
         menuItemHBox.getChildren().add(title);

         Label separator = new Label("|");

         menuItemHBox.getChildren().add(separator);

         Label subTitle = new Label(wv.getSubtitle());

         subTitle.getStyleClass().add("xfe-title-3");
         menuItemHBox.getChildren().add(subTitle);
         this.setGraphic(menuItemHBox);
      } else {
         setGraphic(null);
      }
   }
}
