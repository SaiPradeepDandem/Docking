package xfe.icap.modules.oco;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import xstr.util.concurrent.Future;

import xfe.types.UiSession;
import xstr.session.SessionListener;
import xfe.util.XfeAction;
import xfe.module.Module;
import xfe.icap.modules.actionsui.ActionsUIModule;

public class OcoModule implements Module,SessionListener {

	@ModuleDependency
    public UiSession xfeSession;

	@ModuleDependency
	public ActionsUIModule actions;

	@Override
	public Future<Void> handleLogon() {
		XfeAction ocoAction = new XfeAction();
		ocoAction.disableProperty().set(true);
		ocoAction.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				System.out.println("ON OCO");
			}
		});
		ocoAction.getStyleClass().add("xfe-icon-oco");
		actions.addAction(0, ocoAction);
      return DONE;
	}

	@Override
	public void handleLogoff() {
		uninitializeContents();
	}

	private void uninitializeContents() {
		// TODO Auto-generated method stub

	}
}
