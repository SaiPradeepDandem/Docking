package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnConversionAccessor;

public class AmpContactMe extends AmpAccessor {
   public static final AmpTreq txn = AMP.tREQ("contactMe");

   public static final AsnConversionAccessor<Integer> contactMethod = acc(AMP.tREQ("contactMe.contactMethod"), Integer.class);
}
