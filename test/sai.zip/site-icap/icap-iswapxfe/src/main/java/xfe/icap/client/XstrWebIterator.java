package xfe.icap.client;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xmp.message.XMP.XmpQueryRequest;
import xmp.message.XMP.XmpQueryRequest.Builder;
import xmp.message.XMP.XmpReplyRow;
import xstr.util.Require;
import xstr.util.concurrent.*;
import xstr.util.exception.AsnTypeException;

import xstr.session.XtrQueryRequestContext;
import xstr.session.SessionWrapper;
import xstr.session.XtrQueryReply;
import xstr.session.XtrReplyRow;
import xstr.session.XtrSingleIterator;
import com.omxgroup.xstream.amp.AmpQueryReqChoice;
import com.omxgroup.xstream.api.QueryRequest;
import xstr.icap.csdk.ICAP;

public class XstrWebIterator extends DisposableBase implements XtrSingleIterator {
   private static final Logger logger = LoggerFactory.getLogger(XstrWebIterator.class);
   private final XstrWebConnection connection;
   private final XtrQueryRequestContext context;
	private final SessionWrapper session;
   private final Builder reqBuilder;

   public XstrWebIterator(SessionWrapper webSession, XstrWebConnection webConnection, XtrQueryRequestContext context) throws AsnTypeException {
      Require.argNotNull(webConnection);
      this.connection = webConnection;
      this.session = webSession;
      this.context = context;
      QueryRequest rawRequest = new QueryRequest((AmpQueryReqChoice) context.getRequest().getData());
      String subjectUser = context.getRequest().getSubjectUser();
      XmpQueryRequest xmpQueryRequest = ICAP.tsmrToXmp(rawRequest, context.getCookie());
      this.reqBuilder = XmpQueryRequest.newBuilder(xmpQueryRequest);
      if (subjectUser != null && !subjectUser.isEmpty()) {
         reqBuilder.setSubjectUser(subjectUser);
      }
   }


   @Override
   public Future<List<XtrQueryReply>> next() {
      session.resetLastSendTime();
      return connection.queryHandler.request(reqBuilder.build()).map(replyBatch -> {
         session.resetLastReceiveTime();
         Date timestamp = new Date();
         ArrayList<XtrQueryReply> reps = new ArrayList<>();
         for (XmpReplyRow rawReply : replyBatch.getRowList()) {
            try {
               XtrReplyRow row = new XtrReplyRow(rawReply, replyBatch.getId(), timestamp);
               session.getStats().addRep(row.getData());
               reps.add(row);
            } catch (Exception e) {
               logger.error("Error creating Reply object from message", e);
            }
         }
         reqBuilder.setCookie(replyBatch.getCookie());
         context.setCookie(replyBatch.getCookie().toByteArray());
         return reps;
      });
   }

}
