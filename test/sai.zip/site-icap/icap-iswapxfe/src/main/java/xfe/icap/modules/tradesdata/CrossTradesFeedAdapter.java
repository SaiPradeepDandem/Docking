package xfe.icap.modules.tradesdata;

import com.omxgroup.xstream.api.MarshalError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpDeepCopy;
import xfe.icap.amp.AmpTrade;
import xstr.session.*;
import xstr.types.OrderSide;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class CrossTradesFeedAdapter implements QueryFeed {
   private static final Logger logger = LoggerFactory.getLogger(CrossTradesFeedAdapter.class);

   public CrossTradesFeedAdapter() {
     listener = feedEvents -> {
         List<QueryRowEvent> handledfeedEvents = new ArrayList<>();
         QueryRowEvent ev1;
         QueryRowEvent ev2;
         //AsnWrapper<Asn1Type> tradeId;
         for (QueryRowEvent ev : feedEvents) {
            switch (ev.getEventType()) {
               case CREATE:
                  QueryReplyRow row = ev.getNewRow();

                  // Checking if we have both buyTraderId and sellTraderId
                  // in that case we need to generate two trades from the
                  // single trade row, one per side
                  String buyTraderId = row.getValue(AmpTrade.buyTraderId);
                  String sellTraderId = row.getValue(AmpTrade.sellTraderId);
                  if (buyTraderId != null && !buyTraderId.isEmpty() &&
                     sellTraderId != null && !sellTraderId.isEmpty()) {

                     //tradeId = new AsnWrapper<>(ev.getNewRow().getAsn(AmpTrade.tradeId));
                     QueryReplyRow sellRow = null;
                     try {
                        sellRow = new AbstractQueryReplyRow(row.getKey().genSubKey(),
                           AmpDeepCopy.copy(row.getData()),
                           row.getTimestamp()) {
                           @Override
                           public XtrQueryRequest getRequest() {
                              return null;
                           }
                        };
                     } catch (MarshalError marshalError) {
                        marshalError.printStackTrace();
                     }

                     blankSide(row, OrderSide.SELL);
                     ev1 = QueryRowEvent.create(row);
                     handledfeedEvents.add(ev1);

                     if (sellRow != null) {
                        blankSide(sellRow, OrderSide.BUY);
                        ev2 = QueryRowEvent.create(sellRow);
                        handledfeedEvents.add(ev2);
                     }
                  } else {
                     handledfeedEvents.add(ev);
                  }

                  break;
               default:
                  handledfeedEvents.add(ev);
                  break;
            }
         }

         for (QueryFeedListener l : listeners) {
            try {
               l.handleEvent(handledfeedEvents);
            } catch (Exception e) {
               logger.error("Error while processing events:", e);
            }
         }
      };
   }

   @Override
   public void addContListener(QueryFeedListener sink) {
      listeners.add(sink);
   }

   @Override
   public void addListener(QueryFeedListener sink) {
      listeners.add(sink);
   }

   @Override
   public void removeListener(QueryFeedListener sink) {
      listeners.remove(sink);
      // Send idle event
      sink.handleEvent(Collections.emptyList());
   }

   @Override
   public void dispose() {

   }

   public QueryFeedListener getFeedListener() {
      return listener;
   }

   private void blankSide(QueryReplyRow row, OrderSide side) {
      AmpTrade.getOneSideAccessors(side).forEach(acc -> acc.setFromBase(row.getData(), null));
   }

   private final HashSet<QueryFeedListener> listeners = new HashSet<>();
   private final QueryFeedListener listener;
}
