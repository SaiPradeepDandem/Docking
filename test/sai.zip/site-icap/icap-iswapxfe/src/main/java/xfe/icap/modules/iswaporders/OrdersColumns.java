package xfe.icap.modules.iswaporders;

import static xfe.ui.table.Cells.asnBooleanCell;
import static xfe.ui.table.Cells.asnEmptyZeroNumberCell;
import static xfe.ui.table.Cells.asnNumberCell;
import static xfe.ui.table.Cells.asnStringCell;

import java.lang.ref.WeakReference;

import javafx.scene.control.TableColumn.CellDataFeatures;
import xstr.session.QueryReplyRow;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.util.Fun1;
import xstr.util.Proc2;

import xfe.icap.types.BuySellDecorator;
import xfe.types.OrdersTrans;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ServerSession;
import xstr.util.Fx;
import xstr.util.MoreBindings;
import xstr.util.ValueOnNode;
import xfe.util.scene.control.NodeFlashDecorator;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpManagedOrder;
import xfe.util.XfeAction;
import xstr.session.ObservableReplyRow;
import xfe.util.Constants;
import xfe.icap.ui.table.AsnOrdersDurationValueFactory;
import xfe.ui.table.DynamicTableCell;
import xfe.ui.table.TableCellFactory;
import xfe.ui.table.TableCellFactory.Me;
import xfe.ui.table.ObsRowActionCell;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AmpOrderVerb;

public class OrdersColumns implements Constants{
   private static final long REMAINING_TIME_TO_FLASH = 1000 * 10; //10 seconds
   private final XfeSession xfeSession;
   private static final Logger logger = LoggerFactory.getLogger(OrdersColumns.class);
   private static final ValueOnNode<TableCell<?, ?>, BooleanProperty> cellSelectedPropertyOnNode = new ValueOnNode<TableCell<?, ?>, BooleanProperty>() {
      @Override
      protected BooleanProperty initialise(TableCell<?, ?> cell) {
         return new SimpleBooleanProperty(false);
      }
   };

   private static final Fun1<ObservableReplyRow, ObservableBooleanValue> rowAvailableAccessor = new Fun1<ObservableReplyRow, ObservableBooleanValue>() {
      @Override
      public ObservableBooleanValue call(ObservableReplyRow row) {
         return Fx.valueOf(row != null);
      }
   };

   OrdersColumns(XfeSession xfeSession) {
      this.xfeSession = xfeSession;
   }

   static TableColumn<ObservableReplyRow, String> createInstrumentColumn(
      Property<Runnable> interrogationActionProperty,
      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> cellAction) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnStringCell(AmpManagedOrder.secCode)))
      .strong()
      .annotate(cellSelectedPropertyOnNode, interrogationActionProperty, cellAction, rowAvailableAccessor)
      .textTooltip()
      .basic().setCellFactoryIn(col);
      col.setText(COLUMN_NAME_INSTR);
      col.setPrefWidth(147);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createPayRecColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
            DynamicTableCell.defaultCell(BuySellDecorator.fromOrderVerb(AmpManagedOrder.buySell));
      TableCellFactory.of(buySellStyle(cell, true))
      .textTooltip()
      .basic().setCellFactoryIn(col);
      col.setText("P/R");
      col.setPrefWidth(35);
      col.setResizable(false);

      return col;
   }

   static TableColumn<ObservableReplyRow, String> createRateColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnNumberCell(AmpManagedOrder.price_d)))
      .textTooltip()
      .basic().setCellFactoryIn(col);
   	  col.setText(Constants.COLUMN_NAME_RATE);
      col.setPrefWidth(61);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createBalanceColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnNumberCell(AmpManagedOrder.balance_d)))
      .textTooltip()
      .basic().setCellFactoryIn(col);
      col.setText("Balance");
      col.setPrefWidth(58);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createStatusColumn(ObservableBooleanValue isFlash) {
	  AsnConversionAccessor<Integer> orderStatusAccessor = AmpManagedOrder.orderStatus;
	  TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
            DynamicTableCell.defaultCell(OrderStatusDecorator.orderStatus(orderStatusAccessor));

      Me<ObservableReplyRow, String, DynamicTableCell<ObservableReplyRow, String>> local = TableCellFactory.of(buySellStyle(cell));
      TableCellFactory.of(statusFlashStyle(local, isFlash))
      .textTooltip()
      .basic().setCellFactoryIn(col);
      col.setText("Status");
      col.setPrefWidth(49);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createAmendTimeColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnStringCell(AmpManagedOrder.amendTime)))
      .textTooltip()
      .setCellFactoryIn(col);
   	  col.setText("Am. Time");
      col.setPrefWidth(68);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createTraderColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnStringCell(AmpManagedOrder.userId)))
      .textTooltip()
      .setCellFactoryIn(col);
      col.setText("Trader");
      col.setPrefWidth(76);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createBrokerColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
         DynamicTableCell.defaultCell(brokerValueFactory());
      TableCellFactory.of(buySellStyle(cell))
         .textTooltip()
         .setCellFactoryIn(col);
      col.setText("Broker");
      col.setPrefWidth(76);
      col.setResizable(false);
      return col;
   }

   private static Callback<QueryReplyRow, ObservableObjectValue<String>> brokerValueFactory() {
      return row -> {
         String brokerId = row.getValue(AmpManagedOrder.operatorId);
         if (brokerId == null || brokerId.isEmpty()) {
            brokerId = row.getValue(AmpManagedOrder.introBrokerId);
         }
         if (brokerId == null) brokerId = "";
         return Fx.constOf(brokerId);
      };
   }

   static TableColumn<ObservableReplyRow, String> createDurationColumn(XfeSession xfeSession, double prefWidth) {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      Callback<TableColumn<ObservableReplyRow, String>, DynamicTableCell<ObservableReplyRow, String>> cell =
            DynamicTableCell.defaultCell(new AsnOrdersDurationValueFactory(xfeSession.getUnderlyingSession().teClock));
      TableCellFactory.of(buySellStyle(cell))
      .textTooltip()
      .flashStyle()
      .toggleStyle(NodeFlashDecorator.FLASH_TOKEN, xfeSession.getColumnsUtil().flashOnLastMinute(AmpManagedOrder.expiryTime, REMAINING_TIME_TO_FLASH))
      .basic().setCellFactoryIn(col);
      col.setText("Duration");
      col.setPrefWidth(prefWidth);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, Boolean> createDoneIfTouchedColumn(double prefWidth) {
      TableColumn<ObservableReplyRow, Boolean> col = new TableColumn<>();
      col.setCellFactory(asnBooleanCell(AmpManagedOrder.isDoneIfTouched, false));
      col.setText("DIT");
      col.setPrefWidth(prefWidth);
      col.setResizable(false);
      return col;
   }

   static TableColumn<ObservableReplyRow, String> createFirmColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnStringCell(AmpManagedOrder.firmId)))
         .textTooltip()
         .basic().setCellFactoryIn(col);
      col.setText("Firm");
      col.setPrefWidth(70);
      col.setResizable(false);
      return col;
   }


   TableColumn<ObservableReplyRow, XfeAction> createReferColumn(ServerSession session) {
      TableColumn<ObservableReplyRow, XfeAction> col = new TableColumn<>();
      col.setCellFactory(ObsRowActionCell.factory());
      col.setCellValueFactory(referActionValueFactory(session));
      col.setPrefWidth(37);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createMinFillPopupColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnEmptyZeroNumberCell(AmpManagedOrder.minFillQuantity)))
      .textTooltip()
      .basic().setCellFactoryIn(col);
      col.setText("Min Clip");
      col.setPrefWidth(120);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, Boolean> createBrokerAnonPopupColumn() {
      TableColumn<ObservableReplyRow, Boolean> col = new TableColumn<>();
      col.setCellFactory(asnBooleanCell(AmpManagedOrder.isPublic, true));
      col.setText("Broker Anon");
      col.setPrefWidth(120);
      col.setResizable(false);
      // The line below does not work - we will raise a JIRA for JavaFX
      //col.getStyleClass().add("symbol"); //
      return col;
   }

   TableColumn<ObservableReplyRow, Boolean> createSharedPopupColumn() {
      TableColumn<ObservableReplyRow, Boolean> col = new TableColumn<>();
      col.setCellFactory(asnBooleanCell(AmpManagedOrder.shared, false));
      col.setText("Shared");
      col.setPrefWidth(120);
      col.setResizable(false);
      // The line below does not work - we will raise a JIRA for JavaFX
      //col.getStyleClass().add("symbol"); //
      return col;
   }

   TableColumn<ObservableReplyRow, String> createIcebergPopupColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnEmptyZeroNumberCell(AmpManagedOrder.visibleQuantity)))
      .textTooltip()
      .style("xfe-type-cell")
      .basic().setCellFactoryIn(col);
      col.setText("Visible Qty");
      col.setPrefWidth(120);
      col.setResizable(false);
      return col;
   }

   TableColumn<ObservableReplyRow, String> createEditorPopupColumn() {
      TableColumn<ObservableReplyRow, String> col = new TableColumn<>();
      TableCellFactory.of(buySellStyle(asnStringCell(AmpManagedOrder.updateOperatorId)))
      .textTooltip()
      .style("xfe-type-cell")
      .basic().setCellFactoryIn(col);
      col.setText("Last Editor");
      col.setPrefWidth(120);
      col.setResizable(false);
      return col;
   }

   public static final String REFERRED_ORDER_STYLE = "faded";
   private static final String RENEW_ACTION_STYLE = "action-renew";

   private static class OrderStatusFlashBinding extends StringBinding {
	   ObservableBooleanValue isEmbargoed = Fx.valueOf(false);
	   ObservableBooleanValue isFlash = Fx.valueOf(false);

	   OrderStatusFlashBinding(ObservableBooleanValue isFlash) {
		   this.isFlash = isFlash;
	   }

	   @Override
	   protected String computeValue() {
		   return isEmbargoed.get() && isFlash.getValue() ? "cell-flashing" : "";
	   }

	   public void setRow(ObservableReplyRow row) {
		   super.unbind(isEmbargoed, isFlash);
		   if (row != null)
			   isEmbargoed = OrderFilters.isEmbargoed.accept(row);
		   else
			   isEmbargoed = Fx.valueOf(false);
		   super.bind(isEmbargoed, isFlash);
		   invalidate();
	   }
   }

   private static class OrderStyleBinding extends StringBinding {
      int orderVerb = AmpOrderVerb.buyorsell;
      ObservableBooleanValue isReferred = Fx.valueOf(false);
      private final boolean ignoreReferred;
      OrderStyleBinding(boolean ignoreReferred) {
         this.ignoreReferred = ignoreReferred;
      }

      @Override
      protected String computeValue() {
         if (!ignoreReferred && isReferred.get()) {
            return REFERRED_ORDER_STYLE;
         }

         switch (orderVerb) {
         case AmpOrderVerb.buy:
            return BUY_STYLE;
         case AmpOrderVerb.sell:
            return SELL_STYLE;
         default:
            return "";
         }
      }

      public void setRow(ObservableReplyRow row) {
         super.unbind(isReferred);

         if (row != null) {
            orderVerb = row.getValue(AmpManagedOrder.buySell);
            isReferred = OrderFilters.isReferred.accept(row);
         } else {
            orderVerb = AmpOrderVerb.buyorsell;
            isReferred = Fx.valueOf(false);
         }

         super.bind(isReferred);
         invalidate();
      }
   }

   private static <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> statusFlashStyle(Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory,
                                                                                                                                   ObservableBooleanValue isFlash) {
	   return column -> {
           U cell = wrappedCellFactory.call(column);

           OrderStatusFlashBinding flashStyle = new OrderStatusFlashBinding(isFlash);

           flashStyle.addListener((obsVal, oldStyle, newStyle) -> {

               if (oldStyle != null && !oldStyle.isEmpty()) {
                   cell.getStyleClass().remove(oldStyle);
               }

               if (newStyle != null && !newStyle.isEmpty()) {
                   cell.getStyleClass().add(newStyle);
               }
           });

           InvalidationListener l = observable -> {
               int idx = cell.getIndex();

               if (idx < 0 || idx >= cell.getTableView().getItems().size()) {
                   flashStyle.setRow(null);
               } else {
                   flashStyle.setRow(cell.getTableView().getItems().get(idx));
               }
           };

           cell.itemProperty().addListener(l);

           return cell;
       };
   }

   private static <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> buySellStyle(Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory) {
      return buySellStyle(wrappedCellFactory, false);
   }

   private static <T, U extends TableCell<ObservableReplyRow, T>> Callback<TableColumn<ObservableReplyRow, T>, U> buySellStyle(Callback<TableColumn<ObservableReplyRow, T>, U> wrappedCellFactory, boolean ignoreReferred) {
      return column -> {
         U cell = wrappedCellFactory.call(column);
         OrderStyleBinding orderStyle = new OrderStyleBinding(ignoreReferred);

         orderStyle.addListener((obsVal, oldStyle, newStyle) -> {
            if (oldStyle != null && !oldStyle.isEmpty()) {
               cell.getStyleClass().remove(oldStyle);
            }

            if (newStyle != null && !newStyle.isEmpty()) {
               cell.getStyleClass().add(newStyle);
            }
         });

         InvalidationListener l = observable -> {
            int idx = cell.getIndex();

            if (idx < 0 || idx >= cell.getTableView().getItems().size()) {
               orderStyle.setRow(null);
            } else {
               orderStyle.setRow(cell.getTableView().getItems().get(idx));
            }
         };

         cell.itemProperty().addListener(l);

         return cell;
      };
   }

   private Callback<CellDataFeatures<ObservableReplyRow,XfeAction>, ObservableValue<XfeAction>> referActionValueFactory(ServerSession session) {
      return data -> {
         ObservableReplyRow row = data.getValue();
         WeakReference<ObservableReplyRow> rowRef = new WeakReference<>(row);
         ObservableBooleanValue canRefer = Bindings.and(OrderFilters.isStatusReferable.accept(row) , xfeSession.getOrderFilters().isAmendable.accept(row));
         ObservableBooleanValue canRenew = Bindings.and(OrderFilters.canRenew.accept(row) ,xfeSession.getOrderFilters().isAmendable.accept(row));
         ObservableBooleanValue notClone = OrderFilters.notClonedOrder.accept(row);

         XfeAction action = new XfeAction();

         action.setOnAction(actionEvent -> {
            ObservableReplyRow r = rowRef.get();
            if (r == null) {
               action.setOnAction(null);
               return;
            }
            Asn1Type orderId = r.getAsn(AmpManagedOrder.currentOrderId);
            String userId = r.getValue(AmpManagedOrder.userId);

            if (canRenew.get()) {
               OrdersTrans.activate(session, orderId,userId);
            } else {
               OrdersTrans.deactivate(session, orderId,userId);
            }
         });

         MoreBindings.addConditional(action.getStyleClass(), CELL_STYLE_REFER, canRefer);
         MoreBindings.addConditional(action.getStyleClass(), RENEW_ACTION_STYLE, canRenew);
         action.setText("R");

         action.availableProperty().bind(Bindings.and(notClone,Bindings.or(canRefer, canRenew)));
         return Fx.constOf(action);
      };
   }
}
