package xfe.icap.util;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;
import xstr.util.Fx;

import static xfe.icap.util.Toaster.Type.ERROR;
import static xfe.icap.util.Toaster.Type.INFO;

/**
 * Created by soopot on 10/1/2019.
 *
 * @author Sooraj Pottekat
 */
public class Toaster {

   private static final int DEFAULT_DURATION = 10;
   private static final int DEFAULT_TEXT_SIZE = 40;

   enum Type{
      INFO,ERROR
   }

   public static void toastInfo(String title, String message, int durationInSec, EventHandler<ActionEvent> action){
      toast(title,message,durationInSec,action, INFO);
   }

  public static void toastInfo(String title, String message) {
      toastInfo(title,message, DEFAULT_DURATION,null);
  }
   public static void toastError(String title, String message,int durationInSec, EventHandler<ActionEvent> action){
      toast(title,message,durationInSec,action, ERROR);
   }

   public static void toastError(String title, String message) {
      toastError(title, message, DEFAULT_DURATION,null);
   }

   private static void toast(String title, String message,int durationInSec, EventHandler<ActionEvent> action, Type type){
      Notifications toast =
         Notifications.create().darkStyle().title(title).text(WordWrap.wrap(message, DEFAULT_TEXT_SIZE))
                      .hideAfter(Duration.seconds(durationInSec)).position(Pos.BOTTOM_RIGHT);
      if(action != null){
         toast.onAction(action);
      }
      switch (type){
         case INFO:
            Fx.runLater(() -> toast.showInformation());
            break;
         case ERROR:
            Fx.runLater(() -> toast.showError());
            break;
         default:
            Fx.runLater(() -> toast.show());
            break;
      }
   }
}
