package xfe.icap.modules.iswaptrades;

import com.objsys.asn1j.runtime.Asn1Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.amp.AsnWrapper;
import xfe.icap.amp.AmpTrade;
import xstr.session.*;

import java.util.*;

/**
 * This adapter do two things:
 * <li>create trades forest and hashmap tradeid to node
 * <li>keep a set which the tradeid is received (due to parent tradeId from the trade), while the trade itself is not received yet. <br>
 * So once such trade arrives, all its children need be "deleted" and "recreated" to keep trade view display correct for the legs and strategies.
 * @author jiadin
 */
public class TradesFeedAdapter implements QueryFeed {
   private static final Logger logger = LoggerFactory.getLogger(TradesFeedAdapter.class);
   private final String userId;

   /**
    * One trade may have at most one parent, may have list of child.
    */
   class TradeNode {
      TradeNode(AsnWrapper<Asn1Type> tradeId, AsnWrapper<Asn1Type> buyParentId, AsnWrapper<Asn1Type> sellParentId, QueryReplyRow queryReplyRow) {
         this.tradeId = tradeId;
         this.buyParentId = buyParentId;
         this.sellParentId = sellParentId;
         this.row = queryReplyRow;
         tradeNodeMap.put(tradeId, this);
      }

      void addChild(TradeNode childId) {
         children.add(childId);
      }

      boolean isChildOf(AsnWrapper<Asn1Type> parentId) {
         if (buyParentId == null && sellParentId == null ) return false;

         if(parentId.equals(buyParentId) || parentId.equals(sellParentId)) return true;

         TradeNode buyNode = tradeNodeMap.get(buyParentId);
         if (buyNode != null && buyNode.isChildOf(parentId)) return true;

         TradeNode sellNode = tradeNodeMap.get(sellParentId);
         return sellNode != null && sellNode.isChildOf(parentId);

      }
      final AsnWrapper<Asn1Type> tradeId;
      final List<TradeNode> children = new ArrayList<>(2);
      AsnWrapper<Asn1Type> buyParentId;
      AsnWrapper<Asn1Type> sellParentId;
      QueryReplyRow row;  //if row is null, indicates that the trade transaction is not received yet
   }

   public TradesFeedAdapter(QueryFeed feed, String loggedOnUser) {
      this.userId = loggedOnUser;
      listener = new QueryFeedListener() {

         @Override
         public void handleEvent(List<QueryRowEvent> feedEvents) {
            List<QueryRowEvent> handledfeedEvents = new ArrayList<>();
            for (QueryRowEvent ev : feedEvents) {
               AsnWrapper<Asn1Type> myId;
               switch (ev.getEventType()) {
               case CREATE:

                  myId = new AsnWrapper<>(ev.getNewRow().getAsn(AmpTrade.tradeId));
                  Asn1Type asnBuyParent = null;
                  Asn1Type asnSellParent = null;

                  String buyTraderId = ev.getNewRow().getValue(AmpTrade.buyTraderId);
                  if (userId.equals(buyTraderId))
                     asnBuyParent = ev.getNewRow().getAsn(AmpTrade.buyStrategyTradeId);

                  String sellTraderId = ev.getNewRow().getValue(AmpTrade.sellTraderId);
                  if (userId.equals(sellTraderId))
                     asnSellParent = ev.getNewRow().getAsn(AmpTrade.sellStrategyTradeId);

                  AsnWrapper<Asn1Type> buyParent_create = null;
                  AsnWrapper<Asn1Type> sellParent_create = null;
                  TradeNode node;
                  if (asnBuyParent != null) {
                     buyParent_create = new AsnWrapper<>(asnBuyParent);
                  }
                  if (asnSellParent != null) {
                     sellParent_create = new AsnWrapper<>(asnSellParent);
                  }

                  // The trade identified by myId has just arrived
                  // We need to generate "delete" event for all of its children and then
                  // then generate add for the trade and then
                  // re-generate "add" events for all of its children
                  // to keep "trades view" display such that strategy appears before its legs
                  if (notArrivedTrades.remove(myId)) {
                     node = tradeNodeMap.get(myId);
                     node.row = ev.getNewRow();
                     regenerateEvent(node, ev, handledfeedEvents);
                  } else {
                     node = new TradeNode(myId, buyParent_create, sellParent_create, ev.getNewRow());
                     handledfeedEvents.add(ev);
                  }

                  checkParent(buyParent_create, node);
                  checkParent(sellParent_create, node);

                  break;
               case CLEAR:
                  tradeNodeMap.clear();
                  notArrivedTrades.clear();
                  break;
               case DELETE:
                  myId = new AsnWrapper<>(ev.getOldRow().getAsn(AmpTrade.tradeId));
                  notArrivedTrades.remove(myId);
                  regenerateEvent(tradeNodeMap.get(myId), ev, handledfeedEvents);
                  removeNode(myId);
                  break;
               case UPDATE:
                  myId = new AsnWrapper<>(ev.getNewRow().getAsn(AmpTrade.tradeId));
                  node = tradeNodeMap.get(myId);
                  if (node != null)
                     node.row = ev.getNewRow();
                  handledfeedEvents.add(ev);
                  break;
               case UNKNOWN:
               default:
                  break;
               }
            }

//            for (QueryRowEvent ev: handledfeedEvents) {
//               System.out.println("Event Type Is " + ev.getEventType());
//               if (ev.getEventType() == XtrQueryReplyCommand.DELETE) {
//                  System.out.println("ID Is " + ev.getOldRow().getAsn(AmpTrade.tradeNo));
//                  System.out.println("secCode Is " + ev.getOldRow().getAsn(AmpTrade.secCode));
//                  System.out.println("qty Is " + ev.getOldRow().getValue(AmpTrade.quantity));
//               }
//               if (ev.getEventType() == XtrQueryReplyCommand.CREATE) {
//                  System.out.println("ID Is " + ev.getNewRow().getAsn(AmpTrade.tradeNo));
//                  System.out.println("secCode Is " + ev.getNewRow().getAsn(AmpTrade.secCode));
//                  System.out.println("qty Is " + ev.getNewRow().getValue(AmpTrade.quantity));
//               }
//            }

            for (QueryFeedListener l : listeners) {
               try {
                  l.handleEvent(handledfeedEvents);
               } catch (Exception e) {
                  logger.error("Error while processing events:", e);
               }
            }
         }

         private void removeNode(AsnWrapper<Asn1Type> myId) {
            TradeNode node = tradeNodeMap.remove(myId);

            if (node.sellParentId != null) {
               TradeNode sellParent = tradeNodeMap.get(node.sellParentId);
               if (sellParent != null) sellParent.children.removeIf(tradeNode -> myId.equals(tradeNode.tradeId));
            }

            if (node.buyParentId != null) {
               TradeNode buyParent = tradeNodeMap.get(node.buyParentId);
               if (buyParent != null) buyParent.children.removeIf(tradeNode -> myId.equals(tradeNode.tradeId));
            }

            for( TradeNode child: node.children) {
               if (child.sellParentId == myId) child.sellParentId = null;
               if (child.buyParentId == myId) child.buyParentId = null;
            }

            node.children.clear();
         }

      private void checkParent(AsnWrapper<Asn1Type> parent, TradeNode node) {
    	  if (parent != null) {
    		  TradeNode parentNode = tradeNodeMap.get(parent);
    		  if (parentNode == null) {
    			  parentNode = new TradeNode(parent, null,null, null);
    		  }

    		  if (parentNode.row == null) { // which indicate the trade transaction is not handled by system yet
              notArrivedTrades.add(parent);
           }

    		  parentNode.addChild(node);
    	  }
      }

         /**
          * add "delete" event of all children, add the event itself and then add "create" event of all children.
          * @param evt the event
          * @param handledfeedEvents the events
          */
         private void regenerateEvent(TradeNode node, QueryRowEvent evt, List<QueryRowEvent> handledfeedEvents) {

            List<TradeNode> children = node.children;
            for (TradeNode child : children) {
               generateEvent(child, handledfeedEvents, false);
            }
            handledfeedEvents.add(evt);
            for (TradeNode child : children) {
               generateEvent(child, handledfeedEvents, true);
            }
         }

         /**
          *
          * @param node the trade
          * @param isCreate create or delete flag
          * @param handledfeedEvents the events
          *           true: "create" event, false, "delete" event
          */
         private void generateEvent(TradeNode node, List<QueryRowEvent> handledfeedEvents, boolean isCreate) {
            if (node.row != null) {
               QueryRowEvent artificialEvt;
               if (isCreate)
                  artificialEvt = QueryRowEvent.create(node.row);
               else
                  artificialEvt = QueryRowEvent.delete(node.row);
               handledfeedEvents.add(artificialEvt);
            }

            List<TradeNode> children = node.children;
            for (TradeNode child : children) {
               generateEvent(child, handledfeedEvents, isCreate);
            }

         }
      };
      this.srcFeed = feed;
   }

   public void startPolling() {
	   srcFeed.addListener(listener);
   }

   public void stopPolling() {
	   srcFeed.removeListener(listener);
   }

   @Override
   public void addContListener(QueryFeedListener sink) {
      listeners.add(sink);
   }

   @Override
   public void addListener(QueryFeedListener sink) {
      listeners.add(sink);
   }

   @Override
   public void removeListener(QueryFeedListener sink) {
      listeners.remove(sink);
      // Send idle event
      sink.handleEvent(Collections.emptyList());
   }

   @Override
   public void dispose() {
      srcFeed.removeListener(listener);
      listeners.clear();
      notArrivedTrades.clear();
      tradeNodeMap.clear();
   }

   private List<AsnWrapper<Asn1Type>> getImmediateParentIds(AsnWrapper<Asn1Type> tradeId) {
	   List<AsnWrapper<Asn1Type>> list = new LinkedList<>();

	   TradeNode node = tradeNodeMap.get(tradeId);

	   if (node.buyParentId != null)
		   list.add(node.buyParentId);

	   if (node.sellParentId != null && !node.sellParentId.equals(node.buyParentId))
		   list.add(node.sellParentId);

	   return list;
   }

   List<AsnWrapper<Asn1Type>> getNLevelParentIds(AsnWrapper<Asn1Type> tradeId,
                                                 int level) {
	   if (level == 0) {
		   List<AsnWrapper<Asn1Type>> list = new LinkedList<>();
		   list.add(tradeId);
		   return list;
	   }

	   if (level == 1) {
		   return getImmediateParentIds(tradeId);
	   }

	   Set<AsnWrapper<Asn1Type>> set = new HashSet<>();
	   List<AsnWrapper<Asn1Type>> list = getNLevelParentIds(tradeId, --level);

	   for (AsnWrapper<Asn1Type> id : list) {
		   set.addAll(getImmediateParentIds(id));
	   }

	   return new ArrayList<>(set);
   }

   public List<AsnWrapper<Asn1Type>> getParentIds(AsnWrapper<Asn1Type> tradeId) {
      List<AsnWrapper<Asn1Type>> list = new LinkedList<>();
      // traversal to parent

      TradeNode node = tradeNodeMap.get(tradeId);
      traversal(node,list);

      return list;
   }

   /**
    *
    * @param childId the child's id
    * @param parentId the parent's id
    * @return True is the first node is a child of the second one
    */
   public boolean isAncestor(AsnWrapper<Asn1Type> childId, AsnWrapper<Asn1Type> parentId) {
      if (childId == null || parentId == null) return false;

      TradeNode node = tradeNodeMap.get(childId);
      return node.isChildOf(parentId);
   }

   private void traversal(TradeNode node, List<AsnWrapper<Asn1Type>> list) {
      if (node == null) return;

      if (node.buyParentId != null)
         traversal(tradeNodeMap.get(node.buyParentId), list);

      if (node.sellParentId != null)
         traversal(tradeNodeMap.get(node.sellParentId), list);

      list.add(node.tradeId);
   }
   /**
    * speed up locate a trade without search the whole trade forest.
    */
   private final Map<AsnWrapper<Asn1Type>, TradeNode> tradeNodeMap = new HashMap<>(1024);
   /**
    * keeps a set of tradeId, the trade identified by the tradeId is not arrived yet
    */
   private final Set<AsnWrapper<Asn1Type>> notArrivedTrades = new HashSet<>(1024);
   private final HashSet<QueryFeedListener> listeners = new HashSet<>();
   private final QueryFeedListener listener;
   private final QueryFeed srcFeed;
}
