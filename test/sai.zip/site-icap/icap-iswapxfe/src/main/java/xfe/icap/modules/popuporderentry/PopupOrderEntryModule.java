package xfe.icap.modules.popuporderentry;

import com.nomx.domain.types.DefaultDurationType;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.ordersdata.DataMode;
import xfe.icap.modules.ordersdata.OrderEntryData;
import xfe.icap.modules.ordersdata.OrderFilters;
import xfe.icap.modules.ordersdata.OrdersDataModule;
import xfe.icap.modules.ordersui.OrdersViewUIModule;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.tradesworkup.TradesWorkupViewUIModule;
import xfe.icap.modules.tradesworkup.WorkupConstants;
import xfe.icap.modules.tradesworkup.WorkupDITArgs;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.Orders;
import xfe.module.Module;
import xfe.modules.actions.MyOrdersArgs;
import xfe.modules.actions.PopupOrderEntryArgs;
import xfe.modules.actions.TickUpDownAmendArgs;
import xfe.modules.session.SessionScopeModule;
import xfe.types.OrderType;
import xfe.types.SecBoardStaticInfo;
import xfe.ui.popover.XfePopOver;
import xfe.util.EasyFXML;
import xstr.session.ObservableReplyRow;
import xstr.session.XtrTransReply;
import xstr.types.MapWrapper;
import xstr.types.OrderEvent;
import xstr.types.OrderSide;
import xstr.types.XtrBlob;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;

import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Module.Autostart
public class PopupOrderEntryModule extends SessionScopeModule {

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @ModuleDependency
   public OrdersDataModule ordersDataModule;

   @ModuleDependency
   public SecTabsUIModule secTabsUIModule;

   @ModuleDependency
   public OrdersViewUIModule ordersViewUIModule;

   @ModuleDependency
   public TradesWorkupViewUIModule workupViewUIModule;

   private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

   private final ListChangeListener<ObservableReplyRow> observableReplyRowListChangeListener =
      c -> {
         final String loggedInUser = activeSessionModule.getSession().get().getLoggedOnUserId();
         while (c.next()) {
            c.getAddedSubList().stream().filter(OrderFilters.matchUserID(loggedInUser)).collect(Collectors.toList()).forEach(row -> {
               try {
                  // additional check sec board open is added since it can't be supported from engine for now
                  // need to revisit this when engine fixes the clearforworkup event refer:ISWAXT-12122
                  final String secCode = row.getValue(AmpManagedOrder.secCode);
                  if (row.getValue(AmpManagedOrder.orderEvent) == OrderEvent.clearforworkup && isSecBoardOpen(secCode).get().booleanValue()) {
                     final Date engineTime = activeSessionModule.getSession().get().getStats().getEngineTime();
                     final Date workupEndTime = securitiesDataModule.getWorkupEndTime(secCode);
                     /*If there is no workup for the secCode or the previous workup end time is greater than the timeout,
                       then not processing the clearForWorkup orders. */
                     if (workupEndTime == null || differenceInSeconds(workupEndTime, engineTime) > WorkupConstants.CLEAR_FOR_WORKUP_TIMEOUT) {
                        logger.info("Received OrderEvent.clearforworkup Order :: {}, engineTime:{}, workupEndTime:{}",
                           secCode, engineTime, workupEndTime);
                        return;
                     }

                     OrderSide side = row.getValue(AmpManagedOrder.buySell) == 0 ? OrderSide.BUY : OrderSide.SELL;
                     boolean placeOrder = false;
                     WorkupDITArgs ditInfo = getWorkupViewUIModule().getDITInfo(row.getValue(AmpManagedOrder.secCode));
                     if (ditInfo != null) {
                        placeOrder = side == OrderSide.BUY ? ditInfo.isBidOn() : ditInfo.isOfferOn();
                     }
                     if (placeOrder) {
                        populateAndPlaceOrder(row, ditInfo, false);
                     } else {
                        managedOrderId = row.getValue(AmpManagedOrder.managedOrderId);
                        PopupOrderEntryArgs args = new PopupOrderEntryArgs(row, null, side, null, PopupOrderEntryArgs.DefaultOn.PRICE);
                        showPopupOrderAmend(args);
                     }
                  }
               } catch (Exception ex) {
                  logger.warn("Unable to process the order event {}",  row.getValue(AmpManagedOrder.orderEvent));
               }
            });
         }
      };

   private long differenceInSeconds(Date d1, Date d2) {
      LocalDateTime t1 = Instant.ofEpochMilli(d1.getTime())
         .atZone(ZoneId.systemDefault())
         .toLocalDateTime();
      LocalDateTime t2 = Instant.ofEpochMilli(d2.getTime())
         .atZone(ZoneId.systemDefault())
         .toLocalDateTime();
      return ChronoUnit.SECONDS.between(t1, t2);
   }

   private final InvalidationListener listener = c -> {
      if (configurationModule.getData().popupOnWorkupEndingProperty().get())
         ordersDataModule.getSystemReferredOrders().addListener(observableReplyRowListChangeListener);
      else
         ordersDataModule.getSystemReferredOrders().removeListener(observableReplyRowListChangeListener);
   };

   /**
    * Populates the order details from the provided AmpManagedOrder object and places the order.
    *
    * @param row          ObservableReplyRow of AmpManagedOrder
    * @param ditInfo      Specifies workup DIT info
    * @param copyQuantity Specifies if the quantity need to be copied from AmpManagedOrder
    */
   public void populateAndPlaceOrder(ObservableReplyRow row, WorkupDITArgs ditInfo, boolean copyQuantity) {
      final OrderSide side = row.getValue(AmpManagedOrder.buySell) == 0 ? OrderSide.BUY : OrderSide.SELL;
      final String secCode = row.getValue(AmpManagedOrder.secCode);
      final boolean isDIT = ditInfo != null && ((side == OrderSide.BUY) ? ditInfo.isBidOnDIT() : ditInfo.isOfferOnDIT());
      AbstractOrderTrans orderTrans = new ManagedOrderTrans(null);
      orderTrans.setCloneIntoRFS(false);
      orderTrans.setSecCode(secCode);
      orderTrans.setBoardId(row.getValue(AmpManagedOrder.boardId));
      orderTrans.setOrderType(OrderType.REGULAR);
      orderTrans.setVwap(false);
      orderTrans.setPrice(row.getValue(AmpManagedOrder.price).doubleValue());
      if (isDIT) {
         orderTrans.setQuantity(row.getValue(AmpManagedOrder.balance_d));
      } else if (copyQuantity) {
         orderTrans.setQuantity(row.getValue(AmpManagedOrder.quantity).doubleValue());
      } else {
         orderTrans.setQuantity(getDefaultQuantity(row));
      }
      orderTrans.setDoneIfTouched(isDIT);
      orderTrans.setAnonymous(false);
      orderTrans.setUnderRef(false);
      orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DAY);
      orderTrans.setOnLogOffAction(configurationModule.getData().onLogoffActionProperty().get());
      orderTrans.setShared(configurationModule.getData().sharedOrdersProperty().get());
      orderTrans.setTopCut(row.getValue(AmpManagedOrder.isTopcut));

      // Bid on offer automatic order, so tagged as CM/CLOB
      String orderTag = row.getString(AmpManagedOrder.orderTag);
      orderTag = Orders.CM.equals(orderTag) || isDIT ? Orders.CM : Orders.CLOB;
      final MapWrapper extraField = new MapWrapper();
      extraField.put(Orders.ORDER_TAG_KEY, new XtrBlob(orderTag.getBytes()));
      orderTrans.setMapWrapper(extraField);
      activeSessionModule.getSession().ifPresent(session -> {
         logger.debug("Placing order :: {} ", orderTrans);
         orderTrans.executeBuySell(session,
            side.equals(OrderSide.BUY) ? AmpOrderVerb.buy : AmpOrderVerb.sell).onDone(x -> {
            if (x.get().getStatus() == XtrTransReply.Status.RESULT_OK) {
               logger.info("!!! Successfully placed automatic order on {}  for {}  !!! ", side, secCode);
            } else {
               String errorMsg = x.get().getMessage();
               logger.error("onBidOffer: {}", errorMsg);
            }
            return Future.SUCCESS;
         });
      });
   }

   private Double getDefaultQuantity(ObservableReplyRow row) {
      Double defaultQty = null;
      try {
         // try to get default quantity from the security.
         SecBoardStaticInfo info = securitiesDataModule.getStaticInfo(row.getValue(AmpManagedOrder.secCode), row.getValue(AmpManagedOrder.boardId)).get();
         if (info != null)
            defaultQty = info.defaultQuantity;
      } catch (Exception ex) {
         logger.info("No default quantity is not set for the security or failed to fetch the information");
      }
      // read the default quantity set in the configuration
      if (defaultQty == null || defaultQty == 0)
         defaultQty = BigDecimal.valueOf(midiLayoutModule.getDefaultQuantity(row.getValue(AmpIcapSecBoardTrim2.secClassId))).doubleValue();
      return defaultQty;
   }

   @Override
   public Future<Void> startModule() {
      secTabsUIModule.setEnterOrderHandler(this::showPopupOrderEntry);
      secTabsUIModule.setAmendOrderHandler(this::showPopupOrderAmend);
      secTabsUIModule.setTickUpDownAmendOrder(this::tickUpDownAmend);
      ordersViewUIModule.setAmendOrderHandler(this::showPopupOrderAmend);
      ordersViewUIModule.setPopulateAndPlaceOrderHandler(this::populateAndPlaceOrder);

      if (configurationModule.getData().popupOnWorkupEndingProperty().get())
         ordersDataModule.getSystemReferredOrders().addListener(observableReplyRowListChangeListener);

      configurationModule.getData().popupOnWorkupEndingProperty().addListener(listener);

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      secTabsUIModule.setEnterOrderHandler(null);
      secTabsUIModule.setAmendOrderHandler(null);
      ordersViewUIModule.setAmendOrderHandler(null);
      ordersViewUIModule.setPopulateAndPlaceOrderHandler(null);
      ordersDataModule.getSystemReferredOrders().removeListener(observableReplyRowListChangeListener);
      configurationModule.getData().popupOnWorkupEndingProperty().removeListener(listener);
      return Future.SUCCESS;
   }

   public TradesWorkupViewUIModule getWorkupViewUIModule() {
      return workupViewUIModule;
   }

    /**
     * Amends the order of an instrument based on the tick direction.
     *
     * @param args TickUpDownAmendArgs
     */
    private void tickUpDownAmend(TickUpDownAmendArgs args) {
        AbstractOrderTrans orderTrans = new ManagedOrderTrans(null);
        populateTransactionData(orderTrans, args.getManagedOrderRow(), args.getNewPrice());
        logger.debug("**** Executing Amend BUY/SELL ****");

        activeSessionModule.getSession().ifPresent(session -> {
            final int buySell = args.getSide().equals(OrderSide.BUY) ? AmpOrderVerb.buy : AmpOrderVerb.sell;
            orderTrans.executeBuySell(session, buySell).onDone(x -> {
                if (x.get().getStatus() == XtrTransReply.Status.RESULT_OK) {
                    /* Do nothing */
                } else {
                    String errorMsg = x.get().getMessage();
                    logger.error("onBidOffer: {}", errorMsg);
                }
                return Future.SUCCESS;
            });
        });
    }

    private ObservableList<ObservableReplyRow> getMyOrders(MyOrdersArgs args, boolean referredIncluded) {
      final String secCode = args.getSecCode();
      final BigDecimal orderPrice = args.getOrderPrice();
      if (orderPrice == null) return FXCollections.emptyObservableList();

      return activeSessionModule.getSession().map(session -> {
         final String userId = session.getLoggedOnUserId();

         Predicate<ObservableReplyRow> orderRowFilter =
            OrderFilters.matchSecCode(secCode)
               .and(OrderFilters.matchPrice(orderPrice))
               .and(OrderFilters.matchUserID(userId))
               .and(OrderFilters.matchOpenOrder().or(OrderFilters.matchAmendedOrder()).or(OrderFilters.matchReferredOrder()));
         if (!referredIncluded)
            orderRowFilter = orderRowFilter.and(OrderFilters.matchReferredOrder().negate());
         return ordersDataModule.getFilteredOrders(orderRowFilter);
      }).orElse(FXCollections.emptyObservableList());
   }

   private PopupOrderEntryPane createOrderEntryPane() {
      PopupOrderEntryPane p = EasyFXML.load(PopupOrderEntryPane.class);
      p.setSession(activeSessionModule.getSession());
      p.setMyOrdersGetter(this::getMyOrders);
      return p;
   }

   private void showPopupOrderAmend(PopupOrderEntryArgs popupAmendEntryArgs) {
      // This is a managed order row - TODO: check and throw if not
      ObservableReplyRow row = popupAmendEntryArgs.getRow();

      OrderEntryData orderEntryData = new OrderEntryData();
      String secCode = row.getValue(AmpManagedOrder.secCode);
      String boardId = row.getValue(AmpManagedOrder.boardId);
      orderEntryData.setSecCode(secCode);
      orderEntryData.setBoardId(boardId);
      orderEntryData.setPrice(row.getValue(AmpManagedOrder.price));
      orderEntryData.setQty(row.getValue(AmpManagedOrder.quantity));
      orderEntryData.setBalance(row.getValue(AmpManagedOrder.balance));
      orderEntryData.setOrderId(row.getValue(AmpManagedOrder.managedOrderId));
      orderEntryData.setSide(popupAmendEntryArgs.getSide());
      orderEntryData.setActionOnLogoff(configurationModule.getData().onLogoffActionProperty().get());
      orderEntryData.setIsShared(configurationModule.getData().sharedOrdersProperty().get());
      orderEntryData.setIsTopcut(configurationModule.getData().topCutProperty().get());
      orderEntryData.setOrderTag(row.getValue(AmpManagedOrder.orderTag));

      try {
         securitiesDataModule.getStaticInfo(secCode, boardId).map(info -> {
            orderEntryData.setStaticInfo(info);
            Double qty = info.defaultQuantity;
            if (qty == null || qty == 0) {
               qty = midiLayoutModule.getDefaultQuantity(info.secClassId);
            }
            orderEntryData.setDefaultQuantity(BigDecimal.valueOf(qty));
            return Future.SUCCESS;
         });
      } catch (Exception e) {
         logger.warn("Unable to retrieve default quantity using seccode - failure reason {} ",  e.getMessage());
      }

      if (popupAmendEntryArgs.getNode() != null) {
         orderEntryData.setDataMode(DataMode.AMEND);
         createPopover(orderEntryData, popupAmendEntryArgs);
      } else {
         orderEntryData.setDataMode(DataMode.RENEW);
         createPopup(orderEntryData);
      }
   }

   private void showPopupOrderEntry(PopupOrderEntryArgs popupOrderEntryArgs) {
      // This is a security row - TODO: check and throw if not
      ObservableReplyRow row = popupOrderEntryArgs.getRow();

      OrderEntryData orderEntryData = new OrderEntryData();
      orderEntryData.setDataMode(DataMode.ENTRY);
      orderEntryData.setSecCode(row.getValue(AmpIcapSecBoardTrim2.secCode));
      orderEntryData.setBoardId(row.getValue(AmpIcapSecBoardTrim2.boardId));
      OrderSide side = popupOrderEntryArgs.getSide();
      orderEntryData.setSide(side);
      orderEntryData.setPrice(side.equals(OrderSide.BUY) ?
         row.getValue(AmpIcapSecBoardTrim2.bidPrice) :
         row.getValue(AmpIcapSecBoardTrim2.offerPrice));
      BigDecimal defaultQty = row.getValue(AmpIcapSecBoardTrim2.defaultQty);
      if (defaultQty == null) {
         defaultQty = BigDecimal.valueOf(midiLayoutModule.getDefaultQuantity(row.getValue(AmpIcapSecBoardTrim2.secClassId)));
      }
      orderEntryData.setQty(defaultQty);
      orderEntryData.setActionOnLogoff(configurationModule.getData().onLogoffActionProperty().get());
      orderEntryData.setIsShared(configurationModule.getData().sharedOrdersProperty().get());
      orderEntryData.setIsTopcut(configurationModule.getData().topCutProperty().get());
      orderEntryData.setStaticInfo(securitiesDataModule.getStaticInfo(row));

      createPopover(orderEntryData, popupOrderEntryArgs);
   }

   private void createPopover(OrderEntryData orderEntryData, PopupOrderEntryArgs popupOrderEntryArgs) {
      PopupOrderEntryPane oe = createOrderEntryPane();
      oe.setCloseHandler(midiLayoutModule::closePopOverWindow);
      final XfePopOver popOver = XfePopOver.instance(midiLayoutModule);
      popOver.setHeaderAlwaysVisible(true);
      popOver.setContentNode(oe.getRoot());
      oe.setPopover(popOver);
      oe.setup(orderEntryData);
      midiLayoutModule.closePopOverWindow(XfePopOver.ID_PREFIX + popOver.getTitle());
      popOver.showSafely(popupOrderEntryArgs.getNode());
      oe.setDefaultFocusOn(popupOrderEntryArgs.getDefaultOn());
   }

   private void createPopup(OrderEntryData orderEntryData) {
      PopupOrderEntryPane oe = createOrderEntryPane();
      oe.setCloseHandler(midiLayoutModule::closePopupStage);
      Node root = oe.getRoot();
      OrderSide side = orderEntryData.getSide();
      if (side.equals(OrderSide.BUY)) {
         root.setId(MidiLayoutViews.ORDER_RENEW_BID + " " + managedOrderId);
      } else {
         root.setId(MidiLayoutViews.ORDER_RENEW_OFFER + " " + managedOrderId);
      }
      oe.setup(orderEntryData);
      midiLayoutModule.addView(root);
      oe.showRenewMessage();
   }

   private Future<Boolean> isSecBoardOpen(String secCode) {
      Promise<Boolean> res = Futures.newPromise("res");
      if (secCode != null) {
         securitiesDataModule.retrieveSecBoardTrim2(secCode).map(queryReplyRow ->
            res.setSuccess("Open".equals(queryReplyRow.getValue(AmpIcapSecBoardTrim2.sessionName))));
      } else {
         res.setSuccess(Boolean.FALSE);
      }
      return res;
   }

    private void populateTransactionData(AbstractOrderTrans orderTrans, ObservableReplyRow managedOrder,
                                         double newPrice) {
        orderTrans.setCloneIntoRFS(managedOrder.getValue(AmpManagedOrder.cloneIntoRFS));
        orderTrans.setSecCode(managedOrder.getValue(AmpManagedOrder.secCode));
        orderTrans.setBoardId(managedOrder.getValue(AmpManagedOrder.boardId));
        orderTrans.setOrderType(OrderType.byDescription(managedOrder.getValue(AmpManagedOrder.orderType)));
        orderTrans.setAllowMultiMinFill(managedOrder.getValue(AmpManagedOrder.allowMultiMinFill));
        orderTrans.setVwap(false);
        orderTrans.setPrice(newPrice);
        orderTrans.setQuantity(managedOrder.getValue(AmpManagedOrder.quantity).doubleValue());
        orderTrans.setDoneIfTouched(managedOrder.getValue(AmpManagedOrder.isDoneIfTouched));
        orderTrans.setAnonymous(false);
        orderTrans.setUnderRef(false);
        orderTrans.setDefaultDurationType(managedOrder.getValue(AmpManagedOrder.durationType));
        orderTrans.setMinFill(managedOrder.getValue(AmpManagedOrder.minFillQuantity));
        orderTrans.setVisibleQty(managedOrder.getValue(AmpManagedOrder.visibleQuantity));
        orderTrans.setOnLogOffAction(managedOrder.getValue(AmpManagedOrder.actionOnLogoff));
        orderTrans.setShared(managedOrder.getValue(AmpManagedOrder.shared));
        orderTrans.setTopCut(managedOrder.getValue(AmpManagedOrder.isTopcut));
        final MapWrapper mapWrapper = new MapWrapper();
        mapWrapper.put(Orders.ORDER_TAG_KEY, new XtrBlob(Orders.CLOB.getBytes()));
        orderTrans.setMapWrapper(mapWrapper);
    }

   private Long managedOrderId;
}
