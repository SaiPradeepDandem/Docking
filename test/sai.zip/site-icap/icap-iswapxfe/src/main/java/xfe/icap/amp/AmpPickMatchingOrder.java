package xfe.icap.amp;

import java.util.Date;

import xstr.amp.AMP;
import xstr.amp.acc.AmpAccessor;
import xstr.amp.AsnConversionAccessor;
import xstr.amp.AMP.AmpTreq;

public class AmpPickMatchingOrder extends AmpAccessor {
   public static final  AmpTreq txn = AMP.tREQ("pickMatchingOrder");

   public static final AsnConversionAccessor<Date> orderDate        = acc(AMP.tREQ("pickMatchingOrder.orderId.orderDate"              ), Date.class);
   public static final AsnConversionAccessor<Long>    orderNo        = acc(AMP.tREQ("pickMatchingOrder.orderId.orderNo"              ), Long.class);
   public static final AsnConversionAccessor<String>  secCode        = acc(AMP.tREQ("pickMatchingOrder.secBoardId.secCode"   ), String.class);
   public static final AsnConversionAccessor<String>  boardId        = acc(AMP.tREQ("pickMatchingOrder.secBoardId.boardId"   ), String.class);
   public static final AsnConversionAccessor<Integer> buySell        = acc(AMP.tREQ("pickMatchingOrder.buySell"              ), Integer.class);
   public static final AsnConversionAccessor<String> introBrokerId        = acc(AMP.tREQ("pickMatchingOrder.introBrokerId"              ), String.class);
}
