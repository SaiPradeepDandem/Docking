package xfe.icap.modules.tradesui;

import com.nomx.persist.watchlist.ColumnsSpec;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.dealsdata.DealsDataModule;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.toolbar.actions.ActionToolBarUIModule;
import xfe.icap.modules.tradesdata.CrossTradesFeedAdapter;
import xfe.icap.types.Trade;
import xfe.module.Module;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.modules.session.SessionScopeModule;
import xfe.util.XfeAction;
import xstr.amp.AMP;
import xstr.amp.AmpService;
import xstr.session.*;
import xstr.types.DealStatus;
import xstr.types.OrderSide;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

@Module.Autostart
public class TradesViewUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradesViewUIModule.class);

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ActionToolBarUIModule actionToolBarUIModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   private Pane root;

   private XfeAction tradesAction;
   private TradesViewTable tradesViewTable;

   public Pane getRoot() {
      return root;
   }

   @Override
   public Future<Void> startModule() {
      if (midiLayoutModule.isGiltsSite()) {
         return Future.SUCCESS;
      }

      tradeAggregator = new FeedAggregator<>(AmpTrade.rep, new ObservableReplyRow.ObservableRowFactory());
      final ObservableList<ObservableReplyRow> trades = Fx.sortBy(tradeAggregator.items, Comparator.reverseOrder());

      activeSessionModule.getSession().ifPresent((session) -> {
         tradesFeed = new CrossTradesFeedAdapter();
         tradesFeed.addListener(events -> {
            for (QueryRowEvent event : events) {
               XtrQueryReplyCommand eventType = event.getEventType();
               switch (eventType) {
                  case UPDATE:
                     checkForTradeFlash(trades);
                     actionToolBarUIModule.toggleTradeButtonFlash(isTradeBrokerApproved(event.getNewRow()));
                     if (configurationModule.getData().tradeAutoPopupProperty().get()) {
                        if (isTradeBrokerApproved(event.getNewRow())) {
                           Fx.runLater(() -> midiLayoutModule.addView(getRoot()));
                        }
                     }
                     break;
                  default:
                     logger.error("Unexpected event type: {}", eventType);
               }
            }
         });
         tradesFeed.addListener(tradeAggregator);
         session.getFeedSource(AmpTrade.req).addListener(tradesFeed.getFeedListener());
      });

      // Showing the trades popup automatically if the setting property is set.
      trades.addListener((ListChangeListener.Change<? extends ObservableReplyRow> c) -> {
         checkForTradeFlash(trades);
         while (c.next()) {
            final List<? extends ObservableReplyRow> list = c.getAddedSubList();
            if (configurationModule.getData().tradeAutoPopupProperty().get()) {
               for (ObservableReplyRow row : list) {
                  if (isTradeBrokerApproved(row)) {
                     midiLayoutModule.addView(getRoot());
                     return;
                  }
               }
            }
         }
      });

      tradesViewTable = new TradesViewTable();
      tradesViewTable.setCOGWheelToTheLeft(true);
      tradesViewTable.setItems(trades);
      tradesViewTable.setTradesColsSpecificationPropertySupplier(this::getTradesColsSpecificationProperty);
      tradesViewTable.setTradeAgreeFactory(this::tradeAgreeValueFactoryImpl);
      tradesViewTable.setSideFactory(this::sideValueFactoryImpl);
      tradesViewTable.setTradeRefFactory(this::extTradeRefValueFactoryImpl);
      tradesViewTable.setTypeFactory(this::typeValueFactoryImpl);
      tradesViewTable.setStatusFactory(this::statusValueFactoryImpl);
      tradesViewTable.setCommTypeFactory(this::commTypeFactoryImpl);
      tradesViewTable.setNetValueFactory(this::netValueFactoryImpl);
      tradesViewTable.setTraderFactory(this::traderValueFactoryImpl);
      tradesViewTable.setBrokerFactory(this::brokerValueFactoryImpl);
      tradesViewTable.setTradeAgreeOp(this::agreeTrade);
      tradesViewTable.setTradesAggregatePopupActionConsumer(this::doTradesAggregatePopupAction);
      tradesViewTable.setSecBoardStaticInfoGetter(securitiesDataModule::getStaticInfo);

      this.root = new StackPane();
      this.root.setId(MidiLayoutViews.TRADESVIEW);
      this.root.getChildren().add(tradesViewTable);

      tradesAction = new XfeAction();
      tradesAction.setActionId("trades");
      tradesAction.setOnAction(e -> midiLayoutModule.addView(getRoot()));
      tradesAction.getStyleClass().add("xfe-icon-trades");
      actionToolBarUIModule.addViewAction(tradesAction);

      if (configurationModule.getData().tradesViewOpened().get()) {
         midiLayoutModule.addView(getRoot());
      }
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      if (tradesAction != null) {
         tradesAction.setOnAction(null);
      }
      if (tradesViewTable != null) {
         tradesViewTable.setTradesColsSpecificationPropertySupplier(null);
         tradesViewTable.setTradeAgreeFactory(null);
         tradesViewTable.setSideFactory(null);
         tradesViewTable.setTradeRefFactory(null);
         tradesViewTable.setTypeFactory(null);
         tradesViewTable.setStatusFactory(null);
         tradesViewTable.setCommTypeFactory(null);
         tradesViewTable.setNetValueFactory(null);
         tradesViewTable.setTraderFactory(null);
         tradesViewTable.setBrokerFactory(null);
         tradesViewTable.setTradeAgreeOp(null);
         tradesViewTable.setTradesAggregatePopupActionConsumer(null);
         tradesViewTable.setSecBoardStaticInfoGetter(null);
      }
      if (getRoot() != null) {
         midiLayoutModule.removeView(getRoot());
      }
      return Future.SUCCESS;
   }

   private ObjectProperty<ColumnsSpec> getTradesColsSpecificationProperty() {
      return configurationModule.getData().tradesColsSpecificationProperty();
   }

   private void checkForTradeFlash(List<? extends ObservableReplyRow> trades) {
      boolean isBrokerApproved = trades.stream().anyMatch(this::isTradeBrokerApproved);
      actionToolBarUIModule.toggleTradeButtonFlash(isBrokerApproved);
   }

   private boolean isTradeBrokerApproved(QueryReplyRow row) {
      String buyDealStatus = row.getValue(AmpTrade.buyDealStatus);
      String sellDealStatus = row.getValue(AmpTrade.sellDealStatus);

      return DealStatus.BrokerApproved.name().equals(buyDealStatus) || DealStatus.BrokerApproved.name().equals(sellDealStatus);
   }

   private ObservableValue<XfeAction> tradeAgreeValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> isBrokerApproved(row), row.rowProperty());
   }

   private ObservableValue<BigDecimal> netValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getNetValue(row), row.rowProperty());
   }

   private BigDecimal getNetValue(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.buyAdjustedPrice);

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.sellAdjustedPrice);

      return null;
   }

   private ObservableValue<String> commTypeFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getCommType(row), row.rowProperty());
   }

   private String getCommType(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.buyCommissionType);

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.sellCommissionType);

      return null;
   }

   private ObservableValue<String> typeValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getType(row), row.rowProperty());
   }

   private String getType(ObservableReplyRow row) {
      AtomicReference<Integer> strategyType = new AtomicReference<>(null);
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         strategyType.set(row.getValue(AmpTrade.buyStrategyTradeType));
      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         strategyType.set(row.getValue(AmpTrade.sellStrategyTradeType));

      if (strategyType.get() == null) return null;

      if (Trade.isOutrightType(strategyType.get()))
         return "Outright";
      if (Trade.isStrategyType(strategyType.get()))
         return "Strategy";
      if (Trade.isLegType(strategyType.get()))
         return "Leg";

      return null;
   }

   private ObservableValue<String> statusValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getStatus(row), row.rowProperty());
   }

   private String getStatus(ObservableReplyRow row) {
      AtomicReference<String> status = new AtomicReference<>(null);
      String traderId = row.getValue(AmpTrade.buyTraderId);
      String buyDealStatus = row.getValue(AmpTrade.buyDealStatus);
      String sellDealStatus = row.getValue(AmpTrade.sellDealStatus);

      if (traderId != null && !traderId.isEmpty()) {
         // Treating it first as a GILT
         status.set(buyDealStatus);
         if (isApproved(buyDealStatus) && isBrokerApprovedOrPendingApproval(sellDealStatus)) {
            status.set(DealStatus.PendingCP.toString());
         }
      } else {
         traderId = row.getValue(AmpTrade.sellTraderId);
         if (traderId != null && !traderId.isEmpty()) {
            status.set(sellDealStatus);
            if (isApproved(sellDealStatus) && isBrokerApprovedOrPendingApproval(buyDealStatus)) {
               status.set(DealStatus.PendingCP.toString());
            }
         }
      }

      if (status.get() == null) // using normal trade's status
         status.set(AmpTrade.getStatus(row.getValue(AmpTrade.status)));

      return status.get();
   }

   private boolean isApproved(String status) {
      return status != null && status.equals(DealStatus.Approved.name());
   }

   private boolean isBrokerApprovedOrPendingApproval(String status) {
      return status != null && (status.equals(DealStatus.BrokerApproved.name()) || status.equals(DealStatus.PendingApproval.name()));
   }

   private ObservableValue<String> traderValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getTrader(row), row.rowProperty());
   }

   private String getTrader(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return traderId;

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return traderId;

      return null;
   }


   private ObservableValue<String> brokerValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getBroker(row), row.rowProperty());
   }

   private String getBroker(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.buyOperatorId);

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.sellOperatorId);

      return null;
   }

   private ObservableValue<OrderSide> sideValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getSide(row), row.rowProperty());
   }

   public static OrderSide getSide(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return OrderSide.BUY;

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return OrderSide.SELL;

      return null;
   }

   private ObservableValue<String> extTradeRefValueFactoryImpl(ObservableReplyRow row) {
      return Bindings.createObjectBinding(() -> getExtDealRef(row), row.rowProperty());
   }

   private String getExtDealRef(ObservableReplyRow row) {
      String traderId = row.getValue(AmpTrade.buyTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.buyExtDealId);

      traderId = row.getValue(AmpTrade.sellTraderId);
      if (traderId != null && !traderId.isEmpty())
         return row.getValue(AmpTrade.sellExtDealId);

      return null;
   }

   private XfeAction isBrokerApproved(ObservableReplyRow row) {
      String buyDealStatus = row.getValue(AmpTrade.buyDealStatus);
      String sellDealStatus = row.getValue(AmpTrade.sellDealStatus);

      if (DealStatus.BrokerApproved.name().equals(buyDealStatus)) {
         XfeAction action = new XfeAction();
         action.setText("A");
         action.setOnAction(event -> agreeTrade(row, OrderSide.BUY));
         return action;
      } else if (DealStatus.BrokerApproved.name().equals(sellDealStatus)) {
         XfeAction action = new XfeAction();
         action.setText("A");
         action.setOnAction(event -> agreeTrade(row, OrderSide.SELL));
         return action;
      } else {
         XfeAction action = new XfeAction();
         action.setAvailable(false);
         return action;
      }
   }

   private void agreeTrade(ObservableReplyRow row, OrderSide side) {
      AMP.AmpTreq trns = AMP.tREQ("tradeDealApprove");
      activeSessionModule.getSession().ifPresent(session -> {
         try {
            XtrTransRequestBuilder reqBuilder = XtrTransRequestBuilder.create(trns, session)
               .setAsn(AmpService.INSTANCE.getAccessor(AMP.tREQ("tradeDealApprove.tradeId")),
                  row.getAsn(AmpTrade.tradeId))
               .set(AmpService.INSTANCE.getValAccessor(AMP.tREQ("tradeDealApprove.buySell"), Integer.class),
                  side.ordinal());
            session.execute(reqBuilder.build());
         } catch (AsnTypeException | AmpPermissionException e) {
            e.printStackTrace();
         }
      });
   }

   public void setTradesAggregatePopupHandler(Consumer<TradesAggregateArgs> tradesAggregatePopupHandler) {
      this.tradesAggregatePopupHandler = tradesAggregatePopupHandler;
   }

   private void doTradesAggregatePopupAction(TradesAggregateArgs args) {
      if (tradesAggregatePopupHandler != null)
         tradesAggregatePopupHandler.accept(args);
   }

   private FeedAggregator<ObservableReplyRow> tradeAggregator;
   private CrossTradesFeedAdapter tradesFeed;
   private Consumer<TradesAggregateArgs> tradesAggregatePopupHandler;
}
