package xfe.icap.modules.iswaptrades;

import java.util.Date;

import com.google.common.base.Strings;
import javafx.beans.property.*;
import javafx.beans.value.*;

import xstr.types.TradeSide;
import xstr.session.XtrKey;
import com.objsys.asn1j.runtime.Asn1Type;
import xstr.util.Require;

final class TradeAlert {
   static final String STATUS_DONE = "Done";
   static final String STATUS_WITHDRAW = "Withdrawn";
   static final String STATUS_UNAPPROVED = "Unapproved";
   static final String STATUS_UNCNF_BUY = "Uncnf Buy";
   static final String STATUS_UNCNF_SELL = "Uncnf Sell";
   static final String STATUS_PENDING = "Pending";
   static final String STATUS_AMENDED = "Amended";
   static final String STATUS_WORKUP = "Workup";
   static final String STATUS_RFQ_PENDING = "LL Pending";
   static final String STATUS_UNKNOW = "";

   public final Asn1Type tradeId;
   public final XtrKey key;
   public final String secCode;
   public final TradeSide side;
   final String buyFirmId;
   final String sellFirmId;
   private final String buyBrokerId;
   private final String buyOperatorId;
   private final String sellBrokerId;
   private final String sellOperatorId;
   final String buyTraderId;
   final String sellTraderId;
   final String buyAccount;
   final String sellAccount;
   public final DoubleProperty amount  = new SimpleDoubleProperty();
   public final String rate;
   final Date workupExpTime; //It only contains the time.  method setExpDate will set the date
   final Date timestamp;
   final boolean isLeg;
   public final boolean isBroker;
   private final boolean isIB;

   //	**** Priority 2 (Workups) ****
   final StringProperty alertStatus = new SimpleStringProperty();
   final DoubleProperty buyWorkupAmountProperty = new SimpleDoubleProperty();
   final DoubleProperty sellWorkupAmountProperty = new SimpleDoubleProperty();
   private final BooleanProperty expandProperty = new SimpleBooleanProperty();

   TradeAlert(
      Asn1Type tradeId,
      XtrKey key,
      String secCode,
      TradeSide side,
      String buyFirmId,
      String sellFirmId,
      String buyBrokerId,
      String buyOperatorId,
      String sellBrokerId,
      String sellOperatorId,
      String buyTraderId,
      String sellTraderId,
      String buyAccount,
      String sellAccount,
      Double amount,
      Double sellWorkupAmount,
      Double buyWorkupAmount,
      String status,
      String rate,
      boolean isLeg,
      Date workupExpTime,
      Date tm,
      boolean isBroker,
      boolean isIB) {
      Require.noNulls(secCode);

      this.tradeId = tradeId;
      this.key = key;
      this.secCode = secCode;
      this.buyFirmId = buyFirmId;
      this.sellFirmId = sellFirmId;
      this.buyBrokerId = buyBrokerId;
      this.buyOperatorId = buyOperatorId;
      this.sellBrokerId = sellBrokerId;
      this.sellOperatorId = sellOperatorId;
      this.buyTraderId = buyTraderId;
      this.sellTraderId = sellTraderId;
      this.buyAccount = buyAccount;
      this.sellAccount = sellAccount;
      this.side = side;
      this.amount.setValue(amount);
      this.rate = rate;
      this.workupExpTime = workupExpTime == null ? null : new Date(workupExpTime.getTime());
      this.alertStatus.set(status);
      this.isLeg = isLeg;
      this.isBroker = isBroker;
      this.isIB = isIB;

      //for Mantis 0061634, the workup amount need to be initiated to trade amount.
      try {
         if(buyWorkupAmount == null || buyWorkupAmount == 0)
            buyWorkupAmountProperty.setValue(amount);
         else
            buyWorkupAmountProperty.setValue(buyWorkupAmount);
      } catch (Exception e1) {
         buyWorkupAmountProperty.setValue(buyWorkupAmount);
      }

      try {
         if(sellWorkupAmount == null || sellWorkupAmount == 0)
            sellWorkupAmountProperty.setValue(amount);
         else
            sellWorkupAmountProperty.setValue(sellWorkupAmount);
      } catch (Exception e1) {
         buyWorkupAmountProperty.setValue(buyWorkupAmount);
      }



      if (tm != null) {
         this.timestamp = new Date(tm.getTime());
      } else {
         try {
            Thread.sleep(1);
         } catch (InterruptedException e) {
            e.printStackTrace();
         }

         this.timestamp = new Date();
      }
      setExpDate();
   }

   @SuppressWarnings("deprecation")
   private void setExpDate() {
      if (workupExpTime != null) {
         workupExpTime.setDate(timestamp.getDate());
         workupExpTime.setMonth(timestamp.getMonth());
         workupExpTime.setYear(timestamp.getYear());
      }
   }

   String getCPFirmId() {
      if (side == null) return "";
      switch (side) {
         case BUY:
            return sellFirmId;
         case SELL:
            return buyFirmId;
         default:
            return String.format("%s/%s", buyFirmId, sellFirmId);
      }
   }

   String getPayCPFirmId() {
      return buyFirmId;
   }

   String getRecCPFirmId() {
      return sellFirmId;
   }

   String getTraderName() {
      if (side == null) return "";
      switch (side) {
         case BUY:
            return buyTraderId;
         case SELL:
            return sellTraderId;
         default:
            return String.format("%s/%s", buyTraderId, sellTraderId);
      }
   }

   public boolean isWorkup(){
      return STATUS_WORKUP.equalsIgnoreCase(alertStatus.get());
   }

   public boolean isDone() {
      return STATUS_DONE.equalsIgnoreCase(alertStatus.get());
   }



   //	**** Priority 2 (Workups) ****
   StringProperty alertStatusProperty() {
      return alertStatus;
   }

   String getAlertStatus() {
      return alertStatus.get();
   }


   public BooleanProperty expandProperty() {
      return expandProperty;
   }

   @Override
   public boolean equals(Object other) {
      if(other == null) return false;
      if (other == this) return true;
      if (other instanceof TradeAlert) {
         // DO NOT USE TradeId object for equals - it does nothing else but "=="
         return key != null && key.equals(((TradeAlert) other).key);
      }
      return false;
   }

   @Override
   public int hashCode() {
      return key.hashCode();
   }

   public ObservableDoubleValue getOppWorkupAmount(){
      return side==TradeSide.BUY ? sellWorkupAmountProperty : buyWorkupAmountProperty;
   }


   /*
    * calculate the duration of the workup in second
    */
   @Override
   public String toString() {
      return "TradeAlert "+System.identityHashCode(this)+" [tradeId=" + tradeId + ", key=" + key + ", secCode=" + secCode + ", side=" + side + ", buyFirmId=" + buyFirmId + ", sellFirmId="
         + sellFirmId + ", buyTraderId=" + buyTraderId + ", sellTraderId=" + sellTraderId + ", amount=" + amount + ", rate=" + rate + ", status=" + alertStatus.get()
         + ", isLeg=" + isLeg + ", timestamp=" + timestamp + ", buyWorkupAmountProperty=" + buyWorkupAmountProperty.get()
         +", sellWorkupAmountProperty=" + sellWorkupAmountProperty.get()+", workupExpTime="+workupExpTime
         + ", expandProperty="            + expandProperty + "]";
   }

   public void setAmount(double amount) {
      this.amount.setValue(amount);
   }

   boolean isNeedFlash(String userId){
      return ( (userId.equals(buyBrokerId) || userId.equals(sellTraderId) ) && STATUS_WORKUP.equals(alertStatus.getValue()) );
   }

   String getBrokerId() {
      if (side == null) return "";
      if (side.equals(TradeSide.BUY)) {
         return Strings.isNullOrEmpty(buyOperatorId) ? buyBrokerId : buyOperatorId;
      } else {
         return Strings.isNullOrEmpty(sellOperatorId) ? sellBrokerId : sellOperatorId;
      }
   }
}
