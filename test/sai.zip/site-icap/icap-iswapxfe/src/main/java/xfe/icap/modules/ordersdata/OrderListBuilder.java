package xfe.icap.modules.ordersdata;

import javafx.collections.ObservableList;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.function.Predicate;

/**
 * Created by soopot on 8/9/2019.
 *
 * @author Sooraj Pottekat
 */
public final class OrderListBuilder {
  private final String userID;
  private final String firmID;
  private final ObservableList<ObservableReplyRow> primaryList;
  private Predicate<ObservableReplyRow> filterToApply = (ObservableReplyRow row) -> true ;

  public OrderListBuilder(ObservableList<ObservableReplyRow> list, String userID, String firmID) {
    this.primaryList = list;
    this.userID = Objects.requireNonNull(userID, "user cannot be null");
    this.firmID = Objects.requireNonNull(firmID, "firm cannot be null");
  }

  private OrderListBuilder(OrderListBuilder other) {
    this.firmID = other.firmID;
    this.userID = other.userID;
    this.filterToApply = other.filterToApply;
    this.primaryList = other.primaryList;
  }

  public OrderListBuilder ofSec(String secCode) {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchSecCode(secCode));
    return orderListBuilder;
  }

  private void addFilter(Predicate<ObservableReplyRow> filter) {
    filterToApply = filterToApply.and(filter);
  }

  public OrderListBuilder own() {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter((OrderFilters.matchUserID(userID)));
    return orderListBuilder;
  }

  public OrderListBuilder colleagues() {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(
        (OrderFilters.matchUserID(userID).negate()).and(OrderFilters.matchFirmID(firmID)));
    return orderListBuilder;
  }

  public OrderListBuilder isNotOwn() {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.notMatchUserID(userID));
    return orderListBuilder;
  }

  public OrderListBuilder firm() {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchFirmID(firmID));
    return orderListBuilder;
  }

   public OrderListBuilder isNotFirm() {
      OrderListBuilder orderListBuilder = new OrderListBuilder(this);
      orderListBuilder.addFilter(OrderFilters.notMatchFirmID(firmID));
      return orderListBuilder;
   }

  public OrderListBuilder atCMPrice(BigDecimal cmPrice) {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchIsCMOrder(cmPrice));
    return orderListBuilder;
  }

  public OrderListBuilder atAbsCMPrice(BigDecimal cmPrice) {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchIsCMOrderAbs(cmPrice));
    return orderListBuilder;
  }

  public OrderListBuilder isCM() {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchIsDarkOrder());
    return orderListBuilder;
  }

  public OrderListBuilder notCM() {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchIsDarkOrder().negate());
    return orderListBuilder;
  }

  public OrderListBuilder inSide(OrderSide side) {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchSide(side));
    return orderListBuilder;
  }

  public OrderListBuilder inSide(int side) {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchBuySell(side));
    return orderListBuilder;
  }

  public OrderListBuilder atPrice(BigDecimal price) {
    OrderListBuilder orderListBuilder = new OrderListBuilder(this);
    orderListBuilder.addFilter(OrderFilters.matchPrice(price));
    return orderListBuilder;
  }

  public ObservableList<ObservableReplyRow> build() {
    return primaryList.filtered(filterToApply);
  }
}
