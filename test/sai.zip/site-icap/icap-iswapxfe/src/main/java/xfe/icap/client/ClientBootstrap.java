package xfe.icap.client;

import java.net.*;
import java.util.Optional;

import io.netty.handler.codec.http.HttpHeaders.Names;
import org.slf4j.*;

import xstr.session.XstrClientConfig;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelFuture;
import io.netty.handler.codec.http.*;
import xstr.util.Tuple2;
import xstr.util.XstrIni.Key;

public class ClientBootstrap {
   private static final Logger logger = LoggerFactory.getLogger(ClientBootstrap.class);

   private final XstrClientConfig config;

   public ClientBootstrap(XstrClientConfig config) {
      this.config = config;
      init();
   }

   public boolean isViaProxy() {
      return proxy != Proxy.NO_PROXY;
   }

   public boolean isProxyAut() {
      return proxyCred != null && !proxyUserName.isEmpty();
   }

   public enum Protocol {
      HTTP, HTTPS, WS, WSS
   }
//   private static boolean isUsingProxy;
   private URI uri;
   private String proxyUserName;
   private String proxyCred;
   private int targetPort;
   private String targetHost;
   private Protocol proto;
   private Proxy proxy;

   void init() {
      uri = URI.create(config.get(Key.WEB_URL));
      String proxyHost = config.get(Key.PROXY_HOST);
      String proxyPort = config.get(Key.PROXY_PORT);
      proxyCred = config.get(Key.PROXY_CRED);
      proxy = Proxy.NO_PROXY;
      String schema = uri.getScheme().toUpperCase();
      proto = Protocol.valueOf(schema);
      setupProxy(proxyHost + ":" + proxyPort);
      proxy = getProxyFor();
      boolean usingProxy = proxy != Proxy.NO_PROXY;
      String actualHost = uri.getHost();
      int actualPort = uri.getPort() > 0 ? uri.getPort() : proto==Protocol.HTTPS ? 443 : 80;
      Tuple2<String, Integer> actualHostPort = Tuple2.of(actualHost, actualPort);
      System.setProperty("webserver.host", actualHostPort.a);
      System.setProperty("webserver.port", actualHostPort.b+"");
      Tuple2<String, Integer> usingHostPort = hostPortOf(proxy).orElse(actualHostPort);
      targetHost = usingHostPort.a;
      targetPort = usingHostPort.b;
      logger.info("Configuration - URL: {}", uri);
      logger.info("Configuration - Use Proxy: {}", usingProxy);
      logger.info("Configuration - Host: {}", targetHost);
      logger.info("Configuration - Port: {}", targetPort);
   }

   private String getHttpHost() {
      String h = uri.getHost();
      int p = uri.getPort() > 0 ? uri.getPort() : proto==Protocol.HTTPS ? 443 : 80;
      return uri.getPort() > 0 ? uri.getHost() + ":" + uri.getPort() : uri.getHost();
   }

   private void setupProxy(String proxyStr) {
      if (proxyStr != null && proxyStr.length() > 0){
         int index = proxyStr.indexOf(':');
         String host;
         String port;
         if (index==-1) {
            host = proxyStr;
            port = "8080";
         } else {
            host = proxyStr.substring(0, index);
            port = proxyStr.substring(index + 1);
         }
         System.setProperty("java.net.useSystemProxies", "false");
         System.setProperty("http.proxyHost", host);
         System.setProperty("http.proxyPort", port);
         System.setProperty("http.nonProxyHosts", "none");
         System.setProperty("https.proxyHost", host);
         System.setProperty("https.proxyPort", port);
      } else {
         System.setProperty("java.net.useSystemProxies", "true");
         System.getProperties().remove("http.proxyHost");
         System.getProperties().remove("http.proxyPort");
         System.getProperties().remove("http.nonProxyHosts");
         System.getProperties().remove("https.proxyHost");
         System.getProperties().remove("https.proxyPort");
      }
   }

   private Proxy getProxyFor() {
      /**
      ws/wss defined in #Protocol, should be replease by http/https. Since there is not such schema defined.
       */
      URI temp = uri;
      String str = uri.toString().toUpperCase();
      if (str.startsWith(Protocol.WSS.name())){
         try {
            temp = new URI("https:"+str.substring(str.indexOf(':')+1));
         } catch (URISyntaxException e) {
            logger.error("can't convert wws uri to https uri");
         }
      } else if(str.startsWith(Protocol.WS.name())){
         try {
            temp = new URI("http:"+str.substring(str.indexOf(':')+1));
         } catch (URISyntaxException e) {
            logger.error("can't convert wws uri to https uri");
         }
      }

      try {
         for (Proxy proxy: ProxySelector.getDefault().select(temp)) {
            return proxy;
         }
      } catch (Exception e) {
//         logger.error("test proxy fialed",e);
      }

      return Proxy.NO_PROXY;
   }

   private static Optional<Tuple2<String, Integer>> hostPortOf(Proxy proxy) {
      if (proxy == Proxy.NO_PROXY) {
         return Optional.empty();
      }

      SocketAddress address = proxy.address();

      if (address instanceof InetSocketAddress) {
         InetSocketAddress inetSocketAddress = (InetSocketAddress)address;

         return Optional.of(Tuple2.of(inetSocketAddress.getHostString(), inetSocketAddress.getPort()));
      }

      return Optional.empty();
   }

   public ChannelFuture connect(Bootstrap bootStrap){
      logger.trace("Before connect");
      ChannelFuture r = bootStrap.connect(targetHost, targetPort);
      logger.trace("after connect");
      return r;
   }

   public HttpRequest createHttpReq(HttpMethod httpMethod, ByteBuf data) {
      return createHttpReq(httpMethod, "", data);
   }

   public HttpRequest createHttpReq(HttpMethod httpMethod, String path, ByteBuf data) {
      if (!path.isEmpty() && !path.startsWith("/"))
         path = "/" + path;
      DefaultFullHttpRequest req = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, httpMethod, uri + path + (uri.getQuery() == null ? "" : "?" + uri.getQuery()), data);
      req.headers().set(Names.HOST, getHttpHost());
      return req;
   }

   public boolean isHttps() {
      return proto == Protocol.HTTPS;
   }

   public boolean isWss() {
      return proto == Protocol.WSS;
   }

   public boolean isSSL(){
      return isHttps() || isWss();
   }
   public URI getUri() {
      return uri;
   }

   public String getProxyCred() {
      return proxyCred;
   }

   public URI getUri(String path){
      if (!path.isEmpty() && !path.startsWith("/"))
         path = "/" + path;
      return URI.create(config.get(Key.WEB_URL) + path);
   }



}
