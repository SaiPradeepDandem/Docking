/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xfe.icap.types;

import java.util.Date;
import java.util.Objects;

import xstr.session.QueryReplyRow;
import xfe.icap.amp.AmpTrade;
import com.omxgroup.xstream.amp.AmpStrategyTradeType_v2;

public class Trade {
//   private static final Logger logger = LoggerFactory.getLogger(Trade.class);
   private final QueryReplyRow data;

   public Date getTimestamp() {
      return data.getTimestamp();
   }

   public Trade(QueryReplyRow data) {
      this.data = data;
   }

   private String getBuyFirmId() {
      return data.getValue(AmpTrade.buyFirmId);
   }

   public String getSellFirmId() {
      return data.getValue(AmpTrade.sellFirmId);
   }

   public String getBuyTraderId() {
      return data.getValue(AmpTrade.buyTraderId);
   }

   public String getSellTraderId() {
      return data.getValue(AmpTrade.sellTraderId);
   }

   public boolean isCross() {
      String buyFirmId = getBuyFirmId();
      String sellFirmId = getSellFirmId();
      return (buyFirmId != null && buyFirmId.equals(sellFirmId));
   }

   public boolean isBuyLegType() {
      Integer buyStgyLegtype = data.getValue(AmpTrade.buyStrategyTradeType);
      return buyStgyLegtype != null && isLegType(buyStgyLegtype);
   }

   public boolean isSellLegType() {
      Integer sellStgyLegtype = data.getValue(AmpTrade.sellStrategyTradeType);
      return sellStgyLegtype != null && isLegType(sellStgyLegtype);
   }

   public Integer getStatus() {
      return data.getValue(AmpTrade.status);
   }

   public static boolean isLegType(Integer stgyType) {
      if (stgyType == null) return false;
      return (stgyType == AmpStrategyTradeType_v2.collarLeg ||
            stgyType == AmpStrategyTradeType_v2.fcFutureLeg ||
            stgyType == AmpStrategyTradeType_v2.fcSwapLeg ||
            stgyType == AmpStrategyTradeType_v2.soBondLeg ||
            stgyType == AmpStrategyTradeType_v2.sofcStrategySofcLeg ||
            stgyType == AmpStrategyTradeType_v2.sofcStrategySofcLegFutureLeg ||
            stgyType == AmpStrategyTradeType_v2.sofcStrategySofcLegSwapLeg ||
            stgyType == AmpStrategyTradeType_v2.soStrategySoLeg ||
            stgyType == AmpStrategyTradeType_v2.soStrategySoLegBondLeg ||
            stgyType == AmpStrategyTradeType_v2.soStrategySoLegSwapLeg ||
            stgyType == AmpStrategyTradeType_v2.soSwapLeg ||
            stgyType == AmpStrategyTradeType_v2.straddleLeg ||
            stgyType == AmpStrategyTradeType_v2.strangleLeg ||
            stgyType == AmpStrategyTradeType_v2.strategyLeg);
   }

   public static boolean isOutrightType(Integer stgyType) {
      if (stgyType == null) return false;
      return (stgyType == AmpStrategyTradeType_v2.outright);
   }

   public static boolean isStrategyType(Integer stgyType) {
      if (stgyType == null) return false;
      return (stgyType == AmpStrategyTradeType_v2.spreadOver ||
         stgyType == AmpStrategyTradeType_v2.futureCross ||
         stgyType == AmpStrategyTradeType_v2.strategy ||
         stgyType == AmpStrategyTradeType_v2.straddle ||
         stgyType == AmpStrategyTradeType_v2.strangle ||
         stgyType == AmpStrategyTradeType_v2.collar);
   }

   public boolean isSO_orManualSOFC() {
      String secCode = data.getValue(AmpTrade.secCode);
      Boolean isAutoTrade = data.getValue(AmpTrade.isAutoTrade);
      return secCode != null && (secCode.endsWith(".so") || (Boolean.FALSE.equals(isAutoTrade) && secCode.endsWith(".sofc")));
   }
}
