package xfe.icap.ui;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import xstr.util.Fx;

public class AttachableStage extends Stage {

   private static final double GAP_TO_ATTACH = 40;

   {
      yLis = new InvalidationListener() {

         @Override
         public void invalidated(Observable paramObservable) {
            double top = targetStage.getY();
            double bottom = top + targetStage.getHeight();
            double thisY = AttachableStage.this.getY();
            double thisHeight = AttachableStage.this.getHeight();
            double toPos;
            // align the two stages in the same Y
            if (Math.abs(thisY - top) < GAP_TO_ATTACH) {
               toPos = top;
            } else if (Math.abs(thisY + thisHeight - top) < GAP_TO_ATTACH) { // put this stage on the top
               toPos = top - thisHeight;
            } else if (Math.abs(thisY - bottom) < GAP_TO_ATTACH) {
               toPos = bottom;
            } else {
               toPos = Double.MAX_VALUE;
            }
            if (toPos != Double.MAX_VALUE) {
               yAttached.set(true);
               Fx.runLater(new Runnable() {

                  @Override
                  public void run() {
                     AttachableStage.this.setY(toPos);
                  }
               });
            } else {
               yAttached.set(false);
            }
         }
      };

      attachLis = new InvalidationListener() {

         @Override
         public void invalidated(Observable paramObservable) {
            if (attached.get()) {
               targetStageX = targetStage.getX();
               targetStageY = targetStage.getY();
               targetStage.xProperty().removeListener(parentStagePosLis);
               targetStage.yProperty().removeListener(parentStagePosLis);
               targetStage.xProperty().addListener(parentStagePosLis);
               targetStage.yProperty().addListener(parentStagePosLis);
            } else {
               targetStage.xProperty().removeListener(parentStagePosLis);
               targetStage.yProperty().removeListener(parentStagePosLis);
            }
         }

      };

      parentStagePosLis = new InvalidationListener() {

         @Override
         public void invalidated(Observable paramObservable) {
            double deltaX = targetStage.getX() - targetStageX;
            double deltaY = targetStage.getY() - targetStageY;
            targetStageX = targetStage.getX();
            targetStageY = targetStage.getY();
            Fx.run(new Runnable() {
               @Override
               public void run() {
                  AttachableStage.this.toFront();
                  AttachableStage.this.setX(AttachableStage.this.getX() + deltaX);
                  AttachableStage.this.setY(AttachableStage.this.getY() + deltaY);
               }
            });
         }

      };

      xLis = new InvalidationListener() {

         @Override
         public void invalidated(Observable paramObservable) {
            double left = targetStage.getX();
            double right = left + targetStage.getWidth();
            double thisX = AttachableStage.this.getX();
            double thisWidth = AttachableStage.this.getWidth();
            double toPos;
            // attach to left
            if (Math.abs(thisX + thisWidth - left) < GAP_TO_ATTACH) {
               toPos = left - thisWidth;
            } else if (Math.abs(thisX - right) < GAP_TO_ATTACH) { // attach to right
               toPos = right;
            } else {
               toPos = Double.MAX_VALUE;
            }
            if (toPos != Double.MAX_VALUE) {
               xAttached.set(true);
               Fx.runLater(new Runnable() {

                  @Override
                  public void run() {
                     AttachableStage.this.setX(toPos);
                  }
               });
            } else {
               xAttached.set(false);
            }
         }
      };

      iconifyLis = new InvalidationListener() {

         @Override
         public void invalidated(Observable arg0) {
            AttachableStage.this.setIconified(targetStage.isIconified());
         }
      };
   }

   public AttachableStage(StageStyle transparent, Stage targetStage, boolean isPosition, boolean isIconify) {
      super(transparent);
      this.targetStage = targetStage;
      this.positionAttachable = isPosition;
      this.iconifyAttachable = isIconify;

      this.addEventFilter(WindowEvent.WINDOW_HIDDEN, new EventHandler<WindowEvent>(){

         @Override
         public void handle(WindowEvent paramT) {
            if(positionAttachable){
               xProperty().removeListener(xLis);
               yProperty().removeListener(yLis);
               attached.removeListener(attachLis);
            }
            if(isIconify){
               targetStage.iconifiedProperty().removeListener(iconifyLis);
            }
         }
      });

      this.addEventFilter(WindowEvent.WINDOW_SHOWN,new EventHandler<WindowEvent>() {

         @Override
         public void handle(WindowEvent paramT) {
            if(positionAttachable){
               xProperty().removeListener(xLis);
               yProperty().removeListener(yLis);
               attached.removeListener(attachLis);

               xProperty().addListener(xLis);
               yProperty().addListener(yLis);
               attached.addListener(attachLis);
            }

            if(isIconify){
               targetStage.iconifiedProperty().removeListener(iconifyLis);
               targetStage.iconifiedProperty().addListener(iconifyLis);
            }

         }
      });

   }

   private final BooleanProperty  xAttached = new SimpleBooleanProperty(false);
   private final BooleanProperty  yAttached = new SimpleBooleanProperty(false);
   private final BooleanBinding  attached = Bindings.and(yAttached, xAttached);
   private final Stage targetStage;
   private final boolean positionAttachable ;
   private final boolean iconifyAttachable ;
   private final InvalidationListener iconifyLis;
   private final InvalidationListener yLis;
   private final InvalidationListener xLis;
   private final InvalidationListener attachLis;
   private final InvalidationListener parentStagePosLis;
   private double targetStageX;
   private double targetStageY;

}
