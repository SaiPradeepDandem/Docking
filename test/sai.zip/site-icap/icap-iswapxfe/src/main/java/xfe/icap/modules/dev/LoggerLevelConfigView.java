package xfe.icap.modules.dev;

import ch.qos.logback.classic.Level;
import xfe.ui.GenericView;
import xfe.ui.notifications.ModalAlertModule;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by jiadin on 2015-03-25.
 */
public class LoggerLevelConfigView implements GenericView<VBox> {

   private static Logger logger;

   public void setOnClose(Runnable onCloseHandler) {

      this.onCloseHandler = onCloseHandler;
   }

   private final Label info = new Label("This is set to change the log level of select class. It does not persist the updates.");
   private final ComboBox<String> classNameCombo = new ComboBox<>();
   private final ObservableList<String> classNameList  = FXCollections.observableList(new ArrayList(10));

//   private final ObservableList<String> filteredNameList = Fx.dynamicFilterByF(classNameList, new Fun1<String, ObservableBooleanValue>() {
//      @Override
//      public ObservableBooleanValue call(String className) {
//
//         return new BooleanBinding() {
//            {
//               bind(classNameCombo.getEditor().textProperty());
//            }
//            @Override
//            protected boolean computeValue() {
//               return className.toLowerCase().contains(classNameCombo.getEditor().textProperty().get().toLowerCase());
//            }
//
//         };
//      }
//   });

   private static final String[] wantedPackagePrefix = {"xstr","com.nomx","xmp"};

//   private final static Callback<String,Boolean> classNameFilter = new Callback<String, Boolean>() {
//      @Override
//      public Boolean call(String className) {
//         if(className.indexOf('$')>=0) return  Boolean.FALSE;
//         for(String str:wantedPackagePrefix){
//            if(className.startsWith(str)){
//               try {
////                  Class.forName(className).getDeclaredField("logger");
//                  return Boolean.TRUE;
//               } catch (Throwable e) {
//                  return Boolean.FALSE;
//               }
//            }
//         }
//         return Boolean.FALSE;
//      }
//   };

   private static final Callback<Class,Boolean> classFilter = new Callback<Class, Boolean>() {
      @Override
      public Boolean call(Class aClass) {
         String className = aClass.getName();
         if(aClass.isInterface() || className.indexOf('$')>=0) return  Boolean.FALSE;
         for(String str:wantedPackagePrefix){
            if(className.startsWith(str)){
               try {
                  aClass.getDeclaredField("logger");
                  return Boolean.TRUE;
               } catch (Throwable e) {
                  return Boolean.FALSE;
               }
            }
         }
         return Boolean.FALSE;
      }
   };

   private final ToggleGroup levelGroup = new ToggleGroup();
   private final Map<Level,Toggle> levelToggleMap = new HashMap<>(15);
   private final RadioButton errorButron = createLevelButton(levelGroup,"Error",levelToggleMap);
   private final RadioButton warnButron = createLevelButton(levelGroup,"Warn",levelToggleMap);
   private final RadioButton infoButron = createLevelButton(levelGroup,"Info",levelToggleMap);
   private final RadioButton debugButron = createLevelButton(levelGroup,"Debug",levelToggleMap);
   private final RadioButton traceButron = createLevelButton(levelGroup,"Trace",levelToggleMap);
   private final RadioButton offButron = createLevelButton(levelGroup,"Off",levelToggleMap);
   private final HBox topBox = new HBox(){{this.getChildren().addAll(errorButron,warnButron,infoButron,debugButron,traceButron,offButron);}};

   private final Button closeBtn = new Button("Close");
   private final VBox rootNode = new VBox(){{this.getChildren().addAll(info,topBox,classNameCombo,closeBtn);}};

   public LoggerLevelConfigView() {
      info.setWrapText(true);
      rootNode.setMaxHeight(200);
      rootNode.setMinHeight(200);
      rootNode.setPrefHeight(200);
      rootNode.setMaxWidth(400);
      rootNode.setMinWidth(400);
      rootNode.setPrefWidth(400);
      classNameCombo.setMaxWidth(300);
      classNameCombo.setMinWidth(300);
      classNameCombo.setPrefWidth(300);
      rootNode.setAlignment(Pos.CENTER);
      rootNode.setSpacing(10);
      topBox.setSpacing(10);
      closeBtn.setOnAction(event -> {
         if (onCloseHandler != null)
            onCloseHandler.run();
      });

      rootNode.getStyleClass().add("xfe-popup");
      classNameCombo.setEditable(true);
      classNameCombo.getSelectionModel().selectedItemProperty().addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            String className = classNameCombo.getSelectionModel().getSelectedItem();
            if(className!=null && className.length()>0) {
               ch.qos.logback.classic.Logger selectedLogger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(className);
               Level level = selectedLogger.getLevel();
               levelGroup.selectToggle(levelToggleMap.get(level));
            }
         }
      });
      classNameCombo.setItems(classNameList);
   }


   private static List<Class> list(ClassLoader CL)throws NoSuchFieldException, SecurityException,IllegalArgumentException, IllegalAccessException {
      Class CL_class = CL.getClass();
      while (CL_class != java.lang.ClassLoader.class) {
         CL_class = CL_class.getSuperclass();
      }
      java.lang.reflect.Field ClassLoader_classes_field = CL_class.getDeclaredField("classes");
      ClassLoader_classes_field.setAccessible(true);
      Vector<Class> v = (Vector < Class >) ClassLoader_classes_field.get(CL);
      List<Class> rtn = new ArrayList<Class>(v.size());
      rtn.addAll(v);
      return  rtn;
   }


   private RadioButton createLevelButton(ToggleGroup levelGroup, String level, Map<Level, Toggle> levelToggleMap) {
      RadioButton rtn = new RadioButton(level);
      levelToggleMap.put(Level.toLevel(level),rtn);
      rtn.setToggleGroup(levelGroup);
      rtn.selectedProperty().addListener(new InvalidationListener() {
         @Override
         public void invalidated(Observable observable) {
            String className = classNameCombo.getSelectionModel().getSelectedItem();
            if(className!=null && className.length()>0) {
               ch.qos.logback.classic.Logger selectedLogger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(className);
               selectedLogger.setLevel(Level.toLevel(rtn.getText()));
            }
         }
      });
      return rtn;
   }

   @Override
   public VBox getRootElement() {
      classNameList.clear();
      classNameList.add("com.nomx.libjxapp.newIterator.CachedQueryFeed");
      SortedSet<String> newList = new TreeSet<String>();
      try {
         ClassLoader myCL = Thread.currentThread().getContextClassLoader();
         while (myCL != null) {
            for (Class iter : list(myCL)) {
               if(classFilter.call(iter)){
                  newList.add(iter.getCanonicalName());
               }
            }
            myCL = myCL.getParent();
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      classNameList.addAll(newList);
      return rootNode;
   }

   @Override
   public void requestFocus() {
      classNameCombo.requestFocus();
   }

   private Runnable onCloseHandler;
}
