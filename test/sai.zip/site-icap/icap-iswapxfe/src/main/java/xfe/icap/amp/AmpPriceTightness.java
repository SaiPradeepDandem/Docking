package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnConversionAccessor;

/**
 * Created by baasim on 23/05/2016.
 */
public class AmpPriceTightness extends AmpAccessor {
   public static final  AmpQreq req = AMP.qREQ("priceTightnessReq");
   public static final  AmpQrep rep = AMP.qREP("priceTightnessRep");

   public static final AsnConversionAccessor<Double> reqOutrightLimit = acc(AMP.qREQ("priceTightnessReq.outrightLimit"), Double.class);
   public static final AsnConversionAccessor<Double> reqSpreadLimit = acc(AMP.qREQ("priceTightnessReq.spreadLimit"), Double.class);
   public static final AsnConversionAccessor<Double> reqButterflyLimit = acc(AMP.qREQ("priceTightnessReq.butterflyLimit"), Double.class);
   public static final AsnConversionAccessor<Long> secBoardIdx = acc(AMP.qREP("priceTightnessRep.secBoardIdx"), Long.class);
}
