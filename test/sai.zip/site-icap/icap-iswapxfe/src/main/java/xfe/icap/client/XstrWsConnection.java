package xfe.icap.client;

import xmp.message.XMP.XmpReply;
import xstr.amp.Xtr;
import xstr.session.Credentials;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http.HttpHeaders.Names;
import io.netty.handler.codec.http.websocketx.WebSocketClientProtocolHandler;
import io.netty.handler.codec.http.websocketx.WebSocketVersion;
import io.netty.handler.codec.protobuf.ProtobufDecoder;
import io.netty.handler.codec.protobuf.ProtobufEncoder;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.util.concurrent.GenericFutureListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xmp.message.XmpClientCodec;
import xstr.util.Duration;
import xstr.util.Functions;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;
import xstr.util.exception.Exceptions;
import xstr.util.exception.XtrSessionException;
import xstr.netty.XfeUserAgent;
import xstr.netty.XstrWebSocketCodec;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

class XstrWsConnection extends XstrWebConnection {
   private static final Logger logger = LoggerFactory.getLogger(XstrWsConnection.class);

   private final AtomicReference<Future<Channel>> channelFutureRef = new AtomicReference<>();
   private final Promise<Void> closePromise;

   private ChannelHandler getWebsocketHandler(Promise<Channel> channelPromise) {
      DefaultHttpHeaders headers = new DefaultHttpHeaders();
      headers.add(Names.USER_AGENT, new XfeUserAgent(Xtr.getVersion()).toString());
      return new WebSocketClientProtocolHandler(
         clientBootstrap.getUri("api/websocket"),
         WebSocketVersion.V13,
         null,
         false,
         headers,
         256 * 1024) {
         @Override
         public void userEventTriggered(ChannelHandlerContext ctx, Object evt) {
            logger.debug("User event triggered: {}", evt);

            if (evt == ClientHandshakeStateEvent.HANDSHAKE_COMPLETE) {
               logger.info("WebSocket handshake complete");
               ctx.fireUserEventTriggered(LOGON_REQUIRED);
            }
         }

         @Override
         public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
            logger.warn("Websocket exception: {}", Exceptions.format(cause));
            logger.debug("Websocket exception: ", cause);
            channelPromise.trySetFailure(Functions.wrapAsException(cause));
            super.exceptionCaught(ctx, cause);
         }
      };
   }

   static Future<? extends XstrWebConnection> connect(Credentials cred,
                                                      WsSessionWrapper session) {
      XstrWsConnection connection = new XstrWsConnection(session);
      return connection.channel(cred).map(x -> connection).onError(err ->
         connection.dispose().thenRaise(err)
      );
   }


   XstrWsConnection(WsSessionWrapper sessionWrapper) {
      super(sessionWrapper);
      logger.debug("Creating new connection object.");
      closePromise = Futures.newPromise("closePromise");
   }

   @Override
   public Future<Channel> channel(Credentials cred) {
      Future<Channel> cf = channelFutureRef.get();
      if (cf == null) {
         Promise<Channel> newCF = Futures.newPromise("ws-channel");
         if (channelFutureRef.compareAndSet(null, newCF)) {
            cf = newCF;
            createChannel(cred, newCF);
         } else {
            logger.warn("Channel future modified concurrently.");
            cf = channel(cred);
         }
      }
      return cf;
   }

   @Override
   public Future<Void> closeFuture() {
      return closePromise;
   }

   private void scheduleReconnect(Future<Channel> channelPromise) {
      if (channelFutureRef.weakCompareAndSet(channelPromise, null)) {
         logger.info("Scheduling channel reconnect in 1 second");
         schedule(Duration.of(1, TimeUnit.SECONDS), () -> {
            Future<Channel> cf = channel();
            cf.addListener(f -> {
               try {
                  f.get();
                  logger.info("Reconnect succeeded. Re-sending failed requests.");
                  transactionHandler.resendMessages();
                  queryHandler.resendMessages();
//                  subscriptionHandler.resendMessages();
               } catch (Exception e) {
                  logger.info("Reconnect failed");
                  scheduleReconnect(cf);
               }
            });
         });
      } else {
         logger.warn("Concurrent modification attempt on channel future.");
      }
   }

   private void createChannel(Credentials cred, Promise<Channel> channelPromise) {
      logger.debug("Creating channel.");

      Bootstrap bootstrap = new Bootstrap();
      ChannelInitializer<SocketChannel> handler = new ChannelInitializer<SocketChannel>() {
         @Override
         protected void initChannel(SocketChannel channel) {
            logger.debug("Initializing channel ...");
            ReadTimeoutHandler readTimeoutHandler = new ReadTimeoutHandler((int) sessionWrapper.getConnectTimeout().in(TimeUnit.SECONDS));
            ChannelPipeline pipeline = channel.pipeline();
            pipeline.addFirst(readTimeoutHandler);
            installProxyHandler(pipeline);
            installSslHandler(pipeline);
            pipeline.addLast("logging", new LoggingHandler("xstr.net.message.websocket", LogLevel.TRACE));
            pipeline.addLast("http-codec", new HttpClientCodec());
            pipeline.addLast("http-aggregator", new HttpObjectAggregator(8192){
               @Override
               protected void decode(ChannelHandlerContext ctx, HttpObject msg, List<Object> out) throws Exception {
                  if (msg instanceof HttpResponse) {
                     HttpResponse res = (HttpResponse) msg;
                     if (HttpResponseStatus.BAD_REQUEST.equals(res.getStatus())) {
                        channelPromise.trySetFailure(new XtrSessionException(res.getStatus().toString()));
                        dispose();
                        ctx.close();
                        return;
                     }
                  }
                  super.decode(ctx, msg, out);
               }
            });
            pipeline.addLast("ws-handler", getWebsocketHandler(channelPromise));
            pipeline.addLast("xstr-ws-codec", new XstrWebSocketCodec());
            pipeline.addLast("protobufDecoder", new ProtobufDecoder(XmpReply.getDefaultInstance()));
            pipeline.addLast("protobufEncoder", new ProtobufEncoder());
            pipeline.addLast("xstr-message-codec", new XmpClientCodec());
            pipeline.addLast("txn-handler", transactionHandler);
            pipeline.addLast("qry-handler", queryHandler);
            pipeline.addLast("sub-handler", subscriptionHandler);
            pipeline.addLast("xstr-logon-handler", logonHandler(cred, channelPromise));
            pipeline.addLast("xstr-logoff-handler", logoffHandler);
            pipeline.addLast("session-reply-handler", sessionWrapper.sessionMessageHandler);
         }
      };

      int timeout = (int)sessionWrapper.getConnectTimeout().in(TimeUnit.MILLISECONDS);
      bootstrap
         .group(eventLoopGroup)
         .channel(NioSocketChannel.class)
         .option(ChannelOption.TCP_NODELAY,true)
         .option(ChannelOption.CONNECT_TIMEOUT_MILLIS,timeout)
         .handler(handler);

      clientBootstrap.connect(bootstrap).addListener(new GenericFutureListener<ChannelFuture>() {
         @Override
         public void operationComplete(ChannelFuture connectFuture) {
            try {
               connectFuture.get();
               Channel channel = connectFuture.channel();
               channel.closeFuture().addListener(future -> {
                  if (live()) {
                     // If the object is live we need to allow for a reconnect.
                     scheduleReconnect(channelPromise);
                     logger.info("Channel future ref successfully reset.");
                     try {
                        future.get();
                        String msg = "Connection closed unexpectedly.";
                        logger.warn(msg);
                        channelPromise.trySetFailure(new XtrSessionException(msg));
                     } catch (Exception e) {
                        logger.warn("Connection closed unexpectedly with error: {}", Exceptions.format(e));
                        channelPromise.trySetFailure(e);
                     }
                  }
               });
               logger.debug("WS Connect completed OK");
            } catch (Exception t) {
               logger.warn("WS Failed to connect: {}", Exceptions.format(t));
               logger.debug("WS Failed to connect.", t);
               channelPromise.trySetFailure(t);
            }
         }
      });
   }
}
