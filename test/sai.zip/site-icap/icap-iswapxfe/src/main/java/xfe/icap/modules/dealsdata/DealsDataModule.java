package xfe.icap.modules.dealsdata;

import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import xfe.icap.amp.AmpDeal;
import xfe.icap.modules.tradesdata.TradesOrDealsPriceAggregateData;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import xstr.util.ListenerTracker;
import xstr.util.Tuple2;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.*;

@Module.Autostart
public class DealsDataModule extends SessionScopeModule {
    private final ListenerTracker tracker = new ListenerTracker();
    private final Map<Tuple2<String, String>, Map<BigDecimal, TradesOrDealsPriceAggregateData>> dealsAggregateByPriceBySecBoard = new HashMap<>();
    private ObservableList<ObservableReplyRow> allDeals;
    private Runnable dealUpdateNotifier;
    private DealsFeedAdapter dealsFeed;
    private FeedAggregator<ObservableReplyRow> dealAggregator;
    private ListChangeListener<? super ObservableReplyRow> dealsListener;

    public ObservableList<ObservableReplyRow> getAllDeals() {
        return allDeals;
    }

    public Map<Tuple2<String, String>, Map<BigDecimal, TradesOrDealsPriceAggregateData>> getDealsAggregateByPriceBySecBoard() {
        return dealsAggregateByPriceBySecBoard;
    }

    public void setDealUpdateNotifier(Runnable dealUpdateNotifier) {
        this.dealUpdateNotifier = dealUpdateNotifier;
    }

    @Override
    public Future<Void> startModule() {
        dealsListener = c -> {
            while (c.next()) {
                if (c.wasRemoved()) {
                    c.getRemoved().forEach(row -> {
                        allDeals.remove(row);
                        processDeal(row, false);
                    });
                } else if (c.wasAdded()) {
                    c.getAddedSubList().forEach(row -> processDeal(row, true));
                }
            }
        };
        dealAggregator = new FeedAggregator<>(AmpDeal.rep, new ObservableReplyRow.ObservableRowFactory());
        activeSessionModule.getSession().ifPresent(session -> {
            dealsFeed = new DealsFeedAdapter(session.getFeedSource(AmpDeal.req));
            tracker.addFeedListener(dealsFeed, dealAggregator);
            dealsFeed.startPolling();
        });
        Comparator<QueryReplyRow> ampTradeIdComparator = (row1, row2) -> {
            Long dealNo1 = row1.getValue(AmpDeal.dealNo);
            Long dealNo2 = row2.getValue(AmpDeal.dealNo);
            return dealNo1.compareTo(dealNo2);
        };
        Comparator<QueryReplyRow> ampDealTimeComparator = (row1, row2) -> {
            Date dealTime1 = row1.getValue(AmpDeal.dealTime);
            Date dealTime2 = row2.getValue(AmpDeal.dealTime);
            return dealTime2.compareTo(dealTime1);
        };

        allDeals = Fx.sortBy(dealAggregator.items, ampDealTimeComparator.thenComparing(ampTradeIdComparator));
        allDeals.addListener(dealsListener);
        return Future.SUCCESS;
    }

    @Override
    public Future<Void> stopModule() {
        if (dealsFeed != null) {
            dealsFeed.stopPolling();
            dealsFeed.dispose();
            dealsFeed = null;
        }
        dealAggregator.reset();
        dealAggregator = null;
        allDeals.removeListener(dealsListener);
        dealsListener = null;

        tracker.rollback();
        return Future.SUCCESS;
    }

    private void processDeal(ObservableReplyRow row, boolean isAddDeal) {
        final Tuple2<String, String> secBoardKey = buildSecBoardKey(row);
        if (secBoardKey != null) {
            updateDealsAggregatePriceMap(secBoardKey, row, isAddDeal);
        }
    }

    /**
     * Builds the sec board key tuple.
     *
     * @param row deal row
     * @return Tuple2<String, String>
     */
    private Tuple2<String, String> buildSecBoardKey(ObservableReplyRow row) {
        String secCode = row.getValue(AmpDeal.secCode);
        String boardId = row.getValue(AmpDeal.boardId);
        if (secCode != null && boardId != null) {
            return new Tuple2<>(secCode, boardId);
        }
        return null;
    }

    private void updateDealsAggregatePriceMap(Tuple2<String, String> secBoardKey, ObservableReplyRow row, boolean isAddDeal) {
        Optional<ServerSession> session = activeSessionModule.getSession();
        if (!session.isPresent()) {
            return;
        }
        String userId = session.get().getLoggedOnUserId();
        String firmId = session.get().getLoggedOnUserFirmId();

        // Creating the priceMap for the secBoardKey if not present.
        BigDecimal price = row.getValue(AmpDeal.price);
        Map<BigDecimal, TradesOrDealsPriceAggregateData> priceMap = dealsAggregateByPriceBySecBoard.computeIfAbsent(secBoardKey, k -> new HashMap<>());

        /* Ensuring to remove the deal in all prices. This is required if a deal is amended with a new
         price value or the deal is cancelled.*/
        List<BigDecimal> pricesToRemove = new ArrayList<>();
        priceMap.forEach((p, data) -> {
            boolean isEmpty = data.removeDeal(row);
            if (isEmpty) {
                pricesToRemove.add(p);
            }
        });
        pricesToRemove.forEach(priceMap::remove);

        if (isAddDeal) {
            /* Build/Get the price aggregate data object and add the deal */
            TradesOrDealsPriceAggregateData priceAggregateData = priceMap.computeIfAbsent(price, k -> new TradesOrDealsPriceAggregateData(price, userId, firmId));
            priceAggregateData.addDeal(row);
        }

        if (dealUpdateNotifier != null) {
            dealUpdateNotifier.run();
        }
    }

}
