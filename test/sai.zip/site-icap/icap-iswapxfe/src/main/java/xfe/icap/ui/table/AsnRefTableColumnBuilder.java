package xfe.icap.ui.table;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javafx.scene.control.TableColumnBuilder;

import xstr.session.QueryReplyRow;
import xstr.amp.AMP.AmpQrep;
import xfe.util.scene.control.LayerFactory;
import xfe.ui.table.AsnRefTableColumn;


public class AsnRefTableColumnBuilder<B extends AsnRefTableColumnBuilder<B>> extends TableColumnBuilder<QueryReplyRow, String, AsnRefTableColumnBuilder<B>> {

	private Double prefWidth;
	private String displayName;
	private AmpQrep rep;
	private Boolean isResizable;
	private final ArrayList<String> styles = new ArrayList<String>();
	private final List<LayerFactory<QueryReplyRow, ? super String>> layerFactories = new ArrayList<LayerFactory<QueryReplyRow, ? super String>>();

	protected AsnRefTableColumnBuilder() {
	}


	private AsnRefTableColumnBuilder(AsnRefTableColumnBuilder<B> other) {

		this.prefWidth = other.prefWidth;
		this.displayName = other.displayName;
		this.rep = other.rep;
		this.isResizable = other.isResizable;
		this.styles.addAll(other.styles);
		this.layerFactories.addAll(other.layerFactories);
	}

	public AsnRefTableColumnBuilder<B> prefWidth(Double prefWidth) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.prefWidth = prefWidth;
		return ret;
	}

	public AsnRefTableColumnBuilder<B> displayName(String displayName) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.displayName = displayName;
		return ret;
	}

	public AsnRefTableColumnBuilder<B> qRep(AmpQrep rep) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.rep = rep;
		return ret;
	}

	public AsnRefTableColumnBuilder<B> resizable(Boolean isResizable) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.isResizable = isResizable;
		return ret;
	}

	public AsnRefTableColumnBuilder<B> clearStyles() {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.styles.clear();
		return ret;
	}

	public AsnRefTableColumnBuilder<B> style(String style) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.styles.add(style);
		return ret;
	}

	public AsnRefTableColumnBuilder<B> styles(String... styles) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.styles.addAll(Arrays.asList(styles));
		return ret;
	}

	public AsnRefTableColumnBuilder<B> layerFactory(LayerFactory<QueryReplyRow, ? super String> layerFactory) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.layerFactories.add(layerFactory);
		return ret;
	}

	public AsnRefTableColumnBuilder<B> layerFactories(LayerFactory<QueryReplyRow, ? super String>... layerFactories) {
		AsnRefTableColumnBuilder<B> ret = new AsnRefTableColumnBuilder<B>(this);
		ret.layerFactories.addAll(Arrays.asList(layerFactories));
		return ret;
	}

	public AsnRefTableColumn build() {
		AsnRefTableColumn ret = new AsnRefTableColumn();
		if (prefWidth != null) ret.setPrefWidth(prefWidth);
		if (displayName != null) ret.setDisplayName(displayName);
		if (rep != null) ret.setQueryRep(rep);
		if (isResizable != null) ret.setResizable(isResizable);
		if (!styles.isEmpty()) ret.getCellStyleClass().addAll(styles);
		//if (!layerFactories.isEmpty()) ret.setLayerFactories(layerFactories);

		return ret;
	}

}
