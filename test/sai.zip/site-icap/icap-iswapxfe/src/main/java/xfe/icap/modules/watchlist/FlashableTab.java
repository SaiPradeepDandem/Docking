package xfe.icap.modules.watchlist;

import xstr.util.Fx;
import javafx.beans.property.*;
import javafx.collections.ObservableList;

import com.nomx.persist.watchlist.WatchlistSpec_v2;
import xstr.util.concurrent.ReschedulableTask;
import xfe.util.scene.control.NodeFlashDecorator;
import xfe.icap.XfeSession;

public class FlashableTab extends InstrumentTab {
   public static final String STYLE_FLASH_BG = "xfe-tab-flash-bg";
   public static final String STYLE_STOP_FLASH_BG = "xfe-tab-stop-flash-bg";

   private final LongProperty timeToStopFlash = new SimpleLongProperty(-1);
   private final ReschedulableTask task;
   private final NodeFlashDecorator flashDecorator;

   public FlashableTab(WatchlistSpec_v2 watchSpec, XfeSession xfeSession){
      super(watchSpec);
      task = new ReschedulableTask(xfeSession.getUnderlyingSession().getThreadPool()) {

         @Override
         public void run() {
            stopFlash();
         }

         @Override
         public String toString(){
            return "stopTabFlashTask";
         }
      };
      flashDecorator = new NodeFlashDecorator(titleBox,null,null);
   }

   public void stopFlash(){
     Fx.run(new Runnable() {
       @Override
       public void run() {
         ObservableList<String> styles = titleBox.getStyleClass();
         styles.removeAll(NodeFlashDecorator.FLASH_TOKEN);
         styles.removeAll(STYLE_FLASH_BG);
         if(!styles.contains(STYLE_STOP_FLASH_BG)){
           styles.add(STYLE_STOP_FLASH_BG);
         }
       }
     });
   }

   public void setFlash(long timeToStop){
      ObservableList<String> styles = titleBox.getStyleClass();
      styles.removeAll(STYLE_STOP_FLASH_BG);
      if(this.selectedProperty().get()){
         return;
      }
      if(timeToStopFlash.get()<timeToStop){
         timeToStopFlash.set(timeToStop);
         task.setSchedule(timeToStop);
      }
      if(!styles.contains(STYLE_FLASH_BG)){
         styles.add(STYLE_FLASH_BG);
      }
      if(!styles.contains(NodeFlashDecorator.FLASH_TOKEN)){
         styles.add(NodeFlashDecorator.FLASH_TOKEN);
      }
   }

   public void stopFlashWhenSelected(){
      stopFlash();
      task.cancel();
   }

   public void dispose(){
      flashDecorator.dispose();
      task.dispose();
   }
}
