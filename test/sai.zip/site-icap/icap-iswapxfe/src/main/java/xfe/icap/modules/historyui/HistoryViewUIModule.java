package xfe.icap.modules.historyui;

import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.util.concurrent.Future;

@Module.Autostart
public class HistoryViewUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(HistoryViewUIModule.class);

   private Pane root;

   public Pane getRoot() {
      return root;
   }

   @Override
   public Future<Void> startModule() {
      this.historyviewTable = new HistoryViewTable(this);
      this.root = new StackPane();
      this.root.setId(MidiLayoutViews.HISTORYVIEW);
      this.root.getChildren().add(this.historyviewTable);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      return super.stopModule();
   }

   private HistoryViewTable historyviewTable;
}
