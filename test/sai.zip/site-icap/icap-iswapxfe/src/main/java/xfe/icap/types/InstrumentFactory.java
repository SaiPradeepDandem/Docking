package xfe.icap.types;

import xstr.util.Fun0;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.util.Callback;

import xstr.amp.AsnConversionAccessor;
import xstr.util.Fx;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.modules.watchlist.OrderSpecialTypeDecorator;
import xstr.session.ObservableReplyRow;

public class InstrumentFactory {
   public static Callback<ObservableReplyRow, ObservableValue<String>> typeFactory(boolean isBuy) {
      AsnConversionAccessor<String> acc = isBuy ? AmpIcapSecBoardTrim2.bidSpecialOrderType : AmpIcapSecBoardTrim2.offerSpecialOrderType;

      return row -> {
         if (row != null) {
            return Bindings.createStringBinding(new Fun0<String>() {
               @Override
               public String call() {
                  return OrderSpecialTypeDecorator.getString(row.getValue(acc));
               }
            }, row.getProperty(acc));
         } else {
            return Fx.constOf("");
         }
      };
   }

   public static Callback<ObservableReplyRow, ObservableValue<String>> firmFactory(boolean isBuy, XfeSession session ) {
      AsnConversionAccessor<String> acc = isBuy ? AmpIcapSecBoardTrim2.bidUserId : AmpIcapSecBoardTrim2.offerUserId;
      return row -> {
         if (row != null) {
            return Fx.map(row.getProperty(acc), (userId) -> {
               if (userId == null) {
                  return "";
               } else {
                  if (session.traderFirmMap != null)
                     return session.traderFirmMap.getFirmId(userId);
                  else
                     return "";
               }
            });
         } else {
            return Fx.constOf("");
         }
      };
   }

}
