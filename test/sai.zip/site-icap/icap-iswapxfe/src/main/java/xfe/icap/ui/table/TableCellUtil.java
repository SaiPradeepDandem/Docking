package xfe.icap.ui.table;

import javafx.scene.control.TableCell;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.types.SecBoardStaticInfo;
import xfe.util.Util;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.Date;
import java.util.function.BiFunction;

public class TableCellUtil {
    private static final Logger logger = LoggerFactory.getLogger(TableCellUtil.class);

    private TableCellUtil() {}

    // Used for Price cell that uses priceFormatter
    public static class PriceCell extends TableCell<ObservableReplyRow, BigDecimal> {
        private AsnConversionAccessor<String> secCode;
        private AsnConversionAccessor<String> boardId;
        private BiFunction<String, String, Future<SecBoardStaticInfo>> secBoardStaticInfoGetter;

        public PriceCell(AsnConversionAccessor<String> secCode, AsnConversionAccessor<String> boardId,
                         BiFunction<String, String, Future<SecBoardStaticInfo>> secBoardStaticInfoGetter) {
            this.secCode = secCode;
            this.boardId = boardId;
            this.secBoardStaticInfoGetter = secBoardStaticInfoGetter;
        }

        @Override
        protected void updateItem(BigDecimal item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null || empty) {
                setText(null);
                setGraphic(null);
            } else if (getTableRow() != null && getTableRow().getItem() != null) {
                setTextWithFormatter(item);
            }
        }

        private void setTextWithFormatter(BigDecimal item) {
            ObservableReplyRow rowItem = (ObservableReplyRow) getTableRow().getItem();
            try {
                if (secBoardStaticInfoGetter != null) {
                    secBoardStaticInfoGetter.apply(rowItem.getValue(secCode), rowItem.getValue(boardId)).map(info -> {
                        if (getTableRow() != null && getTableRow().getItem() != null) {
                            ObservableReplyRow newRowItem = (ObservableReplyRow) getTableRow().getItem();
                            if (rowItem == newRowItem) {
                                setText(info.priceFormatter.apply(item));
                            }
                        }
                        return Future.SUCCESS;
                    });
                } else {
                    setText(xstr.util.Util.getDefaultFormatter().apply(item));
                }
            } catch (Exception ex) {
                logger.error("Unable to fetch the price for the security, {}@{}", secCode, boardId);
            }
        }
    }

    // Used for OrderSide data cell that should display Buy or Sell
    public static class BuySellCell extends TableCell<ObservableReplyRow, OrderSide> {

        @Override
        protected void updateItem(OrderSide item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null) {
                setText(null);
            } else {
                setText(OrderSide.BUY == item ? "Buy" : "Sell");
            }
        }
    }

    // Used for OrderSide data cell that should display Bid or Offer
    public static class BidOfferCell extends TableCell<ObservableReplyRow, OrderSide> {
        @Override
        protected void updateItem(OrderSide item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null) {
                setText(null);
            } else {
                setText(OrderSide.BUY == item ? "Bid" : "Offer");
            }
        }
    }

    // Used for String data cell
    public static class StringCell extends TableCell<ObservableReplyRow, String> {

        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            setText(item);
        }
    }

    // Used for BigDecimal data cell
    public static class BigDecimalCell extends TableCell<ObservableReplyRow, BigDecimal> {

        @Override
        protected void updateItem(BigDecimal item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null || empty)
                setText(null);
            else
                setText(item.toString());
        }
    }

    // Used for Time data cell
    public static class TimeCell extends TableCell<ObservableReplyRow, Date> {
        @Override
        protected void updateItem(Date item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null) {
                setText(null);
            } else {
                setText(Util.formatTime(item));
            }
        }
    }
}
