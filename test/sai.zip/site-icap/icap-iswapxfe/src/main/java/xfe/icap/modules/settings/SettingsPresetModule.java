package xfe.icap.modules.settings;

import com.google.common.base.Strings;
import com.nomx.domain.types.InstrumentsFilter;
import com.nomx.persist.ParametersStorage;
import com.nomx.persist.PersistantName;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.nomx.persist.watchlist.WatchlistSpec_v2.Security;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.app.XfeApplicationContext;
import xfe.module.Module;
import xfe.modules.logon.LogonModule;
import xfe.modules.session.SessionScopeModule;
import xfe.types.UiSession;
import xstr.session.Preset;
import xstr.session.Presets;
import xstr.util.Fun1;
import xstr.util.Fun1Throws;
import xstr.util.Fx;
import xstr.util.concurrent.Future;
import xstr.util.concurrent.Futures;
import xstr.util.concurrent.Promise;

import java.io.Serializable;
import java.util.*;

@Module.Autostart
public class SettingsPresetModule extends SessionScopeModule {
   static final Logger logger = LoggerFactory.getLogger(SettingsPresetModule.class);
   @ModuleDependency
   public UiSession uiSessionModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public XfeApplicationContext appContextModule;
   @ModuleDependency
   public LogonModule logonModule;

   private List<MenuItem> menuItems;


   public SettingsPresetModule() {
      revertMenu.setVisible(false);
   }

   public Future<Void> handleLogon() {
      if (!uiSessionModule.getUnderlyingSession().getLoggedOnUserId().startsWith(Presets.DEFAULT)) {
         try {
            long t0 = System.nanoTime();
            Future<Void> f = processPresets();
            logger.debug("presetTracker logon cost time: {}",(System.nanoTime() - t0) / 1000000);
            return f;
         } catch (Exception e) {
            logger.error("Error processing presets", e);
         }
      }
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> startModule() {
      appContextModule.addMenu(revertMenu, 800);
      logonModule.addVetoLogoffTask(this::handleVetoLogoff);
      return handleLogon().map( x -> {
         revertMenu.setVisible(true);
         menuItems = new ArrayList<>();
         for (Preset p: uiSessionModule.getUnderlyingSession().getPresets()) {
            MenuItem m = new MenuItem(p.getDescription());
            m.setOnAction(e -> new Alert(
               Alert.AlertType.CONFIRMATION,
               "All settings will be reverted to the selected preset. Do you want to continue?")
               .showAndWait()
               .ifPresent(b -> {
                  if(b == ButtonType.OK) {
                     revertToPreset(p.getId());
                  }
               }));
//            m.setOnAction(ae -> AlertBuilder.create(modalAlertModule)
//               .content("All settings will be reverted to the selected preset. Do you want to continue?")
//               .action("Ok", () -> revertToPreset(p.getId()))
//               .actionCancel()
//               .show());
            menuItems.add(m);
         }

         menuItems.sort(Comparator.comparing(MenuItem::getText));

         revertMenu.getItems().addAll(menuItems);
         return null;
      });
   }

   @Override
   public Future<Void> stopModule() {
      appContextModule.removeMenu(revertMenu);
      menuItems.clear();
      menuItems = null;
      return Future.SUCCESS;
   }

   private Future<Void> processPresets() {
      ParametersStorage parametersStorage = configurationModule.getParametersStorage();
      String presetName = parametersStorage.get(PersistantName.PRESET, String.class, (String)null).get();
      if (Strings.isNullOrEmpty(presetName)) {
         logger.info("No preset found for user. Selecting appropriate preset...");

         return showPresetChooser();
      }else{
         logger.info("Preset {} is set for user.",presetName);
      }

      wsVersion = ((DoubleProperty)PersistantName.WorkSpaceVersion.get(parametersStorage)).get();

      String currentPresetName = parametersStorage.getValue(PersistantName.PRESET, null);

      double appWsVersion = appContextModule.getWsVersion();

      String currentPresetId = currentPresetName;

      if (currentPresetName == null) {
         List<Preset> presets = new ArrayList<>(uiSessionModule.getUnderlyingSession().getPresets());
         presets.sort(Comparator.comparing(Preset::getDescription));

         if (presets.isEmpty()) {
            currentPresetName = Presets.DEFAULT;
            currentPresetId = currentPresetName;
         } else {
            currentPresetName = presets.get(0).getDescription();
            currentPresetId = presets.get(0).getId();
         }
      }

      String basePresetName = currentPresetName;
      String basePresetId = currentPresetId;

      return configurationModule.loadPresetAppConfig(basePresetId).onSuccess((Fun1Throws<Map<PersistantName, Serializable>, Void>) presetSettings -> {
         if (presetSettings.isEmpty()) {
            logger.info("preset {} not found. Nothing to compare.", basePresetName);
            new Alert(
               Alert.AlertType.ERROR,
               String.format("Unable to load preset: %s", basePresetName),
               ButtonType.OK).showAndWait();
            return null;
         }

         // The relevant current PRESET workspace has been loaded for the user
         Double presetWsVersion = presetSettings.get(PersistantName.WorkSpaceVersion) == null ?
            null :
            (Double)presetSettings.get(PersistantName.WorkSpaceVersion);

         if(isAppWorkspaceOld(appWsVersion,presetWsVersion)) {
            configurationModule.setUpdateWSVersion(false);
            new Alert(
               Alert.AlertType.WARNING,
               "The PRESET "+basePresetName+" is upgrade to "+presetWsVersion+".\nCan't load the latest preset. please upgrade XFE.",
               ButtonType.OK).showAndWait();
            return null;
         }
         Date presetTimestamp = (Date) presetSettings.get(PersistantName.TIMESTAMP_KEY);
         ObjectProperty<Date> ownPresetTimestamp = parametersStorage.get(PersistantName.PRESET_TIMESTAMP_KEY, Date.class, (Date)null);

         // Checking that PRESET update time is newer than user's workspace
         if (ownPresetTimestamp.get() == null || ownPresetTimestamp.get().compareTo(presetTimestamp) < 0) {

            // Now we need to load the user's preset
            configurationModule.loadUserPresetAppConfigData(basePresetId).onSuccess(new Fun1<Map<PersistantName, Serializable>, Void>() {

               @Override
               public Void call(Map<PersistantName, Serializable> userPresetSettings) {

                  if (userPresetSettings == null || userPresetSettings.isEmpty()) {
                     userPresetSettings = parametersStorage.getBackedMap();
                     try {
                        configurationModule.writeUserPresetToServer(basePresetId, userPresetSettings);
                     }
                     catch (Exception e) {
                        logger.error("Unable to save user's Preset");
                     }
                  }

                  Date userPresetTimestamp = (Date) userPresetSettings.get(PersistantName.TIMESTAMP_KEY);

                  if (userPresetTimestamp.compareTo(presetTimestamp) < 0) {

                     // Now we need to find the differences between user preset and updated preset
                     // and then compare those to user workspace
                     List<WatchlistSpec_v2> wlOurPreset = (List<WatchlistSpec_v2>) userPresetSettings.get(PersistantName.WatchlistTabs);
                     List<WatchlistSpec_v2> wlOurs = parametersStorage.getList(PersistantName.WatchlistTabs, WatchlistSpec_v2.class, Collections.emptyList()).get();
                     List<WatchlistSpec_v2> wlOursCopy = WatchlistSpec_v2.clone(wlOurs);
                     List<WatchlistSpec_v2> wlPreset = (List<WatchlistSpec_v2>) presetSettings.get(PersistantName.WatchlistTabs);
                     // Generating change tree for watchlists
                     SettingsChange<Object> root = new SettingsChange<Object>(null, "All", null, null, true) {
                        @Override
                        protected void applyChanges(SettingsChange changeAgent) {
                           for (SettingsChange<?> change: getChildren()) {
                              change.applyChanges(null);
                           }
                        }
                     };

                     SettingsChange watchListDiff = generateWatchlists3WayDiff(wlOurs, wlOursCopy, wlOurPreset, wlPreset, root);
                     SettingsChange settingsDiff = generateSettings3WayDiff(parametersStorage, userPresetSettings, presetSettings, root);

                     if (!watchListDiff.getChildren().isEmpty())
                        root.getChildren().add(watchListDiff);

                     if (!settingsDiff.getChildren().isEmpty())
                        root.getChildren().add(settingsDiff);

                     // Checking that PRESET has any changes compared to user's workspace
                     if (!root.getChildren().isEmpty()) {
                        final PresetNotificationView view = new PresetNotificationView(root);
                        view.captionProperty().set("Preset has changed");
                        view.widthProperty().set(560);
                        view.heightProperty().set(520);
                        final Dialog<ButtonType> dlg = new Dialog<>();
                        dlg.getDialogPane().setContent(view.getRootElement());
                        final ButtonType remindMeLater = new ButtonType("Remind me later", ButtonBar.ButtonData.CANCEL_CLOSE);
                        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, remindMeLater);
                        dlg.setResultConverter(dialogButton -> {
                           if (dialogButton == ButtonType.OK) {
                              configurationModule.writeUserPresetToServer(basePresetId, presetSettings);
                              root.doApplyChanges();
                              applySpecChanges(wlOurs, wlOursCopy);
                              ownPresetTimestamp.set(presetTimestamp);
                           }
                           return null;
                        });
                        dlg.showAndWait();
                     } else {
                        ownPresetTimestamp.set(presetTimestamp);
                     }
                  }
                  return null;
               }
            });
         }
         return null;
      }).onError(e -> {
         String message = String.format("Unable to load preset: %s", basePresetName);
         logger.error("Unable to load preset {}: {}", e.getMessage());
         new Alert(
            Alert.AlertType.ERROR,
            message,
            ButtonType.OK).showAndWait();
         return Future.SUCCESS;
      });
   }

   private Future<Void> revertToPreset(String presetId) {
      return configurationModule.loadPresetAppConfig(presetId).flatMap(val -> {
         Double presetVer = (Double)val.get(PersistantName.WorkSpaceVersion);
         Promise<Void> rtn = Futures.newPromise("revertPreset");
         if(isAppWorkspaceOld(presetVer,wsVersion)){
            new Alert(
               Alert.AlertType.WARNING,
               "The version of "+presetId+" is "+presetVer+", which is newer than the version of the workspace.\nCan't revert to the preset.")
               .showAndWait()
               .ifPresent(b -> {
                  rtn.setSuccess(null);
               });
            return rtn;
         }else{
            // Saving the new preset into user's preset
            return configurationModule.writeUserPresetToServer(presetId, val).map(aVoid -> {
               ParametersStorage parametersStorage = configurationModule.getParametersStorage();
               Date presetTimestamp = (Date) val.get(PersistantName.TIMESTAMP_KEY);
               parametersStorage.updateAll(val);
               parametersStorage.get(PersistantName.PRESET_TIMESTAMP_KEY, Date.class, (Date) null).set(presetTimestamp);
               parametersStorage.get(PersistantName.PRESET, String.class,(String)null).set(presetId);
               return null;
            });
         }
      });
   }

//   public Future<Void> writeUserPresetToServer(String presetId, Map<PersistantName, Serializable> val) {
//      Disposer disposer = new Disposer();
//      val.put(PersistantName.PRESET,presetId);
//      // Saving the header
//      ByteArrayOutputStream os = disposer.disposes(new ByteArrayOutputStream());
//      writeAppConfigToStream(os, val);
//      XtrBlob data = XtrBlob.valueOf(os);
//      disposer.dispose();
//      return activeSessionModule.getSession().map(primarySession -> primarySession.saveUserPreset(data, presetId))
//         .orElse(Future.SUCCESS);
//   }

   private static boolean isAppWorkspaceOld(Double appWsVersion, Double presetWsVersion) {
      if (presetWsVersion == null || presetWsVersion == -1) return false;
      //user work space does not have version, while preset work space have version
      return appWsVersion == null || appWsVersion == -1 || appWsVersion < presetWsVersion;
   }

   private Future<Boolean> handleVetoLogoff() {
      ParametersStorage origStorage = configurationModule.getOrigStorage();
      ParametersStorage storage = configurationModule.getParametersStorage();
      Set<PersistantName> relevantWsItems = new HashSet<>(PersistantName.workspaceItems);
      relevantWsItems.removeAll(PersistantName.wsIgnoredItems());
      StringProperty origPresetWS = origStorage.get(PersistantName.PRESET, null);
      String origPresetName = (origPresetWS == null) ? null : origPresetWS.get();
      String currentPresetName = storage.getValue(PersistantName.PRESET, null);

      if (!Objects.equals(origPresetName, currentPresetName) ||
         !ParametersStorage.equals(origStorage, storage, PersistantName.workspaceItems) ||
         !ParametersStorage.equals(origStorage, storage, PersistantName.settingsItems)) {
         BooleanProperty autosave = storage.get(PersistantName.AutoSaveWorkspace, false);
         if (autosave.get()) {
            return Future.valueOf(false);
         } else {
            Promise<Boolean> promise = Futures.newPromise("SaveOnExit");

            if (ParametersStorage.equals(origStorage, storage, relevantWsItems) &&
               ParametersStorage.equals(origStorage, storage, PersistantName.settingsItems)) {
               // No changes - Nothing to save
               configurationModule.setSaveOnExit(false);
               return Future.valueOf(false);
            }


            Alert alert = new Alert(
               Alert.AlertType.CONFIRMATION,
               "If you don't save, your changes will be lost",
               ButtonType.YES, ButtonType.NO, ButtonType.CANCEL
            );

            alert.setHeaderText("Do you want to save the changes to the workspace?");
            // TODO: Verify promise is set even for abnormal exit.
            alert.showAndWait()
               .ifPresent(b -> {
                  if (b == ButtonType.YES) {
                     configurationModule.setSaveOnExit(true);
                     promise.setSuccess(false);
                  } else if (b == ButtonType.NO) {
                     configurationModule.setSaveOnExit(false);
                     promise.setSuccess(false);
                  } else {
                     configurationModule.setSaveOnExit(true);
                     promise.setSuccess(true);
                  }

               });

            return promise;
         }
      } else {
         // No changes - Nothing to save
         configurationModule.setSaveOnExit(false);
         return Future.valueOf(false);
      }
   }

   private void applySpecChanges(List<WatchlistSpec_v2> origSpecs,
                                 List<WatchlistSpec_v2> newSpecs) {
      List<WatchlistSpec_v2> remainingSpecs = new LinkedList<>(newSpecs);
      List<WatchlistSpec_v2> removedSpecs = new LinkedList<>(origSpecs);

      for (WatchlistSpec_v2 currNewSpec: newSpecs) {
         ListIterator<WatchlistSpec_v2> origSpecItr = origSpecs.listIterator();
         while (origSpecItr.hasNext()) {
            WatchlistSpec_v2 currOrigSpec = origSpecItr.next();
            if (Objects.equals(currNewSpec.getId(), currOrigSpec.getId())) {
               remainingSpecs.remove(currNewSpec);
               removedSpecs.remove(currOrigSpec);
               if (!Objects.equals(currNewSpec, currOrigSpec))
                  origSpecItr.set(currNewSpec);
            }
         }
      }

      // Adding/Removing specs
      origSpecs.removeAll(removedSpecs);
      origSpecs.addAll(remainingSpecs);
   }

   private SettingsChange generateSettings3WayDiff(
      ParametersStorage parameterStorage,
      Map<PersistantName, Serializable> userPresetSettings,
      Map<PersistantName, Serializable> presetSettings,
      SettingsChange root) {

      SettingsChange<Object> inRoot = new SettingsChange<Object>(root, "Settings", null, null, true) {

         @Override
         protected void applyChanges(SettingsChange changeAgent) {
            for (SettingsChange<?> change: getChildren()) {
               change.applyChanges(null);
            }
         }
      };

      Set<PersistantName> relevantItems = PersistantName.getItems();
      relevantItems.removeAll(PersistantName.wsIgnoredItems());
      relevantItems.remove(PersistantName.TIMESTAMP_KEY);
      relevantItems.remove(PersistantName.PRESET);
      relevantItems.remove(PersistantName.PRESET_TIMESTAMP_KEY);
      relevantItems.remove(PersistantName.WatchlistTabs);

      Map<PersistantName, Serializable> ours = parameterStorage.getBackedMap();

      for (PersistantName name : relevantItems) {
         Serializable presetV = presetSettings.get(name);
         Serializable userPresetV = userPresetSettings.get(name);
         Serializable ourV = ours.get(name);

         if (presetV == null && ourV == null) continue;

         if (ourV == null) {
            name.get(parameterStorage);
            ourV = ours.get(name);
         }

         if (userPresetV == null)
            userPresetV = ourV;

         if (presetV == null) {
            logger.debug("Setting <{}> is new", name);
            continue;
         }

         if (Objects.equals(ourV, presetV) || Objects.equals(userPresetV, presetV)) continue;

         inRoot.getChildren().add(new SettingsChange<Serializable>(inRoot,
            name.toString(),
            ourV,
            presetV,
            true) {
            @Override
            protected void applyChanges(SettingsChange changeAgent) {
               parameterStorage.updateVal(PersistantName.valueOf(getDescription()),
                  getTheirValue());
            }
         });
      }

      return inRoot;
   }

   private SettingsChange generateWatchlists3WayDiff(
      List<WatchlistSpec_v2> wlOurs,
      List<WatchlistSpec_v2> wlOursCopy,
      List<WatchlistSpec_v2> wlOurPreset,
      List<WatchlistSpec_v2> wlPreset,
      SettingsChange root) {

      SettingsChange<Object> inRoot = new SettingsChange<Object>(root, "Watchlists", null, null, true) {

         @Override
         protected void applyChanges(SettingsChange changeAgent) {
            for (SettingsChange<?> change: getChildren()) {
               change.applyChanges(null);
            }
         }
      };

      Map<UUID, WatchlistSpec_v2> uuidToSpecMapNewPreset = new HashMap<>();

      // Building a map from uuid to the spec it designates, from the new preset
      // (we do not need to retain order there)
      for (WatchlistSpec_v2 spec: wlPreset) {
         uuidToSpecMapNewPreset.put(spec.getId(), spec);
      }

      Map<UUID, WatchlistSpec_v2> uuidToSpecMapOurPreset = new HashMap<>();

      // Building a map from uuid to the spec it designates, from our preset
      // (we do not need to retain order there)
      if (wlOurPreset != null) {
         for (WatchlistSpec_v2 spec: wlOurPreset) {
            uuidToSpecMapOurPreset.put(spec.getId(), spec);
         }
      }

      // Checking per each of our specs if it is still there
      // If it is not, we need to create a Remove Change for it
      // If it is, then we need to see if there are any contents differences
      // and if so, create the relevant Change subtree.
      for (WatchlistSpec_v2 spec : wlOurs) {
         WatchlistSpec_v2 newPresetSpec = uuidToSpecMapNewPreset.remove(spec.getId());
         WatchlistSpec_v2 ourPresetSpec = uuidToSpecMapOurPreset.remove(spec.getId());
         if (newPresetSpec == null && ourPresetSpec != null) {
            // We now know that the spec exists in our and our preset workspace, but not in the new PRESET workspace
            // (If this spec does not exist in the PRESET workspace we used last time
            // then it means we customized it, so no need to create a Change object for it)

            // The spec was removed
            inRoot.getChildren().add(new SettingsChange<String>(inRoot,
               spec.getTitle() + "|" + spec.getSubtitle(),
               "",
               "Missing",
               true) {

               @Override
               protected void applyChanges(SettingsChange changeAgent) {
                  // Removing this spec
                  wlOursCopy.remove(spec);
               }
            });
         } else if (newPresetSpec != null && !newPresetSpec.equals(spec) && !newPresetSpec.equals(ourPresetSpec)) {

            // If here we need to drill down into the specs and create
            // the relevant Change subtree.

            // We only care about changes between the user's spec and the new PRESET that are
            // also changes between the user's PRESET and the new PRESET

            // Adding subtree's root
            SettingsChange<UUID> change = new SettingsChange<UUID>(inRoot,
               spec.getTitle() + "|" + spec.getSubtitle(),
               spec.id,
               newPresetSpec.id,
               true) {

               private void accept(SettingsChange<?> change) {
                  change.applyChanges(this);
               }

               @Override
               protected void applyChanges(SettingsChange changeAgent) {
                  getChildren().forEach(this::accept);
               }
            };

            boolean titleChange = false, subtitleChange = false;
            if (!spec.title.equals(newPresetSpec.title)) {
               if (ourPresetSpec == null || !newPresetSpec.title.equals(ourPresetSpec.title)) {
                  titleChange = true;
               }
            }
            if (!spec.subtitle.equals(newPresetSpec.subtitle)) {
               if (ourPresetSpec == null || !newPresetSpec.subtitle.equals(ourPresetSpec.subtitle)) {
                  subtitleChange = true;
               }
            }

            if (titleChange || subtitleChange) {
               change.getChildren().add(new SettingsChange<String>(change,
                  "Name",
                  spec.title + "|" + spec.subtitle,
                  newPresetSpec.title + "|" + newPresetSpec.subtitle,
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     updateCurrentSpec(wlOursCopy, (UUID) changeAgent.getMyValue(), new Fun1<WatchlistSpec_v2, WatchlistSpec_v2>() {

                        @Override
                        public WatchlistSpec_v2 call(WatchlistSpec_v2 prevSpec) {
                           return prevSpec.withName(getTheirValue());
                        }
                     });
                  }
               });
            }

            if (spec.visible != newPresetSpec.visible &&
               (ourPresetSpec == null || newPresetSpec.visible != ourPresetSpec.visible)) {
               change.getChildren().add(new SettingsChange<Boolean>(change,
                  "Visibility",
                  spec.visible,
                  newPresetSpec.visible,
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     updateCurrentSpec(wlOursCopy, (UUID) changeAgent.getMyValue(), new Fun1<WatchlistSpec_v2, WatchlistSpec_v2>() {

                        @Override
                        public WatchlistSpec_v2 call(WatchlistSpec_v2 prevSpec) {
                           return prevSpec.withVisible(getTheirValue());
                        }
                     });
                  }
               });
            }

            if (spec.filterVisible != newPresetSpec.filterVisible &&
               (ourPresetSpec == null || newPresetSpec.filterVisible != ourPresetSpec.filterVisible)) {
               change.getChildren().add(new SettingsChange<Boolean>(change,
                  "Filter Visibility",
                  spec.filterVisible,
                  newPresetSpec.filterVisible,
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     updateCurrentSpec(wlOursCopy, (UUID) changeAgent.getMyValue(), new Fun1<WatchlistSpec_v2, WatchlistSpec_v2>() {

                        @Override
                        public WatchlistSpec_v2 call(WatchlistSpec_v2 prevSpec) {
                           return prevSpec.withFilterVisible(getTheirValue());
                        }
                     });
                  }
               });
            }

            if (spec.instrFilter != newPresetSpec.instrFilter &&
               (ourPresetSpec == null || newPresetSpec.instrFilter != ourPresetSpec.instrFilter)) {
               change.getChildren().add(new SettingsChange<InstrumentsFilter>(change,
                  "Instruments Filter",
                  spec.instrFilter,
                  newPresetSpec.instrFilter,
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     updateCurrentSpec(wlOursCopy, (UUID) changeAgent.getMyValue(), new Fun1<WatchlistSpec_v2, WatchlistSpec_v2>() {

                        @Override
                        public WatchlistSpec_v2 call(WatchlistSpec_v2 prevSpec) {
                           return prevSpec.withInstrFilter(getTheirValue());
                        }
                     });
                  }
               });
            }

            if (spec.priceTight != newPresetSpec.priceTight &&
               (ourPresetSpec == null || newPresetSpec.priceTight != ourPresetSpec.priceTight)) {
               change.getChildren().add(new SettingsChange<Boolean>(change,
                  "Price Tightness",
                  spec.priceTight,
                  newPresetSpec.priceTight,
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     updateCurrentSpec(wlOursCopy, (UUID) changeAgent.getMyValue(), new Fun1<WatchlistSpec_v2, WatchlistSpec_v2>() {

                        @Override
                        public WatchlistSpec_v2 call(WatchlistSpec_v2 prevSpec) {
                           return prevSpec.withPriceTight(getTheirValue());
                        }
                     });
                  }
               });
            }

            // Comparing securities
            Set<Security> ourSet = new LinkedHashSet(Arrays.asList(spec.securities));
            Set<Security> newPresetSet = new LinkedHashSet(Arrays.asList(newPresetSpec.securities));
            Set<Security> ourPresetSet = new LinkedHashSet(ourPresetSpec == null ?
               new ArrayList<Security>() :
               Arrays.asList(ourPresetSpec.securities));

            if (!ourSet.equals(newPresetSet) && (ourPresetSpec == null || !newPresetSet.equals(ourPresetSet))) {
               SettingsChange<Object> secsChange = new SettingsChange<Object>(change,
                  "Securities",
                  null,
                  null,
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     getChildren().forEach(change -> change.applyChanges(changeAgent));
                  }
               };

               Set<Security> oursNewPresetCommonSet = new LinkedHashSet(newPresetSet);
               oursNewPresetCommonSet.retainAll(ourSet);

               // Elements in our set only
               ourSet.removeAll(oursNewPresetCommonSet);
               // We need to check they also exist in user's preset
               // (otherwise it means we added them to our workspace)
               // Removing this security
               ourSet.stream().filter(ourSec -> ourPresetSpec == null ||
                  ourPresetSet.contains(ourSec)).forEach(ourSec
                  -> secsChange.getChildren().add(new SettingsChange<String>(secsChange,
                  ourSec.getSecCode(),
                  "",
                  "Missing",
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     // Removing this security
                     updateCurrentSpec(wlOursCopy, (UUID) changeAgent.getMyValue(), new Fun1<WatchlistSpec_v2, WatchlistSpec_v2>() {

                        @Override
                        public WatchlistSpec_v2 call(WatchlistSpec_v2 prevSpec) {
                           List<Security> newList = new LinkedList<>(Arrays.asList(prevSpec.securities));
                           newList.remove(new Security(null, getDescription()));
                           return prevSpec.withSecurities(newList);
                        }
                     });
                  }
               }));

               // Elements in their set only
               newPresetSet.removeAll(oursNewPresetCommonSet);
               // We need to check they do not exist in user's preset
               // (otherwise it means we removed them from our workspace)
               // Adding this security
               newPresetSet.stream().filter(theirSec -> !ourPresetSet.contains(theirSec)).forEach(theirSec
                  -> secsChange.getChildren().add(new SettingsChange<String>(secsChange,
                  theirSec.getSecCode(),
                  "Missing",
                  "",
                  false) {

                  @Override
                  protected void applyChanges(SettingsChange changeAgent) {
                     // Adding this security
                     updateCurrentSpec(wlOursCopy, (UUID) changeAgent.getMyValue(), new Fun1<WatchlistSpec_v2, WatchlistSpec_v2>() {

                        @Override
                        public WatchlistSpec_v2 call(WatchlistSpec_v2 prevSpec) {
                           List<Security> newList = new LinkedList<>(Arrays.asList(prevSpec.securities));
                           newList.add(new Security(null, getDescription()));
                           return prevSpec.withSecurities(newList);
                        }
                     });
                  }
               }));

               if (!secsChange.getChildren().isEmpty())
                  change.getChildren().add(secsChange);
            }

            if (!change.getChildren().isEmpty())
               inRoot.getChildren().add(change);
         }
      }

      // Now we need to create Add Changes for all new tabs
      // If these exist in user's preset then they are not really newly added tabs
      uuidToSpecMapNewPreset.values().stream().filter(spec -> !uuidToSpecMapOurPreset.containsKey(spec.getId())).forEach(spec
         -> inRoot.getChildren().add(new SettingsChange<String>(inRoot,
         spec.getTitle() + "|" + spec.getSubtitle(),
         "Missing",
         "",
         false) {

         @Override
         protected void applyChanges(SettingsChange changeAgent) {
            wlOursCopy.add(spec);
         }
      }));

      return inRoot;
   }

   private void updateCurrentSpec(List<WatchlistSpec_v2> ours,
                                  UUID mine,
                                  Fun1<WatchlistSpec_v2, WatchlistSpec_v2> replacement) {
      ArrayList<WatchlistSpec_v2> a = new ArrayList<>();
      for (WatchlistSpec_v2 v : ours) {
         if (v.id.equals(mine))
            a.add(replacement.call(v));
         else
            a.add(v);
      }
      ours.clear();
      ours.addAll(a);
   }

   private Future<Void> showPresetChooser() {

      Promise<Void> promise = Futures.newPromise("PresetChooser");

      ListView<Preset> presetList = new ListView<>();
      List<Preset> presets = new ArrayList<>(uiSessionModule.getUnderlyingSession().getPresets());
      presets.sort(Comparator.comparing(Preset::getDescription));
      presetList.getItems().setAll(presets);

      Alert alert = new Alert(
         Alert.AlertType.INFORMATION,
         null,
         ButtonType.OK
      );
      alert.setHeaderText("Please choose a preset");

      alert.getDialogPane().setExpandableContent(presetList);
      alert.getDialogPane().setExpanded(true);
      Fx.runLater(() -> presetList.getSelectionModel().clearAndSelect(0));
      alert.showAndWait()
         .ifPresent(b -> {
            if (presetList.getSelectionModel().getSelectedItem() != null)
               promise.setFuture(revertToPreset(presetList.getSelectionModel().getSelectedItem().getId()));
            else {
               promise.setFailure(new RuntimeException("there is no preset selected"));
               promise.setSuccess(null);
            }
         });

      return promise;
   }

   private final Menu revertMenu = new Menu("Default W/space");
   private Double wsVersion;
}
