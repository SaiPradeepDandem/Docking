package xfe.icap.modules.iswaptrades;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import javafx.beans.property.*;
import javafx.collections.*;
import javafx.geometry.Rectangle2D;
import javafx.scene.*;
import javafx.stage.*;

import org.slf4j.*;

import xfe.icap.XfeSession;
import xfe.types.StepArray;
import xstr.session.XtrKey;
import xstr.util.Fx;
import xfe.layout.LayoutManager;
import xfe.ui.notifications.ModalAlertModule;

class TradeWorkupStageFactory {
   private static final Logger logger = LoggerFactory.getLogger(TradeWorkupStageFactory.class);

   private static final long keepOpenAfterPassiveClose = 1L; //The spec says "immediately" close the dialog

   private static final List<TradeAlert> tradesList = new LinkedList<>(); // using linked list instead of arraylist, since there are lots of remove/add operations
   private static final ListChangeListener<TradeAlert> listener =  new ListChangeListener<TradeAlert>() {

      @Override
      public void onChanged(Change<? extends TradeAlert> change) {
         while (change.next()) {
            if (change.wasAdded()) {
               int size = change.getAddedSize();
               for (int i = 0; i < size; i++) {
                  TradeAlert trade = change.getAddedSubList().get(i);
                  if (popupTradeWorkup.get()) {
                     showTradeWorkup(trade,xfeSession.getUnderlyingSession().getStats().getEngineTime());
                  }
               }
            }
            if (change.wasRemoved()) {
               int size = change.getRemovedSize();
               for (int i = 0; i < size; i++) {
                  TradeAlert trade = change.getRemoved().get(i);
                  logger.debug("trade is removed from workingupTrades(listener invoked).{} ", trade);
                  TradeWorkupStage stage = stages.get(trade);
                  if (stage != null) {
                     stages.remove(trade);
                     Fx.runLater(stage::close);
                  }
                  logger.debug("trade is removed from workingupTrades and stage {} is closed.",
                     stage != null ? stage.getTitle() : "\"stage not opened\"");
               }
            }
         }
      }
   };


   private static final ObservableList<TradeAlert> workupTrades = FXCollections.observableList(tradesList);
   // TODO thinking about concurrent weak ref map
   /*
    * keeps all the trades which has a stage opened. There are two cases: if "show trade workup" is turned on or double clicked on "workup" cell, an corresponding stage will be open for the trade.
    */
   private static final ConcurrentHashMap<TradeAlert, TradeWorkupStage> stages = new ConcurrentHashMap<>(32);


   private static LayoutManager<Node> layoutManager;
   private static BooleanProperty popupTradeWorkup;
   // TODO: FIX THIS SOON!!!! Get rid of static here!!!
   static XfeSession xfeSession;
   static ReadOnlyObjectProperty<StepArray> spinQtySteps;
   static ModalAlertModule notifier;

   private static Thread cleanThread;
   private static boolean keepRunning = true;

   private static double x;
   private static double y;
   private static double screenWidth;
   private static double screenHeight;
   private static TradeWorkupStage createStage(TradeAlert trade, Date engineTime) {
      TradeWorkupStage popupStage = new TradeWorkupStage(trade,workupTrades, engineTime);
      layoutManager.register(popupStage,popupStage.getAppContainer());
//the spec does not say so , leave it
//      popupStage.setX(x);
//      popupStage.setY(y);
      popupStage.show();
      x+=popupStage.getWidth();
      if(x+popupStage.getWidth()>screenWidth){
         x=0;
         y+=popupStage.getHeight();
         if(y+popupStage.getHeight()>screenHeight){
            x=0;
            y=0;
         }
      }

      return popupStage;
   }


   public static void init(LayoutManager<Node> layoutManager,
                           BooleanProperty showTradeWorkup,
                           XfeSession session,
                           ReadOnlyObjectProperty<StepArray> readOnlySpinQtySteps,
                           ModalAlertModule notifier) {
//      calScreenSpace(jfxContextModule);
      TradeWorkupStageFactory.layoutManager = layoutManager;
      x = 0;
      y = 0;
      Rectangle2D rec = Screen.getPrimary().getVisualBounds();
      screenWidth = rec.getWidth();
      screenHeight = rec.getHeight();
      xfeSession = session;
      popupTradeWorkup = showTradeWorkup;
      workupTrades.addListener(listener);
      spinQtySteps = readOnlySpinQtySteps;
      TradeWorkupStageFactory.notifier = notifier;
      keepRunning = true;
      // the task periodically check the above two hashmap. removing the expired trades for workup
   }

//   private static void calScreenSpace(FxContext jfxContextModule) {
////      Stage mainStage = jfxContextModule.getStage();
////      mainStage.
//
//   }

   private static void showTradeWorkup(TradeAlert trade, Date engineTime) {
      try {
         TradeWorkupStage stage = createStage(trade,engineTime);
         stages.put(trade, stage);
         trade.alertStatusProperty().addListener((paramObservableValue, oldValue, newValue) -> {
            if (TradeAlert.STATUS_DONE.equals(newValue)) {
               stage.disableInputAndShowFinalSize();
               Fx.delay(keepOpenAfterPassiveClose, () -> {
                  logger.debug("trade is removed (status listener) from the workupTrades.{}", trade);
                  workupTrades.remove(trade);
               });

            }
         });
      } catch (Exception e) {
         logger.warn("Creating workup dialog error", e);
      }

   }

   static void showTradeWorkup(XtrKey key) {
      boolean isFound = false;
      TradeWorkupStage stage = null;
      Enumeration<TradeAlert> keys = stages.keys();
      while (keys.hasMoreElements()) {
         TradeAlert aTrade = keys.nextElement();
         if (key.equals(aTrade.key)) {
            stage = stages.get(aTrade);
            isFound = true;
            break;
         }
      }
      if (stage != null) {
         stage.show();
         stage.requestFocus();
         stage.toFront();
      }else{
         for(TradeAlert aTrade: workupTrades){
            if(key.equals(aTrade.key)){
               if (TradeAlert.STATUS_WORKUP.equals(aTrade.alertStatus.get())){
                  showTradeWorkup(aTrade,xfeSession.getUnderlyingSession().getStats().getEngineTime());
                  isFound = true;
               }else{
                  logger.info("The trade's status is not workup. "+aTrade);
               }
            }
         }
      }
      if(!isFound ){
         logger.info("can't find the key in opened stage list and workuptrades list. key is {}"+key);
      }
   }


   /**
    *
    * @param isNewTrade
    *           . is this trade a "create" or a " update"
    * @param trade
    *           the tradealert
    *
    *           for normal trade(non rfq), only the the "create" trade alert can be "Workup" but for rfq trade, the first trade alert is "rfqpending" then comes "Workup" trade alerts.
    */
   public static void add(boolean isNewTrade, TradeAlert trade) {
      int index = workupTrades.indexOf(trade);

      if (index >= 0) {
         TradeAlert existTrade = workupTrades.get(index);
         existTrade.alertStatusProperty().set(trade.getAlertStatus());
         existTrade.sellWorkupAmountProperty.set(trade.sellWorkupAmountProperty.get());
         existTrade.buyWorkupAmountProperty.set(trade.buyWorkupAmountProperty.get());
         existTrade.setAmount(trade.amount.get());
      } else if (trade.isWorkup()) // create dialog for the workup trade
         workupTrades.add(trade);
      else if(trade.isDone()){
         logger.debug("trade is removed from workingupTrades(trade is done).{} ",trade);
         workupTrades.remove(trade);
      }
   }

   private static void closeAll() {
      for(TradeAlert trade: workupTrades){
         TradeWorkupStage stage = stages.get(trade);
         if (stage != null) {
            stages.remove(trade);
            stage.close();
         }
      }
   }


//   protected void showStatusAndDisableInput(final TradeAlert trade) {
////      mainPane.updateStatusMessage("Workup Completed. The final trade size is "+trade.amount);
//   }
   static void uninitialize() {
      spinQtySteps = null;
      notifier = null;
      xfeSession = null;
      layoutManager = null;
      keepRunning = false;
      if(cleanThread!=null){
         cleanThread.interrupt();
         cleanThread = null;
      }
      closeAll();
      workupTrades.removeListener(listener);
   }

   static void workupStageClosed(TradeAlert trade){
      workupTrades.remove(trade);
      logger.debug("trade is removed (stage closed) {}", trade);
   }
}
