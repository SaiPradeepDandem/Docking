package xfe.icap.client;

import xstr.icap.csdk.ICAPSession;
import xstr.session.SessionWrapper;
import xstr.session.XstrClientConfig;
import xstr.session.XstrConnectType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.XstrIni.Key;
import xstr.icap.amp.ICAPAmpSiteConfig;
import xstr.util.exception.XtrSessionException;

public class IcapWebSiteConfig extends ICAPAmpSiteConfig {
   private static final Logger logger = LoggerFactory.getLogger(IcapWebSiteConfig.class);

   @Override
   public SessionWrapper createSession(XstrClientConfig config) throws XtrSessionException {
      XstrConnectType connectType = XstrConnectType.nameOf(config.get(Key.CONN_TYPE));
      switch (connectType) {
//      case AUTO:
//         throw new XtrSessionException("Auto connection type not implemented yet.");
      case HTTP:
         logger.info("Creating HTTP session to {}", config.get(Key.WEB_URL));
         return new HttpSessionWrapper(config);
      case TSMR:
         logger.info("Creating TSMR session to {} [{}]", config.get(Key.TSMR_POSSIBLE_HOSTS), config.get(Key.TSMR_TCP_PORT));
         return new ICAPSession(config);
      case WS:
         logger.info("Creating Websocket session to {}", config.get(Key.WEB_URL));
         return new WsSessionWrapper(config);
      default:
         throw new XtrSessionException("Invalid Connection Type: " + connectType);
      }
   }
}
