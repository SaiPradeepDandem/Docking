package xfe.icap.modules.tradesui;

import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.ui.table.XfeTableView;
import xstr.util.Util;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

public class TradesOrDealsAggregatePane {
   private static final Logger logger = LoggerFactory.getLogger(TradesOrDealsAggregatePane.class);

   private Comparator<TradesOrDealsAggregateData> comparator = Comparator.comparing(TradesOrDealsAggregateData::getPrice).reversed();

   @FXML
   void initialize() {
      root.setUserData(this);
      tradesAggregateTable.limitTableViewHeight(10, 10);
      netQtyCell.prefWidthProperty().bind(pricePointColumn.widthProperty());
      myQtyCell.prefWidthProperty().bind(myQtyColumn.widthProperty());
      myFirmCell.prefWidthProperty().bind(myFirmColumn.widthProperty());
      marketQtyCell.prefWidthProperty().bind(marketQtyColumn.widthProperty());

      pricePointColumn.setCellValueFactory(cd -> new SimpleObjectProperty<>(cd.getValue().getPrice()));
      myQtyColumn.setCellValueFactory(cd -> new SimpleObjectProperty<>(cd.getValue().getMyQty()));
      myFirmColumn.setCellValueFactory(cd -> new SimpleObjectProperty<>(cd.getValue().getMyFirmQty()));
      marketQtyColumn.setCellValueFactory(cd -> new SimpleObjectProperty<>(cd.getValue().getMarketQty()));

      final Callback<TableColumn<TradesOrDealsAggregateData, BigDecimal>, TableCell<TradesOrDealsAggregateData, BigDecimal>> quantityCellFactory = new Callback<TableColumn<TradesOrDealsAggregateData, BigDecimal>, TableCell<TradesOrDealsAggregateData, BigDecimal>>() {
         @Override
         public TableCell<TradesOrDealsAggregateData, BigDecimal> call(TableColumn<TradesOrDealsAggregateData, BigDecimal> param) {
            return new TableCell<TradesOrDealsAggregateData, BigDecimal>() {
               @Override
               protected void updateItem(BigDecimal item, boolean empty) {
                  super.updateItem(item, empty);
                  if (item != null && !empty) {
                     setText(Util.getDefaultQuanitityFormatter().format(item));
                  } else {
                     setText(null);
                  }
               }
            };
         }
      };
      myQtyColumn.setCellFactory(quantityCellFactory);
      myFirmColumn.setCellFactory(quantityCellFactory);
      marketQtyColumn.setCellFactory(quantityCellFactory);

      pricePointColumn.setCellFactory(new Callback<TableColumn<TradesOrDealsAggregateData, BigDecimal>, TableCell<TradesOrDealsAggregateData, BigDecimal>>() {
         @Override
         public TableCell<TradesOrDealsAggregateData, BigDecimal> call(TableColumn<TradesOrDealsAggregateData, BigDecimal> param) {
            return new TableCell<TradesOrDealsAggregateData, BigDecimal>() {
               @Override
               protected void updateItem(BigDecimal item, boolean empty) {
                  super.updateItem(item, empty);
                  if (item != null && !empty) {
                     if (priceFormatter != null) {
                        try {
                           setText(priceFormatter.apply(item));
                        } catch (Exception e) {
                           logger.error("Exception while formatting price in Trades Aggregate !!!");
                        }
                     } else {
                        setText(Util.getDefaultFormatter().apply(item));
                     }
                  } else {
                     setText(null);
                  }
               }
            };
         }
      });
   }

   public BorderPane getRoot() {
      return root;
   }

   public void updateData(List<TradesOrDealsAggregateData> data) {
      tradesAggregateTable.getItems().clear();
      Collections.sort(data, comparator);
      tradesAggregateTable.getItems().addAll(data);
      DecimalFormat formatter = Util.getDefaultQuanitityFormatter();
      BigDecimal myQtyTotal = BigDecimal.ZERO;
      BigDecimal myFirmTotal = BigDecimal.ZERO;
      BigDecimal marketQtyTotal = BigDecimal.ZERO;
      for (TradesOrDealsAggregateData tradesOrDealsAggregateData : tradesAggregateTable.getItems()) {
         myQtyTotal = myQtyTotal.add(tradesOrDealsAggregateData.getMyQty());
         myFirmTotal = myFirmTotal.add(tradesOrDealsAggregateData.getMyFirmQty());
         if(!isForDeals) {
            marketQtyTotal = marketQtyTotal.add(tradesOrDealsAggregateData.getMarketQty());
         }
      }
      myQtyLbl.setText(formatter.format(myQtyTotal));
      myFirmLbl.setText(formatter.format(myFirmTotal));
      if(!isForDeals) {
         marketQtyLbl.setText(formatter.format(marketQtyTotal));
      }
   }

   public void setPriceFormatter(Function<Number, String> priceFormatter) {
      this.priceFormatter = priceFormatter;
   }

   public void setIsForDeals(boolean forDeals) {
      this.isForDeals = forDeals;
      if(this.isForDeals){
         tradesAggregateTable.setPrefWidth(311);
         marketQtyColumn.setVisible(false);
         marketQtyCell.setVisible(false);
         marketQtyCell.setManaged(false);
      }
   }

   @FXML
   private BorderPane root;

   @FXML
   private XfeTableView<TradesOrDealsAggregateData> tradesAggregateTable;
   @FXML
   private TableColumn<TradesOrDealsAggregateData, BigDecimal> pricePointColumn;
   @FXML
   private TableColumn<TradesOrDealsAggregateData, BigDecimal> myQtyColumn;
   @FXML
   private TableColumn<TradesOrDealsAggregateData, BigDecimal> myFirmColumn;
   @FXML
   private TableColumn<TradesOrDealsAggregateData, BigDecimal> marketQtyColumn;

   @FXML
   private StackPane netQtyCell;
   @FXML
   private StackPane myQtyCell;
   @FXML
   private StackPane myFirmCell;
   @FXML
   private StackPane marketQtyCell;

   @FXML
   private Label myQtyLbl;
   @FXML
   private Label myFirmLbl;
   @FXML
   private Label marketQtyLbl;

   private Function<Number, String> priceFormatter;

   private boolean isForDeals = false;
}
