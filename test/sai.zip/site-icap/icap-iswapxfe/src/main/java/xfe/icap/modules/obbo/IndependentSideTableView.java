package xfe.icap.modules.obbo;

import xfe.util.XfePickupAction;
import xfe.util.scene.control.AsnTableRow;
import xfe.util.XfeAction;
import javafx.beans.InvalidationListener;
import javafx.beans.property.*;
import javafx.collections.ObservableList;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xstr.amp.AsnPrintFormatter;

import xfe.util.scene.control.SelectionTracker;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.icap.amp.AmpOrderBookByOrder;
import xstr.session.ObservableReplyRow;
import xfe.util.Constants;
import com.objsys.asn1j.runtime.Asn1Type;

abstract class IndependentSideTableView extends TableViewHeaderUnmovable<ObservableReplyRow> {
	private static final Logger logger = LoggerFactory.getLogger(IndependentSideTableView.class);

	/*TODO Actually SelectionTracker<ObservableReplyRow, Object> is better.  The SelectionTracker is using equals method to track the selection.
	 * but The com.omxgroup.xstream.amp.AmpOrderId does not overwrite the equals method.*/
	private final SelectionTracker<ObservableReplyRow> selectionTracker;
   private final Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>> obboRowFactory;

	private final ObjectProperty<Double> trackedRowPriceUpdate = new SimpleObjectProperty<>();

   private final Callback<ObservableReplyRow, Boolean> isPickedUpInstrument;
   private final Callback<ObservableReplyRow,Boolean> isRfsHasNoLLTime;

   IndependentSideTableView(boolean isBid, boolean is4PopupStage, ObjectProperty<XfePickupAction> pickedupActionProp, ObboModule obboModule) {
		getStyleClass().add("xfe-table");
		this.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

		this.setMinHeight(50);
		this.setPrefHeight(100);
      selectionTracker = new SelectionTracker<ObservableReplyRow>(this, obboRow -> {
         String obboId = null;
         if (obboRow != null) {
            obboId = obboRow.getString(AmpOrderBookByOrder.managedOrderIdAcc);
            if (obboId == null) {
               obboId = obboRow.getString(AmpOrderBookByOrder.orderId);
            }
         }

         return obboId;
      }, obboRow -> {
         trackedRowPriceUpdate.setValue(obboRow.getValue(AmpOrderBookByOrder.price));
         return null;
      },"Obbo." + ((isBid)?"Bid":"Offer") ) {


         @Override
         public void setRowFactory() {
            IndependentSideTableView.this.setRowFactory(obboRowFactory);
         }
      };

		// Listening on row selection change
		selectionTracker.selectedItemProperty().addListener((observableRow, oldRow, newRow) -> {

         if (is4PopupStage)
            return;

         updateObboSelection(isBid, newRow, false);
      });

		trackedRowPriceUpdate.addListener((arg0, arg1, arg2) -> {
           if (arg2 != null) {
              obboRowPriceUpdated(arg2);
           }
        });

      isPickedUpInstrument = row -> {
         XfePickupAction action = pickedupActionProp.get();
         logger.debug("XfeAction is {}", action);
         if (action == null) return false;
         long pickedOrderId = action.getId();
         logger.debug("picked up order id  is {}", pickedOrderId);
         if (pickedOrderId == Long.MIN_VALUE) return false;
         Long orderId = row.getValue(AmpOrderBookByOrder.orderNo);
         logger.debug("row order Id is {}", orderId);
         return orderId != null && pickedOrderId == orderId;
      };

      isRfsHasNoLLTime = row -> {
         if ( (obboModule.selectionContextModule.dataContextRfqSec.get() || obboModule.selectionContextModule.dataContextRfsSec.get())  &&
             !Constants.PRICE_TYPE_INDICATIVE.equals(row.getValue(AmpOrderBookByOrder.specialOrderType))) {
            Long lastLookTime = row.getValue(AmpOrderBookByOrder.lastLookTime);
            return lastLookTime == null || lastLookTime.equals(0L);
         }
         return false;
      };

      obboRowFactory = new Callback<TableView<ObservableReplyRow>, TableRow<ObservableReplyRow>>() {
         @Override
         public TableRow<ObservableReplyRow> call(TableView<ObservableReplyRow> param) {
            AsnTableRow row = new AsnTableRow() {
               private final ObservableList<String> styles = this.getStyleClass();

               private final InvalidationListener pickUpPropLis = observable -> turnOnStyle(isPickedUpInstrument, Constants.CELL_STYLE_PICKEDUP_LY);

               private void clear() {
                  styles.removeAll("new-sweep", "sweep-last", "sweep-first",
                     Constants.CELL_STYLE_PICKEDUP_LY,
                     Constants.NON_LL_LG_STYLE,
                     Constants.PRICE_TYPE_INDICATIVE,
                     Constants.CELL_STYLE_INDICATIVE_BID,
                     Constants.CELL_STYLE_INDICATIVE_OFFER);
               }

               private final InvalidationListener sweepIndexLis = observable -> {
                  if (sweepToIndex.get() <= -1) {
                     clear();
                     return;
                  }
                  int index = _this.getIndex();
                  if (index <= sweepToIndex.get()) {
                     if (index == 0) {
                        style("sweep-first");
                     } else if (index == sweepToIndex.get()) {
                        style("sweep-last");
                     }
                     style("new-sweep");

                  } else {
                     clear();
                  }
               };

               @Override
               protected void updateItem(ObservableReplyRow item, boolean empty) {
                  super.updateItem(item, empty);
                  pickedupActionProp.removeListener(pickUpPropLis);
                  sweepToIndex.removeListener(sweepIndexLis);
                  if (item != null && !empty) {
                     turnOnStyle(AmpOrderBookByOrder.specialOrderType, Constants.PRICE_TYPE_INDICATIVE, isBid ? Constants.CELL_STYLE_INDICATIVE_BID : Constants.CELL_STYLE_INDICATIVE_OFFER);
                     turnOnStyle(isPickedUpInstrument, Constants.CELL_STYLE_PICKEDUP_LY);
                     turnOnStyle(isRfsHasNoLLTime, Constants.NON_LL_LG_STYLE);
                     pickedupActionProp.addListener(pickUpPropLis);
                     sweepToIndex.addListener(sweepIndexLis);
                  }else{
                     clear();
                  }
               }
            };

            row.addEventFilter(MouseEvent.MOUSE_CLICKED, event -> selectionTracker.setSelectedItem(row.getItem()));
            return row;
         }
      };
      this.setRowFactory(obboRowFactory);
	}

   //	public void deactivate() {
	//		if (getSelectionModel().getSelectedItem() != null) {
	//			getSelectionModel().clearSelection();
	//		}
	//		selectionTracker.setEnabled(false);
	//	}

	abstract void obboRowSelectionUpdated(ObservableReplyRow queryReplyRow, TablePosition tablePosition, int rowIndex, boolean forceUpdate);
	abstract void obboRowPriceUpdated(Double newPrice);

	void setActive(boolean isActive) {
		if (!isActive && selectionTracker.selectedItemProperty().get() != null) {
			selectionTracker.clearSelection();
		}
	}
	void updateObboSelection(boolean isBid,
                            ObservableReplyRow newRow,
                            boolean forceUpdate) {
		if (newRow != null) {
			Asn1Type lastSelectedOrderId = newRow.getAsn(AmpOrderBookByOrder.orderId);
			logger.debug("{} side Selected row changed - Order id: {}", isBid? Constants.COLUMN_NAME_BID:Constants.COLUMN_NAME_OFFER,AsnPrintFormatter.toShortString(lastSelectedOrderId));
			ObservableList<TablePosition>  tablePositions= IndependentSideTableView.this.getSelectionModel().getSelectedCells();
			if (tablePositions != null && tablePositions.size() == 1) {
				obboRowSelectionUpdated(newRow, tablePositions.get(0), IndependentSideTableView.this.getSelectionModel().getSelectedIndex(), forceUpdate);
			} else {
				obboRowSelectionUpdated(newRow, null, -1, forceUpdate);
			}
			obboRowPriceUpdated(newRow.getValue(AmpOrderBookByOrder.price));
		} else {
			logger.debug("{} side No row selected.", isBid ? Constants.COLUMN_NAME_BID : Constants.COLUMN_NAME_OFFER);
		}
	}

   private final IntegerProperty sweepToIndex = new SimpleIntegerProperty(-1);

   void highlightTo(int toRow) {
      int existIndex = sweepToIndex.get();
      if (toRow == -1 && existIndex < 0) {
         sweepToIndex.set(existIndex - 1);
      } else {
         sweepToIndex.set(toRow);
      }
   }
}
