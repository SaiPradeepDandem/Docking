package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpTreq;
import xstr.amp.AsnConversionAccessor;

public class AmpUserSetAutoOCO extends AmpAccessor {
	public static final AmpTreq txn = AMP.tREQ("userSetAutoOCO");

	public static final AsnConversionAccessor<Boolean> autoOCO = acc(AMP.tREQ("userSetAutoOCO.autoOCO"), Boolean.class);
}
