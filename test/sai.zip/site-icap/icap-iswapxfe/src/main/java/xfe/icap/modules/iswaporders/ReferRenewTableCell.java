package xfe.icap.modules.iswaporders;

import xfe.icap.types.ManagedOrder;
import xfe.types.UiSession;
import xfe.icap.amp.AmpManagedOrder;
import xstr.session.ObservableReplyRow;

import static xfe.icap.modules.iswaporders.OrderStatusDecorator.EMBARGOED;
import static xfe.icap.modules.iswaporders.OrderStatusDecorator.OPEN;
import static xfe.icap.modules.iswaporders.OrderStatusDecorator.PRIVATE_ORDER;

public class ReferRenewTableCell {

	public enum ActionType {
		REFER,
		RENEW,
		NONE
   }

	public static ActionType calcActionType(UiSession session, ObservableReplyRow row) {
      if(!new ManagedOrder(row).isManaged())
          return ActionType.NONE;
      String userId = row.getValue(AmpManagedOrder.userId);
      if (userId == null) {
          return ActionType.NONE;
      }

      int orderStatus = row.getValue(AmpManagedOrder.orderStatus);

      switch (orderStatus) {
          case OPEN:
          case EMBARGOED:
              return ActionType.REFER;
          case PRIVATE_ORDER:
              return ActionType.RENEW;
          default:
              return ActionType.NONE;
      }
	}
}
