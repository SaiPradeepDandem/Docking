package xfe.icap.util;

import com.nomx.domain.types.AlertSound;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import java.net.URL;

/**
 * Created by alum on 20/04/2020.
 *
 * @author Alum Lee
 * When running XFE via java launcher, AudioClip class made some performance issue, delay and high CPU usage.
 * Therefore, we need to use AudioSystem instead of AudioClip.
 * Both Settings module and Trade Alert module are need to use AudioSystem class so create new util class for handling alert sound file thru AudioSystem & Clip class.
 */
public class SoundPlayer {
   private static final Logger logger = LoggerFactory.getLogger(SoundPlayer.class);

   public static Clip createClip(AlertSound type) {
      if (type.getFile() == null)
         return null;

      URL url = SoundPlayer.class.getResource("/css/" + type.getFile());
      try {
         AudioInputStream sound = AudioSystem.getAudioInputStream(url);
         DataLine.Info info = new DataLine.Info(Clip.class, sound.getFormat());
         Clip clip = (Clip) AudioSystem.getLine(info);
         clip.open(sound);
         return clip;
      } catch (Exception e) {
         logger.error("cannot handle {} file: {}", type.toString(), e.toString());
         return null;
      }
   }
}
