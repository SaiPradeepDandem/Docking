package xfe.icap.types;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.collections.ObservableSet;
import xstr.util.Fun1;
import xstr.util.Lazy;
import xstr.util.Tuple;
import xstr.util.Tuple2;

import xstr.session.QueryFeed;
import xstr.session.QueryReplyRow;
import xstr.session.ServerSession;
import xstr.util.AmpListAggregator;
import xstr.util.Fx;
import xfe.icap.amp.AmpRfqMarketMaker;

public class RfqMarketMakers {
   private final AmpListAggregator aggregator = new AmpListAggregator(AmpRfqMarketMaker.rep);
   public final BooleanProperty readyProperty = new SimpleBooleanProperty(false);

   public final Lazy<ObservableList<QueryReplyRow>> all = new Lazy<ObservableList<QueryReplyRow>>() {
      @Override
      protected ObservableList<QueryReplyRow> initialize() {
         return Fx.unmodifiable(aggregator.items);
      }
   };

   public final Lazy<ObservableSet<String>> firms = new Lazy<ObservableSet<String>>() {
      @Override
      protected ObservableSet<String> initialize() {
         ObservableList<String> newFirmsList = Fx.map(all.get(), new Fun1<QueryReplyRow, String>() {
            @Override
            public String call(QueryReplyRow row) {
               return row.getValue(AmpRfqMarketMaker.firmId);
            }
         });

         return Fx.hashed(newFirmsList);
      }
   };

   public final Lazy<ObservableMap<String, ObservableList<String>>> firmsByInstrument = new Lazy<ObservableMap<String, ObservableList<String>>>() {
      @Override
      protected ObservableMap<String, ObservableList<String>> initialize() {
         return Fx.groupValuesBy(all.get(), new Fun1<QueryReplyRow, Tuple2<String, String>>() {
            @Override
            public Tuple2<String, String> call(QueryReplyRow row) {
               return Tuple.of(row.getValue(AmpRfqMarketMaker.instrId), row.getValue(AmpRfqMarketMaker.firmId));
            }
         });
      }
   };

   public RfqMarketMakers(ServerSession session) {
      QueryFeed feed = session.getFeedSource(AmpRfqMarketMaker.req);
      feed.addListener(aggregator);
      readyProperty.bind(aggregator.busyProperty().not());
   }
}
