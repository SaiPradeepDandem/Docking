package xfe.icap.client;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http.HttpHeaders.Names;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xstr.util.exception.XtrException;

import java.net.URI;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by jiadin on 9/02/2016.
 */
public class ProxyHandler extends ChannelDuplexHandler {

   private static final Logger logger = LoggerFactory.getLogger(ProxyHandler.class);

   public static final String CONNECT_PROXY="proxy";

   private final ByteBuf proxyConnectReq;
   private final URI targetUrl;
   private final String cred;

   public ProxyHandler(URI targetUrl) {
      this(targetUrl, null);
   }

   public ProxyHandler(URI targetUrl, String cred) {
      this.targetUrl = targetUrl;
      this.cred = cred;
      proxyConnectReq = proxyConnect();
   }

   private volatile boolean isConnected;
   private final List<Object> pendingObj= new LinkedList<>();

   boolean isConnecting;
   @Override
   public void channelActive(ChannelHandlerContext ctx) {
      isConnecting = true;
      ctx.writeAndFlush(proxyConnectReq);
   }

   @Override
   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
      if(isConnecting){
         isConnecting = false;
         logger.trace("connecting to proxy");
         super.write(ctx,msg,promise);
      } else if(!isConnected){
         keep(msg);
      }else{
         super.write(ctx,msg,promise);
         logger.trace("writing msg");
      }
   }

   private void keep(Object msg) {
//      if (msg instanceof ByteBuf)
      //         ByteBuf byteBuf = (ByteBuf) msg;
//         pendingObj.add(byteBuf.copy());
      pendingObj.add(msg);
      logger.trace("add msg into pending list {}", msg);
   }


   @Override
   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
      if(msg instanceof ByteBuf){
         ByteBuf bb = (ByteBuf)msg;
         int length = bb.readableBytes();
         byte[] proxyResponse = new  byte[length];
         bb.readBytes(proxyResponse);
         String strResponse = new String(proxyResponse);
         logger.trace("proxy response: {}", strResponse);
         if(strResponse.indexOf(" 200 ")>0){
            isConnected = true;
            ctx.pipeline().remove(this);
            super.channelActive(ctx);
         }else{
            throw new XtrException("connect to proxy failed");
         }
      }
      if(isConnected) {
         for (Object o:pendingObj) {
            ctx.writeAndFlush(o);
            logger.trace("write pending msg: {}", o);
         }

         logger.trace("Proxy handler removed");
      }
   }

   private ByteBuf proxyConnect(){
      ByteBuf bb = Unpooled.buffer();
      StringBuilder sb = new StringBuilder(100);
      sb.append("CONNECT ").append(targetUrl.getHost()).append(':').append(targetUrl.getPort()).append(' ').append(HttpVersion.HTTP_1_1).append('\r').append('\n');
      sb.append("Host: ").append(targetUrl.getHost()).append(':').append(targetUrl.getPort()).append('\r').append('\n').append('\r').append('\n');

      if (cred != null) {
         // Adding authentication credentials
         sb.append(Names.AUTHORIZATION).append(": Basic ").append(cred);
      }

      bb.writeBytes(sb.toString().getBytes());
      return bb;
   }
}

