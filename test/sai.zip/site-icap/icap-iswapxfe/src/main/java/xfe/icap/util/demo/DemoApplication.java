package xfe.icap.util.demo;

import com.sun.javafx.css.StyleManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import xfe.icap.themes.StyleSheet;

public class DemoApplication extends Application {

    public static Stage stage ;
    public static  Scene scene;
    protected BorderPane root ;

    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        root = FXMLLoader.load(getClass().getResource("/xfe/icap/util/demo/RootLayout.fxml"));
        scene = new Scene(root,700,700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("JavaFX Labs");
        primaryStage.show();
        Application.setUserAgentStylesheet(null);
        StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.BASE.getPath());
        StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.GILTS_BASE.getPath());
        StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.GILTS_BLUE.getPath());
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
