package xfe.icap.types;


import xstr.util.exception.AsnTypeException;
import javafx.util.Duration;

import xstr.amp.AsnConverter;
import com.objsys.asn1j.runtime.Asn1Type;
import com.omxgroup.xstream.amp.AsnDate;
import com.omxgroup.xstream.amp.AsnDateTime;
import com.omxgroup.xstream.amp.AsnTime;

public class ConverterForAsnDateTime_Duration implements AsnConverter<Duration> {

	@Override
	public Duration asnToValue(Asn1Type member) {
		if (member == null) return null;
		if (member instanceof AsnDateTime) {
			AsnDateTime asndt = (AsnDateTime)member;
			AsnTime asnTime = asndt.getTime();
			if (asnTime == null)
				throw new NullPointerException("ERROR: AsnDateTimeToDuration: AsnDateTime.time cannot be null");

			double millis =  (asnTime.value / 10000 % 100 * 3600 +
				    		 asnTime.value / 100 % 100 * 60 +
				    		 asnTime.value  % 100) * 1000;

         return new Duration(millis);
		}
		else
			throw new ClassCastException("Cannot convert " + member.getClass().getName() + " to Duration.");
	}

	@Override
	public Asn1Type valueToAsn(Duration value) throws AsnTypeException {
		if (value == null)
			return null;
		Asn1Type ret = null;
		try {
			ret = getAsnType().newInstance();
			setAsn(ret, value);
		} catch (InstantiationException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			//FIXME: Handle this
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}

	@Override
	public Asn1Type objectToAsn(Object obj) throws AsnTypeException {
		return valueToAsn((Duration)obj);
	}

	@Override
	public void setAsn(Asn1Type member, Duration val) throws AsnTypeException {
		if (val == null)
			throw new NullPointerException("Cannot set ASN internals to null. The whole ASN object should be set to null.");
		if (member instanceof AsnDateTime) {
			AsnDate dt = ((AsnDateTime)member).getDate();
			AsnTime tm = ((AsnDateTime)member).getTime();
			if (dt == null) {
				dt = new AsnDate();
				((AsnDateTime)member).setDate(dt);
			}
			if (tm == null) {
				tm = new AsnTime();
				((AsnDateTime)member).setTime(tm);
			}
			double totalNumOfSecs = val.toSeconds();
			int numOfHours = (int)(totalNumOfSecs / 3600);
			int numOfMinutes = (int)((totalNumOfSecs - numOfHours * 3600) / 60);
			int numOfSecs = (int)(totalNumOfSecs - numOfHours * 3600 - numOfMinutes * 60);

			tm.value =  numOfHours * 10000 + numOfMinutes * 100 + numOfSecs;
			dt.value = 0;
		}
		else
			throw new AsnTypeException("Cannot convert " + member.getClass().getName() + " to Duration.");
	}

	@Override
	public Class<Duration> getValueType() {
		return Duration.class;
	}

	@Override
	public Class<? extends Asn1Type> getAsnType() {
		return AsnDateTime.class;
	}

}
