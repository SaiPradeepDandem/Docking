package xfe.icap.ui;

import javafx.scene.media.AudioClip;

/**
 * Created by jiadin on 6/10/2016.
 */
public class Sounds {
   private final AudioClip tradeAlert;

   public Sounds(String resouceLocation) {
      tradeAlert = new AudioClip(Sounds.class.getResource("/css/" + resouceLocation).toString());
   }

   public void play() {
      tradeAlert.play();
   }
}
