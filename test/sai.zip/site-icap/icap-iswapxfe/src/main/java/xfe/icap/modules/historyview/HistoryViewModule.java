package xfe.icap.modules.historyview;

import javafx.beans.value.ObservableStringValue;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.util.Callback;
import xfe.icap.modules.actionsui.ActionsUIModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.layout.FxAbstractLayout;
import xfe.module.Module;
import xfe.modules.actionsui.ActionButton;
import xfe.modules.history.HistoricalEvent;
import xfe.modules.history.HistoryModule;
import xfe.modules.session.SessionScopeModule;
import xfe.util.scene.control.*;
import xstr.util.Filter;
import xstr.util.Fx;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.Future;

import java.text.DateFormat;

@Module.Autostart
public class HistoryViewModule extends SessionScopeModule {

   @ModuleDependency
   public ConfigurationModule settingsModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public HistoryModule historyModule;
   @ModuleDependency
   public ActionsUIModule actionsModule;

   private class HistoryViewDisposer implements Runnable {
      public HistoryViewDisposer(DecoratedTitledPane historyProviderPane) {
         this.titledPane = historyProviderPane;
      }

      @Override
      public void run() {
         layoutModule.removeView(titledPane);
         titledPane.dispose();
         if(presenter!=null){
            presenter.dispose();
         }
      }
      private final DecoratedTitledPane titledPane;
   }
   private static final DateFormat timeFormat = DateFormat.getTimeInstance();
   private static final Callback<HistoricalEvent, Node> translate = new Callback<HistoricalEvent, Node>() {

      @Override
      public Node call(HistoricalEvent ev) {
         if (ev != null) {
            Label label = new Label(ev.msgText);

            switch(ev.msgType) {
               case ERROR:
               case QUERY_REPLY_BAD:
               case TRANS_REPLY_BAD:
                  label.getStyleClass().add("error");
                  break;
               default:
                  label.getStyleClass().add("info");
            }

            Label timeLabel = new Label(timeFormat.format(ev.time)) {
               protected double computeMinWidth(double dontCare) {
                  return super.computePrefWidth(-1.f);
               }
            };

            GridPane pane = new GridPane() {
               {
                  ColumnConstraints colCons1 = new ColumnConstraints();
                  colCons1.setHgrow(Priority.ALWAYS);
                  colCons1.setFillWidth(true);
                  ColumnConstraints colCons2 = new ColumnConstraints();
                  colCons2.setHgrow(Priority.NEVER);
                  this.getColumnConstraints().setAll(colCons1, colCons2);
               }

               @Override
               public String toString() {
                  return "pane for "+ev.msgText;
               }
            };

            pane.add(label, 0, 0);
            pane.add(timeLabel, 1, 0);
            GridPane.setMargin(timeLabel, new Insets(0, 0, 0, 14.f));


            return pane;
         } else {
            return new Label();
         }
      }};

   @SuppressWarnings("unchecked")
   private static TableView<HistoricalEvent> createTableView() {
      return new TableViewHeaderUnmovable<HistoricalEvent>() {{
         this.getStyleClass().add("xfe-table");
         ObservableList<TableColumn<HistoricalEvent, ?>> columns = this.getColumns();
         this.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
         columns.add(new EnhancedTableColumn<HistoricalEvent, String>() {
            {
               this.setText("Event");
               this.setPrefWidth(580);
               this.setResizable(false);
               this.setCellFactory(new Callback<TableColumn<HistoricalEvent, String>, TableCell<HistoricalEvent, String>>() {
                  @Override
                  public TableCell<HistoricalEvent, String> call(TableColumn<HistoricalEvent, String> column) {

                     return new TextFieldTableCell<HistoricalEvent, String>() {
                        @Override
                        public void updateItem(String item, boolean empty) {
                           super.updateItem(item, empty);

                           if (!empty) {
                              HistoricalEvent eve = getTableView().getItems().get(getTableRow().getIndex());
                              Tooltip tip = new Tooltip(eve.msgText);
                              setTooltip(tip);
                              setText(eve.msgText);
                           } else {
                              setTooltip(null);
                              setText(null);
                           }
                        }
                     };
                  }
               });


               Filter<HistoricalEvent> errorFilter = new Filter<HistoricalEvent>() {
                  @Override
                  public boolean accept(HistoricalEvent ev) {
                     switch(ev.msgType) {
                        case ERROR:
                        case QUERY_REPLY_BAD:
                        case TRANS_REPLY_BAD:
                           return true;
                        default:
                     }
                     return false;
                  }};
               this.setLayerFactories(layerFactory("info", errorFilter.not(),
                  layerFactory("error", errorFilter, LabeledLayerFactory.create())));
            }
         });
         columns.add(new EnhancedTableColumn<HistoricalEvent, String>() {{
            this.setText("Time");
            this.setPrefWidth(80);
            this.setResizable(false);
            this.setValueFactory(new Callback<HistoricalEvent, ObservableStringValue>() {
               @Override
               public ObservableStringValue call(HistoricalEvent ev) {
                  return Fx.constOf(timeFormat.format(ev.time));
               }
            });
         }
         });
      }};
   }

   @Override
   public Future<Void> startModule() {
      createHistoryView();
      actionsModule.addCustomButton(2, new ActionButton() {{
         this.getStyleClass().add("xfe-icon-historyModule");
         this.setText("History");
         setId("xfe-iswap-btn-action-history");
         XfeTooltipFactory.setTooltip(this);
         tracker.bindBidirectional(this.selectedProperty(), settingsModule.getData().displayHistoryProperty());
         this.installUnreadCountStateListeners(tracker, historyModule.historyProperty());
      }});
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tracker.rollback();
      return Future.SUCCESS;
   }

   private void createHistoryView() {
      TableView<HistoricalEvent> tableView = createTableView();
      DecoratedTitledPane titledPane = new DecoratedTitledPane("History", tableView,true,layoutModule,true);
      HBox buttonsPane = new HBox();
      titledPane.setLeftDecoration(buttonsPane);
//         titledPane.getDecoratedTitledPaneSkin().getTitleButton().getStyleClass().add("disabled-look-title-button");
      tracker.registerRollbackAction(new HistoryViewDisposer(titledPane));
      titledPane.setId("history-provider-view");
      tracker.bindBidirectional(titledPane.expandProperty(), settingsModule.getData().historyExpandProperty());
      tracker.bindBidirectional(titledPane.displayProperty(), settingsModule.getData().displayHistoryProperty());
      tracker.bindBidirectional(titledPane.sizeProperty(), settingsModule.getData().historyHeightProperty());
      presenter = new DecoratedTitledPaneCompositePresenter<>(titledPane, translate, tracker, Fx.valueOf(0.0));
      tracker.bind(presenter.headerShowingTimeoutProperty(),
         settingsModule.getData().historyHeaderNotificationTimeoutProperty());
      presenter.setItems(historyModule.historyProperty());

      tableView.setItems(Fx.sortBy(historyModule.historyProperty(), (ev1, ev2) -> {
         return ev2.time.compareTo(ev1.time);
      }));

      layoutModule.addView(titledPane);
   }
   private final ListenerTracker tracker = new ListenerTracker();
   private DecoratedTitledPaneCompositePresenter<HistoricalEvent> presenter;
}
