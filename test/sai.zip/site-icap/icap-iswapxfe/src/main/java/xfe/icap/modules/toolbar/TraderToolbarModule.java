package xfe.icap.modules.toolbar;

import com.omxgroup.xstream.amp.AmpContactMethod;
import javafx.application.Platform;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.stage.Stage;
import xfe.XfeAppModule;
import xfe.icap.amp.AmpContactMe;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settingsview.SettingsViewModule;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.control.IconButton;
import xfe.ui.control.IconToggleButton;
import xfe.ui.window.ManagedWindow;
import xfe.util.scene.control.XfeTooltipFactory;
import xstr.session.XtrTransRequestBuilder;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

@Module.Autostart
public class TraderToolbarModule extends SessionScopeModule {
    @ModuleDependency
    public MidiLayoutModule midiLayoutModule;

    @ModuleDependency
    public SettingsViewModule settingsViewModule;

    @ModuleDependency
    public ConfigurationModule configurationModule;

    @ModuleDependency
    public XfeAppModule appModule;

    private static final String SAFE_MODE = "Safe Mode";

    private Button phoneMeButton;
    private Button ibMeButton;
    private ToggleButton safeModeButton;
    private Node uiRoot;
    private SimpleDateFormat sdfDate = new SimpleDateFormat("HH:mm");
    private Button settingsButton;
    private Button saveButton;
    private ToggleButton toolTipsButton;
    private Label teTimeLabel;
    private Consumer<Label> safeModeLabelConsumer;
    private EventHandler<ActionEvent> saveActionHandler;
    private EventHandler<ActionEvent> settingsActionHandler;
    private ToolBar toolBar;
    private ScheduledExecutorService executor;
    private IconButton workspaceResetButton;

    @Override
    public Future<Void> startModule() {
        saveActionHandler = e -> configurationModule.save();

        BooleanProperty tooltipOnConfig = configurationModule.getData().tooltipOn();
        getToolTipButton().setSelected(tooltipOnConfig.get());
        XfeTooltipFactory.tooltipOnProp.bind(getToolTipButton().selectedProperty());
        tooltipOnConfig.bind(getToolTipButton().selectedProperty());

        toolBar = new ToolBar();
        toolBar.setPadding(new Insets(0, 10, 0, 10));
        toolBar.setMinHeight(24);

        final Pane rightSpacer = new Pane();
        HBox.setHgrow(rightSpacer, Priority.ALWAYS);


        teTimeLabel = new Label("TE Time");

        toolBar.getItems().addAll(getSettingsButton(), getSaveButton(), getPhoneButton(), getIbMeButton(),
                getSafeModeButton(), getToolTipButton(), getWorkspaceRestButton(),
                rightSpacer, teTimeLabel);

        executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(new UpdateEngineTimeTask(), 0, 1, TimeUnit.MINUTES);
        TraderToolbarModule.this.uiRoot = toolBar;
        uiRoot.setId(MidiLayoutViews.TRADER_TOOLBAR);
        midiLayoutModule.addView(uiRoot);
        return Future.SUCCESS;
    }

    private Button getSettingsButton() {
        if (this.settingsButton == null) {
            this.settingsButton = new IconButton("xfe-icon-settings") {
                {
                    setId("xfe-iswap-settings-btn");
                    XfeTooltipFactory.setTooltip(this);
                }
            };

            final Consumer<ManagedWindow> stageHandler = stage -> {
                if (stage.getOnCloseRequest() == null) {
                    stage.setOnCloseRequest(e -> {
                        settingsViewModule.getCancelHandler().run();
                        e.consume();
                    });
                }
            };
            settingsActionHandler = e -> {
                midiLayoutModule.addPopupView(settingsViewModule.getRoot(), stageHandler);
                settingsViewModule.onPopupShown();
            };
            this.settingsButton.setOnAction(settingsActionHandler);
        }
        return this.settingsButton;
    }

    /**
     * Specific button used by TestFX to reset the workspace. NOT FOR XFE APP.
     *
     * @return Button
     */
    private Button getWorkspaceRestButton() {
        if (this.workspaceResetButton == null) {
            this.workspaceResetButton = new IconButton() {
                {
                    setId("xfe-iswap-workspace-reset-btn");
                }
            };
            // Totally hiding but making it available to search by TestFX
            this.workspaceResetButton.setStyle("-fx-opacity:0;");
            this.workspaceResetButton.setMouseTransparent(true);
            this.workspaceResetButton.setFocusTraversable(false);
            this.workspaceResetButton.setOnAction(e -> settingsViewModule.resetAllForTestFX());
        }
        return this.workspaceResetButton;
    }

    private Button getSaveButton() {
        if (this.saveButton == null) {
            this.saveButton = new IconButton("xfe-icon-save") {
                {
                    setId("xfe-iswap-save-btn");
                    XfeTooltipFactory.setTooltip(this);
                }
            };
            this.saveButton.setOnAction(saveActionHandler);
        }
        return this.saveButton;
    }

    private Button getPhoneButton() {
        if (phoneMeButton == null) {
            phoneMeButton =
                    new IconButton("xfe-icon-call-me") {
                        {
                            setId("xfe-iswap-callme-btn");
                            XfeTooltipFactory.setTooltip(this);
                            setOnAction(
                                    event -> {
                                        Alert alert =
                                                new Alert(
                                                        null,
                                                        "Do you wish TPICAP to contact you by phone?",
                                                        ButtonType.YES,
                                                        ButtonType.CANCEL);
                                        ((Stage) alert.getDialogPane().getScene().getWindow())
                                                .getIcons()
                                                .addAll(appModule.getStage().getIcons());
                                        alert
                                                .showAndWait()
                                                .filter(response -> response == ButtonType.YES)
                                                .ifPresent(
                                                        response -> {
                                                            try {
                                                                XtrTransRequestBuilder reqBuilder =
                                                                        XtrTransRequestBuilder.create(
                                                                                AmpContactMe.txn,
                                                                                activeSessionModule.getSession().get())
                                                                                .set(AmpContactMe.contactMethod, AmpContactMethod.phone);
                                                                activeSessionModule.getSession().get().execute(reqBuilder.build());
                                                            } catch (AsnTypeException | AmpPermissionException e) {
                                                                e.printStackTrace();
                                                            }
                                                        });
                                    });
                        }
                    };
        }
        return phoneMeButton;
    }

    private Button getIbMeButton() {
        if (ibMeButton == null) {
            ibMeButton =
                    new IconButton("xfe-icon-ib-me") {
                        {
                            setId("xfe-iswap-ibme-btn");
                            XfeTooltipFactory.setTooltip(this);
                            setOnAction(
                                    event -> {
                                        Alert alert =
                                                new Alert(
                                                        null,
                                                        "Do you wish TPICAP to contact you by IB?",
                                                        ButtonType.YES,
                                                        ButtonType.CANCEL);
                                        alert.getDialogPane().getStyleClass().add("xfe-icon-app-title");
                                        ((Stage) alert.getDialogPane().getScene().getWindow())
                                                .getIcons()
                                                .addAll(appModule.getStage().getIcons());
                                        alert
                                                .showAndWait()
                                                .filter(response -> response == ButtonType.YES)
                                                .ifPresent(
                                                        response -> {
                                                            try {
                                                                XtrTransRequestBuilder reqBuilder =
                                                                        XtrTransRequestBuilder.create(
                                                                                AmpContactMe.txn,
                                                                                activeSessionModule.getSession().get())
                                                                                .set(
                                                                                        AmpContactMe.contactMethod,
                                                                                        AmpContactMethod.instantMessage);
                                                                activeSessionModule.getSession().get().execute(reqBuilder.build());
                                                            } catch (AsnTypeException | AmpPermissionException e) {
                                                                e.printStackTrace();
                                                            }
                                                        });
                                    });
                        }
                    };
        }
        return ibMeButton;
    }

    private ToggleButton getSafeModeButton() {
        if (safeModeButton == null) {
            BooleanProperty skipSafeDeselection = new SimpleBooleanProperty();
            safeModeButton =
                    new IconToggleButton("xfe-icon-safemode") {
                        {
                            setId("xfe-iswap-safemode-btn");
                            this.tooltipProperty()
                                    .bind(
                                            new ObjectBinding<Tooltip>() {
                                                {
                                                    bind(selectedProperty(), toolTipsButton.selectedProperty());
                                                }

                                                @Override
                                                protected Tooltip computeValue() {
                                                    return toolTipsButton.selectedProperty().get()
                                                            ? (selectedProperty().get()
                                                            ? XfeTooltipFactory.createTooltip(
                                                            SAFE_MODE, "Turn Safe Mode off")
                                                            : XfeTooltipFactory.createTooltip(
                                                            SAFE_MODE, "Turn Safe Mode on"))
                                                            : null;
                                                }
                                            });
                            setSelected(false);
                        }
                    };
            safeModeButton
                    .selectedProperty()
                    .addListener(
                            (obs, old, safeMode) ->
                                    activeSessionModule
                                            .getSession()
                                            .ifPresent(
                                                    serverSession -> {
                                                        if (safeMode) {
                                                            if (serverSession.isLocked()) {
                                                                // If already locked, then deselecting the safe button.
                                                                skipSafeDeselection.set(true);
                                                                safeModeButton.setSelected(false);
                                                            } else {
                                                                activeSessionModule.lock(true);
                                                                if (safeModeLabelConsumer != null) {
                                                                    final Label safeModeLbl = new Label(SAFE_MODE);
                                                                    safeModeLbl.getStyleClass().add("safe-mode-label");
                                                                    safeModeLabelConsumer.accept(safeModeLbl);

                                                                    final Label safeModeLbl1 = new Label(SAFE_MODE);
                                                                    safeModeLbl1.getStyleClass().add("safe-mode-label");
                                                                    midiLayoutModule.displaySafeModeLabel(safeModeLbl1);
                                                                }
                                                            }
                                                        } else {
                                                            // Not performing any operation if the session is already locked and
                                                            // the button is deselected programatically.
                                                            if (!skipSafeDeselection.get()) {
                                                                activeSessionModule.unlock(null, true);
                                                                if (safeModeLabelConsumer != null) {
                                                                    safeModeLabelConsumer.accept(null);
                                                                }
                                                                midiLayoutModule.displaySafeModeLabel(null);
                                                            }
                                                            skipSafeDeselection.set(false);
                                                        }
                                                    }));
        }
        return safeModeButton;
    }


    private ToggleButton getToolTipButton() {
        if (toolTipsButton == null) {
            toolTipsButton =
                    new IconToggleButton("xfe-icon-tooltip") {
                        {
                            setId("xfe-iswap-settings-tooltip");
                            Tooltip on = XfeTooltipFactory.createTooltip("Tooltips", "Turn tooltips off", true);
                            Tooltip off = XfeTooltipFactory.createTooltip("Tooltips", "Turn tooltips on", true);
                            this.tooltipProperty()
                                    .bind(
                                            new ObjectBinding<Tooltip>() {
                                                {
                                                    bind(selectedProperty());
                                                }

                                                @Override
                                                protected Tooltip computeValue() {
                                                    return selectedProperty().get() ? on : off;
                                                }
                                            });
                        }
                    };
        }
        return toolTipsButton;
    }

    @Override
    public Future<Void> stopModule() {
        XfeTooltipFactory.tooltipOnProp.unbind();
// exit the timer thread
        getSaveButton().setOnAction(null);
        getSettingsButton().setOnAction(null);
        saveActionHandler = null;
        settingsActionHandler = null;
        midiLayoutModule.removeView(settingsViewModule.getRoot());
        midiLayoutModule.removeView(uiRoot);
        cleanUpToolBar();
        stopEngineTimer();
        return Future.SUCCESS;
    }

    private void cleanUpToolBar() {
        phoneMeButton = null;
        ibMeButton = null;
        safeModeButton = null;
        toolTipsButton = null;
        saveButton = null;
        settingsButton = null;
        toolBar.getItems().clear();
        toolBar = null;
    }

    private void stopEngineTimer() {
        executor.shutdown();
    }

    public void setSafeModeLabelConsumer(Consumer<Label> safeModeLabelConsumer) {
        this.safeModeLabelConsumer = safeModeLabelConsumer;
    }

    private class UpdateEngineTimeTask implements Runnable {
        @Override
        public void run() {
            activeSessionModule.getSession().ifPresent(session -> {
                final Date engineTime = session.getStats().getEngineTime();
                Platform.runLater(() -> teTimeLabel.setText(sdfDate.format(engineTime)));
            });
        }
    }
}
