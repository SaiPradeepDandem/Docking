package xfe.icap.modules.orderentry;

import com.nomx.persist.rfq.MarketMaker;
import com.nomx.persist.rfq.MarketMakerGroup;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpFirm;
import xfe.types.SecBoard;
import xstr.session.QueryReplyRow;
import xfe.types.StepArray;
import xstr.util.Fun1;
import xstr.util.Fx;
import xfe.util.HandlerCompositeUtils;
import xstr.util.Lazy;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Disposer;
import xstr.util.concurrent.Future;
import xfe.util.scene.control.DoubleTextField;
import xfe.util.scene.control.SpinBox;
import xfe.modules.orderentry.RfqView;
import xfe.icap.modules.settings.SettingsData;
import xfe.ui.logon.UnlockView;

import java.io.IOException;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class RfqPane extends DisposableBase implements RfqView<Node> {
   private static final Logger logger = LoggerFactory.getLogger(RfqPane.class);

   private static final String rfq_bidText = "REQUEST BIDS";
   private static final String rfq_offerText = "REQUEST OFFERS";
   private static final Object SPIN_CHANGE = new Object();

   private RfqPane(
      SettingsData data,
      EntryModule entryModule,
      SecBoardContext secBoardContext,
      XfeSession session) {
      this.entryModule = entryModule;
      this.settingsData = data;
      this.secBoardContext = secBoardContext;
      this.session = session;
      mmFirms.get(); // Initialise
   }

   public StepArray getPriceStepArray() {
      return priceStepArrayProperty().get();
   }

   public void setPriceStepArray(StepArray priceStepArray) {
      priceStepArrayProperty().set(priceStepArray);
   }

   public ObjectProperty<StepArray> priceStepArrayProperty() {
      return priceStepArrayProperty;
   }

   public StepArray getQuantityStepArray() {
      return quantityStepArrayProperty().get();
   }

   public void setQuantityStepArray(StepArray quantityStepArray) {
      quantityStepArrayProperty().set(quantityStepArray);
   }

   public void setUnlockHandler(Consumer<char[]> handler) {
      getUnlockView().setUnlockHandler(handler);
   }

   public BooleanProperty bidOnLeftProperty() {
      return settingsData.bidOnLeftProperty();
   }

   public BooleanProperty disableProperty() {
      return this.getRootElement().disableProperty();
   }

   @Override
   public StackPane getRootElement() {
      if (!isInitialized) {
         isInitialized = true;

         rfqRootNode.disableProperty().bind(Bindings.or(noSecSelected, secHasNoMM));

         configure();

         Node unlockSplashPane = getUnlockView().getRootElement();
         disposer.disposes(Fx.bind(unlockSplashPane.visibleProperty(), presenterProperty.get().unlockViewVisibleProperty()));
         disposer.disposes(Fx.bind(unlockSplashPane.managedProperty(), presenterProperty.get().unlockViewVisibleProperty()));
         disposer.disposes(Fx.addWeakListener(presenterProperty.get().unlockViewVisibleProperty(), HandlerCompositeUtils.wrapPostponeListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(
               ObservableValue<? extends Boolean> observableVisible,
               Boolean oldVisible,
               Boolean newVisible) {
               if (newVisible) {
                  getUnlockView().requestFocus();
               }
            }
         })));

         rootNode.getChildren().add(unlockSplashPane);
      }

      return rootNode;
   }

   private void configure() {
      sizeHBoxR.getChildren().addAll(
         sizeEdit.get(),
         new SpinBox() {{
            this.setOnSpin(event -> sizeEdit.get().step(event.amount));
         }});

      this.firmCheckboxes.get(); // Initialise checkboxes.
   }

   @Override
   public void requestFocus() {
   }

   static RfqPane load(
      SettingsData data,
      EntryModule entryModule,
      SecBoardContext secBoardContext,
      XfeSession session) {

      FXMLLoader ldr;
      ldr = new FXMLLoader(RfqPane.class.getResource("RfqPane.fxml"));

      Disposer disposer = new Disposer();

      try {
         RfqPane rfqPane = disposer.disposes(new RfqPane(data, entryModule, secBoardContext, session));

         rfqPane.isInitialized = false;
         ldr.setController(rfqPane);

         try {
            ldr.load();

            return disposer.cancelThenYield(rfqPane);
         } catch (IOException e) {
            return null;
         }
      } finally {
         disposer.dispose();
      }
   }

   @Override
   protected Future<Void> dispose(boolean disposing) {
      return disposer.dispose().onSuccess(vd -> {
         if(lockedSplash!=null){
            lockedSplash.dispose();
         }
         sizeEdit.get().valueProperty().unbindBidirectional(entryModule.rfqSizeEditProperty.get());
         return RfqPane.super.dispose(disposing);
      });
   }

   @FXML
   private void initialize() {
      try {
         fullSizeChk.setText("FULL SIZE");

         disposer.disposes(Fx.addWeakListener(Bindings.isNotNull(presenterProperty), (observable1, oldValue, newValue) -> {
            if (newValue)
               submitButton.disableProperty().bind(Bindings.or(Bindings.not(Bindings.or(requestBidsChk.selectedProperty(),
                  requestOffersChk.selectedProperty())), presenterProperty.get().pendingDatesProperty()));
            else
               submitButton.disableProperty().bind(new ReadOnlyBooleanWrapper(false));
         }));

         submitButton.setOnAction(event -> getPresenter().onSubmit(false));
         disposer.disposes(Fx.addWeakListener(entryModule.selectionContextModule.secBoardContext.get().rowProperty(), (obsVal, oldVal, newVal) -> {
            if (entryModule.showOrderPaneProperty.getValue()|| newVal == null) {
               isSecSelectionChanged = true;
               return;
            }
            isSecSelectionChanged = false;
            setDefaultValue();
         }));
         disposer.disposes(Fx.addWeakListener(entryModule.showRfqPaneProperty, observable -> {
            if (entryModule.showRfqPaneProperty.getValue() && isSecSelectionChanged) {
               setDefaultValue();
               isSecSelectionChanged = false;
            }
         }));
         disposer.disposes(Fx.addWeakListener(mmFirms.get(), (Observable observable) -> {
            secHasNoMM.set(mmFirms.get().isEmpty());
         }));
         InvalidationListener lis = observable -> {
            if(settingsData.bidOnLeftProperty().get()){

               GridPane.setConstraints(requestBidsChk, 0, GridPane.getRowIndex(requestBidsChk));
               GridPane.setConstraints(requestOffersChk, 1, GridPane.getRowIndex(requestOffersChk));
            }else{
               GridPane.setConstraints(requestBidsChk, 1, GridPane.getRowIndex(requestBidsChk));
               GridPane.setConstraints(requestOffersChk, 0, GridPane.getRowIndex(requestOffersChk));
            }
         };
         lis.invalidated(null);
         requestBidsChk.setSelected(true);
         requestOffersChk.setSelected(true);
         disposer.disposes(Fx.addWeakListener(settingsData.bidOnLeftProperty(), lis));
      } catch (Exception e) {
         e.printStackTrace(System.out);
      }

   }

   protected Presenter<?> getPresenter() {
      return presenterProperty.get();
   }

   private void setDefaultValue() {
      requestBidsChk.setText(rfq_bidText);
      requestOffersChk.setText(rfq_offerText);
      firmCheckboxes.get().stream().filter(mm -> mm.getUserData() == null).forEach(mm -> mm.setSelected(false));
      sizeEdit.get().setValue(entryModule.rfqPresenter.get().getDefaultSize());
   }

   @Override
   public void setPresenter(Presenter<Node> presenter) {
      this.presenterProperty.set(presenter);
   }

   @Override
   public void setLabel(String text) {
      instrumentNameLabel.textProperty().set(text);
   }

   @Override
   public boolean getRequestBids() {
      return requestBidsChk.isSelected() ;
   }

   @Override
   public boolean getRequestOffers() {
      return requestOffersChk.isSelected() ;
   }

   @Override
   public String getSizeText() {
      return sizeEdit.get().doubleTextProperty().get();
   }

   @Override
   public Boolean getFullSize() {
      return fullSizeChk.isSelected();
   }

   @Override
   public String[] getFirms() {
      List<CheckBox> allCheckbox = firmCheckboxes.get();
      String[] rtn;
      if (settingsData.rfqMMAdvSettingAEnabledProperty().get()) {
         Set<String> firms = new HashSet<>(30);
         for(CheckBox checkBox: allCheckbox){
            if(!checkBox.isSelected()) continue;
            Object o = checkBox.getUserData();
            if(o!=null){
               MarketMakerGroup group = (MarketMakerGroup)o;
               firms.addAll(group.getItems().stream().map(MarketMaker::getId).collect(Collectors.toList()));
            }
         }
         rtn = firms.toArray(new String[firms.size()]);
      }else{
         List<String> firms = new ArrayList<>(allCheckbox.size());
         for(CheckBox checkBox: allCheckbox){
            if(!checkBox.isSelected()) continue;
            Object o = checkBox.getUserData();
            if(o!=null){
               firms.add(o.toString());
            }
         }
         rtn = firms.toArray(new String[firms.size()]);
      }
      return rtn;
   }

   @Override
   public void setAllFirms(ObservableSet<String> allFirms) {
      initMMFirms(allFirms);
   }

   void initMMFirms(ObservableSet<String> allFirms) {
      List<String> wsFirms = new ArrayList<>(settingsData.selectedMMFirmsProperty().get());
      wsFirms.retainAll(allFirms);
      selectedFirms.setAll(wsFirms.stream().sorted().collect(Collectors.toList()));
      settingsData.selectedMMFirmsProperty().addListener((observable, oldValue, newValue) -> {
         selectedFirms.setAll(newValue);
      });
   }

   @Override
   public void setSizeDecimals(long decimals) {
      sizeEdit.get().decimalsProperty().set((int) decimals);
   }

   public ObjectProperty<StepArray> quantityStepArrayProperty() {
      return quantityStepArrayProperty;
   }

   @Override
   public ReadOnlyStringProperty sizeTextProperty() {
      return sizeEdit.get().doubleTextProperty();
   }

   public UnlockView<? extends Node> getUnlockView() {
      if (lockedSplash == null) {
         lockedSplash = new LockedSplashPane();
      }

      return lockedSplash;
   }

   @Override
   public IntegerProperty sizeDecimalsProperty() {
      return sizeEdit.get().decimalsProperty();
   }

   @Override
   public void setFocusOnQty() {
      sizeEdit.get().requestFocus();
   }

   @Override
   public void enableRfq(boolean rfqDisabled) {
      this.noSecSelected.set(!rfqDisabled);
   }
   @FXML public VBox rfqRootNode;
   final ObservableList<String> selectedFirms = FXCollections.observableArrayList();
   boolean isInitialized;
   private EntryModule entryModule;
   private final Disposer disposer = new Disposer();
   private boolean isSecSelectionChanged;
   private final ObjectProperty<Presenter<Node>> presenterProperty = new SimpleObjectProperty<>();
   @FXML	private StackPane rootNode;
   @FXML private Label instrumentNameLabel;
   @FXML private CheckBox requestBidsChk;
   @FXML private CheckBox requestOffersChk;
   @FXML private HBox sizeHBoxR;
   @FXML private CheckBox fullSizeChk;
   @FXML private CheckBox firm0Chk;
   @FXML private CheckBox firm1Chk;
   @FXML private CheckBox firm2Chk;
   @FXML private CheckBox firm3Chk;
   @FXML private CheckBox firm4Chk;
   @FXML private CheckBox firm5Chk;
   @FXML private Button submitButton;
   private final Lazy<ObservableList<CheckBox>> firmCheckboxes = new Lazy<ObservableList<CheckBox>>() {
      @Override
      public ObservableList<CheckBox> initialize() {

         selectedFirms.addListener(new ListChangeListener<String>() {
            @Override
            public void onChanged(Change<? extends String> change) {
               if(!settingsData.rfqMMAdvSettingAEnabledProperty().get()){
                  for (CheckBox checkbox: firmCheckboxes.get()) {
                     checkbox.setSelected(false);
                  }
               }
            }
         });

         ObservableList<CheckBox> newFirmCheckboxes = Fx.unmodifiable(
            FXCollections.observableList(Arrays.asList(firm0Chk, firm1Chk, firm2Chk, firm3Chk, firm4Chk, firm5Chk)));

         ObservableMap<String, QueryReplyRow> firmsById = entryModule.xfeSessionModule.firms.get().byId.get();

         for (int i = 0; i < newFirmCheckboxes.size(); ++i) {
            CheckBox checkBox = newFirmCheckboxes.get(i);
            int index = i;


            checkBox.textProperty().bind(new StringBinding() {
               {
                  bind(selectedFirms, shortcutGroup.get(),firmsById, entryModule.xfeSessionModule.firms.get().all.get(),settingsData.rfqMMAdvSettingAEnabledProperty());
               }

               @Override
               protected String computeValue() {
                  if (settingsData.rfqMMAdvSettingAEnabledProperty().get()) {
                     if (index >= shortcutGroup.get().size()) {
                        checkBox.setUserData(null);
                        return "";
                     }
                     MarketMakerGroup group = shortcutGroup.get().get(index);
                     String groupName = group.getId();
                     checkBox.setUserData(group);
                     return groupName;
                  } else {
                     if (index >= selectedFirms.size()) {
                        checkBox.setUserData(null);
                        return "";
                     }

                     String selectedFirm = selectedFirms.get(index);
                     checkBox.setUserData(selectedFirm);
                     QueryReplyRow firm = firmsById.get(selectedFirm);
                     String percent;
                     if (firm != null)
                        percent = " (" + firm.getValue(AmpFirm.rfqTradeCompletionPct) + "%)";
                     else{
                        percent = "...";
                     }

                     return selectedFirms.size() > index ? selectedFirm + " " + percent : "";
                  }
               }
            });

            // Reverting to this line until the code below is working
            checkBox.disableProperty().bind(new BooleanBinding() {
               {
                  bind(selectedFirms, shortcutGroup.get(), mmFirms.get(), settingsData.rfqMMAdvSettingAEnabledProperty());
               }

               @Override
               protected boolean computeValue() {
                  if (settingsData.rfqMMAdvSettingAEnabledProperty().get()) {
                     return index >= shortcutGroup.get().size();
                  } else {
                     if (index >= selectedFirms.size()) return true;

                     String selectedFirm = selectedFirms.get(index);

                     boolean isDisabled =  !mmFirms.get().contains(selectedFirm);
                     if (isDisabled) {
                        checkBox.setSelected(false);
                     } else {
                        checkBox.setSelected(true);
                     }

                     return isDisabled;
                  }
               }
            });

         }

         return newFirmCheckboxes;
      }
   };
   private final Lazy<ObservableList<MarketMakerGroup>> shortcutGroup = new Lazy<ObservableList<MarketMakerGroup>>() {
      @Override
      protected ObservableList<MarketMakerGroup> initialize() {
         ObservableList<MarketMakerGroup> newSelectedFirms = Fx.derefList(settingsData.selectedMMGroupProperty());
         ObservableList<MarketMakerGroup> shortcutList = Fx.filterBy(newSelectedFirms, new Fun1<MarketMakerGroup, Boolean>() {

            @Override
            public Boolean call(MarketMakerGroup mm) {
               return mm.isShortcut;
            }
         });

         shortcutList.addListener(new ListChangeListener<MarketMakerGroup>() {
            @Override
            public void onChanged(Change<? extends MarketMakerGroup> change) {
               if(settingsData.rfqMMAdvSettingAEnabledProperty().get()){
                  for (CheckBox checkbox: firmCheckboxes.get()) {
                     checkbox.setSelected(false);
                  }
               }
            }
         });

         return shortcutList;
      }
   };
   private final SettingsData settingsData;
   private final Lazy<DoubleTextField> sizeEdit = new Lazy<DoubleTextField>() {
      @Override
      protected DoubleTextField initialize() {
         return new DoubleTextField(0, 10000) {
            {
               this.setTextAlignment(TextAlignment.CENTER);
               this.getStyleClass().add("xfe-rfq-size-edit");
               this.decimalsProperty().set(0);
               this.setPrefHeight(30);
               this.valueProperty().bindBidirectional(entryModule.rfqSizeEditProperty.get());
            }

            @Override
            public void step(int steps) {
               StepArray quantityStepArray = RfqPane.this.getQuantityStepArray();

               if (quantityStepArray != null) {
                  changeTrail.run(SPIN_CHANGE, () -> {
                     double newValue = quantityStepArray.notch(getValue(), steps);
                     setValue(newValue);
                     noRecurse.run(() -> {
                        Fx.runLater(this::selectAll);
                        requestFocus();
                     });
                  });
               }
            }
         };
      }
   };

   public Lazy<ObservableSet<String>> mmFirms = new Lazy<ObservableSet<String>>() {
      @Override
      protected ObservableSet<String> initialize() {
         ObservableValue<String> liveInstrumentId = Fx.map(secBoardContext.liveSecBoard.get(), new Fun1<SecBoard, String>() {
            @Override
            public String call(SecBoard secBoard) {
               return secBoard != null ? secBoard.getInstrumentId() : null;
            }
         });

         ObservableList<String> newMmFirms = Fx.derefList(Fx.valueAt(session.mmFirms.get().firmsByInstrument.get(), liveInstrumentId));

         if (logger.isTraceEnabled()) {
            newMmFirms.addListener((ListChangeListener<String>) change -> logger.debug("firms is {}.", String.join(",",newMmFirms)));
         }
         return Fx.hashed(newMmFirms);
      }
   };

   private LockedSplashPane lockedSplash;
   private final SecBoardContext secBoardContext;
   private final XfeSession session;
   private final BooleanProperty noSecSelected = new SimpleBooleanProperty(false);
   private final BooleanProperty secHasNoMM = new SimpleBooleanProperty(true);
   private final ObjectProperty<StepArray> priceStepArrayProperty = new SimpleObjectProperty<>();
   private final ObjectProperty<StepArray> quantityStepArrayProperty = new SimpleObjectProperty<>();
}

