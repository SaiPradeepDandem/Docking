package xfe.icap.modules.iswaptrades;

import com.google.common.base.Strings;
import com.nomx.domain.types.AlertSound;
import com.nomx.domain.types.AlertsGroup;
import com.objsys.asn1j.runtime.Asn1Type;
import javafx.beans.InvalidationListener;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.stage.Screen;
import javafx.util.Callback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.AmpMarketTrade;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.icap.modules.rfq.RfqTradeRemainingStage;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.settings.SettingsData;
import xfe.icap.ui.Sounds;
import xfe.layout.LayoutManager;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.types.Trade;
import xfe.ui.notifications.ModalAlertModule;
import xstr.amp.AMP;
import xstr.session.*;
import xstr.types.TradeSide;
import xstr.util.*;
import xstr.util.concurrent.Future;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.SECONDS;

@Module.Autostart
public final class TradeNotificationsModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradeNotificationsModule.class);

   @Module.ModuleDependency
   public LayoutManager<Node> layoutManagerModule;
   @Module.ModuleDependency
   public TradesModule tradesModule;
   @Module.ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public ModalAlertModule modalAlertModule;
   @ModuleDependency
   public TradesFlashModule tradesFlashModule;

   private class TradesNumberLister implements ChangeListener<Number>{
      TradesNumberLister(TradeNotificationsStage tradeInfoPopup) {
         this.tradeInfoPopup = tradeInfoPopup;
      }

      @Override
      public void changed(
         ObservableValue<? extends Number> observableRowCount,
         Number oldRowCount,
         Number newRowCount) {
         int myNewRowCount = (Integer)newRowCount;
         int myOldRowCount = (Integer)oldRowCount;

         if (myNewRowCount != 0 || myNewRowCount > myOldRowCount) {
            boolean wasHidden = tradeInfoPopup.isIconified() || !tradeInfoPopup.isShowing();
            if (wasHidden) {
               logger.info("Showing Trade Popup window");
               positionPopup(tradeInfoPopup);
               logger.debug("****PRE SHOWING: After positioning****");
               tradeInfoPopup.setIconified(false);
               tradeInfoPopup.show();
            } else {
               logger.info("Trade Popup window to front");
            }
            tradeInfoPopup.toFront();
            if (wasHidden)
               logger.info("Showing Trade Popup window - Done");
         } else {
            logger.info("Hiding Trade Popup window");
            tradeInfoPopup.hide();
         }
      }
      final TradeNotificationsStage tradeInfoPopup;
   }

   private class openActionListener implements InvalidationListener {
      openActionListener(TradeNotificationsStage tradeInfoPopup) {
         this.tradeInfoPopup = tradeInfoPopup;
      }

      @Override
      public void invalidated(javafx.beans.Observable observable) {
         logger.debug("****PRE SHOWING: Before positioning****");

         positionPopup(tradeInfoPopup);

         logger.debug("****PRE SHOWING: After positioning****");

         tradeInfoPopup.toFront();
         tradeInfoPopup.setIconified(false);
         tradeInfoPopup.setIconified(false);
         tradeInfoPopup.show();
         tradeInfoPopup.show();
         logger.debug("****POST SHOWING****");
      }
      final TradeNotificationsStage tradeInfoPopup;
   }

   private static Node createNotification(TradeAlert r , String userId, TradeSide side, boolean isLoggonUserTrader) {
      TradeInfo info = new TradeInfo(r, userId,side,isLoggonUserTrader).init();
      String text = info.getText();
      String css = info.getCss();

      Node pane = TradeNotificationsStage.createNotification(text);
      pane.setId("xfe-trade-alert-header");
      pane.getStyleClass().add("xfe-trade-alert-header");

      if (css != null) {
         pane.getStyleClass().add(css);
      }

      return pane;
   }

   public static boolean isBrokerEntered(QueryReplyRow r, String userId,String firmid) {
      boolean rtn = false;
      if(userId.equals(r.getString(AmpTrade.buyTraderId)) || firmid.equals(r.getString(AmpTrade.buyFirmId))){
         rtn =  !Strings.isNullOrEmpty(r.getString(AmpTrade.buyIntroBrokerId)) || !Strings.isNullOrEmpty(r.getString(AmpTrade.buyOperatorId));
      }else if(userId.equals(r.getString(AmpTrade.sellTraderId)) || firmid.equals(r.getString(AmpTrade.sellFirmId))){
         rtn =  !Strings.isNullOrEmpty(r.getString(AmpTrade.sellIntroBrokerId)) || !Strings.isNullOrEmpty(r.getString(AmpTrade.sellOperatorId));
      }
      return rtn;
   }

   public void registerTradeAlertAction(Callback<Asn1Type, Boolean> action) {
      tradeIdActions.add(action);
      tracker.registerRollbackAction(() -> tradeIdActions.remove(action));
   }

   @Override
   public Future<Void> startModule() {
      tradeNotificationsStageProperty.addListener((observableStage, oldStage, newStage) -> {
         if (newStage != null && tradesFeed.get() != null) {
            newStage.show();
            newStage.hide();
         }
         if(oldStage!=null){
            oldStage.dispose();
         }
      });

      BooleanProperty showTradeWorkup = new SimpleBooleanProperty(true);
      BooleanBinding subTradeFeed = Bindings.or(showTradeAlerts, showTradeWorkup);
      playSoundProperty.bind(configurationModule.getData().tradeSoundProperty());
      showBrokerAlertProperty.bind(configurationModule.getData().showBrokerTradeProperty());
      configurationModule.getData().setOpenTradeNotificationProp(openTradeNotificationHandler);
      TradeWorkupStageFactory.init(layoutManagerModule,showTradeWorkup, xfeSessionModule,selectionContextModule.secBoardContext.get().spinQtyStepsProperty(), modalAlertModule);
      marketTradeFeed = xfeSessionModule.getUnderlyingSession().getFeedSource(AMP.qREQ("marketTradeReq"));
      tracker.registerRollbackAction(() -> {
         showTradeAlerts.unbind();
         showTradeAlerts.set(false);
         showTradeWorkup.unbind();
         showTradeWorkup.set(false);
      });
      tracker.bind(tradeNotificationsStageProperty, new ObjectBinding<TradeNotificationsStage>() {
         {
            bind(tradesFeed);
         }

         @Override
         protected TradeNotificationsStage computeValue() {
            if (tradesFeed.get() == null) {
               return null;
            }

            logger.debug("Creating Trade NotificationStage...");
            TradeNotificationsStage tradeInfoPopup = new TradeNotificationsStage(tradesFlashModule, configurationModule, layoutManagerModule, showTradeAlerts,showTradeWorkup, xfeSessionModule.getUnderlyingSession().getLoggedOnUserId(),logger) {{

               this.xProperty().addListener((observablePopupStage, oldPopupStage, newPopupStage) -> configurationModule.getData().tradeAlertsNotificationPosXProperty().set((Double)newPopupStage));
               this.yProperty().addListener((observablePopupStage, oldPopupStage, newPopupStage) -> configurationModule.getData().tradeAlertsNotificationPosYProperty().set((Double)newPopupStage));
            }};

            logger.debug("Creating Trade NotificationStage - Done");
            tracker.addListener(tradeInfoPopup.rowCountProperty(), new TradesNumberLister(tradeInfoPopup));
            tracker.addListener(openActionProperty, new openActionListener(tradeInfoPopup));

            tradeInfoPopup.onItemActionProperty().set(tradeIdEvent -> tradesModule.jumpToTradeById(tradeIdEvent.tradeId));

            InvalidationListener expireLis = observable -> {
               if (configurationModule.getData().tradeAlertPopupExpiryProperty().get()) {
                  Duration d = Duration.of(configurationModule.getData().tradeAlertPopupExpiryValueProperty().get(), SECONDS);
                  tradeInfoPopup.setExpiryDuration(d);
               }else{
                  tradeInfoPopup.setExpiryDuration(Duration.ZERO);
               }
            };

            tracker.addListener(configurationModule.getData().tradeAlertPopupExpiryProperty(), expireLis);
            tracker.addListener(configurationModule.getData().tradeAlertPopupExpiryValueProperty(), expireLis);
            expireLis.invalidated(null);

            tracker.registerRollbackAction(tradeInfoPopup::hide);

            return tradeInfoPopup;
         }
      });

      tracker.bind(showTradeAlerts, Bindings.equal(AlertsGroup.NONE, configurationModule.getData().tradeAlertsProperty()).not());
      tracker.bind(showTradeWorkup, configurationModule.getData().autoPopupWorkupProperty());
      subscribeToTradesFeed(subTradeFeed);

      //	if Settings/ShowTradeAlerts is set, we should poll, else don't
      ChangeListener<AlertsGroup> showTradesAlertsListener = (observable, oldValue, newValue) -> {
         if (newValue != null) {
            if (newValue != AlertsGroup.NONE) {
               //	visible
               startPolling();
            } else {
               //	not visible
               stopPolling();
            }
         }
      };
      tracker.addListenerAndTriggerChange(configurationModule.getData().tradeAlertsProperty(), showTradesAlertsListener);

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      dealtTradeNo.clear();
      tracker.rollback();
      marketTradeFeed.removeListener(marketQueryFeedListener);
      configurationModule.getData().setOpenTradeNotificationProp(null);

      TradeNotificationsStage tradeNotificationsStage = tradeNotificationsStageProperty.get();

      if (tradeNotificationsStage != null) {
         tradeNotificationsStage.hide();
         tradeNotificationsStage.dispose();
      }

      TradeWorkupStageFactory.uninitialize();
      RfqTradeRemainingStage.closeAll();
      TradesFilters.dispose();
      return Future.SUCCESS;
   }



   // To reduce the time it takes to show the popup stage for the first time
   // we try to create it up-front so that all the classes are loaded and all the
   // window resources are created.

   private void subscribeToTradesFeed(ObservableBooleanValue subTradeFeed) {
      TradesFilters filters = new TradesFilters(xfeSessionModule);
      String userId = xfeSessionModule.getUnderlyingSession().getLoggedOnUserId();
      String firmId = xfeSessionModule.getUnderlyingSession().getLoggedOnUserFirmId();
      ReadOnlyObjectProperty<AlertsGroup> alertsGroup = configurationModule.getData().tradeAlertsProperty();
      ReadOnlyBooleanProperty alertsShowLegs = configurationModule.getData().alertsShowLegsProperty();

      Require.noNulls(userId, alertsGroup, tradeNotificationsStageProperty);

      queryFeedListener = ev -> {
         List<QueryRowEvent> rowEvents = ev.stream().filter(QueryRowEvent::hasRow).collect(Collectors.toList());
         if (rowEvents.isEmpty()) return;

         if (logger.isInfoEnabled()) {
            rowEvents.forEach(rev -> logger.info("Trade received: {} with row timestamp {}", AmpTrade.toShortString(rev.getRow()), rev.getTimeStamp().orElse(null)));
         }

         Fx.runLater(() -> {
            logger.info("Processing {} tradeReq events", rowEvents.size());
            Date connectedTime = xfeSessionModule.getUnderlyingSession().getConnectTime();
            logger.debug("Processing Alert Event. logon time is " + connectedTime);
            rowEvents.forEach(rev -> {
               boolean playSound = false;
               XtrQueryReplyCommand eventType = rev.getEventType();

               if (eventType != XtrQueryReplyCommand.CREATE && eventType != XtrQueryReplyCommand.UPDATE) {
                  logger.info("{} notification skipped: Not Update or create event", AmpTrade.abbreviate(rev.getOldRow()));
                  return;
               }

               boolean isNewTradeEvent = eventType == XtrQueryReplyCommand.CREATE;
               QueryReplyRow r = rev.getNewRow();
               String tradeInfo = AmpTrade.abbreviate(r);

               Date tradeTime = r.getValue(AmpTrade.time);
               //final XtrTime workupExpTime = r.getValue(AmpTrade.workupExpTime);
               int intStatus = r.getValue(AmpTrade.status);
               logger.debug("{} eventType is {} tradeTime is {} logon Time is {} status is {}",
                  tradeInfo, eventType, tradeTime.getTime(), connectedTime, intStatus);
               //final Date workupExpTimestamp = workupExpTime==null? null : workupExpTime.convert2TETimestamp(xfeSessionModule.getUnderlyingSession().getStats().getEngineTime());

                     /*if( (workupExpTimestamp == null && tradeTime.before(connectedTime)) || (workupExpTimestamp != null && workupExpTimestamp.before(connectedTime) && AmpTradeStatus_v2.workup != intStatus) ){
                        logger.debug("eventType is " + eventType +
                                " tradeTime is " + tradeTime.getTime() +
                                " logonTimpStamp " + connectedTime.getTime() +
                                " workupExpTime is " + workupExpTime +
                                " workupExpTimestamp " + workupExpTimestamp +
                                " status is " + intStatus +
                                " NOT POPPING UP ALERT");
                        continue;
                     }*/
               if (xfeSessionModule.getUnderlyingSession().isLoggedOnTrader()) {
                  if (!showBrokerAlertProperty.get() && isBrokerEntered(r, userId, firmId)) {
                     logger.info("{} notification skipped: broker entered", tradeInfo);
                     return;
                  }

                  boolean isMyFirmTrade = TradesFilters.isMyFirmTrade(firmId, r);
                  if (alertsGroup.get() == AlertsGroup.DESK && !isMyFirmTrade) {
                     logger.info("{} notification skipped: AlertGroup is DESK and trade is not from my firm", tradeInfo);
                     return;
                  }
               } else {
                  if (alertsGroup.get() == AlertsGroup.DESK) {
                     logger.info("{} notification skipped: AlertGroup is DESK", tradeInfo);
                     return;
                  }

                  String userId1 = xfeSessionModule.getUnderlyingSession().getLoggedOnUserId();
                  if (xfeSessionModule.getUnderlyingSession().isLoggedOnUserIB()) {
                     String IBSellId = r.getString(AmpTrade.sellIntroBrokerId);
                     String IBBuyId = r.getString(AmpTrade.buyIntroBrokerId);
                     if (!Objects.equals(userId1, IBSellId) &&
                        !Objects.equals(userId1, IBBuyId)) {
                        logger.info("{} notification skipped: User is IB but trade does not have matching buy/sell IB (buyIB:{}/sellIB:{})",
                           tradeInfo,
                           IBSellId == null ? "NULL" : IBSellId,
                           IBBuyId == null ? "NULL" : IBBuyId);
                        return;
                     }
                  } else {
                     String brokerSellId = r.getString(AmpTrade.sellOperatorId);
                     String brokerBuyId = r.getString(AmpTrade.buyOperatorId);
                     if (!Objects.equals(userId1, brokerSellId) &&
                        !Objects.equals(userId1, brokerBuyId)) {
                        logger.info("{} notification skipped: User is a broker but trade does not have matching buy/sell broker (buy:{}/sell:{})",
                           tradeInfo,
                           brokerSellId == null ? "NULL" : brokerSellId,
                           brokerBuyId == null ? "NULL" : brokerBuyId);
                        return;
                     }
                  }
               }

               boolean isLeg = TradesFilters.isLeg.accept(r);
               // Skipping legs if they are not shown
               if (isLeg && !alertsShowLegs.get()) {
                  logger.info("{} notification skipped: leg trade", tradeInfo);
                  return;
               }
               // Skipping manual trades
               if (!filters.isAuto.accept(r)) {
                  logger.info("{} notification skipped: Not Auto Trade", tradeInfo);
                  return;
               }

               boolean isMyTrade = TradesFilters.isMyTrade(userId, r);
               if (alertsGroup.get() == AlertsGroup.MINE && !isMyTrade) {
                  logger.info("{} notification skipped: AlertGroup is MINE and trade is not mine", tradeInfo);
                  return;
               }
               String tradeNo = r.getString(AmpTrade.tradeNo);
               if (dealtTradeNo.contains(tradeNo) && isNewTradeEvent) {
                  logger.info("{} notification skipped: already processed", tradeInfo);
                  return;
               }
               TradeSide side = TradesFilters.getTradeSide(r);
               if (side == null) {
                  logger.warn("{} notification skipped: Trade Side is null", tradeInfo);
                  return;
               }

               logger.info("{} generating notification", tradeInfo);

               if (isNewTradeEvent) {
                  dealtTradeNo.add(tradeNo);
                  playSound = TradeNotificationsModule.this.playSoundProperty.get() &&  showTradeAlerts.get() && tradeTime.after(connectedTime);
               }

               // Play alert for every new trade
               if(playSound) {
                  logger.info("{} Playing trade alert sound...", tradeInfo);
                  if (isMyTrade) {
                     AlertSound alertSound = configurationModule.getData().alertSoundForMineProperty().get();
                     String resourceLocation = alertSound!=null ? alertSound.getFile() : null;
                     if (resourceLocation != null) {
                        new Sounds(resourceLocation).play();
                     }
                  } else {
                     AlertSound alertSound = configurationModule.getData().alertSoundForAllProperty().get();
                     String resourceLocation = alertSound!=null ? alertSound.getFile() : null;
                     if (resourceLocation != null) {
                        new Sounds(resourceLocation).play();
                     }
                  }
                  logger.info("{} Playing trade alert sound - Done", tradeInfo);
               }


               String strStatus = TradesFilters.getStatus(r);
               logger.debug("Side: " + side + " Status: " + strStatus);
               logger.debug("{} ****Trade Alert Added****", tradeInfo);
               String rateStr = r.getString(AmpTrade.price);
               String spreadoverBP = r.getString(AmpTrade.spreadoverBP);
               String secCode = r.getValue(AmpTrade.secCode);
               String boardId = r.getValue(AmpTrade.boardId);
               Trade trade = new Trade(r);
               if (rateStr != null && xfeSessionModule.secBoards.get().isUsBond(secCode,boardId)) {
                  try {
                     rateStr = Util.convertToUsBondPrice(Double.parseDouble(rateStr));
                  } catch (NumberFormatException e) {
                     logger.error("{} can't parse rate from {}", tradeInfo, rateStr);
                     rateStr = "N/A";
                  }
               } else if (trade != null && spreadoverBP != null && trade.isSO_orManualSOFC()) {
                  rateStr = spreadoverBP;
               }
               TradeAlert alert = new TradeAlert(r.getAsn(AmpTrade.tradeId), r.getKey(),secCode, side,
                  r.getValue(AmpTrade.buyFirmId), r.getValue(AmpTrade.sellFirmId),
                  r.getString(AmpTrade.buyIntroBrokerId),r.getString(AmpTrade.buyOperatorId),r.getString(AmpTrade.sellIntroBrokerId),r.getString(AmpTrade.sellOperatorId),
                  //r.getValue(AmpTrade.buyBrokerId), r.getValue(AmpTrade.sellBrokerId),
                  r.getValue(AmpTrade.buyTraderId), r.getValue(AmpTrade.sellTraderId),
                  r.getValue(AmpTrade.buyAccountName), r.getValue(AmpTrade.sellAccountName),
                  r.getValue(AmpTrade.quantity_d),
                  null/*r.getValue(AmpTrade.sellWorkupQuantity)*/,
                  null/*r.getValue(AmpTrade.buyWorkupQuantity)*/,
                  strStatus, rateStr,
                  isLeg, null/*workupExpTimestamp*/,tradeTime, xfeSessionModule.getUnderlyingSession().isLoggedOnUserBroker(), xfeSessionModule.getUnderlyingSession().isLoggedOnUserIB());
               logger.debug("{} ****Trade Alert Created **** {}", tradeInfo, alert);
               if (userId.equals(alert.sellTraderId) || userId.equals(alert.buyTraderId)) //for mantis:0062799
                  TradeWorkupStageFactory.add(isNewTradeEvent, alert);
               if(showTradeAlerts.get()) tradeNotificationsStageProperty.get().addAlerts(alert, isNewTradeEvent, r.getAsn(AmpTrade.buyStrategyTradeId), r.getAsn(AmpTrade.sellStrategyTradeId));
               logger.debug("{} ****BEFORE createNotification****", tradeInfo);
               if (isNewTradeEvent && tradeTime.after(connectedTime) && !TradesFilters.isLeg.accept(r))
                  tradeNotificationsStageProperty.get().addNotification(createNotification(alert, userId,side, xfeSessionModule.getUnderlyingSession().isLoggedOnTrader()));
               logger.debug("{} ****AFTER createNotification****", tradeInfo);
            });
         });
      };

      marketQueryFeedListener = ev -> {
         List<QueryRowEvent> rowEvents = ev.stream().filter(QueryRowEvent::hasRow).collect(Collectors.toList());
         if (rowEvents.isEmpty()) return;

         if (AlertsGroup.MINE.equals(alertsGroup.get())) {
            logger.info("MktTrade notifications skipped: Alert group is MINE");
            return;
         }

         if (AlertsGroup.DESK.equals(alertsGroup.get()) && (!showBrokerAlertProperty.get())) {
            // presently showBrokerAlert is always false for DESK option
            logger.info("MktTrade notifications skipped: Alert group is DESK and user is broker");
            return;
         }

         if (logger.isInfoEnabled()) {
            rowEvents.forEach(rev -> logger.info("MktTrade received: {} with row timestamp {}", AmpMarketTrade.toShortString(rev.getNewRow()), rev.getNewRow().getTimestamp()));
         }

         Fx.runLater(() -> {
            Date connectedTime = xfeSessionModule.getUnderlyingSession().getConnectTime();
            logger.debug("Processing Alert Event. logon time is " + connectedTime);
            rowEvents.forEach(rev -> {
               XtrQueryReplyCommand eventType = rev.getEventType();

               if (eventType != XtrQueryReplyCommand.CREATE && eventType != XtrQueryReplyCommand.UPDATE) {
                  logger.info("{} notification skipped: Not Update or create event", AmpMarketTrade.abbreviate(rev.getOldRow()));
                  return;
               }

               boolean isNewTradeEvent = eventType == XtrQueryReplyCommand.CREATE;
               QueryReplyRow r = rev.getNewRow();
               String tradeInfo = AmpTrade.abbreviate(r);

               Date tradeTime = r.getValue(AmpMarketTrade.tradeTime);
               int intStatus = r.getValue(AmpMarketTrade.status);
               logger.debug("eventType is " + eventType + " tradeTime is " + tradeTime.getTime() + " logon Time is " + connectedTime + " status is " + intStatus);

               // TODO: if we need to support broker trades checkbox option for DESK
               // then we need to find out how to detect such trades
               // isMyFirmMarketTrade then needs to change to detect it properly
               boolean isMyFirmTrade = TradesFilters.isMyFirmMarketTrade(firmId, r);
               if (AlertsGroup.DESK.equals(alertsGroup.get()) && !isMyFirmTrade) {
                  logger.info("{} notification skipped: AlertGroup is DESK and trade is not from my firm", tradeInfo);
                  return;
               }

               if (tradeTime.before(connectedTime)) {
                  logger.info("{} notification skipped: Trade predates logon", tradeInfo);
                  return;
               }

               boolean isLeg = TradesFilters.isLeg.accept(r);
               // Skipping legs if they are not shown
               if (isLeg && !alertsShowLegs.get()) {
                  logger.info("{} notification skipped: leg trade", tradeInfo);
                  return;
               }

               Fx.delay(1000L, ()-> {
                  String tradeNo = r.getString(AmpMarketTrade.tradeNo);
                  if(dealtTradeNo.contains(tradeNo)){
                     logger.info("{} notification skipped: already processed", tradeInfo);
                     return;
                  }

                  dealtTradeNo.add(tradeNo);
                  logger.info("{} generating notification", tradeInfo);

                  if (playSoundProperty.get() && showTradeAlerts.get() && isNewTradeEvent) {
                     AlertSound alertSound = configurationModule.getData().alertSoundForAllProperty().get();
                     String resourceLocation = alertSound != null ? alertSound.getFile() : null;
                     if (resourceLocation != null) {
                        new Sounds(resourceLocation).play();
                     }
                  }
                  logger.debug("Adding Trade Alert from Market Trades - trade time is {}", tradeTime);
                  String rateStr = r.getString(AmpMarketTrade.price);
                  String secCode = r.getValue(AmpMarketTrade.secCode);
                  String boardId = r.getValue(AmpMarketTrade.boardId);
                  if (rateStr != null && xfeSessionModule.secBoards.get().isUsBond(secCode, boardId)) {
                     try {
                        rateStr = Util.convertToUsBondPrice(Double.parseDouble(rateStr));
                     } catch (NumberFormatException e) {
                        logger.error("can't parse rate from {}", rateStr);
                        rateStr = "N/A";
                     }
                  }
                  String strStatus = TradesColumns.tradeStatusConverter.toString(intStatus);
                  TradeAlert alert = new TradeAlert(r.getAsn(AmpMarketTrade.tradeId), r.getKey(), secCode, null,
                     "", "",
                     "", "", "", "",
                     //r.getValue(AmpTrade.buyBrokerId), r.getValue(AmpTrade.sellBrokerId),
                     null, null,
                     "", "",
                     r.getValue(AmpMarketTrade.quantity),
                     null/*r.getValue(AmpTrade.sellWorkupQuantity)*/,
                     null/*r.getValue(AmpTrade.buyWorkupQuantity)*/,
                     strStatus, rateStr,
                     isLeg, null/*workupExpTimestamp*/, tradeTime, false, false);
                  if (showTradeAlerts.get())
                     tradeNotificationsStageProperty.get().addAlerts(alert, isNewTradeEvent, null, null);

                  if (isNewTradeEvent && !isLeg) {
                     logger.debug("Creating Trade Notification");
                     tradeNotificationsStageProperty.get().addNotification(createNotification(alert, userId, null, xfeSessionModule.getUnderlyingSession().isLoggedOnTrader()));
                  } else {
                     logger.info("{} Not creating Trade Notification. isNewTradeEvent: {}, tradeTime: {}, connectedTime: {}, isLeg: {}", tradeInfo, isNewTradeEvent, tradeTime, connectedTime, isLeg);
                  }
               });

            });
            logger.debug("Processing Alert Event - Done");
         });
      };

      tracker.addListener(tradesFeed, (observable, oldFeed, newFeed) -> {
         if (oldFeed != null) {
            oldFeed.removeListener(queryFeedListener);
         }

         if (newFeed != null && showTradeAlerts.get()) {
            newFeed.addListener(queryFeedListener);
         }
      });

      tracker.bind(tradesFeed, new ObjectBinding<QueryFeed> () {
         @Override
         protected QueryFeed computeValue() {
            return xfeSessionModule.getUnderlyingSession().getFeedSource(AMP.qREQ("tradeReq"));
         }
      });

      if (AlertsGroup.ALL.equals(configurationModule.getData().tradeAlertsProperty().get()) ||
         AlertsGroup.DESK.equals(configurationModule.getData().tradeAlertsProperty().get())) {
         marketTradeFeed.addListener(marketQueryFeedListener);
      }
      if (!xfeSessionModule.getUnderlyingSession().isLoggedOnTrader()) {
         tracker.addListener(configurationModule.getData().tradeAlertsProperty(), observable -> {
            if (AlertsGroup.ALL.equals(configurationModule.getData().tradeAlertsProperty().get()) ||
               AlertsGroup.DESK.equals(configurationModule.getData().tradeAlertsProperty().get())) {
               marketTradeFeed.addListener(marketQueryFeedListener);
            } else {
               marketTradeFeed.removeListener(marketQueryFeedListener);
            }
         });
      }

      tracker.registerRollbackAction(() -> {
         tradesFeed.unbind();
         tradesFeed.set(null);
      });
   }

   private void startPolling() {
      tradesFeed.get().addListener(queryFeedListener);
   }

   private void stopPolling() {
      tradesFeed.get().removeListener(queryFeedListener);
   }

   private void positionPopup(TradeNotificationsStage tradeInfoPopup) {
      SettingsData settingsData = configurationModule.getData();

      if (settingsData.tradeAlertsNotificationPosXProperty().get() == -1.0 &&
         settingsData.tradeAlertsNotificationPosYProperty().get() == -1.0) {

         settingsData.tradeAlertsNotificationPosXProperty().set(tradeInfoPopup.getX());
         settingsData.tradeAlertsNotificationPosYProperty().set(tradeInfoPopup.getY());
      } else {
         tradeInfoPopup.setX(settingsData.tradeAlertsNotificationPosXProperty().get());
         tradeInfoPopup.setY(settingsData.tradeAlertsNotificationPosYProperty().get());
      }

      double x = tradeInfoPopup.getX();
      double y = tradeInfoPopup.getY();
      double w = tradeInfoPopup.getWidth();
      double h = tradeInfoPopup.getHeight();
      boolean alertInBounds = false;
      double newX = x;
      double newY = y;

      for (Screen screen: Screen.getScreens()) {
         Rectangle2D screeBounds = screen.getBounds();
         if (screeBounds.contains(x, y, w, h)) {
            alertInBounds = true;
         }

         if (screeBounds.getMinX() == 0. && screeBounds.getMinY() == 0.0) {
            newX = (screeBounds.getWidth() - w) / 2.;
            newY = (screeBounds.getHeight() - h) / 2.;
         }
      }

      // If popup not in bounds of any of the screens we move it to center of main screen
      if (!alertInBounds) {
         tradeInfoPopup.setX(newX);
         tradeInfoPopup.setY(newY);
         settingsData.tradeAlertsNotificationPosXProperty().set(newX);
         settingsData.tradeAlertsNotificationPosYProperty().set(newY);
         logger.info("Positioned at + (" + tradeInfoPopup.getX() + "," + tradeInfoPopup.getY() + ")");
      } else {
         logger.debug("Positioned at + (" + tradeInfoPopup.getX() + "," + tradeInfoPopup.getY() + ")");
      }
   }
   private final ObjectProperty<TradeNotificationsStage> tradeNotificationsStageProperty = new SimpleObjectProperty<>();
   private final ListenerTracker tracker = new ListenerTracker();
   private final LinkedHashSet<Callback<Asn1Type, Boolean>> tradeIdActions = new LinkedHashSet<>();
   private final BooleanProperty showTradeAlerts = new SimpleBooleanProperty(true);
   private final ObjectProperty<QueryFeed> tradesFeed = new SimpleObjectProperty<>();
   private final BooleanProperty openActionProperty = new SimpleBooleanProperty(true);
   private final EventHandler<ActionEvent> openTradeNotificationHandler = event -> openActionProperty.set(!openActionProperty.get());
   private final HashSet<String> dealtTradeNo = new HashSet<>(1052);
   private final BooleanProperty playSoundProperty = new SimpleBooleanProperty(this, "playSound", true);
   private final BooleanProperty showBrokerAlertProperty = new SimpleBooleanProperty(this, "showBrokerAlert", true);
   private QueryFeed marketTradeFeed ;
   private QueryFeedListener queryFeedListener;
   private QueryFeedListener marketQueryFeedListener;
}
