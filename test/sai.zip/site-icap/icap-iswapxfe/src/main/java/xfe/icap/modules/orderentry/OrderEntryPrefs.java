package xfe.icap.modules.orderentry;

import com.nomx.domain.types.AmountType;
import com.nomx.domain.types.DefaultDurationType;
import com.nomx.domain.types.OnLogoffAction;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import xstr.util.ListenerTracker;
import xfe.icap.modules.settings.SettingsData;

public class OrderEntryPrefs {

   public void bind(SettingsData settings, ListenerTracker tracker) {
      tracker.bind(managed, settings.managedOrdersProperty());
      tracker.bind(clone2RFS, settings.clone2RFSProperty());
      tracker.bind(shared, settings.sharedOrdersProperty());
      tracker.bind(anon, settings.anonOrdersProperty());
      tracker.bind(rfqInitiatorOrderAon, settings.rfqInitiatorOrderAon());
      tracker.bind(yoursMineDefaultAmount, Bindings.when(Bindings.equal(AmountType.DEFAULT, settings.yoursMineDefaultAmountProperty())).then(true).otherwise(false));
      tracker.bind(yoursMineOrderWithdraw, settings.yoursMineOrderWithdrawProperty());
      tracker.bind(yoursMineLitDelay, settings.yoursMineLitDelayProperty());
      tracker.bind(marketSize, settings.marketSizeOnOrderEnterProperty());
      tracker.bind(strategyDefaultQty, settings.strategyDefaultQtyProperty());
      tracker.bind(outrightDefaultQty, settings.outrightDefaultQtyProperty());
      tracker.bind(qty1, settings.leftQtyBtnProperty());
      tracker.bind(qty2, settings.middleQtyBtnProperty());
      tracker.bind(qty3, settings.rightQtyBtnProperty());
      tracker.bind(defaultDurationType, settings.defaultDurationTypeProperty());
      tracker.bind(defaultDuration, settings.defaultDurationProperty());
      tracker.bind(onLogoffAction, settings.onLogoffActionProperty());
   }

   public BooleanProperty shared() {
      return shared;
   }

   public BooleanProperty managed() {
      return managed;
   }

   public BooleanProperty clone2RFS() {
      return clone2RFS;
   }

   public BooleanProperty anon() {
      return anon;
   }

   public BooleanProperty rfqInitiatorOrderAon(){
      return rfqInitiatorOrderAon;
   }

   public DoubleProperty yoursMineLitDelay() {
      return yoursMineLitDelay;
   }

   public BooleanProperty yoursMineDefaultAmount() {
      return yoursMineDefaultAmount;
   }

   public BooleanProperty yoursMineOrderWithdraw() {
      return yoursMineOrderWithdraw;
   }

   public DoubleProperty strategyDefaultQty() {
      return strategyDefaultQty;
   }

   public DoubleProperty outrightDefaultQty() {
      return outrightDefaultQty;
   }

   public BooleanProperty isMarketSize(){
      return marketSize;
   }

   public DoubleProperty qty1() {
      return qty1;
   }

   public DoubleProperty qty2() {
      return qty2;
   }

   public DoubleProperty qty3() {
      return qty3;
   }

   public ObjectProperty<DefaultDurationType> defaultDurationType() {
      return defaultDurationType;
   }

   public ObjectProperty<OnLogoffAction> onLogoffAction() {
      return onLogoffAction;
   }

   public IntegerProperty defaultDuration() {
      return defaultDuration;
   }
   private final BooleanProperty managed = new SimpleBooleanProperty(this, "managedOrder", true);
   private final BooleanProperty clone2RFS = new SimpleBooleanProperty(this,"clone2RFS",false);
   private final BooleanProperty shared = new SimpleBooleanProperty(this, "shared", true);
   private final BooleanProperty anon = new SimpleBooleanProperty(this, "anon", true);
   private final BooleanProperty rfqInitiatorOrderAon = new SimpleBooleanProperty(this, "rfqInitiatorOrderAon", true);
   private final BooleanProperty yoursMineDefaultAmount = new SimpleBooleanProperty(this, "yoursMineDefaultAmount", true);
   private final BooleanProperty yoursMineOrderWithdraw = new SimpleBooleanProperty(this, "yoursMineOrderWithdraw", true);
   private final DoubleProperty yoursMineLitDelay = new SimpleDoubleProperty(this, "yoursMineLitDelay", 0.5);
   private final DoubleProperty strategyDefaultQty = new SimpleDoubleProperty(this, "strategyDefaultQty", 25.0);
   private final DoubleProperty outrightDefaultQty = new SimpleDoubleProperty(this, "outrightDefaultQty", 25.0);
   private final BooleanProperty marketSize = new SimpleBooleanProperty(this,"martketSize",false);
   private final DoubleProperty qty1 = new SimpleDoubleProperty(this, "qty1", 25.0);
   private final DoubleProperty qty2 = new SimpleDoubleProperty(this, "qty2", 50.0);
   private final DoubleProperty qty3 = new SimpleDoubleProperty(this, "qty3", 100.0);
   private final ObjectProperty<DefaultDurationType> defaultDurationType = new SimpleObjectProperty<DefaultDurationType>(DefaultDurationType.GOOD_TILL_DAY);
   private final IntegerProperty defaultDuration = new SimpleIntegerProperty(5);
   private final ObjectProperty<OnLogoffAction> onLogoffAction = new SimpleObjectProperty<OnLogoffAction>(OnLogoffAction.REFER);

}
