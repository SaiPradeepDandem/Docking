package xfe.icap.amp;

import xstr.amp.acc.AmpAccessor;
import xstr.amp.AMP;
import xstr.amp.AMP.AmpQrep;
import xstr.amp.AMP.AmpQreq;
import xstr.amp.AsnConversionAccessor;

import java.util.Date;

public class AmpRfqTrade extends AmpAccessor {
    public static final AmpQreq req = AMP.qREQ("rfqTradeReq");
    public static final AmpQrep rep = AMP.qREP("rfqTradeRep");

    public static final AsnConversionAccessor<Long> rfqNo = acc(AMP.qREP("rfqTradeRep.rfqId.rfqNo"), Long.class);
    public static final AsnConversionAccessor<Date> tradeTime = acc(AMP.qREP("rfqTradeRep.tradeTime"), Date.class);
    public static final AsnConversionAccessor<Integer> initiatorOrderVerb = acc(AMP.qREP("rfqTradeRep.initiatorOrderVerb"), Integer.class);
    public static final AsnConversionAccessor<Double> coverPrice = acc(AMP.qREP("rfqTradeRep.coverPrice"), Double.class);
    public static final AsnConversionAccessor<Integer> priceIndicator = acc(AMP.qREP("rfqTradeRep.priceIndicator"), Integer.class);
}
