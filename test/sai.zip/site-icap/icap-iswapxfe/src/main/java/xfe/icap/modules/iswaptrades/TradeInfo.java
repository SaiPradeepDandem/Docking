package xfe.icap.modules.iswaptrades;

import com.google.common.base.Strings;
import xstr.types.TradeSide;
import java.text.DecimalFormat;

class TradeInfo {
   private final boolean isLoggonUserTrader;
   private static final DecimalFormat formtter = new DecimalFormat("#.#");

   private final TradeAlert r;
   private final String userId;
   private String text;
   private String css;
   private final TradeSide side;

   TradeInfo(TradeAlert r, String userId, TradeSide side, boolean isLoggonUserTrader) {
      this.r = r;
      this.userId = userId;
      this.side = side;
      this.isLoggonUserTrader = isLoggonUserTrader;
   }

   public String getText() {
      return text;
   }

   public String getCss() {
      return css;
   }

   public TradeSide getSide() {
      return side;
   }

   public TradeInfo init() {
      String buyFirmId = r.buyFirmId;
      String sellFirmId = r.sellFirmId;
      String quantity = formtter.format(r.amount.get());
      String secCode = r.secCode;
      String price = r.rate;
      String buyTraderId = r.buyTraderId;
      String sellTraderId = r.sellTraderId;
      String enteredByBroker = Strings.isNullOrEmpty(r.getBrokerId()) ? "" : " (Broker-Entered)";
      if (side == null) {
         text = String.format("%s at %s in %sM", secCode, price,quantity );
         css = "neutral";
      } else switch (side) {
         case BUY:
            css = "pay";
            String payer = "";
            if (isLoggonUserTrader) {
               if (userId.equals(buyTraderId)) {
                  payer = "You ";
               } else if (buyTraderId != null) {
                  payer = buyTraderId + " ";
               } else if (buyFirmId != null) {
                  payer = buyFirmId + " ";
               }
            } else {
               payer = (buyFirmId == null ? "" : buyFirmId) + " ";
            }
            if (sellFirmId == null) {
               sellFirmId = "";
            } else {
               sellFirmId = " to " + sellFirmId;
            }
            text = String.format("%sPayed %sM %s%s at %s%s", payer, quantity, secCode, sellFirmId, price, enteredByBroker);
            break;
         case SELL:
            css = "rec";
            String receiver = "";
            if (isLoggonUserTrader) {
               if (userId.equals(sellTraderId)) {
                  receiver = "You ";
               } else if (sellTraderId != null) {
                  receiver = sellTraderId + " ";
               } else if (sellFirmId != null) {
                  receiver = sellFirmId + " ";
               }
            } else {
               receiver = (sellFirmId == null ? "" : sellFirmId) + " ";
            }
            if (buyFirmId == null) {
               buyFirmId = "";
            } else {
               buyFirmId = " from " + buyFirmId;
            }
            text = String.format("%sReceived %sM %s%s at %s%s", receiver, quantity, secCode, buyFirmId, price, enteredByBroker);
            break;
         case CROSS:
            css = null;
            text = String.format("%s Received %sM %s from %s at %s%s", sellFirmId, quantity, secCode, buyFirmId, price, enteredByBroker);
      }
      return this;
   }
}
