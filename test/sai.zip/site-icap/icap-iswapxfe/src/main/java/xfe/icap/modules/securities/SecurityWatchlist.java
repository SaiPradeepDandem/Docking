package xfe.icap.modules.securities;

import com.nomx.persist.watchlist.HeadingSpec;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.nomx.persist.watchlist.WatchlistSpec_v2.Security;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.types.SecBoard;
import xfe.types.SecBoards;
import xstr.amp.AMP;
import xstr.session.*;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xstr.util.FeedAggregator;

import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class SecurityWatchlist {
   private static final Logger logger = LoggerFactory.getLogger(SecurityWatchlist.class);

   private ListChangeListener<ObservableReplyRow> aggregatorListener = c -> {
      while (c.next()) {
         if (c.wasAdded()) {
            c.getAddedSubList().forEach(row -> this.secBoards.updateStaticInfo(row));
         }
      }
      // handling added/ updated events
      // After stop polling, do not handling received reply
      if (this.feedSrc != null && !this.aggregator.isBusyUpdating()) {
         handleAddItems(c.getList());
         /* Updates the price change flags in the watch list row */
         updatePriceChangeFlags();
      }
   };

   SecurityWatchlist(SecBoards secboards, ServerSession session, String parentModule) {
      // This is temporary usage for the diagnosis logs about WU issues. After fixing issue, need to rollback
      aggregator = new FeedAggregator<>(AmpIcapSecBoardTrim2.rep, new ObservableRowFactory(), parentModule);
      this.parentModule = parentModule;
      this.secBoards = secboards;
      this.session = session;
      items = FXCollections.observableArrayList();

      aggregator.items.addListener(aggregatorListener);

      displayedItems.addListener((ListChangeListener<WatchlistRow>) c -> {
         while (c.next()) {
            if (c.wasRemoved()) {
               c.getRemoved().stream().filter(row -> !row.isHeading()).forEach(row -> items.remove(row.getRow()));
            } else if (c.wasAdded()) {
               c.getAddedSubList().stream().filter(row -> !row.isHeading()).forEach(row -> items.add(row.getRow()));
            }
         }
      });
   }

   private void handleAddItems(List<? extends ObservableReplyRow> aggregatorRows) {
      updateMirrorList(aggregatorRows);

      // For trigger refresh of TableView, displayedItems only change when replies are happened
      List<WatchlistRow> filteredList = mirrorList.stream().filter(wr -> wr.isHeading() || wr.isExpanded()).collect(Collectors.toList());

      // First handle about all rows that were removed
      List<WatchlistRow> removedRows = new ArrayList<>();
      displayedItems.forEach(row -> {
         if (!filteredList.contains(row)) {
            removedRows.add(row);
         }
      });

      if (!removedRows.isEmpty())
         displayedItems.removeAll(removedRows);

      // Then handle about all rows that were added
      if (displayedItems.isEmpty()) {
         displayedItems.addAll(filteredList);
      } else {
         filteredList.forEach( wr -> {
            if (!displayedItems.contains(wr)) {
               int index = filteredList.indexOf(wr);
               displayedItems.add(index, wr);
            }
         });
      }
   }

   private void updateMirrorList(List<? extends ObservableReplyRow> aggregatorRows) {
      List<String> mirrorSecs = mirrorList.stream().filter(WatchlistRow::isNotHeading).map(wr -> wr.getRow().getValue(AmpIcapSecBoardTrim2.secCode)).collect(Collectors.toList());
      // Do nothing for update events only
      if (queriedSecBoards.size() == mirrorSecs.size()) return;

      List<String> mirrorHeadings = mirrorList.stream().filter(WatchlistRow::isHeading).map(WatchlistRow::getHeading).collect(Collectors.toList());
      Map<String, ObservableReplyRow> secCodesToRows =
         aggregatorRows.stream().collect(Collectors.toMap(row -> row.getValue(AmpIcapSecBoardTrim2.secCode), Function.identity(),(row1,row2) -> row2));
      List<String> sortRule = new ArrayList<>();
      Security currentHeading = null;
      for (Security sec : specProperty.get().securities) {
         if (sec.isHeading() && (currentHeading == null || !Objects.equals(sec.getHeadingName(), currentHeading.getHeadingName()))) {
            // This is only for Actives tab about header rows
            currentHeading = sec;
            sortRule.add(sec.getHeadingName());
         } else {
            String secCode = sec.getSecCode();
            ObservableReplyRow row = secCodesToRows.get(secCode);
            if (row != null) {
               if (currentHeading == null) {
                  // This process is only for common sec tabs and TradesWorkupView.
                  // For TradesWorkupView, spec also dynamically changed but no header row
                  // so need to check secCode for preventing to add duplicate row.
                  sortRule.add(secCode);
                  if (!mirrorSecs.contains(secCode)) {
                     mirrorList.add(new WatchlistRow(row, secCode));
                  }
               } else {
                  // This is only for Actives tab about secBoard rows
                  String headingName = sec.getProductId();
                  String rowKey = headingName + ":" + secCode;
                  sortRule.add(rowKey);
                  // Add heading row if cannot find from mirrorList
                  if (!mirrorHeadings.contains(headingName)) {
                     int countHeading = Collections.frequency(mirrorHeadings, headingName);
                     mirrorList.add(new WatchlistRow(currentHeading.getHeadingName(), countHeading, currentHeading.isExpanded(), headingName));
                     mirrorHeadings.add(headingName);
                  }
                  // Add secboard record row if cannot find mirrorList
                  if (!mirrorSecs.contains(secCode)) {
                     mirrorList.add(new WatchlistRow(row, currentHeading.isExpanded(), rowKey));
                  }
               }
            }
         }
      }

      mirrorList.sort(Comparator.comparing(wr -> sortRule.indexOf(wr.getRowKey())));
   }

   private void handleRemoveItems() {
      if (mirrorList.isEmpty()) return;

      long cntMirrorSecs = mirrorList.stream().filter(WatchlistRow::isNotHeading).count();
      if (queriedSecBoards.size() == cntMirrorSecs) return;

      List<String> queriedSecs = queriedSecBoards.stream().map(SecBoard::getSecCode).collect(Collectors.toList());
      List<WatchlistRow> removedRows = new ArrayList<>();
      mirrorList.forEach( wr -> {
         boolean bFind = false;
         String secCode = null;
         if (wr.isHeading()) {
            // Find matched heading name from specProperty's securities
            bFind = findHeadingInSpecProperty(wr.getHeading());
         } else {
            // Find matched secCode from queriedSecBoards
            secCode = wr.getRow().getValue(AmpIcapSecBoardTrim2.secCode);
            if (queriedSecs.contains(secCode))
               bFind = true;
         }
         // Remove the row that cannot find from specProperty's securities or queriedSecBoards
         // Also remove price history data from secCodePriceCacheMap
         if (!bFind) {
            removedRows.add(wr);
            if (secCode != null)
               secCodePriceCacheMap.remove(secCode);
         }
      });

      if (!removedRows.isEmpty()) {
         mirrorList.removeAll(removedRows);
      }
   }

   private void refreshDisplayedItems() {
      // Check SecurityWatchlist is used by Actives tab, otherwise do nothing.
      if (mirrorList.isEmpty() || mirrorList.stream().filter(WatchlistRow::isHeading).count() == 0) return;

      // This process is only for updating Expand and Collapse status
      List<String> expandHeadings = new ArrayList<>();
      // Check heading row's Expaned status from specProperty
      for (Security sec : specProperty.get().securities) {
         if (sec.isHeading() && sec.isExpanded()) {
            expandHeadings.add(sec.getHeadingName());
         }
      }

      // Update mirrorList's Expanded status
      mirrorList.forEach( wr -> {
         String headingName = (wr.isHeading())? wr.getHeading() : wr.getRowKey().substring(0, wr.getRowKey().indexOf(':'));
         wr.setExpanded(expandHeadings.contains(headingName));
         if (!wr.isHeading() && !wr.isExpanded() && displayedItems.contains(wr))
            displayedItems.remove(wr);
      });

      List<WatchlistRow> filteredList = mirrorList.stream().filter(wr -> wr.isHeading() || wr.isExpanded()).collect(Collectors.toList());
      filteredList.forEach( wr -> {
         if (!displayedItems.contains(wr)) {
            int index = filteredList.indexOf(wr);
            displayedItems.add(index, wr);
         }
      });
   }

   private boolean findHeadingInSpecProperty(String headingName) {
      for (Security sec : specProperty.get().securities) {
         if (sec.isHeading() && Objects.equals(headingName, sec.getHeadingName())) {
            return true;
         }
      }
      return false;
   }

   /**
    * Updates the price change flags in the WatchListRow and keeps a backup of the prices.
    */
   private void updatePriceChangeFlags() {
      // During processing the aggregatorListener, setSpec called and it made ConcurrentModificationException.
      // So copy mirrorList and use that one instead of directly use it.
      List<WatchlistRow> copyRow = new ArrayList<>(mirrorList);
      copyRow.forEach(watchListRow -> {
         if (watchListRow != null) {
            final ObservableReplyRow row = watchListRow.getRow();
            if (row != null) {
               final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
               final BigDecimal bidPrice = row.getValue(AmpIcapSecBoardTrim2.bidPrice);
               final BigDecimal matchPrice = row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
               final BigDecimal offerPrice = row.getValue(AmpIcapSecBoardTrim2.offerPrice);
               final BigDecimal prvlgdTrdngPrice = row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngPrice);
               final boolean isWorkupTrade = prvlgdTrdngPrice != null && matchPrice != null && prvlgdTrdngPrice.compareTo(matchPrice) == 0;
               WatchListSecCodePriceCache priceCache = secCodePriceCacheMap.get(secCode);
               if (priceCache == null) {
                  watchListRow.resetPriceFlags();
                  secCodePriceCacheMap.put(secCode, new WatchListSecCodePriceCache(bidPrice, matchPrice, offerPrice, isWorkupTrade));
                  watchListRow.setIsCMWorkupTraded(isWorkupTrade);
               } else {
                  if (isWorkupTrade)
                     priceCache.setIsCMWorkupTraded(true);
                  if (!isPriceEqual(bidPrice, priceCache.getBidPrice())) {
                     priceCache.setBidPrice(bidPrice);
                     watchListRow.setBidPriceChanged(true);
                  }
                  if (!isPriceEqual(matchPrice, priceCache.getMatchPrice())) {
                     if (priceCache.getMatchPrice() != null)
                        priceCache.setIsCMWorkupTraded(false);
                     priceCache.setMatchPrice(matchPrice);
                     watchListRow.setMatchPriceChanged(true);
                  }
                  if (!isPriceEqual(offerPrice, priceCache.getOfferPrice())) {
                     priceCache.setOfferPrice(offerPrice);
                     watchListRow.setOfferPriceChanged(true);
                  }
                  watchListRow.setIsCMWorkupTraded(priceCache.isCMWorkupTraded());
               }
            }
         }
      });
   }

   /**
    * Specifies if the provided two prices are equal or not.
    *
    * @param price1
    * @param price2
    * @return true/false
    */
   private boolean isPriceEqual(BigDecimal price1, BigDecimal price2) {
      if (price1 != null && price2 != null) {
         return price1.equals(price2);
      } else if ((price1 == null && price2 != null) || price1 != null) {
         return false;
      }
      return true;
   }

   private boolean isHeadingCollapseInSpec(String headingName) {
      HeadingSpec spec = headingSpecGetter.apply(headingName);
      return spec != null && spec.isCollapse();
   }

   private void updateHeadingCollapseInSpec(String headingName, boolean isCollapse) {
      HeadingSpec spec = headingSpecGetter.apply(headingName);
      if (spec != null && spec.isCollapse() != isCollapse) {
         spec.setCollapse(isCollapse);
      }
   }

   public WatchlistSpec_v2 getSpec() {
      return specProperty.get();
   }

   public ObjectProperty<WatchlistSpec_v2> specProperty() {
      return specProperty;
   }

   public void setSpec(WatchlistSpec_v2 spec) {
      setSpec(spec, true);
   }

   public void setSpec(WatchlistSpec_v2 spec, boolean autoStartPolling) {
      // Depend on autoStartPolling param, start polling or leave it for manual start
      // Common secboard tabs need the manual polling
      // but others, actives tab or workup dialog, need the auto polling so supports autoStartPolling input
      if (Objects.equals(specProperty.get(), spec))
         return;

      List<String> secCodes = Arrays.stream(spec.securities).filter(sec -> sec.getSecCode() != null).map(WatchlistSpec_v2.Security::getSecCode).collect(Collectors.toList());
      this.specProperty.setValue(spec);
      if (secCodes.isEmpty()) {
         stopPolling();
         mirrorList.clear();
         displayedItems.clear();
      } else if (this.secBoards != null) {
         this.secBoards
            .getAllBySecCode(secCodes)
            .map(
                secBoardList -> {
                  secBoardList.sort(Comparator.comparingLong(SecBoard::getIndex));
                  if (queriedSecBoards.equals(secBoardList) && feedSrc != null) {
                    refreshDisplayedItems();
                  } else {
                    stopPolling();
                    queriedSecBoards.clear();
                    queriedSecBoards.addAll(secBoardList);
                    handleRemoveItems();
                    if (autoStartPolling) startPolling();
                  }

                  return Future.SUCCESS;
                });
      }
   }

   public WatchlistSpec_v2 adjustHeadingsState(WatchlistSpec_v2 spec) {
      // In this method we are making sure that the new spec's expand/collapse headings that exist in its previous state
      // do not change their toggle state
      WatchlistSpec_v2 toggledSpec = spec;
      Integer headingNum;
      Map<String, Integer> headings = new HashMap<>();
      for (Security sec : spec.securities) {
         if (sec.isHeading()) {
            String headingName = sec.getHeadingName();
            headings.putIfAbsent(headingName, 0);
            headingNum = headings.get(headingName);
            headings.put(headingName, ++headingNum);
            if (!isHeadingCollapseInSpec(headingName) != sec.isExpanded()) {
               toggledSpec = toggledSpec.toggleExpandCollapse(headingName, headingNum - 1);
            }
         }
      }

      return toggledSpec;
   }

   public void startPolling() {
      if (aggregator == null) {
         logger.warn("{}::fail to startPolling()", parentModule);
         return;
      }

      // do not polling if queriedSecBoards is empty
      if (!session.isLoggedOn()) {
         return;
      }
      if (feedSrc == null && !queriedSecBoards.isEmpty()) {
         int size = queriedSecBoards.size();
         Long[] indices = new Long[size];
         for (int i = 0; i < size; i++) {
            indices[i] = queriedSecBoards.get(i).getIndex();
         }
         try {
            XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpIcapSecBoardTrim2.req, session)
               .set(AMP.qREQ("icapSecBoardTrim2Req.secBoardIdxList"), indices)
               .build();
            this.feedSrc = session.queries.getFeedSource(req);
            this.feedSrc.addContListener(aggregator);
         } catch (AsnTypeException | AmpPermissionException ex) {
            logger.error(ex.getMessage(), ex);
         }
      }
   }

   public ObservableList<ObservableReplyRow> getItems() {
      return items;
   }

   public ObservableList<WatchlistRow> getAllItems() {
      return displayedItems;
   }


   public void stopPolling() {
      if (aggregator == null) {
         logger.warn("{}::fail to stopPolling()", parentModule);
         return;
      }

      if (feedSrc != null) {
         feedSrc.removeListener(aggregator);
         feedSrc = null;
      }
   }

   public void cleanUp(){
      if (aggregatorListener != null) {
         aggregator.items.removeListener(aggregatorListener);
         aggregatorListener = null;
         secBoards = null;
         aggregator = null;
         feedSrc = null;
         session = null;
         mirrorList.clear();
         displayedItems.clear();
         queriedSecBoards.clear();
         secCodePriceCacheMap.clear();
      }

      if (items != null) {
         items.clear();
         items = null;
      }
   }

   public void doExpandCollapse(WatchlistRow headingRow) {
      if (!headingRow.isHeading()) {
         logger.warn("{}::Row {} must be a heading", parentModule, headingRow);
         return;
      }

      String headingName = headingRow.getHeading();
      int headingIndex = headingRow.getHeadingIndex();
      setSpec(specProperty.get().toggleExpandCollapse(headingName, headingIndex));
      Boolean isHeadingExpanded = specProperty.get().isHeadingExpanded(headingName, headingIndex);
      boolean isCollapse = (isHeadingExpanded != null && isHeadingExpanded.equals(Boolean.FALSE));
      updateHeadingCollapseInSpec(headingName, isCollapse);
   }

   public void setHeadingSpecGetter(Function<String, HeadingSpec> headingSpecGetter) {
      this.headingSpecGetter = headingSpecGetter;
   }

   // This is temporary usage for the diagnosis logs about WU issues. After fixing issue, need to rollback
   private FeedAggregator<ObservableReplyRow> aggregator;
   private List<SecBoard> queriedSecBoards = new ArrayList<>();
   private final List<WatchlistRow> mirrorList = new ArrayList<>();
   private final ObservableList<WatchlistRow> displayedItems = FXCollections.observableArrayList();

   private QueryFeed feedSrc;
   private ServerSession session;
   private SecBoards secBoards;
   private ObjectProperty<WatchlistSpec_v2> specProperty = new SimpleObjectProperty<>();
   private ObservableList<ObservableReplyRow> items;
   private Map<String, WatchListSecCodePriceCache> secCodePriceCacheMap = new HashMap<>();
   private String parentModule;
   private Function<String, HeadingSpec> headingSpecGetter;
}
