package xfe.icap.modules.sectabsui;

import javafx.event.EventHandler;
import javafx.scene.control.TableCell;
import javafx.scene.input.MouseEvent;
import org.controlsfx.glyphfont.Glyph;

import xfe.ui.popover.PopOverOwner;
import xstr.session.WatchlistRow;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * This is the base class for all custom watchlist cells - it can handle separately a data row and a heading one.
 *
 * @param <T>
 */
abstract class WatchlistCell<T> extends TableCell<WatchlistRow, T> implements PopOverOwner {

   protected static Map<Integer, Double> glyphFontSizeMap = new HashMap<>();

   static {
      glyphFontSizeMap.put(-4, 6d); // zoomLevel, size in PX (~6pt)
      glyphFontSizeMap.put(-3, 8d); // (~7pt)
      glyphFontSizeMap.put(-2, 10d);// (~8pt)
      glyphFontSizeMap.put(-1, 11d);      // (~9pt)
      glyphFontSizeMap.put(0, 13.333333); // (~10pt)
      glyphFontSizeMap.put(1, 14.666667); // (~11pt)
      glyphFontSizeMap.put(2, 16d);       // (~12pt)
      glyphFontSizeMap.put(3, 17.333333); // (~13pt)
      glyphFontSizeMap.put(4, 18.666667); // (~14pt)
      glyphFontSizeMap.put(5, 20d);       // (~15pt)
      glyphFontSizeMap.put(6, 21.333333); // (~16pt)
      glyphFontSizeMap.put(7, 22.666667); // (~17pt)
      glyphFontSizeMap.put(8, 24d);       // (~18pt)
      glyphFontSizeMap.put(9, 25.333333); // (~19pt)
      glyphFontSizeMap.put(10, 26.666667);// (~20pt)
   }

   private Glyph plus;
   private Glyph minus;
   private String rowKey;

   /* Heading's Expand/Collapse : In case of icon single click to open and rest of the header double click to open */
   private EventHandler<? super MouseEvent> headingMouseHandler = e -> {
      if ((isPlusMinusIconClicked(e) && e.getClickCount() == 1) || e.getClickCount() == 2) {
         getSecTable().getToggleExpandCollapseAction().accept(getWatchListRow());
      }
   };

   /* Event handler to run when clicking on default table row cells.*/
   private EventHandler<? super MouseEvent> defaultRowMouseHandler = e -> {
      if (e.getClickCount() == 1) {
         onSingleClick(e);
      } else if (e.getClickCount() == 2) {
         onDoubleClick(e);
      }
   };

   /**
    * Code to run on double click of cell.
    *
    * @param e Mouse event
    */
   protected void onDoubleClick(MouseEvent e) {
      /* Empty. Will be defined by sub classes if required. */
   }

   /**
    * Code to run on single click of cell.
    *
    * @param e Mouse event
    */
   protected void onSingleClick(MouseEvent e) {
      /* Empty. Will be defined by sub classes if required. */
   }

   /**
    * Specifies whether the mouse click is on the glyph icon bounds or not.
    *
    * @param e Mouse event
    * @return {@code true} if the mouse is pressed on glyph icon
    */
   private boolean isPlusMinusIconClicked(MouseEvent e) {
      return getPlus().getBoundsInParent().contains(e.getX(), e.getY()) || getMinus().getBoundsInParent().contains(e.getX(), e.getY());
   }

   @Override
   protected final void updateItem(T item, boolean empty) {
      // DO NOT call resetStyles without any condition. It made some performance issue when previous style is same as current one.
      // Please call resetStyles case by case.
      //Rather than saving a variable around(rowKey), and having to set it up and clean it up, we can just get the previous cell value.
      //This need to be done before the super.updateItem is called, as there is where the value is updated
      super.updateItem(item, empty);
      final WatchlistRow currentRow = getWatchListRow();

      /////Processing for empty rows
      //Checking for empty cells is done first, cleaning done and then quit, no other business logic should take place
      //Checking for emtpy cells, or items null
      if(item == null || empty || currentRow == null){
          resetForNonInstrumentRow();
          processForEmptyRows(empty,currentRow);
         return;
      }

      //Processing for rows with values
      if (currentRow.isHeading()) {
         rowKey = null;
         resetStyles();
         resetForNonInstrumentRow();
         updateHeadingItem(item, currentRow.isExpanded());
         setOnMouseClicked(headingMouseHandler);
         setEditable(false);
      } else {
         // When watchlistRow is changed (re-use cell instacne), do resetData and save rowKey again.
         if (!Objects.equals(rowKey, currentRow.getRow().getKey().toString())) {
            if(isEditing()) cancelEdit();
            resetStyles();
            resetDataItem();
            rowKey = currentRow.getRow().getKey().toString();
         }
         updateDataItem(item);
         setOnMouseClicked(defaultRowMouseHandler);
         setEditable(isDataEditable());
      }

   }

   /**
    * Reset actions that needs to be done for the cell.
    */
    protected void resetForNonInstrumentRow(){
       /* Empty. Will be defined by sub classes if required. */
    }

   private void processForEmptyRows(boolean empty, WatchlistRow currentRow){
       if(empty || currentRow==null){
          rowKey = null;
           if(isEditing()) cancelEdit();
           //Cleaning cell, turning off any mouse events
           setOnMouseClicked(null);
       } else if(currentRow.isHeading()) {
          rowKey = null;
           if(isEditing()) cancelEdit();
           //making sure empty cells part of headers still respond to mouse click with
           //headingMouseHandler, and are not editable
           setOnMouseClicked(headingMouseHandler);
           setEditable(false);
       }else{
          if (!Objects.equals(rowKey, currentRow.getRow().getKey().toString())) {
             if (isEditing()) cancelEdit();
             rowKey = currentRow.getRow().getKey().toString();
          }
           //empty cells in securities also need to respond to mouse, even if they are empty
           setOnMouseClicked(defaultRowMouseHandler);
           setEditable(isDataEditable());
       }
       //Canceling editing needs to be done before the resetDataItem and resetStyles. (when required, thats
       //why extra if controls in the previous if.
       // Stop the edit mode first. When call cancelEdit, do set previous Item again in JavaFx standard process.
       // If do cancelEdit after finishing all reset, previous value set again after reset so it causes garbage issue when cell instance re-use.
       resetDataItem();
       resetStyles();
   }
   /**
    * Gets the plus icon.
    *
    * @return the plus icon
    */
   private Glyph getPlus() {
      if (plus == null) {
         plus = new Glyph("FontAwesome", "PLUS_SQUARE");
         plus.setFontSize(glyphFontSizeMap.get(getSecTable().getZoomLevel().get()));
         plus.getStyleClass().add("header-icon-plus");
      }
      return plus;
   }

   /**
    * Gets the minus icon.
    *
    * @return the minus icon
    */
   private Glyph getMinus() {
      if (minus == null) {
         minus = new Glyph("FontAwesome", "MINUS_SQUARE");
         minus.setFontSize(glyphFontSizeMap.get(getSecTable().getZoomLevel().get()));
         minus.getStyleClass().add("header-icon-minus");
      }
      return minus;
   }

   /**
    * Updates the cell with the provided item. Typically this is implemented for non-heading row cells.
    *
    * @param item Value to be updated in cell
    */
   protected abstract void updateDataItem(T item);

   /**
    * Reset the cell for removing heading Row setup. For non-heading row reset, override on each cell class.
    */
   protected void resetDataItem() {
      setText(null);
      setGraphic(null);
   }

   /**
    * Resets the styles of the cell.
    */
   protected void resetStyles(){
      /* Empty by default */
   }


   /**
    * Specifies whether the cell is editable or not.
    *
    * @return {@code true} if the cell is editable
    */
   protected boolean isDataEditable() {
      return false;
   }


   /**
    * Updates the heading row cell.
    *
    * @param item       Value of the cell
    * @param isExpanded Specifies if the row is expanded or collapsed
    */
   protected void updateHeadingItem(T item, boolean isExpanded) {
      //If I make it here, its because item is NOT null, no extra check and cleaning is needed. Only set the value.
      setText(item.toString());
      if (!item.toString().isEmpty()) {
         setGraphic(isExpanded ? getMinus() : getPlus());
      } else {
         setGraphic(null);
      }
   }

   /**
    * Returns the SecTable associated to this cell. The main intention of this method is to avoid repeated casting code in all the sub cells code.
    *
    * @return SecTable
    */
   protected final SecTable getSecTable() {
      return (SecTable) getTableView();
   }

   /**
    * Returns the WatchListRow item associated to the row of this cell.  The main intention of this method is to avoid repeated casting code in all the sub cells code.
    *
    * @return WatchListRow. {@code null} is returned for empty rows.
    */
   protected final WatchlistRow getWatchListRow() {
      return (getTableRow() == null)? null : (WatchlistRow) getTableRow().getItem();
   }
}
