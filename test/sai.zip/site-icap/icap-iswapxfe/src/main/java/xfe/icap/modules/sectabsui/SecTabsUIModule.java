package xfe.icap.modules.sectabsui;

import com.nomx.domain.types.AmountType;
import com.nomx.domain.types.DefaultDurationType;
import com.nomx.domain.types.InstrumentKey;
import com.nomx.domain.types.OnLogoffAction;
import com.nomx.instrumentsettings.InstrumentSettingsSpec;
import com.nomx.persist.PersistantName;
import com.nomx.persist.watchlist.ColumnsSpec;
import com.nomx.persist.watchlist.HeadingSpec;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.nomx.persist.watchlist.WatchlistSpec_v2.Security;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import com.omxgroup.xstream.amp.AmpSecClassId;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.input.ScrollEvent;
import javafx.util.Callback;
import javafx.util.Duration;
import javafx.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.amp.AmpActives;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.ordersdata.OrdersDataModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.securities.SecurityWatchlist;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.shortlist.ShortlistButtonsViewUIModule;
import xfe.icap.modules.tradesdata.TradesDataModule;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.Orders;
import xfe.module.Module;
import xfe.modules.actions.*;
import xfe.modules.session.SessionScopeModule;
import xfe.types.*;
import xfe.ui.flasher.PseudoFlasher;
import xfe.ui.table.CellButton;
import xfe.util.XfeAction;
import xstr.session.*;
import xstr.types.MapWrapper;
import xstr.types.OrderSide;
import xstr.types.XtrBlob;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static xfe.util.Constants.PRICE_TYPE_INDICATIVE;
import static xstr.types.OrderSide.SELL;

@Module.Autostart
public class SecTabsUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(SecTabsUIModule.class);

   private static final String SECURITY_WATCHLIST_KEY = "SECURITY-WATCHLIST-KEY";
   private static final String WATCHLIST_SPEC_ID_KEY = "WATCHLIST_SPEC_ID_KEY";
   private static final String ACTIVES_TABLE_ID = "ACTIVES_TABLE_ID";

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @ModuleDependency
   public OrdersDataModule ordersDataModule;

   @ModuleDependency
   public TradesDataModule tradesDataModule;

   @ModuleDependency
   public ShortlistButtonsViewUIModule shortlistButtonsViewUIModule;

   private Map<String, ObjectProperty<ColumnsSpec>> tableColumnsSpecMap = new HashMap<>();
   private ChangeListener<ColumnsSpec> columnsSpecListener;


   /**
    * Indicates the number of scrolls done on the SecTable.
    */
   private int scrollCount = 0;

   public void setEnterOrderHandler(Consumer<PopupOrderEntryArgs> enterOrder) {
      this.enterOrder = enterOrder;
   }

   public void setAmendOrderHandler(Consumer<PopupOrderEntryArgs> amendOrder) {
      this.amendOrder = amendOrder;
   }

   public void setTickUpDownAmendOrder(Consumer<TickUpDownAmendArgs> tickUpDownAmendOrder) {
      this.tickUpDownAmendOrder = tickUpDownAmendOrder;
   }

   public void setReferAllOrdersHandler(Consumer<ReferArgs> referAllOrders) {
      this.referAllOrders = referAllOrders;
   }

   public void setWithdrawOrders(Consumer<WithdrawArgs> withdrawOrders) {
      this.withdrawOrders = withdrawOrders;
   }

   public void setWithdrawCMOrders(Consumer<WithdrawArgs> withdrawCMOrders) {
      this.withdrawCMOrders = withdrawCMOrders;
   }

   public void setHitTakeOrderHandler(Consumer<PopupOrderEntryArgs> hitTakeOrder) {
      this.hitTakeOrder = hitTakeOrder;
   }

   public void setEnterCMOrdersHandler(Consumer<PopupOrderEntryArgs> enterCMOrder) {
      this.enterCMOrder = enterCMOrder;
   }

   public void setAmendCMOrdersHandler(Consumer<PopupOrderEntryArgs> amendCMOrder) {
      this.amendCMOrder = amendCMOrder;
   }

   public void setReferCMOrderHandler(Consumer<ReferArgs> referCMOrder) {
      this.referAllCMOrders = referCMOrder;
   }

   public void setWorkupHandler(Consumer<WorkupArgs> workup) {
      this.workup = workup;
   }

   @Override
   public Future<Void> stopModule() {
      /* Removing the watch list listener to avoid possible memory leaks */
      watchlists.removeListener(watchListListener);
      watchListListener = null;

      /* Removing the tab change listener before clearing the tabs. Otherwise this listener will trigger to save wrong selected tab in settings when tabs are cleared. */
      this.secTabs.getSelectionModel().selectedItemProperty().removeListener(tabChangeListener);
      tabChangeListener = null;


      clearTabs();
      clearShortlistButtonModuleHandlers();

      tableColumnsSpecMap.forEach((id, prop) -> prop.removeListener(columnsSpecListener));
      tableColumnsSpecMap.clear();

      columnsSpecListener = null;

      fullHighlightedList = null;
      halfHighlightedList = null;

      midiLayoutModule.removeView(secTabs);
      activesWatchlist = null;
      setApplyAllVisibilityHandler(null);
      this.secTabs = null;
      PseudoFlasher.clearAllFlashingNodes();
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> startModule() {
      watchListListener = getWatchListListener();
      columnsSpecListener = (observable, oldValue, newValue) -> replaceSpec(newValue);
      tabChangeListener = (observable, oldTab, newTab) -> {
         bindSelectedRow(newTab);
         if (newTab != null) {
            final UUID tabId = getSpecId();
            /* Actives spec is not in watchlists, so combining both into one list */
            List<WatchlistSpec_v2> specs = new ArrayList<>(watchlists);
            if (activesSpec != null) {
               specs.add(0, activesSpec);
            }
            /* Setting the spec in settings based on the selected tab */
            specs.stream().filter(wl -> wl.getId().equals(tabId)).findFirst()
               .ifPresent(spec -> configurationModule.getData().selectedWatchListTabProperty().set(spec));
         }
      };

      fullHighlightedList = configurationModule.getParametersStorage().getList(PersistantName.InstrumentsHighlightData, InstrumentKey.class, FXCollections.observableArrayList());
      halfHighlightedList = configurationModule.getParametersStorage().getList(PersistantName.InstrumentsHighlightData2, InstrumentKey.class, FXCollections.observableArrayList());

      BooleanProperty activesTabProperty = configurationModule.getData().activesTabProperty();
      activesTabProperty.addListener((observable, oldValue, newValue) -> {
         // Adding or removing the activesTab
         if (newValue) {
            addActivesTab();
            secTabs.getSelectionModel().select(0);
         } else {
            removeActivesTab();
         }
      });
      this.secTabs = new SecTabs();
      midiLayoutModule.addView(secTabs);

      watchlists = configurationModule.getWatchlists();
      watchlists.addListener(watchListListener);
      generateTabs(watchlists);
      // Note :: add listener only after generating the tabs.
      this.secTabs.getSelectionModel().selectedItemProperty().addListener(tabChangeListener);

      final Consumer<ColumnsSpec> applyAllVisibilityHandler = (args) -> this.secTabs.getTabs().forEach(tab -> {
         if (tab.getContent() instanceof SecTable) {
            final SecTable secTable = (SecTable) tab.getContent();
            secTable.applyColumnsVisibility(args);
         }
      });
      setApplyAllVisibilityHandler(applyAllVisibilityHandler);
      configureZoomLevel();
      updateShortlistButtonModuleHandlers();

      configurationModule.getData().tradeOneClickProperty().addListener((observable, oldValue, newValue) -> {
         secTabs.getTabs().forEach(tab -> {
            if (tab.getContent() instanceof SecTable) {
               final SecTable secTable = (SecTable) tab.getContent();
               secTable.setOneClickTrading(newValue);
            }
         });
         shortlistButtonsViewUIModule.updateOneClickTrading(newValue);
      });

      return Future.SUCCESS;
   }

   /**
    * Generates the tabs from the provided list of watchList Specs.
    *
    * @param watchLists List of watchList specs
    */
   private void generateTabs(List<WatchlistSpec_v2> watchLists) {
      // Add tabs for each watchList
      watchLists.stream().filter(WatchlistSpec_v2::isVisible).forEach(spec -> addWatchlistTab(spec));

      // Add actives tab if configured
      if (configurationModule.getData().activesTabProperty().get()) {
         addActivesTab();
      }

      // Select the default tab that is saved in workspace setting.
      final ObjectProperty<WatchlistSpec_v2> selectedWatchListTabProperty = configurationModule.getData().selectedWatchListTabProperty();
      if (selectedWatchListTabProperty != null && selectedWatchListTabProperty.get() != null) {
         UUID selectedSpecID = selectedWatchListTabProperty.get().getId();
         secTabs.getTabs().stream().filter(tab -> Objects.equals(selectedSpecID, tab.getProperties().get(WATCHLIST_SPEC_ID_KEY)))
            .findFirst().ifPresent(tab -> secTabs.getSelectionModel().select(tab));
      }

      bindSelectedRow(this.secTabs.getSelectionModel().getSelectedItem());
   }

   private void bindSelectedRow(Tab newTab) {
      if (newTab == null)
         return;

      if (newTab.getContent() instanceof SecTable) {
         final SecTable secTable = (SecTable) newTab.getContent();
         selectedSecurityRow.bind(secTable.getSelectionTracker().selectedItemProperty());
      }
   }


   private void addActivesTab() {
      ObjectProperty<WatchlistSpec_v2> activesSpecProperty = configurationModule.getData().activesSpecProperty();
      WatchlistSpec_v2 wsActivesSpec = activesSpecProperty.get();
      activesSpec = wsActivesSpec.withTitle("Actives").withSecurities(new WatchlistSpec_v2.Security[0]);
      activesSpecProperty.setValue(activesSpec);
      cleanUpObsoleteHeadings();
      activesWatchlist = securitiesDataModule.createWatchlist(SecTabsUIModule.class.getName() + "_Actives");
      // Actives tab also start/stop polling depend on selection condition so do not auto-polling
      activesWatchlist.setHeadingSpecGetter(this::getHeadingSpec);
      activesWatchlist.setSpec(activesWatchlist.adjustHeadingsState(activesSpec), false);

      SecTable table = new SecTable(activesSpec.getColumnsSpec());
      table.setId(ACTIVES_TABLE_ID);
      table.getStyleClass().add(SecTable.ZOOM_STYLE + getZoomLevel());
      table.columnsSpecProperty().addListener((observable, oldValue, newValue) -> activesSpecProperty.setValue(activesSpec.withSecurities(new WatchlistSpec_v2.Security[0]).withColumnsSpec(newValue)));

      // Adding tab and starting query
      activesTab = new WatchListTab(activesSpec.title, activesSpec.subtitle);
      activesTab.getProperties().put(WATCHLIST_SPEC_ID_KEY, activesSpec.getId());
      setupTable(activesSpec, activesWatchlist, table);
      activesTab.setContent(table);
      secTabs.addTab(0, activesTab);
      // Actives tab also start/stop polling depend on selection condition
      activesTab.selectedProperty().addListener((o, oldVal, newVal) -> {
         if (newVal) {
            activesWatchlist.startPolling();
         } else {
            activesWatchlist.stopPolling();
         }
      });
      if (activesTab.isSelected()) {
         activesWatchlist.startPolling();
      }

      // Setting up includedActives query
      try {
         Optional<ServerSession> session = activeSessionModule.getSession();
         if (session.isPresent()) {
            XtrQueryRequestBuilder reqBuilder = XtrQueryRequestBuilder.create(AmpActives.req, session.get());
            activesFeedSrc = session.get().queries.getFeedSource(reqBuilder.build());
            activesFeedListener = feedEvents -> {
               for (QueryRowEvent event : feedEvents) {
                  XtrQueryReplyCommand eventType = event.getEventType();

                  switch (eventType) {
                     case CLEAR:
                        // Resetting view
                        clearActives();
                        break;
                     case CREATE:
                        addActive(event.getNewRow().getValue(AmpActives.secCode));
                        break;
                     case UPDATE:
                        // Do we need to do anything?!
                        break;
                     case DELETE:
                        removeActive(event.getOldRow().getValue(AmpActives.secCode));
                        break;
                     default:
                        logger.error("Unexpected event type: {}", eventType);
                  }

               }
            };
            activesFeedSrc.addListener(activesFeedListener);
         }
      } catch (AsnTypeException | AmpPermissionException e) {
         e.printStackTrace();
      }
   }

   private void removeActivesTab() {
      // Stopping query and removing tab
      if (activesFeedListener != null) {
         activesFeedSrc.removeListener(activesFeedListener);
         activesFeedListener = null;
         activesFeedSrc = null;
      }

      if (activesTab != null) {
         final SecTable secTable = (SecTable) activesTab.getContent();
         if (secTable != null) {
            secTable.getItems().clear();
            secTable.setSelectionModel(null);
            clearTableHandlers(secTable);
         }
         activesTab.setContent(null);
         secTabs.removeTab(activesTab);
         /* activesWatchList is already cleaned  just before this method call in the for loop, so no need to clean again */
         activesWatchlist = null;
         activesTab = null;
      }

      includedActives.clear();
      excludedActives.clear();
   }

   private void updateShortlistButtonModuleHandlers() {
      shortlistButtonsViewUIModule.setActionFactory(this::actionValueFactoryImpl);
      shortlistButtonsViewUIModule.setCM_ActionFactory(this::CM_ActionValueFactoryImpl);
      shortlistButtonsViewUIModule.setMatchColFactory(this::matchColFactory);
      shortlistButtonsViewUIModule.setPriceColFactory(this::priceColFactory);
      shortlistButtonsViewUIModule.setTotalColFactory(this::totalColFactory);
      shortlistButtonsViewUIModule.setDoTotalColDblClickAction(this::doTotalColDblClickAction);
      shortlistButtonsViewUIModule.setDoPriceColDblClickAction(this::doPriceColDblClickAction);
      shortlistButtonsViewUIModule.setDoTickUpDownPriceAmendAction(this::doTickUpDownPriceAmendAction);
      shortlistButtonsViewUIModule.setDoReferAllButtonAction(this::doReferAllButtonAction);
      shortlistButtonsViewUIModule.setDoHitTakeButtonAction(this::doHitTakeButtonAction);
      shortlistButtonsViewUIModule.setTradesAggregatePopupAction(this::doTradesAggregatePopupAction);
      shortlistButtonsViewUIModule.setSpreadForPriceReversal(securitiesDataModule::isSpreadForPriceReversal);
      shortlistButtonsViewUIModule.setStepArrayCallBack(this::getStepArrayForInstrument);
      shortlistButtonsViewUIModule.setDoCMPriceColEntry(this::doCMPriceColEntry);
      shortlistButtonsViewUIModule.setDoCMPriceColAmend(this::doCMPriceColAmend);
      shortlistButtonsViewUIModule.setDoReferAllCMButtonAction(this::doReferAllCMButtonAction);
      shortlistButtonsViewUIModule.setDoSideColAction(this::doWorkupAction);
      shortlistButtonsViewUIModule.setDoWorkupAction(this::doWorkupAction);
      shortlistButtonsViewUIModule.setSendDefaultOrder(this::sendDefaultOrder);
      shortlistButtonsViewUIModule.setIsLockedClbk(this::isLocked);
      shortlistButtonsViewUIModule.setZoomLevel(this::getZoomLevel);
      shortlistButtonsViewUIModule.setLoggedInUserId(this::getLoggedInUserId);
   }

   private void clearShortlistButtonModuleHandlers() {
      shortlistButtonsViewUIModule.setActionFactory(null);
      shortlistButtonsViewUIModule.setCM_ActionFactory(null);
      shortlistButtonsViewUIModule.setMatchColFactory(null);
      shortlistButtonsViewUIModule.setPriceColFactory(null);
      shortlistButtonsViewUIModule.setTotalColFactory(null);
      shortlistButtonsViewUIModule.setDoTotalColDblClickAction(null);
      shortlistButtonsViewUIModule.setDoPriceColDblClickAction(null);
      shortlistButtonsViewUIModule.setDoReferAllButtonAction(null);
      shortlistButtonsViewUIModule.setDoHitTakeButtonAction(null);
      shortlistButtonsViewUIModule.setTradesAggregatePopupAction(null);
      shortlistButtonsViewUIModule.setSpreadForPriceReversal(null);
      shortlistButtonsViewUIModule.setDoCMPriceColEntry(null);
      shortlistButtonsViewUIModule.setDoCMPriceColAmend(null);
      shortlistButtonsViewUIModule.setDoReferAllCMButtonAction(null);
      shortlistButtonsViewUIModule.setDoSideColAction(null);
      shortlistButtonsViewUIModule.setDoWorkupAction(null);
      shortlistButtonsViewUIModule.setSendDefaultOrder(null);
      shortlistButtonsViewUIModule.setIsLockedClbk(null);
      shortlistButtonsViewUIModule.setZoomLevel(null);
      shortlistButtonsViewUIModule.setLoggedInUserId(null);
   }

   private void setApplyAllVisibilityHandler(Consumer<ColumnsSpec> columnsVisibilityAction) {
      this.columnsVisibilityAction = columnsVisibilityAction;
   }

   /**
    * Configures the zoom level implementation on all secTables throughout the application.
    */
   private void configureZoomLevel() {
      final IntegerProperty zoomLevel = configurationModule.getData().instrumentsTableZoomLevelProperty();
      Timeline timeline = new Timeline(new KeyFrame(Duration.millis(100), e -> {
         scrollCount = 0; // Resetting the scroll count
         updateZoomOnTables(zoomLevel.get());
      }));
      zoomLevel.addListener((obs, oldVal, zoom) -> {
         if (timeline.getStatus() == Animation.Status.RUNNING) {
            timeline.playFromStart();
         } else {
            timeline.play();
         }
      });
      updateZoomOnTables(zoomLevel.get());

      // Implementing zooming feature on Ctrl + Scroll.
      final EventHandler<ScrollEvent> scrollEventEventHandler = (evt) -> {
         if (evt.isControlDown()) {
            evt.consume();
            scrollCount++;
            // Considering only after every 2 scroll steps to decrease the speed of zooming
            if (scrollCount % 2 == 0) {
               int factor = evt.getDeltaY() > 0 ? 1 : -1;
               int zoom = zoomLevel.get() + factor;
               if (zoom > -5 && zoom < 11) {
                  zoomLevel.set(zoom);
               }
            }
         }
      };
      this.secTabs.addEventFilter(ScrollEvent.SCROLL, scrollEventEventHandler);
      shortlistButtonsViewUIModule.setScrollEventEventHandler(scrollEventEventHandler);
      // On every tab selection, checking whether the zoom is with recent value. If not refresh the table.
      this.secTabs.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, selTab) -> {
         if (selTab != null && selTab.getContent() instanceof TableView) {
            final String zoomStyle = SecTable.ZOOM_STYLE + zoomLevel.getValue();
            if (!selTab.getContent().getStyleClass().contains(zoomStyle)) {
               updateTableStyle((TableView) selTab.getContent(), zoomStyle);
            }
         }
      });
   }

   /**
    * Update the provided tableView with the given style class.
    *
    * @param tableView TableView to be updated
    * @param zoomStyle Style class to apply
    */
   private void updateTableStyle(TableView tableView, String zoomStyle) {
      tableView.getStyleClass().removeIf(style -> style.startsWith(SecTable.ZOOM_STYLE));
      tableView.getStyleClass().add(zoomStyle);
      tableView.refresh();
   }

   /**
    * Updates the provided zoom level on all the secTables.
    *
    * @param zoomLevel Zoom level value
    */
   private void updateZoomOnTables(int zoomLevel) {
      Tab selectedTab = this.secTabs.getSelectionModel().getSelectedItem();
      if (selectedTab != null) {
         final long time = System.currentTimeMillis();
         // Applying zoom only on the selected tab. For other tabs, the style will be applied on tab selection.
         Node selectedTabContent = selectedTab.getContent();
         if (selectedTabContent instanceof TableView) {
            final String zoomStyle = SecTable.ZOOM_STYLE + zoomLevel;
            final TableView tableView = (TableView) selectedTabContent;
            updateTableStyle(tableView, zoomStyle);
         }
         shortlistButtonsViewUIModule.updateZoomToTables(zoomLevel);
         logger.debug("!!! Updated ZOOM  {} in :: {} ms" , zoomLevel,  (System.currentTimeMillis() - time));
      }
   }

   /**
    * Clears all the tabs by removing all the associated handlers to the table in each tab.
    */
   private void clearTabs() {
      this.secTabs.getTabs().forEach(tab -> {
         if (tab.getContent() instanceof SecTable) {
            final SecTable secTable = (SecTable) tab.getContent();
            final SecurityWatchlist securityWatchlist = (SecurityWatchlist) secTable.getProperties().get(SECURITY_WATCHLIST_KEY);
            securitiesDataModule.stopAndCleanWatchList(securityWatchlist);
            secTable.getProperties().remove(SECURITY_WATCHLIST_KEY);
            secTable.getItems().clear();
            secTable.setSelectionModel(null);
            tab.setContent(null);
            clearTableHandlers(secTable);
         }
      });
      removeActivesTab();
      this.secTabs.getTabs().clear();
   }

   private ListChangeListener<WatchlistSpec_v2> getWatchListListener() {
      return (ListChangeListener.Change<? extends WatchlistSpec_v2> c) -> {
         while (c.next()) {
            final UUID selectedTabId = (UUID) this.secTabs.getSelectionModel().getSelectedItem().getProperties().get(WATCHLIST_SPEC_ID_KEY);

            // First stop polling the current/all SecurityWatchList, dispose all tabs and tables as we are repopulating them again.
            clearTabs();

            // Adding tabs for new watchlistspecs.
            AtomicReference<WatchListTab> selectedTab = new AtomicReference<>(null);
            List<? extends WatchlistSpec_v2> addedList = c.getAddedSubList();
            for (WatchlistSpec_v2 wl : addedList) {
               Stream.of(wl).filter(WatchlistSpec_v2::isVisible).forEach(w -> {
                  WatchListTab tab = this.addWatchlistTab(w);
                  // Implementing selection of tab based on current section in settings->tabeditor->listview selection.
                  if (wl.isSelectedInTabListView()) {
                     selectedTab.set(tab);
                  }
               });
            }
            if (configurationModule.getData().activesTabProperty().get())
               addActivesTab();

            if (selectedTab.get() != null)
               this.secTabs.getSelectionModel().select(selectedTab.get());

            // If no tab is selected, then defaulting to earlier selection. If that tab is deleted, then defaulting to first tab selection.
            if (this.secTabs.getSelectionModel().getSelectedItem() == null) {
               Optional<Tab> tab = this.secTabs.getTabs().stream().filter(t -> t.getProperties().get(WATCHLIST_SPEC_ID_KEY).equals(selectedTabId)).findFirst();
               if (tab.isPresent()) {
                  this.secTabs.getSelectionModel().select(tab.get());
               } else {
                  this.secTabs.getSelectionModel().selectFirst();
               }
            }
         }
      };
   }

   private void replaceSpec(UUID id, ColumnsSpec specs) {
      int index = -1;
      int foundIndex = -1;
      for (WatchlistSpec_v2 spec : watchlists) {
         ++index;
         if (spec.id.equals(id)) {
            foundIndex = index;
            break;
         }
      }
      if (foundIndex >= 0) {
         replaceInWatchList(foundIndex, watchlists.get(foundIndex).withColumnsSpec(specs));
      }
   }

   private void replaceSpec(ColumnsSpec specs) {
      int index = -1;
      int foundIndex = -1;
      for (WatchlistSpec_v2 spec : watchlists) {
         ++index;
         if (spec.id.toString().equals(specs.getId())) {
            foundIndex = index;
            break;
         }
      }
      if (foundIndex >= 0) {
         replaceInWatchList(foundIndex, watchlists.get(foundIndex).withColumnsSpec(specs));
      }
   }

   private void replaceSpec(WatchlistSpec_v2 newSpec) {
      UUID id = newSpec.id;
      int index = -1;
      int foundIndex = -1;
      for (WatchlistSpec_v2 spec : watchlists) {
         ++index;
         if (spec.id.equals(id)) {
            foundIndex = index;
            break;
         }
      }
      if (foundIndex >= 0) {
         replaceInWatchList(foundIndex, newSpec);
      }
   }

   private void replaceInWatchList(int index, WatchlistSpec_v2 watchList) {
      /* Removing the listener to not fire to reconstruct the tabs again */
      watchlists.removeListener(watchListListener);
      watchlists.set(index, watchList);
      /* Adding the listener back after updating the watchlist */
      watchlists.addListener(watchListListener);
   }

   public ObjectProperty<ColumnsSpec> getTableColumnsSpec(String id) {
      if (tableColumnsSpecMap.get(id) == null) {
         for (WatchlistSpec_v2 wlSpec : watchlists) {
            if (wlSpec.id.toString().equals(id)) {
               final ColumnsSpec columnsSpec = wlSpec.getColumnsSpec() == null ? new ColumnsSpec() : wlSpec.getColumnsSpec();
               columnsSpec.setId(id);
               final ObjectProperty<ColumnsSpec> columnsSpecProperty = new SimpleObjectProperty<>(columnsSpec);
               columnsSpecProperty.addListener(columnsSpecListener);
               tableColumnsSpecMap.put(id, columnsSpecProperty);
            }
         }
      }
      return tableColumnsSpecMap.get(id);
   }

   private WatchListTab addWatchlistTab(WatchlistSpec_v2 spec) {
      // For making XFE more light, improve to start polling only for selected tab
      // Common secboard tab, except actives tab, managed polling condition by selection listener.
      SecurityWatchlist wl = securitiesDataModule.createWatchlist(SecTabsUIModule.class.getName() + "_" + spec.title);
      wl.setSpec(spec, false);
      wl.specProperty().addListener((obs) -> replaceSpec(wl.getSpec()));

      WatchListTab tab = new WatchListTab(spec.title, spec.subtitle);
      tab.getProperties().put(WATCHLIST_SPEC_ID_KEY, spec.getId());

      SecTable table = new SecTable(spec.getColumnsSpec());
      table.columnsSpecProperty().addListener((observable, oldValue, newValue) -> replaceSpec(spec.id, newValue));

      setupTable(spec, wl, table);
      tab.setContent(table);

      secTabs.addTab(tab);

      tab.selectedProperty().addListener((o, oldVal, newVal) -> {
         if (newVal) {
            wl.startPolling();
            updateActiveInstrumentTabInfo();
         } else {
            wl.stopPolling();
         }
      });

      if (tab.isSelected()) {
         wl.startPolling();
         updateActiveInstrumentTabInfo();
      }
      return tab;
   }

   private void setupTable(WatchlistSpec_v2 spec, SecurityWatchlist wl, SecTable table) {
      table.setItems(wl.getAllItems());
      table.getProperties().put(SECURITY_WATCHLIST_KEY, wl);

      table.setOneClickTrading(configurationModule.getData().tradeOneClickProperty().get());
      table.setActionFactory(this::actionValueFactoryImpl);
      table.setCMActionFactory(this::CM_ActionValueFactoryImpl);
      table.setMatchColFactory(this::matchColFactory);
      table.setPriceColFactory(this::priceColFactory);
      table.setTotalColFactory(this::totalColFactory);
      table.setSendDefaultOrderClbk(this::sendDefaultOrder);
      table.setTotalColDblClickAction(this::doTotalColDblClickAction);
      table.setPriceColDblClickAction(this::doPriceColDblClickAction);
      table.setDoTickUpDownPriceAmend(this::doTickUpDownPriceAmendAction);
      table.setStepArrayCallBack(this::getStepArrayForInstrument);
      table.setCMPriceColEntry(this::doCMPriceColEntry);
      table.setCMPriceColAmend(this::doCMPriceColAmend);
      table.setPriceColWorkupAction(this::doWorkupAction);
      table.setCMPriceColWorkupAction(this::doWorkupAction);
      table.setToggleExpandCollapseAction(wl::doExpandCollapse);
      table.setIsLockedClbk(this::isLocked);
      table.setTradesAggregatePopupAction(this::doTradesAggregatePopupAction);
      table.setZoomLevel(this::getZoomLevel);
      table.setColumnsVisibilityAction(this::doColumnsVisibilityAction);
      table.setSaveToggleClbk(this::saveToggle);
      table.setPriceCellFlashDuration(this::priceCellFlashDuration);


      Callback<TableView<WatchlistRow>, TableRow<WatchlistRow>> rowFactory = tableView -> new TableRow<WatchlistRow>() {

         @Override
         public void updateItem(WatchlistRow r, boolean empty) {
            super.updateItem(r, empty);

            if (!empty && r != null) {
               getStyleClass().remove("heading-row");
               if (!r.isHeading()) {
                  ObservableReplyRow row = getItem().getRow();
                  String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
                  String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
                  final UUID tabId = spec.getId();
                  if (tabId != null) {
                     removeAllHighlighting();
                     if (fullHighlightedList.getValue().contains(InstrumentKey.create(tabId, secCode, boardId))) {
                        setHighlighting(RowHighlight.FULL);
                     } else if (halfHighlightedList.getValue().contains(InstrumentKey.create(tabId, secCode, boardId))) {
                        setHighlighting(RowHighlight.HALF);
                     } else {
                        setHighlighting(RowHighlight.NONE);
                     }
                  }
               } else {
                  getStyleClass().add("heading-row");
               }
            } else {
               removeAllHighlighting();
            }
         }

         private void setHighlighting(RowHighlight h) {
            (getItem().getRow()).setCustomProperty(SecTable.HIGHLIGHT_PROP_NAME, h);
            pseudoClassStateChanged(h.getStyle(), true);
         }

         private void removeAllHighlighting() {
            pseudoClassStateChanged(RowHighlight.NONE.getStyle(), false);
            pseudoClassStateChanged(RowHighlight.HALF.getStyle(), false);
            pseudoClassStateChanged(RowHighlight.FULL.getStyle(), false);
         }
      };
      table.setRowFactory(rowFactory);
   }

   private void clearTableHandlers(SecTable table) {
      table.setActionFactory(null);
      table.setCMActionFactory(null);
      table.setMatchColFactory(null);
      table.setPriceColFactory(null);
      table.setTotalColFactory(null);
      table.setSendDefaultOrderClbk(null);
      table.setTotalColDblClickAction(null);
      table.setPriceColDblClickAction(null);
      table.setDoTickUpDownPriceAmend(null);
      table.setCMPriceColEntry(null);
      table.setCMPriceColAmend(null);
      table.setStepArrayCallBack(null);
      table.setPriceColWorkupAction(null);
      table.setCMPriceColWorkupAction(null);
      table.setToggleExpandCollapseAction(null);
      table.setIsLockedClbk(null);
      table.setTradesAggregatePopupAction(null);
      table.setZoomLevel(null);
      table.setColumnsVisibilityAction(null);
      table.setSaveToggleClbk(null);
      table.setRowFactory(null);
   }

   private void saveToggle(ObservableReplyRow row, RowHighlight prevState) {
      final UUID tabId = getSpecId();
      if (tabId != null) {
         String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
         InstrumentKey key = InstrumentKey.create(tabId, secCode, boardId);

         if (prevState.equals(RowHighlight.HALF)) {
            removeToggledRow(halfHighlightedList, key);
         } else if (prevState.equals(RowHighlight.FULL)) {
            removeToggledRow(fullHighlightedList, key);
         }

         RowHighlight newState = prevState.getNext();
         if (newState.equals(RowHighlight.HALF)) {
            addToggledRow(halfHighlightedList, key);
         } else if (newState.equals(RowHighlight.FULL)) {
            addToggledRow(fullHighlightedList, key);
         }
      }
   }

   private boolean isLocked() {
      Optional<ServerSession> session = activeSessionModule.getSession();
      return session.isPresent() && session.get().isLocked();
   }

   private int getZoomLevel() {
      if (configurationModule.getData() != null) {
         return configurationModule.getData().instrumentsTableZoomLevelProperty().get();
      }
      return 0;
   }

   private UUID getSpecId() {
      final Tab tab = secTabs.getSelectionModel().getSelectedItem();
      if (tab != null) return (UUID) tab.getProperties().get(WATCHLIST_SPEC_ID_KEY);
      return null;
   }

   private void removeToggledRow(ObjectProperty<ObservableList<InstrumentKey>> highlightList, InstrumentKey key) {
      highlightList.get().remove(key);
   }

   private void addToggledRow(ObjectProperty<ObservableList<InstrumentKey>> highlightList, InstrumentKey key) {
      highlightList.get().add(key);
   }

   /**
    * Sets the boolean flag about the current selected instrument tab. This flag is later used to do the default selection in Settings -> Tab Editor.
    */
   private void updateActiveInstrumentTabInfo() {
      final Tab tab = this.secTabs.getSelectionModel().getSelectedItem();
      if (tab != null) {
         final UUID tabId = (UUID) tab.getProperties().get(WATCHLIST_SPEC_ID_KEY);
         configurationModule.getWatchlists().forEach(wl -> wl.setSelectedInTabListView(wl.getId().equals(tabId)));
      }
   }

   private void doTotalColDblClickAction(PopupOrderEntryArgs args) {
      if (enterOrder != null) {
         enterOrder.accept(args);
      }
   }

   private void doPriceColDblClickAction(PopupOrderEntryArgs args) {
      if (enterOrder != null)
         enterOrder.accept(args);
   }

   private void doTickUpDownPriceAmendAction(TickUpDownAmendArgs args){
      String secCode = args.getRow().getValue(AmpIcapSecBoardTrim2.secCode);
      OrderSide side = args.getSide();
      ObservableList<ObservableReplyRow> orders = ordersDataModule.ordersToWithdraw(secCode,side);
      if(withdrawOrders!=null){
         withdrawOrders.accept(new WithdrawArgs(args.getRow(), side, false));
      }
      if(tickUpDownAmendOrder!=null){
         String boardId = args.getRow().getValue(AmpIcapSecBoardTrim2.boardId);
         try {
            ObservableReplyRow managedOrder = orders.get(0);
            NumberContext priceContext = securitiesDataModule.getStaticInfo(secCode, boardId).get().priceContext;
            StepArray stepArray = priceContext.getSpinStepArray();
            if (stepArray == null) {
               logger.info("Nothing for Tick Up/Down because StepArray is null for secCode :: "+secCode);
               return;
            }
            double price =  managedOrder.getValue(AmpManagedOrder.price).doubleValue();
            double newPrice;
            boolean priceReversal = securitiesDataModule.isSpreadForPriceReversal(args.getRow());
            boolean stepUP = (!priceReversal && args.isTickUp()) ||
               (priceReversal && !args.isTickUp());
            if(stepUP){
               newPrice = stepArray.stepUp(price);
            }else{
               newPrice = stepArray.stepDown(price);
            }

            args.setManagedOrderRow(managedOrder);
            args.setNewPrice(newPrice);
            tickUpDownAmendOrder.accept(args);
         } catch (Exception e) {
            e.printStackTrace();
         }
      }
   }

   private StepArray getStepArrayForInstrument(String secCode, String boardId){
      try {
         NumberContext priceContext = securitiesDataModule.getStaticInfo(secCode, boardId).get().priceContext;
         return priceContext.getSpinStepArray();
      } catch (Exception e) {
         e.printStackTrace();
      }
      return null;
   }
   private void doReferAllButtonAction(ReferArgs args) {
      if (referAllOrders != null)
         referAllOrders.accept(args);
   }

   private void doHitTakeButtonAction(PopupOrderEntryArgs args) {
      if (hitTakeOrder != null)
         hitTakeOrder.accept(args);
   }

   private void doCMPriceColEntry(PopupOrderEntryArgs args) {
      if (enterCMOrder != null)
         enterCMOrder.accept(args);
   }

   private void doCMPriceColAmend(PopupOrderEntryArgs args) {
      if (amendCMOrder != null) {
         ObservableReplyRow secRow = args.getRow();
         BigDecimal matchPrice = secRow.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
         String secCode = secRow.getValue(AmpIcapSecBoardTrim2.secCode);
         boolean isSpreadReversal = securitiesDataModule.isSpreadForPriceReversal(secRow);

         ObservableList<ObservableReplyRow> myCM_OpenOrders = getMyCMOpenOrders(matchPrice, secCode, isSpreadReversal);
         ObservableList<ObservableReplyRow> firmCM_OpenOrders = getFirmCMOpenOrders(matchPrice, secCode, isSpreadReversal);
         if (!myCM_OpenOrders.isEmpty()) {
            ObservableReplyRow orderRow = myCM_OpenOrders.get(0);
            amendCMOrder.accept(new PopupOrderEntryArgs(orderRow, args.getNode(), args.getSide(), isSpreadReversal, PopupOrderEntryArgs.DefaultOn.SIZE));
         } else if (!firmCM_OpenOrders.isEmpty()) {
            // In this case we do not have our own order, only a colleague one
            // we still want to display the amend popup for seeing the colleague's order,
            // but we should also allow for order entry in it, so we need to provide
            // a security row inside instead of an order row
            amendCMOrder.accept(new PopupOrderEntryArgs(secRow, args.getNode(), args.getSide(), isSpreadReversal, PopupOrderEntryArgs.DefaultOn.SIZE));
         }
      }
   }

   private ObservableList<ObservableReplyRow> getMyCMOpenOrders(BigDecimal matchPrice, String secCode, boolean isSpreadReversal) {
      //filter all open CM orders
      // belonging to the logged in user's firm, but not to the user him (or her) self
      ObservableList<ObservableReplyRow> myCM_OpenOrders;
      if (matchPrice == null) {
         myCM_OpenOrders = FXCollections.emptyObservableList();
      } else if (isSpreadReversal) {
         myCM_OpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).own().isCM().build();
      } else {
         myCM_OpenOrders =
            ordersDataModule
               .getOpenOrdersBuilder()
               .ofSec(secCode)
               .own()
               .atCMPrice(matchPrice)
               .build();
      }
      return myCM_OpenOrders;
   }

   private ObservableList<ObservableReplyRow> getFirmCMOpenOrders(BigDecimal matchPrice, String secCode, boolean isSpreadReversal) {
      //filtered observable list of all open CM orders
      // belonging to the logged in user's firm, but not to the user him (or her) self
      ObservableList<ObservableReplyRow> firmCM_OpenOrders;
      if (matchPrice == null) {
         firmCM_OpenOrders = FXCollections.emptyObservableList();
      } else if (isSpreadReversal) {
         firmCM_OpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).colleagues().isCM().build();
      } else {
         firmCM_OpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).colleagues().atCMPrice(matchPrice).build();
      }
      return firmCM_OpenOrders;
   }


   private void doReferAllCMButtonAction(ReferArgs args) {
      if (referAllCMOrders != null)
         referAllCMOrders.accept(args);
   }

   private void doWorkupAction(WorkupArgs args) {
      if (workup != null)
         workup.accept(args);
   }

   private void doColumnsVisibilityAction(ColumnsSpec args) {
      if (columnsVisibilityAction != null) {
         columnsVisibilityAction.accept(args);
      }
   }

   private ObservableValue<Double> totalColFactory(ObservableReplyRow row, OrderSide side) {
      BigDecimal prvlgdPrice = row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngPrice);
      BigDecimal cmPrice = row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);

      Double total = (side == OrderSide.BUY) ?
         row.getValue(AmpIcapSecBoardTrim2.bidDepth_d) :
         row.getValue(AmpIcapSecBoardTrim2.offerDepth_d);
      Double finalTotal = total;
      if (cmPrice != null && prvlgdPrice != null && cmPrice.abs().doubleValue() == prvlgdPrice.abs().doubleValue()) {
         finalTotal = null;
      }

      Double finalTotal1 = finalTotal;
      return Bindings.createObjectBinding(() -> finalTotal1, row.rowProperty());
   }

   private Pair<BigDecimal, WatchListCellState> determinePriceAndCellState(ObservableReplyRow row, OrderSide side) {
      final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      BigDecimal prvlgdPrice = row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngPrice);
      BigDecimal cmPrice = row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
      BigDecimal price = (side == OrderSide.BUY) ? row.getValue(AmpIcapSecBoardTrim2.bidPrice) : row.getValue(AmpIcapSecBoardTrim2.offerPrice);
      int prvlgedSide = AmpIcapSecBoardTrim2.getAggressiveSide(row.getValue(AmpIcapSecBoardTrim2.aggressiveSide));
      BigDecimal finalPrice;
      WatchListCellState cellState = WatchListCellState.NONE;
      if (prvlgdPrice != null && side.isReverse(prvlgedSide) && // add workup style only if NOT CM workup
         (cmPrice == null || cmPrice.abs().doubleValue() != prvlgdPrice.abs().doubleValue())) {
         finalPrice = prvlgdPrice;
         cellState = WatchListCellState.WORKUP_CLOB_ORDER;

      } else if (cmPrice != null && prvlgdPrice != null && cmPrice.abs().doubleValue() == prvlgdPrice.abs().doubleValue()) {
         finalPrice = null;

      } else {
         finalPrice = price;
         ObservableList<ObservableReplyRow> myOpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).own().inSide(side).notCM().build();
         if (!myOpenOrders.isEmpty()) {
            cellState = WatchListCellState.MY_CLOB_ORDER;
         } else {
            ObservableList<ObservableReplyRow> firmOpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).colleagues().inSide(side).notCM().build();
            if (!firmOpenOrders.isEmpty()) {
               cellState = WatchListCellState.FIRM_CLOB_ORDER;
            }
         }
      }
      return new Pair<>(finalPrice, cellState);
   }

   private ObservableValue<PriceCellValue<BigDecimal>> priceColFactory(WatchlistRow watchlistRow, OrderSide side) {
      final ObservableReplyRow row = watchlistRow.getRow();
      final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      return Bindings.createObjectBinding(() -> {
         final Pair<BigDecimal, WatchListCellState> priceAndState = determinePriceAndCellState(row, side);
         final BigDecimal finalPrice = priceAndState.getKey();
         final WatchListCellState finalCellState = priceAndState.getValue();
         final PriceCellValue<BigDecimal> priceCellValue = new PriceCellValue<>(finalPrice);
         priceCellValue.setState(finalCellState);

         SecBoardStaticInfo staticInfo = securitiesDataModule.getStaticInfo(row);
         Function<Number, String> formatter = staticInfo.priceFormatter;
         priceCellValue.setFormatter(formatter);


         /* Handling CLOB Workup conditions */
         if (priceCellValue.isCLOBWorkup()) {
            final BigDecimal workupPrice = row.getValue(AmpIcapSecBoardTrim2.workupPrice);
            final boolean isSpreadForReversal = securitiesDataModule.isSpreadForPriceReversal(row);
            if (workupPrice != null) {
               final BigDecimal priceToShow = (side.equals(SELL) && isSpreadForReversal) ? workupPrice.negate() : workupPrice;
               final String value = priceCellValue.getFormatter().apply(priceToShow);
               priceCellValue.setFlashOffValue(value);

               final String tradingQty = row.getValue(AmpIcapSecBoardTrim2.prvlgdTradingQty);
               if (tradingQty != null) {
                  priceCellValue.setFlashOnValue(xstr.util.Util.getFlashingQuantityFormatter().format(Double.parseDouble(tradingQty)));
               } else {
                  priceCellValue.setFlashOnValue(value);
               }
            }
         }
         /* Handling CLOB Non-Workup conditions */
         else {
            boolean litWorkupState = AmpIcapSecBoardTrim2Util.isInLitWorkupState(row);
            boolean otherUserWorkup = !getLoggedInUserId().equals(AmpIcapSecBoardTrim2Util.getUserId(row, side));
            boolean otherSideWorkup = litWorkupState && otherUserWorkup;
            /* Only displaying the price, if it is not other side workup */
            if (!otherSideWorkup) {
               /* Setting the price string to display */
               priceCellValue.setFlashOffValue(priceCellValue.getFormatter().apply(finalPrice));

               /* Handling CLOB Price flash conditions */
               boolean priceChanged = side == OrderSide.BUY ? watchlistRow.isBidPriceChanged() : watchlistRow.isOfferPriceChanged();
               if (priceChanged) {
                  Future<Boolean> clobFlashingFuture = isSecurityEnabledForCLOBPriceFlashing(secCode);
                  while (!clobFlashingFuture.isDone()) {
                     /* Wait till the future is loaded */
                  }
                  clobFlashingFuture.map(enabled -> {
                     if (enabled) {
                        priceCellValue.setPriceFlashState(WatchListCellState.CLOB_PRICE_CHANGE_FLASHING);
                     }
                     return null;
                  });

                  /* Reset the price change flag */
                  if (side == OrderSide.BUY) {
                     watchlistRow.setBidPriceChanged(false);
                  } else {
                     watchlistRow.setOfferPriceChanged(false);
                  }
               }
            }
         }
         return priceCellValue;
      }, row.rowProperty());
   }

   private ObservableValue<PriceCellValue<BigDecimal>> matchColFactory(WatchlistRow watchlistRow) {
      final ObservableReplyRow row = watchlistRow.getRow();
      BigDecimal prvlgdTrdngPrice = row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngPrice);
      ObservableObjectValue<BigDecimal> matchPrice = row.getProperty(AmpIcapSecBoardTrim2.darkMatchPrice);

      final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      final String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);

      // We are in workup if match price equates to privileged trading price and both are non-null
      final boolean isWorkupTrade = prvlgdTrdngPrice != null && matchPrice.get() != null && prvlgdTrdngPrice.compareTo(matchPrice.get()) == 0;

      WatchListCellState state = WatchListCellState.NONE;
      if (isWorkupTrade) {
         state = WatchListCellState.WORKUP_CM_ORDER;
      } else {
         ObservableList<ObservableReplyRow> myCM_OpenOrders = matchPrice.get() == null ? FXCollections.emptyObservableList() :
            ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).own().isCM().atAbsCMPrice(matchPrice.get()).build();
         if (!myCM_OpenOrders.isEmpty()) {
            state = WatchListCellState.MY_CM_ORDER;
         } else {
            //filtered observable list of all open CM orders
            // belonging to the logged in user's firm, but not to the user him (or her) self
            ObservableList<ObservableReplyRow> firmCM_OpenOrders =
               ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).colleagues().isCM().build();
            if (!firmCM_OpenOrders.isEmpty()) {
               state = WatchListCellState.FIRM_CM_ORDER;
            } else if (watchlistRow.isCMWorkupTraded()) { // a workup was done on this price, but is no longer active
               state = WatchListCellState.CM_TRADE;
            }
         }
      }

      ObservableList<ObservableReplyRow> marketTrades = tradesDataModule.getMarketTradeData();
      WatchListCellState finalState = state;
      ObservableList<ObservableReplyRow> openOrdersBySec = ordersDataModule.getOpenOrdersBySec(row.getValue(AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId));
      return Bindings.createObjectBinding(() -> {
         BigDecimal finalPrice = matchPrice.get();
         final PriceCellValue<BigDecimal> priceCellValue = new PriceCellValue<>(finalPrice);
         priceCellValue.setState(finalState);

         /* Getting static info details */
         SecBoardStaticInfo staticInfo = securitiesDataModule.getStaticInfo(row);
         Function<Number, String> formatter = staticInfo.priceFormatter;
         priceCellValue.setFormatter(formatter);

         /* Setting the default price string */
         priceCellValue.setFlashOffValue(priceCellValue.getFormatter().apply(finalPrice));

         /* Handling CM Workup conditions */
         if (priceCellValue.isCMWorkup()) {
            BigDecimal workupPrice = row.getValue(AmpIcapSecBoardTrim2.workupPrice);
            if (workupPrice != null) {
               final String value = priceCellValue.getFormatter().apply(workupPrice);
               priceCellValue.setFlashOffValue(value);

               final String tradingQty = row.getValue(AmpIcapSecBoardTrim2.prvlgdTradingQty);
               if (tradingQty != null) {
                  priceCellValue.setFlashOnValue(xstr.util.Util.getFlashingQuantityFormatter().format(Double.parseDouble(tradingQty)));
               } else {
                  priceCellValue.setFlashOnValue(value);
               }
            }
         }

         /* Handling CM Price flash conditions (only for non-workup orders) */
         if (watchlistRow.isMatchPriceChanged() && !priceCellValue.isCMWorkup()) {
            Future<Boolean> cmFlashingFuture = isSecurityEnabledForCMPriceFlashing(secCode);
            while (!cmFlashingFuture.isDone()) {
               /* Wait till the future is loaded */
            }
            cmFlashingFuture.map(enabled -> {
               if (enabled) {
                  priceCellValue.setPriceFlashState(WatchListCellState.CM_PRICE_CHANGE_FLASHING);
               }
               return null;
            });
            /* Reset the flag */
            watchlistRow.setMatchPriceChanged(false);
         }
         return priceCellValue;
      }, openOrdersBySec, row.rowProperty(), marketTrades, matchPrice);
   }

   private ObservableValue<XfeAction> actionValueFactoryImpl(ObservableReplyRow row, OrderSide side) {
      return Bindings.createObjectBinding(() -> {
         XfeAction action;
         ReferArgs referArgs = new ReferArgs(row, side, false);
         WithdrawArgs withdrawArgs = new WithdrawArgs(row, side, false);

         // If the top of the book order belongs to another firm or to our firm but not shared, we put a Hit/Take action
         // If the top of the book order belongs to us then we put a Refer action
         // Otherwise, the top of the book is a shared firm order, so we put a Withdraw action
         String userId = null;
         BigDecimal bestPrice = null;
         String specialOrderType = null;
         if (side == OrderSide.BUY) {
            userId = row.getValue(AmpIcapSecBoardTrim2.bidUserId);
            bestPrice = row.getValue(AmpIcapSecBoardTrim2.bidPrice);
            specialOrderType = row.getValue(AmpIcapSecBoardTrim2.bidSpecialOrderType);
         } else if (side == OrderSide.SELL) {
            userId = row.getValue(AmpIcapSecBoardTrim2.offerUserId);
            bestPrice = row.getValue(AmpIcapSecBoardTrim2.offerPrice);
            specialOrderType = row.getValue(AmpIcapSecBoardTrim2.offerSpecialOrderType);
         }

         action = new XfeAction();
         action.setAvailable(false);
         // There is a top of the book order
         if (bestPrice != null) {
            boolean isIndicativePrice = Objects.equals(specialOrderType, PRICE_TYPE_INDICATIVE);
            String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
            final ObservableList<ObservableReplyRow> allOrdersOnSecurity = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).inSide(side).notCM().build();
            final ObservableList<ObservableReplyRow> myOpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).own().inSide(side).notCM().build();
            final boolean isWorkupState = AmpIcapSecBoardTrim2Util.isInLitWorkupState(row);
            if ((userId == null || userId.isEmpty()) && allOrdersOnSecurity.isEmpty() && !isIndicativePrice) {
               if (!isWorkupState) {
                  action = mineYoursAction(row, side);
                  action.setAvailable(true);
               }
            } else if (!myOpenOrders.isEmpty() && !isIndicativePrice) {
               action = referAllAction(referArgs);
               action.setAvailable(true);
            }

            if (!action.isAvailable()) {
               /* If no action is set and if the price has fingerprinting, then setting the withdraw action. */
               Pair<BigDecimal, WatchListCellState> priceAndState = determinePriceAndCellState(row, side);
               boolean hasFingerPrinting = priceAndState.getValue() == WatchListCellState.FIRM_CLOB_ORDER || priceAndState.getValue() == WatchListCellState.MY_CLOB_ORDER;
               if (hasFingerPrinting) {
                  action = withdrawAction(withdrawArgs);
                  action.setAvailable(true);
               }
            }
         }

         BigDecimal prvlgdPrice = row.getValue(AmpIcapSecBoardTrim2.prvlgdTrdngPrice);
         BigDecimal cmPrice = row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
         if (cmPrice != null && prvlgdPrice != null && cmPrice.abs().doubleValue() == prvlgdPrice.abs().doubleValue()) {
            action.setAvailable(false);
         }

         return action;
      }, ordersDataModule.getOpenOrdersBySec(row.getValue(AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId)), row.rowProperty());
   }

   private ObservableValue<XfeAction> CM_ActionValueFactoryImpl(ObservableReplyRow row, OrderSide side) {
      // If the user does not have a constant match bid then the cell will be blank
      // Clicking on "Withdraw" will withdraw own CM order first and then will withdraw the colleagues order based on it available in the queue..
      return Bindings.createObjectBinding(() -> {
         XfeAction action;
         WithdrawArgs withdrawArgs = new WithdrawArgs(row, side, true);
         if (canWithdrawCM(withdrawArgs)) {
            action = withdrawCMAction(withdrawArgs);
         } else {
            action = new XfeAction();
            action.setAvailable(false);
         }

         return action;
      }, ordersDataModule.getOpenOrdersBySec(row.getValue(AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId)), row.rowProperty());
   }

   private boolean canWithdrawCM(WithdrawArgs withdrawArgs) {
      AtomicBoolean canWithdraw = new AtomicBoolean(false);
      final String secCode = withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.secCode);
      final BigDecimal constantMatchPrice = withdrawArgs.getRow().getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
      Collection<ObservableReplyRow> withdrawList = constantMatchPrice == null ? FXCollections.emptyObservableList() :
         ordersDataModule.getOpenOrdersBuilder()
            .ofSec(secCode)
            .firm()
            .atAbsCMPrice(constantMatchPrice)
            .inSide(withdrawArgs.getSide())
            .build();
      activeSessionModule.getSession().ifPresent((session) -> {
         // We have a list of all our open orders for the designated side and the relevant security code
         // Now we need to see if any of them is a constant match order
         // (i.e. an order is CM if constant match price equals order's price and it is a dark order)
         // Any CM orders will be withdrawn
         // if order from both self and firm is present, 1st withdraw own order and then firm order
         for (ObservableReplyRow order : withdrawList) {
            if (Objects.equals(order.getValue(AmpManagedOrder.isDoneIfTouched), Boolean.TRUE)) {
               BigDecimal price = order.getValue(AmpManagedOrder.price);
               if (price == null && constantMatchPrice == null ||
                  price != null && constantMatchPrice != null && price.abs().compareTo(constantMatchPrice.abs()) == 0)
                  // can withdraw this  order
                  canWithdraw.set(true);
               break;
            }
         }
      });

      // If here then all relevant orders are CM, which means we cannot withdraw them
      return canWithdraw.get();
   }

   private XfeAction withdrawAction(WithdrawArgs withdrawArgs) {
      XfeAction action = new XfeAction();
      action.getStyleClass().add("xfe-icon-withdraw");
      action.setOnAction(ev -> {
         if (withdrawOrders != null) {
            withdrawOrders.accept(withdrawArgs);
         }
      });
      return action;
   }

   private XfeAction withdrawCMAction(WithdrawArgs withdrawArgs) {
      XfeAction action = new XfeAction();
      action.getStyleClass().add("xfe-icon-withdraw-cm");
      action.setOnAction(ev -> {
         if (withdrawCMOrders != null) {
            withdrawCMOrders.accept(withdrawArgs);
         }
      });
      return action;
   }

   private XfeAction referAllAction(ReferArgs referArgs) {
      XfeAction action = new XfeAction();
      action.getStyleClass().add("xfe-icon-withdraw");
      action.setOnAction(ev -> {
         if (referAllOrders != null) {
            referAllOrders.accept(referArgs);
         }
      });

      if (referArgs.getSide() == OrderSide.BUY) {
         //action.getStyleClass().add("table-view-bid-button");
      } else {
         //action.getStyleClass().add("table-view-offer-button");
      }

      return action;
   }

   private XfeAction referAllCMAction(ReferArgs referArgs) {
      XfeAction action = new XfeAction();
      action.getStyleClass().add("xfe-icon-refer");
      action.setText("X");
//      if (side == OrderSide.BUY) {
//         action.setText(">");
//      } else {
//         action.setText(">");
//      }
      action.setOnAction(ev -> {
         if (referAllCMOrders != null) {
            referAllCMOrders.accept(referArgs);
         }
      });

      if (referArgs.getSide() == OrderSide.BUY) {
         //action.getStyleClass().add("table-view-cm-button");
      } else {
         //action.getStyleClass().add("table-view-cm-button");
      }

      return action;
   }

   private XfeAction mineYoursAction(ObservableReplyRow row, OrderSide side) {
      XfeAction action = new XfeAction();
      if (side == OrderSide.BUY) {
         action.getStyleClass().add("xfe-icon-take");
      } else {
         action.getStyleClass().add("xfe-icon-hit");
      }

      action.setOnAction(ev -> {
         Object tmpObj = ev.getSource();
         CellButton cellButton = null;
         if (tmpObj instanceof CellButton) {
            cellButton = (CellButton) ev.getSource();
         }

         // When oneClickHitTake is setted, directly send transaction without pop over.
         // Otherwise, pop over the dialog for hit/take
         if (cellButton != null) {
            if (configurationModule.getData().oneClickHitTakeProperty().get()) {
               autoHitTake(row, side);
            } else {
               doHitTakeButtonAction(new PopupOrderEntryArgs(row, cellButton, side, null, PopupOrderEntryArgs.DefaultOn.PRICE));
            }
         }
      });

      return action;
   }

   private void autoHitTake(ObservableReplyRow row, OrderSide side) {
      AbstractOrderTrans orderTrans = new ManagedOrderTrans(null);

      String secCode = row.getStringProperty(AmpIcapSecBoardTrim2.secCode).getValue();
      orderTrans.setSecCode(secCode);
      String boardId = row.getStringProperty(AmpIcapSecBoardTrim2.boardId).getValue();
      orderTrans.setBoardId(boardId);

      // If this is a gilts spread we need to negate the price
      double priceReversal = securitiesDataModule.isSpreadForPriceReversal(row) ? -1.0 : 1.0;
      orderTrans.setPrice(side == OrderSide.BUY ? row.getValue(AmpIcapSecBoardTrim2.bidPrice_d) * priceReversal : row.getValue(AmpIcapSecBoardTrim2.offerPrice_d) * priceReversal);

      Double defaultQty = row.getValue(AmpIcapSecBoardTrim2.defaultQty_d);
      if (defaultQty == null) {
         defaultQty = getDefaultQty(row);
      }

      if (configurationModule.getData().yoursMineDefaultAmountProperty().get() != AmountType.DEFAULT) {
         defaultQty = (side == OrderSide.BUY)? row.getValue(AmpIcapSecBoardTrim2.bidDepth_d) : row.getValue(AmpIcapSecBoardTrim2.offerDepth_d);
      }

      orderTrans.setQuantity(defaultQty);
      orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
      orderTrans.setOnLogOffAction(OnLogoffAction.Default);
      // Setting the order tag
      String orderTag;
      if(configurationModule.getData().yoursMineOrderWithdrawProperty().get()){
         orderTag = Orders.CLOB;
      } else {
         orderTag = Orders.AGGRESSOR;
      }
      final MapWrapper mapWrapper = new MapWrapper();
      mapWrapper.put(Orders.ORDER_TAG_KEY, new XtrBlob(orderTag.getBytes()));
      orderTrans.setMapWrapper(mapWrapper);
      activeSessionModule.getSession().ifPresent(session -> orderTrans.executeBuySell(session, side.equals(OrderSide.BUY) ?
         AmpOrderVerb.sell : AmpOrderVerb.buy).onDone(x -> {
         XtrTransReply result = x.get();
         if (result.getStatus() != XtrTransReply.Status.RESULT_OK) {
            String errorMsg = result.getMessage();
            logger.warn("One-Click Hit Take: {}", errorMsg);
            // temporally commenting the toast notification
            // Toaster.toastError("Order Entry", errorMsg);
         }
         return Future.SUCCESS;
      }));
   }

   private Future<XtrTransReply> sendDefaultOrder(ObservableReplyRow row, Pair<OrderSide, Double> sidePriceParams) {
      AtomicReference<Future<XtrTransReply>> res = new AtomicReference<>(null);
      activeSessionModule.getSession().ifPresent(session -> {
         AbstractOrderTrans orderTrans = new ManagedOrderTrans(null);
         final String sec = row.getStringProperty(AmpIcapSecBoardTrim2.secCode).getValue();
         orderTrans.setSecCode(sec);
         orderTrans.setBoardId(row.getStringProperty(AmpIcapSecBoardTrim2.boardId).getValue());
         orderTrans.setPrice(sidePriceParams.getValue());
         Double defaultQty = row.getValue(AmpIcapSecBoardTrim2.defaultQty_d);
         if (defaultQty == null)
            defaultQty = getDefaultQty(row);
         orderTrans.setQuantity(defaultQty);
         orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DAY);
         orderTrans.setOnLogOffAction(configurationModule.getData().onLogoffActionProperty().get());
         orderTrans.setShared(configurationModule.getData().sharedOrdersProperty().get());
         orderTrans.setTopCut(configurationModule.getData().topCutProperty().get());
         // For default order the order tag is CLOB
         MapWrapper mapWrapper = new MapWrapper();
         mapWrapper.put(Orders.ORDER_TAG_KEY, new XtrBlob(Orders.CLOB.getBytes()));
         orderTrans.setMapWrapper(mapWrapper);
         Future<XtrTransReply> xtrTransReplyFuture = orderTrans.executeBuySell(session, sidePriceParams.getKey().equals(OrderSide.BUY) ? AmpOrderVerb.buy : AmpOrderVerb.sell);
         xtrTransReplyFuture.onDone(
            x -> {
               if (x.get().getStatus() != XtrTransReply.Status.RESULT_OK) {
                  String errorMsg = x.get().getMessage();
                  logger.error("onBidOffer: {}", errorMsg);
                  // temporally commenting the toast notification
                  //Toaster.toastError("Order Entry", errorMsg);
               }

               return Future.SUCCESS;
            }
         );
         res.set(xtrTransReplyFuture);
      });
      return res.get();
   }

   private Double getDefaultQty(ObservableReplyRow row) {
      Integer secClassId = row.getValue(AmpIcapSecBoardTrim2.secClassId);

      if (secClassId != null && secClassId == AmpSecClassId.strategy)
         return configurationModule.getData().strategyDefaultQtyProperty().get();

      return configurationModule.getData().outrightDefaultQtyProperty().get();
   }

   private Integer priceCellFlashDuration() {
      // Set the price cell flash timeout.
      return configurationModule.getData().priceCellFlashDuration().getValue();
   }

   private SecTabs secTabs;

   // Handlers from external modules
   private Consumer<PopupOrderEntryArgs> enterOrder;
   private Consumer<PopupOrderEntryArgs> amendOrder;
   private Consumer<TickUpDownAmendArgs> tickUpDownAmendOrder;
   private Consumer<WithdrawArgs> withdrawOrders;
   private Consumer<WithdrawArgs> withdrawCMOrders;
   private Consumer<ReferArgs> referAllOrders;
   private Consumer<PopupOrderEntryArgs> hitTakeOrder;
   private Consumer<PopupOrderEntryArgs> enterCMOrder;
   private Consumer<PopupOrderEntryArgs> amendCMOrder;
   private Consumer<ReferArgs> referAllCMOrders;
   private Consumer<WorkupArgs> workup;
   private Consumer<ColumnsSpec> columnsVisibilityAction;
   private Consumer<TradesAggregateArgs> tradesAggregatePopupHandler;
   private final ObjectProperty<WatchlistRow> selectedSecurityRow = new SimpleObjectProperty<>(null);


   private ObjectProperty<ObservableList<InstrumentKey>> fullHighlightedList;
   private ObjectProperty<ObservableList<InstrumentKey>> halfHighlightedList;

   private WatchlistSpec_v2 activesSpec;
   private WatchListTab activesTab;
   private QueryFeed activesFeedSrc;
   private SecurityWatchlist activesWatchlist;
   private Comparator<Security> activesComp = (s1, s2) -> {
      // Sorting first by product and then by maturity date
      try {
         // TODO: Verify that accessing the secBoard futures synchronously at this point in time cannot create a potential blocking issue
         // If it does, then we will have to only add an active security to the set when we know secboard info is available
         if (s1 == null && s2 == null) return 0;

         if (s1 == null) return 1;

         if (s2 == null) return -1;

         final String prod1 = s1.getProductId();
         final String prod2 = s2.getProductId();

         SecBoards secBoards = securitiesDataModule.getSecboards();

         Instrument inst1 = secBoards.getInstById(prod1).get();
         Instrument inst2 = secBoards.getInstById(prod2).get();

         // First trying to sort using product's sortOrder defined in db
         int prodComp1 = 0;
         if (inst1 != null && inst1.getSortOrder() != null && inst2 != null && inst2.getSortOrder() != null)
            prodComp1 = Long.compare(inst1.getSortOrder(), inst2.getSortOrder());
         if (prodComp1 != 0) return prodComp1;

         // Trying alphabetical sorting on product name to decide
         int prodComp2 = prod1.compareTo(prod2);

         if (prodComp2 != 0) return prodComp2;

         // We need to rely now on the security itself for comparison

         // For non gilt strategies we can use maturity date
         SecBoard sb1 = secBoards.getFirstBySecCode(s1.getSecCode()).get();
         SecBoard sb2 = secBoards.getFirstBySecCode(s2.getSecCode()).get();

         if (sb1 == null && sb2 == null)
            return 0;
         else if (sb1 == null)
            return 1;
         else if (sb2 == null)
            return -1;
         else if (sb1.isStrategy() && sb1.isGilt() && sb2.isStrategy() && sb2.isGilt())
            return Comparator.comparing(SecBoard::getStrategyInfo).compare(sb1, sb2);
         else
            return Comparator.comparing(SecBoard::getMaturityDateAsLong).thenComparing(SecBoard::getSecCode).compare(sb1, sb2);
      } catch (Exception e) {
         logger.error("Security Comparator : {}", e.getMessage());
         logger.debug("Security Comparator ", e);
      }

      return 0;
   };

   private Set<Security> includedActives = new TreeSet<>(activesComp);
   private Set<Security> excludedActives = new HashSet<>();
   private QueryFeedListener activesFeedListener;
   private ObservableList<WatchlistSpec_v2> watchlists;
   private ChangeListener<Tab> tabChangeListener;
   private ListChangeListener<WatchlistSpec_v2> watchListListener;


   private void clearActives() {
      includedActives.clear();
      excludedActives.clear();
      activesSpec = activesSpec.withSecurities(new ArrayList<>(includedActives));
      // Actives tab also start/stop polling depend on selection condition so do auto-polling depend on it
      activesWatchlist.setSpec(activesSpec, activesTab.isSelected());
   }

   private void removeActive(String secCode) {
      securitiesDataModule.getSecboards().getFirstBySecCode(secCode).map(sb -> {
         excludedActives.remove(new Security(sb.getInstrumentId(), secCode));
         if (includedActives.remove(new Security(sb.getInstrumentId(), secCode))) {
            activesSpec = activesSpec.withSecurities(new ArrayList<>(includedActives)).withAutoHeadings();
            // Actives tab also start/stop polling depend on selection condition so do auto polling depend on it
            activesWatchlist.setSpec(activesWatchlist.adjustHeadingsState(activesSpec), activesTab.isSelected());
         }

         return Future.SUCCESS;
      });
   }

   private void addActive(String secCode) {
      securitiesDataModule.getSecboards().getFirstBySecCode(secCode).map(sb -> {
         if (isInstrumentEnabledForActives(sb.getInstrumentId())) {
            if (includedActives.add(new Security(sb.getInstrumentId(), secCode))) {
               activesSpec = activesSpec.withSecurities(new ArrayList<>(includedActives)).withAutoHeadings();
               // Actives tab also start/stop polling depend on selection condition so do auto-polling depend on it.
               activesWatchlist.setSpec(activesWatchlist.adjustHeadingsState(activesSpec), activesTab.isSelected());
            }
         } else {
            excludedActives.add(new Security(sb.getInstrumentId(), secCode));
         }
         return Future.SUCCESS;
      });
   }

   private boolean isInstrumentEnabledForActives(String instrumentId) {
      InstrumentSettingsSpec instrumentSettingsSpec = getInstrumentSettingsSpec(instrumentId);
      return instrumentSettingsSpec != null && instrumentSettingsSpec.isActiveTabs();
   }

   public Future<Boolean> isSecurityEnabledForCMPriceFlashing(String secCode) {
      return securitiesDataModule.getSecboards().getFirstBySecCode(secCode).map(sb -> {
         InstrumentSettingsSpec instrumentSettingsSpec = getInstrumentSettingsSpec(sb.getInstrumentId());
         return instrumentSettingsSpec != null && instrumentSettingsSpec.isFlashOnCMPriceChange();
      });
   }

   public Future<Boolean> isSecurityEnabledForCLOBPriceFlashing(String secCode) {
      return securitiesDataModule.getSecboards().getFirstBySecCode(secCode).map(sb -> {
         InstrumentSettingsSpec instrumentSettingsSpec = getInstrumentSettingsSpec(sb.getInstrumentId());
         return instrumentSettingsSpec != null && instrumentSettingsSpec.isFlashOnCLOBPriceChange();
      });
   }

   private InstrumentSettingsSpec getInstrumentSettingsSpec(String instrumentId) {
      try {
         ObservableList<InstrumentSettingsSpec> instrumentSettingsSpecs = configurationModule.getData().instrumentSettingsProperty().get();
         InstrumentSettingsSpec spec = InstrumentSettingsSpec.getSpecByInstrumentId(instrumentSettingsSpecs, instrumentId);
         if (spec == null) {
            spec = InstrumentSettingsSpec.getSpecByInstrumentId(instrumentSettingsSpecs, InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
         }
         return spec;
      } catch (Exception ex) {
         logger.warn("Failed to fetch the instrument settings spec for {} : Error cause {}", instrumentId, ex.getMessage());
      }
      return null;
   }

   private HeadingSpec getHeadingSpec(String headingName) {
      try {
         ObservableList<HeadingSpec> headingSpecs = configurationModule.getData().headingsSpecProperty().get();
         HeadingSpec spec = HeadingSpec.getSpecByHeadingName(headingSpecs, headingName);
         if (spec == null) {
            spec = new HeadingSpec(headingName, false);
            headingSpecs.add(spec);
         }
         return spec;
      } catch (Exception ex) {
         logger.error("Failed to fetch the header spec for {} : {}", headingName, ex.getMessage());
         logger.info("Failed to clean up obsolete data of headingsSpecProperty : ", ex);
      }
      return null;
   }

   private void cleanUpObsoleteHeadings() {
      try {
         ObservableList<HeadingSpec> headingSpecs = configurationModule.getData().headingsSpecProperty().get();
         List<String> allInstrs = securitiesDataModule.getSecboards().instrs.stream().map(Instrument::getInstrumentId).collect(Collectors.toList());
         List<HeadingSpec> obsoletes = new ArrayList<>();

         for (HeadingSpec spec : headingSpecs) {
            if (!allInstrs.contains(spec.getHeadingName())) {
               obsoletes.add(spec);
            }
         }

         if (!obsoletes.isEmpty())
            headingSpecs.removeAll(obsoletes);
      } catch (Exception ex) {
         logger.error("Failed to clean up obsolete data of headingsSpecProperty : {}", ex.getMessage());
         logger.info("Failed to clean up obsolete data of headingsSpecProperty :", ex);
      }
   }

   public void refreshActives() {
      if (activesSpec != null && activesWatchlist != null) {
         Set<Security> included = new HashSet<>();
         included.addAll(includedActives);
         included.addAll(excludedActives);
         Set<Security> excluded = included.stream().filter(security -> !isInstrumentEnabledForActives(security.getProductId())).collect(Collectors.toSet());
         included.removeAll(excluded);

         // Updating the cache and refreshing the watchlist
         includedActives.clear();
         includedActives.addAll(included);
         activesSpec = activesSpec.withSecurities(new ArrayList<>(includedActives)).withAutoHeadings();
         // Actives tab also start/stop polling depend on selection condition so do auto-polling depend on it
         activesWatchlist.setSpec(activesWatchlist.adjustHeadingsState(activesSpec), activesTab.isSelected());

         excludedActives.clear();
         excludedActives.addAll(excluded);
      }
   }

   public void setTradesAggregatePopupHandler(Consumer<TradesAggregateArgs> tradesAggregatePopupHandler) {
      this.tradesAggregatePopupHandler = tradesAggregatePopupHandler;
   }

   private void doTradesAggregatePopupAction(TradesAggregateArgs args) {
      if (tradesAggregatePopupHandler != null)
         tradesAggregatePopupHandler.accept(args);
   }

   private String getLoggedInUserId() {
      Optional<ServerSession> session = activeSessionModule.getSession();
      if (session.isPresent()) {
         return session.get().getLoggedOnUser().getUserId();
      }
      return "";
   }
}
