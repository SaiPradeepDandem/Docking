package xfe.icap.modules.tradesui;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import xfe.icap.amp.AmpActions;
import xfe.ui.table.AlignedTableColumn;
import xfe.ui.table.Tables;
import xfe.util.Util;
import xstr.session.ObservableReplyRow;

import java.math.BigDecimal;
import java.util.Date;
import java.util.function.BiConsumer;

public class TradeStatsTable extends TableView<ObservableReplyRow> {
   TradeStatsTable(){
      setPlaceholder(Tables.stripedRowCSSPlaceholder());

      TableColumn<ObservableReplyRow, String> secCol = new AlignedTableColumn<>("Instrument", HPos.CENTER);
      secCol.getStyleClass().add("xfe-bold-text");
      secCol.setCellValueFactory(this::getStrippedPrefixSecCode);
      getColumns().add(secCol);

      TableColumn<ObservableReplyRow, String> priceCol = new AlignedTableColumn<>("Price", HPos.CENTER);
      priceCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpActions.message));
      priceCol.setCellFactory(param -> new TableCell<ObservableReplyRow, String>() {
         @Override
         protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
               setText(null);
            } else {
               if (priceFormatter != null) {

                  priceFormatter.accept(this, parsePriceToBigDecimal(item));
               } else {
                  setText(item.toString());
               }
            }
         }
      });
      getColumns().add(priceCol);

      TableColumn<ObservableReplyRow, String> buyersCol = new AlignedTableColumn<>("Buyers", HPos.CENTER);
      buyersCol.setCellValueFactory(this::parseBuyersFromMessage);
      getColumns().add(buyersCol);

      TableColumn<ObservableReplyRow, String> sellersCol = new AlignedTableColumn<>("Sellers", HPos.CENTER);
      sellersCol.setCellValueFactory(this::parseSellersFromMessage);
      getColumns().add(sellersCol);

      TableColumn<ObservableReplyRow, Date> timeCol = new AlignedTableColumn<>("Time", HPos.CENTER);
      timeCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpActions.actionTime));
      timeCol.setCellFactory(param -> new TableCell<ObservableReplyRow, Date>() {
         @Override
         protected void updateItem(Date item, boolean empty) {
            super.updateItem(item, empty);
            if (item == null) {
               setText(null);
            } else {
               setText(Util.formatTime(item));
            }
         }
      });
      getColumns().add(timeCol);
   }

   private ObservableValue<String> getStrippedPrefixSecCode(TableColumn.CellDataFeatures<ObservableReplyRow, String> cd) {
      return new ReadOnlyObjectWrapper(Util.stripper(cd.getValue().getProperty(AmpActions.secCode).get(), "UKT"));
   }

   private BigDecimal parsePriceToBigDecimal(String item) {
      String tmpStrArr[] = item.split("PRICE");
      return new BigDecimal(Double.parseDouble(tmpStrArr[1].trim()));
   }

   private ObservableValue<String> parseBuyersFromMessage(TableColumn.CellDataFeatures<ObservableReplyRow, String> cd) {
      String msg = cd.getValue().getProperty(AmpActions.message).get();
      String tmpStrArr[] = msg.split("AND");
      String tmpStr = tmpStrArr[0];
      int idxColon = tmpStr.indexOf(":");
      if(idxColon != -1){
         return new ReadOnlyObjectWrapper(getTradersCount(tmpStr.substring(idxColon+1), "BUYERS"));
      }
      return new ReadOnlyObjectWrapper(getTradersCount(tmpStr, "BUYERS"));
   }

   private ObservableValue<String> parseSellersFromMessage(TableColumn.CellDataFeatures<ObservableReplyRow, String> cd) {
      String msg = cd.getValue().getProperty(AmpActions.message).get();
      String tmpStrArr[] = msg.split("AND");
      String tmpStr = tmpStrArr[1];
      return new ReadOnlyObjectWrapper(getTradersCount(tmpStr, "SELLERS"));
   }

   private static String getTradersCount(String s, String phrase){
      int idx = s.indexOf(phrase);
      if(idx != -1) {
         String countsStr = s.substring(0, idx);
         return countsStr.trim();
      }
      else{
         return "";
      }
   }

   public void setPriceFormatter(BiConsumer<TableCell<ObservableReplyRow, String>, BigDecimal> priceFormatter) {
      this.priceFormatter = priceFormatter;
   }

   private BiConsumer<TableCell<ObservableReplyRow, String>, BigDecimal> priceFormatter;
}
