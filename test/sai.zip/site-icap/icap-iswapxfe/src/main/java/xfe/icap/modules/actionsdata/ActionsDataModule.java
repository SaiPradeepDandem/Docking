package xfe.icap.modules.actionsdata;

import com.omxgroup.xstream.amp.AmpActionsType_v2;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import xfe.icap.amp.AmpActions;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.session.ObservableReplyRow;
import xstr.session.QueryFeed;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import xstr.util.concurrent.Future;

import java.util.Comparator;
import java.util.function.Predicate;

import static xstr.util.filter.RowFilters.fieldEqual;

@Module.Autostart
public class ActionsDataModule extends SessionScopeModule {
   private ObservableList<ObservableReplyRow> actions;
   private QueryFeed feed;
   private FeedAggregator<ObservableReplyRow> aggregator;

   @Override
   public Future<Void> startModule() {
      aggregator = new FeedAggregator<>(AmpActions.rep, new ObservableReplyRow.ObservableRowFactory());

      activeSessionModule.getSession().ifPresent((session) -> {
         feed = session.getFeedSource(AmpActions.req);
         feed.addListener(aggregator);
      });

      actions = Fx.sortBy(aggregator.items, Comparator.reverseOrder());
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      if (feed != null) {
         feed.removeListener(aggregator);
         feed = null;
      }
      return Future.SUCCESS;
   }

   public ObservableList<ObservableReplyRow> getStats() {
      return activeSessionModule.getSession().map((session) -> {
         Predicate<ObservableReplyRow> p =
            fieldEqual(AmpActions.msgType, AmpActionsType_v2.stats);
         return (ObservableList<ObservableReplyRow>) actions.filtered(p);
      }).orElse(FXCollections.emptyObservableList());
   }
}
