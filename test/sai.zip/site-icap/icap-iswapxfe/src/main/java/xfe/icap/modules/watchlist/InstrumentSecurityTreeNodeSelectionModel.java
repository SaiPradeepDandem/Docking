package xfe.icap.modules.watchlist;

import xstr.util.collection.ObservableListTransformer;

import javafx.collections.ObservableList;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.TreeItem;
import xfe.modules.watchlist.InstrumentSecurityTreeNode;

public class InstrumentSecurityTreeNodeSelectionModel extends MultipleSelectionModel<InstrumentSecurityTreeNode> {
	private final MultipleSelectionModel<TreeItem<InstrumentSecurityTreeNode>> treeSelectionModel;
	private ObservableListTransformer<InstrumentSecurityTreeNode, TreeItem<InstrumentSecurityTreeNode>> _itemToNodeTransformer;

	public InstrumentSecurityTreeNodeSelectionModel(MultipleSelectionModel<TreeItem<InstrumentSecurityTreeNode>> treeSelectionModel) {
		this.treeSelectionModel = treeSelectionModel;
	}

	@Override
	public ObservableList<Integer> getSelectedIndices() {
		return treeSelectionModel.getSelectedIndices();
	}

	@Override
	public ObservableList<InstrumentSecurityTreeNode> getSelectedItems() {
		return getObservableListTransformer().getItems();
	}

	private ObservableListTransformer<InstrumentSecurityTreeNode, TreeItem<InstrumentSecurityTreeNode>> getObservableListTransformer() {
		if (_itemToNodeTransformer == null) {
			_itemToNodeTransformer = new ObservableListTransformer<InstrumentSecurityTreeNode, TreeItem<InstrumentSecurityTreeNode>>(treeSelectionModel.getSelectedItems()) {
				@Override
				protected InstrumentSecurityTreeNode transform(TreeItem<InstrumentSecurityTreeNode> treeItem) {
					return treeItem != null ? treeItem.getValue() : null;
				}
			};
		}

		return _itemToNodeTransformer;
	}

	@Override
	public void selectIndices(int paramInt, int... paramArrayOfInt) {
		treeSelectionModel.selectIndices(paramInt, paramArrayOfInt);
	}

	@Override
	public void selectAll() {
		treeSelectionModel.selectAll();
	}

	@Override
	public void selectFirst() {
		treeSelectionModel.selectFirst();
	}

	@Override
	public void selectLast() {
		treeSelectionModel.selectLast();
	}

	@Override
	public void clearAndSelect(int paramInt) {
		treeSelectionModel.clearAndSelect(paramInt);
	}

	@Override
	public void select(int paramInt) {
		treeSelectionModel.select(paramInt);
	}

	@Override
	public void select(InstrumentSecurityTreeNode paramT) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void clearSelection(int paramInt) {
		treeSelectionModel.clearSelection(paramInt);
	}

	@Override
	public void clearSelection() {
		treeSelectionModel.clearSelection();
	}

	@Override
	public boolean isSelected(int paramInt) {
		return treeSelectionModel.isSelected(paramInt);
	}

	@Override
	public boolean isEmpty() {
		return treeSelectionModel.isEmpty();
	}

	@Override
	public void selectPrevious() {
		treeSelectionModel.selectPrevious();
	}

	@Override
	public void selectNext() {
		treeSelectionModel.selectNext();
	}
}
