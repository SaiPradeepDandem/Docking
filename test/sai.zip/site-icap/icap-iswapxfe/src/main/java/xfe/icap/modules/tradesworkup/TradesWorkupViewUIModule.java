package xfe.icap.modules.tradesworkup;

import com.nomx.domain.types.DefaultDurationType;
import com.nomx.instrumentsettings.InstrumentSettingsSpec;
import com.nomx.persist.watchlist.WatchlistSpec_v2;
import com.nomx.persist.watchlist.WatchlistSpec_v2.Security;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import com.omxgroup.xstream.amp.AmpStrategyTradeType_v2;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.AmpMarketTrade;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.amp.AmpTrade;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.ordersdata.OrdersDataModule;
import xfe.icap.modules.sectabsui.SecTabsUIModule;
import xfe.icap.modules.securities.SecuritiesDataModule;
import xfe.icap.modules.securities.SecurityWatchlist;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.icap.modules.tradesdata.TradesDataModule;
import xfe.icap.types.AbstractOrderTrans;
import xfe.icap.types.ManagedOrderTrans;
import xfe.icap.types.OrderTrans;
import xfe.icap.types.Orders;
import xfe.module.Module;
import xfe.modules.actions.WorkupArgs;
import xfe.modules.session.SessionScopeModule;
import xfe.types.OrderType;
import xfe.types.OrdersTrans;
import xfe.types.SecBoard;
import xfe.types.SecBoardStaticInfo;
import xstr.amp.AsnConversionAccessor;
import xstr.session.ObservableReplyRow;
import xstr.session.XtrTransReply;
import xstr.types.MapWrapper;
import xstr.types.OrderSide;
import xstr.types.XtrBlob;
import xstr.util.Fx;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import static xfe.icap.modules.tradesworkup.WorkupConstants.*;

@Module.Autostart
public class TradesWorkupViewUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradesWorkupViewUIModule.class);

   public static String FORCE_OPEN = "showCenter";

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public SecTabsUIModule secTabsUIModule;

   @ModuleDependency
   public TradesDataModule tradesDataModule;

   @ModuleDependency
   public OrdersDataModule ordersDataModule;

   @ModuleDependency
   public SecuritiesDataModule securitiesDataModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   // Keeps track of workups which are manually closed.
   private final Set<String> closedWorkupSecCodes = new HashSet<>();

   // Keeps track of workups that were auto opened.
   private final Set<String> autoWorkupSessions = new HashSet<>();

   // Keeps track of all the active workups secCodes and there session numbers. (including the closed secCodes)
   private final Map<String, TradeData> activeWorkupSecCodes = new HashMap<>();

   // Keeps track of secCode and its related orders.
   private final List<SecCodeAndOrders> secCodeAndOrdersList = new ArrayList<>();

   // Keeps track for all Securities of all active workups.
   private final List<Security> secs = new ArrayList<>();

   // WatchList to listen to the changes for the SecBoards.
   private SecurityWatchlist watchlist;
   private final Map<String, WorkupDITArgs> secCodeDITMap = new HashMap<>();

   private ListChangeListener<? super ObservableReplyRow> marketTradeDataListener;
   private ListChangeListener<? super ObservableReplyRow> tradeDataListener;
   private ListChangeListener<? super ObservableReplyRow> watchlistListener;

   @Override
   public Future<Void> startModule() {
      this.watchlist = securitiesDataModule.createWatchlist(TradesWorkupViewUIModule.class.getName());
      this.watchlist.setSpec(new WatchlistSpec_v2());
      this.secTabsUIModule.setWorkupHandler(this::openWorkup);
      this.tradesWorkupLayout = TradesWorkupLayout.load();
      addHandlersToLayout();

      // Loading and listening to trades to identify the workups.
      tradesDataModule.getTradeData().addListener(getTradeDataListener());

      //Loading and listening to market trades without firm information to identify 3rd party workups.
      tradesDataModule.getMarketTradeData().addListener(getMarketTradeDataListener());

      //Adds listener to watchlist to trigger the workup pop up.
      watchlist.getItems().addListener(getWatchlistListener());
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      // Remove Reply handler first then stop tradesWorkupLayout and clear all handler belong to tradesWorkupLayout.
      // When WU popup is opening and do log off, it cause some exception & error cases in watchlist(SecurityWatchlist)
      midiLayoutModule.removeView(tradesWorkupLayout.getRoot());
      tradesDataModule.getTradeData().removeListener(getTradeDataListener());
      tradesDataModule.getMarketTradeData().removeListener(getMarketTradeDataListener());
      watchlist.getItems().removeListener(getWatchlistListener());
      clearHandlersToLayout();
      tradesWorkupLayout.removeAllRow();
      tradesWorkupLayout = null;
      this.secTabsUIModule.setWorkupHandler(null);
      securitiesDataModule.stopAndCleanWatchList(this.watchlist);
      this.watchlist = null;
      secCodeAndOrdersList.forEach(SecCodeAndOrders::dispose);
      secCodeAndOrdersList.clear();
      return Future.SUCCESS;
   }

   public WorkupDITArgs getDITInfo(String secCode) {
      return secCodeDITMap.get(secCode);
   }

   /**
    * Adds all the required handlers to the layout.
    */
   private void addHandlersToLayout() {
      /* Setting handler for closing the workup row. */
      this.tradesWorkupLayout.setCloseHandler((ObservableReplyRow row) -> {
         final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         closedWorkupSecCodes.add(secCode);
         disposeSecBoardAndOrders(row);
      });

      /* Setting handler for removing the workup row when its session is timed out. */
      this.tradesWorkupLayout.setRemoveHandler((ObservableReplyRow row) -> {
         final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         try {
            disposeSecBoardAndOrders(row);
            activeWorkupSecCodes.remove(secCode);
            closedWorkupSecCodes.remove(secCode);
            secs.remove(new Security(null, secCode));
            watchlist.setSpec(new WatchlistSpec_v2().withSecurities(secs));
         } catch (Exception e) {
            e.printStackTrace();
         }
      });

      /* Setting handler to get the default quantity from configuration. */
      this.tradesWorkupLayout.setDefaultQuantityHandler((Integer secClassId) -> midiLayoutModule.getDefaultQuantity(secClassId));

      /* Setting handler to withdraw the open orders for the provided secCode & order side. */
      this.tradesWorkupLayout.setWithdrawHandler((row, orderSide) -> activeSessionModule.getSession().ifPresent(serverSession -> {
         //String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         //String boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
         //OrdersTrans.withdrawBySecBoardAndOrderSide(serverSession, new Pair<>(secCode, boardId), orderSide);

         String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         BigDecimal workupPriceABS = row.getValue(AmpIcapSecBoardTrim2.workupPrice).abs();
         ObservableList<ObservableReplyRow> myOpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).own().inSide(orderSide).build();
         if (!myOpenOrders.isEmpty()) {
            for (ObservableReplyRow orderRow : myOpenOrders) {
               if (orderRow.getValue(AmpManagedOrder.price).abs().compareTo(workupPriceABS) == 0) {
                  OrdersTrans.withdrawByOrderId(serverSession, orderRow.getAsn(AmpManagedOrder.currentOrderId));
               }
            }
         }
      }));

      this.tradesWorkupLayout.setReadCurrentOrderTag( row -> {
         String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         BigDecimal workupPriceABS = row.getValue(AmpIcapSecBoardTrim2.workupPrice).abs();
         String orderTag = null;
         // Fetch the current active order
         final Optional<SecCodeAndOrders> ordersInTheSecurity = secCodeAndOrdersList.stream().filter(sc -> sc.secCode.equals(secCode)).findFirst();
         if(ordersInTheSecurity.isPresent()){
            final Comparator<ObservableReplyRow> orderEntryTime = Comparator.comparing(o -> o.getValue(AmpManagedOrder.entryTime));
            final Predicate<ObservableReplyRow> priceMatch = order -> order.getValue(AmpManagedOrder.price).equals(workupPriceABS);
            final Optional<ObservableReplyRow> orderActive = ordersInTheSecurity.get().orders.stream()
               .sorted(orderEntryTime.reversed())
               .filter(priceMatch).findFirst();
         if(orderActive.isPresent()){
            orderTag = orderActive.get().getString(AmpManagedOrder.orderTag);
         }
         }

         if(orderTag == null){
            orderTag = configurationModule.getData().yoursMineOrderWithdrawProperty().get() ? Orders.CLOB : Orders.AGGRESSOR;
         }
         return orderTag;
      });

      this.tradesWorkupLayout.setColleagueWithdrawHandler((row, orderSide) -> activeSessionModule.getSession().ifPresent(serverSession -> {
         String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
         BigDecimal workupPriceABS = row.getValue(AmpIcapSecBoardTrim2.workupPrice).abs();
         ObservableList<ObservableReplyRow> notMyOpenOrders = ordersDataModule.getOpenOrdersBuilder().ofSec(secCode).colleagues().inSide(orderSide).build();
         if (!notMyOpenOrders.isEmpty()) {
            for (ObservableReplyRow orderRow : notMyOpenOrders) {
               if (orderRow.getValue(AmpManagedOrder.price).abs().compareTo(workupPriceABS) == 0) {
                  OrdersTrans.withdrawByOrderId(serverSession, orderRow.getAsn(AmpManagedOrder.currentOrderId));
               }
            }
         }
         //OrdersTrans.withdrawColleagueBySecBoardAndOrderSide(serverSession, new Pair<>(secCode, boardId), orderSide);
      }));

      /* Setting handler to place the order with the provided secCode, quantity & order side. */
      this.tradesWorkupLayout.setPlaceOrderHandler((row, orderParams) -> activeSessionModule.getSession().ifPresent(serverSession -> {
         // for a CM amend we need to send a day hidden order
         boolean isImmediate = !orderParams.isCM;
         boolean isDark = orderParams.isCM;
         boolean isManaged = true;
         final int buySell = orderParams.orderSide.equals(OrderSide.BUY) ? AmpOrderVerb.buy : AmpOrderVerb.sell;
         final AbstractOrderTrans orderTrans = isManaged ? new ManagedOrderTrans(null) : new OrderTrans(null);
         orderTrans.setQuantity(orderParams.quantity);
         populateTransactionData(row, orderTrans, isImmediate, isDark, orderParams.orderSide,orderParams.orderTag);
         final Future<XtrTransReply> reply = orderTrans.executeBuySell(serverSession, buySell);
         reply.onDone(x -> {
            if (x.get().getStatus() != XtrTransReply.Status.RESULT_OK) {
               tradesWorkupLayout.showErrorMessage(x.get().getMessage());

            } else {
               // If the transaction is successful then refreshing the quantities.
               handleQuantityUpdates();
            }
            return Future.SUCCESS;
         });
      }));

      /* Setting handler to return the current engine time */
      this.tradesWorkupLayout.setEngineTimeHandler(() -> activeSessionModule.getSession().get().getStats().getEngineTime());

      /* Setting the supplier to get the DIT args map */
      this.tradesWorkupLayout.setDitArgsMapSupplier(() -> secCodeDITMap);

   }

   /**
    * Adds all the required handlers to the layout.
    */
   private void clearHandlersToLayout() {
      this.tradesWorkupLayout.setCloseHandler(null);
      this.tradesWorkupLayout.setRemoveHandler(null);
      this.tradesWorkupLayout.setDefaultQuantityHandler(null);
      this.tradesWorkupLayout.setWithdrawHandler(null);
      this.tradesWorkupLayout.setColleagueWithdrawHandler(null);
      this.tradesWorkupLayout.setPlaceOrderHandler(null);
      this.tradesWorkupLayout.setEngineTimeHandler(null);
      this.tradesWorkupLayout.setDitArgsMapSupplier(null);
   }

   private ListChangeListener<? super ObservableReplyRow> getMarketTradeDataListener() {
      if (marketTradeDataListener == null) {
         marketTradeDataListener = c -> {
            while (c.next()) {
               final List<? extends ObservableReplyRow> list = c.getAddedSubList();
               if (!list.isEmpty()) {
                  final List<String> addedWorkupSecCodes = new ArrayList<>();
                  list.forEach(row -> {
                     if (row.getValue(AmpMarketTrade.buyFirmId) == null &&
                        row.getValue(AmpMarketTrade.sellFirmId) == null) {
                        // Since this market trade does not contain our firm id in any of the fields
                        // we can conclude that this market trade does not have a corresponding trade

                        // now we filter out any leg trades
                        if (!new Integer(AmpStrategyTradeType_v2.strategyLeg).equals(row.getValue(AmpMarketTrade.buyStrategyTradeType)) &&
                           !new Integer(AmpStrategyTradeType_v2.strategyLeg).equals(row.getValue(AmpMarketTrade.sellStrategyTradeType))) {
                           final String workUpSecCode = row.getValue(AmpMarketTrade.secCode);
                           final String sessionNo = "M_" + workUpSecCode;
                           // Only showing the pop up if the settings property is set.
                           if (isWorkupPopupEnabled(workUpSecCode)) {
                              final Boolean isCM = row.getValue(AmpMarketTrade.isCMTrade);
                              if (!activeWorkupSecCodes.containsKey(workUpSecCode)) {
                                 activeWorkupSecCodes.put(workUpSecCode, new TradeData(sessionNo, isCM));
                                 addedWorkupSecCodes.add(workUpSecCode);
                              }
                           }
                        }
                     }
                  });
                  if (!addedWorkupSecCodes.isEmpty()) {
                     resetWatchList(addedWorkupSecCodes);
                  }
               }
            }
         };
      }
      return marketTradeDataListener;
   }

    private ListChangeListener<? super ObservableReplyRow> getTradeDataListener() {
        if (tradeDataListener == null) {
            tradeDataListener = c -> {
                while (c.next()) {
                    if (c.wasAdded()) {
                        final List<? extends ObservableReplyRow> list = c.getAddedSubList();
                        final List<String> addedWorkupSecCodes = new ArrayList<>();
                        for (ObservableReplyRow row : list) {
                            // DO NOT filter out any leg trades because it made ISWAXT-12505 issue.
                            // For marketTradeRep, it need to filter out leg trades but for tradeRep and dealRep, display all recieved
                            final String workUpSecCode = row.getValue(AmpTrade.secCode);
                            final String sessionNo = row.getValue(AmpTrade.prvlgdTrdngSessionNo);
                            // Only showing the pop up if the settings property is set.
                            if (sessionNo != null /*isWorkUpTriggered*/ && isWorkupPopupEnabled(workUpSecCode)) {
                                final Boolean isCM = row.getValue(AmpTrade.isCMTrade);
                                activeWorkupSecCodes.put(workUpSecCode, new TradeData(sessionNo, isCM));
                                addedWorkupSecCodes.add(workUpSecCode);
                            }
                        }

                        if (!addedWorkupSecCodes.isEmpty()) {
                            resetWatchList(addedWorkupSecCodes);
                        }
                        // If there is a trade for an already existing workup.
                        logger.debug("!!!!! Calling handle updates from trades listener !!!!!");
                        handleQuantityUpdates();
                    }
                }
            };
        }
        return tradeDataListener;
    }

   private ListChangeListener<? super ObservableReplyRow> getWatchlistListener() {
      if (watchlistListener == null) {
         watchlistListener = c -> {
            while (c.next()) {
               validateAndShowWorkup(watchlist.getItems(), false);
            }
         };
      }
      return watchlistListener;
   }

   /**
    * Specifies whether the provided secCode instrumentId is allowed to have workup popup opening.
    *
    * @param secCode Security code
    * @return true if workup popup enabled.
    */
   private boolean isWorkupPopupEnabled(String secCode) {
      if (!configurationModule.getData().autoPopupWorkupProperty().get()) {
         return false;
      }
      Future<SecBoard> secBoard = securitiesDataModule.getSecboards().getFirstBySecCode(secCode);
      try {
         if (secBoard.isDone() && secBoard.get() != null) {
            ObservableList<InstrumentSettingsSpec> instrumentSettingsSpecs = configurationModule.getData().instrumentSettingsProperty().get();
            String instrumentId = secBoard.get().getInstrumentId();
            InstrumentSettingsSpec spec = InstrumentSettingsSpec.getSpecByInstrumentId(instrumentSettingsSpecs, instrumentId);
            if (spec == null) {
               spec = InstrumentSettingsSpec.getSpecByInstrumentId(instrumentSettingsSpecs, InstrumentSettingsSpec.ALL_INSTRUMENTS_ID);
            }
            // Spec can be still null as by default no specs are set in workspace.
            if (spec != null) {
               return spec.isEnableWorkupPopup();
            }
         }
      } catch (Exception e) {
         e.printStackTrace();
         return false;
      }
      return true;
   }

   private void validateAndShowWorkup(final List<? extends ObservableReplyRow> list, boolean isManuallyClosed) {
      logger.info("validateAndShowWorkup start");
      if (!list.isEmpty()) {
         logger.info("doAddWorkup process {}", list.size());
         final ObservableSet<String> finishedWorkups = FXCollections.observableSet();
         list.forEach(row -> {
            boolean isCM = false;
            //BigDecimal matchPrice1= row.getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
            //final BigDecimal midPrice1 = matchPrice1;
            //BigDecimal midPrice2 = midPrice1;
            //if (midPrice1 != null && securitiesDataModule.isSpreadForPriceReversal(row))
            //   midPrice2 = midPrice1.negate();

            String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
            ObservableObjectValue<String> sessionName = row.getProperty(AmpIcapSecBoardTrim2.sessionName);

            if (!isManuallyClosed && (PRIVATE_SESSION.equals(sessionName.get()) || PUBLIC_SESSION.equals(sessionName.get())) && !autoWorkupSessions.contains(secCode)) {
               autoWorkupSessions.add(secCode);
               doAddWorkup(row, isCM);
            }

            ChangeListener<String> sessionNameLis = new ChangeListener<String>() {
               @Override
               public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                  if (!isManuallyClosed && (PRIVATE_SESSION.equals(sessionName.get()) || PUBLIC_SESSION.equals(sessionName.get())) && !autoWorkupSessions.contains(secCode)) {
                     autoWorkupSessions.add(secCode);
                     doAddWorkup(row, isCM);
                  }

                  if (OPEN_SESSION.equals(newValue)) {
                     sessionName.removeListener(this);
                     finishedWorkups.add(secCode);
                  }
               }
            };

            sessionName.addListener(sessionNameLis);

            // Not auto-showing if the workup is manually closed and then becomes Public
            if ((PRIVATE_SESSION.equals(sessionName.get()) || PUBLIC_SESSION.equals(sessionName.get())) && isManuallyClosed) {
               doAddWorkup(row, isCM);
            }
         });

         // If there are any finished workups, ensuring to reset the watchlist with the valid ones only.
         //finishedWorkups
         finishedWorkups.addListener((InvalidationListener) observable -> {
            if (!finishedWorkups.isEmpty()) {
               autoWorkupSessions.removeAll(finishedWorkups);
               secs.removeAll(finishedWorkups.stream().map(s -> new Security(null, s)).collect(Collectors.toList()));
               Platform.runLater(finishedWorkups::clear);
               watchlist.setSpec(new WatchlistSpec_v2().withSecurities(secs));
            }
         });

         // Perform quantity calculations for each workup row.
         handleQuantityUpdates();
      }
   }

   private void doAddWorkup(ObservableReplyRow row, boolean isCM) {
      String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      logger.info("doAddWorkup {} start", secCode);
      if (!closedWorkupSecCodes.contains(secCode)) {
         if (isWorkupPopupEnabled(secCode) || tradesWorkupLayout.getRoot().getProperties().get(TradesWorkupViewUIModule.FORCE_OPEN) != null) {
            TradeData tradeData = activeWorkupSecCodes.get(secCode);
            if (tradeData != null && tradeData.isCM != null) {
               isCM = tradeData.isCM;
            }
            boolean isCMWorkup = isCM;
            securitiesDataModule.getStaticInfo(secCode, row.getValue(AmpIcapSecBoardTrim2.boardId)).map(info -> {
               try {
                  logger.info("doAddWorkup {} call tradesWorkupLayout.addWorkupRow", secCode);
                  secCodeDITMap.put(row.getValue(AmpIcapSecBoardTrim2.secCode), new WorkupDITArgs());
                  tradesWorkupLayout.addWorkupRow(row, isCMWorkup, info.priceFormatter);
                  handleQuantityUpdates();
                  Fx.runLater(this::showWorkupPopup);
               } catch (Exception e) {
                  logger.error("Exception while formatting price in SecTable's in cell edit !!!");
               }
               return Future.SUCCESS;
            });
         }
      } else {
         logger.debug("Workup is manually CLOSED :: {}" , secCode);
      }
   }

   /**
    * Updates the quantity field of each workup row, by summing all the traded quantities and balances of open AmpManagedOrders.
    */
   private void handleQuantityUpdates() {
      // Do nothing after stopModule
      if (tradesWorkupLayout == null) return;
      secCodeAndOrdersList.forEach(SecCodeAndOrders::dispose);
      secCodeAndOrdersList.clear();
      final List<ObservableReplyRow> workupSecBoards = tradesWorkupLayout.getSecBoards();
      for (ObservableReplyRow secBoard : workupSecBoards) {
         final ObservableList<ObservableReplyRow> allOrdersBySecOriginal = ordersDataModule.getAllOrdersBySec(secBoard.getValue(AmpIcapSecBoardTrim2.secCode, AmpIcapSecBoardTrim2.boardId));
         String secCode = secBoard.getValue(AmpIcapSecBoardTrim2.secCode);
         BigDecimal workupPrice = secBoard.getValue(AmpIcapSecBoardTrim2.workupPrice);
         SecBoardStaticInfo staticInfo = securitiesDataModule.getStaticInfo(secBoard);
         secCodeAndOrdersList.add(new SecCodeAndOrders(secCode, workupPrice, allOrdersBySecOriginal, staticInfo));
      }
   }

   private void updateWorkupQuantity(String secCode,
                                     BigDecimal workupPrice,
                                     ObservableList<ObservableReplyRow> openOrders,
                                     SecBoardStaticInfo staticInfo) {
      logger.debug("Updating workup quantity for : " + secCode + " : All orders size :: " + openOrders.size());

      // Do nothing after stopModule
      if (tradesWorkupLayout == null || !activeSessionModule.getSession().isPresent()) return;

      /* Calculating the total traded quantity of trades matching the workup session */
      final ObjectProperty<BigDecimal> totalBuyTradedQty = new SimpleObjectProperty<>(BigDecimal.ZERO);
      final ObjectProperty<BigDecimal> totalSellTradedQty = new SimpleObjectProperty<>(BigDecimal.ZERO);

      /* Calculating the total traded quantity of trades matching the workup session for colleague at same bank*/
      final ObjectProperty<BigDecimal> totalColleagueBuyTradedQty = new SimpleObjectProperty<>(BigDecimal.ZERO);
      final ObjectProperty<BigDecimal> totalColleagueSellTradedQty = new SimpleObjectProperty<>(BigDecimal.ZERO);
      final String loggedOnUserId = activeSessionModule.getSession().get().getLoggedOnUserId();
      TradeData tradeData = activeWorkupSecCodes.get(secCode);
      final String sessionNo = (tradeData == null) ? null : tradeData.sessionNo;

      final Predicate<ObservableReplyRow> trdngSessionNoMatch = row -> sessionNo != null && sessionNo.equals(row.getValue(AmpTrade.prvlgdTrdngSessionNo));
      final Predicate<ObservableReplyRow> secCodeMatch = row -> secCode.equals(row.getValue(AmpTrade.secCode));

      tradesDataModule.getTradeData().stream().filter(trdngSessionNoMatch.and(secCodeMatch)).forEach(trade -> {
         String buyTraderId = trade.getValue(AmpTrade.buyTraderId);
         String sellTraderId = trade.getValue(AmpTrade.sellTraderId);

         if (loggedOnUserId.equals(buyTraderId)) {
            totalBuyTradedQty.set(totalBuyTradedQty.get().add(trade.getValue(AmpTrade.quantity)));
         }

         if (loggedOnUserId.equals(sellTraderId)) {
            totalSellTradedQty.set(totalSellTradedQty.get().add(trade.getValue(AmpTrade.quantity)));
         }

         if (buyTraderId != null && !loggedOnUserId.equals(buyTraderId)) {
            totalColleagueBuyTradedQty.set(totalColleagueBuyTradedQty.get().add(trade.getValue(AmpTrade.quantity)));
         }

         if (sellTraderId != null && !loggedOnUserId.equals(sellTraderId)) {
            totalColleagueSellTradedQty.set(totalColleagueSellTradedQty.get().add(trade.getValue(AmpTrade.quantity)));
         }
      });

      // add or update colleague panel if any sizes

      /* Calculating the total balance of open orders which match with workup price */
      final ObjectProperty<BigDecimal> totalBuyBalanceQty = new SimpleObjectProperty<>(BigDecimal.ZERO);
      final ObjectProperty<BigDecimal> totalSellBalanceQty = new SimpleObjectProperty<>(BigDecimal.ZERO);

      /* Calculating the total balance of open orders which match with workup price for colleague at same bank*/
      final ObjectProperty<BigDecimal> totalColleagueBuyBalanceQty = new SimpleObjectProperty<>(BigDecimal.ZERO);
      final ObjectProperty<BigDecimal> totalColleagueSellBalanceQty = new SimpleObjectProperty<>(BigDecimal.ZERO);

      final Predicate<ObservableReplyRow> priceMatch = row -> {
         final String status = AmpManagedOrder.getOrderStatusDisplayValue(row.getValue(AmpManagedOrder.orderStatus));
         BigDecimal priceVal = row.getValue(AmpManagedOrder.price);
         return status.equals("Open")
            && priceVal != null
            && workupPrice != null
            && priceVal.abs().compareTo(workupPrice.abs()) == 0;
      };

      openOrders.stream().filter(priceMatch).forEach(ord -> {
         //printOrder(ord);
         String orderUserId = ord.getValue(AmpManagedOrder.userId);

         if (orderUserId != null) {
            if (loggedOnUserId.equals(orderUserId)) {
               if (ord.getValue(AmpManagedOrder.buySell) == 0) {
                  totalBuyBalanceQty.set(totalBuyBalanceQty.get().add(getOrderBalance(ord)));
               } else {
                  totalSellBalanceQty.set(totalSellBalanceQty.get().add(getOrderBalance(ord)));
               }
            } else {
               if (ord.getValue(AmpManagedOrder.buySell) == 0) {
                  totalColleagueBuyBalanceQty.set(totalColleagueBuyBalanceQty.get().add(getOrderBalance(ord)));
               } else {
                  totalColleagueSellBalanceQty.set(totalColleagueSellBalanceQty.get().add(getOrderBalance(ord)));
               }
            }
         }
      });

      // Updating the workup rows with the quantities
      tradesWorkupLayout.updateWorkupQuantity(secCode,
         totalBuyTradedQty.get(),
         totalBuyBalanceQty.get(),
         totalSellTradedQty.get(),
         totalSellBalanceQty.get(),
         totalColleagueBuyTradedQty.get(),
         totalColleagueBuyBalanceQty.get(),
         totalColleagueSellTradedQty.get(),
         totalColleagueSellBalanceQty.get(),
         staticInfo.qtyContext.getMaxDecimals());
   }

   private void disposeSecBoardAndOrders(ObservableReplyRow row) {
      final String secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
      final Optional<SecCodeAndOrders> secCodeAndOrders = secCodeAndOrdersList.stream().filter(sc -> sc.secCode.equals(secCode)).findFirst();
      secCodeAndOrders.ifPresent(sc -> {
         sc.dispose();
         secCodeAndOrdersList.remove(sc);
      });
   }

   private void populateTransactionData(ObservableReplyRow row, AbstractOrderTrans orderTrans,
                                        boolean isImmediate, boolean isDark, OrderSide orderSide, String orderTag) {
      orderTrans.setCloneIntoRFS(false);
      orderTrans.setSecCode(row.getStringProperty(AmpIcapSecBoardTrim2.secCode).getValue());
      orderTrans.setBoardId(row.getStringProperty(AmpIcapSecBoardTrim2.boardId).getValue());
      orderTrans.setOrderType(OrderType.REGULAR);
      orderTrans.setVwap(false);
      double negatePrice = orderSide.equals(OrderSide.SELL) && securitiesDataModule.isSpreadForPriceReversal(row) ? -1.0 : 1.0;
      orderTrans.setPrice(row.getValue(AmpIcapSecBoardTrim2.workupPrice).doubleValue() * negatePrice);
      orderTrans.setDoneIfTouched(false);
      orderTrans.setAnonymous(false);
      orderTrans.setUnderRef(false);
      if (isImmediate) {
         orderTrans.setDefaultDurationType(DefaultDurationType.IMMEDIATE);
      } else {
         orderTrans.setDefaultDurationType(DefaultDurationType.GOOD_TILL_DAY);
      }
      orderTrans.setDoneIfTouched(isDark);
      orderTrans.setOnLogOffAction(configurationModule.getData().onLogoffActionProperty().get());
      orderTrans.setShared(configurationModule.getData().sharedOrdersProperty().get());
      orderTrans.setTopCut(configurationModule.getData().topCutProperty().get());
      // For WU reading the original order's order tag and setting it
      final MapWrapper extraFields = new MapWrapper();
      extraFields.put(Orders.ORDER_TAG_KEY, new XtrBlob(orderTag.getBytes()));
      orderTrans.setMapWrapper(extraFields);

   }

   /**
    * Returns the value of balance property of AmpManagedOrder.
    *
    * @param order ObservableReplyRow
    * @return Balance value.
    */
   private BigDecimal getOrderBalance(ObservableReplyRow order) {
      BigDecimal balance = new BigDecimal(BigInteger.ZERO);
      try {
         balance = order.getValue(AmpManagedOrder.balance);
      } catch (Exception e) {
         e.printStackTrace();
      }
      return balance;
   }

   /**
    * Returns the value of provided accessor of AmpTrade.
    *
    * @param trade ObservableReplyRow
    * @return Value of given accessor.
    */
   private String getNullableValue(ObservableReplyRow trade, AsnConversionAccessor<String> accessor) {
      String value = null;
      try {
         value = trade.getValue(accessor);
      } catch (Exception e) {
         e.printStackTrace();
      }
      return value;
   }

   private void showWorkupPopup() {
      if (!tradesWorkupLayout.isWorkupShowing()) {
         midiLayoutModule.addPopupView(tradesWorkupLayout.getRoot(), (stage) -> {
            stage.setOnShowingHandler(e -> tradesWorkupLayout.getRoot().getProperties().remove(FORCE_OPEN));
         });
      }
      tradesWorkupLayout.sizeToScene();
   }

   /**
    * Opens the workup from the SecTable cell. This opening of workup will NOT check for settings whether workupPoupEnabled.
    *
    * @param workupArgs Required arguments regarding the workup
    */
   private void openWorkup(WorkupArgs workupArgs) {
      final String secCode = workupArgs.getRow().getValue(AmpIcapSecBoardTrim2.secCode);
      logger.info("openWorkup {} start", secCode);
      if (!tradesWorkupLayout.isWorkupShowing()) {
         tradesWorkupLayout.getRoot().getProperties().put(FORCE_OPEN, true);
      }
      // Working if there is any active workup session for the secCode.
      if (activeWorkupSecCodes.keySet().contains(secCode)) {
         // If current workup secCode is not actively showing then create a row and display.
         // Ensuring the secCode is removed from closedWorkupSecCodes as it is re-triggered from SecTabs to show.
         closedWorkupSecCodes.remove(secCode);
         validateAndShowWorkup(watchlist.getItems(), true);
         tradesWorkupLayout.scrollTo(secCode);
      } else {
         // If there is not active workup session, then finding the session number from the existing trades and resetting the watchlist.
         Optional<ObservableReplyRow> tradeRow = tradesDataModule.getTradeData().stream().filter(row -> {
            final boolean isWorkUpTriggered = row.getValue(AmpTrade.prvlgdWorkUpTriggered);
            final String trdSecCode = row.getValue(AmpTrade.secCode);
            return isWorkUpTriggered && trdSecCode.equals(secCode);
         }).findFirst();

         String sessionNo = null;
         Boolean isCM = false;
         // If a tradeRow is present, get the details from the trade.
         if (tradeRow.isPresent()) {
            sessionNo = tradeRow.get().getValue(AmpTrade.prvlgdTrdngSessionNo);
            isCM = tradeRow.get().getValue(AmpTrade.isCMTrade);
         } else {
            // If the workup is for 3rd party trader, then get the details from AmpIcapSecBoardTrim2
            final BigDecimal prvlgdTrdngPrice = workupArgs.getRow().getValue(AmpIcapSecBoardTrim2.prvlgdTrdngPrice);
            final BigDecimal darkMatchPrice = workupArgs.getRow().getValue(AmpIcapSecBoardTrim2.darkMatchPrice);
            if (prvlgdTrdngPrice != null && darkMatchPrice != null) {
               isCM = prvlgdTrdngPrice.compareTo(darkMatchPrice) == 0;
            }
         }

         activeWorkupSecCodes.put(secCode, new TradeData(sessionNo, isCM));
         boolean isPresentInWatchList = watchlist.getItems().stream().anyMatch(row -> secCode.equals(row.getValue(AmpIcapSecBoardTrim2.secCode)));
         if (isPresentInWatchList) {
            validateAndShowWorkup(watchlist.getItems(), false);
         } else {
            secs.clear();
            resetWatchList(new ArrayList<>(activeWorkupSecCodes.keySet()));
         }
         tradesWorkupLayout.scrollTo(secCode);
      }
   }

   /**
    * Resets the watchlist by adding new secBoards to existing list.
    *
    * @param secCodes List of new secCodes.
    */
   private void resetWatchList(List<String> secCodes) {
      try {
         // Clearing all the earlier references to secCode to Orders.
         secCodeAndOrdersList.forEach(SecCodeAndOrders::dispose);
         secCodeAndOrdersList.clear();
         secs.addAll(secCodes.stream().map(s -> new Security(null, s)).collect(Collectors.toList()));
         watchlist.setSpec(new WatchlistSpec_v2().withSecurities(secs));
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   @Deprecated
   private void printAmpTrade(ObservableReplyRow row) {
      String secCode = row.getProperty(AmpTrade.secCode).get();
      boolean workupTriggered = row.getProperty(AmpTrade.prvlgdWorkUpTriggered).get();
      String sessionNo = row.getProperty(AmpTrade.prvlgdTrdngSessionNo).get();
      String buyTraderId = row.getProperty(AmpTrade.buyTraderId).get();
      String sellTraderId = row.getProperty(AmpTrade.sellTraderId).get();
      String buyFirmId = row.getProperty(AmpTrade.buyFirmId).get();
      String sellFirmId = row.getProperty(AmpTrade.sellFirmId).get();
      BigDecimal tradeQty = row.getProperty(AmpTrade.quantity).get();
      logger.debug("Trade ---> SecCode: " + secCode + ", WorkUpTriggered: " + workupTriggered + ", SessionNo: " + sessionNo);
      //System.out.println ("Trade ---> SecCode: " + secCode + ", WorkUpTriggered: " + workupTriggered + ", SessionNo: " + sessionNo);
      //System.out.println ("buyTraderId " + buyTraderId);
      //System.out.println ("sellTraderId " + sellTraderId);
      //System.out.println ("buyFirmId " + buyFirmId);
      //System.out.println ("sellFirmId " + sellFirmId);
      //System.out.println ("qty " + tradeQty);
   }

   @Deprecated
   private void printAmpIcapSecBoardTrim2(ObservableReplyRow row) {
      logger.debug("AmpIcapSecBoardTrim2 ---> SecCode: " + row.getProperty(AmpIcapSecBoardTrim2.secCode).get() + ", Phase: " + row.getProperty(AmpIcapSecBoardTrim2.sessionName).get() + ", WorkupPrice: " + row.getProperty(AmpIcapSecBoardTrim2.workupPrice).get());
      //System.out.println("Timer  : " + row.getProperty(AmpIcapSecBoardTrim2.prvlgdTrdngEndTime).get());
      //System.out.println("Engine time :: " + activeSessionModule.getSession().get().getStats().getEngineTime());
   }

   @Deprecated
   private void printOrder(ObservableReplyRow row) {
      double qty = row.getProperty(AmpManagedOrder.quantity_d).get();
      String status = AmpManagedOrder.getOrderStatusDisplayValue(row.getProperty(AmpManagedOrder.orderStatus).get());
      String buySell = row.getProperty(AmpManagedOrder.buySell).get() == 0 ? "Buy" : "Sell";
      logger.debug("Order ---> Side: " + buySell + ", Qty: " + qty + ", Bal: " + getOrderBalance(row) + ", Status: " + status);
   }

   /**
    * Class to add listener to the orders of the secCode and keep a reference of it.
    * It will be later used to dispose everything when a watchlist set method is called.
    */
   class SecCodeAndOrders {
      private ObservableList<ObservableReplyRow> orders;
      private ObservableList<ObservableReplyRow> allOrdersBySecOriginal;
      private ListChangeListener<ObservableReplyRow> listener;
      private String secCode;
      private BigDecimal workupPrice;
      private SecBoardStaticInfo staticInfo;

      SecCodeAndOrders(String sc,
                       BigDecimal wup,
                       ObservableList<ObservableReplyRow> allOrdersBySecOriginal,
                       SecBoardStaticInfo staticInfo) {
         this.allOrdersBySecOriginal = allOrdersBySecOriginal;
         // Creating an ObservableList observing on row property. Any changes in the row value will trigger the appropriate listener events of list.
         orders = FXCollections.observableArrayList(row -> new Observable[]{row.rowProperty()});
         Bindings.bindContent(orders, allOrdersBySecOriginal);
         this.secCode = sc;
         this.workupPrice = wup;
         this.staticInfo = staticInfo;
         this.listener = (ListChangeListener.Change<? extends ObservableReplyRow> c) -> {
            logger.debug("Listener triggered for orders size :: " + orders.size());
            //orders.forEach(TradesWorkupViewUIModule.this::printOrder);
            updateWorkupQuantity(secCode, workupPrice, orders, staticInfo);
         };
         this.orders.addListener(listener);
         updateWorkupQuantity(secCode, workupPrice, orders, staticInfo);
      }

      public void dispose() {
         Bindings.unbindContent(orders, allOrdersBySecOriginal);
         orders.removeListener(listener);
         listener = null;
         orders.clear();
         orders = null;
      }
   }

   private TradesWorkupLayout tradesWorkupLayout;


   private class TradeData {
      String sessionNo;
      Boolean isCM;

      TradeData(String sessionNo, Boolean isCM) {
         this.sessionNo = sessionNo;
         this.isCM = isCM;
      }
   }
}
