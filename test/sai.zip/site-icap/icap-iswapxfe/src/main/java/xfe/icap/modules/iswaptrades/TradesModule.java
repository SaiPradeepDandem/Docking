package xfe.icap.modules.iswaptrades;

import com.nomx.persist.PersistantName;
import com.objsys.asn1j.runtime.Asn1Type;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableIntegerValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.amp.AmpMarketTrade;
import xfe.icap.amp.AmpTrade;
import xfe.util.TradeFlashPropInvalidationListener;
import xfe.util.WeakCompositeRef;
import xstr.session.ObservableReplyRow;
import xstr.session.ObservableReplyRow.ObservableRowFactory;
import xstr.session.QueryReplyRow;
import xstr.types.TradeSide;
import xstr.types.User;
import xstr.util.*;
import xfe.util.HandlerCompositeUtils.ObservableFilterExpression;
import xstr.util.collection.ObservableCollections;
import xstr.util.concurrent.Future;
import xstr.util.filter.DynamicFilter;
import xstr.util.filter.Filters;
import xstr.util.filter.RowFilters;
import xfe.util.scene.control.Builders;
import xfe.util.scene.control.DecoratedTitledPane;
import xfe.util.scene.control.TableViewHeaderUnmovable;
import xfe.util.scene.control.XfeTooltipFactory;
import xfe.icap.XfeSession;
import xfe.icap.modules.selectioncontext.SelectionContext;
import xfe.icap.modules.selectioncontext.SelectionContextModule;
import xfe.icap.modules.selectioncontext.SelectionContextModule.GridType;
import xfe.layout.FxAbstractLayout;
import xfe.layout.LayoutManager;
import xfe.module.Module;
import xfe.icap.modules.TradesFlash.TradesFlashModule;
import xfe.modules.actionsui.ActionButton;
import xfe.icap.modules.actionsui.ActionsUIModule;
import xfe.modules.session.SessionModule;
import xfe.modules.session.SessionScopeModule;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.ui.KeyEventFilter;
import xfe.ui.TabSelector;
import xfe.ui.ToggleButtonPaneSelector;
import xfe.ui.table.Tables;
import xfe.ui.table.XfeTableColumn;

import java.util.Comparator;
import java.util.List;

@Module.Autostart
public class TradesModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(TradesModule.class);

   @ModuleDependency
   public SelectionContextModule selectionContextModule;
   @ModuleDependency
   public XfeSession xfeSessionModule;
   @ModuleDependency
   public SessionModule sessionModule;
   @ModuleDependency
   public LayoutManager<Node> layoutManagerModule;
   @ModuleDependency
   public FxAbstractLayout layoutModule;
   @ModuleDependency
   public ConfigurationModule configurationModule;
   @ModuleDependency
   public ActionsUIModule actionsUIModule;
   @ModuleDependency
   public TradesFlashModule tradesFlashModule;

   public TradesModule() {
      logger.debug("Default constructing");
   }

   @Override
   public Future<Void> startModule() {
      tradeAggregator = new FeedAggregator<>(AmpTrade.rep,new ObservableRowFactory());
      tradesFeed = new TradesFeedAdapter(xfeSessionModule.getUnderlyingSession().getFeedSource(AmpTrade.req), xfeSessionModule.getUnderlyingSession().getLoggedOnUser().getUserId());
      tracker.addFeedListener(tradesFeed, tradeAggregator);
      tracker.bind(TradesColumns.autoPopupWorkupProp, configurationModule.getData().autoPopupWorkupProperty());
      marketAggregator = new FeedAggregator<>(AmpMarketTrade.rep,new ObservableRowFactory());
      marketTradesFeed = new TradesFeedAdapter(xfeSessionModule.getUnderlyingSession().getFeedSource(AmpMarketTrade.req), xfeSessionModule.getUnderlyingSession().getLoggedOnUser().getUserId());
      tracker.addFeedListener(marketTradesFeed, marketAggregator);
      filters = new TradesFilters(xfeSessionModule,this);
      tg = new ToggleGroup();
      sp = new StackPane();
      tradesPane = new DecoratedTitledPane("Trades", sp, true, layoutModule,true);

      buttonsPane = new HBox();
      buttonsPane.setFillHeight(true);
      tradesPane.setLeftDecoration(buttonsPane);

      rightDecorationHBox = new HBox();
      rightDecorationHBox.setMinWidth(107);
      rightDecorationHBox.setAlignment(Pos.CENTER_LEFT);
      rightDecorationHBox.setId("xfe-trades-right-decoration");
      rightDecorationHBox.getStyleClass().add("xfe-trades-right-decoration");
      tradesPane.setRightDecoration(rightDecorationHBox);

      tradesPane.setId("xfe-trades-view");
      tradesPane.getStyleClass().add("xfe-iswap-pane");
      tracker.bindBidirectional(tradesPane.expandProperty(), configurationModule.getData().tradesExpandProperty());
      tracker.bindBidirectional(tradesPane.displayProperty(), configurationModule.getData().displayTradesProperty());
      tracker.bindBidirectional(tradesPane.sizeProperty(), configurationModule.getData().tradesHeightProperty());
      attachTabSelectorAccelerators(tradesPane);

      ChangeListener<Boolean> showTradesPaneListener = (observable, oldValue, showTradePane) -> {
         if (showTradePane) {
            tradesFeed.startPolling();
            marketTradesFeed.startPolling();
         } else {
            tradesFeed.stopPolling();
            marketTradesFeed.stopPolling();
         }
      };

      BooleanProperty displayTradesProperty = configurationModule.getData().displayTradesProperty();

      tracker.registerRollbackAction(() -> layoutModule.removeView(tradesPane));

      xfeSessionModule.secBoards.get().ready().onSuccess(new Fun1<Boolean, Void>() {

         @Override
         public Void call(Boolean dummy) {

            if (xfeSessionModule.loggedOnProperty().get()) {
               User loggedonUser = xfeSessionModule.getUnderlyingSession().getLoggedOnUser();
               if (loggedonUser != null)
                  if (loggedonUser.isIB()) {
                     initializeContents4IB();
                  } else if (loggedonUser.isBrokerButNotIB()) {
                     initializeContents4Broker();
                  } else {
                     initializeContents4Trader();
                  }
            }

            return null;
         }
      });

      tracker.addListener(displayTradesProperty, showTradesPaneListener);
      layoutModule.addView(tradesPane);
      if (displayTradesProperty.get()) {
         tradesFeed.startPolling();
         marketTradesFeed.startPolling();
      } else {
         tradesFeed.stopPolling();
         marketTradesFeed.stopPolling();
      }
      actionsUIModule.addCustomButton(0, new ActionButton() {
         {
            this.getStyleClass().add("xfe-icon-trades");
            this.setText("Trades");
            setId("xfe-iswap-btn-action-trades");
            XfeTooltipFactory.setTooltip(this);
            tracker.bindBidirectional(this.selectedProperty(), configurationModule
               .getData().displayTradesProperty());
            this.installUnreadCountStateListeners(tracker,
               tradeAggregator.items);
         }
      });

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      tradesFeed.stopPolling();
      tracker.rollback();
      if(marketAggregator!=null){
         marketAggregator.reset();
      }
      marketAggregator = null;
      if(tradesPane!=null){
         tradesPane.dispose();
      }
      sp = null;
      tradesFeed = null ;
      marketTradesFeed.dispose();
      marketTradesFeed = null ;
      filters = null ;
      tg = null;

      TradesFilters.dispose();

      return Future.SUCCESS;
   }

   public void jumpToTradeById(Object tradeId) {
      System.out.println(String.format("TradesModule.jumpToTradeById %s",
         tradeId));
   }

   private void initializeContents4Trader() {

      CheckBox showDeskChk = new CheckBox();

      showDeskChk.getStyleClass().add("xfe-iswap-chk");
      showDeskChk.setSelected(false);
      showDeskChk.setAlignment(Pos.CENTER_LEFT);
      showDeskChk.setTextOverrun(OverrunStyle.CENTER_ELLIPSIS);
      showDeskChk.visibleProperty().bind(showDeskChk.managedProperty());

      DynamicFilter<ObservableReplyRow> iswapFilter = DynamicFilter
         .of(ObservableFilterExpression.<ObservableReplyRow> build(
            "auto & (own | showDeskChk) & (!leg | strategyChk)",
            "strategyChk",
            Filters.fixed(strategyChk.selectedProperty()),
            "showDeskChk",
            Filters.fixed(showDeskChk.selectedProperty()), "auto",
            Filters.dynamic(filters.isAuto), "leg",
            Filters.dynamic(TradesFilters.isLeg), "own", filters.isTraderTrade));
      ObservableList<ObservableReplyRow> iSwapView = ObservableCollections
         .sort(tradeAggregator.items, new TradesComparator(tradesFeed),iswapFilter,tracker);

      DynamicFilter<ObservableReplyRow> voiceFilter = DynamicFilter
         .of(ObservableFilterExpression.<ObservableReplyRow> build(
            "!auto & (own | showDeskChk) & (!leg | strategyChk)",
            "strategyChk",
            Filters.fixed(strategyChk.selectedProperty()),
            "showDeskChk",
            Filters.fixed(showDeskChk.selectedProperty()), "auto",
            Filters.dynamic(filters.isAuto), "leg",
            Filters.dynamic(TradesFilters.isLeg), "own", filters.isTraderTrade));
      ObservableList<ObservableReplyRow> voiceView = ObservableCollections.sort(tradeAggregator.items, new TradesComparator(tradesFeed),voiceFilter,tracker);

      ObservableList<ObservableReplyRow> marketView = Fx.sortBy(marketAggregator.items, reverseComparator);

      TableView<ObservableReplyRow> myTrades = setupTradesView(filters,tradeAggregator.items);
      TableView<ObservableReplyRow> myMarketTrades = setupMarketTradesView(marketView, xfeSessionModule, false);

      tracker.bind(sp.maxHeightProperty(), myTrades.maxHeightProperty());
      sp.getChildren().addAll(myTrades, myMarketTrades);

      // Listening on other grids' selection change
      tracker.disposes(Fx.addListener(
         selectionContextModule.selectionContextProperty(),
         (observableVal, oldVal, newVal) -> {
            if (newVal.grid != GridType.Trades
               && newVal.grid != GridType.MarketTrades
               && isActive) {
               // We need to reset our selection
               isActive = false;
               myTrades.getSelectionModel().clearSelection();
               myMarketTrades.getSelectionModel().clearSelection();
            }
         }));

//		double prefBtnWidth = 110;
      ToggleButton voiceBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
//		voiceBtn.setPrefWidth(prefBtnWidth);
      voiceBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(voiceBtn));
      ToggleButton marketBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
//		marketBtn.setPrefWidth(prefBtnWidth);
      marketBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(marketBtn));

      tracker.addListener(tradesFlashModule.blinkNeutralToOffProp, new TradeFlashPropInvalidationListener(marketBtn.getStyleClass(), Fx.valueOf(true)) {
         @Override
         public void invalidated(Observable observable) {
            super.invalidated(observable);
         }
      });

      ToggleButton iSwapBtn;
      iSwapBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
      HBox hbox = new HBox();
      hbox.getChildren().add(new Label("i"));
      iSwapBtn.setGraphic(hbox);
      iSwapBtn.setGraphicTextGap(0);
      iSwapBtn.getStyleClass().add("i-Swap");
      iSwapBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(iSwapBtn));

      tracker.bind(
         showDeskChk.managedProperty(),
         Bindings.equal(tg.selectedToggleProperty(), iSwapBtn).or(
            Bindings.equal(tg.selectedToggleProperty(), voiceBtn)));

      tracker.bind(
         strategyChk.managedProperty(),
         Bindings.equal(tg.selectedToggleProperty(), iSwapBtn).or(
            Bindings.equal(tg.selectedToggleProperty(), voiceBtn)));

      buttonsPane.getChildren().addAll(iSwapBtn, voiceBtn, marketBtn);

      tracker.bind(iSwapBtn.textProperty(),
         Bindings.format("-Swap (%d)", Fx.sizeOfList(iSwapView)));
      tracker.bind(voiceBtn.textProperty(),
         Bindings.format("Voice (%d)", Fx.sizeOfList(voiceView)));
      tracker.bind(marketBtn.textProperty(),
         Bindings.format("Market (%d)", Fx.sizeOfList(marketView)));
      BooleanBinding toggleBinding = Bindings.equal(marketBtn,
         tg.selectedToggleProperty());

      // Passing focus from hiding TableView to showing TableView
      tracker.addListener(toggleBinding, (observableValue, oldValue, newValue) -> {
         Node oldNode;
         Node newNode;

         if (newValue) {
            oldNode = myTrades;
            newNode = myMarketTrades;
         } else {
            newNode = myTrades;
            oldNode = myMarketTrades;
         }

         if (oldNode.isFocused()) {
            Fx.runLater(newNode::requestFocus);
         }
      });
      tracker.bind(myTrades.visibleProperty(), toggleBinding.not());
      tracker.bind(myMarketTrades.visibleProperty(), toggleBinding);

      // TODO : Checkboxes counter
      Bindings.equal(iSwapBtn, tg.selectedToggleProperty());

      DynamicFilter<ObservableReplyRow> legFilter = DynamicFilter
         .of(ObservableFilterExpression
            .<ObservableReplyRow> build(
               "leg & (own | showDeskChk) & (iSwapBtn & auto | voiceBtn & !auto)",

               "iSwapBtn",
               Filters.fixed(Bindings.equal(iSwapBtn,
                  tg.selectedToggleProperty())),
               "voiceBtn",
               Filters.fixed(Bindings.equal(voiceBtn,
                  tg.selectedToggleProperty())),
               "showDeskChk",
               Filters.fixed(showDeskChk.selectedProperty()),
               "own", filters.isTraderTrade, "auto",
               Filters.dynamic(filters.isAuto), "leg",
               Filters.dynamic(TradesFilters.isLeg)));

      DynamicFilter<ObservableReplyRow> notOwnFilter = DynamicFilter
         .of(ObservableFilterExpression
            .<ObservableReplyRow> build(
               "!own & (!leg | strategyChk) & (iSwapBtn & auto | voiceBtn & !auto)",

               "iSwapBtn",
               Filters.fixed(Bindings.equal(iSwapBtn,
                  tg.selectedToggleProperty())),
               "voiceBtn",
               Filters.fixed(Bindings.equal(voiceBtn,
                  tg.selectedToggleProperty())),
               "strategyChk",
               Filters.fixed(strategyChk.selectedProperty()),
               "leg", Filters.dynamic(TradesFilters.isLeg), "auto",
               Filters.dynamic(filters.isAuto), "own",
               filters.isTraderTrade));

      ObservableList<ObservableReplyRow> legs = ObservableCollections.filter(tradeAggregator.items, legFilter,tracker);
      ObservableList<ObservableReplyRow> others = ObservableCollections.filter(tradeAggregator.items, notOwnFilter,tracker);
      tracker.bind(strategyChk.textProperty(),Bindings.format("Legs (%d)", Fx.sizeOfList(legs)));
      tracker.bindBidirectional(strategyChk.selectedProperty(), configurationModule.getParametersStorage().get(PersistantName.TradesPaneShowLegs, false));

      tracker.bind(showDeskChk.textProperty(),Bindings.format("Desk (%d)", Fx.sizeOfList(others)));
      tracker.bindBidirectional(showDeskChk.selectedProperty(), configurationModule.getParametersStorage().get(PersistantName.TradesPaneShowDeskTrades, false));

      rightDecorationHBox.getChildren().addAll(strategyChk, showDeskChk);

      tracker.addListener(tg.selectedToggleProperty(),
         (observableToggle, oldToggle, newToggle) -> {
            myTrades.getSelectionModel().clearSelection();
            myMarketTrades.getSelectionModel().clearSelection();

            int toggleIndex = tg.getToggles().indexOf(
               newToggle);

            if (toggleIndex != -1) {
               configurationModule.getData().selectedTradesTabProperty()
                  .set(toggleIndex);
            }

            if (newToggle == iSwapBtn) {
               myTrades.setItems(Fx.alwaysUnequal(iSwapView));
               seletedTabObjectProperty.setValue(SelectedTab.ISWAP);
            } else if (newToggle == voiceBtn) {
               myTrades.setItems(Fx.alwaysUnequal(voiceView));
               seletedTabObjectProperty.setValue(SelectedTab.VOICE);
            } else if (newToggle == marketBtn) { // marketBtn
               myMarketTrades.setItems(Fx.alwaysUnequal(marketView));
               seletedTabObjectProperty.setValue(SelectedTab.MARKET);
            }
         });


      IntegerProperty selectedTab = configurationModule.getData().selectedTradesTabProperty();
      tg.getToggles().get(selectedTab.get()).setSelected(true);

      tracker.addListener(configurationModule.getData().selectedTradesTabProperty(),
         observable -> {
            tg.getToggles()
               .get(configurationModule.getData()
                  .selectedTradesTabProperty().get())
               .setSelected(true);
         });

   }

   private void initializeContents4IB() {
      ToggleButton brokerBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
      CheckBox traderChk = new CheckBox();
      traderChk.getStyleClass().add("xfe-iswap-chk");
      traderChk.setSelected(false);
      traderChk.setAlignment(Pos.CENTER_LEFT);
      tracker.bind(traderChk.visibleProperty(), brokerBtn.selectedProperty());

      DynamicFilter<ObservableReplyRow> introBrokerFilter = DynamicFilter.of(ObservableFilterExpression.<ObservableReplyRow> build(
         "auto & ( (!showTrader & own)  | (showTrader & onBehalfof) ) & (!leg | strategyChk)",
         "auto",Filters.dynamic(filters.isAuto),
         "showTrader",Filters.fixed(traderChk.selectedProperty()),
         "own", filters.isIBTrades,
         "onBehalfof", filters.isOnbehalftraderUnderBroker, // Containing all trades involving orders entered by (or on-behalf-of) the logged-in Introducing broker with check box filter for selected trader
         "strategyChk",Filters.fixed(strategyChk.selectedProperty()),
         "leg", Filters.dynamic(TradesFilters.isLeg)
      ));

      ObservableList<ObservableReplyRow> introbrokerView =  ObservableCollections.sort(tradeAggregator.items, new TradesComparator(tradesFeed), introBrokerFilter, tracker);

      /*{IB Firm Name} - Containing all trades involving orders entered by (or on-behalf-of) all IB's from the logged-in user's firm*/
      DynamicFilter<ObservableReplyRow> firmFilter = DynamicFilter.of(ObservableFilterExpression.<ObservableReplyRow> build(
         "auto & ibFirmTrades & (!leg | strategyChk)",
         "auto",Filters.dynamic(filters.isAuto),
         "ibFirmTrades",filters.isIBFirmTrade,
         "strategyChk",Filters.fixed(strategyChk.selectedProperty()),
         "leg", Filters.dynamic(TradesFilters.isLeg)
      ));

      ObservableList<ObservableReplyRow> firmView = ObservableCollections.sort(tradeAggregator.items, new TradesComparator(tradesFeed), firmFilter, tracker);

      ObservableList<ObservableReplyRow> marketView = Fx.sortBy(marketAggregator.items, reverseComparator);
      TableView<ObservableReplyRow> myMarketTrades = setupMarketTradesView(marketView, xfeSessionModule, true);

      DynamicFilter<ObservableReplyRow> onBehalfTraderFilter = DynamicFilter.of(ObservableFilterExpression.<ObservableReplyRow> build(
         "auto & onBehalfof & (!leg | strategyChk)",
         "auto",Filters.dynamic(filters.isAuto),
         "onBehalfof",filters.isOnbehalftraderUnderBroker,
         "strategyChk",Filters.fixed(strategyChk.selectedProperty()),
         "leg", Filters.dynamic(TradesFilters.isLeg)
      ));

      ObservableList<ObservableReplyRow> onBehalfTraderView = ObservableCollections.filter(tradeAggregator.items, onBehalfTraderFilter,tracker);
      TableView<ObservableReplyRow> myTrades = setupTradesView4Broker(filters, tradeAggregator.items);
      tracker.bind(sp.maxHeightProperty(), myTrades.maxHeightProperty());
      sp.getChildren().addAll(myTrades,myMarketTrades);

      // Listening on other grids' selection change
      tracker.disposes(Fx.addListener(selectionContextModule.selectionContextProperty(), (observableVal, oldVal, newVal) -> {
         if (newVal.grid != GridType.Trades && newVal.grid != GridType.MarketTrades && isActive) {
            // We need to reset our selection
            isActive = false;
            myMarketTrades.getSelectionModel().clearSelection();
         }
      }));

      brokerBtn.setId("xfe-trades-brokerButton");
      brokerBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(brokerBtn));
      tracker.bind(brokerBtn.textProperty(), Bindings.format("%s (%d)", xfeSessionModule.getUnderlyingSession().getLoggedOnUserId(),Fx.sizeOfList(introbrokerView)));

      tracker.bind(traderChk.textProperty(), Bindings.format("%s (%d)", xfeSessionModule.getUnderlyingSession().onBehalfTraderId,Fx.sizeOfList(onBehalfTraderView)));

      ToggleButton firmBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
      firmBtn.setId("xfe-trades-firmButton");
      firmBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(firmBtn));
      tracker.bind(firmBtn.textProperty(), Bindings.format("%s (%d)", xfeSessionModule.getUnderlyingSession().getLoggedOnUserFirmId(),Fx.sizeOfList(firmView)));

      ToggleButton marketBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
      marketBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(marketBtn));
      tracker.bind(marketBtn.textProperty(), Bindings.format("Market (%d)", Fx.sizeOfList(marketView)));
      tracker.addListener(tradesFlashModule.blinkNeutralToOffProp, new TradeFlashPropInvalidationListener(marketBtn.getStyleClass(), Fx.valueOf(true)));
      rightDecorationHBox.getChildren().addAll(traderChk,strategyChk);

      BooleanBinding marketViewBinding = Bindings.equal(marketBtn, tg.selectedToggleProperty());

      // Passing focus from hiding TableView to showing TableView
      tracker.addListener(marketViewBinding, (observableValue, oldValue, newValue) -> {
         Node oldNode;
         Node newNode;

         if (newValue) {
            oldNode = myTrades;
            newNode = myMarketTrades;
         } else {
            newNode = myTrades;
            oldNode = myMarketTrades;
         }

         if (oldNode.isFocused()) {
            Fx.runLater(newNode::requestFocus);
         }
      });
      tracker.bind(myTrades.visibleProperty(), marketViewBinding.not());
      tracker.bind(myMarketTrades.visibleProperty(), marketViewBinding);

      buttonsPane.getChildren().setAll(brokerBtn, firmBtn ,marketBtn);

      BooleanProperty alwaysShowLeg = new SimpleBooleanProperty(true);
      DynamicFilter<ObservableReplyRow> introBrokerFilterHasLeg = filters.isIntroBroker(new SimpleBooleanProperty(true),traderChk.selectedProperty());
      DynamicFilter<ObservableReplyRow> onBehalfTraderFilterHasLeg = filters.isOnbehalfTrade4IB(alwaysShowLeg);
      DynamicFilter<ObservableReplyRow> legFilter = filters.legFilter4IB(introBrokerFilterHasLeg,onBehalfTraderFilterHasLeg,traderChk.selectedProperty());
      ObservableList<ObservableReplyRow> legs = ObservableCollections.filter(tradeAggregator.items, legFilter,tracker);
      tracker.bind(strategyChk.textProperty(),Bindings.format("Legs (%d)", Fx.sizeOfList(legs)));

      tracker.bind(strategyChk.visibleProperty(), brokerBtn.selectedProperty());

      tracker.bindBidirectional(strategyChk.selectedProperty(), configurationModule.getParametersStorage().get(PersistantName.TradesPaneShowLegs, false));

      tracker.addListener(tg.selectedToggleProperty(), (observableToggle, oldToggle, newToggle) -> {
         myTrades.getSelectionModel().clearSelection();
         myMarketTrades.getSelectionModel().clearSelection();

         int toggleIndex = tg.getToggles().indexOf(newToggle);

         if (toggleIndex != -1) {
            configurationModule.getData().selectedTradesTabProperty().set(toggleIndex);
         }

         if (newToggle == brokerBtn) {
            myTrades.setItems(Fx.alwaysUnequal(introbrokerView));
            seletedTabObjectProperty.setValue(SelectedTab.BROKER);
         } else if (newToggle == firmBtn) {
            myTrades.setItems(Fx.alwaysUnequal(firmView));
            seletedTabObjectProperty.setValue(SelectedTab.FIRM);
         } else if (newToggle == marketBtn) { // marketBtn
            myMarketTrades.setItems(Fx.alwaysUnequal(marketView));
            seletedTabObjectProperty.setValue(SelectedTab.MARKET);
         }
      });

      IntegerProperty selectedTab = configurationModule.getData().selectedTradesTabProperty();
      tg.getToggles().get(selectedTab.get()).setSelected(true);

      tracker.addListener(configurationModule.getData().selectedTradesTabProperty(), observable -> {
         tg.getToggles().get(configurationModule.getData().selectedTradesTabProperty().get()).setSelected(true);
      });

   }

   /*
    * The following tabs will be displayed in the trades view for brokers:
�  {Broker-name} � Containing all trades involving orders entered by the logged-in broker
�  {Trader-name} � Containing all trades involving orders (broker & trader entered) entered by the selected trader or on his behalf
�  All � Contains all trades. Also a checkbox �My Traders� to filter for trades involving orders on his broker desk (ie those he can enter orders on-behalf-of).
    */
   private void initializeContents4Broker() {
      CheckBox myTradersChk = new CheckBox("My Traders");
      myTradersChk.getStyleClass().add("xfe-iswap-chk");
      myTradersChk.setSelected(false);
      myTradersChk.setAlignment(Pos.CENTER_LEFT);
      myTradersChk.setTextOverrun(OverrunStyle.CENTER_ELLIPSIS);

      DynamicFilter<ObservableReplyRow> brokerFilter = filters.isOpertator(strategyChk.selectedProperty());
      ObservableList<ObservableReplyRow> brokerView =  ObservableCollections.sort(tradeAggregator.items, new TradesComparator(tradesFeed),brokerFilter,tracker);

      DynamicFilter<ObservableReplyRow> allFilter = filters.brokerDesk(myTradersChk.selectedProperty(),strategyChk.selectedProperty());
      ObservableList<ObservableReplyRow> allView =  ObservableCollections.sort(tradeAggregator.items, new TradesComparator(tradesFeed),allFilter,tracker);

      DynamicFilter<ObservableReplyRow> onBehalfTraderFilter = filters.isOnbehalfTrade4Broker(strategyChk.selectedProperty());
      ObservableList<ObservableReplyRow> onBehalfTraderView = ObservableCollections.sort(tradeAggregator.items, new TradesComparator(tradesFeed),onBehalfTraderFilter,tracker);
      ObservableIntegerValue sizeOfTrader = Fx.sizeOfList(onBehalfTraderView);


      TableView<ObservableReplyRow> myTrades = setupTradesView4Broker(filters, tradeAggregator.items);

      tracker.bind(sp.maxHeightProperty(), myTrades.maxHeightProperty());
      sp.getChildren().addAll(myTrades);

      // Listening on other grids' selection change
      tracker.disposes(Fx.addListener(selectionContextModule.selectionContextProperty(), (observableVal, oldVal, newVal) -> {
         if (newVal.grid != GridType.Trades && newVal.grid != GridType.MarketTrades && isActive) {
            // We need to reset our selection
            isActive = false;
            myTrades.getSelectionModel().clearSelection();
         }
      }));

      ToggleButton brokerBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
      brokerBtn.setId("xfe-trades-brokerButton");
      brokerBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(brokerBtn));
      tracker.bind(brokerBtn.textProperty(), Bindings.format("%s (%d)", xfeSessionModule.getUnderlyingSession().getLoggedOnUserId(),Fx.sizeOfList(brokerView)));

      ToggleButton allBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
      allBtn.setId("xfe-all-allButton");
      allBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(allBtn));
      tracker.bind(allBtn.textProperty(), Bindings.format("All (%d)", Fx.sizeOfList(allView)));

      myTradersChk.visibleProperty().bind(allBtn.selectedProperty());
      /* TODO: comment out this like to get the legs checkbox visible for ALL tab */
      strategyChk.visibleProperty().bind(Bindings.not(allBtn.selectedProperty()));

      ToggleButton traderBtn = Builders.create(tg, WeakCompositeRef.valueOf(tradesPane));
      traderBtn.setId("xfe-trades-traderButton");
      traderBtn.mouseTransparentProperty().bind(tg.selectedToggleProperty().isEqualTo(traderBtn));
      StringBinding text = new StringBinding() {
         {
            bind(xfeSessionModule.getUnderlyingSession().onBehalfTraderId, sizeOfTrader);
         }

         @Override
         protected String computeValue() {
            return xfeSessionModule.getUnderlyingSession().onBehalfTraderId.get() +" ("+sizeOfTrader.get()+")";
         }
      };

      DynamicFilter<ObservableReplyRow> onBehalfTraderFilterLeg = filters.isOnbehalfTrade4BrokerOnlyLeg();
      DynamicFilter<ObservableReplyRow> brokerFilterOnlyLeg = filters.isOpertatorOnlyLeg();
      DynamicFilter<ObservableReplyRow> legFilter = filters.legFilter4Broker(brokerFilterOnlyLeg,onBehalfTraderFilterLeg,traderBtn.selectedProperty(),brokerBtn.selectedProperty());
      ObservableList<ObservableReplyRow> legs = ObservableCollections.filter(tradeAggregator.items, legFilter,tracker);
      tracker.bind(strategyChk.textProperty(),Bindings.format("Legs (%d)", Fx.sizeOfList(legs)));

      tracker.bind(traderBtn.textProperty(), text);

      buttonsPane.getChildren().setAll(brokerBtn, allBtn,traderBtn);


      tracker.bindBidirectional(strategyChk.selectedProperty(), configurationModule.getParametersStorage().get(PersistantName.TradesPaneShowLegs, false));

      tracker.addListener(tg.selectedToggleProperty(), (observableToggle, oldToggle, newToggle) -> {
         myTrades.getSelectionModel().clearSelection();

         int toggleIndex = tg.getToggles().indexOf(newToggle);

         if (toggleIndex != -1) {
            configurationModule.getData().selectedTradesTabProperty().set(toggleIndex);
         }

         if (newToggle == brokerBtn) {
            myTrades.setItems(Fx.alwaysUnequal(brokerView));
            seletedTabObjectProperty.setValue(SelectedTab.BROKER);
         } else if (newToggle == allBtn) {
            myTrades.setItems(Fx.alwaysUnequal(allView));
            seletedTabObjectProperty.setValue(SelectedTab.ALL);
         } else if (newToggle == traderBtn) {
            myTrades.setItems(Fx.alwaysUnequal(onBehalfTraderView));
            seletedTabObjectProperty.setValue(SelectedTab.TRADER);
         }
      });
      rightDecorationHBox.getChildren().addAll(strategyChk,myTradersChk);
      int selectedToggle = configurationModule.getData().selectedTradesTabProperty().get();
      if (selectedToggle >= tg.getToggles().size()) selectedToggle = tg.getToggles().size() - 1;
      tg.getToggles().get(selectedToggle).setSelected(true);

      tracker.addListener(configurationModule.getData().selectedTradesTabProperty(), observable -> {
         tg.getToggles().get(configurationModule.getData().selectedTradesTabProperty().get()).setSelected(true);
      });

   }

   private void attachTabSelectorAccelerators(
      DecoratedTitledPane tradesPane) {
      TabSelector tabSelector = new ToggleButtonPaneSelector(
         WeakCompositeRef.valueOf(tg),
         WeakCompositeRef.valueOf(tradesPane));

      EventHandler<KeyEvent> ctrlUpEventHandler = KeyEventFilter
         .filterBy(tabSelector.reverseEvent(), new KeyCodeCombination(
            KeyCode.PAGE_UP, KeyCombination.CONTROL_DOWN));
      EventHandler<KeyEvent> ctrlDnEventHandler = KeyEventFilter
         .filterBy(tabSelector.forwardEvent(), new KeyCodeCombination(
            KeyCode.PAGE_DOWN, KeyCombination.CONTROL_DOWN));

      tradesPane.addEventFilter(KeyEvent.KEY_PRESSED, ctrlUpEventHandler);
      tradesPane.addEventFilter(KeyEvent.KEY_PRESSED, ctrlDnEventHandler);

      tracker.registerRollbackAction(() -> {
         tradesPane.removeEventFilter(KeyEvent.KEY_PRESSED,
            ctrlDnEventHandler);
         tradesPane.removeEventFilter(KeyEvent.KEY_PRESSED,
            ctrlUpEventHandler);
      });
   }

   private TableView<ObservableReplyRow> setupMarketTradesView(
      ObservableList<ObservableReplyRow> items, XfeSession session, boolean isIB) {
      TableView<ObservableReplyRow> myMarketTrades = new TableViewHeaderUnmovable<>();

      myMarketTrades.getColumns().add(
         TradesColumns.createMarketInstrumentColumn());
      myMarketTrades.getColumns().add(TradesColumns.createMarketRateColumn(session));
      myMarketTrades.getColumns().add(TradesColumns.createMarketQtyColumn());
      myMarketTrades.getColumns().add(
         TradesColumns.createMarketTradeTimeColumn());
      myMarketTrades.getColumns().add(
         TradesColumns.createMarketLastUlColumn());
      if (isIB) {
         myMarketTrades.getColumns().add(
            TradesColumns.createMarketFirmColumn(xfeSessionModule.getUnderlyingSession(), TradeSide.BUY));
         myMarketTrades.getColumns().add(
            TradesColumns.createMarketFirmColumn(xfeSessionModule.getUnderlyingSession(), TradeSide.SELL));
      } else {
         myMarketTrades.getColumns().add(
            TradesColumns.createMarketPayTypeColumn());
         myMarketTrades.getColumns().add(
            TradesColumns.createMarketRecTypeColumn());
      }

      myMarketTrades.setItems(items);
      TableViewSelectionModel<ObservableReplyRow> sm = myMarketTrades
         .getSelectionModel();
      // TODO: There is no CSS entry for xfe-table-view - search and destroy
      // this style class
      myMarketTrades.getStyleClass().addAll("xfe-table",
         "xfe-has-bid-offer-color");
      // myMarketTrades.setMinHeight(60);
      myMarketTrades.setPrefHeight(100);
      sm.setSelectionMode(SelectionMode.SINGLE);

      // Listening on row selection change
      sm.getSelectedItems().addListener(
         (ListChangeListener<ObservableReplyRow>) change -> {
            while (change.next()) {
               List<? extends ObservableReplyRow> selectionList = change
                  .getAddedSubList();
               int listSize = selectionList.size();

               if (listSize == 1) {
                  isActive = true;
                  selectionContextModule
                     .setSelectionContext(new SelectionContext(
                        GridType.MarketTrades,
                        selectionList.get(0), null, sm
                        .getSelectedIndices()
                        .get(0)));
               }
            }
         });

      return myMarketTrades;
   }

   private TableView<ObservableReplyRow> setupTradesView(
      TradesFilters filters,
      ObservableList<ObservableReplyRow> allTrades) {

      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> tradeInfoAction = new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
         @Override
         public void call(ObservableReplyRow row,
                          TableCell<ObservableReplyRow, ?> cell) {
            logger.debug("Creating Info popup");
            Asn1Type tradeNo = row.getAsn(AmpTrade.tradeNo);
            ObservableList<ObservableReplyRow> tradePopupCursorRows = ObservableCollections
               .sort(allTrades, RowFilters.equalsAsnStatic(
                  AmpTrade.tradeNo, tradeNo));
            TradesInfoPopup infoPopup = new TradesInfoPopup(cell,
               tradePopupCursorRows, filters,
               xfeSessionModule.getUnderlyingSession(),
               sessionModule.connectedProperty());
            layoutManagerModule.register(infoPopup,null);
            infoPopup.show(cell.getScene().getWindow());
         }
      };

      TableView<ObservableReplyRow> myTrades = new TableViewHeaderUnmovable<>();
      Property<Runnable> interrogationActionProperty = new SimpleObjectProperty<>(
         Functions.NOOP_RUNNABLE);
      myTrades.getColumns().add(TradesColumns.createInstrumentColumn(xfeSessionModule.getUnderlyingSession(),interrogationActionProperty, tradeInfoAction, null));
      myTrades.getColumns().add(TradesColumns.createPayRecColumn(xfeSessionModule.getUnderlyingSession()));
      myTrades.getColumns().add(TradesColumns.createRateColumn(xfeSessionModule, null));
      myTrades.getColumns().add(TradesColumns.createQtyColumn(xfeSessionModule.getUnderlyingSession(), null));
      myTrades.getColumns().add(TradesColumns.createStatusColumn(xfeSessionModule.getUnderlyingSession(),null));
      myTrades.getColumns().add(TradesColumns.createTradeTimeColumn(xfeSessionModule.getUnderlyingSession(),null));
      myTrades.getColumns().add(TradesColumns.createFirmColumn(xfeSessionModule.getUnderlyingSession(),null));
      myTrades.getColumns().add(TradesColumns.createTraderColumn(xfeSessionModule.getUnderlyingSession(),null));
      myTrades.getColumns().add(TradesColumns.createBrokerTickColumn(xfeSessionModule.getUnderlyingSession()));

      XfeTableColumn<ObservableReplyRow, String> istrCol = new XfeTableColumn<>();
      istrCol.setCellFactory(Tables.asnValueCellFactory(AmpTrade.secCode));

      TableViewSelectionModel<ObservableReplyRow> sm = myTrades
         .getSelectionModel();

      myTrades.getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
      // myTrades.setMinHeight(60);
      myTrades.setPrefHeight(100);
      sm.setSelectionMode(SelectionMode.SINGLE);

      // Listening on row selection change
      tracker.addListener(sm.selectedItemProperty(),
         (observableValue, oldValue, newValue) -> {
            if (newValue != null) {
               isActive = true;
               selectionContextModule
                  .setSelectionContext(new SelectionContext(
                     GridType.Trades, newValue, null, sm
                     .getSelectedIndex()));
            } else if (selectionContextModule.getSelectionContext().grid == GridType.Trades) {
               isActive = false;
               selectionContextModule
                  .setSelectionContext(new SelectionContext(GridType.Trades, null, null, -1));
            }
         });

      return myTrades;
   }

   private TableView<ObservableReplyRow> setupTradesView4Broker(
      TradesFilters filters,
      ObservableList<ObservableReplyRow> allTrades) {

      Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>> tradeInfoAction = new Proc2<ObservableReplyRow, TableCell<ObservableReplyRow, ?>>() {
         @Override
         public void call(ObservableReplyRow row,
                          TableCell<ObservableReplyRow, ?> cell) {
            logger.debug("Creating Info popup");
            Asn1Type tradeNo = row.getAsn(AmpTrade.tradeNo);
            ObservableList<ObservableReplyRow> tradePopupCursorRows = ObservableCollections
               .sort(allTrades, RowFilters.equalsAsnStatic(
                  AmpTrade.tradeNo, tradeNo));
            TradesInfoPopup infoPopup = new TradesInfoPopup(cell,
               tradePopupCursorRows, filters,
               xfeSessionModule.getUnderlyingSession(),
               sessionModule.connectedProperty());
            layoutManagerModule.register(infoPopup,null);
            infoPopup.show(cell.getScene().getWindow());
         }
      };

      TableView<ObservableReplyRow> myTrades = new TableViewHeaderUnmovable<>();
      Property<Runnable> interrogationActionProperty = new SimpleObjectProperty< >(
         Functions.NOOP_RUNNABLE);
      myTrades.getColumns().add(TradesColumns.createInstrumentColumn(xfeSessionModule.getUnderlyingSession(),interrogationActionProperty, tradeInfoAction, filters.isLegForBroker));
      myTrades.getColumns().add(TradesColumns.createRateColumn(xfeSessionModule,filters.isLegForBroker));
      myTrades.getColumns().add(TradesColumns.createQtyColumn(xfeSessionModule.getUnderlyingSession(),filters.isLegForBroker));
      myTrades.getColumns().add(TradesColumns.createStatusColumn(xfeSessionModule.getUnderlyingSession(),filters.isLegForBroker));
      myTrades.getColumns().add(TradesColumns.createTradeTimeColumn(xfeSessionModule.getUnderlyingSession(),filters.isLegForBroker));
      myTrades.getColumns().add(TradesColumns.createFirmColumn(xfeSessionModule.getUnderlyingSession(), TradeSide.BUY, filters.isLegForBroker));
      myTrades.getColumns().add(TradesColumns.createFirmColumn(xfeSessionModule.getUnderlyingSession(), TradeSide.SELL, filters.isLegForBroker));

      XfeTableColumn<ObservableReplyRow, String> istrCol = new XfeTableColumn<>();
      istrCol.setCellFactory(Tables.asnValueCellFactory(AmpTrade.secCode));

      TableViewSelectionModel<ObservableReplyRow> sm = myTrades
         .getSelectionModel();

      myTrades.getStyleClass().addAll("xfe-table", "xfe-has-bid-offer-color");
      // myTrades.setMinHeight(60);
      myTrades.setPrefHeight(100);
      sm.setSelectionMode(SelectionMode.SINGLE);

      // Listening on row selection change
      tracker.addListener(sm.selectedItemProperty(),
         (observableValue, oldValue, newValue) -> {
            if (newValue != null) {
               isActive = true;
               selectionContextModule
                  .setSelectionContext(new SelectionContext(
                     GridType.Trades, newValue, null, sm
                     .getSelectedIndex()));
            } else if (selectionContextModule.getSelectionContext().grid == GridType.Trades) {
               isActive = false;
               selectionContextModule
                  .setSelectionContext(new SelectionContext(GridType.Trades, null, null, -1));
            }
         });

      return myTrades;
   }

   private final ListenerTracker tracker = new ListenerTracker();
   private final ObjectProperty<SelectedTab> seletedTabObjectProperty = new SimpleObjectProperty<>();
   public final ReadOnlyObjectProperty<SelectedTab> selectedTab = seletedTabObjectProperty;
   private final Comparator<QueryReplyRow> reverseComparator = Comparator.reverseOrder();
   private final CheckBox strategyChk = new CheckBox() {
      {
         this.getStyleClass().add("xfe-iswap-chk");
         this.setSelected(false);
         this.setAlignment(Pos.CENTER_LEFT);
         this.setTextOverrun(OverrunStyle.CENTER_ELLIPSIS);
         this.visibleProperty().bind(this.managedProperty());
      }
   };
   private boolean isActive;
   private ToggleGroup tg ;
   private TradesFeedAdapter tradesFeed;
   private TradesFeedAdapter marketTradesFeed;
   private TradesFilters filters;
   private FeedAggregator<ObservableReplyRow> tradeAggregator;
   private FeedAggregator<ObservableReplyRow> marketAggregator;
   private DecoratedTitledPane tradesPane;
   private StackPane sp;
   private HBox buttonsPane;
   private HBox rightDecorationHBox;
}
