package xfe.icap.modules.sectabsui;

import java.util.Objects;
import java.util.function.Function;

/**
 * Value object for all price cells in instrument table.
 *
 * @param <T>
 */
public class PriceCellValue<T> {
    private T value;
    private WatchListCellState state;
    private String flashOnValue;
    private String flashOffValue;
    private Function<Number, String> formatter;
    private WatchListCellState priceFlashState;
    private T priceTick;

    public PriceCellValue(T value) {
        this.value = value;
    }

    public PriceCellValue(PriceCellValue<T> item) {
        this.value = item.getValue();
        this.state = item.getState();
        this.flashOnValue = item.getFlashOnValue();
        this.flashOffValue = item.getFlashOffValue();
        this.formatter = item.getFormatter();
    }

    public boolean isCLOBWorkup() {
        return WatchListCellState.WORKUP_CLOB_ORDER == getState();
    }

    public boolean isCMWorkup() {
        return WatchListCellState.WORKUP_CM_ORDER == getState();
    }

    public boolean isCMAmend() {
        return WatchListCellState.MY_CM_ORDER == getState() || WatchListCellState.FIRM_CM_ORDER == getState();
    }

    public T getValue() {
        return value;
    }

    public WatchListCellState getState() {
        return state;
    }

    public void setState(WatchListCellState state) {
        this.state = state;
    }

    public String getFlashOnValue() {
        return flashOnValue;
    }

    public void setFlashOnValue(String flashOnValue) {
        this.flashOnValue = flashOnValue;
    }

    public String getFlashOffValue() {
        return flashOffValue;
    }

    public void setFlashOffValue(String flashOffValue) {
        this.flashOffValue = flashOffValue;
    }

    public Function<Number, String> getFormatter() {
        return formatter;
    }

    public void setFormatter(Function<Number, String> formatter) {
        this.formatter = formatter;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public WatchListCellState getPriceFlashState() {
        return priceFlashState;
    }

    public boolean hasPriceFlash() {
        return getPriceFlashState() != null;
    }

    public void setPriceFlashState(WatchListCellState priceFlashState) {
        this.priceFlashState = priceFlashState;
    }

    public T getPriceTick() {
        return priceTick;
    }

    public void setPriceTick(T priceTick) {
        this.priceTick = priceTick;
    }

    public String toFullString() {
        return "PriceCellValue{" +
                "value=" + value +
                "priceTick=" + priceTick +
                ", state=" + state +
                ", flashOnValue='" + flashOnValue + '\'' +
                ", flashOffValue='" + flashOffValue + '\'' +
                ", priceFlashState=" + priceFlashState +
                '}';
    }

   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (!(o instanceof PriceCellValue)) return false;
      PriceCellValue<?> that = (PriceCellValue<?>) o;
      return Objects.equals(value, that.value) &&
              state == that.state &&
              Objects.equals(flashOnValue, that.flashOnValue) &&
              Objects.equals(flashOffValue, that.flashOffValue) &&
              Objects.equals(formatter, that.formatter) &&
              priceFlashState == that.priceFlashState &&
              Objects.equals(priceTick, that.priceTick);
   }

   @Override
   public int hashCode() {
      return Objects.hash(value, state, flashOnValue, flashOffValue, formatter, priceFlashState, priceTick);
   }

   @Override
    public String toString() {
        if (value == null)
            return "";

        return value.toString();
    }

   /**
    * Specifies if the price cell is amendable. (or his own order, order of same firm or order placed onbehalf by
    * broker)
    * @return true if amendable
    */
    public boolean isAmendable(){
       return WatchListCellState.MY_CLOB_ORDER == state || WatchListCellState.FIRM_CLOB_ORDER == state;
    }
}
