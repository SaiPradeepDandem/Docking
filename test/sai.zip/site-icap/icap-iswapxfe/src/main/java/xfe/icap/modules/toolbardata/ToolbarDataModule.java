package xfe.icap.modules.toolbardata;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import xfe.module.Module;
import xfe.modules.actionsui.ActionButton;
import xfe.modules.session.SessionScopeModule;
import xfe.ui.control.IconButton;
import xfe.util.XfeAction;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// FIXME : Need to delete this class.
@Deprecated
@Module.Autostart
public class ToolbarDataModule extends SessionScopeModule {

   private static final int MAX_NUM_ACTIONS = 12;
   private static final int BUTTON_WIDTH = 28;
   private static final int BUTTON_HEIGHT = 24;

   public void addAction(int index, XfeAction action) {
      if (actionToBtnIdx.containsValue(index)) {
         for (Map.Entry<XfeAction, Integer> e : actionToBtnIdx.entrySet()) {
            if (index == e.getValue()) {
               break;
            }}
      }

      if (index < 0 || index >= MAX_NUM_ACTIONS)
         throw new ArrayIndexOutOfBoundsException(index);

      if (action == null)
         throw new IllegalArgumentException("Action object cannot be null");

      actionToBtnIdx.put(action, index);

      if (actionButtons.get(index) == null) {
         actionButtons.set(index, createActionButton());
      }

      Button button = (Button)actionButtons.get(index);
      action.bindTo(button);
      HBox.setHgrow(button, Priority.ALWAYS);
   }

   private Button createActionButton() {
      Button btn = new IconButton();
      btn.setPrefWidth(BUTTON_WIDTH);
      btn.setPrefHeight(BUTTON_HEIGHT);
      btn.setMaxWidth(BUTTON_WIDTH);
      btn.setMaxHeight(BUTTON_HEIGHT);
      btn.setMinWidth(BUTTON_WIDTH);
      btn.setMinHeight(BUTTON_HEIGHT);
      List<String> styles = btn.getStyleClass();
      if(!styles.contains(ActionButton.NORMAL_STYLE)) {
         styles.add(ActionButton.NORMAL_STYLE);
      }
      return btn;
   }

   public void setupToolbar(ToolBar toolbar) {
      ToolBar actionsPane = toolbar;
      for (int i = 0; i < MAX_NUM_ACTIONS; ++i) {
         if (actionButtons.get(i) == null) {
            actionButtons.set(i, createActionButton());
         }
      }
      actionsPane.getItems().addAll(actionButtons);
      actionButtons = actionsPane.getItems();
   }

   private final HashMap<XfeAction, Integer> actionToBtnIdx =  new HashMap<>();
   private ObservableList<Node> actionButtons = FXCollections.observableList(Arrays.asList(new Node[MAX_NUM_ACTIONS]));
}
