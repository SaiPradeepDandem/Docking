package xfe.icap.modules.iswaptrades;

import java.util.*;

import xstr.amp.AsnWrapper;
import com.objsys.asn1j.runtime.Asn1Type;

public class TradeAlertComparator  implements Comparator<TradeAlert> {

	private static final int MAX_SPREAD_DEPTH = 2;

   class TradeNode {
      AsnWrapper<Asn1Type> tradeId;
      AsnWrapper<Asn1Type> buyParentId;
      AsnWrapper<Asn1Type> sellParentId;

      public TradeNode(AsnWrapper<Asn1Type> tradeId, AsnWrapper<Asn1Type> buyParentId, AsnWrapper<Asn1Type> sellParentId) {
         this.tradeId = tradeId;
         this.buyParentId = buyParentId;
         this.sellParentId = sellParentId;
      }
   }
   private Map<AsnWrapper<Asn1Type>, TradeNode> tradeNodeMap = new HashMap<>(1024);

	public TradeAlertComparator() {
   }

   public void dispose() {
      tradeNodeMap.clear();
   }

   public void addTradeNode(Asn1Type asnTradeId, Asn1Type asnBuyParentId, Asn1Type asnSellParentId) {
      AsnWrapper<Asn1Type> newTradeId = new AsnWrapper<>(asnTradeId);
      AsnWrapper<Asn1Type> newBuyParent = null;
      AsnWrapper<Asn1Type> newSellParent = null;
      if (asnBuyParentId != null)
         newBuyParent = new AsnWrapper<>(asnBuyParentId);
      if (asnSellParentId != null)
         newSellParent = new AsnWrapper<>(asnSellParentId);
      TradeNode oldNode = tradeNodeMap.get(newTradeId);
      if (oldNode == null) {
         tradeNodeMap.put(newTradeId,  new TradeNode(newTradeId, newBuyParent, newSellParent));
      } else {
         oldNode.buyParentId = newBuyParent;
         oldNode.sellParentId = newSellParent;
      }

      if (asnBuyParentId != null) {
         TradeNode buyParentNode = tradeNodeMap.get(newBuyParent);
         if (buyParentNode == null)
            tradeNodeMap.put(newBuyParent,  new TradeNode(newBuyParent, null, null));
      }

      if (asnSellParentId != null && !asnSellParentId.equals(asnBuyParentId)) {
         TradeNode sellParentNode = tradeNodeMap.get(newSellParent);
         if (sellParentNode == null)
            tradeNodeMap.put(newSellParent,  new TradeNode(newSellParent, null, null));
      }
   }

	@Override
	public int compare(TradeAlert trade1, TradeAlert trade2) {

		// We first reverse it by time
		Date trade1Time = trade1.timestamp;
		Date trade2Time = trade2.timestamp;

		int dateCompare = trade2Time.compareTo(trade1Time);

		if (dateCompare != 0) return dateCompare;

		// If the date is the same we compare based on parents

		AsnWrapper<Asn1Type> trade1Id = new AsnWrapper<>(trade1.tradeId);
		AsnWrapper<Asn1Type> trade2Id = new AsnWrapper<>(trade2.tradeId);

		if (trade1Id.equals(trade2Id)) return 0;

		List<AsnWrapper<Asn1Type>> t1ParentsList = new LinkedList<>();
		List<AsnWrapper<Asn1Type>> t2ParentsList = new LinkedList<>();
		int search1Depth  = GetDeepestParents(trade1Id, t1ParentsList, MAX_SPREAD_DEPTH);
		int search2Depth  = GetDeepestParents(trade2Id, t2ParentsList, MAX_SPREAD_DEPTH);

		// First we handle cases were the two trades either have no common parent or else do have one,
		// but are at exactly the same level relative to it - in this case we determine the order by the first varying parent
		// ids starting from top ancestor (or their own ids if they have no parents)

		for (int i = 0; i <= Math.min(search1Depth, search2Depth); ++i) {
			 if (i > 0) {
				 GetDeepestParents(trade1Id, t1ParentsList, search1Depth - i);
				 GetDeepestParents(trade2Id, t2ParentsList, search2Depth - i);
			 }

			 if (hasCommon(t1ParentsList, t2ParentsList)) continue;

			 AsnWrapper<Asn1Type> parentTrade1Id = t1ParentsList.get(0);
			 AsnWrapper<Asn1Type> parentTrade2Id = t2ParentsList.get(0);

			 return parentTrade2Id.compareTo(parentTrade1Id);
		}

		return search1Depth - search2Depth;
	}

	private int GetDeepestParents(AsnWrapper<Asn1Type> tradeId,
			 					  List<AsnWrapper<Asn1Type>> parentsList,
			 					  int maxSpreadDepth) {
		// This method returns the deepest list of parents for tradeId up to maxSpreadDepth
		// So if the total depth of the tree starting from tradeId is 5, but maxSpreadDepth is 3, the level 3
		// the level 3 ancestors will be returned.
		// if the total depth is 2 (i.e. less than maxSpreadDepth) then the level 2 ancestors
		// will be returned.

		int searchDepth = maxSpreadDepth;
		parentsList.clear();
		parentsList.addAll(getNLevelParentIds(tradeId, searchDepth));

		while (parentsList.isEmpty()) {
			 parentsList.addAll(getNLevelParentIds(tradeId, --searchDepth));

			 if (searchDepth == 0) break;
		}

		return searchDepth;
	}

	private boolean hasCommon(List<AsnWrapper<Asn1Type>> t1ParentsList,
							  List<AsnWrapper<Asn1Type>> t2ParentsList) {
		Set<AsnWrapper<Asn1Type>> t1ParentsSet = new HashSet<>(t1ParentsList);
		Set<AsnWrapper<Asn1Type>> t2ParentsSet = new HashSet<>(t2ParentsList);

		t1ParentsSet.retainAll(t2ParentsSet);

		return !t1ParentsSet.isEmpty();
	}

   private List<AsnWrapper<Asn1Type>> getImmediateParentIds(AsnWrapper<Asn1Type> tradeId) {
      List<AsnWrapper<Asn1Type>> list = new LinkedList<>();

      TradeNode node = tradeNodeMap.get(tradeId);

      if (node.buyParentId != null)
         list.add(node.buyParentId);

      if (node.sellParentId != null && !node.sellParentId.equals(node.buyParentId))
         list.add(node.sellParentId);

      return list;
   }

   private List<AsnWrapper<Asn1Type>> getNLevelParentIds(AsnWrapper<Asn1Type> tradeId,
                                                        int level) {
      if (level == 0) {
         List<AsnWrapper<Asn1Type>> list = new LinkedList<>();
         list.add(tradeId);
         return list;
      }

      if (level == 1) {
         return getImmediateParentIds(tradeId);
      }

      Set<AsnWrapper<Asn1Type>> set = new HashSet<>();
      List<AsnWrapper<Asn1Type>> list = getNLevelParentIds(tradeId, --level);

      for (AsnWrapper<Asn1Type> id : list) {
         set.addAll(getImmediateParentIds(id));
      }

      return new ArrayList<>(set);
   }
}
