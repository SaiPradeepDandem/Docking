package xfe.icap.modules.ordersui;

import javafx.scene.control.TableCell;
import xfe.icap.amp.AmpManagedOrder;
import xfe.modules.actions.OrderActionArgs;
import xfe.ui.control.SvgButton;
import xstr.session.ObservableReplyRow;
import xfe.modules.actions.ActionName;
import xfe.ui.control.IconButton;

/**
 * Custom action table cell of Orders to withdraw the corresponding order.
 */
public class OrdersWithdrawActionTableCell extends TableCell<ObservableReplyRow, Integer> {
   private SvgButton withdrawButton;

   @Override
   protected void updateItem(Integer item, boolean empty) {
      super.updateItem(item, empty);
      if (item == null || !(item.equals(AmpManagedOrder.OPENED) || item.equals(AmpManagedOrder.REFERRED))) {
         setGraphic(null);
      } else {
         setGraphic(getWithdrawButton());
      }
   }

   /**
    * Lazy getter of the withdraw button.
    *
    * @return IconButton
    */
   private SvgButton getWithdrawButton() {
      if (this.withdrawButton == null) {
         final SvgButton withdrawButton = new SvgButton("xfe-svg-bg", "xfe-icon-withdraw");
         withdrawButton.setPrefSize(16,16);
         withdrawButton.setOnAction(e -> {
            final ObservableReplyRow row = (ObservableReplyRow) getTableRow().getItem();
            getTableView().getSelectionModel().select(row);
            ((OrdersViewTable) getTableView()).getOrderActionConsumer().accept(new OrderActionArgs(ActionName.WithdrawOrder, row, this));
         });
         this.withdrawButton = withdrawButton;
      }
      return this.withdrawButton;
   }
}
