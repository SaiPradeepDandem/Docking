package xfe.icap.modules.watchlist;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import xfe.icap.types.IcapSecBoardTrim2Watchlist;
import xfe.types.SecBoard;
import xfe.types.Watchlist;
import xstr.util.Fun1;
import xstr.util.concurrent.DisposableBase;
import xstr.util.concurrent.Future;
import xstr.util.exception.AmpPermissionException;
import xstr.util.exception.AsnTypeException;

import xstr.types.*;
import xstr.session.QueryFeed;
import xstr.session.XtrQueryRequestBuilder;
import xstr.amp.AsnAccessor;
import xstr.session.XtrQueryRequest;
import xstr.util.FeedAggregator;
import xstr.util.Fx;
import xfe.icap.XfeSession;
import xfe.icap.amp.AmpIcapSecBoardTrim2;
import xfe.icap.amp.AmpNLevelImplied;
import xstr.session.ObservableReplyRow;
import xfe.util.Constants;
import com.omxgroup.xstream.amp.AmpOrderImpliedType;
import com.omxgroup.xstream.amp.AmpOrderVerb;
import xstr.session.ObservableReplyRow.ObservableRowFactory;

public class ImpliedQueryStruct extends DisposableBase {
	private static final Logger logger = LoggerFactory.getLogger(ImpliedQueryStruct.class);
	private final Runnable disposeAction;
	final StringProperty rate = new SimpleStringProperty(this, Constants.COLUMN_NAME_RATE, "");
	final StringProperty quantity = new SimpleStringProperty(this, "quantity", "");
	final String secCode;
	final String boardId;
	final FeedAggregator<ObservableReplyRow> aggregator;

	final BooleanProperty dataReady = new SimpleBooleanProperty(this, "dataReady", false);

	public ImpliedQueryStruct(
	      XfeSession session,
	      ObservableReplyRow row,
			OrderSide orderSide,
			int orderImpliedType,
			AsnAccessor priceAcc,
			AsnAccessor qtyAcc) throws AsnTypeException, AmpPermissionException {
		Watchlist watchList = new IcapSecBoardTrim2Watchlist(session);
		this.secCode = row.getValue(AmpIcapSecBoardTrim2.secCode);
		this.boardId = row.getValue(AmpIcapSecBoardTrim2.boardId);
		session.secBoards.get().getSecBoard(secCode, boardId).map(new Fun1<SecBoard, Void>(){

         @Override
         public Void call(SecBoard secBoard) {
            watchList.getSpecWatchedSecboards().setAll(secBoard);
            return null;
         }
		});
		watchList.getItems().addListener(new InvalidationListener() {
			@Override
			public void invalidated(Observable obsVal) {
				if (!watchList.getItems().isEmpty()) {
					ObservableReplyRow watchedRow = watchList.getItems().get(0);
					rate.bind(watchedRow.getStringProperty(priceAcc));
					quantity.bind(
					      orderImpliedType == AmpOrderImpliedType.display
			            ? Fx.constOf(null) : watchedRow.getStringProperty(qtyAcc));
				}
			}
		});

		XtrQueryRequest req = XtrQueryRequestBuilder.create(AmpNLevelImplied.req, session.getUnderlyingSession())
			.set(AmpNLevelImplied.reqSecCode, secCode)
			.set(AmpNLevelImplied.reqBoardId, boardId)
			.set(AmpNLevelImplied.buySell, orderSide == OrderSide.BUY ? AmpOrderVerb.buy : AmpOrderVerb.sell)
			.set(AmpNLevelImplied.orderImpliedType, orderImpliedType)
			.build();

		aggregator = new FeedAggregator<ObservableReplyRow>(AmpNLevelImplied.rep, new ObservableRowFactory());
		aggregator.busyProperty().addListener(new InvalidationListener() {

			@Override
			public void invalidated(Observable arg0) {
				if(!aggregator.isBusy()) {
					dataReady.set(true);
					aggregator.busyProperty().removeListener(this);
				}
			}
		});

		QueryFeed feed = session.getUnderlyingSession().queries.getFeedSource(req);
		feed.addListener(aggregator);
		this.rate.bind(row.getStringProperty(priceAcc));
		this.quantity.bind(orderImpliedType == AmpOrderImpliedType.display
		      ? Fx.constOf(null)
		      : row.getStringProperty(qtyAcc));

//		FxLog.debug(logger, Bindings.size(aggregator.getItems()));
		this.disposeAction = new Runnable() {
			@Override
			public void run() {
				feed.removeListener(aggregator);
				watchList.dispose();
			}
		};
	}

	ObservableList<ObservableReplyRow> getItems() {
		return aggregator.items;
	}

   @Override
   protected Future<Void> dispose(boolean disposing) {
      disposeAction.run();

      return super.dispose(disposing);
   }
}
