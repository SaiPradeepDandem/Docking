package xfe.icap.modules.springboard;

import javafx.scene.layout.StackPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.icap.modules.layout.midi.MidiLayoutModule;
import xfe.icap.modules.layout.midi.MidiLayoutViews;
import xfe.icap.modules.settings.ConfigurationModule;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;
import xstr.util.concurrent.Future;

@Module.Autostart
public class SpringBoardUIModule extends SessionScopeModule {
   private static final Logger logger = LoggerFactory.getLogger(SpringBoardUIModule.class);

   @ModuleDependency
   public MidiLayoutModule midiLayoutModule;

   @ModuleDependency
   public ConfigurationModule configurationModule;

   private StackPane root;

   @Override
   public Future<Void> startModule() {
      root = new StackPane();
      this.root.setId(MidiLayoutViews.SPRINGBOARD_VIEW);
      root.setPrefSize(150,300);

      if(configurationModule.getData().springBoardOpened().get()){
         openSpringBoard();
      }

      midiLayoutModule.setSpringBoardLauncher(this::openSpringBoard);
      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      midiLayoutModule.setSpringBoardLauncher(null);
      midiLayoutModule.removeView(getRoot());
      root = null;
      return Future.SUCCESS;
   }

   public StackPane getRoot() {
      return root;
   }

   public void openSpringBoard(){
      midiLayoutModule.addView(getRoot());
   }
}
