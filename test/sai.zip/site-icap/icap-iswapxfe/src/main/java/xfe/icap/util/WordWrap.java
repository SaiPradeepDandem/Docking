package xfe.icap.util;

/**
 * Created by soopot on 10/4/2019.
 *
 * @author Sooraj Pottekat
 */
public class WordWrap{
   public static String wrap(String input, int delim){
      StringBuilder sb = new StringBuilder(input);
    for (int i = delim; i < sb.length(); i = i+delim) {
       sb.insert(i, "\n");
       i++;
    }
      return sb.toString();
   }
}
