package xfe.icap.types;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;

public class SweepRateQty {
	@Override
	public int hashCode() {
		int prime = 31;
		int result = 1;
		result = prime * result
				+ ((isSweepBuy == null) ? 0 : isSweepBuy.hashCode());
		result = prime * result
				+ ((totalQty == null) ? 0 : totalQty.hashCode());
		result = prime * result
				+ ((wavgRate == null) ? 0 : wavgRate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SweepRateQty other = (SweepRateQty) obj;
		if (isSweepBuy == null) {
			if (other.isSweepBuy != null)
				return false;
		} else if (!isSweepBuy.equals(other.isSweepBuy))
			return false;
		if (totalQty == null) {
			if (other.totalQty != null)
				return false;
		} else if (!totalQty.equals(other.totalQty))
			return false;
		if (wavgRate == null) {
         return other.wavgRate == null;
		} else return wavgRate.equals(other.wavgRate);
   }

	private final ObjectProperty<Double> wavgRate = new SimpleObjectProperty<Double>();
	private final ObjectProperty<Double> totalQty = new SimpleObjectProperty<Double>();
	private final ObjectProperty<Boolean> isSweepBuy = new SimpleObjectProperty<Boolean>();

	public SweepRateQty() {
		wavgRate.set(null);
		totalQty.set(null);
		isSweepBuy.set(null);
	}

	public SweepRateQty(Double wavgRate,
                       Double totalQty,
                       Boolean isSweepBuy) {
		this.wavgRate.set(wavgRate);
		this.totalQty.set(totalQty);
		this.isSweepBuy.set(isSweepBuy);
	}

	public SweepRateQty(SweepRateQty sweepRateQty) {
		if (sweepRateQty == null) return;

		wavgRate.set(sweepRateQty.wavgRate.get());
		totalQty.set(sweepRateQty.totalQty.get());
		isSweepBuy.set(sweepRateQty.isSweepBuy.get());
	}

	public Property<Double> getWavgRate() {
		return wavgRate;
	}

	public Property<Double> getTotalQty() {
		return totalQty;
	}

	public boolean isNull() {
		return wavgRate.get() == null && totalQty.get() == null && isSweepBuy.get() == null;
	}

	public boolean isValid() {
	   return wavgRate.get() != null && totalQty.get() != null && isSweepBuy.get() != null;
   }

	public Property<Boolean> getIsSweepBuy() {
		return isSweepBuy;
	}

   @Override
   public String toString() {
      return "SweepRateQty [wavgRate=" + wavgRate.get() + ", totalQty=" + totalQty.get() + ", isSweepBuy=" + isSweepBuy.get() + "]";
   }

}
