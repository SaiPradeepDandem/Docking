package xfe.icap.modules.watchlist;

import xstr.amp.AMP;
import xstr.session.QueryFeed;
import xstr.session.SessionListener;
import xstr.session.XtrQueryRequest;
import xfe.types.UiSession;
import xstr.util.AmpListAggregator;
import xstr.util.ListenerTracker;
import xstr.util.concurrent.Future;
import xstr.util.exception.AsnTypeException;
import xfe.module.Module;

import java.util.LinkedList;
import java.util.List;

public class MemoryLeakDetectorsModule implements Module,SessionListener {
   public static final int aggregatorCount = 10000;


   @ModuleDependency
   public UiSession xfeSession;

   private final ListenerTracker tracker = new ListenerTracker();

   private final List<AmpListAggregator> traderAggregators = new LinkedList<AmpListAggregator>();
   {
      for (int i = 0; i < aggregatorCount; ++i) {
         AmpListAggregator ampListAggregator = new AmpListAggregator(AMP.qREP("managedOrderRep"));
         traderAggregators.add(ampListAggregator);
      }

   }
   //private ObservableListSorter<QueryReplyRow> traderView;

   @Override
   public Future<Void> handleLogon() {
      initializeContents();
      return DONE;
   }

   @Override
   public void handleLogoff() {
      uninitializeContents();
   }




   private void setFeedSource() {
      try {
         XtrQueryRequest req = new XtrQueryRequest(AMP.qREQ("managedOrderReq"));
         QueryFeed ordersFeed = xfeSession.getUnderlyingSession().queries.getFeedSource(req);

         for (AmpListAggregator aggregator : traderAggregators) {
            tracker.addFeedListener(ordersFeed, aggregator);
         }
      } catch (AsnTypeException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }


   protected void uninitializeContents() {
      tracker.rollback();
   }

   protected void initializeContents() {
      setFeedSource();

   }
}
