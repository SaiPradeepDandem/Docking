package xfe.icap.modules.ordersui;

import com.nomx.persist.watchlist.ColumnSpec;
import com.nomx.persist.watchlist.ColumnsSpec;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ObservableValue;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.VBox;
import xfe.icap.amp.AmpManagedOrder;
import xfe.icap.modules.toolbar.actions.InstrumentCell;
import xfe.icap.modules.toolbar.actions.TradesAggregatePopupSource;
import xfe.icap.ui.table.TableCellUtil;
import xfe.modules.actions.OrderActionArgs;
import xfe.modules.actions.TradesAggregateArgs;
import xfe.types.SecBoardStaticInfo;
import xfe.ui.table.AlignedTableColumn;
import xfe.ui.table.ConfigurableTableView;
import xfe.ui.table.Tables;
import xfe.util.Util;
import xstr.session.ObservableReplyRow;
import xstr.types.OrderSide;
import xstr.util.concurrent.Future;

import java.math.BigDecimal;
import java.util.Date;
import java.util.function.*;

/**
 * Table view implementation for the orders view.
 */
class OrdersViewTable extends ConfigurableTableView<ObservableReplyRow> implements TradesAggregatePopupSource {
   static final PseudoClass OPENED_BID_PSEUDO_CLASS = PseudoClass.getPseudoClass("opened-bid");
   static final PseudoClass OPENED_OFFER_PSEUDO_CLASS = PseudoClass.getPseudoClass("opened-offer");
   static final PseudoClass REFERRED_PSEUDO_CLASS = PseudoClass.getPseudoClass("referred");

   private UnaryOperator<String> productHandler;
   private Function<ObservableReplyRow, ObservableValue<OrderSide>> sideColFactory;
   private BiFunction<String, String, Future<SecBoardStaticInfo>> secBoardStaticInfoGetter;// Used for Type, TraderId, BrokerId, CommType

   private class StatusCell extends TableCell<ObservableReplyRow, Integer> {
      @Override
      protected void updateItem(Integer item, boolean empty) {
         super.updateItem(item, empty);
         if (item == null) {
            setText(null);
         } else {
            setText(AmpManagedOrder.getOrderStatusDisplayValue(item));
         }
      }
   }

   OrdersViewTable() {
      setId("orders-view-table");
      setPlaceholder(Tables.stripedRowCSSPlaceholder());
      getStyleClass().add("orders-view-table");
      setRowFactory(tableView -> new OrdersViewTableRow());
      initializeTableColumns();
      setColumnResizePolicy(CONSTRAINED_RESIZE_POLICY);
   }

   private void setupColumnsMenu() {
      // setting up the menu for showing/hiding columns
      VBox settingsPane = new VBox();
      settingsPane.setPadding(new Insets(15));
      settingsPane.setSpacing(10);
      settingsPane.setPrefWidth(150);
      getColumns().forEach(col -> {
         String cbTitle = (String) col.getProperties().getOrDefault(SETTING_TEXT, col.getText());
         Double colWidth = col.getWidth();

         if (!cbTitle.isEmpty()) {
            CheckBox cb = new CheckBox(cbTitle);
            cb.selectedProperty().bindBidirectional(col.visibleProperty());
            cb.selectedProperty().addListener((observable, oldValue, newValue) -> {
               final ObjectProperty<ColumnsSpec> columnsSpec = getColumnsSpecifications();
               columnsSpec.setValue(columnsSpec.get().editColumnSpec(cbTitle, newValue));
            });
            col.widthProperty().addListener((observable, oldValue, newValue) -> {
               final ObjectProperty<ColumnsSpec> columnsSpec = getColumnsSpecifications();
               columnsSpec.setValue(columnsSpec.get().editColumnSpec(cbTitle, (Double) newValue));
            });
            settingsPane.getChildren().add(cb);
            final ObjectProperty<ColumnsSpec> columnsSpec = getColumnsSpecifications();
            columnsSpec.setValue(columnsSpec.get().setColumnSpec(cbTitle, colWidth));
            ColumnSpec spec = columnsSpec.get().getColumnSpec(cbTitle);
            col.setPrefWidth(spec.getWidth());
            col.setVisible(spec.isVisible());
         }
      });
      setSettingsContent(settingsPane);
      setTableMenuButtonVisible(true);
   }

   private void initializeTableColumns() {
      final TableColumn<ObservableReplyRow, Date> timeCol = new AlignedTableColumn<>("Time");
      timeCol.setId("time-tablecolumn");
      timeCol.setMinWidth(65);
      timeCol.setSortable(true);
      timeCol.setSortType(TableColumn.SortType.DESCENDING);
      timeCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.entryTime));
      timeCol.setCellFactory(param -> new TableCellUtil.TimeCell());

      final TableColumn<ObservableReplyRow, Long> orderNoCol = new AlignedTableColumn<>("Order No");
      orderNoCol.setMinWidth(85);
      orderNoCol.setId("orderno-tablecolumn");
      orderNoCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.managedOrderId));

      final TableColumn<ObservableReplyRow, OrderSide> sideCol = new AlignedTableColumn<>("B/O");
      sideCol.setId("side-tablecolumn");
      sideCol.setMinWidth(45);
      sideCol.setCellValueFactory(cd -> sideColFactory.apply(cd.getValue()));
      sideCol.setCellFactory(param -> new TableCellUtil.BidOfferCell());

      final TableColumn<ObservableReplyRow, String> instrumentCol = new TableColumn<>("Instrument");
      instrumentCol.setId("instrument-tablecolumn");
      instrumentCol.getStyleClass().add("xfe-bold-text");
      instrumentCol.setMinWidth(150);
      instrumentCol.setCellValueFactory(OrdersViewTable::call);
      instrumentCol.setCellFactory(p -> new InstrumentCell());

      final TableColumn<ObservableReplyRow, String> productCol = new AlignedTableColumn<>("Product");
      productCol.setId("product-tablecolumn");
      productCol.setMinWidth(150);
      productCol.setCellValueFactory(cd -> {
         final String secCode = cd.getValue().getProperty(AmpManagedOrder.secCode).get();
         return new ReadOnlyStringWrapper(productHandler.apply(secCode));
      });

      final TableColumn<ObservableReplyRow, BigDecimal> priceCol = new AlignedTableColumn<>("Price");
      priceCol.setId("price-tablecolumn");
      priceCol.setMinWidth(55);
      priceCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.price));
      priceCol.setCellFactory(param -> new TableCellUtil.PriceCell(AmpManagedOrder.secCode, AmpManagedOrder.boardId, secBoardStaticInfoGetter));

      final TableColumn<ObservableReplyRow, Double> sizeCol = new AlignedTableColumn<>("Size");
      sizeCol.setId("size-tablecolumn");
      sizeCol.setMinWidth(50);
      sizeCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.quantity_d));

      final TableColumn<ObservableReplyRow, Double> balanceCol = new AlignedTableColumn<>("Balance");
      balanceCol.setId("balance-tablecolumn");
      balanceCol.setMinWidth(70);
      balanceCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.balance_d));

      final TableColumn<ObservableReplyRow, String> traderCol = new AlignedTableColumn<>("Trader");
      traderCol.setId("trader-tablecolumn");
      traderCol.setMinWidth(80);
      traderCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.userId));

      final TableColumn<ObservableReplyRow, String> brokerCol = new AlignedTableColumn<>("Broker");
      brokerCol.setId("broker-tablecolumn");
      brokerCol.setMinWidth(65);
      brokerCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.operatorId));

      final TableColumn<ObservableReplyRow, Integer> statusCol = new AlignedTableColumn<>("Status");
      statusCol.setId("status-tablecolumn");
      statusCol.setMinWidth(60);
      statusCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.orderStatus));
      statusCol.setCellFactory(param -> new StatusCell());

      final TableColumn<ObservableReplyRow, Integer> referCol = new AlignedTableColumn<>("Action");
      referCol.setId("action-tablecolumn");
      referCol.setResizable(false);
      referCol.setMinWidth(80);
      referCol.setMaxWidth(80);
      referCol.setSortable(false);
      referCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.orderStatus));
      referCol.setCellFactory(param -> new OrdersReferActionTableCell());

      final TableColumn<ObservableReplyRow, Integer> withdrawCol = new AlignedTableColumn<>("Cancel");
      withdrawCol.setId("cancel-tablecolumn");
      withdrawCol.setResizable(false);
      withdrawCol.setMinWidth(80);
      withdrawCol.setMaxWidth(80);
      withdrawCol.setSortable(false);
      withdrawCol.setCellValueFactory(cd -> cd.getValue().getProperty(AmpManagedOrder.orderStatus));
      withdrawCol.setCellFactory(param -> new OrdersWithdrawActionTableCell());

      getColumns().addAll(timeCol, orderNoCol, sideCol, instrumentCol, productCol, priceCol, sizeCol, balanceCol, traderCol, brokerCol, statusCol, referCol, withdrawCol);
      getSortOrder().add(timeCol);
   }

   void setProductHandler(UnaryOperator<String> productHandler) {
      this.productHandler = productHandler;
   }

   void setSideFactory(Function<ObservableReplyRow, ObservableValue<OrderSide>> sideColFactoryImpl) {
      this.sideColFactory = sideColFactoryImpl;
   }

   public void setSecBoardStaticInfoGetter(BiFunction<String, String, Future<SecBoardStaticInfo>> secBoardStaticInfoGetter) {
      this.secBoardStaticInfoGetter = secBoardStaticInfoGetter;
   }

   private static ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableReplyRow, String> cd) {
      return new ReadOnlyObjectWrapper<>(Util.stripper(cd.getValue().getProperty(AmpManagedOrder.secCode).get(), "UKT"));
   }

   public void setOrdersColsSpecificationPropertySupplier(Supplier<ObjectProperty<ColumnsSpec>> ordersColsSpecificationPropertySupplier) {
      this.ordersColsSpecificationPropertySupplier = ordersColsSpecificationPropertySupplier;
      if(ordersColsSpecificationPropertySupplier!=null) {
         setupColumnsMenu();
      }
   }

   private ObjectProperty<ColumnsSpec> getColumnsSpecifications() {
      return this.ordersColsSpecificationPropertySupplier.get();
   }

   public void setOrderActionConsumer(Consumer<OrderActionArgs> orderActionConsumer) {
      this.orderActionConsumer = orderActionConsumer;
   }

   public Consumer<OrderActionArgs> getOrderActionConsumer() {
      return orderActionConsumer;
   }

   private Supplier<ObjectProperty<ColumnsSpec>> ordersColsSpecificationPropertySupplier;
   private Consumer<OrderActionArgs> orderActionConsumer;

   private Consumer<TradesAggregateArgs> tradesAggregatePopupActionConsumer;

   @Override
   public void setTradesAggregatePopupActionConsumer(Consumer<TradesAggregateArgs> tradesAggregatePopupActionConsumer) {
      this.tradesAggregatePopupActionConsumer = tradesAggregatePopupActionConsumer;
   }

   @Override
   public Consumer<TradesAggregateArgs> getTradesAggregatePopupActionConsumer() {
      return this.tradesAggregatePopupActionConsumer;
   }
}
