package xfe.icap.modules.actionsui;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import xstr.util.concurrent.Future;
import xfe.layout.FxAbstractLayout;
import xfe.module.Module;
import xfe.modules.session.SessionScopeModule;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Module.Autostart
public class ConfigActionsUIModule extends SessionScopeModule {

   @ModuleDependency
   public FxAbstractLayout layoutModule;

   private static final String toolbarId = "xfe-iswap-toolbar";
   private static final Map<String,Integer> Priorities = Collections.unmodifiableMap(new HashMap<String, Integer>() {
      {
         put("xfe-iswap-settings-btn", 10);
         put("xfe-iswap-linelist-btnid", 20);
         put("xfe-iswap-linelist-sc-btnid", 30);
         put("xfe-iswap-callme-btn", 40);
         put("xfe-iswap-ibme-btn", 50);
         put("xfe-iswap-settings-tg-filter",60);
         put("xfe-iswap-settings-tg-highlight",70);
         put("xfe-iswap-safemode-btn",80);
         put("xfe-iswap-settings-tooltip",100);
         put("xfe-combobox-pane",110);

         put("xfe-sprint-pane",900);
         put("xfe-iswap-toolbar",1000);
      }
   });

   @Override
   public Future<Void> startModule() {
      actionsPane = new ToolBar();
      actionsPane.setPadding(new Insets(1,0,1,10));
      actionsPane.setId(toolbarId);
      actionsPane.setPrefHeight(24);
      actionsPane.setMaxHeight(24);
      actionsPane.setMinHeight(24);
      actionsPane.getItems().add(sprintPane);
      actionsPane.setStyle("-fx-spacing:13px;");

      showMyself();

      return Future.SUCCESS;
   }

   @Override
   public Future<Void> stopModule() {
      if (actionsPane != null) {
         layoutModule.removeView(actionsPane);
      }
      actionsPane = null;
      return Future.SUCCESS;
   }

   /**
    * Add any node to actions panel
    * @param node The node to add to the toolbar
    */
   public void addNode(Node node) {
      if(node instanceof Button || node instanceof ToggleButton){
         node.getStyleClass().add("xfe-icon-button");
      }
      actionsPane.getItems().add(node);
      actionsPane.getItems().sort((node1, node2) -> {
         if (node2.getId() == null || Priorities.get(node2.getId()) == null) return -1;
         if (node1.getId() == null || Priorities.get(node1.getId()) == null) return 1;
         return Priorities.get(node1.getId()).compareTo(Priorities.get(node2.getId()));
      });
   }

   private void showMyself() {
      if (actionsPane != null) {
         layoutModule.addView(actionsPane);
      }
   }

   private final Pane sprintPane = new Pane(){{this.setId("xfe-sprint-pane");
      HBox.setHgrow(this, Priority.ALWAYS);}};
   private ToolBar actionsPane;
}

