package com.nomx.persist;

import xfe.icap.types.AbstractOrderTrans.OnLogoffAction;

@Deprecated
public class OnLogoffActionConverter extends Converter<OnLogoffAction, com.nomx.domain.types.OnLogoffAction> {

	public static final OnLogoffActionConverter INSTANCE = new OnLogoffActionConverter();

	private OnLogoffActionConverter() {
		super(OnLogoffAction.class, com.nomx.domain.types.OnLogoffAction.class);
	}

	@Override
	public com.nomx.domain.types.OnLogoffAction convert(OnLogoffAction input) {
		return com.nomx.domain.types.OnLogoffAction.values()[input.ordinal()];
	}
}
