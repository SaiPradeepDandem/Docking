package xstr.session;

public class ObservableReplyRow {

    private String title;

    private String phase;

    public ObservableReplyRow(String title, String phase) {
        this.title = title;
        this.phase = phase;
    }

    public String getTitle() {
        return title;
    }

    public String getPhase() {
        return phase;
    }
}
