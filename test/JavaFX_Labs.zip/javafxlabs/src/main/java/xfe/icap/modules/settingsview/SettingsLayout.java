package xfe.icap.modules.settingsview;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class SettingsLayout {

    public static SettingsLayout load() {
        FXMLLoader ldr = new FXMLLoader(SettingsLayout.class.getResource("SettingsLayout.fxml"));
        try {
            ldr.load();
            return ldr.getController();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public VBox getRoot() {
        return root;
    }

    @FXML
    private VBox root;
}
