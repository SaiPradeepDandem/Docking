package xfe.icap.modules.tradesworkup;

import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import xfe.ui.PresetSizeButtonsPane;
import xstr.session.ObservableReplyRow;

/**
 * Layout for each trade workup row.
 */
public class TradeWorkupRow {

    public static double WORKUP_ROW_CONTENT_HEIGHT = 25.0;
    public static double WORKUP_ROW_HEIGHT = WORKUP_ROW_CONTENT_HEIGHT + 18;

    @FXML
    public void initialize() {
        sellTextField.focusedProperty().addListener((obs, old, focused) -> {
            if (!focused) {
                sellTextField.setVisible(false);
            }
        });
        sellLabel.setOnMouseClicked(e -> {
            sellTextField.setVisible(true);
            Platform.runLater(() -> sellTextField.requestFocus());
        });

        buyTextField.focusedProperty().addListener((obs, old, focused) -> {
            if (!focused) {
                buyTextField.setVisible(false);
            }
        });

        buyTextField.setOnAction(event -> {
            double quantity = Double.parseDouble(buyTextField.getText());
            System.out.println("Quantity : " + quantity);
            root.requestFocus();
        });
        buyLabel.setOnMouseClicked(e -> {
            buyTextField.setVisible(true);
            buyTextField.setText("26.0");
            buyTextField.requestFocus();
            buyTextField.positionCaret(0);
            buyTextField.selectAll();
        });

        closeButton.setOnAction((e) -> {
            layout.removeRow(this);
        });

        workupTimerPane.setOnMouseClicked(e -> {
            secondRow.setVisible(!secondRow.isVisible());
            secondRow.setManaged(secondRow.isVisible());
            this.layout.readjustScrollHeight();
        });
    }

    public void update(ObservableReplyRow row, TradesWorkupLayout layout) {
        this.row = row;
        this.layout = layout;
        secCodeLabel.setText(row.getTitle());
        this.root.setUserData(this);
        workupPhaseLabel.setText(row.getPhase());
        if (row.getPhase().equals("PRI")) {
            workupPhasePane.getStyleClass().add("xfe-trade-workup-private-phase");
            workupTimerPane.getStyleClass().add("xfe-trade-workup-private-phase");
        }
        EventHandler<ActionEvent> evt = e -> {
        };
        PresetSizeButtonsPane buyButtons = new PresetSizeButtonsPane(3, 50, 68, evt, true);
        buyButtons.updateButtonSizes(100, 50);
        buyButtonsPane.getChildren().add(buyButtons);

        PresetSizeButtonsPane sellButtons = new PresetSizeButtonsPane(3, 5, 1, evt, false);
        sellButtonsPane.getChildren().add(sellButtons);
       // firstRow.pseudoClassStateChanged(PseudoClass.getPseudoClass("flash"),true);
    }

    public VBox getRoot() {
        return root;
    }

    @FXML
    private VBox root;

    @FXML
    private HBox firstRow;

    @FXML
    private HBox secondRow;

    @FXML
    private Button closeButton;

    @FXML
    private Label secCodeLabel;

    @FXML
    private StackPane workupPhasePane;

    @FXML
    private Label workupPhaseLabel;

    @FXML
    private StackPane workupTimerPane;

    @FXML
    private Label workupTimerLabel;

    @FXML
    private Label sellLabel;

    @FXML
    private TextField sellTextField;

    @FXML
    private Label buyLabel;

    @FXML
    private TextField buyTextField;

    @FXML
    private StackPane buyButtonsPane;

    @FXML
    private StackPane sellButtonsPane;

    private ObservableReplyRow row;

    private TradesWorkupLayout layout;

    public double getRowHeight() {
        return secondRow.isVisible() ? 2 * WORKUP_ROW_HEIGHT : WORKUP_ROW_HEIGHT;
    }
}
