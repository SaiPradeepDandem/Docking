package xfe.icap.modules.settings;

import com.nomx.persist.PersistantName;
import com.sun.istack.internal.NotNull;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ObservableValue;
import org.controlsfx.control.PropertySheet;

import java.util.Optional;

public class SettingsPropertyItem implements PropertySheet.Item {

    private String category;
    private PersistantName persistantName;
    private String description;

    public SettingsPropertyItem(@NotNull String category, PersistantName persistantName, String description) {
        this.category = category;
        this.persistantName = persistantName;
        this.description = description;
    }

    @Override
    public Class<?> getType() {
        return null;
    }

    @Override
    public String getCategory() {
        return category;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public Object getValue() {
        return null;
    }

    @Override
    public void setValue(Object o) {

    }

    @Override
    public Optional<ObservableValue<? extends Object>> getObservableValue() {
        return Optional.empty();
    }
}
