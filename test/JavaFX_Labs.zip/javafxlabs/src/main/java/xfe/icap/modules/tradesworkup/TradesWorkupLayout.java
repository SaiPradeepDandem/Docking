package xfe.icap.modules.tradesworkup;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import xfe.ui.popup.PopUpStage;
import xfe.util.EasyFXML;
import xstr.session.ObservableReplyRow;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Layout class for showing the multiple Trade Workups in a single panel.
 */
public class TradesWorkupLayout {

    public static int WORKUP_ROWS_COUNT = 8;

    public static TradesWorkupLayout load() {
        FXMLLoader ldr = new FXMLLoader(TradesWorkupLayout.class.getResource("TradesWorkupLayout.fxml"));
        try {
            ldr.load();
            return ldr.getController();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void initialize() {
        Platform.runLater(() -> {
            ((PopUpStage) root.getScene().getWindow()).setStageAsNonResizable();
        });

        workupRowsScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        workupRowsLayoutPane.getChildren().addListener(new ListChangeListener<Node>() {
            @Override
            public void onChanged(Change<? extends Node> c) {
                readjustScrollHeight();
            }
        });

        Bindings.bindContent(workupRowsLayoutPane.getChildren(), workupRows);
        AtomicInteger inc;
        for (inc = new AtomicInteger(1); inc.get() < 4; inc.getAndIncrement()) {
            TradeWorkupRow workupRow = EasyFXML.load(TradeWorkupRow.class);
            workupRow.update(new ObservableReplyRow("Sec Code " + inc.get(), (inc.get() % 2 == 0) ? "PUB" : "PRI"), this);
            workupRows.add(workupRow.getRoot());
        }
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    TradeWorkupRow workupRow = EasyFXML.load(TradeWorkupRow.class);
                    workupRow.update(new ObservableReplyRow("Sec Code " + inc.get(), (inc.get() % 2 == 0) ? "PUB" : "PRI"), TradesWorkupLayout.this);
                    workupRows.add(workupRow.getRoot());
                    if (inc.getAndIncrement() == 5) {
                        timer.cancel();
                    }
                });
            }
        }, 5000, 5000);
    }

    public void readjustScrollHeight() {
        int count = workupRows.size();
        if (count > WORKUP_ROWS_COUNT) {
            count = WORKUP_ROWS_COUNT;
        }
        double totalHeight = 2;
        for (int i = 0; i < count; i++) {
           TradeWorkupRow tradeWorkupRow = (TradeWorkupRow) workupRows.get(i).getUserData();
            totalHeight += tradeWorkupRow.getRowHeight();
        }
        workupRowsScrollPane.setPrefHeight(totalHeight);
        workupRowsScrollPane.setMinHeight(totalHeight);
        resetStage();
    }

    private void resetStage() {
        if (root.getScene() != null && root.getScene().getWindow()!=null) {
            root.getScene().getWindow().sizeToScene();
        }
        workupRowsScrollPane.setVvalue(1.0);
    }

    public void removeRow(TradeWorkupRow row) {
        workupRows.remove(row.getRoot());
    }

    public VBox getRoot() {
        return root;
    }

    public ObservableList<Node> getWorkupRows() {
        return workupRows;
    }

    int x = 0;
    int y = 0;

    public void buzzStage() {
        Stage primaryStage = (Stage) root.getScene().getWindow();
        final Timeline timeLineX = new Timeline(new KeyFrame(Duration.seconds(0.08), t -> {
            if (x == 0) {
                primaryStage.setX(primaryStage.getX() + 10);
                x = 1;
            } else {
                primaryStage.setX(primaryStage.getX() - 10);
                x = 0;
            }
        }));
        timeLineX.setCycleCount(4);
        timeLineX.setAutoReverse(false);
        timeLineX.play();

        final Timeline timeLineY = new Timeline(new KeyFrame(Duration.seconds(0.08), t -> {
            if (y == 0) {
                primaryStage.setY(primaryStage.getY() + 10);
                y = 1;
            } else {
                primaryStage.setY(primaryStage.getY() - 10);
                y = 0;
            }
        }));
        timeLineY.setCycleCount(4);
        timeLineY.setAutoReverse(false);
        timeLineY.play();
    }

    @FXML
    private VBox root;

    @FXML
    private ScrollPane workupRowsScrollPane;

    @FXML
    private VBox workupRowsLayoutPane;

    private ObservableList<Node> workupRows = FXCollections.observableArrayList();

}
