package xfe;

import javafx.scene.image.Image;

import java.util.Arrays;
import java.util.List;

public class XfeAppModule{
    public static List<Image> getIcons() {
        return Arrays.asList(new Image[] {
                new Image("/css/ICAP_Lozenges_16pix.png"),
                new Image("/css/ICAP_Lozenges_32pix.png"),
                // new Image(getClass().getResource("iswap_white_48x48.png").toExternalForm())
        });
    }
}