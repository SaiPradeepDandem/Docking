package xfe.ui.popover;

public interface PopOverManager {
   void register(XfePopOver popOver);

   void unregister(XfePopOver popOver);
}
