package xfe.ui.popup;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import xfe.XfeAppModule;

import java.util.List;

/**
 * Popup stage to show the corresponding views in pop up.
 */
public class PopUpStage extends Stage {

    public PopUpStage(Stage owner, PopUpManager popUpManager, Node node, String title) {
        this.setTitle(title);
        this.content.setValue(node);
        //this.initOwner(owner);

        List<Image> icons = XfeAppModule.getIcons();
        if (icons != null && !icons.isEmpty()) {
            this.getIcons().setAll(icons);
        }

        final StackPane stageRoot = new StackPane();
        stageRoot.getChildren().add(node);
        final Scene stageScene = new Scene(stageRoot);
        this.setScene(stageScene);

        // Registering the events while showing and hiding the stage.
        this.setOnHiding(event -> {
            popUpManager.unregister(node.getId(), PopUpStage.this);
        });
        this.setOnShowing(event -> {
            popUpManager.register(node.getId(), PopUpStage.this);
            PopUpStage.this.toFront();
        });

        // Binding the bound values
        this.stageWidth.bind(this.widthProperty());
        this.stageHeight.bind(this.heightProperty());
        this.xPosition.bind(this.xProperty());
        this.yPosition.bind(this.yProperty());
    }

    /**
     * Shows the stage. If the stage is already rendered then restores the previous bounds for the stage.
     */
    public void showStage() {
        if (this.stageWidth.get() > 0) {
            setWidth(this.stageWidth.get());
            setHeight(this.stageHeight.get());
            setX(this.xPosition.get());
            setY(this.yPosition.get());
        }
        show();
    }

    /**
     * Sets the stage as non resizable. The extra sizeToScene() method call is a hack to fix the padding issue
     * to the root element when resizable is set to false.
     */
    public void setStageAsNonResizable() {
        setResizable(false);
        sizeToScene();
    }

    private final DoubleProperty stageWidth = new SimpleDoubleProperty();
    private final DoubleProperty stageHeight = new SimpleDoubleProperty();
    private final DoubleProperty xPosition = new SimpleDoubleProperty();
    private final DoubleProperty yPosition = new SimpleDoubleProperty();
    private final ObjectProperty<Node> content = new SimpleObjectProperty<>();
}
