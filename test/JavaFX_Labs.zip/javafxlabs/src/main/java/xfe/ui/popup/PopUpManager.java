package xfe.ui.popup;

/**
 * Interface to manage the popup dialogs.
 */
public interface PopUpManager {
   void register(String id, PopUpStage window);

   void unregister(String id, PopUpStage window);
}
