package xfe.ui.table;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Skin;
import javafx.scene.control.TableView;

/**
 * Custom table view control which enables to show the settings pop up on click of the settings button.
 * The settings button is visible on mouse hover of TableView header area.
 *
 * @param <S> The type of the objects contained within the TableView items list.
 */
public class ConfigurableTableView<S> extends TableView<S> {

    /**
     * Creates a default ConfigurableTableView control.
     *
     * <p>Refer to the {@link TableView} class documentation for details on the
     * default state of other properties.
     */
    public ConfigurableTableView() {
        super();
    }

    /**
     * Creates a ConfigurableTableView with the settingsContent provided in the items ObservableList.
     * This also sets up an observer such that any changes to the items list
     * will be immediately reflected in the ConfigurableTableView itself.
     *
     * <p>Refer to the {@link TableView} class documentation for details on the
     * default state of other properties.
     *
     * @param items The items to insert into the ConfigurableTableView, and the list to watch
     *              for changes (to automatically show in the ConfigurableTableView).
     */
    public ConfigurableTableView(ObservableList<S> items) {
        super(items);
    }

    private ObjectProperty<Node> settingsContent;

    /**
     * <p>The settingsContent to show for the TableView. The settingsContent
     * can be any Node such as UI controls or groups of nodes added
     * to a PopOver.</p>
     */
    public final void setSettingsContent(Node value) {
        settingsContentProperty().set(value);
    }

    /**
     * <p>The settingsContent associated with the TableView.</p>
     *
     * @return The settingsContent associated with the TableView.
     */
    public final Node getSettingsContent() {
        return settingsContent == null ? null : settingsContent.get();
    }

    /**
     * <p>The settingsContent associated with the TableView.</p>
     */
    public final ObjectProperty<Node> settingsContentProperty() {
        if (settingsContent == null) {
            settingsContent = new SimpleObjectProperty<Node>(this, "settingsContent");
        }
        return settingsContent;
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new ConfigurableTableViewSkin<S>(this);
    }
}
