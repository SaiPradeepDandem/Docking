package xfe.ui.table;

import com.sun.javafx.scene.control.skin.TableHeaderRow;
import com.sun.javafx.scene.control.skin.TableViewSkin;
import javafx.animation.KeyFrame;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import org.controlsfx.control.PopOver;


/**
 * Skin implementation for ConfigurableTableView.
 *
 * @param <T> The type of the objects contained within the TableView items list.
 */
public class ConfigurableTableViewSkin<T> extends TableViewSkin<T> {
    private ConfigurableTableView<T> configurableTableView;

    private BooleanProperty settingsContentPresent = new SimpleBooleanProperty();

    private BooleanProperty showButton = new SimpleBooleanProperty();

    private Button settingButton;

    private VBox defaultColumnsFiltering;

    private PopOver popOver;

    private Timeline visibleTimer = new Timeline();

    private static final double TWEAK_FACTOR =20;

    private EventHandler<MouseEvent> ENTER_HANDLER = (e) -> {
        if (isMenuButtonVisible()) {
            if (visibleTimer.getStatus() == Timeline.Status.RUNNING) {
                visibleTimer.stop();
            }
            showButton.set(true);
        }
    };

    private EventHandler<MouseEvent> EXIT_HANDLER = (e) -> {
        if (isMenuButtonVisible()) {
            if (visibleTimer.getStatus() == Timeline.Status.RUNNING) {
                visibleTimer.stop();
            }
            if (!getPopOver().isShowing()) {
                visibleTimer.playFromStart();
            }
        }
    };

    public ConfigurableTableViewSkin(final ConfigurableTableView<T> tableView) {
        super(tableView);
        this.configurableTableView = tableView;
        initialize();
    }


    private void initialize() {
        this.configurableTableView.getStyleClass().add("configurable-table-view");
        visibleTimer.getKeyFrames().add(new KeyFrame(new Duration(500)));
        visibleTimer.setOnFinished(event -> showButton.set(false));

        final Button settingsButton = getSettingButton();
        showButton.addListener((obs, oldVal, show) -> {
            if (show) {
                if (!getChildren().contains(settingsButton)) {
                    getChildren().add(settingsButton);
                }
                layoutSettingButton();
            } else {
                getChildren().remove(settingsButton);
            }
        });

        settingsContentPresent.set(configurableTableView.getSettingsContent() != null);
        configurableTableView.settingsContentProperty().addListener((obs, oldVal, settingsContent) -> {
            settingsContentPresent.set(settingsContent != null);
            if (isMenuButtonVisible()) {
                if (settingsContent != null) {
                    getPopOver().setContentNode(settingsContent);
                } else {
                    getPopOver().setContentNode(getDefaultColumnsFiltering());
                }
            }
        });


        final TableHeaderRow headerRow = getTableHeaderRow();
        headerRow.setOnMouseMoved(ENTER_HANDLER);
        headerRow.setOnMouseEntered(ENTER_HANDLER);
        headerRow.setOnMouseExited(EXIT_HANDLER);
        settingsButton.setOnMouseEntered(ENTER_HANDLER);
        settingsButton.setOnMouseExited(EXIT_HANDLER);
    }

    private void layoutSettingButton() {
        final double btnSize = 30;
        final double tableHeight = configurableTableView.getHeight();
        final double tableWidth = configurableTableView.getWidth()-TWEAK_FACTOR;
        final double baselineOffset = tableHeight / 2;
        layoutInArea(getSettingButton(), (tableWidth - btnSize - 5), 0, btnSize, btnSize, baselineOffset, HPos.CENTER, VPos.CENTER);
    }

    private Button getSettingButton() {
        if (settingButton == null) {
            settingButton = new Button();
            settingButton.getStyleClass().add("setting-button");
            settingButton.setPrefSize(30, 30);
            settingButton.setTranslateX(TWEAK_FACTOR);
            settingButton.setOnAction(e -> {
                if (isMenuButtonVisible()) {
                    getPopOver().show(settingButton);
                }
            });
        }
        return settingButton;
    }

    private PopOver getPopOver() {
        if (popOver == null) {
            popOver = new PopOver();
            //popOver.setDetachable(false);
            final Node content;
            if (isSettingsContentPresent()) {
                content = configurableTableView.getSettingsContent();
            } else {
                content = getDefaultColumnsFiltering();
            }
            popOver.setContentNode(content);
            popOver.setArrowSize(10);
            popOver.setArrowLocation(PopOver.ArrowLocation.RIGHT_TOP);
            popOver.showingProperty().addListener((obs, oldVal, showing) -> {
                if (!showing) {
                    EXIT_HANDLER.handle(null);
                }
            });
        }
        return popOver;
    }

    private VBox getDefaultColumnsFiltering() {
        if (defaultColumnsFiltering == null) {
            defaultColumnsFiltering = new VBox();
            defaultColumnsFiltering.setPadding(new Insets(15));
            defaultColumnsFiltering.setSpacing(10);
            configurableTableView.getColumns().forEach(column -> {
                CheckBox cb = new CheckBox(column.getText());
                cb.selectedProperty().bindBidirectional(column.visibleProperty());
                defaultColumnsFiltering.getChildren().add(cb);
            });
        }
        return defaultColumnsFiltering;
    }

    public boolean isSettingsContentPresent() {
        return settingsContentPresent.get();
    }

    public boolean isMenuButtonVisible() {
        return configurableTableView.isTableMenuButtonVisible();
    }
}
