package xfe.ui.popover;

import org.controlsfx.control.PopOver;

/**
 * Xfe customized PopOver to register and unregister the PopOver.
 */
public class XfePopOver extends PopOver {

   public XfePopOver(PopOverManager popOverManager) {
      super();
      detachedProperty().addListener((obs, oldVal, detached) -> {
         if (detached) {
            popOverManager.register(this);
         }
      });
      setOnHiding(e -> {
         if (isDetached()) {
            popOverManager.unregister(this);
         }
      });
   }
}
