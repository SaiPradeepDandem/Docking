package xfe.ui.popup;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class HalfTransparentWindow_Demo extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        StackPane root = new StackPane();
        root.setAlignment(Pos.TOP_LEFT);

        primaryStage.initStyle(StageStyle.TRANSPARENT);
        Scene scene = new Scene(root, 300,300, Color.TRANSPARENT);

        StackPane box = new StackPane();
        box.setStyle("-fx-background-color:#0E273D;-fx-border-color: yellow;-fx-border-width: 2px;");
        box.setMaxHeight(150);
        root.getChildren().add(box);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
