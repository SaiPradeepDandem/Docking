package xfe.ui.control;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;

/**
 * Custom Button control for explicitly showing SVG based icon only without text and custom background.
 */
public class SvgButton extends Button {
    private final StackPane svg = new StackPane();

    /**
     * Default constructor used to create control from FXML files.
     */
    public SvgButton() {
        this(null);
    }

    public SvgButton(String... buttonStyles) {
        super();
        apply(this, buttonStyles);
        setGraphic(svg);
        svgStyleClassProperty().addListener((obs, oldVal, newVal) -> {
            if (oldVal != null && !oldVal.isEmpty()) {
                svg.getStyleClass().removeAll(oldVal);
            }
            if (newVal != null && !newVal.isEmpty()) {
                svg.getStyleClass().addAll(newVal);
            }
        });
    }

    public static void apply(Button b, String... buttonStyles) {
        b.getStyleClass().add("xfe-svg-button");
        if (buttonStyles != null) {
            b.getStyleClass().addAll(buttonStyles);
        }
    }

    public final StringProperty svgStyleClassProperty() {
        if (svgStyleClass == null) {
            svgStyleClass = new SimpleStringProperty(this, "svgStyleClass", "");
        }
        return svgStyleClass;
    }

    /**
     * The svg style class to set on button.
     */
    private StringProperty svgStyleClass;

    public final void setSvgStyleClass(String value) {
        svgStyleClassProperty().setValue(value);
    }

    public final String getSvgStyleClass() {
        return svgStyleClass == null ? "" : svgStyleClass.getValue();
    }
}
