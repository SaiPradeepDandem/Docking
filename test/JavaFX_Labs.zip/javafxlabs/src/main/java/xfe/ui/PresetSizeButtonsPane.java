package xfe.ui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class PresetSizeButtonsPane extends FlowPane {//TilePane{

   public PresetSizeButtonsPane(int numberOfButtons,
                                double minimumSize,
                                double balance,
                                EventHandler<ActionEvent> eventHandler,
                                boolean reverseOrder) {
      super(Orientation.HORIZONTAL);
      this.reverseOrder = reverseOrder;
      minSize = minimumSize;
      int startIdx = 1;
      if (numberOfButtons <= 9) // cannot have more than 9 buttons
         buttonCount = numberOfButtons;

      if (reverseOrder) {
         for (int i = buttonCount - 1; i >= 0; i--) {
            double size = (i + startIdx) * minSize;
            final String sizeStr = sizeFormatter.format(size);
            Button button = new Button(sizeStr);
            button.setId(sizeStr);
            button.setOnAction(eventHandler);
            getChildren().add(button);
            buttons.add(button);
         }
      } else {
         for (int i = 0; i < buttonCount; i++) {
            double size = (i + startIdx) * minSize;
            final String sizeStr = sizeFormatter.format(size);
            Button button = new Button(sizeStr);
            button.setId(sizeStr);
            button.setOnAction(eventHandler);
            getChildren().add(button);
            buttons.add(button);
         }
      }

      // set button width and bind
      final Button firstButton = buttons.get(0);
      firstButton.setPrefWidth(buttonPrefWidth);

      for (int i = 1; i < buttons.size(); i++) {
         final Button aButton = buttons.get(i);
         aButton.prefWidthProperty().bind(firstButton.prefWidthProperty());
      }
   }

   public void updateButtonSizes(double balance, double minimumSize) {
      minSize = minimumSize;

      int startIdx = 1;

      if (balance == 0.0) {
         startIdx = 1;
      } else {
         // work out the start idx
         if (balance == minSize) {
            startIdx = 2;
         } else {
            if (balance >= minSize) {
               startIdx = (int) (balance / minSize);
              // double r = balance % minSize;
              // System.out.println(r);
            }
            startIdx = startIdx+1;
            //if (startIdx < 1) {
            //   startIdx = 1;
            //}
         }
      }

      if (reverseOrder) {
         for (int i = 0; i < buttonCount; i++) {
            double size = (buttonCount - i + startIdx - 1) * minSize;
            final String sizeStr = sizeFormatter.format(size);
            Button button = buttons.get(i);
            button.setId(sizeStr);
            button.setText(sizeStr);
         }
      } else {
         for (int i = 0; i < buttonCount; i++) {
            double size = (i + startIdx) * minSize;
            final String sizeStr = sizeFormatter.format(size);
            Button button = buttons.get(i);
            button.setId(sizeStr);
            button.setText(sizeStr);
         }
      }
   }
   private final DecimalFormat sizeFormatter = new DecimalFormat("##0.######");
   private int buttonCount = 9;
   private final List<Button> buttons = new ArrayList<Button>();
   private double minSize;
   final private boolean reverseOrder;
   private static final double buttonPrefWidth = 45;
}
