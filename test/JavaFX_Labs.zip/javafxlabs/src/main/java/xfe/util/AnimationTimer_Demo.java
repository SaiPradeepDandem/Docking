package xfe.util;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class AnimationTimer_Demo extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    private long var = 0;
    @Override
    public void start(Stage primaryStage) {
        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                System.out.println(now/1000000);
            }
        };
        Button button = new Button("Press to make JavaFX thread sleep for 5 seconds");
        button.setDisable(true);
        button.setOnAction(e->{
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        });

        Button timerButton = new Button("Start Animation Timer");

        HBox row1 = new HBox(timerButton, button);
        row1.setAlignment(Pos.CENTER);
        row1.setSpacing(20);

        ComboBox<Integer> timesCombo = new ComboBox<>();
        List<Integer> list = IntStream.range(1,1001).boxed().collect(Collectors.toList());
        timesCombo.setValue(1000);
        timesCombo.getItems().addAll(list);

        Button run = new Button("Run");
        run.setOnAction(e->{
            var = 0;
            int count = timesCombo.getValue();
            for (int i = 0; i < count; i++) {
                long pl = var++;
                Platform.runLater(()-> System.out.println(pl+" Platform.runLater :: "+System.currentTimeMillis()));

                long ae = var++;
                AfterLayout.execute(()-> System.out.println(ae+" AfterLayout.execute :: "+System.currentTimeMillis()));
            }
        });

        HBox row2 = new HBox(timesCombo, run);
        row2.setAlignment(Pos.CENTER);
        row2.setSpacing(20);

        row2.disabledProperty().addListener((obs,old,v)->{
            if(v){
                System.out.println("");
            }
        });
        timerButton.setOnAction(e->{
            if(timerButton.getText().startsWith("Start")){
                timer.start();
                button.setDisable(false);
                timerButton.setText("Stop Animation Timer");
                row2.setDisable(true);
            }else{
                timer.stop();
                button.setDisable(true);
                timerButton.setText("Start Animation Timer");
                row2.setDisable(false);
            }
        });

        VBox vb = new VBox(row1,row2);
        vb.setSpacing(20);
        vb.setAlignment(Pos.CENTER);
        StackPane root = new StackPane(vb);
        Scene scene = new Scene(root, 700,300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

class AfterLayout{
    public static void execute(Runnable runnable){
        new AnimationTimer(){
            int count = 0;
            @Override
            public void handle(long now) {
                if(count>1){
                    runnable.run();
                    stop();
                }
                count++;
            }
        }.start();
    }
}
