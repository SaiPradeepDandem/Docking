package xfe.util;

import javafx.fxml.FXMLLoader;
import javafx.fxml.LoadException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import xstr.util.exception.Exceptions;

import java.io.IOException;

public class EasyFXML {
   private static final Logger logger = LoggerFactory.getLogger(EasyFXML.class);

   /**
    * A Simplified FXML loader class that can be used if specific conventions are followed.
    * This loader will work when all the following conditions are met:
    *   * The fxml file name is exactly the same as the simpleName of its controller class
    *   * The fxml file is located in the same package as its controller class
    *   * The controller class must have the means to access the root node from the FXML file
    *     or else it will not be possible to use the loaded FXML node.
    * @param cls The controller class for the FXML file to load
    * @param <T> The type of the controller class
    * @return A new instance of the controller class
    */
   public static <T> T load(Class<T> cls) {
      String fileName = cls.getSimpleName() + ".fxml";
      FXMLLoader ldr = new FXMLLoader(cls.getResource(fileName));
      try {
         ldr.load();
         return ldr.getController();
      } catch (LoadException le) {
         //logger.error("Error loading {}: {}", fileName, Exceptions.format(le.getCause()));
         logger.debug("Error:", le.getCause());
      } catch (IOException e) {
         //logger.error("Error loading {}: {}", fileName, Exceptions.format(e));
         logger.debug("Error:", e);
      }
      return null;
   }
}
