package com.nomx.javafxlabs;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

public class Instrument {
    private StringProperty instrument = new SimpleStringProperty();
    private StringProperty type = new SimpleStringProperty();
    private StringProperty total = new SimpleStringProperty();
    private StringProperty bid = new SimpleStringProperty();
    private StringProperty offer = new SimpleStringProperty();
    private StringProperty amount = new SimpleStringProperty();
    private StringProperty price = new SimpleStringProperty();


    public Instrument(String instrument, String type, String total, String bid, String offer, String amount, String price) {
        this.instrument.set(instrument);
        this.type.set(type);
        this.total.set(total);
        this.bid.set(bid);
        this.offer.set(offer);
        this.amount.set(amount);
        this.price.set(price);
    }

    public static List<Instrument> getSampleData(){
        List<Instrument> list = new ArrayList<>();
        for(int i=1;i<25;i++){
            list.add(new Instrument("A-EUR "+i+"Y-"+(i+1)+"Y.sp",(i%2==0?"Bid":"Offer"),"52.36","47","58","523.00","47"));
        }
        return list;
    }

    public String getInstrument() {
        return instrument.get();
    }

    public StringProperty instrumentProperty() {
        return instrument;
    }

    public String getType() {
        return type.get();
    }

    public StringProperty typeProperty() {
        return type;
    }

    public String getTotal() {
        return total.get();
    }

    public StringProperty totalProperty() {
        return total;
    }

    public String getBid() {
        return bid.get();
    }

    public StringProperty bidProperty() {
        return bid;
    }

    public String getOffer() {
        return offer.get();
    }

    public StringProperty offerProperty() {
        return offer;
    }

    public String getAmount() {
        return amount.get();
    }

    public StringProperty amountProperty() {
        return amount;
    }

    public String getPrice() {
        return price.get();
    }

    public StringProperty priceProperty() {
        return price;
    }
}
