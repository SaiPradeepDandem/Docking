package com.nomx.javafxlabs;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.stage.Stage;

public class PopupDelay_Demo extends Application {
    int x = 0;
    @Override
    public void start(Stage stage) throws Exception {
        Button button = new Button("Show");
        button.setOnAction(e->show(button));
        VBox root = new VBox(button);
        root.setPadding(new Insets(10));
        Scene sc = new Scene(root, 300, 300);
        stage.setScene(sc);
        stage.show();
    }

    private void show(Node node) {
        System.out.println("\n----------------------------------------------------------------------------");
        long t = System.currentTimeMillis();
        x = x+25;
        StackPane sp = new StackPane(buildTable());
        sp.setStyle("-fx-background-color:grey;-fx-border-width: 2px;-fx-border-color: black;");
        sp.setPrefSize(200,200);
        sp.needsLayoutProperty().addListener((obs,old,needsLayout)->{
            System.out.println(needsLayout+"  : Time taken :: "+(System.currentTimeMillis()-t)+"ms");
        });
        Popup pop = new Popup();
        pop.getContent().add(sp);
        pop.show(node, x,0);
    }

    private TableView<String[]> buildTable(){
        TableView<String[]> tableView = new TableView<>();
        TableColumn<String[], String> col1 = new TableColumn<>("Col 1");
        col1.setCellValueFactory(param -> new SimpleStringProperty(param.getValue()[0]));
        TableColumn<String[], String> col2 = new TableColumn<>("Col 2");
        col2.setCellValueFactory(param -> new SimpleStringProperty(param.getValue()[1]));
        tableView.getColumns().addAll(col1,col2);

        ObservableList<String[]> items = FXCollections.observableArrayList();
        for (int i = 0; i < 100; i++) {
            String[] arr = {"col 1 "+i,"col 2 "+i };
            items.addAll(arr);
        }
        tableView.getItems().addAll(items);
        return tableView;
    }
}
