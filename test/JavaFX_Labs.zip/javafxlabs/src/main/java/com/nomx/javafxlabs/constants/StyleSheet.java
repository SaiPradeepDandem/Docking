package com.nomx.javafxlabs.constants;

public enum StyleSheet {
    TEST ("/css/test.css"),
    CORE_BASE ("/css/base.css"),
    BASE ("/css/gilts_base.css"),
    BLUE ("/css/themes/gilts_blue.css"),
    DARK ("/css/themes/gilts_classic.css"),
    WINDOW ("/css/xfewindow.css");

    private StyleSheet(String path){
        this.path = path;
    }

    public String getPath(){
        return this.path;
    }
    private String path;
}
