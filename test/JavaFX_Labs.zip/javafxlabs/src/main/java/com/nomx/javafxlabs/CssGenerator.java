package com.nomx.javafxlabs;

public class CssGenerator {

    public static void main(String... a) {
        int fontSize = 6;
        int cellSize = 10;
        for (int zoom = -4; zoom < 11; zoom++) {
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell {");
            //System.out.println("    -fx-font-size: " + fontSize + "pt;");
            System.out.println("    -fx-cell-size: " + (zoom < 0 ? (cellSize + 1) : cellSize) + "px;");
            System.out.println("}");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell > .text,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell > .label,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell .wrapper > .label,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell > .text-field,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell > .text,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell > .label,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell .wrapper > .label,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell > .text-field{");
            System.out.println("    -fx-font-size: " + fontSize + "pt;");
            System.out.println("}");


            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell .xfe-cell-button,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view > .virtual-flow > .clipped-container > .sheet > .table-row-cell > .table-cell .xfe-cell-button {");
            System.out.println("    -xfe-icon-size: " + (zoom < 0 ? (cellSize - 3) : (cellSize - 2)) + "px; /* "+(zoom < 0 ? "cellSize - 3" : "cellSize - 2")+" */");
            System.out.println("}");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .table-view .action-column,");
            System.out.println(".instruments-tab-pane-zoom" + zoom + " > .tab-content-area > .table-view .action-column{");
            System.out.println("    -fx-pref-width:" + (cellSize + 2) + "px; /* cellSize + 2 */");
            System.out.println("}");
            System.out.println("");
            fontSize++;
            cellSize = cellSize + 2;
        }

    }
}
