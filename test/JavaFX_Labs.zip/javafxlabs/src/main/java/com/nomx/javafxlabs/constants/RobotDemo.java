package com.nomx.javafxlabs.constants;

import java.awt.*;
import java.awt.event.InputEvent;
import java.util.Date;

public class RobotDemo {
    public static void main(String... a) throws AWTException {
        long minute = 60000;
        long noOfMinutes = 300;//600;
        Robot r = new Robot();
        long time = System.currentTimeMillis();
        long endTime = time+ (noOfMinutes * minute);
        while(System.currentTimeMillis()<endTime) {
           Point point =  MouseInfo.getPointerInfo().getLocation();
            r.mouseMove(point.x-1,point.y-1);
            r.delay(500);
            r.mouseMove(point.x,point.y);
            r.delay(60000);
        }
        r.mouseMove(50,250);
        //r.mouseMove(-1900,200);
        //r.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        //r.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        System.out.println("Stopped at "+new Date());
    }
}

