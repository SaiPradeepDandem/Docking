package com.nomx.javafxlabs;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.ScrollEvent;
import org.scenicview.ScenicView;
import xfe.ui.table.ConfigurableTableView;

import java.util.List;
import java.util.stream.Collectors;

public class SettableTableViewController {
    @FXML
    private Button scenicViewButton;

    @FXML
    private ConfigurableTableView<Instrument> tableView;

    @FXML
    private TableColumn<Instrument, String> instrumentColumn;

    @FXML
    private TableColumn<Instrument, String> typeColumn;

    @FXML
    private TableColumn<Instrument, String> totalColumn;

    @FXML
    private TableColumn<Instrument, String> bidColumn;

    @FXML
    private TableColumn<Instrument, String> offerColumn;

    @FXML
    private TableColumn<Instrument, String> amountColumn;

    @FXML
    private TableColumn<Instrument, String> priceColumn;

    @FXML
    private CheckBox instrumentCB;

    @FXML
    private CheckBox typeCB;

    @FXML
    private CheckBox totalCB;

    @FXML
    private CheckBox bidCB;

    @FXML
    private CheckBox offerCB;

    @FXML
    private CheckBox amountCB;

    @FXML
    private CheckBox priceCB;

    @FXML
    public void initialize() {
        scenicViewButton.setOnAction(e -> ScenicView.show(scenicViewButton.getScene()));

        instrumentCB.selectedProperty().bindBidirectional(instrumentColumn.visibleProperty());
        typeCB.selectedProperty().bindBidirectional(typeColumn.visibleProperty());
        totalCB.selectedProperty().bindBidirectional(totalColumn.visibleProperty());
        bidCB.selectedProperty().bindBidirectional(bidColumn.visibleProperty());
        offerCB.selectedProperty().bindBidirectional(offerColumn.visibleProperty());
        amountCB.selectedProperty().bindBidirectional(amountColumn.visibleProperty());
        priceCB.selectedProperty().bindBidirectional(priceColumn.visibleProperty());

        instrumentColumn.setCellValueFactory(cd -> cd.getValue().instrumentProperty());
        instrumentColumn.getStyleClass().add("bold-font");

        typeColumn.setCellValueFactory(cd -> cd.getValue().typeProperty());
        typeColumn.setCellFactory(tableView -> {
            return new TableCell<Instrument, String>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item != null) {
                        Button b = new Button(item);
                        b.setPrefWidth(50);
                        b.getStyleClass().add("table-view-button");
                        b.getStyleClass().add(item.equals("Bid") ? "table-view-bid-button" : "table-view-offer-button");

                        Label l = new Label(item);
                        l.getStyleClass().addAll(item.equals("Bid") ? "referred" : "opened", "bold-font");
                        setGraphic(b);
                    }
                }
            };
        });

        totalColumn.setCellValueFactory(cd -> cd.getValue().totalProperty());
        totalColumn.getStyleClass().add("bold-font");
        bidColumn.setCellValueFactory(cd -> cd.getValue().bidProperty());
        offerColumn.setCellValueFactory(cd -> cd.getValue().offerProperty());
        amountColumn.setCellValueFactory(cd -> cd.getValue().amountProperty());
        priceColumn.setCellValueFactory(cd -> cd.getValue().priceProperty());

        ObservableList<Instrument> instruments = FXCollections.observableArrayList(Instrument.getSampleData());
        tableView.setItems(instruments);

        IntegerProperty zoomLevel = new SimpleIntegerProperty();
        tableView.addEventFilter(ScrollEvent.SCROLL,(evt)->{
            if (evt.isControlDown()) {
                evt.consume();
                int factor = evt.getDeltaY() > 0 ? 1 : -1;
                int zoom = zoomLevel.get() + factor;
                if (zoom > -1 && zoom < 11) {
                    zoomLevel.set(zoom);
                    List<String> styles = tableView.getStyleClass().stream().filter(s -> s.startsWith("table-view-zoom")).collect(Collectors.toList());
                    tableView.getStyleClass().removeAll(styles);
                    tableView.getStyleClass().add("table-view-zoom"+zoom);
                }
            }
        });
        //tableView.getStyleClass().add("table-view-zoom4");
    }
}
