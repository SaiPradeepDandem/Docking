package com.nomx.javafxlabs;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.util.Duration;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class OwnerStage_Demo extends Application {
    @Override
    public void start(Stage stage) throws Exception {

        Stage dummyStage = new Stage();
        dummyStage.initStyle(StageStyle.TRANSPARENT);
        StackPane dummyRoot = new StackPane();
        dummyRoot.setStyle("-fx-background-color:transparent;");
        dummyStage.setScene(new Scene(dummyRoot,100,100, Color.TRANSPARENT));
        dummyStage.initOwner(null);

        stage.focusedProperty().addListener((obs,old,focused)->{
            if(focused){
               // dummyStage.setAlwaysOnTop(true);
            }
        });
        Button button = new Button("Open Window");
        button.setOnAction(e -> {
            button.setDisable(true);
            button.getParent().requestFocus();
            if(!dummyStage.isShowing()) {
               // dummyStage.show();
            }

            //stg.setAlwaysOnTop(true);
            // Window will close automatically after 10secs.
            Timeline timeline = new Timeline(new KeyFrame(Duration.millis(10000), x -> {
                Stage stg = new Stage();
                stg.setScene(new Scene(new StackPane(), 300, 300));
                try {
                   // stg.show();
//                    Field impl_peer_field = Window.class.getDeclaredField("impl_peer");
//                    impl_peer_field.setAccessible(true);
//                    Object impl_peer = impl_peer_field.get(stg);
//                    Method getPlatformWindow = impl_peer.getClass().getDeclaredMethod("getPlatformWindow");
//                    getPlatformWindow.setAccessible(true);
//                    com.sun.glass.ui.Window platformWindow = (com.sun.glass.ui.Window) getPlatformWindow.invoke(impl_peer);
//                    platformWindow.setFocusable(false);

                } catch (Exception e1) {
                    e1.printStackTrace();
                }


                StackPane sp = new StackPane();
                sp.setStyle("-fx-background-color:red;");
                sp.setPrefSize(200,200);
                Popup pop = new Popup();
                pop.getContent().add(sp);
                pop.show(stage);
            }));
            timeline.setCycleCount(1);
            timeline.play();
        });
        VBox root = new VBox(button, new Button("Test"));
        root.setStyle("-fx-background-color:yellow;");
        root.setOnMousePressed(e->root.setStyle("-fx-background-color:red;"));
        root.setOnMouseReleased(e->root.setStyle("-fx-background-color:yellow;"));
        root.setSpacing(10);
        Scene sc = new Scene(root, 600, 600);
        stage.setScene(sc);
        stage.show();
    }

    public static void main(String... a) {
        Application.launch(a);
    }
}
