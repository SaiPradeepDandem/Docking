package com.nomx.javafxlabs;

import com.nomx.javafxlabs.constants.StyleSheet;
import com.nomx.memorymonitor.MonitorWindow;
import com.sai.javafx.tickupdown.TickUpDownUtil;
import com.sun.javafx.css.StyleManager;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.*;
import javafx.util.Callback;
import lombok.Getter;
import javafx.stage.Stage;
import org.controlsfx.control.PopOver;
import org.scenicview.ScenicView;
import xfe.icap.modules.settingsview.SettingsLayout;
import xfe.icap.modules.tradesworkup.TradesWorkupLayout;
import xfe.ui.popup.PopUpManager;
import xfe.ui.popup.PopUpStage;
import xfe.ui.table.ConfigurableTableView;

import java.util.Date;

/**
 * Controller for RootLayout.fxml file.
 */
public class RootLayoutController implements PopUpManager {

    @FXML
    @Getter
    private BorderPane rootLayout;

    @FXML
    private Button scenicViewButton;

    @FXML
    private ChoiceBox<StyleSheet> styleChoiceBox;

    @FXML
    private SplitMenuButton menuBox;

    @FXML
    private SplitMenuButton showMeBox;

    @FXML
    private Button settingsButton;

    @FXML
    private Button closeButton;

    @FXML
    private TabPane instrumentsTab;

    @FXML
    private TabPane baseTab;

    @FXML
    private Tab firstTab;

    @FXML
    private Button secondButton;

    @FXML
    private Button popOverButton;

    @FXML
    private TableView<Instrument> tableView;

    @FXML
    private ConfigurableTableView<Instrument> b_tableView;

    @FXML
    private TableColumn<Instrument, String> instrumentColumn;
    @FXML
    private TableColumn<Instrument, String> typeColumn;
    @FXML
    private TableColumn<Instrument, String> totalColumn;
    @FXML
    private TableColumn<Instrument, String> bidColumn;
    @FXML
    private TableColumn<Instrument, String> offerColumn;
    @FXML
    private TableColumn<Instrument, String> amountColumn;
    @FXML
    private TableColumn<Instrument, String> priceColumn;

    @FXML
    private TableView<Instrument> tableView2;

    @FXML
    public void initialize() {

        //firstTab.setText("First tab\ndummy Tab");

        Text text1 = new Text("Spreads");
        text1.getStyleClass().add("tab-title");
        Text text2 = new Text("\nbmk");
        text2.getStyleClass().add("tab-sub-title");
        VBox vb = new VBox();
        vb.getChildren().addAll(text1, text2);
        TextFlow textFlow = new TextFlow(text1, text2);
        firstTab.setGraphic(textFlow);
        for (int i = 1; i < 10; i++) {
            addTab("Main Tab " + i, "Sub " + i, instrumentsTab);
            addTab("Main Tab " + i, null, baseTab);
        }

        ObservableList<String> list = FXCollections.unmodifiableObservableList(FXCollections.observableArrayList());
        FilteredList<String> fList = new FilteredList<>(list, a -> true);
        styleChoiceBox.getItems().addAll(StyleSheet.BLUE, StyleSheet.DARK);
        styleChoiceBox.getSelectionModel().selectedItemProperty().addListener((ob, oldVal, newVal) -> {
            if (oldVal != null && oldVal != StyleSheet.BASE) {
                StyleManager.getInstance().removeUserAgentStylesheet(oldVal.getPath());
            }
            if (newVal != StyleSheet.BASE) {
                StyleManager.getInstance().addUserAgentStylesheet(newVal.getPath());
            }
        });
        styleChoiceBox.getSelectionModel().select(StyleSheet.DARK);

        secondButton.setOnAction(
                new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        final Stage dialog = new Stage();
                        dialog.initOwner(MainApplication.stage);
                        VBox dialogVbox = new VBox(20);
                        dialogVbox.getStyleClass().add("headerPane");
                        dialogVbox.getChildren().add(new Text("This is a Dialog"));
                        Scene dialogScene = new Scene(dialogVbox, 300, 200);
                        dialog.setScene(dialogScene);
                        dialog.show();
                    }
                });

        tableView.setPlaceholder(stripedRowPlaceholder());
        //tableView2.setPlaceholder(stripedRowPlaceholder());
        b_tableView.setPlaceholder(stripedRowPlaceholder());

        instrumentColumn.setCellValueFactory(cd -> cd.getValue().instrumentProperty());
        instrumentColumn.getStyleClass().add("bold-font");

        typeColumn.getStyleClass().add("type-column");
        typeColumn.setResizable(false);
        typeColumn.setCellValueFactory(cd -> cd.getValue().typeProperty());
        typeColumn.setCellFactory(tableView -> {
            return new TableCell<Instrument, String>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item != null) {
                        Button b = new Button();
                        b.setPickOnBounds(true);
                        b.getStyleClass().add("xfe-cell-button");
                        b.getStyleClass().add(item.equals("Bid") ? "table-view-bid-button" : "table-view-offer-button");

                        Label l = new Label(item);
                        l.getStyleClass().addAll(item.equals("Bid") ? "referred" : "opened", "bold-font");
                        setGraphic(b);
                    }
                }
            };
        });

        totalColumn.setCellValueFactory(cd -> cd.getValue().totalProperty());
        totalColumn.getStyleClass().add("bold-font");
        totalColumn.setCellFactory(new Callback<TableColumn<Instrument, String>, TableCell<Instrument, String>>() {
            @Override
            public TableCell<Instrument, String> call(TableColumn<Instrument, String> param) {
                return new TableCell<Instrument, String>(){

                    TickUpDownUtil helper = new TickUpDownUtil(0,this, 0.25, 4);
                    {
                        helper.setCallBack((val,isTickUp)->{
                            System.out.println((isTickUp?"Tick Up":"Tick Down")+" for value :"+val);
                            setText(val.toString());
                            helper.setBaseValue(val);
                        });
                    }
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if(item!=null && !empty){
                            setText(item);
                            helper.setBaseValue(Double.parseDouble(item));
                            helper.setEnabled(true);
                        }else{
                            setText(null);
                            helper.setEnabled(false);
                        }
                    }
                };
            }
        });
        bidColumn.setCellValueFactory(cd -> cd.getValue().bidProperty());
        offerColumn.setCellValueFactory(cd -> cd.getValue().offerProperty());
        offerColumn.setCellFactory(new Callback<TableColumn<Instrument, String>, TableCell<Instrument, String>>() {
            @Override
            public TableCell<Instrument, String> call(TableColumn<Instrument, String> param) {
                return new TableCell<Instrument, String>(){
                    StackPane sp = new StackPane();
                    Label lbl = new Label();
                    TickUpDownUtil helper = new TickUpDownUtil(0,sp, 0.25, 4);
                    {
                        helper.setCallBack((val,isTickUp)->{
                            System.out.println((isTickUp?"Tick Up":"Tick Down")+" for value :"+val);
                        });
                        sp.getChildren().add(lbl);
                        sp.setStyle("-fx-background-color:pink;");
                    }
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if(item!=null && !empty){
                            lbl.setText(item);
                            setGraphic(sp);
                        }else{
                            setGraphic(null);
                        }
                    }
                };
            }
        });
        amountColumn.setCellValueFactory(cd -> cd.getValue().amountProperty());
        priceColumn.setCellValueFactory(cd -> cd.getValue().priceProperty());


        ObservableList<Instrument> instruments = FXCollections.observableArrayList(Instrument.getSampleData());
        tableView.setItems(instruments);

        scenicViewButton.setOnAction(e -> ScenicView.show(MainApplication.scene));
        Platform.runLater(() -> {
            instrumentsTab.lookupAll(".tab-label > .text").stream()
                    .forEach(node -> {
                        // System.out.println("Node :: "+node.getParent().getChildrenUnmodifiable().remove(node));
                    });
        });

        addMenu();
        addPopOver();
        addWorkup();
        addSettings();
    }

    private void addSettings(){
        settingsButton.setOnAction(e->{
            SettingsLayout setttings = SettingsLayout.load();
            PopUpStage stage = new PopUpStage(MainApplication.stage, this,setttings.getRoot(),"Settings" );
            stage.showStage();
            //ScenicView.show(stage.getScene());
        });
    }

    private void addWorkup() {
        closeButton.setOnAction(e->{
            TradesWorkupLayout workup = TradesWorkupLayout.load();
            PopUpStage stage = new PopUpStage(MainApplication.stage, this,workup.getRoot(),"ICAP Gilts Trades Workup" );
            //stage.setStageAsNonResizable();
            stage.showStage();
           //ScenicView.show(stage.getScene());
        });
    }

    private void addPopOver() {
        popOverButton.setOnAction(e->{
            PopOver editor = new PopOver();
            Text text = new Text("This is text");
            Label lbl = new Label("This is label");
            VBox vb = new VBox();
            vb.setPadding(new Insets(20));
            vb.setPrefSize(200,200);
            vb.getChildren().addAll(text,lbl);
            editor.setContentNode(vb);
            editor.show(popOverButton);
        });
    }

    private void addMenu() {
        Menu item1 = new Menu("Appearance");
        MenuItem subitem1 = new MenuItem("Sub Item");
        MenuItem subitem2 = new MenuItem("Different Item");
        item1.getItems().addAll(subitem1,subitem2);
        MenuItem logout = new MenuItem("Logout");
        menuBox.getItems().addAll(item1,logout);

        Menu i1 = new Menu("Appearance");
        MenuItem si1 = new MenuItem("Sub Item");
        MenuItem si2 = new MenuItem("Different Item");
        i1.getItems().addAll(si1,si2);
        MenuItem lg = new MenuItem("Logout");
        showMeBox.getItems().addAll(i1,lg);


    }

    private void addTab(String title, String subTitle, TabPane tabPane) {
        Tab newTab = new Tab();
        newTab.setText(subTitle != null ? title + "\n" + subTitle : title);
        newTab.setClosable(false);
        if (tabPane == instrumentsTab) {
            Text text1 = new Text(title);
            text1.getStyleClass().add("tab-title");
            if (subTitle != null) {
                Text text2 = new Text("\n" + subTitle);
                text2.getStyleClass().add("tab-sub-title");
                TextFlow textFlow = new TextFlow(text1, text2);
                newTab.setGraphic(textFlow);
            } else {
                TextFlow textFlow = new TextFlow(text1);
                newTab.setGraphic(textFlow);
            }
        }
        tabPane.getTabs().add(newTab);
    }

    public static Node stripedRowPlaceholder() {
        StackPane sp = new StackPane();
        sp.getStyleClass().add("xfe-table-view-place-holder");
        return sp;
    }

    @Override
    public void register(String id, PopUpStage window) {

    }

    @Override
    public void unregister(String id, PopUpStage window) {

    }

    @FXML
    private void showMemoryMonitor(){
        MonitorWindow.show(new Date());
    }
}