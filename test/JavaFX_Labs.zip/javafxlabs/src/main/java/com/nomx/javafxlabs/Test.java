package com.nomx.javafxlabs;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Test {

    public static void main(String... a){
        String path = "/home/saidan/csltools/syssrv_4.1.1/lib:/home/saidan/csltools/tsmr_5.4.65.25/lib:/home/saidan/csltools/gsl_1.14.0-1/lib::/home/saidan/icap_v2/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v2/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v2/olts/lib:/home/saidan/icap_v2/olts/../comet/lib:/home/saidan/csltools/picompress_2.9.4/pub:/home/saidan/icap_v2/olts/../ipxs/lib::/home/saidan/icap_v2/olts/../hurl/lib:/usr/pgsql-9.6/lib:/home/saidan/csltools/syssrv_4.1.1/lib:/home/saidan/csltools/tsmr_5.4.65.25/lib:/home/saidan/csltools/gsl_1.14.0-1/lib::/home/saidan/icap_v2/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v2/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v2/olts/lib:/home/saidan/icap_v2/olts/../comet/lib:/home/saidan/csltools/picompress_2.9.4/pub:/home/saidan/icap_v2/olts/../ipxs/lib::/home/saidan/icap_v2/olts/../hurl/lib:/home/saidan/csltools/syssrv_4.1.1/lib:/home/saidan/csltools/tsmr_5.4.65.25/lib:/home/saidan/csltools/gsl_1.14.0-1/lib::/home/saidan/icap_v4/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v4/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v4/olts/lib:/home/saidan/icap_v4/olts/../comet/lib:/home/saidan/csltools/picompress_2.9.4/pub:/home/saidan/icap_v4/olts/../ipxs/lib::/home/saidan/icap_v4/olts/../hurl/lib:/home/saidan/csltools/syssrv_4.1.1/lib:/home/saidan/csltools/tsmr_5.4.65.25/lib:/home/saidan/csltools/gsl_1.14.0-1/lib::/home/saidan/icap_v4/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v4/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v4/olts/lib:/home/saidan/icap_v4/olts/../comet/lib:/home/saidan/csltools/picompress_2.9.4/pub:/home/saidan/icap_v4/olts/../ipxs/lib::/home/saidan/icap_v4/olts/../hurl/lib:/home/saidan/csltools/syssrv_4.1.1/lib:/home/saidan/csltools/gsl_1.14.0-1/lib:/home/saidan/csltools/tsmr_5.4.65.25/lib::/home/saidan/icap_v4/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v4/olts/../amp/lib:/home/saidan/csltools/snacc_1.1.3.6/lib:/home/saidan/icap_v4/olts/lib:/home/saidan/icap_v4/olts/../comet/lib:/home/saidan/csltools/picompress_2.9.4/pub:/home/saidan/icap_v4/olts/../ipxs/lib::/home/saidan/icap_v4/olts/../hurl/lib::/usr/pgsql-9.3/lib";
        String[] paths = path.split(":");
        List<String> pList = new ArrayList<>();
        for(String pth : paths){
            if(!pList.contains(pth)){
                pList.add(pth);
            }
        }
        System.out.println(pList.stream().collect(Collectors.joining(":")));
    }
}
