package com.nomx.memorymonitor;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import org.scenicview.ScenicView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xfe.util.EasyFXML;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class MonitorWindow {
   private static final Logger logger = LoggerFactory.getLogger(MonitorWindow.class);

   private static final double BYTES_TO_MB = 1.0 / (1024.0 * 1024.0);

   private final List<DummyClass> leakMemoryHolder = new LinkedList<>();
   private long leakInterval = 100;
   private boolean isKeepLeaking = true;

   private static String mSecsToTime(long mSecs) {
      long seconds = mSecs / 1000;
      return String.format("%d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, (seconds % 60));

   }

   private static class MemInfo {
      final long upTime;
      final long maxMem;
      final long totalMem;
      final long usedMem;

      MemInfo(Date startTime) {
         upTime = new Date().getTime() - startTime.getTime();
         maxMem = Runtime.getRuntime().maxMemory();
         totalMem = Runtime.getRuntime().totalMemory();
         usedMem = totalMem - Runtime.getRuntime().freeMemory();
      }

      double getMaxMb() {
         return maxMem * BYTES_TO_MB;
      }

      double getTotalMb() {
         return totalMem * BYTES_TO_MB;
      }

      double getUsedMb() {
         return usedMem * BYTES_TO_MB;
      }

      String getFormattedUpTime() {
         return mSecsToTime(upTime);
      }
//		long getUpTimeSeconds() {
//			return upTime / 1000;
//		}

      @Override
      public String toString() {
         return String.format("Uptime: %s - Memory Max: %.1fMb  -  Total: %.1fMb  - Used: %.1fMb",
            getFormattedUpTime(),
            getMaxMb(),
            getTotalMb(),
            getUsedMb()
         );
      }
   }

   public static Date applicationStartTime;
   private final Series<Number, Number> totalMemSeries = new Series<>();
   private final Series<Number, Number> usedMemSeries = new Series<>();
   private final Series<Number, Number> maxMemSeries = new Series<>();
   private Task<Void> snapshotTask;
   private long gcCount;
   private long gcTime;
   private double gcLoad;
   private Date lastCollection = new Date();

   private Task<Void> createSnapshotTask() {
      return new Task<Void>() {


         @Override
         protected Void call() throws Exception {
            while (!isDone()) {
               if (gcBeforeUpdateCheck.isSelected())
                  gc(1);
               long count = 0;
               long time = 0;
               for (GarbageCollectorMXBean bean : ManagementFactory.getGarbageCollectorMXBeans()) {
                  count += bean.getCollectionCount();
                  time += bean.getCollectionTime();
               }

               Date now = new Date();
               gcLoad = ((double) (time - gcTime)) / (now.getTime() - lastCollection.getTime());
               logger.info("GC runs: {} Duration: {}ms Load:{}", count - gcCount, time - gcTime, gcLoad);
               gcCount = count;
               gcTime = time;
               MemInfo mi = new MemInfo(applicationStartTime);
               logger.info("{}", mi);
               lastCollection = now;
               Platform.runLater(() -> appendChartData(mi));
               Thread.sleep(autoIntervalChoice.getValue() * 1000);
            }
            return null;
         }
      };

   }

   @FXML
   public AnchorPane root;
   @FXML
   public TextArea logArea;
   @FXML
   public Button gcButton;
   @FXML
   public AreaChart<Number, Number> memChart;
   @FXML
   public NumberAxis xAxis;
   @FXML
   public NumberAxis yAxis;
   @FXML
   public ChoiceBox<Integer> gcChoice;
   @FXML
   public CheckBox autoCheck;
   @FXML
   public ChoiceBox<Integer> autoIntervalChoice;
   @FXML
   public Button clearButton;
   @FXML
   public CheckBox gcBeforeUpdateCheck;
   @FXML
   public Button slowMemoryLeak;
   @FXML
   public Button fastMemoryLeak;
   @FXML
   public Button stopMemoryLeak;
   @FXML
   public Button clearMemoryLeak;
   @FXML
   public TextField textThreshold;

   public AnchorPane getRoot() {
      return root;
   }

   @FXML
   public void handleGcButtonAction(ActionEvent event) {
      logger.info("Performing manual Snapshot");
      doSnapshot();
   }

   @FXML
   public void handleClearGraphButtonAction(ActionEvent event) {
      logger.info("Clearing snapshot data.");
      doSnapshot();
      maxMemSeries.getData().subList(0, maxMemSeries.getData().size() - 1).clear();
      totalMemSeries.getData().subList(0, totalMemSeries.getData().size() - 1).clear();
      usedMemSeries.getData().subList(0, usedMemSeries.getData().size() - 1).clear();
   }

   public MonitorWindow() {

   }

   public MonitorWindow(Date startTime) {
      applicationStartTime = new Date(startTime.getTime());
   }

   static MonitorWindow mw;
   static Stage stage;

   public static synchronized void show(Date startTime) {
      MonitorWindow.applicationStartTime = startTime;
      if (stage == null) {
         stage = new Stage();
         mw = new MonitorWindow(startTime);
         stage.setOnHidden(paramT -> mw.dispose());
         stage.setScene(new Scene(load(mw)));
         stage.show();
      } else {
         stage.show();
         stage.toFront();
      }
      ScenicView.show(stage.getScene());

   }

   protected void dispose() {
      stopSnapshotTask();
   }

   private void gc(int count) {
      for (int i = 0; i < count; i++)
         System.gc();
   }


   public static void stopLeak() {
      if (mw != null) {
         logger.warn("Stop Leak Pressed");
         mw.isKeepLeaking = false;
      }
   }

   private void doSnapshot() {
      gc(Double.valueOf(gcChoice.getValue()).intValue());
      MemInfo mi = new MemInfo(applicationStartTime);
      logArea.appendText(mi.toString());
      logArea.appendText("\n");
      logger.info("GC Snapshot result: {}", mi);
      appendChartData(mi);
   }

   private void appendChartData(MemInfo mi) {

      maxMemSeries.getData().add(new Data<>(mi.upTime, mi.getMaxMb()));
      totalMemSeries.getData().add(new Data<>(mi.upTime, mi.getTotalMb()));
      usedMemSeries.getData().add(new Data<>(mi.upTime, mi.getUsedMb()));
      if (maxMemSeries.getData().size() > 100) {
         maxMemSeries.getData().remove(0);
         totalMemSeries.getData().remove(0);
         usedMemSeries.getData().remove(0);
      }
   }

   public static Parent load(MonitorWindow controller) {
      AnchorPane p = null;
      try {
         MonitorWindow mw = EasyFXML.load(MonitorWindow.class);
         return mw.getRoot();
//			FXMLLoader ldr = new FXMLLoader(MonitorWindow.class.getResource("xfe/util/scene/MonitorWindow.fxml"));
//			ldr.setControllerFactory(paramP -> controller);
//			p = ldr.load();
      } catch (Exception e) {
         e.printStackTrace();
      }
      return p;
   }

   private void stopSnapshotTask() {
      if (snapshotTask != null && snapshotTask.isRunning()) {
         snapshotTask.cancel();
      }
   }

   private void startSnapshotTask() {
      stopSnapshotTask();
      snapshotTask = createSnapshotTask();
      Thread memLogThread = new Thread(snapshotTask);
      memLogThread.setDaemon(true);
      gcTime = 0;
      gcCount = 0;
      for (GarbageCollectorMXBean bean : ManagementFactory.getGarbageCollectorMXBeans()) {
         gcCount += bean.getCollectionCount();
         gcTime += bean.getCollectionTime();
      }
      memLogThread.start();
   }

   //	private MemoryUsageMonitor memoryMonitor = new MemoryUsageMonitor(300*1024*1024L);
   double threshold_percentage = 0.98;

   @FXML
   public void initialize() {
      logArea.clear();
      logArea.appendText(String.format("Application started on %s%n", applicationStartTime));
      gcChoice.getItems().clear();
      gcChoice.getItems().addAll(0, 1, 5, 10, 15, 20);
      gcChoice.setValue(2);
      autoIntervalChoice.getItems().clear();
      autoIntervalChoice.getItems().addAll(1, 2, 5, 10, 20, 60);
      autoIntervalChoice.setValue(60);
      gcBeforeUpdateCheck.setSelected(false);
      gcBeforeUpdateCheck.selectedProperty().addListener((observable, oldValue, newValue) -> {
         logger.info("Run GC flag changed to {}", newValue);
      });
      autoIntervalChoice.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
         logger.info("Monitor Interval changed from {} to {}", oldValue, newValue);
      });
      gcChoice.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
         logger.info("GC Run count changed from {} to {}", oldValue, newValue);
      });

      logger.info("Initial Snapshot");
      doSnapshot();
      ObservableList<Series<Number, Number>> areaChartData2 = FXCollections.observableArrayList();
      areaChartData2.addAll(totalMemSeries, usedMemSeries);
      memChart.setData(areaChartData2);

      usedMemSeries.setName("Memory Used");
      totalMemSeries.setName("Allocated Memory");
      xAxis.setTickLabelFormatter(new StringConverter<Number>() {

         @Override
         public String toString(Number data) {
            return mSecsToTime(data.longValue());
         }

         @Override
         public Number fromString(String paramString) {
            return null;
         }
      });

      autoCheck.selectedProperty().addListener((paramObservableValue, oldVal, newVal) -> {
         logger.info("Auto Update changed to {}", newVal);
         if (newVal)
            startSnapshotTask();
         else
            stopSnapshotTask();
      });

      Runnable leakingThread = new Runnable() {

         @Override
         public void run() {
            leakMemoryHolder.add(new DummyClass());
            if (leakMemoryHolder.size() % 1000 == 0)
               logger.debug("leakMemoryHolder's size is {}, Memory is {}M", leakMemoryHolder.size(), leakMemoryHolder.size() * 8092 / 1024 / 1024);
            if (isKeepLeaking) {
               //Fx.delay(leakInterval, this);
            }
         }
      };

      slowMemoryLeak.setOnMouseClicked(event -> {
         logger.warn("slowMemoryLeak Pressed");
         isKeepLeaking = true;
         leakInterval = 200;
         Platform.runLater(leakingThread);
         fastMemoryLeak.setDisable(true);
         slowMemoryLeak.setDisable(true);
      });


      fastMemoryLeak.setOnMouseClicked(event -> {
         logger.warn("fastMemoryLeak Pressed");
         isKeepLeaking = true;
         leakInterval = 10;
         try {
            threshold_percentage = Double.parseDouble(textThreshold.getText());
         } catch (Exception e) {
            threshold_percentage = 0.98;
         }
//            Callback<MemoryUsage,Void> callback = new Callback<MemoryUsage, Void>() {
//
//               @Override
//               public Void call(MemoryUsage param) {
//                  logger.info("Stop the leaking procedure since memory usage break the threshold({}).",threshold_percentage);
//                  memoryMonitor.unregister();
//                  fastMemoryLeak.setDisable(false);
//                  slowMemoryLeak.setDisable(false);
//                  isKeepLeaking = false;
//                  return null;
//               }
//            };
//            memoryMonitor.register(callback);
         Platform.runLater(leakingThread);
         fastMemoryLeak.setDisable(true);
         slowMemoryLeak.setDisable(true);
      });

      stopMemoryLeak.setOnMouseClicked(event -> {
         logger.warn("stopMemoryLeak Pressed");
         isKeepLeaking = false;
//            memoryMonitor.unregister();
         fastMemoryLeak.setDisable(false);
         slowMemoryLeak.setDisable(false);
      });

      clearMemoryLeak.setOnAction(arg0 -> {
         logger.warn("clearMemoryLeak Pressed");
         leakMemoryHolder.clear();
      });
   }


   /**
    * size of the object is 8092(8k)  bytes.  1009*8(8072) + 8 (bytes object overhead) + 12 ( for array object overhead).
    *
    * @author jiadin
    */
   private class DummyClass {
      private final long[] dummyLong = new long[1009];
   }

   public static synchronized void close() {
      if (stage != null) {
         stage.close();
      }
   }
}
