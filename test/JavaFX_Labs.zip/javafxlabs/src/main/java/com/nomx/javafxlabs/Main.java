package com.nomx.javafxlabs;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Main extends Application {
    private Stage primaryStage;
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        try {
            BorderPane root = new BorderPane();
            root.setBackground(new Background(new BackgroundFill(Color.YELLOW, null, null)));
            Button b = new Button("Click me");
            b.setOnAction(this::OnClick);
            root.setCenter(b);
            Scene scene = new Scene(root,400,400);
            //scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    private void OnClick(ActionEvent event)
    {
        Stage popup = new Stage();
        popup.initStyle(StageStyle.TRANSPARENT);
        // popup.initStyle(StageStyle.UNDECORATED);
        popup.initOwner(primaryStage);
        popup.setAlwaysOnTop(true);

        VBox vb = new VBox();
        Scene scene = new Scene(vb);
        scene.setFill(Color.TRANSPARENT);
        popup.setScene(scene);
        vb.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, null, null)));
        ClassLoader cl = Main.class.getClassLoader();
        Image image = new Image(cl.getResourceAsStream("images/TranspRedCircle.png"));
        ImageView view = new ImageView(image);
        view.setFitHeight(image.getHeight()/4);
        view.setFitWidth(image.getWidth()/4);
        vb.getChildren().add(view);
        popup.show();
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                int i = 0; // set breakpoint here
            }
        });
    }
    public static void main(String[] args) {
        launch(args);
    }
}