package com.nomx.javafxlabs;

import com.nomx.javafxlabs.constants.StyleSheet;
import com.sun.javafx.css.StyleManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainApplication extends Application {

    public static Stage stage ;
    public static  Scene scene;
    protected BorderPane root ;

    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        root = FXMLLoader.load(getClass().getResource("/fxml/RootLayout.fxml"));
        scene = new Scene(root,700,700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("JavaFX Labs");
        primaryStage.show();
        Application.setUserAgentStylesheet(null);
        StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.CORE_BASE.getPath());
        StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.BASE.getPath());
        StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.TEST.getPath());
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
