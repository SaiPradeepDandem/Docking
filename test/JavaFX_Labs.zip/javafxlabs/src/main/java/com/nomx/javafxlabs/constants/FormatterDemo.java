package com.nomx.javafxlabs.constants;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.function.Function;
import java.util.stream.IntStream;

public class FormatterDemo {
    public static void main(String... a) {
        BigDecimal bd = new BigDecimal(-51.067);
        DecimalFormat defaultPriceFormat = new DecimalFormat();
        defaultPriceFormat.setMaximumFractionDigits(2);
        defaultPriceFormat.setMinimumFractionDigits(2);
        defaultPriceFormat.setPositivePrefix("");
        defaultPriceFormat.setNegativePrefix("");
        //System.out.println(defaultPriceFormat.format(bd));

        DecimalFormat dpf = new DecimalFormat();
        //dpf.setMinimumFractionDigits(2);
        //dpf.setRoundingMode(RoundingMode.UP);

        Function<Number, String> f = formatter(3);
        System.out.println(f.apply(-95));
        System.out.println(f.apply(95.12));
        System.out.println(f.apply(95.134530));
        System.out.println(f.apply(95.1367));

    }

    public static DecimalFormat getPrefixPriceFormat(int minDecmials) {
        DecimalFormat priceFormat = new DecimalFormat();
        priceFormat.setMinimumFractionDigits(minDecmials);
        priceFormat.setPositivePrefix("+");
        priceFormat.setNegativePrefix("-");
        return priceFormat;
    }

    public static Function<Number, String> formatter(int minDecimals) {
        return (number) -> {
            String prefix = number.doubleValue() >= 0 ? "+" : "";
            String output = number.doubleValue() + "";
            String decimals = output.substring(output.indexOf(".") + 1);
            if (decimals.length() < minDecimals) {
                int req = minDecimals - decimals.length();
                StringBuilder zeros = new StringBuilder();
                IntStream.range(0, req).forEach(i -> zeros.append("0"));
                output = output + zeros;
            }
            return prefix + output;
        };
    }
}
