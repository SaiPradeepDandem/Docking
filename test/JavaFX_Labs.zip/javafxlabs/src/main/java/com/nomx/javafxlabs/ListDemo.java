package com.nomx.javafxlabs;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ListDemo {

    public static void main(String...a){
        ObservableList<String> list = FXCollections.observableArrayList();
        list.add("A");
        FilteredList<String> fl = new FilteredList(list);
        Stream.of("B","C","D").forEach(s->list.add(s));
        System.out.println(fl.size());
    }
}
