package com.nomx.persist;

import com.nomx.domain.types.AlertSound;

import java.io.Serializable;

public enum PersistantName {
    AlertSoundForMine(AlertSound.class, AlertSound.NONE, "AlertSoundForMine"),
    AlertSoundForAll(AlertSound.class, AlertSound.NONE, "AlertSoundForAll"),

    MarketSizeOnOrderEnter(Boolean.class, false, "MarketSizeOnOrderEnter"),
    OutrightDefaultQty(Double.class, 50.0, "OutrightDefaultQty"),

    LeftQtyBtn(Integer.class, 25, "LeftQtyBtn"),
    MiddleQtyBtn(Integer.class, 50, "MiddleQtyBtn"),
    RightQtyBtn(Integer.class, 100, "RightQtyBtn");

    private Class<?> inputType = Object.class; // the type of the setting
    private Serializable defaultValue;  // the default value of this setting
    private final String desc;

    private PersistantName(Class<? extends Serializable> inputType, Serializable defaultValue, String name) {
        this.inputType = inputType;
        this.defaultValue = defaultValue;
        this.desc = name;
    }


}
