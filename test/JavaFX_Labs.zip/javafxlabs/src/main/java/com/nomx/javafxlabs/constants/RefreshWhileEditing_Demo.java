package com.nomx.javafxlabs.constants;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.Duration;

import java.security.SecureRandom;
import java.util.concurrent.atomic.AtomicInteger;

public class RefreshWhileEditing_Demo extends Application {
    ObservableList<Person> persons = FXCollections.observableArrayList();
    SecureRandom rnd = new SecureRandom();

    @Override
   public void start(Stage primaryStage) throws Exception {
        for (int i = 0; i < 10; i++) {
            persons.add(new Person("First name" + i, "Last Name" + i));
        }

        TableView<Person> tableView = new TableView<>();
        tableView.editingCellProperty().addListener((obs,old,val)->{
            tableView.setUserData(val);
        });
        tableView.setEditable(true);
        TableColumn<Person, String> indexCol = new TableColumn<>("Index");
        indexCol.setCellValueFactory(param -> param.getValue().firstNameProperty());
        indexCol.setCellFactory(new Callback<TableColumn<Person, String>, TableCell<Person, String>>() {
            @Override
            public TableCell<Person, String> call(TableColumn<Person, String> param) {
                return new TableCell<Person, String>(){
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        setText("");

                        if(!empty){
                            setText(getIndex()+"");
                        }
                    }
                };
            }
        });
        TableColumn<Person, String> fnCol = new TableColumn<>("First Name");
        fnCol.setEditable(true);
        fnCol.setCellValueFactory(param -> param.getValue().firstNameProperty());
        fnCol.setCellFactory(param -> new EditingCell<>());

        TableColumn<Person, String> lnCol = new TableColumn<>("Last Name");
        lnCol.setEditable(true);
        lnCol.setCellValueFactory(param -> param.getValue().lastNameProperty());
        lnCol.setCellFactory(param -> new EditingCell<>());

        tableView.getColumns().addAll(indexCol, fnCol, lnCol);
        tableView.setItems(persons);
        tableView.getItems().addListener((ListChangeListener<? super Person>) p->{
            if(tableView.getUserData()!=null){
                TablePosition<Person,?> pos = (TablePosition<Person,?>) tableView.getUserData();
                Platform.runLater(()->{
                   tableView.edit(pos.getRow(), pos.getTableColumn());
                });
            }
        });

        Label label = new Label();

        VBox sp = new VBox();
        sp.setSpacing(10);
        sp.setPadding(new Insets(10));
        sp.setAlignment(Pos.TOP_LEFT);
        sp.getChildren().addAll(label, tableView);
        Scene sc = new Scene(sp);
        primaryStage.setScene(sc);
        primaryStage.show();

        startTimer(label);
    }

    private void startTimer(Label label) {
        int rowNum = rnd.nextInt(persons.size());
        AtomicInteger timeSeconds = new AtomicInteger(10);
        Timeline timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.seconds(1),
                        event -> {
                            timeSeconds.decrementAndGet();
                            label.setText(
                                    "Updating row : " + rowNum + " in " + timeSeconds.get() + "secs");
                            if (timeSeconds.get() <= 0) {
                                timeline.stop();
                                persons.set(rowNum,new Person(rnd.nextInt(1000) + "",rnd.nextInt(1000) + ""));
                                persons.add(new Person(rnd.nextInt(1000) + "",rnd.nextInt(1000) + ""));
                                startTimer(label);
                            }
                        }));
        timeline.play();
    }

    class EditingCell<T> extends TableCell<T, String> {

        private TextField textField;

        public EditingCell() {

        }

        @Override
        public void startEdit() {
            super.startEdit();

            if (textField == null) {
                createTextField();
            }

            setGraphic(textField);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            textField.selectAll();
        }

        @Override
        public void cancelEdit() {
            super.cancelEdit();
            setText(String.valueOf(getItem()));
            setContentDisplay(ContentDisplay.TEXT_ONLY);
        }

        @Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);

            if (empty) {
               setText(null);
                setGraphic(textField);
            } else {
                if (isEditing()) {
                    if (textField != null) {
                        textField.setText(getString());
                    }
                    setGraphic(textField);
                    setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                } else {
                    setText(getString());
                    setContentDisplay(ContentDisplay.TEXT_ONLY);
                }
            }
        }

        private void createTextField() {
            textField = new TextField(getString());
            textField.setMinWidth(this.getWidth() - this.getGraphicTextGap() * 2);
            textField.setOnKeyPressed(t -> {
                if (t.getCode() == KeyCode.ENTER) {
                    commitEdit(textField.getText());
                } else if (t.getCode() == KeyCode.ESCAPE) {
                    cancelEdit();
                }
            });
        }

        private String getString() {
            return getItem() == null ? "" : getItem();
        }
    }

    public static void main(String... a) {
        Application.launch(a);
    }

    class Person {
        private StringProperty firstName = new SimpleStringProperty();
       private StringProperty lastName = new SimpleStringProperty();

        public Person(String fn, String ln) {
            setFirstName(fn);
            setLastName(ln);
        }

        public String getFirstName() {
            return firstName.get();
        }

        public StringProperty firstNameProperty() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName.set(firstName);
        }

        public String getLastName() {
            return lastName.get();
        }

        public StringProperty lastNameProperty() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName.set(lastName);
        }

    }
}
