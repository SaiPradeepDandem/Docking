package com.nomx.javafxlabs;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.util.Duration;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class NonFocusableStage_Demo extends Application {

    private final SecureRandom rnd = new SecureRandom();
    private final String[] colors = new String[]{};//{"yellow", "pink", "orange", "lightgreen", "gray", "lightblue", "aqua", "gold"};
    static int rowNum = 1;

    @Override
    public void start(Stage stage) throws Exception {

        ChangeListener<Boolean> listener = (obs, old, focused) -> {
            if(StageFactory.INSTANCE!=null) {
                StageFactory.INSTANCE.setAlwaysOnTop(focused);
                if (!focused) {
                    StageFactory.INSTANCE.toBack();
                }
            }
        };

        VBox root = new VBox();
        root.setStyle("-fx-background-color:#888888;");
        root.setSpacing(10);
        root.setPadding(new Insets(10));
        Scene sc = new Scene(root, 600, 600);
        stage.setScene(sc);
        stage.show();
        StageFactory.init(stage);
        Button normal = new Button("Open Normal Stage");
        normal.setOnAction(e -> {
            Stage stg = new Stage();
            StackPane pane = new StackPane(new Label("Stage"));
            stg.setScene(new Scene(pane, 300, 300));
            stg.focusedProperty().addListener(listener);
            stg.show();
        });
        root.getChildren().addAll(normal, new Separator());
        addRow(root);
    }

    private void addRow(VBox root) {
        int num = rowNum;
        GridPane row = new GridPane();
        row.setHgap(10);
        ColumnConstraints c = new ColumnConstraints();
        c.setPrefWidth(40);
        c.setHalignment(HPos.CENTER);
        row.getColumnConstraints().add(c);

        ObjectProperty<StageFactory.CustomStage> obj = new SimpleObjectProperty();
       Button openButton = new Button("Click to open window " + num + " in 5Secs");
        Button hide1Button = new Button("Hide window " + num + " in 5Secs");
        hide1Button.setDisable(true);
        Button hide2Button = new Button("Hide window " + num + " instantly");
        hide2Button.setDisable(true);

        openButton.setOnAction(e -> {
            Timeline timeline = new Timeline(new KeyFrame(Duration.millis(5000), x -> {
                Label lbl = new Label(num + "");
                lbl.setStyle("-fx-font-size:28px;-fx-font-weight:bold;");
                VBox vb = new VBox(lbl,new Label("You can drag me !"));
                vb.setSpacing(10);
                vb.setAlignment(Pos.CENTER);
                StackPane sp = new StackPane(vb);
               sp.setStyle("-fx-background-color:black," + colors[rnd.nextInt(colors.length)] + ";-fx-background-insets:0,2;");
                sp.setPrefSize(200, 200);
                sp.setMinSize(200, 200);
                StageFactory.CustomStage customStage = StageFactory.INSTANCE.createStage();
                customStage.setRoot(sp);
                customStage.setX(300);
                customStage.setY(200);
                customStage.show();
                obj.set(customStage);
                openButton.setDisable(true);
                hide1Button.setDisable(false);
                hide2Button.setDisable(false);
                addRow(root);
            }));
            timeline.setCycleCount(1);
            timeline.play();
        });
        hide1Button.setOnAction(e -> {
            Timeline timeline = new Timeline(new KeyFrame(Duration.millis(5000), x -> {
                obj.get().hide();
                openButton.setDisable(false);
                hide1Button.setDisable(true);
                hide2Button.setDisable(true);
            }));
            timeline.setCycleCount(1);
            timeline.play();
        });

        hide2Button.setOnAction(e -> {
            obj.get().hide();
            openButton.setDisable(false);
            hide1Button.setDisable(true);
            hide2Button.setDisable(true);
        });
        row.addRow(0, new Label(num + ""), openButton, hide1Button, hide2Button);
        root.getChildren().add(row);
        rowNum++;
    }

    public static void main(String... a) {
        Application.launch(a);
    }
}

class StageFactory extends Stage {
    public static StageFactory INSTANCE;
    private static Pane root;
    private List<CustomStage> stages = new ArrayList<>();

    private StageFactory() {
        // Private constructor
    }

    public static void init(Window owner) {
        if (INSTANCE != null) {
            throw new IllegalStateException("Cannot create instance as it is already created");
        }
        StageFactory stageFactory = new StageFactory();
        stageFactory.initOwner(owner);
        stageFactory.initStyle(StageStyle.TRANSPARENT);

        root = new Pane();
        Pane mainRoot = new Pane(root);
        mainRoot.setStyle("-fx-background-color:transparent;");
        stageFactory.setScene(new Scene(mainRoot, Color.TRANSPARENT));
        determineStageSize(stageFactory, root);
        stageFactory.show();

        INSTANCE = stageFactory;
    }

    private static void determineStageSize(Stage stage, Node root) {
        DoubleProperty width = new SimpleDoubleProperty();
        DoubleProperty height = new SimpleDoubleProperty();
        DoubleProperty shift = new SimpleDoubleProperty();
        Screen.getScreens().forEach(screen -> {
            Rectangle2D bounds = screen.getVisualBounds();
            width.set(width.get() + bounds.getWidth());

            if (bounds.getHeight() > height.get()) {
                height.set(bounds.getHeight());
            }
            if (bounds.getMinX() < shift.get()) {
                shift.set(bounds.getMinX());
            }
        });
        stage.setX(shift.get());
        stage.setY(0);
        stage.setWidth(width.get());
        stage.setHeight(height.get());
        root.setTranslateX(-1 * shift.get());
    }

    public CustomStage createStage() {
        CustomStage stage = new CustomStage(root);
        stages.add(stage);
        return stage;
    }

    class CustomStage extends Group {

        private Pane parent;
        double sceneX, sceneY, layoutX, layoutY;

       public CustomStage(Pane parent) {
            this.parent = parent;
            addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                // Making to visible on top
                parent.getChildren().remove(this);
                parent.getChildren().add(this);
            });

            setOnMousePressed(e -> {
                sceneX = e.getSceneX();
                sceneY = e.getSceneY();
                layoutX = getLayoutX();
                layoutY = getLayoutY();
            });
            setOnMouseDragged(e -> {
                double offsetX = e.getSceneX() - sceneX;
                double offsetY = e.getSceneY() - sceneY;
                setTranslateX(offsetX);
                setTranslateY(offsetY);
            });
            setOnMouseReleased(e -> {
                // Updating the new layout positions
                setLayoutX(layoutX + getTranslateX());
                setLayoutY(layoutY + getTranslateY());

                // Resetting the translate positions
                setTranslateX(0);
                setTranslateY(0);
            });
        }

        public void setX(double x) {
            setLayoutX(x);
        }

        public void setY(double y) {
            setLayoutY(y);
        }

        public void show() {
            if (!parent.getChildren().contains(this)) {
                parent.getChildren().add(this);
            }
            parent.getScene().getWindow();
        }

        public void hide() {
            parent.getChildren().remove(this);
        }

        public void setRoot(Node rootNode) {
            getChildren().add(rootNode);
        }
    }
}
