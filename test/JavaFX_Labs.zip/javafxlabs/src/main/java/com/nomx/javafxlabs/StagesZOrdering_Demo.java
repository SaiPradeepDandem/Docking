package com.nomx.javafxlabs;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class StagesZOrdering_Demo extends Application {
    private Map<String, Stage> stages = new HashMap<>();

    @Override
    public void start(Stage stage) throws Exception {
        Button button1 = new Button("Back");
        button1.setOnAction(e -> openStage("Back",stage));

        Button button2 = new Button("Middle");
        button2.setOnAction(e -> openStage("Middle",stage));

        Button button3 = new Button("Front");
        button3.setOnAction(e -> openStage("Front",stage));

        VBox root = new VBox(button1, button2, button3);
        root.setAlignment(Pos.CENTER);
        root.setSpacing(10);
        Scene sc = new Scene(root, 200, 200);
        stage.setScene(sc);
        stage.show();
    }

    private void openStage(String title,Stage stage) {
        if (stages.get(title) != null) {
            stages.get(title).requestFocus();
        } else {
            Stage stg = new Stage();
            stg.setTitle(title);
            stg.setScene(new Scene(new StackPane(), 300, 300, Color.GRAY));
            stg.initOwner(stage);
            stg.show();
            stg.initOwner(null);
            stg.setOnHidden(e -> stages.remove(title));
            stages.put(title, stg);
        }
    }

    public static void main(String... a) {
        Application.launch(a);
    }
}