package com.nomx.javafxlabs;

import javafx.application.Application;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FilteredListTest2 extends Application {

    ObjectProperty<ObservableList<Item>> baseList;

    ObjectProperty<ObservableList<Item>> filteredList;

    ListView<Item> listView;

    ComboBox<Item> comboBox;

    @Override
    public void start(Stage primaryStage) {
        initialize();

        VBox root = new VBox();
        root.getChildren().add(listView);
        root.getChildren().add(comboBox);
        Scene scene = new Scene(root, 160, 250);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void initialize() {
        listView = new ListView<>();
        comboBox = new ComboBox<>();

        baseList = new SimpleObjectProperty<>();
        baseList.set(FXCollections.observableArrayList(item -> 
                new Observable[] {item.activeProperty()}));
        filteredList = new SimpleObjectProperty<>();
        filteredList.set(new FilteredList<>(baseList.get(), item -> item.getActive()));

        listView.itemsProperty().bind(baseList);
        listView.setCellFactory(CheckBoxListCell.forListView(
                Item::activeProperty));

        baseList.get().addListener(new ListChangeListener() {
            @Override
            public void onChanged(ListChangeListener.Change c) {
                if (c.next()) {
                    if (c.wasAdded()) {
                        System.out.println("base list: added " + 
                            (c.getAddedSubList()));
                    } else if (c.wasRemoved()) {
                        System.out.println("base list: removed " + 
                            (c.getRemoved()));
                    }
                }
            }});

        filteredList.get().addListener(new ListChangeListener() {
            @Override
            public void onChanged(ListChangeListener.Change c) {
                if (c.next()) {
                    if (c.wasAdded()) {
                        System.out.println("filtered list: added " + 
                            (c.getAddedSubList()));
                    } else if (c.wasRemoved()) {
                        System.out.println("filtered list: removed " + 
                            (c.getRemoved()));
                    }
                }
            }});

        comboBox.itemsProperty().bind(filteredList);

        baseList.get().add(new Item("1"));
        baseList.get().add(new Item("2"));
        baseList.get().add(new Item("3"));
    } 

    public static class Item {
        private final StringProperty name = new SimpleStringProperty();
        private final BooleanProperty active = new SimpleBooleanProperty(true);

        public Item(String name) {
            setName(name);
        }

        public final StringProperty nameProperty() {
            return this.name;
        }

        public final String getName() {
            return this.nameProperty().get();
        }

        public final void setName(final String name) {
            this.nameProperty().set(name);
        }

        public final BooleanProperty activeProperty() {
        return this.active;
    }

    public final boolean getActive() {
        return this.activeProperty().get();
    }

    public final void setActive(final boolean active) {
        this.activeProperty().set(active);
    }

    @Override
    public String toString() {
        return "name=" + getName() + ", active=" + getActive();
    }
}}