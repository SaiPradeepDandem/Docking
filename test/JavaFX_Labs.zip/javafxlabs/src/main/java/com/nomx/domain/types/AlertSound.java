package com.nomx.domain.types;

import javafx.scene.control.ChoiceBox;

/**
 * Created by jiadin on 6/10/2015.
 */
public enum AlertSound {
   NONE{
      @Override
      public String toString() {
         return "None";
      }
   }

   ,FIREALARM{
      @Override
      public String toString(){
         return "Ding";
      }

      @Override
      public String getFile(){
         return "11.wav";
      }
   }

   ,SELLNOW{
      @Override
      public String toString(){
         return "Glass Ping";
      }

      @Override
      public String getFile(){
         return "21.wav";
      }
   }
   ;

   public String getFile() { return null; }

   public static void setitems(ChoiceBox<AlertSound> choiceBox){
      choiceBox.getItems().setAll(NONE, FIREALARM, SELLNOW);
   }

}
