package com.sai.javafx.tablesorting;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GridPaneRowHidingDemo extends Application {

    int k = 0;

    @Override
    public void start(Stage stage) throws Exception {
        VBox root = new VBox();
        root.setSpacing(10);
        root.setAlignment(Pos.TOP_CENTER);
        Scene scene = new Scene(root);
        stage.setTitle("GridPane Sample");
        stage.setWidth(700);
        stage.setHeight(700);
        stage.setScene(scene);
        stage.show();

        GridPane gp = new GridPane();
        gp.setGridLinesVisible(true);
        gp.setVgap(10);
        gp.setHgap(10);

        FlowPane fp = new FlowPane();
        fp.setHgap(10);
        Button addRow = new Button("Add Row");
        addRow.setOnAction(e -> {
            int count = k;
            gp.addRow(count, new Label("Col 1-" + count), new Label("Col 2-" + count), new Label("Col 3-" + count));
            RowConstraints rc = new RowConstraints();
            rc.setPrefHeight(30);
            gp.getRowConstraints().addAll(rc);
            CheckBox btn = new CheckBox("Row " + count);
            btn.setSelected(true);
            btn.setOnAction(e1 -> {
                toggleRow(count, gp, btn.isSelected());
            });
            fp.getChildren().add(btn);
            k++;
        });

        root.getChildren().addAll(addRow, gp, fp);
    }

    Map<Integer, List<Node>> gpNodes = new HashMap<>();
    private void toggleRow(int index, GridPane gp, boolean visible) {

        if(gpNodes.isEmpty()){
            gp.getChildren().forEach(node -> {
                Integer i = GridPane.getRowIndex(node);
                if(i!=null && i>-1){
                    if(gpNodes.get(i)==null){
                        gpNodes.put(i, new ArrayList<>());
                    }
                    gpNodes.get(i).add(node);
                }
            });
        }
        removeRow(index,gp);
//        RowConstraints rc = gp.getRowConstraints().get(index);
//        gp.getChildren().forEach(node -> {
//            if (node.getProperties().get("gridpane-row") != null && node.getProperties().get("gridpane-row-bkp") == null) {
//                node.getProperties().put("gridpane-row-bkp", node.getProperties().get("gridpane-row"));
//            }
//        });
//        List<Node> rowNodes = gp.getChildren().stream()
//                .filter(n -> {
//                    return n.getProperties().get("gridpane-row-bkp") != null && n.getProperties().get("gridpane-row-bkp").equals(index);
//                })
//                .peek(System.out::println).collect(Collectors.toList());
//
//        rowNodes.forEach(node -> {
//            node.setVisible(false);
//            node.setManaged(false);
//            GridPane.setRowIndex(node, null);
//            GridPane.setColumnIndex(node, null);
//        });
//
//        gp.getChildren().forEach(node -> {
//            Integer idx = (Integer) node.getProperties().get("gridpane-row");
//            if (idx != null && idx>index){
//                node.getProperties().put("gridpane-row", idx-1);
//            }
//        });
//
//        gp.getChildren().removeAll(rowNodes);


//        List<Node> nodes = gp.getChildren().stream().peek(System.out::println).filter(node -> GridPane.getRowIndex(node) == index).collect(Collectors.toList());
//        if(!visible){
//            rc.setMinHeight(0);
//            rc.setMaxHeight(0);
//            rc.setPrefHeight(0);
//            nodes.forEach(n->{
//                n.setVisible(false);
//                n.setManaged(false);
//            });
//        }
//        GridPane.setRowIndex();
    }

    private Node[] removeRow(int rowIdx, GridPane gp) {
        for (int i = gpNodes.size() - 1; i > rowIdx; i--) {
            for (int j = 0; j < gpNodes.get(i).size(); j++) {
                GridPane.setConstraints(gpNodes.get(i).get(j), j, i - 1);
            }
        }

        for (Node node: gpNodes.get(rowIdx)) {
            gp.getChildren().remove(node);
        }
        return null;
    }
    public static void main(String[] args) {
        launch(args);
    }
}
