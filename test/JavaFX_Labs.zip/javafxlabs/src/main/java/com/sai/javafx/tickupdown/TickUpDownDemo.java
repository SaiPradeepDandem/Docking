package com.sai.javafx.tickupdown;

import com.sun.javafx.css.StyleManager;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class TickUpDownDemo extends Application {
    @Override 
    public void start(Stage stage) throws Exception {
        StackPane root = new StackPane();
        Scene sc = new Scene(root, 600, 600);
        sc.getStylesheets().add("/com/sai/javafx/tickupdown/tickupdown.css");
        stage.setScene(sc);
        stage.show();

        StackPane r = new StackPane();
        r.setMinSize(100,50);
        r.setMaxSize(100,50);
        r.setStyle("-fx-background-color:gray;");
        Label lbl = new Label();
        r.getChildren().add(lbl);
        root.getChildren().add(r);
        TickUpDownUtil tickUpDown = new TickUpDownUtil(0,r, 1, 4);
        tickUpDown.setCallBack((val,isTickUp)->{
            System.out.println("Value is :"+val+"  with "+(isTickUp?"TickUp":"TickDown"));
            lbl.setText(val+"");
            tickUpDown.setBaseValue(val);
        });
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
