package com.sai.controlsfx.popover;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.binding.DoubleBinding;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Bounds;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.util.HashMap;
import java.util.Map;

public class PopOverDemo extends Application {
    private int c = 0;

    Map<String, Stage> popupMap = new HashMap<>();
    private double percent = 30;

    @Override
    public void start(Stage stage) throws Exception {
        StackPane root = new StackPane();
        root.setAlignment(Pos.CENTER_LEFT);
        Scene sc = new Scene(root, 600, 600);
        stage.setScene(sc);
        stage.show();

        Line l1 = getLine(sc);
        DoubleBinding x1 = sc.widthProperty().divide(100).multiply(percent);
        l1.translateXProperty().bind(x1);

        Line l2 = getLine(sc);
        DoubleBinding x2 = sc.widthProperty().subtract(x1);
        l2.translateXProperty().bind(x2);

        Line centerLine = getLine(sc);
        centerLine.translateXProperty().bind(sc.widthProperty().divide(2));

        FlowPane hb = new FlowPane();
        hb.setHgap(10);
        hb.setVgap(10);
        hb.setOrientation(Orientation.HORIZONTAL);
        for (int i = 1; i < 15; i++) {
            hb.getChildren().add(createButton(i + ""));
        }

        VBox vb = new VBox();
        StackPane spacer = new StackPane();
        spacer.setMinSize(10, 10);
        vb.getChildren().addAll(spacer, hb);
        root.getChildren().addAll(l1, l2, centerLine, vb);
    }

    private Line getLine(Scene sc) {
        Line l1 = new Line();
        l1.setFill(Color.LIGHTGRAY);
        l1.setStartY(0);
        l1.setStartX(0);
        l1.setEndX(0);
        l1.endYProperty().bind(sc.heightProperty());
        return l1;
    }

    private Button createButton(String t) {
        Button btn = new Button("Show " + t);
        btn.setOnAction(e -> {

            Stage oldStage = popupMap.get(t);
            if (oldStage != null) {
                oldStage.close();
                popupMap.remove(t);
            }

            StackPane sp = new StackPane();
            sp.setStyle("-fx-background-color:#DDDDDD");
            sp.getChildren().add(getTable());

            Bounds boundsInLocal = btn.getBoundsInLocal();
            Bounds boundsInScene = btn.localToScene(boundsInLocal);
            Bounds boundsInScreen = btn.localToScreen(boundsInLocal);

            Scene scene = btn.getScene();
            double x = scene.getWindow().getX();
            double y = boundsInScreen.getMinY() + boundsInLocal.getHeight() - 6;
            double w = scene.getWidth();
            double h = scene.getHeight() - boundsInScene.getMinY() - boundsInLocal.getHeight()-15;

            //sp.setPrefSize(w, h);

            double btnX = btn.getLayoutX();


            PopOver p = new PopOver();
            p.setArrowLocation(PopOver.ArrowLocation.TOP_LEFT);
            p.setArrowIndent(btnX);
            p.setHeaderAlwaysVisible(true);
            p.setContentNode(sp);
            p.show(btn, x, y);
            StackPane popOverRoot = p.getRoot();
            popOverRoot.minHeightProperty().unbind();
            popOverRoot.minWidthProperty().unbind();
            popOverRoot.setMinSize(w, h);
            popOverRoot.setMaxSize(w, h);
            new java.util.Timer().schedule(
                    new java.util.TimerTask() {
                        @Override
                        public void run() {
                            Platform.runLater(() -> {
                                p.getScene().getWindow().setX(x);
                                p.getScene().getWindow().setY(y);
                            });
                        }
                    },
                    100
            );


            p.detachedProperty().addListener((obs, old, detached) -> {
                if (detached) {
                    double w1 = sp.getWidth();
                    double h1 = sp.getHeight();
                    ((BorderPane) p.getRoot().getChildren().get(1)).setCenter(null);
                    Stage s = new Stage();
                    s.initOwner(btn.getScene().getWindow());
                    s.setTitle(t);
                    StackPane root = new StackPane();
                    root.getChildren().add(sp);
                    Scene scn = new Scene(root, w1, h1);
                    scn.setFill(Color.BLUE);
                    s.setScene(scn);
                    s.setX(p.getX());
                    s.setY(p.getY());
                    p.hide();
                    s.show();
                    popupMap.put(t, s);
                }
            });


        });
        return btn;
    }

    private TableView<Person> getTable() {
        ObservableList<Person> list = FXCollections.observableArrayList();
        list.add(new Person("John", "Abraham", 40));
        list.add(new Person("Sandeep", "Chowtha", 56));
        list.add(new Person("Naridu", "GBaridu", 60));

        TableView<Person> tv = new TableView<>();
        TableColumn<Person, String> fc = new TableColumn<>("First Name");
        fc.setCellValueFactory(new PropertyValueFactory<Person, String>("firstName"));
        TableColumn<Person, String> lc = new TableColumn<>("Last Name");
        lc.setCellValueFactory(new PropertyValueFactory<Person, String>("lastName"));
        TableColumn<Person, String> ac = new TableColumn<>("Age");
        ac.setCellValueFactory(new PropertyValueFactory<Person, String>("age"));

        tv.getColumns().addAll(fc, lc, ac);
        tv.setItems(list);
        return tv;
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
