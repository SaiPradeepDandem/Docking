package com.sai.javafx.dragndrop;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class DragNDropDemo extends Application {

    public static Stage stage;
    public static Scene scene;
    protected StackPane root;

    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        root = new StackPane();
        root.setAlignment(Pos.TOP_LEFT);
        scene = new Scene(root, 700, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Drag n Drop");
        primaryStage.show();

        Rectangle r1 = new Rectangle(100, 100, Color.RED);
        r1.setTranslateX(10);
        r1.setTranslateY(10);
        addHandlers(r1);

        Rectangle r2 = new Rectangle(150, 150, Color.GRAY);
        r2.setTranslateX(300);
        r2.setTranslateY(20);
        addHandlers(r2);

        Rectangle r3 = new Rectangle(200, 200, Color.BLUE);
        r3.setTranslateX(400);
        r3.setTranslateY(400);
        addHandlers(r3);

        root.getChildren().addAll(r1, r2, r3);
    }

    private void addHandlers(Rectangle r) {
        Delta delta = new Delta();
        Delta tdelta = new Delta();
        r.setOnMousePressed(e -> {
            delta.x = e.getSceneX();
            delta.y = e.getSceneY();
            tdelta.x = r.getTranslateX();
            tdelta.y = r.getTranslateY();
            r.getScene().setCursor(Cursor.MOVE);
        });
        r.setOnMouseReleased(e -> {
            delta.x = 0;
            delta.y = 0;
            tdelta.x = 0;
            tdelta.y = 0;
            r.getScene().setCursor(Cursor.HAND);
        });
        r.setOnDragDetected(e -> r.startFullDrag());
        r.setOnMouseDragged(e -> {
            r.setTranslateX(tdelta.x + (e.getSceneX() - delta.x));
            r.setTranslateY(tdelta.y + (e.getSceneY() - delta.y));
        });
        r.setOnMouseEntered(e -> {
            if (!e.isPrimaryButtonDown()) {
                r.getScene().setCursor(Cursor.HAND);
            }
        });
        r.setOnMouseDragEntered(e -> r.setOpacity(.5));
        r.setOnMouseDragExited(e -> r.setOpacity(1));
        r.setOnMouseExited(e -> {
            if (!e.isPrimaryButtonDown()) {
                r.getScene().setCursor(Cursor.DEFAULT);
            }
        });
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    class Delta {
        double x, y;
    }
}
