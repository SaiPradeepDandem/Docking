package com.sai.javafx.overflow;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class SimpleShapeDrawing extends Application {

    double x[] = new double[6];
    double y[] = new double[6];
    double orgSceneX, orgSceneY;
    int count = 0;
    boolean drawShape = true;
    private Line currentLine;
    List<Double> values = new ArrayList<>();
    ColorPicker fillColor = new ColorPicker();
    ColorPicker strokeColor = new ColorPicker();
    RadioButton lagSirkel = new RadioButton("Sirkel");
    RadioButton lagRektangel = new RadioButton("Rektangel");
    RadioButton lagPolygon = new RadioButton("Polygon");
    RadioButton lagLinje = new RadioButton("Linje");
    RadioButton edit = new RadioButton("Edit");
    TextArea figurInfo = new TextArea();
    SelectionModel<Shape> selectionModel;
    Group root;

    @Override
    public void start(Stage primaryStage) {
        BorderPane pane = new BorderPane();
        BorderPane.setMargin(pane, new Insets(5, 5, 5, 5));
        pane.setPrefSize(700, 450);
        root = new Group();

        AnchorPane drawArea = new AnchorPane();
        pane.setCenter(drawArea);
        drawArea.setOnMouseDragged(mouseHandlerPolygon);
        drawArea.setOnMousePressed(mouseHandlerPolygon);
        drawArea.setOnMouseReleased(mouseHandlerPolygon);
        drawArea.setStyle("-fx-border-color: black;");
        drawArea.getChildren().add(root);

        VBox vbInfo = new VBox(15);
        figurInfo.setEditable(false);
        figurInfo.setWrapText(true);
        figurInfo.setPrefRowCount(20);
        figurInfo.setPrefColumnCount(10);
        pane.setRight(vbInfo);
        vbInfo.getChildren().addAll(fillColor, strokeColor, figurInfo);

        HBox hbFigurValg = new HBox(15);
        pane.setTop(hbFigurValg);
        ToggleGroup figurKnapper = new ToggleGroup();
        lagSirkel.setToggleGroup(figurKnapper);
        lagRektangel.setToggleGroup(figurKnapper);
        lagPolygon.setToggleGroup(figurKnapper);
        lagLinje.setToggleGroup(figurKnapper);
        edit.setToggleGroup(figurKnapper);
        hbFigurValg.getChildren().addAll(lagSirkel, lagRektangel, lagPolygon, lagLinje, edit);

        drawArea.addEventHandler(MouseEvent.MOUSE_CLICKED, (MouseEvent e) -> {
            if (e.getButton().equals(MouseButton.PRIMARY) && lagSirkel.isSelected()) {
                Circle circle = createCircle(e.getX(), e.getY(), 20, fillColor.getValue());
                circle.setStroke(strokeColor.getValue());
                drawArea.getChildren().add(circle);
            }
        });

        drawArea.addEventHandler(MouseEvent.MOUSE_CLICKED, (MouseEvent e) -> {
            if (e.getButton().equals(MouseButton.PRIMARY) && lagRektangel.isSelected()) {
                Rectangle rectangle = createRectangle(e.getX(), e.getY(), 40, 40);
                rectangle.setStroke(strokeColor.getValue());
                rectangle.setFill(fillColor.getValue());
                drawArea.getChildren().add(rectangle);
                if (e.getButton().equals(MouseButton.PRIMARY) && edit.isSelected() && e.getSource().equals(rectangle)) {
                    figurInfo.setText("Test");
                }
            }
        });
        drawArea.addEventHandler(MouseEvent.MOUSE_PRESSED, (MouseEvent e) -> {
            if (e.getButton().equals(MouseButton.PRIMARY) && lagLinje.isSelected()) {
                currentLine = new Line(e.getX(), e.getY(), e.getX(), e.getY());
                currentLine.setFill(fillColor.getValue());
                currentLine.setStroke(strokeColor.getValue());
                currentLine.setStrokeWidth(3);
                drawArea.getChildren().add(currentLine);

            }
        });

        drawArea.addEventHandler(MouseEvent.MOUSE_DRAGGED, (MouseEvent e) -> {
            if (e.getButton().equals(MouseButton.PRIMARY) && lagLinje.isSelected()) {
                currentLine.setEndX(e.getX());
                currentLine.setEndY(e.getY());
            }
        });

        drawArea.addEventFilter(MouseEvent.MOUSE_CLICKED, e -> {
            if (e.isControlDown()) {
                selectionModel.select((Shape) e.getSource());
                figurInfo.setText("Test");
            }
        });

        Scene scene = new Scene(pane);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private Rectangle createRectangle(double x, double y, double width, double height) {
        Rectangle rectangle = new Rectangle(x, y, width, height);
        rectangle.setCursor(Cursor.HAND);

        rectangle.setOnMousePressed((e) -> {
            orgSceneX = e.getSceneX();
            orgSceneY = e.getSceneY();

            Rectangle r = (Rectangle) (e.getSource());
            r.toFront();
        });

        rectangle.setOnMouseDragged((e) -> {
            double offsetX = e.getSceneX() - orgSceneX;
            double offsetY = e.getSceneY() - orgSceneY;

            Rectangle r = (Rectangle) (e.getSource());

            r.setX(r.getX() + offsetX);
            r.setY(r.getY() + offsetY);

            orgSceneX = e.getSceneX();
            orgSceneY = e.getSceneY();
        });
        return rectangle;
    }

    private Circle createCircle(double x, double y, double r, Color color) {
        Circle circle = new Circle(x, y, r, color);
        circle.setCursor(Cursor.HAND);

        circle.setOnMousePressed((e) -> {
            orgSceneX = e.getSceneX();
            orgSceneY = e.getSceneY();

            Circle c = (Circle) (e.getSource());
            c.toFront();
        });

        circle.setOnMouseDragged((e) -> {
            double offsetX = e.getSceneX() - orgSceneX;
            double offsetY = e.getSceneY() - orgSceneY;

            Circle c = (Circle) (e.getSource());

            c.setCenterX(c.getCenterX() + offsetX);
            c.setCenterY(c.getCenterY() + offsetY);

            orgSceneX = e.getSceneX();
            orgSceneY = e.getSceneY();
        });
        return circle;
    }

    private Polygon createPolygon() {
        Polygon polygon = new Polygon();
        polygon.setCursor(Cursor.HAND);

        polygon.setOnMousePressed((e) -> {
            orgSceneX = e.getSceneX();
            orgSceneY = e.getSceneY();

            Polygon p = (Polygon) (e.getSource());
            p.toFront();
        });

        polygon.setOnMouseDragged((e) -> {
            double offsetX = e.getSceneX() - orgSceneX;
            double offsetY = e.getSceneY() - orgSceneY;

            Polygon p = (Polygon) (e.getSource());

            p.setLayoutX(p.getLayoutX() + offsetX);
            p.setLayoutY(p.getLayoutY() + offsetY);

            orgSceneX = e.getSceneX();
            orgSceneY = e.getSceneY();
        });
        return polygon;
    }
    EventHandler<MouseEvent> mouseHandlerPolygon = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
            if (e.getEventType() == MouseEvent.MOUSE_PRESSED && lagPolygon.isSelected()) {
                if (drawShape) {
                    x[count] = e.getX();
                    y[count] = e.getY();
                }
            } else if (e.getEventType() == MouseEvent.MOUSE_RELEASED && lagPolygon.isSelected()) {
                if (drawShape) {
                    Polygon polygon = createPolygon();
                    values.add(x[count]);
                    values.add(y[count]);
                    count++;
                    polygon.getPoints().addAll(values);
                    polygon.setStroke(strokeColor.getValue());
                    polygon.setStrokeWidth(2);
                    polygon.setFill(fillColor.getValue());
                    root.getChildren().add(polygon);

                    if (count == 6) {
                        drawShape = false;
                        count = 0;
                    }
                }
            }
        }
    };
}