package com.sai.javafx.dragndrop;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class LinesApp extends Application {

    private Pane root = new Pane();
    private DoubleProperty mouseX = new SimpleDoubleProperty();
    private DoubleProperty mouseY = new SimpleDoubleProperty();

    private List<Circle> nodes;
    private Line currentLine = null;
    private boolean dragActive = false;

    private Parent createContent() {
        root.setPrefSize(600, 600);

        nodes = Arrays.asList(
                new Circle(50, 50, 50, Color.BLUE),
                new Circle(500, 100, 50, Color.RED),
                new Circle(400, 500, 50, Color.GREEN)
        );

        nodes.forEach(root.getChildren()::add);

        MenuBar bar = new MenuBar();
        Menu m1 = new Menu("Test");
        Menu m2 =new Menu("Sai");
        bar.getMenus().addAll(m1,m2);

        ObservableList<MenuItem> itms = FXCollections.observableArrayList();
        itms.addAll(new MenuItem("Item1"), new MenuItem("Item 2"), new MenuItem("Item 3"));
        Bindings.bindContent(m1.getItems(), itms);
        Bindings.bindContent(m2.getItems(), itms);
        VBox vb = new VBox(bar,root);
        VBox.setVgrow(root,Priority.ALWAYS);
        return vb;
    }

    private Optional<Circle> findNode(double x, double y) {
        return nodes.stream().filter(n -> n.contains(x, y)).findAny();
    }

    private void startDrag(Circle node) {
        if (dragActive)
            return;

        dragActive = true;
        currentLine = new Line();
        currentLine.setUserData(node);
        currentLine.setStartX(node.getCenterX());
        currentLine.setStartY(node.getCenterY());
        currentLine.endXProperty().bind(mouseX);
        currentLine.endYProperty().bind(mouseY);

        root.getChildren().add(currentLine);
    }

    private void stopDrag(Circle node) {
        dragActive = false;

        if (currentLine.getUserData() != node) {
            // distinct node
            currentLine.endXProperty().unbind();
            currentLine.endYProperty().unbind();
            currentLine.setEndX(node.getCenterX());
            currentLine.setEndY(node.getCenterY());
            currentLine = null;
        } else {
            // same node
            stopDrag();
        }
    }

    private void stopDrag() {
        dragActive = false;

        currentLine.endXProperty().unbind();
        currentLine.endYProperty().unbind();
        root.getChildren().remove(currentLine);
        currentLine = null;
    }

    private void attachHandlers(Scene scene) {
        scene.setOnMouseMoved(e -> {
            mouseX.set(e.getSceneX());
            mouseY.set(e.getSceneY());
        });

        scene.setOnMouseDragged(e -> {
            mouseX.set(e.getSceneX());
            mouseY.set(e.getSceneY());
        });

        scene.setOnMousePressed(e -> {
            findNode(e.getSceneX(), e.getSceneY()).ifPresent(this::startDrag);
        });

        scene.setOnMouseReleased(e -> {
            Optional<Circle> maybeNode = findNode(e.getSceneX(), e.getSceneY());
            if (maybeNode.isPresent()) {
                stopDrag(maybeNode.get());
            } else {
                stopDrag();
            }
        });
    }

    @Override
    public void start(Stage stage) throws Exception {
        Scene scene = new Scene(createContent());

        attachHandlers(scene);

        stage.setScene(scene);
        stage.show();

        Rectangle r = new Rectangle(200,200);
        r.setStyle("-fx-fill:red;");
        String sty = getClass().getResource("test.css").toExternalForm();
        r.sceneProperty().addListener((obs,old,sce)->{
            if(sce!=null && !sce.getStylesheets().contains(sty)){
                System.out.println("hi");
                sce.getStylesheets().add(sty);
            }
        });
        Notifications.create()
                .title("Title Text")
                .text("Hello World 0!")
                .graphic(r)
                .show();//showWarning();
    }

    public static void main(String[] args) {
        launch(args);
    }
}