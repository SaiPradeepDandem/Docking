package com.sai.java.watchservice;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SplitPaneDemo extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox root = new VBox();
        SplitPane split = new SplitPane();
        VBox.setVgrow(split, Priority.ALWAYS);
        split.setOrientation(Orientation.VERTICAL);
        StackPane sp = new StackPane();
        sp.setStyle("-fx-background-color: red;");
        StackPane sp1 = new StackPane();
        sp1.setStyle("-fx-background-color: yellow;");
        split.getItems().addAll(sp, sp1);
        root.getChildren().add(split);


        primaryStage.setOnShown(e -> {
            split.lookupAll(".vertical-grabber").forEach(div -> {
                StackPane divP = (StackPane) div;
                divP.getChildren().clear();
                Label lbl = new Label("Hellowd");
                lbl.setMinWidth(Region.USE_PREF_SIZE);
                divP.getChildren().add(lbl);
            });
        });

        Scene sc = new Scene(root, 500, 500);
        sc.getStylesheets().add(SplitPaneDemo.class.getResource("splitpanedemo.css").toExternalForm());
        primaryStage.setScene(sc);
        primaryStage.show();
    }
}
