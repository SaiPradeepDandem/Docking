package com.sai.javafx.window;

import java.util.Arrays;
import java.util.List;

import javafx.beans.DefaultProperty;
import javafx.collections.ObservableList;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.stage.WindowEvent;

/**
 * A custom control representing a window.
 */
public class XfeWindow extends Stage{

    /**
     * Potential display states for the window
     */
    public enum WindowState {
        /**
         * State if the window is floating
         */
        WINDOWED,
        /**
         * State if the window is minimized
         */
        MINIMIZED,
        /**
         * State if the window is maximized
         */
        MAXIMIZED
    }

    /**
     * Holds the window configuration when minimized or maximized
     */
    class WindowedStateConfig {

        /**
         * The left offset
         */
        private final double windowX;

        /**
         * The top offset
         */
        private final double windowY;

        /**
         * The width of the window
         */
        private final double windowWidth;

        /**
         * The height of the window
         */
        private final double windowHeight;

        /**
         * Constructor for minimize events
         *
         * @param windowHeightTmp the height of the window
         */
        WindowedStateConfig(final double windowHeightTmp) {
            windowX = -1;
            windowY = -1;
            windowWidth = -1;
            windowHeight = windowHeightTmp;
        }

        /**
         * Constructor for maximize and restoration events
         *
         * @param window with the desired configuration
         */
        WindowedStateConfig(final Window window) {
            windowX = window.getX();
            windowY = window.getY();
            if (window instanceof XfeWindow) {
                windowWidth = ((XfeWindow) window).getWindowPane().getWidth();
                windowHeight = ((XfeWindow) window).getWindowPane().getHeight();
            } else {
                windowWidth = window.getWidth();
                windowHeight = window.getHeight();
            }
        }

        /**
         * Assign the dimensions stored here to the provided window
         */
        void assignDimensions() {
            double contentWidth = windowPane.getWidth();
            double contentHeight = windowPane.getHeight();
            if (windowWidth > -1) {
                contentWidth = windowWidth;
            }

            if (windowHeight > -1) {
                contentHeight = windowHeight;
            }
            getWindowPane().resize(contentWidth, contentHeight);

            if (windowX > -1) {
                xfeWindow.setX(windowX);
            }

            if (windowY > -1) {
                xfeWindow.setY(windowY);
            }

            xfeWindow.setWidth(windowPane.getWidth());
            xfeWindow.setHeight(windowPane.getHeight());
        }
    }

    private Stage xfeWindow;

    private static Stage windowOwner;

    /** Id of the window minimize button */
    private static final String MINIMIZE_BUTTON_ID = "button-minimize";

    /** Id of the window maximize button */
    private static final String MAXIMIZE_BUTTON_ID = "button-maximize";

    /** Id of the window close button */
    private static final String CLOSE_BUTTON_ID = "button-close";

    /** List of ids of all window buttons */
    private static final List<String> BUTTON_IDS =
            Arrays.asList(MINIMIZE_BUTTON_ID, MAXIMIZE_BUTTON_ID, CLOSE_BUTTON_ID);

    /** Pseudo class for stage focused state */
    private static final PseudoClass FOCUSED_PSEUDO_CLASS = PseudoClass.getPseudoClass("focused");

    /** Pseudo class for window button restore state */
    private static final PseudoClass RESTORE_PSEUDO_CLASS = PseudoClass.getPseudoClass("restore");

    private WindowAttributes windowAttributes;

    /**
     * The current display state of the window
     */
    private WindowState currentWindowState;

    /**
     * The primary root node of a XfeWindow
     */
    BorderPane windowPane;

    /**
     * The title bar of any WindowMode::Normal window
     */
    private HBox windowTitleBar;

    /**
     * The title box, used for dynamic title elements
     */
    private HBox dynamicTitleBox;

    /**
     * The label displaying the window title
     */
    private Label labelTitle;

    /**
     * The panel on which to delegate any header content
     */
    private HBox headerPane;

    /**
     * The minimize, maximize and close button panel
     */
    private HBox buttonPane;

    /**
     * The minimize button
     */
    private Button buttonMinimize;

    /**
     * The maximize button
     */
    private Button buttonMaximize;

    /**
     * The close button
     */
    private Button buttonClose;

    /**
     * Coordinate for moving the XfeWindow
     */
    private double sceneXOffset = 0;

    /**
     * Coordinate for moving the XfeWindow
     */
    private double sceneYOffset = 0;

    /**
     * Stored configuration for window restoration, if necessary
     */
    private WindowedStateConfig windowedStateConfig;

    /**
     * Constructor
     *
     * @param mainContent Allows the creation of a new window with node already specified
     */
    public XfeWindow(final Node mainContent) {
        this();
        setWindowContent(mainContent);
    }

    /**
     * Constructor
     * <p>
     * Disables the default title bar and border display
     */
    public XfeWindow() {
        super();
        applyTo(this);
        xfeWindow.initOwner(windowOwner);
    }

    public void applyTo(Stage stage){
        xfeWindow = stage;
        xfeWindow.initStyle(StageStyle.TRANSPARENT);
        init();
    }
    private void init(){
        buildRootNode();
        currentWindowState = WindowState.WINDOWED;
        xfeWindow.focusedProperty().addListener(
                (obs, oldValue, focused) -> windowPane.pseudoClassStateChanged(FOCUSED_PSEUDO_CLASS, focused));
        assignTitleBarEvents();
    }

    public void setWindowContent(Node mainContent){
        if (mainContent != null) {
            windowPane.setCenter(mainContent);
            BorderPane.setAlignment(mainContent, Pos.TOP_CENTER);
        }
    }

    /**
     * Required for window hierarchy
     * <p>
     * FIXME CL/PNA: to be removed.
     *
     * @param windowOwnerTmp The parent window
     */
    public static void setWindowOwner(final Stage windowOwnerTmp) {
        XfeWindow.windowOwner = windowOwnerTmp;
    }

    /**
     * Bring to front or show window
     */
    public final void closeWindow() {
        if (xfeWindow.getOnCloseRequest() != null) {
            xfeWindow.getOnCloseRequest().handle(new WindowEvent(this, WindowEvent.WINDOW_CLOSE_REQUEST));
        }
        xfeWindow.hide();
        setWindowState(WindowState.WINDOWED);
    }

    /**
     * The button panel
     *
     * @return The panel
     */
    public final Button getButtonClose() {
        return buttonClose;
    }

    /**
     * The maximize button
     *
     * @return The button
     */
    public final Button getButtonMaximize() {
        return buttonMaximize;
    }

    /**
     * The minimize button
     *
     * @return The button
     */
    public final Button getButtonMinimize() {
        return buttonMinimize;
    }

    /**
     * The button panel
     *
     * @return The panel
     */
    public final HBox getButtonPane() {
        return buttonPane;
    }


    /**
     * The current window state
     *
     * @return the state
     */
    public final WindowState getCurrentWindowState() {
        return currentWindowState;
    }


    /**
     * Get the current location of this window
     *
     * @return The top left of the window as a {@link Point2D}
     */
    public final Point2D getDragPoint() {
        return new Point2D(xfeWindow.getX(), xfeWindow.getY());
    }

    /**
     * The HBox for allowing the display of dynamic title elements
     *
     * @return the hbox
     */
    public HBox getDynamicTitleBox() {
        return dynamicTitleBox;
    }

    /**
     * The header content panel
     *
     * @return the panel
     */
    public final HBox getHeaderPane() {
        return headerPane;
    }



    /**
     * The window title label
     *
     * @return the label
     */
    public final Label getLabelTitle() {
        return labelTitle;
    }


       /**
     * The root node of the XfeWindow
     *
     * @return the pane
     */
    public final BorderPane getWindowPane() {
        return windowPane;
    }

    /**
     * The title bar of the window
     *
     * @return the panel
     */
    public final HBox getWindowTitleBar() {
        return windowTitleBar;
    }

    /**
     * Determines whether the mouse event target node is on any of the window buttons or not.
     *
     * @param event Mouse event instance
     * @return {@code true} if the mouse event target is any of the window buttons else returns {@code false}.
     */
    public boolean isWindowButtonTarget(final MouseEvent event) {
        return event.getTarget() instanceof Button && BUTTON_IDS.contains(((Button) event.getTarget()).getId());
    }





    public final void setWindowTitle(final String  title) {
        if (title != null) {
            xfeWindow.setTitle(title);
            labelTitle.setText(title);
        }
    }

    public Stage getStage(){
        return xfeWindow;
    }
    /**
     * Set the WindowAttributes property.
     *
     */
    public final void setWindowAttributes(final WindowAttributes windowAttributes) {
        this.windowAttributes = windowAttributes;

        if (windowAttributes != null) {
            ResizeHelper.handleResizeListener(this, isWindowResizable());
            final Point2D defaultPosition = windowAttributes.getDefaultPosition();
            if(defaultPosition!=null) {
                xfeWindow.setX(defaultPosition.getX());
                xfeWindow.setY(defaultPosition.getY());
            }

            enableComponent(buttonClose, windowAttributes.isClosable());
            enableComponent(buttonMinimize, windowAttributes.isMinimisable());
            enableComponent(buttonMaximize, windowAttributes.isMaximisable());
        }
    }

    /**
     * Set a new state for the window based on button actions or event triggers
     *
     * @param windowStateTmp The desired window state
     */
    public final void setWindowState(final WindowState windowStateTmp) {
        final WindowState newState;
        if(windowStateTmp == WindowState.MINIMIZED){
            newState =WindowState.MINIMIZED;
        }else {
            newState = windowStateTmp.equals(currentWindowState) ? WindowState.WINDOWED : windowStateTmp;
        }
        currentWindowState = newState;
        final Node center = windowPane.getCenter();
        switch (newState) {
            case MINIMIZED:
//                windowedStateConfig = new WindowedStateConfig(xfeWindow.getHeight());
//
//                xfeWindow.setResizable(false);
//                buttonMaximize.setDisable(true);
//                enableComponent(center, false);
//                xfeWindow.setHeight(windowPane.prefHeight(-1));
                xfeWindow.setIconified(true);
                break;
            case MAXIMIZED:
                //if (xfeWindow.getOwner() != null) {
                    windowedStateConfig = new WindowedStateConfig(xfeWindow);
                    final ObservableList<Screen> screensForRectangle = getScreensForWindow();
                    Screen.getScreensForRectangle(xfeWindow.getX(), xfeWindow.getY(), xfeWindow.getWidth(), xfeWindow.getHeight());

                    final Rectangle2D visualBounds = screensForRectangle.get(0).getVisualBounds();
                    xfeWindow.setX(visualBounds.getMinX());
                    xfeWindow.setY(visualBounds.getMinY());
                    xfeWindow.setWidth(visualBounds.getWidth());
                    xfeWindow.setHeight(visualBounds.getHeight());
               // }

                xfeWindow.setResizable(false);
                buttonMinimize.setDisable(true);
                break;
            case WINDOWED:
            default:
                enableComponent(center, true);
                xfeWindow.setResizable(windowAttributes.isResizable());

                if (windowedStateConfig != null) {
                    windowedStateConfig.assignDimensions();
                    windowedStateConfig = null;
                }

                enableComponent(buttonMinimize, windowAttributes.isMinimisable());
                enableComponent(buttonMaximize, windowAttributes.isMaximisable());

        }
        buttonMaximize.pseudoClassStateChanged(RESTORE_PSEUDO_CLASS, newState == WindowState.MAXIMIZED);
        //buttonMinimize.pseudoClassStateChanged(RESTORE_PSEUDO_CLASS, newState == WindowState.MINIMIZED);
    }

    /**
     * Bring to front or show window
     */
    public final void showWindow() {
        setWindowState(WindowState.WINDOWED);

        xfeWindow.show();
        xfeWindow.toFront();
        xfeWindow.requestFocus();
    }

    /**
     * Assign the movement events to the title bar of the window
     * <p>
     * Make the title visible and managed
     */
    private void assignTitleBarEvents() {
        final Node top = windowPane.getTop();
        if (top != null) {
            enableComponent(top, true);
        }

        windowTitleBar.setOnMousePressed(this::recordXfeWindowLocation);
        windowTitleBar.setOnMouseDragged(this::moveXfeWindow);
        windowTitleBar.setOnMouseReleased(this::resetMousePointer);
    }

    /**
     * Build the default root and title panels for a XfeWindow, and assign all default configurations
     */
    private void buildRootNode() {
        windowPane = new BorderPane();
        windowPane.getStyleClass().add("xfe-window-pane");

        headerPane = new HBox();
        headerPane.setAlignment(Pos.CENTER_RIGHT);

        labelTitle = new Label();
        labelTitle.getStyleClass().add("label-title");
        labelTitle.setMaxHeight(Double.MAX_VALUE);
        HBox.setHgrow(labelTitle, Priority.ALWAYS);

        buttonMinimize = new Button();
        buttonMinimize.setId(MINIMIZE_BUTTON_ID);
        buttonMinimize.setFocusTraversable(false);
        buttonMinimize.getStyleClass().add("xfe-button-minimize");
        buttonMinimize.setOnMouseClicked(evt -> setWindowState(WindowState.MINIMIZED));

        buttonMaximize = new Button();
        buttonMaximize.setId(MAXIMIZE_BUTTON_ID);
        buttonMaximize.setFocusTraversable(false);
        buttonMaximize.getStyleClass().add("xfe-button-maximize");
        buttonMaximize.setOnMouseClicked(evt -> setWindowState(WindowState.MAXIMIZED));

        buttonClose = new Button();
        buttonClose.setId(CLOSE_BUTTON_ID);
        buttonClose.setFocusTraversable(false);
        buttonClose.getStyleClass().add("xfe-button-close");
        buttonClose.setOnMouseClicked(evt -> closeWindow());

        dynamicTitleBox = new HBox(labelTitle);
        dynamicTitleBox.setAlignment(Pos.CENTER_LEFT);
        dynamicTitleBox.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(dynamicTitleBox, Priority.ALWAYS);
        buttonPane = new HBox(buttonMinimize, buttonMaximize, buttonClose);

        windowTitleBar = new HBox(dynamicTitleBox, headerPane, buttonPane);
        windowTitleBar.setSpacing(10);
        windowTitleBar.setPadding(new Insets(0, 0, 0, 10));
        windowTitleBar.setAlignment(Pos.CENTER_LEFT);
        windowTitleBar.getStyleClass().add("xfe-title-bar");
        BorderPane.setAlignment(windowTitleBar, Pos.TOP_CENTER);

        windowPane.setTop(windowTitleBar);
        xfeWindow.setScene(new Scene(windowPane));

        windowPane.heightProperty().addListener((obs, oVal, nVal) -> {
            if (oVal.doubleValue() != nVal.doubleValue() && nVal.doubleValue() != xfeWindow.getHeight()) {
                xfeWindow.setHeight(windowPane.getHeight());
            }
        });
    }

    /**
     * Handles mouse drag events where the user attempts to move the window to another screen
     *
     * @param event The mouse event
     * @param screensForRectangle The list of screens involved in the mouse event
     */
    private void crossScreenDragEvent(final MouseEvent event, final ObservableList<Screen> screensForRectangle) {
        // Screen detection seems to be Screen[0] is the screen where the mouse is. Okay.
        final double mouseLocationX = event.getScreenX();
        final double mouseLocationY = event.getScreenY();
        final Rectangle2D currentScreenMouseBounds = screensForRectangle.get(0).getBounds();
        final Rectangle2D currentScreenVisualBounds = screensForRectangle.get(0).getVisualBounds();
        final Rectangle2D newScreenVisualBounds =
                screensForRectangle.get(screensForRectangle.size() - 1).getVisualBounds();

        if (xfeWindow.getY() < currentScreenVisualBounds.getMinY()) {
            double newY = currentScreenVisualBounds.getMinY();
            if (mouseLocationY < currentScreenMouseBounds.getMinY()) {
                newY = newScreenVisualBounds.getMaxY() - xfeWindow.getHeight();
            }
            xfeWindow.setY(newY);
        } else if (xfeWindow.getY() + xfeWindow.getHeight() > currentScreenVisualBounds.getMaxY()) {
            double newY = currentScreenVisualBounds.getMaxY() - xfeWindow.getHeight();
            if (mouseLocationY >= currentScreenMouseBounds.getMaxY()) {
                newY = newScreenVisualBounds.getMinY();
            }
            xfeWindow.setY(newY);
        }

        if (xfeWindow.getX() + xfeWindow.getWidth() > currentScreenVisualBounds.getMaxX()) {
            double newX = currentScreenVisualBounds.getMaxX() - xfeWindow.getWidth();
            if (mouseLocationX >= currentScreenMouseBounds.getMaxX()) {
                newX = newScreenVisualBounds.getMinX();
            }
            xfeWindow.setX(newX);
        } else if (xfeWindow.getX() < currentScreenVisualBounds.getMinX()) {
            double newX = newScreenVisualBounds.getMaxX() - xfeWindow.getWidth();
            if (mouseLocationX > currentScreenMouseBounds.getMinX()) {
                newX = currentScreenVisualBounds.getMinX();
            }
            xfeWindow.setX(newX);
        }
    }

    /**
     * Disable a component completely from being rendered, clickable or allocated space
     *
     * @param node The node to disable
     * @param isUsable Whether it should be enabled or disabled
     */
    private void enableComponent(final Node node, final Boolean isUsable) {
        node.setVisible(isUsable);
        node.setManaged(isUsable);
        node.setDisable(!isUsable);
    }

    /**
     * Provide the location and dimensions of the window to get a list of intersected screens
     *
     * @return The list of screens
     */
    private ObservableList<Screen> getScreensForWindow() {
        return Screen.getScreensForRectangle(xfeWindow.getX(), xfeWindow.getY(), xfeWindow.getWidth(), xfeWindow.getHeight());
    }

    /**
     * Determines whether the mouse event is performed with primary button or not
     *
     * @param event MouseEvent instance
     * @return {@code true} if the mouse event is performed with primary button else {@code false}
     */
    private boolean isActionButton(final MouseEvent event) {
        return event.getButton().equals(MouseButton.PRIMARY);
    }

    /**
     * Determines whether the window is resizable based on configurable properties {@code WindowAttributes}
     * and {@code WindowModeProperty}
     *
     * @return {@code true} if the window is resizable else {@code false}
     */
    private boolean isWindowResizable() {
        final boolean attrResizable =
                windowAttributes != null ? windowAttributes.isResizable() : false;
       return attrResizable;
    }

    /**
     * Move the window relative to the recorded top-left position
     *
     * @param event The drag mouse event
     */
    private final void moveXfeWindow(final MouseEvent event) {
        if (getCurrentWindowState() != WindowState.MAXIMIZED && isActionButton(event)) {
            final double xOffset = event.getScreenX() - sceneXOffset;
            final double yOffset = event.getScreenY() - sceneYOffset;

            xfeWindow.setX(xOffset);
            xfeWindow.setY(yOffset);

            final ObservableList<Screen> screensForRectangle = getScreensForWindow();
            final Rectangle2D visualBounds = screensForRectangle.get(0).getVisualBounds();
            if (screensForRectangle.size() > 1) {
                crossScreenDragEvent(event, screensForRectangle);
            } else {
                // Manage X Changes
                if (xOffset < visualBounds.getMinX()) {
                    xfeWindow.setX(visualBounds.getMinX());
                } else if (xOffset + xfeWindow.getWidth() > visualBounds.getMaxX()) {
                    xfeWindow.setX(visualBounds.getMaxX() - xfeWindow.getWidth());
                }

                // Manage Y changes
                if (yOffset < visualBounds.getMinY()) {
                    xfeWindow.setY(visualBounds.getMinY());
                } else if (yOffset + xfeWindow.getHeight() > visualBounds.getMaxY()) {
                    xfeWindow.setY(visualBounds.getMaxY() - xfeWindow.getHeight());
                }
            }

            event.consume();
        }
    }

    /**
     * Record the top-left location of the window for drag event handling
     *
     * @param event The drag mouse event
     */
    private final void recordXfeWindowLocation(final MouseEvent event) {
        if (!xfeWindow.isMaximized() && isActionButton(event)) {
            sceneXOffset = event.getSceneX();
            sceneYOffset = event.getSceneY();
            xfeWindow.getScene().setCursor(Cursor.MOVE);
        }
    }

    /**
     * Resets the mouse pointer back to default state
     *
     * @param event The drag mouse event
     */
    private final void resetMousePointer(final MouseEvent event) {
        if (!xfeWindow.isMaximized() && isActionButton(event)) {
            xfeWindow.getScene().setCursor(Cursor.DEFAULT);
        }
    }

}
