package com.sai.javafx.shapes;

import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.effect.InnerShadow;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ArcDemo extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        StackPane root = new StackPane();
        Scene scene = new Scene(root, 500, 500);
        primaryStage.setScene(scene);
        primaryStage.show();

        double border = 1;
        double radius = 150;
        double pieces = 7;
        double eachAngle = 360 / pieces;


        StackPane pane = new StackPane();
        pane.setAlignment(Pos.CENTER_RIGHT);
        pane.setMaxSize((radius * 2)+(2*border), (radius * 2)+(2*border));
        pane.setStyle("-fx-background-color:#FF000050");

        InnerShadow is = new InnerShadow();
        is.setOffsetX(2.0f);
        is.setOffsetY(2.0f);
        is.setColor(Color.web("#333333"));

        Circle c = new Circle(20);
        c.setFill(Color.web("#555555"));
        c.setEffect(is);
        root.getChildren().addAll(pane,c);
        Color[] colors = {Color.GRAY, Color.GREEN, Color.BLUE, Color.LEMONCHIFFON, Color.OLIVE, Color.OLIVEDRAB, Color.YELLOW, Color.PINK, Color.PURPLE, Color.ROYALBLUE};
        for (int i = 0; i < pieces; i++) {
            Arc arc = new Arc();
            arc.setRadiusX(radius);
            arc.setRadiusY(radius);
            arc.setStartAngle(-eachAngle / 2);
            arc.setLength(eachAngle);
            arc.setType(ArcType.ROUND);
            arc.setFill(colors[4]);
            arc.setStrokeWidth(1);
            arc.setStroke(Color.DARKGRAY);
            arc.setOnMouseEntered(e->{arc.setEffect(is);arc.setFill(colors[5]);});
            arc.setOnMouseExited(e->{arc.setEffect(null);arc.setFill(colors[4]);});

            StackPane icon = getIcon();
            icon.translateXProperty().bind(arc.radiusXProperty().divide(2)/*.subtract(icon.widthProperty().divide(2))*/);
            icon.translateYProperty().bind(icon.heightProperty().divide(2).multiply(-1));
            Group grp = new Group(arc,icon);

            Rotate rotate = new Rotate();
            rotate.setPivotX(0);
            rotate.setPivotY(0);
            rotate.setAngle(i*eachAngle);
            icon.rotateProperty().bind(rotate.angleProperty().multiply(-1).add(pane.rotateProperty().multiply(-1)));
            grp.getTransforms().add(rotate);
            pane.getChildren().add(grp);
        }

        RotateTransition rt = new RotateTransition(Duration.millis(10000), pane);
        rt.setByAngle(360);
        rt.setCycleCount(4);
        rt.setAutoReverse(true);
       // rt.play();
    }

    private StackPane getIcon(){
        StackPane icon = new StackPane();
        icon.setMaxSize(20,20);
        icon.setPrefSize(20,20);
        icon.setStyle("-fx-background-color:#FF000050;-fx-border-width:1px;");
        return icon;
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
