package com.sai.javafx.listview;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

public class ReOrderableListViewDemo extends Application {
    static int c = 0;

    @Override
    public void start(Stage stage) throws Exception {
        VBox root = new VBox();
       root.setSpacing(10);
        root.setPadding(new Insets(15));
        Scene sc = new Scene(root, 600, 800);
        sc.getStylesheets().add("com/thales/javafx/listview/reorderablelistview.css");
        stage.setScene(sc);
        stage.show();

        ObservableList<String> namesList = FXCollections.<String>observableArrayList("Item 0", "Item 1", "Item 2", "Item 3", "Item 4", "Item 5");

        ListView<String> listView = new ListView<>(namesList);
        listView.setCellFactory(new Callback<ListView<String>, ListCell<String>>() {
            @Override
            public ListCell<String> call(ListView<String> param) {
                return new ListCell<String>(){
                    HBox hb = new HBox();
                    StackPane drag = new StackPane();
                    Label label = new Label();
                    {
                        drag.setMaxSize(25,25);
                        drag.setPrefSize(25,25);
                        drag.setStyle("-fx-background-color:grey;");
                        StackPane sp = new StackPane();
                        sp.getChildren().add(label);
                        sp.setAlignment(Pos.CENTER_LEFT);
                        hb.getChildren().addAll(sp,drag);
                        hb.setSpacing(10);
                        hb.setPadding(new Insets(5));
                        hb.setAlignment(Pos.CENTER_LEFT);
                        HBox.setHgrow(sp,Priority.ALWAYS);

                        new ListCellDragHelper().initDrag(this,listView);
                    }
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        label.setText(null);
                        if(item!=null){
                            label.setText(item);
                            setGraphic(hb);
                        }else{
                            setGraphic(null);
                        }
                    }
                };
            }
        });
        root.getChildren().addAll(listView);

    }
}
