package com.sai.javafx.window;

import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

/**
 * Helper class to set the resizing implementation for any given undecorated stage.
 */
public class ResizeHelper {

    /**
     * Handler to process the resizing of the the given stage.
     */
    static class ResizeHandler implements EventHandler<MouseEvent> {

        /** Space to consider around the stage border for resizing */
        private static final double BORDER = 6;

        /** Space to consider the border width factor while resizing */
        private static final double BORDER_WIDTH_FACTOR = 6;

        /** XfeWindow to which the handler is implemented */
        private final Stage xfeStage;

        private final XfeWindow xfeWindow;
        /** Current cursor reference to the scene */
        private Cursor cursor = Cursor.DEFAULT;

        /** X position of the drag start */
        private double startX = 0;

        /** Y position of the drag start */
        private double startY = 0;

        /**
         * Constructor.
         *
         * @param xfeWindow XfeWindow to which resizing to be set.
         */
        ResizeHandler(final XfeWindow xfeWindow) {
            this.xfeWindow = xfeWindow;
            this.xfeStage = xfeWindow.getStage();
        }

        @Override
        public void handle(final MouseEvent event) {
            final EventType<? extends MouseEvent> eventType = event.getEventType();
            final Scene scene = xfeStage.getScene();
            final double mouseEventX = event.getSceneX();
            final double mouseEventY = event.getSceneY();
            final double sceneWidth = scene.getWidth();
            final double sceneHeight = scene.getHeight();
            final boolean isResizable = XfeWindow.WindowState.WINDOWED.equals(xfeWindow.getCurrentWindowState());

            if (isResizable) {
                if (MouseEvent.MOUSE_MOVED.equals(eventType)) {
                    assignCursor(scene, event, mouseEventX, mouseEventY, sceneWidth, sceneHeight);

                } else if (MouseEvent.MOUSE_PRESSED.equals(eventType)) {
                    startX = xfeStage.getWidth() - mouseEventX;
                    startY = xfeStage.getHeight() - mouseEventY;
                    consumeEventIfNotDefaultCursor(event);

                } else if (MouseEvent.MOUSE_DRAGGED.equals(eventType) && !Cursor.DEFAULT.equals(cursor)) {
                    consumeEventIfNotDefaultCursor(event);
                    if (!Cursor.W_RESIZE.equals(cursor) && !Cursor.E_RESIZE.equals(cursor)) {
                        handleHeightResize(event);
                    }

                    if (!Cursor.N_RESIZE.equals(cursor) && !Cursor.S_RESIZE.equals(cursor)) {
                        handleWidthResize(event);
                    }
                }
            }
        }

        /**
         * Determines and sets the appropriate cursor based on the mouse position in relative to scene bounds.
         *
         * @param scene XfeWindow scene
         * @param event MouseEvent instance
         * @param mouseEventX X position of mouse in the scene
         * @param mouseEventY Y position of mouse in the scene
         * @param sceneWidth Width of the scene
         * @param sceneHeight Height of the scene
         */
        private void assignCursor(final Scene scene, final MouseEvent event, final double mouseEventX,
                final double mouseEventY, final double sceneWidth, final double sceneHeight) {
            final Cursor cursor1;
            if (mouseEventX < BORDER && mouseEventY < BORDER) {
                cursor1 = Cursor.NW_RESIZE;
            } else if (mouseEventX < BORDER && mouseEventY > sceneHeight - BORDER) {
                cursor1 = Cursor.SW_RESIZE;
            } else if (mouseEventX > sceneWidth - BORDER
                && mouseEventY < BORDER
                && !xfeWindow.isWindowButtonTarget(event)) {
                cursor1 = Cursor.NE_RESIZE;
            } else if (mouseEventX > sceneWidth - BORDER && mouseEventY > sceneHeight - BORDER) {
                cursor1 = Cursor.SE_RESIZE;
            } else if (mouseEventX < BORDER) {
                cursor1 = Cursor.W_RESIZE;
            } else if (mouseEventX > sceneWidth - BORDER && !xfeWindow.isWindowButtonTarget(event)) {
                cursor1 = Cursor.E_RESIZE;
            } else if (mouseEventY < BORDER && !xfeWindow.isWindowButtonTarget(event)) {
                cursor1 = Cursor.N_RESIZE;
            } else if (mouseEventY > sceneHeight - BORDER) {
                cursor1 = Cursor.S_RESIZE;
            } else {
                cursor1 = Cursor.DEFAULT;
            }
            cursor = cursor1;
            scene.setCursor(cursor);
        }

        /**
         * Consumes the mouse event if the cursor is not the DEFAULT cursor.
         *
         * @param event MouseEvent instance
         */
        private void consumeEventIfNotDefaultCursor(final MouseEvent event) {
            if (!cursor.equals(Cursor.DEFAULT)) {
                event.consume();
            }
        }

        /**
         * Processes the vertical drag movement and resizes the window height.
         *
         * @param event MouseEvent instance
         */
        private void handleHeightResize(final MouseEvent event) {
            final double mouseEventY = event.getSceneY();
            final double computedPrefHeight = xfeStage.getScene().getRoot().prefHeight(Region.USE_COMPUTED_SIZE);
            final double minHeight = computedPrefHeight + BORDER_WIDTH_FACTOR;
            if (Cursor.NW_RESIZE.equals(cursor)
                || Cursor.N_RESIZE.equals(cursor)
                || Cursor.NE_RESIZE.equals(cursor)) {
                if (xfeStage.getHeight() > minHeight || mouseEventY < 0) {
                    final double newHeight = xfeStage.getY() - event.getScreenY() + xfeStage.getHeight();
                    xfeStage.setHeight(max(newHeight, minHeight));
                    xfeStage.setY(event.getScreenY());
                }
            } else if (xfeStage.getHeight() > minHeight || mouseEventY + startY - xfeStage.getHeight() > 0) {
                final double newHeight = mouseEventY + startY;
                xfeStage.setHeight(max(newHeight, minHeight));
            }
        }

        /**
         * Processes the horizontal drag movement and resizes the window width.
         *
         * @param event MouseEvent instance
         */
        private void handleWidthResize(final MouseEvent event) {
            final double mouseEventX = event.getSceneX();
            final double computedPrefWidth = xfeStage.getScene().getRoot().prefWidth(Region.USE_COMPUTED_SIZE);
            final double minWidth = computedPrefWidth + BORDER_WIDTH_FACTOR;
            if (Cursor.NW_RESIZE.equals(cursor)
                || Cursor.W_RESIZE.equals(cursor)
                || Cursor.SW_RESIZE.equals(cursor)) {
                if (xfeStage.getWidth() > minWidth || mouseEventX < 0) {
                    final double newWidth = xfeStage.getX() - event.getScreenX() + xfeStage.getWidth();
                    xfeStage.setWidth(max(newWidth, minWidth));
                    xfeStage.setX(event.getScreenX());
                }
            } else if (xfeStage.getWidth() > minWidth || mouseEventX + startX - xfeStage.getWidth() > 0) {
                final double newWidth = mouseEventX + startX;
                xfeStage.setWidth(max(newWidth, minWidth));
            }
        }

        /**
         * Determines the max value among the provided two values.
         *
         * @param value1 First value
         * @param value2 Second value
         * @return Maximum value of the given two values.
         */
        private double max(final double value1, final double value2) {
            return value1 > value2 ? value1 : value2;
        }
    }

    /** Reference to the earlier handler to remove if required */
    private static ResizeHandler resizeHandler = null;

    /**
     * Constructor.
     *
     */
    private ResizeHelper() {

    }

    /**
     * Handles the resizing feature for the provided {@code XfeWindow} if it is resizable.
     *
     * @param window Instance of {@code XfeWindow}
     * @param isResizable Boolean specifying whether the window is resizable or not
     */
    public static void handleResizeListener(final XfeWindow window, final boolean isResizable) {
        if (isResizable) {
            addResizeHandler(window);
        } else {
            removeResizeHandler(window);
        }
    }

    /**
     * Adds the resize handler to the provided stage.
     *
     * @param window XfeWindow to which the resizing should be implemented
     */
    private static void addResizeHandler(final XfeWindow window) {
        resizeHandler = new ResizeHandler(window);
        window.getStage().getScene().addEventFilter(MouseEvent.ANY, resizeHandler);
    }

    /**
     * Removes the resize handler to the provided stage.
     *
     * @param window XfeWindow from which the resizing should be removed
     */
    private static void removeResizeHandler(final XfeWindow window) {
        if (resizeHandler != null) {
            window.getStage().getScene().addEventFilter(MouseEvent.ANY, resizeHandler);
        }
    }

}
