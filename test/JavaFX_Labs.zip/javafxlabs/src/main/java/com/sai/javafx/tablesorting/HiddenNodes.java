package com.sai.javafx.tablesorting;

import javafx.application.Application;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.*;

public class HiddenNodes extends Application {

    private static final int N_COLS = 3;
    private static final int INIT_N_ROWS = 10;

    private int nextRowId = 0;
    private Node[] lastRemovedRow = null;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        CustomGrid grid = new CustomGrid();
        grid.setGridLinesVisible(true);

        for (int i = 0; i < INIT_N_ROWS; i++) {
            Label[] labels = createRow(grid);
            grid.insertRow(i, labels);
        }

        Button prepend = new Button("Prepend");
        prepend.setOnAction(event -> {
            Label[] labels = createRow(grid);
            grid.insertRow(0, labels);
        });

        Button append = new Button("Append");
        append.setOnAction(event -> {
            Label[] labels = createRow(grid);
            grid.insertRow(grid.getRowsSize(), labels);
        });

        HBox controls = new HBox(10, prepend, append);

        VBox layout = new VBox(10, controls, grid);
        layout.setPadding(new Insets(10));

        stage.setScene(new Scene(layout, 200, 600));
        stage.show();
    }

    private Label[] createRow(CustomGrid grid) {
        Label[] labels = new Label[N_COLS];
        for (int j = 0; j < N_COLS; j++) {
            final int fj = j;
            labels[j] = new Label(nextRowId + ":" + j);
            labels[j].setStyle("-fx-background-color: coral;");
            labels[j].setOnMouseClicked((MouseEvent e) -> {
                lastRemovedRow = grid.removeRowContaining(labels[fj]);
            });
        }

        nextRowId++;

        return labels;
    }

    class CustomGrid extends GridPane {
        private ObservableList<Node[]> rows = FXCollections.observableArrayList();

        CustomGrid() {
            this.setHgap(20);
            this.setVgap(20);

            ColumnConstraints firstColConstraints = new ColumnConstraints();
            firstColConstraints.setHalignment(HPos.RIGHT);
            firstColConstraints.setPercentWidth(50.0);
            firstColConstraints.setHgrow(Priority.ALWAYS);
            ColumnConstraints secondColConstraints = new ColumnConstraints();
            ColumnConstraints thirdColConstraints = new ColumnConstraints();
            thirdColConstraints.setHgrow(Priority.ALWAYS);
            thirdColConstraints.setHalignment(HPos.LEFT);

            this.getColumnConstraints().addAll(firstColConstraints, secondColConstraints, thirdColConstraints);
            VBox.setMargin(this, new Insets(10, 0, 50, 0));
        }

        void insertRow(int rowIdx, Node... nodes) {
            for (int i = rows.size() - 1; i >= rowIdx; i--) {
                for (int j = 0; j < rows.get(i).length; j++) {
                    setConstraints(rows.get(i)[j], j, i + 1);
                }
            }

            addRow(rowIdx, nodes);
            rows.add(rowIdx, nodes);
        }

        private Node[] removeRow(int rowIdx) {
            for (int i = rows.size() - 1; i > rowIdx; i--) {
                for (int j = 0; j < rows.get(i).length; j++) {
                    setConstraints(rows.get(i)[j], j, i - 1);
                }
            }

            for (Node node: rows.get(rowIdx)) {
                getChildren().remove(node);
            }
            return rows.remove(rowIdx);
        }

        Node[] removeRowContaining(Node node) {
            Iterator<Node[]> rowIterator = rows.iterator();
            int rowIdx = 0;
            while (rowIterator.hasNext()) {
                Node[] row = rowIterator.next();
                for (Node searchNode : row) {
                    if (searchNode == node) {
                        return removeRow(rowIdx);
                    }
                }

                rowIdx++;
            }

            return null;
        }

        int getRowsSize() {
            return rows.size();
        }
    }
}