package com.sai.javafx.window;

import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;

public class CustomTextArea extends TextArea {
    private ScrollPane textAreaScrollPane;

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if (textAreaScrollPane == null) {
            textAreaScrollPane = (ScrollPane) lookup(".scroll-pane");
            textAreaScrollPane.focusedProperty().addListener((obs, oldVal, focused) -> {
                if (focused) {
                    requestFocus();
                }
            });
        }
    }
}