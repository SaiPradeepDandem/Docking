package com.sai.javafx.glyph;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import org.controlsfx.glyphfont.FontAwesome;
import org.controlsfx.glyphfont.Glyph;

import java.util.stream.Stream;

public class GlyphTest extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        ScrollPane root = new ScrollPane();
        root.setFitToHeight(true);
        root.setFitToWidth(true);
        Scene sc = new Scene(root, 600, 800);
        stage.setScene(sc);
        stage.show();

        FlowPane fp = new FlowPane();
        fp.setVgap(20);
        fp.setHgap(20);
        fp.prefWidthProperty().bind(root.widthProperty().subtract(20));
        root.setContent(fp);

        Stream.of(FontAwesome.Glyph.values()).forEach(glyph -> {
            Label lbl = new Label();
            Glyph graphic = new Glyph("FontAwesome", glyph.name());
            graphic.setColor(Color.valueOf("#444444"));
            graphic.size(28);
            lbl.setGraphic(graphic);
            lbl.setTooltip(new Tooltip(glyph.name()));
            fp.getChildren().add(lbl);
        });
    }
}
