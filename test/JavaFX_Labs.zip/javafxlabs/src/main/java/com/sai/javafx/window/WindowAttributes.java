package com.sai.javafx.window;

import javafx.geometry.Point2D;

public class WindowAttributes {

    private Point2D defaultPosition;
    private boolean minimisable;
    private boolean maximisable;
    private boolean closable;
    private boolean resizable;

    public Point2D getDefaultPosition() {
        return defaultPosition;
    }

    public void setDefaultPosition(Point2D defaultPosition) {
        this.defaultPosition = defaultPosition;
    }

    public boolean isMinimisable() {
        return minimisable;
    }

    public void setMinimisable(boolean minimisable) {
        this.minimisable = minimisable;
    }

    public boolean isMaximisable() {
        return maximisable;
    }

    public void setMaximisable(boolean maximisable) {
        this.maximisable = maximisable;
    }

    public boolean isClosable() {
        return closable;
    }

    public void setClosable(boolean closable) {
        this.closable = closable;
    }

    public boolean isResizable() {
        return resizable;
    }

    public void setResizable(boolean resizable) {
        this.resizable = resizable;
    }
}
