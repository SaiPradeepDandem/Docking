package com.sai.javafx.window;

import com.nomx.javafxlabs.constants.StyleSheet;
import com.sun.javafx.css.StyleManager;
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class XfeWindowDemo extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        WindowAttributes wa = new WindowAttributes();
        wa.setClosable(true);
        wa.setMaximisable(true);
        wa.setMinimisable(true);
        wa.setResizable(true);

        VBox root =new VBox();
        root.setPrefSize(500,400);
        XfeWindow w = new XfeWindow();
        w.applyTo(primaryStage);
        w.setWindowContent(root);
        w.setWindowAttributes(wa);



        Button show = new Button("Show");
        show.setOnAction(e->{
            //XfeWindow.setWindowOwner(primaryStage);

            StackPane sp = new StackPane();
            sp.setPrefSize(500,400);

            wa.setDefaultPosition(new Point2D(200,200));
            XfeWindow window = new XfeWindow(sp);
            window.setWindowAttributes(wa);
            window.setWindowTitle("Window Demo");
            window.show();


        });
        root.getChildren().add(show);
        Application.setUserAgentStylesheet(null);
        StyleManager.getInstance().addUserAgentStylesheet(StyleSheet.WINDOW.getPath());

        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
