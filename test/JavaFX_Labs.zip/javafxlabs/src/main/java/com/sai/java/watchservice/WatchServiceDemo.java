package com.sai.java.watchservice;

import java.io.IOException;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WatchServiceDemo {
    static String rootPath = "C:\\dev\\Projects\\xfe\\site-icap\\icap-iswapxfe\\";
    //static String rootPath = "C:\\dev\\xfe_css\\xfe\\site-icap\\icap-iswapxfe\\";
    static SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    public static void main(String[] args) throws IOException {
        WatchService watcher = FileSystems.getDefault().newWatchService();
        Path dir = Paths.get(rootPath + "src\\main\\resources\\css");
        dir.register(watcher, StandardWatchEventKinds.ENTRY_MODIFY);

        for (; ; ) {

            // wait for key to be signaled
            WatchKey key;
            try {
                key = watcher.take();
            } catch (InterruptedException x) {
                return;
            }

            for (WatchEvent<?> event : key.pollEvents()) {
                WatchEvent.Kind kind = event.kind();

                if (kind == StandardWatchEventKinds.OVERFLOW) {
                    continue;
                }

                //The filename is the context of the event.
                WatchEvent<Path> ev = (WatchEvent<Path>) event;
                Path filename = ev.context();

                //Verify that the new file is a text file.
                Path child = dir.resolve(filename);
                if (!child.getFileName().toString().endsWith(".css")) {
                    //System.err.format("Modified file '%s' is not a .css file.%n", filename);
                    continue;
                }


                //Email the file to the specified email alias.
                Files.copy(child, Paths.get(rootPath + "target\\classes\\css\\" + child.getFileName().toString()), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                System.out.format(formatter.format(new Date()) + " :: Copied file %s%n", filename);

            }

            //Reset the key -- this step is critical if you want to receive
            //further watch events. If the key is no longer valid, the directory
            //is inaccessible so exit the loop.
            boolean valid = key.reset();
            if (!valid) {
                break;
            }
        }
    }
}
