package com.sai.javafx.listview;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

public class ListView_ScrollTo_Demo extends Application {
    static int c = 0;

    @Override
    public void start(Stage stage) throws Exception {
        VBox root = new VBox();
        root.setSpacing(10);
        root.setPadding(new Insets(15));
        Scene sc = new Scene(root, 600, 800);
        stage.setScene(sc);
        stage.show();

        ObservableList<String> namesList = FXCollections.<String>observableArrayList("Item 0");

        ListView<String> listView = new ListView<>(namesList);
        root.getChildren().addAll(listView);
        listView.scrollTo(0);
        //root.layout();
    }
}
