package com.sai.javafx.tickupdown;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Bounds;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * Util class to perform the tick up down for the given region.
 */
public class TickUpDownUtil {

    public static boolean CLICKED = false;
    private double baseValue;
    private Region region;
    private double step;
    private int size;
    private BiConsumer<Double, Boolean> callBack;

    private BooleanProperty showing = new SimpleBooleanProperty();
    private Timeline hidingTimer = new Timeline();
    private boolean onRegion = false;
    private boolean onPopup = false;
    private DoubleProperty arrowHeight;
    private DoubleProperty boxHeight;

    private List<Label> upLabels;
    private List<Label> downLabels;
    private StackPane upArrowPane;

    private boolean enabled = true;

    public TickUpDownUtil(double baseValue, Region region, double step, int size) {
        this.baseValue = baseValue;
        this.region = region;
        this.step = step;
        this.size = size;
        init();
        updateLabels();
    }

    public double getBaseValue() {
        return baseValue;
    }

    public void setBaseValue(double baseValue) {
        this.baseValue = baseValue;
        updateLabels();
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    public double getStep() {
        return step;
    }

    public void setStep(double step) {
        this.step = step;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setCallBack(BiConsumer<Double, Boolean> callBack) {
        this.callBack = callBack;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    private void init() {
        hidingTimer.getKeyFrames().add(new KeyFrame(new Duration(0)));
        hidingTimer.setOnFinished(event -> {
            if (!onRegion && !onPopup) {
                showing.set(false);
            }
        });

        VBox upBox = new VBox();
        upBox.setOnMouseEntered(e -> {
            onPopup = true;
        });
        upLabels = generateLabels(true);

        VBox downBox = new VBox();
        downBox.setOnMouseEntered(e -> {
            onPopup = true;
        });
        downLabels = generateLabels(false);

        arrowHeight = new SimpleDoubleProperty();
        arrowHeight.bind(region.heightProperty().divide(4).multiply(3));

        boxHeight = new SimpleDoubleProperty();
        boxHeight.bind(region.heightProperty().multiply(size));

        Popup upPop = new Popup();
        Popup downPop = new Popup();

        upArrowPane = new StackPane();
        upArrowPane.prefHeightProperty().bind(arrowHeight);
        upArrowPane.prefWidthProperty().bind(region.widthProperty());
        upArrowPane.getStyleClass().add("tickupdown-arrow-btn-up");
        upArrowPane.getChildren().add(createArrow(false));
        upArrowPane.setOnMouseEntered(e -> {
            onPopup = true;
            showing.set(true);
        });
        upArrowPane.setOnMouseClicked(e -> {
            CLICKED = true;
            if (upBox.getChildren().isEmpty()) {
                upBox.getChildren().addAll(upLabels);
                realignPopup(upPop, upBox, true);
            }
        });

        StackPane downArrowPane = new StackPane();
        downArrowPane.prefHeightProperty().bind(arrowHeight);
        downArrowPane.prefWidthProperty().bind(region.widthProperty());
        downArrowPane.getStyleClass().add("tickupdown-arrow-btn-down");
        downArrowPane.getChildren().add(createArrow(true));
        downArrowPane.setOnMouseEntered(e -> {
            onPopup = true;
            showing.set(true);
        });
        downArrowPane.setOnMouseClicked(e -> {
            if (downBox.getChildren().isEmpty()) {
                downBox.getChildren().addAll(downLabels);
                realignPopup(downPop, downBox, false);
            }
        });

        VBox upPane = new VBox();
        upPane.getChildren().addAll(upArrowPane, upBox);
        upPane.setOnMouseEntered(e -> {
            onPopup = true;
        });
        upPane.setOnMouseExited(e -> {
            if (!CLICKED) {
                onPopup = false;
                if (!onRegion) {
                    hidingTimer.playFromStart();
                } else {
                    upBox.getChildren().clear();
                    realignPopup(upPop, upBox, true);
                }
            }
            CLICKED = false;
        });

        VBox downPane = new VBox();
        downPane.getChildren().addAll(downBox, downArrowPane);
        downPane.setOnMouseEntered(e -> showing.set(true));
        downPane.setOnMouseEntered(e -> {
            onPopup = true;
        });
        downPane.setOnMouseExited(e -> {
            onPopup = false;
            if (!onRegion) {
                hidingTimer.playFromStart();
            } else {
                downBox.getChildren().clear();
                realignPopup(downPop, downBox, false);
            }
        });

        upPop.getContent().add(upPane);

        downPop.getContent().add(downPane);

        showing.addListener((obs, oldVal, show) -> {
            if (show) {
                realignPopup(upPop, upBox, true);
                realignPopup(downPop, downBox, false);
            } else {
                upBox.getChildren().clear();
                upPop.hide();
                downBox.getChildren().clear();
                downPop.hide();
            }
        });
        region.setOnMouseEntered(e -> {
            if (enabled && !CLICKED) {
                onRegion = true;
                showing.set(true);
            }
        });
        region.setOnMouseExited(e -> {
            if(enabled) {
                onRegion = false;
                hidingTimer.playFromStart();
            }
        });

    }

    private void realignPopup(Popup popup, VBox box, boolean isUp) {
        Bounds bounds = region.localToScreen(region.getBoundsInLocal());
        double x = bounds.getMinX();
        double y = bounds.getMinY();
        if (isUp) {
            double hgt = arrowHeight.get();
            if (popup.isShowing()) {
                if (!box.getChildren().isEmpty()) {
                    hgt = hgt + boxHeight.get();
                }
                popup.show(region, x, y - hgt);
            } else {
                popup.show(region, x, y - hgt);
            }
        } else {
            if (!popup.isShowing()) {
                popup.show(region, x, y +bounds.getHeight());
            }
        }
        setBaseValue(baseValue);

    }

    private List<Label> generateLabels(boolean isTickUp) {
        List<Label> labels = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            Label label = new Label("A");
            label.prefWidthProperty().bind(region.widthProperty());
            label.prefHeightProperty().bind(region.heightProperty());
            label.getStyleClass().add("tickupdown-option-label");
            label.setOnMouseEntered(e -> {
                onPopup = true;
            });
            label.setOnMouseClicked(e -> {
                if (callBack != null) {
                    double val = Double.parseDouble(label.getText());
                    callBack.accept(val, isTickUp);
                }
                //onPopup = false;
                //hidingTimer.playFromStart();
            });
            labels.add(label);
        }
        return labels;
    }

    private StackPane createArrow(boolean isDown) {
        final StackPane arrow = new StackPane();
        arrow.maxHeightProperty().bind(region.heightProperty().divide(3.5));
        arrow.maxWidthProperty().bind(arrow.maxHeightProperty());
        arrow.getStyleClass().add(isDown ? "tickupdown-arrow-down" : "tickupdown-arrow-up");
        return arrow;
    }

    private void updateLabels() {
        System.out.println("Updating labels....");
        double start = baseValue;
        for (int i = size - 1; i > -1; i--) {
            start = start + step;
            upLabels.get(i).setText(start + "");
        }

        start = baseValue;
        for (Label downLabel : downLabels) {
            start = start - step;
            downLabel.setText(start + "");
        }
    }
}
