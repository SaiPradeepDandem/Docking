package com.sai.java.watchservice;

public class StringDemo {
    public static void main(String... a){
        String v = "Hellow\nDude";
        System.out.println(v);
    }
}
