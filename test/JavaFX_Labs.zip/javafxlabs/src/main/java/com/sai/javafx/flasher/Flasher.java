package com.sai.javafx.flasher;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.css.PseudoClass;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Helper class to toggle the provided CSS variable with given values, which will eventually gives the effect of flashing.
 */
public final class Flasher {

    /**
     * Registers the stage and its root node for updating the css variables.
     *
     * @param stage Stage to be registered
     */
    public static void register(Stage stage) {
        if (stagesMap.get(stage) == null) {
            Platform.runLater(() -> {
                final Node rootNode = stage.getScene().lookup(".root");
                if (rootNode != null) {
                    stagesMap.put(stage, rootNode);
                }
            });
        }
    }

    /**
     * Unregister the provided stage from the flashing effect.
     *
     * @param stage Stage to be unregistered
     */
    public static void unregister(Stage stage) {
        stagesMap.remove(stage);
    }

    public static void addFlasher(String id){
        flashers.add(id);
        if(!flashers.isEmpty() && getTimeline().getStatus() != Animation.Status.RUNNING){
            getTimeline().playFromStart();
        }
    }

    public static void removeFlasher(String id){
        flashers.remove(id);
        if(flashers.isEmpty()){
            getTimeline().stop();
        }
    }


    /**
     * Starts the indefinite Timeline for flashing.
     */
    private static Timeline getTimeline() {
        if (timeline == null) {
            timeline = new Timeline(
                    new KeyFrame(Duration.seconds(0.5), e -> addFlash()),
                    new KeyFrame(Duration.seconds(1.0), e -> removeFlash()));
            timeline.setCycleCount(Animation.INDEFINITE);
        }
        return timeline;
    }

    /**
     * Sets the default values to the registered CSS variables in all stages root nodes.
     */
    private static void removeFlash() {
        stagesMap.forEach((stage, rootNode) -> {
            cssStyle.setLength(0);
            FLASH_STYLES_MAP.forEach((k, v) -> cssStyle.append(k).append(":").append(v.defaultCss).append(";"));
            rootNode.setStyle(cssStyle.toString());
        });

    }

    /**
     * Sets the flash values to the registered CSS variables in all stages root nodes.
     */
    private static void addFlash() {
        stagesMap.forEach((stage, rootNode) -> {
            cssStyle.setLength(0);
            FLASH_STYLES_MAP.forEach((k, v) -> cssStyle.append(k).append(":").append(v.flashCss).append(";"));
            rootNode.setStyle(cssStyle.toString());
        });
    }

    /**
     * The data object of the flash styles.
     */
    static class FlashStyle {
        private final String defaultCss;
        private final String flashCss;

        public FlashStyle(String defaultCss, String flashCss) {
            this.defaultCss = defaultCss;
            this.flashCss = flashCss;
        }
    }

    public static final PseudoClass PSEUDO_CLASS_FLASH = PseudoClass.getPseudoClass("flash");
    private static final Map<String, FlashStyle> FLASH_STYLES_MAP = new HashMap<>();
    private static final Map<Stage, Node> stagesMap = new HashMap<>();
    private static final Set<String> flashers = new HashSet<>();
    private static StringBuilder cssStyle = new StringBuilder();
    private static Timeline timeline;

    /**
     * Registering all the CSS variables with there alternate values that need to be toggled.
     */
    static {
        FLASH_STYLES_MAP.put("-fx-my-row-flash", new Flasher.FlashStyle("-fx-my-row-default", "-fx-my-green"));
        FLASH_STYLES_MAP.put("-fx-first-name-flash", new Flasher.FlashStyle("transparent", "red"));
        FLASH_STYLES_MAP.put("-fx-last-name-flash", new Flasher.FlashStyle("#FFC0CB", "#00FF00"));
    }

}
