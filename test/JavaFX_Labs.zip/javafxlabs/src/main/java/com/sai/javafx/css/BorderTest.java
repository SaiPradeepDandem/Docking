package com.sai.javafx.css;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class BorderTest extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        StackPane root = new StackPane();
        root.setMinSize(200,200);
        root.setMaxSize(200,200);
        root.setPadding(new Insets(15));
        Scene sc = new Scene(new StackPane(root), 600, 800);
        stage.setScene(sc);
        stage.show();
        String border = "-fx-border-width: 0 0px 18px 0;"+
                "-fx-border-insets:0,0 0 2 0;"+
                "-fx-border-color:red, blue;";
        root.setStyle("-fx-background-color:yellow;"+border);
    }
}
