package com.sai.javafx.overflow;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SliderDemo extends Application {

    public static void main(String... args){
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        Label label = new Label();
        label.setStyle("-fx-font-size:30px");

        Slider slider = new Slider(5,240,5);
        slider.setBlockIncrement(10);
        slider.setMajorTickUnit(10);
        slider.setMinorTickCount(0);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setSnapToTicks(true);

        //slider.valueProperty().addListener((obs,old,val)->label.setText((int)Math.round(val.doubleValue())+""));

        final ChangeListener<Number> numberChangeListener = (obs, old, val) -> {
            final double roundedValue = Math.floor(val.doubleValue() / 10.0) * 10.0 +5;
            slider.valueProperty().set(roundedValue);
            label.setText(Double.toString(roundedValue));
        };

        slider.valueProperty().addListener(numberChangeListener);
        VBox root = new VBox(slider,label);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.setSpacing(20);

        Scene scene = new Scene(root,600,200);
        stage.setScene(scene);
        stage.show();
    }
}