package com.sai.javafx.flasher;

import com.sai.controlsfx.popover.Person;
import com.sun.javafx.css.StyleManager;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.Duration;
import org.scenicview.ScenicView;
import xfe.ui.popup.PopUpManager;
import xfe.ui.popup.PopUpStage;

import java.util.HashMap;
import java.util.Map;

public class NormalFlasherDemo extends Application implements PopUpManager {

    ObservableList<Person> list = FXCollections.observableArrayList();
    private Duration flashDuration = Duration.seconds(30);

    public static Stage stage;
    public static Scene scene;
    protected StackPane root;

    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        root = new StackPane();
        root.setPadding(new Insets(15));
        Button showPopUp = new Button("Show Pop up");
        showPopUp.setOnAction(e -> showPopUp());


        VBox vb = new VBox();
        vb.setSpacing(10);
        vb.getChildren().addAll(showPopUp, new Container(), getTable());

        root.getChildren().add(vb);
        scene = new Scene(root, 700, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Flasher Demo");
        primaryStage.show();
        Application.setUserAgentStylesheet(null);
        StyleManager.getInstance().addUserAgentStylesheet("/css/flasher.css");

        Flasher.register(stage);
        ScenicView.show(scene);
    }

    private void showPopUp() {
        VBox rootPane = new VBox();
        rootPane.setPrefSize(500, 400);
        rootPane.getStyleClass().add("pop-up");
        rootPane.getChildren().addAll(new Container());

        PopUpStage stg = new PopUpStage(stage, this, rootPane, "Popup");
        stg.initOwner(stage);
        stg.showStage();
    }

    private TableView<Person> getTable() {
        for (int i = 1; i < 100; i++) {
            list.add(new Person("John " + i, "Dep " + i, 40));
            list.add(new Person("Sandeep " + i, "Chowtha " + i, 56));
            list.add(new Person("Naridu " + i, "GBaridu " + i, 60));
        }

        TableView<Person> tv = new TableView<>();
        TableColumn<Person, String> fc = new TableColumn<>("First Name");
        fc.setCellValueFactory(new PropertyValueFactory<Person, String>("firstName"));
        fc.setCellFactory(new Callback<TableColumn<Person, String>, TableCell<Person, String>>() {
            @Override
            public TableCell<Person, String> call(TableColumn<Person, String> param) {

                return new TableCell<Person, String>() {
                    {
                        getStyleClass().add("first-name-table-cell");
                    }

                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        getStyleClass().remove("first-name-flash-cell");
                        if (item != null && !empty) {
                            if(item.endsWith("0")) {
                               // pseudoClassStateChanged(Flasher.PSEUDO_CLASS_FLASH,true);
                                        getStyleClass().add("first-name-flash-cell");
                            }
                            setText(item);
                        } else {
                            setText(null);
                        }
                    }
                };
            }
        });
        TableColumn<Person, String> lc = new TableColumn<>("Last Name");
        lc.setCellValueFactory(new PropertyValueFactory<Person, String>("lastName"));
        lc.setCellFactory(new Callback<TableColumn<Person, String>, TableCell<Person, String>>() {
            @Override
            public TableCell<Person, String> call(TableColumn<Person, String> param) {

                return new TableCell<Person, String>() {
                    {
                        getStyleClass().add("last-name-table-cell");
                    }

                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        getStyleClass().remove("last-name-flash-cell");
                        if (item != null && !empty) {
                            if(item.endsWith("1")) {
                                getStyleClass().add("last-name-flash-cell");
                            }
                            setText(item);
                        } else {
                            setText(null);
                        }
                    }
                };
            }
        });

        TableColumn<Person, String> ac = new TableColumn<>("Age");
        ac.setCellValueFactory(new PropertyValueFactory<Person, String>("age"));

        tv.getColumns().addAll(fc, lc, ac);
        tv.setItems(list);
        return tv;
    }

    @Override
    public void register(String id, PopUpStage window) {
        Flasher.register(window);
    }

    @Override
    public void unregister(String id, PopUpStage window) {
        Flasher.unregister(window);
    }

    class Container extends VBox {
        private Map<String, Row> rowMap = new HashMap<>();

        public Container() {
            setSpacing(10);
            HBox btns = new HBox();
            btns.setSpacing(10);
            btns.getChildren().addAll(createButton("Row 1"), createButton("Row 2"), createButton("Row 3"), createButton("Row 4"), createButton("Row 5"));
            getChildren().add(btns);
        }

        private Button createButton(String title) {
            Button button = new Button(title);
            button.setOnAction(e -> {
                Row row;
                if (!rowMap.keySet().contains(title)) {
                    row = new Row(title);
                    getChildren().add(row);
                    rowMap.put(title, row);
                } else {
                    row = rowMap.get(title);
                    row.update();
                }
                row.getStyleClass().add("row-flash-cell");
                Timeline tl = new Timeline(new KeyFrame(Duration.ZERO, null), new KeyFrame(flashDuration, null));
                tl.setOnFinished(ex -> row.getStyleClass().remove("row-flash-cell"));
                tl.play();
            });
            return button;
        }
    }

    class Row extends StackPane {
        Label lbl = new Label();

        public Row(String title) {
            getStyleClass().add("my-row");
            setPrefHeight(30);
            setPadding(new Insets(5));
            setAlignment(Pos.CENTER_LEFT);
            lbl.setText(title);
            getChildren().add(lbl);
        }

        private void update() {
            lbl.setText(lbl.getText() + " +");
        }
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
