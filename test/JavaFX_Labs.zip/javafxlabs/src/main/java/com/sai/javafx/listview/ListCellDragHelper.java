package com.sai.javafx.listview;

import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Utility class to enable the cell reordering in a listView.
 */
public class ListCellDragHelper {

    private double dragStartY;
    private double dragStartSceneY;
    private double dragContentHeight;
    private Object draggedItem;
    private boolean dragDetected = false;

    /**
     * Initialises the drag feature on the provided listCell. Cells can be ordered by dragging the ListCell.
     * @param listCell ListCell of the listView
     * @param listView ListView
     */
    public void initDrag(ListCell listCell, ListView listView) {
        initDrag(null, listCell, listView);
    }

    /**
     * Initialises the drag feature on the provided target node. Cells can be ordered only by dragging the provided target drag node.
     * @param targetDragNode Target drag node
     * @param listCell ListCell of the listView
     * @param listView ListView
     */
    public void initDrag(Node targetDragNode, ListCell listCell, ListView listView) {

        Group dp = (Group) listView.getProperties().get("DRAG-PANE");
        if (dp == null) {
            dp = new Group();
            dp.setMouseTransparent(true);
            dp.setVisible(false);
            listView.getProperties().put("DRAG-PANE", dp);
        }
        Group dragPane = dp;
        Node dragNode = listCell;
        dragNode.setOnDragDetected(e -> {
            if (targetDragNode != null && e.getTarget() != targetDragNode) {
                return;
            }
            dragDetected = true;
            enableAllCells(listCell);

            final ImageView dragRow = new ImageView(listCell.snapshot(null, null));
            dragPane.getChildren().add(dragRow);
            dragPane.setVisible(true);
            ((Group) listCell.getParent()).getChildren().remove(dragPane);
            ((Group) listCell.getParent()).getChildren().add(dragPane);

            draggedItem = listCell.getItem();
            listView.getSelectionModel().clearSelection();
            final Bounds bounds = listView.sceneToLocal(listCell.localToScene(listCell.getBoundsInLocal()));
            dragStartY = bounds.getMinY() + listView.snappedTopInset() + listView.snappedBottomInset();
            dragStartSceneY = e.getSceneY();
            dragContentHeight = bounds.getHeight();
            dragPane.setTranslateY(dragStartY);
        });

        dragNode.setOnMouseReleased(e -> {
            if (!dragDetected) {
                return;
            }
            dragPane.setVisible(false);
            dragPane.getChildren().clear();
            ((Group) listCell.getParent()).getChildren().remove(dragPane);
            dragDetected = false;

            List<ListCell> cells = listCell.getListView().lookupAll(".list-cell").stream().map(node -> (ListCell) node).collect(Collectors.toList());
            for (ListCell cell : cells) {
                cell.setOpacity(1);
            }
            listView.getSelectionModel().select(draggedItem);
        });

        dragNode.setOnMouseDragged(e -> {
            if (!dragDetected) {
                return;
            }
            double ty = dragStartY + (e.getSceneY() - dragStartSceneY);
            final double topOffset = listView.snappedTopInset();
            Bounds lastCellBounds = listCell.getListView().lookupAll(".list-cell").stream().map(node -> (ListCell) node)
                    .filter(lc -> lc.getItem() != null)
                    .filter(lc -> listView.getItems().indexOf(lc.getItem()) == listView.getItems().size() - 1)
                    .findFirst().map(lc -> listView.sceneToLocal(lc.localToScene(lc.getBoundsInLocal()))).get();

            final double bottomOffset = listView.getHeight() - listView.snappedBottomInset() - dragContentHeight;
            if (ty > lastCellBounds.getMinY() && lastCellBounds.getMinY() < bottomOffset) {
                ty = lastCellBounds.getMinY();
            } else if (ty > bottomOffset) {
                ty = bottomOffset;
            } else if (ty < topOffset) {
                ty = topOffset;
            }
            dragPane.setTranslateY(ty);

            double ty1 = ty;
            double border = listView.getBorder() != null ? listView.getBorder().getInsets().getTop() : 0;
            final double buff =
                    border + listView.snappedTopInset() + listView.snappedBottomInset();
            listView.lookupAll(".list-cell").stream().map(node -> (ListCell) node).filter(cell -> cell.getItem() != null)
                    .forEach(cell -> {
                        final Bounds cellBounds = listView.sceneToLocal(cell.localToScene(cell.getBoundsInLocal()));
                        final double cellMinY = cellBounds.getMinY() - buff;
                        final double cellMaxY = cellBounds.getMaxY() - buff;
                        if (cellMinY <= ty1 && ty1 <= cellMaxY) {
                            int cellIndex = cell.getIndex();
                            if (cellIndex == 0 && ty1 > cellMinY + cell.getHeight() / 2) {
                                cellIndex = 1;
                            }
                            int dragItemIndex = listView.getItems().indexOf(draggedItem);
                            if (dragItemIndex != cellIndex) {
                                listView.getItems().remove(draggedItem);
                                listView.getItems().add(cellIndex, draggedItem);
                            }
                        }
                    });

            List<ListCell> cells = listView.lookupAll(".list-cell").stream().map(node -> (ListCell) node).collect(Collectors.toList());
            for (ListCell cell : cells) {
                cell.setOpacity(1);
                if (cell.getItem() != null && cell.getItem() == draggedItem) {
                    cell.setOpacity(0);
                }
            }
        });
    }

    private void enableAllCells(ListCell listCell) {
        List<ListCell> cells = listCell.getListView().lookupAll(".list-cell").stream().map(node -> (ListCell) node).collect(Collectors.toList());
        for (ListCell cell : cells) {
            cell.setOpacity(1);
        }
    }
}
