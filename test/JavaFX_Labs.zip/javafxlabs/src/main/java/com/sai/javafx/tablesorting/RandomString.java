package com.sai.javafx.tablesorting;

import java.security.SecureRandom;

public class RandomString {
    public static void main(String[] args) {
        System.out.println(randomString(5));
    }

    static SecureRandom rnd = new SecureRandom();

    static String randomString( int len ){
        StringBuilder sb = new StringBuilder( len );
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String nums = "0123456789";
        for( int i = 0; i < 2; i++ ) {
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        }
        for( int i = 0; i < 3; i++ ) {
            sb.append(nums.charAt(rnd.nextInt(nums.length())));
        }
        return sb.toString();
    }
}
