package com.sai.javafx.overflow;

import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class TaskDemo extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        StackPane root = new StackPane();
        Button addBtn = new Button("Add");
        root.getChildren().add(addBtn);

        Scene scene = new Scene(root,500,500);
        primaryStage.setScene(scene);
        primaryStage.show();

        addBtn.setOnAction(e->{
            DatabaseTask<String> task = new DatabaseTask<>(new DatabaseOperation<String>() {
                @Override
                public String perform(String session) {
                    System.out.println("Now performing db operation..");
                    return "Success";
                }
            });

            task.setOnSucceeded(e1-> System.out.println("User added successfully"));
            new Thread(task).start();
        });
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    class DatabaseTask<T> extends Task<T>{
        private DatabaseOperation<T> databaseOperation;

        public DatabaseTask(DatabaseOperation<T> databaseOperation){
            if(databaseOperation==null){
                throw new IllegalArgumentException("Exception");
            }
            this.databaseOperation = databaseOperation;
        }
        @Override
        protected T call() throws Exception {
            System.out.println("Task started");
            return databaseOperation.perform("X");
        }
    }

    interface DatabaseOperation<T>{
        public T perform(String session);
    }
}
