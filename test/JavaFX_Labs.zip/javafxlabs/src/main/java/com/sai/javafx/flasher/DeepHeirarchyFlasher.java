package com.sai.javafx.flasher;

import com.sun.javafx.css.StyleManager;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class DeepHeirarchyFlasher extends Application {

    public static Stage stage;
    public static Scene scene;
    protected StackPane root;

    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        root = new StackPane();
        root.setPadding(new Insets(15));

        StackPane parent =root;
        for(int i=0;i<300;i++){
            StackPane c = new StackPane();
            c.setPadding(new Insets(2));
            if(i%2==0){
                c.setStyle("-fx-background-color:-fx-last-name-flash;");
            }else{
                c.setStyle("-fx-background-color:white;");
            }
            //c.getChildren().add(new Label("hello"));
            parent.getChildren().add(c);
            parent = c;
            System.out.println(i);
        }
        scene = new Scene(root, 700, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Flasher Demo");
        primaryStage.show();
        Application.setUserAgentStylesheet(null);
        StyleManager.getInstance().addUserAgentStylesheet("/css/flasher.css");

        Flasher.register(stage);
    }
}
