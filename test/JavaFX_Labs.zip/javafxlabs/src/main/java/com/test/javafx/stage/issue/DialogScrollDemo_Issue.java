package com.test.javafx.stage.issue;

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class DialogScrollDemo_Issue extends Application {

    private final SecureRandom rnd = new SecureRandom();

    @Override
    public void start(Stage stage) throws Exception {
        VBox root = new VBox(buildScrollPane());
        root.setStyle("-fx-background-color:#888888;");
        root.setSpacing(10);
        root.setPadding(new Insets(10));
        Scene sc = new Scene(root, 600, 600);
        stage.setScene(sc);
        stage.show();
        NonFocusPopupStageFactory.init(stage);

        Button normal = new Button("Open UnManaged Normal Stage");
        normal.setOnAction(e -> {
            Stage stg = new Stage();
            StackPane pane = new StackPane(new Label("Stage"), buildScrollPane());
            Scene subScene = new Scene(pane, 200, 200);
            stg.setScene(subScene);
            stg.focusedProperty().addListener((obs, old, focused) -> {
                if (NonFocusPopupStageFactory.INSTANCE != null) {
                    NonFocusPopupStageFactory.INSTANCE.setAlwaysOnTop(focused);
                }
            });
            stg.show();
        });

        Button popup = new Button("Open Managed Popup Stage");
        popup.setOnAction(e -> {
            Label txt = new Label("I stay always on top !! You can drag me !!");
            Label close = new Label("X");
            close.setStyle("-fx-font-weight:bold;-fx-font-size:22;");
            StackPane.setAlignment(close, Pos.TOP_RIGHT);
            StackPane sp = new StackPane(txt, close);
            sp.setStyle("-fx-background-color:black,yellow;-fx-background-insets:0,2;");
            sp.setPrefSize(300, 300);
            sp.setMaxSize(300, 300);
            NonFocusPopupStage customStage = NonFocusPopupStageFactory.INSTANCE.createStage();
            customStage.setRoot(sp);
            customStage.setX(300);
            customStage.setY(200);
            customStage.show();
            close.setOnMouseClicked(e1 -> customStage.hide());

        });

        root.getChildren().addAll(new Separator(), normal, new Separator(), popup);
    }

    private ScrollPane buildScrollPane() {
        VBox vp = new VBox();
        IntStream.range(0, 100).forEach(i -> vp.getChildren().add(new Label(i + "")));
        ScrollPane scroll = new ScrollPane();
        scroll.setContent(vp);
        scroll.setMinHeight(150);
        scroll.setMaxHeight(150);
        return scroll;
    }
}

class NonFocusPopupStageFactory extends Stage {
    public static NonFocusPopupStageFactory INSTANCE;
    private static Pane root;
    private List<NonFocusPopupStage> stages = new ArrayList<>();

    private NonFocusPopupStageFactory() {
        // Private constructor
    }

    public static void init(Window owner) {
        if (INSTANCE != null) {
            throw new IllegalStateException("Cannot create instance as it is already created");
        }
        NonFocusPopupStageFactory stageFactory = new NonFocusPopupStageFactory();
        stageFactory.initOwner(owner);
        stageFactory.initStyle(StageStyle.TRANSPARENT);

        root = new Pane();
        Pane mainRoot = new Pane(root);
        mainRoot.setStyle("-fx-background-color:transparent;");
        stageFactory.setScene(new Scene(mainRoot, Color.TRANSPARENT));
        determineStageSize(stageFactory, root);
        stageFactory.show();
        INSTANCE = stageFactory;
    }

    private static void determineStageSize(Stage stage, Node root) {
        DoubleProperty width = new SimpleDoubleProperty();
        DoubleProperty height = new SimpleDoubleProperty();
        DoubleProperty shift = new SimpleDoubleProperty();
        Screen.getScreens().forEach(screen -> {
            Rectangle2D bounds = screen.getVisualBounds();
            width.set(width.get() + bounds.getWidth());

            if (bounds.getHeight() > height.get()) {
                height.set(bounds.getHeight());
            }
            if (bounds.getMinX() < shift.get()) {
                shift.set(bounds.getMinX());
            }
        });
        stage.setX(shift.get());
        stage.setY(0);
        stage.setWidth(width.get());
        stage.setHeight(height.get());
        root.setTranslateX(-1 * shift.get());
    }

    public NonFocusPopupStage createStage() {
        NonFocusPopupStage stage = new NonFocusPopupStage(root);
        stages.add(stage);
        return stage;
    }
}

class NonFocusPopupStage extends Group {

    private Pane parent;
    double sceneX, sceneY, layoutX, layoutY;

    public NonFocusPopupStage(Pane parent) {
        this.parent = parent;
        addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
            // Making to visible on top
            parent.getChildren().remove(this);
            parent.getChildren().add(this);
        });

        setOnMousePressed(e -> {
            setCache(true);
            sceneX = e.getSceneX();
            sceneY = e.getSceneY();
            layoutX = getLayoutX();
            layoutY = getLayoutY();
        });
        setOnMouseDragged(e -> {
            double offsetX = e.getSceneX() - sceneX;
            double offsetY = e.getSceneY() - sceneY;
            setTranslateX(offsetX);
            setTranslateY(offsetY);
        });
        setOnMouseReleased(e -> {
            setCache(false);
            // Updating the new layout positions
            setLayoutX(layoutX + getTranslateX());
            setLayoutY(layoutY + getTranslateY());

            // Resetting the translate positions
            setTranslateX(0);
            setTranslateY(0);
        });
    }

    public void setX(double x) {
        setLayoutX(x);
    }

    public void setY(double y) {
        setLayoutY(y);
    }

    public void show() {
        if (!parent.getChildren().contains(this)) {
            parent.getChildren().add(this);
        }
    }

    public void hide() {
        parent.getChildren().remove(this);
    }

    public void setRoot(Node rootNode) {
        getChildren().add(rootNode);
    }
}
