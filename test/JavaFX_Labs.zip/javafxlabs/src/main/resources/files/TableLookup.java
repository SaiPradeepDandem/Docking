package files;

import static javafx.scene.AccessibleAttribute.COLUMN_INDEX;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.sun.javafx.scene.control.skin.TableColumnHeader;

import javafx.scene.AccessibleAttribute;
import javafx.scene.Node;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;

/**
 * Methods for navigating around tables.
 */
public final class TableLookup {

   /**
    * Constructor.
    */
   private TableLookup() {
      /* Empty. */
   }

   /**
    * Finds the cell at the specified position in a table.
    *
    * @param <T>   the table type
    * @param i     the row index
    * @param j     the column index
    * @param table the table
    * @return the cell at the given index
    */
   public static <T extends TableView> Optional<TableCell> cell(final int i, final int j, final T table) {
      return Optional.of((TableCell) table.queryAccessibleAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, i, j));
   }

   /**
    * Finds the cell in the given row in the column with the given header.
    *
    * @param <T>    the table type
    * @param i      row index
    * @param column title of the column which should contain value
    * @param table  table to search
    * @return index of the row with value at column
    */
   public static <T extends TableView> Optional<TableCell> cellInColumn(final int i, final String column, final T table) {
      return columnIndex(column, table).flatMap(j -> cell(i, j, table));
   }

   /**
    * Finds the cell in the given row in the column with the given header id.
    *
    * @param <T>      the table type
    * @param rowIndex row index
    * @param columnId id of the column which should contain value
    * @param table    table to search
    * @return index of the row with value at column
    */
   public static <T extends TableView> Optional<TableCell> cellInColumnId(final int rowIndex, final String columnId, final T table) {
      Function<Integer, TableCell> tableCell = index -> cell(rowIndex, index, table).get();
      return columnIdIndex(columnId, table).map(tableCell);
   }

   /**
    * Returns the text for a cell in a table.
    *
    * @param <T>   the table type
    * @param i     row index of cell
    * @param j     column index of cell
    * @param table table
    * @return cell text
    */
   public static <T extends TableView> Optional<String> cellText(final int i, final int j, final T table) {
      return cell(i, j, table).flatMap(TableLookup::cellText);
   }

   /**
    * Returns the text of the first {@link Text} node in a cell.
    *
    * @param c cell to search
    * @return text of the first text node
    */
   public static Optional<String> cellText(final TableCell c) {
      return Nodes.allVisibleChildren(c).stream().map(Nodes.filterClass(Text.class)).filter(Nodes.nonNull())
         .findFirst()
         .flatMap(t -> Optional.of(t.getText()));
   }

   /**
    * Finds the index of the column with given id in a table.
    *
    * @param <T>   the table type
    * @param id    column title for which to search
    * @param table table to search
    * @return index of the column
    */
   public static <T extends TableView> Optional<Integer> columnIdIndex(final String id, final T table) {
      return optIndexOf(headers(table).stream().map(Node::getId).collect(Collectors.toList()), id);
   }

   /**
    * Finds the index of the column with given title in a table.
    *
    * @param <T>   the table type
    * @param title column title for which to search
    * @param table table to search
    * @return index of the column
    */
   public static <T extends TableView> Optional<Integer> columnIndex(final String title, final T table) {
      return optIndexOf(headerStrings(table), title);
   }

   /**
    * Headers of a table.
    *
    * @param <T>   the table type
    * @param table table for which to get headers
    * @return stream of header texts
    */
   public static <T extends TableView> List<TableColumnHeader> headers(final T table) {
      return Nodes.allVisibleChildren(table).stream().map(Nodes.filterInstance(TableColumnHeader.class))
         .filter(Nodes.nonNull()).collect(Collectors.toList());
   }

   /**
    * Finds the text of the column headers in a table.
    *
    * @param <T>   the table type
    * @param table table for which to get headers
    * @return column headers in order
    */
   public static <T extends TableView> List<String> headerStrings(final T table) {
      return headerTexts(table).stream().map(Text::getText).collect(Collectors.toList());
   }

   /**
    * Texts in headers of a table.
    *
    * @param <T>   the table type
    * @param table table for which to get headers
    * @return stream of header texts
    */
   public static <T extends TableView> List<Text> headerTexts(final T table) {
      return headers(table).stream().flatMap(header -> Nodes.allVisibleChildren(header).stream())
         .map(Nodes.filterClass(Text.class)).filter(Nodes.nonNull()).collect(Collectors.toList());
   }

   /**
    * Get the row at a specified index in a table.
    *
    * @param <T>   the table type
    * @param i     row index
    * @param table table to search
    * @return row at index or nothing
    */
   public static <T extends TableView> Optional<TableRow> row(final int i, final T table) {
      return Nodes
         .allVisibleChildren(table).stream()
         .map(Nodes.filterClass(TableRow.class))
         .filter(Nodes.nonNull())
         .filter(byRowRow(i))
         .findFirst();
   }

   /**
    * Finds the index of the first row which contains the given value at the given column, or nothing, if it
    * doesn't exist.
    *
    * @param <T>   the table type
    * @param value value to search for
    * @param j     column which should contain value
    * @param table table to search
    * @return index of the row with value at column
    */
   public static <T extends TableView> Optional<Integer> rowWithValueAtColumn(final String value, final int j, final T table) {
      return Nodes
         .allVisibleChildren(table)
         .stream()
         .map(Nodes.filterClass(TableCell.class))
         .filter(Nodes.nonNull())
         .filter(c -> Nodes.allVisible(c).stream().anyMatch(Nodes.withText(value)))
         .filter(byCellColumn(j))
         .findFirst()
         .map(c -> (int) c.queryAccessibleAttribute(AccessibleAttribute.ROW_INDEX));
   }

   /**
    * Finds the index of the first row which contains the given value at the given column, or nothing, if it
    * doesn't exist.
    *
    * @param <T>    the table type
    * @param value  value to search for
    * @param column title of the column which should contain value
    * @param table  table to search
    * @return index of the row with value at column
    */
   public static <T extends TableView> Optional<Integer> rowWithValueAtColumn(final String value,
                                                                              final String column, final T table) {
      return columnIndex(column, table).flatMap(j -> Nodes
         .allVisibleChildren(table)
         .stream()
         .map(Nodes.filterClass(TableCell.class))
         .filter(Nodes.nonNull())
         .filter(Nodes.filterByChildren(Nodes.withText(value)))
         .filter(byCellColumn(j))
         .findFirst()
         .map(c -> (int) c.queryAccessibleAttribute(AccessibleAttribute.ROW_INDEX)));
   }

   /**
    * Return a predicate that a cell is a specific column index.
    *
    * @param j the column index
    * @return the predicate
    */
   private static Predicate<TableCell> byCellColumn(final int j) {
      return cell -> (int) cell.queryAccessibleAttribute(COLUMN_INDEX) == j;
   }

   /**
    * Returns a predicate that a row is at a specified index.
    *
    * @param index the row index
    * @return the predicate
    */
   private static Predicate<TableRow> byRowRow(final int index) {
      return row -> row.getIndex() == index;
   }

   /**
    * Finds the index of an element.
    *
    * @param <T> type of elements
    * @param xs  collection of elements
    * @param x   element to find
    * @return index of first occurrence, otherwise nothing
    */
   private static <T> Optional<Integer> optIndexOf(final List<T> xs, final T x) {
      final int i = xs.indexOf(x);
      if (i == -1) {
         return Optional.empty();
      }
      return Optional.of(i);
   }

}

