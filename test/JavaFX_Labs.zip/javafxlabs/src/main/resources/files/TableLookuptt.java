package files;

import static javafx.scene.AccessibleAttribute.COLUMN_INDEX;

import java.util.function.Predicate;

import com.sun.javafx.scene.control.skin.TableColumnHeader;

import javafx.scene.AccessibleAttribute;
import javafx.scene.Node;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;

/**
 * Methods for navigating around tables.
 */
@SuppressWarnings({ "rawtypes", "restriction" })
public final class TableLookup {

    /**
     * Constructor.
     */
    private TableLookup() {
        /* Empty. */
    }

    /**
     * Finds the cell at the specified position in a table.
     *
     * @param <T> the table type
     * @param i the row index
     * @param j the column index
     * @param table the table
     * @return the cell at the given index
     */
    public static <T extends TableView> Option<TableCell> cell(final int i, final int j, final T table) {
        /*
         * Retrieving cells using the accessible attribute has the advantage of causing cells in VirtualFlows to be
         * created on demand.
         */
        return Option
            .option((TableCell) table.queryAccessibleAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, i, j));
    }

    /**
     * Finds the cell in the given row in the column with the given header.
     *
     * @param <T> the table type
     * @param i row index
     * @param column title of the column which should contain value
     * @param table table to search
     * @return index of the row with value at column
     */
    public static <T extends TableView> Option<TableCell> cellInColumn(final int i, final String column,
            final T table) {
        return columnIndex(column, table).flatMap(j -> cell(i, j, table));
    }

    /**
     * Finds the cell in the given row in the column with the given header id.
     *
     * @param <T> the table type
     * @param i row index
     * @param id id of the column which should contain value
     * @param table table to search
     * @return index of the row with value at column
     */
    public static <T extends TableView> Option<TableCell> cellInColumnId(final int i, final String id,
            final T table) {
        return columnIdIndex(id, table).flatMap(j -> cell(i, j, table));
    }

    /**
     * Returns the text for a cell in a table.
     *
     * @param <T> the table type
     * @param i row index of cell
     * @param j column index of cell
     * @param table table
     * @return cell text
     */
    public static <T extends TableView> Option<String> cellText(final int i, final int j, final T table) {
        return cell(i, j, table).flatMap(TableLookup::cellText);
    }

    /**
     * Returns the text of the first {@link Text} node in a cell.
     *
     * @param c cell to search
     * @return text of the first text node
     */
    public static Option<String> cellText(final TableCell c) {
        return Nodes.allVisibleChildren(c).flatMap(Nodes.filterClass(Text.class)).headOption().flatMap(
                t -> Option.option(t.getText()));
    }

    /**
     * Finds the index of the column with given id in a table.
     *
     * @param <T> the table type
     * @param id column title for which to search
     * @param table table to search
     * @return index of the column
     */
    public static <T extends TableView> Option<Integer> columnIdIndex(final String id, final T table) {
        return optIndexOf(headers(table).map(Node::getId), id);
    }

    /**
     * Finds the index of the column with given title in a table.
     *
     * @param <T> the table type
     * @param title column title for which to search
     * @param table table to search
     * @return index of the column
     */
    public static <T extends TableView> Option<Integer> columnIndex(final String title, final T table) {
        return optIndexOf(headerStrings(table), title);
    }

    /**
     * Headers of a table.
     *
     * @param <T> the table type
     * @param table table for which to get headers
     * @return stream of header texts
     */
    public static <T extends TableView> List<TableColumnHeader> headers(final T table) {
        return Nodes.allVisibleChildren(table).flatMap(Nodes.filterInstance(TableColumnHeader.class));
    }

    /**
     * Finds the text of the column headers in a table.
     *
     * @param <T> the table type
     * @param table table for which to get headers
     * @return column headers in order
     */
    public static <T extends TableView> List<String> headerStrings(final T table) {
        return headerTexts(table).map(Text::getText);
    }

    /**
     * Texts in headers of a table.
     *
     * @param <T> the table type
     * @param table table for which to get headers
     * @return stream of header texts
     */
    public static <T extends TableView> List<Text> headerTexts(final T table) {
        return headers(table).flatMap(Nodes::allVisibleChildren).flatMap(Nodes.filterClass(Text.class));
    }

    /**
     * Get the row at a specified index in a table.
     *
     * @param <T> the table type
     * @param i row index
     * @param table table to search
     * @return row at index or nothing
     */
    public static <T extends TableView> Option<TableRow> row(final int i, final T table) {
        return Nodes
            .allVisibleChildren(table)
            .flatMap(Nodes.filterClass(TableRow.class))
            .filter(byRowRow(i))
            .headOption();
    }

    /**
     * Finds the index of the first row which contains the given value at the given column, or nothing, if it
     * doesn't exist.
     *
     * @param <T> the table type
     * @param value value to search for
     * @param j column which should contain value
     * @param table table to search
     * @return index of the row with value at column
     */
    public static <T extends TableView> Option<Integer> rowWithValueAtColumn(final String value, final int j,
            final T table) {
        return Nodes
            .allVisibleChildren(table)
            .flatMap(Nodes.filterClass(TableCell.class))
            .filter(c -> Nodes.allVisible(c).any(NodeLookup.withText(value)))
            .filter(byCellColumn(j))
            .headOption()
            .map(c -> (int) c.queryAccessibleAttribute(AccessibleAttribute.ROW_INDEX));
    }

    /**
     * Finds the index of the first row which contains the given value at the given column, or nothing, if it
     * doesn't exist.
     *
     * @param <T> the table type
     * @param value value to search for
     * @param column title of the column which should contain value
     * @param table table to search
     * @return index of the row with value at column
     */
    public static <T extends TableView> Option<Integer> rowWithValueAtColumn(final String value,
            final String column, final T table) {
        return columnIndex(column, table).flatMap(j -> Nodes
            .allVisibleChildren(table)
            .flatMap(Nodes.filterClass(TableCell.class))
            .filter(Nodes.filterByChildren(NodeLookup.withText(value)))
            .filter(byCellColumn(j))
            .headOption()
            .map(c -> (int) c.queryAccessibleAttribute(AccessibleAttribute.ROW_INDEX)));
    }

    /**
     * Return a predicate that a cell is a specific column index.
     *
     * @param j the column index
     * @return the predicate
     */
    private static Predicate<TableCell> byCellColumn(final int j) {
        return cell -> (int) cell.queryAccessibleAttribute(COLUMN_INDEX) == j;
    }

    /**
     * Returns a predicate that a row is at a specified index.
     *
     * @param index the row index
     * @return the predicate
     */
    private static Predicate<TableRow> byRowRow(final int index) {
        return row -> row.getIndex() == index;
    }

    /**
     * Finds the index of an element.
     *
     * @param <T> type of elements
     * @param xs collection of elements
     * @param x element to find
     * @return index of first occurrence, otherwise nothing
     */
    private static <T> Option<Integer> optIndexOf(final List<T> xs, final T x) {
        final int i = xs.indexOf(x);
        if (i == -1) {
            return Option.empty();
        }
        return Option.some(i);
    }

}

import java.util.Optional;
import java.util.stream.Collectors;


import javafx.scene.AccessibleAttribute;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;

/**
 * Feature extractors for tables.
 */
@SuppressWarnings("rawtypes")
public final class TableFeatures {

    /** Description constant for cell index. */
    private static final String CELL_AT_ROW = "Cell at row ";

    /**
     * Constructor.
     */
    private TableFeatures() {
        /* Empty. */
    }

    /**
     * Extract the table cell at specific index in the table.
     *
     * @param <T> the table type
     * @param i the row index
     * @param j the column index
     * @return the feature extractor as described
     */
    public static <T extends TableView> OptionalFeatureExtractor<T, TableCell> cell(final int i, final int j) {
        return table -> Feature.of(describeCellIndices(i, j), opt(TableLookup.cell(i, j, table)));
    }

    /**
     * Returns a feature extractor describing the checked state of a table cell containing a checkbox.
     *
     * @return feature extractor as described
     */
    public static FeatureExtractor<TableCell, Boolean> cellChecked() {
        return cell -> {
            final boolean cellChecked = Nodes
                .allVisibleChildren(cell)
                .flatMap(Nodes.filterClass(CheckBox.class))
                .map(CheckBox::isSelected)
                .headOption()
                .getOrElse(false);
            return Feature.of("Cell checked", cellChecked);
        };
    }

    /**
     * Returns a feature extractor describing the checked state of a table cell containing a checkbox.
     *
     * @param <T> type of table
     * @param i row
     * @param j index
     * @return feature extractor as described
     */
    public static <T extends TableView> OptionalFeatureExtractor<T, Boolean> cellChecked(final int i,
            final int j) {
        final OptionalFeatureExtractor<T, TableCell> c = cell(i, j);
        return c.andThen(cellChecked());
    }

    /**
     * Extract the table cell at specific row and column in the table.
     *
     * @param <T> the table type
     * @param i the row index
     * @param column the title of the column
     * @return the feature extractor as described
     */
    public static <T extends TableView> OptionalFeatureExtractor<T, TableCell> cellInColumn(final int i,
            final String column) {
        return table -> Feature.of(CELL_AT_ROW + i + " in column with title '" + column + "'",
                opt(TableLookup.cellInColumn(i, column, table)));
    }

    /**
     * Extract the table cell at specific row and column in the table.
     *
     * @param <T> the table type
     * @param i the row index
     * @param id the id of the column
     * @return the feature extractor as described
     */
    public static <T extends TableView> OptionalFeatureExtractor<T, TableCell> cellInColumnId(final int i,
            final String id) {
        return table -> Feature.of(CELL_AT_ROW + i + " and column id '" + id + "'",
                opt(TableLookup.cellInColumnId(i, id, table)));
    }

    /**
     * Returns a feature extractor extracting the string value of a table cell.
     *
     * @param <T> type of node
     * @param i row
     * @param j column
     * @return feature extractor as described
     */
    public static <T extends TableView> OptionalFeatureExtractor<T, String> cellString(final int i, final int j) {
        return table -> Feature.of(describeCellIndices(i, j), opt(TableLookup.cellText(i, j, table)));
    }

    /**
     * Extracts the cell text.
     *
     * @return the feature extractor as described
     */
    public static OptionalFeatureExtractor<TableCell, String> cellText() {
        return cell -> Feature.of("Cell text", opt(TableLookup.cellText(cell)));
    }

    /**
     * Returns a feature extractor extracting a table's column count, including one level of sub-columns.
     *
     * @param <U> type of table contents
     * @param <T> type of table
     * @return feature extractor as described
     */
    public static <U, T extends TableView<U>> FeatureExtractor<T, Integer> columnCount() {
        return table -> Feature.of("Number of columns",
                table.getColumns().stream().filter(TableColumn::isVisible).collect(
                        Collectors.summingInt(c -> c.getColumns().size() > 0 ? c.getColumns().size() : 1)));
    }

    /**
     * Returns a feature extractor extracting a table's visible column header.
     *
     * @param <U> type of table contents
     * @param <T> type of table
     * @param index visible index
     * @return feature extractor as described
     */
    public static <U, T extends TableView<U>> OptionalFeatureExtractor<T, String> columnHeader(final int index) {
        return table -> Feature.of("Visible column headers",
                table
                    .getColumns()
                    .stream()
                    .filter(TableColumn::isVisible)
                    .map(TableColumn::getText)
                    .skip(index)
                    .findFirst());
    }

    /**
     * Extracts the number of non-empty rows from a table.
     *
     * @param <T> type of table
     * @return feature extractor as described
     */
    public static <T extends TableView> FeatureExtractor<T, Integer> nonEmptyRowCount() {
        return table -> Feature.of("Non-empty table rows",
                Nodes
                    .allVisibleChildren(table)
                    .flatMap(Nodes.filterClass(TableRow.class))
                    .filter(Nodes.filterByChildren(NodeLookup.withText()))
                    .count());
    }

    /**
     * Feature extractor for the row at index in a table.
     *
     * @param <T> type of table
     * @param i row index
     * @return feature extractor as described
     */
    public static <T extends TableView> OptionalFeatureExtractor<T, TableRow> row(final int i) {
        return table -> Feature.of("Row " + i, opt(TableLookup.row(i, table)));
    }

    /**
     * Feature extractor for the first row in a table which has the given value in the given column.
     *
     * @param <T> type of table
     * @param j column index with value
     * @param value value which is expected in column
     * @return feature extractor as described
     */
    public static <T extends TableView> OptionalFeatureExtractor<T, TableRow> row(final int j,
            final String value) {
        return table -> Feature.of("Row with " + value + " at column " + j,
                opt(TableLookup.rowWithValueAtColumn(value, j, table).flatMap(i -> TableLookup.row(i, table))));
    }

    /**
     * Returns a feature extractor extracting a table's row count.
     *
     * @param <U> type of table contents
     * @param <T> type of table
     * @return feature extractor as described
     */
    public static <U, T extends TableView<U>> FeatureExtractor<T, Integer> rowCount() {
        return table -> Feature.of("Number of rows",
                (int) table.queryAccessibleAttribute(AccessibleAttribute.ROW_COUNT));
    }

    /**
     * Returns a string describing a cells position in a table.
     *
     * @param i row index
     * @param j column index
     * @return feature description
     */
    private static String describeCellIndices(final int i, final int j) {
        return CELL_AT_ROW + i + " and column " + j;
    }

    /**
     * Convert {@link Option} to {@link Optional}.
     *
     * @param <T> contained type
     * @param o input option
     * @return optional value
     */
    private static <T> Optional<T> opt(final Option<T> o) {
        if (o.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(o.get());
    }

}