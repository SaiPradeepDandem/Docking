package com.sai;

import com.sai.utils.Utils;

import java.util.*;
import java.util.stream.Collectors;

public class CalculatorApp {

    private Deque<String> paramsStack = new ArrayDeque<>();

    private Deque<Double> outputStack = new ArrayDeque<>();

    private int pos = -1;

    private List<String> unattendedParams = new ArrayList<>();

    private void start() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            String params = scanner.nextLine();
            processParams(params.trim());
            printOutputStack();
            if (!unattendedParams.isEmpty()) {
                String value = unattendedParams.stream().collect(Collectors.joining(", "));
                printMessage("(the " + value + " were not pushed on to the stack due to the previous error)");
            }
            //app.printParamsStack(); // For Dev testing
        }
    }

    private void printOutputStack() {
        String output = outputStack.stream().map(num -> {
            if (num - Math.floor(num) == 0) {
                return num.intValue() + "";
            }
            return num + "";
        }).collect(Collectors.joining(" "));
        System.out.println("stack: " + output);
    }

    private void printParamsStack() {
        String params = paramsStack.stream().map(param -> {
            if (!Utils.isOperator(param)) {
                Double num = Double.parseDouble(param);
                if (num - Math.floor(num) == 0) {
                    return num.intValue() + "";
                }
                return num + "";
            }
            return param;

        }).collect(Collectors.joining(" "));
        System.out.println("params stack: " + params);
    }

    private void processParams(String parameters) {
        pos = -1;
        unattendedParams.clear();

        String[] params = parameters.split(" ");
        if (!isValidParams(params)) {
            System.out.println("Invalid parameters !!");
            return;
        }

        boolean isValid = true;
        for (String param : params) {
            pos = pos + 2;
            if (!isValid) {
                unattendedParams.add(param);
            } else if (Utils.isNumeric(param)) {
                outputStack.addLast(Double.parseDouble(param));
                paramsStack.addLast(param);
            } else if (Utils.isOperator(param)) {

                switch (param) {
                    case "+":
                        isValid = performAddition();
                        break;
                    case "-":
                        isValid = performSubtraction();
                        break;
                    case "*":
                        isValid = performMultiplication();
                        break;
                    case "/":
                        isValid = performDivision();
                        break;
                    case "sqrt":
                        isValid = performSqrt();
                        break;
                    case "undo":
                        performUndo();
                        break;
                    case "clear":
                        performClear();
                        break;
                    default:
                        printMessage("Not a valid operator.");
                }
            }

        }
    }

    private boolean performAddition() {
        if (outputStack.size() < 2) {
            printMessage("operator + (position : " + pos + "): Insufficient parameters.");
            return false;
        }
        Double result = outputStack.pollLast() + outputStack.pollLast();
        outputStack.addLast(result);
        paramsStack.addLast("+");
        paramsStack.addLast(result + "");
        return true;
    }

    private boolean performSubtraction() {
        if (outputStack.size() < 2) {
            printMessage("operator - (position : " + pos + "): Insufficient parameters.");
            return false;
        }
        Double l1 = outputStack.pollLast();
        Double l2 = outputStack.pollLast();
        Double result = l2 - l1;
        outputStack.addLast(result);
        paramsStack.addLast("-");
        paramsStack.addLast(result + "");
        return true;
    }

    private boolean performMultiplication() {
        if (outputStack.size() < 2) {
            printMessage("operator * (position : " + pos + "): Insufficient parameters.");
            return false;
        }
        Double p1 = outputStack.pollLast();
        Double p2 = outputStack.pollLast();
        Double result = p1 * p2;
        outputStack.addLast(result);
        paramsStack.addLast("*");
        paramsStack.addLast(result + "");
        return true;
    }

    private boolean performDivision() {
        if (outputStack.size() < 2) {
            printMessage("operator / (position : " + pos + "): Insufficient parameters.");
            return false;
        }
        Double l1 = outputStack.pollLast();
        Double l2 = outputStack.pollLast();
        Double result = l2 / l1;
        outputStack.addLast(result);
        paramsStack.addLast("/");
        paramsStack.addLast(result + "");
        return true;
    }


    private boolean performSqrt() {
        if (outputStack.size() < 1) {
            printMessage("operator sqrt (position : " + pos + "): Insufficient parameters.");
            return false;
        }
        Double result = Math.sqrt(outputStack.pollLast());
        outputStack.addLast(result);
        paramsStack.addLast("sqrt");
        paramsStack.addLast(result + "");
        return true;
    }

    private void performUndo() {
        if (paramsStack.isEmpty()) {
            printMessage("Has not params to undo..");
            return;
        }
        paramsStack.pollLast(); // Removing the result or number from params stack.
        boolean hasNone = paramsStack.isEmpty();
        String operatorOrNum = hasNone ? "" : paramsStack.getLast(); // Removing the operator
        if (hasNone || !Utils.isOperator(operatorOrNum)) {
            outputStack.pollLast();
        } else {
            // If last operation is on operator
            String operator = operatorOrNum;
            paramsStack.pollLast(); // Removing the operator from params stack.
            outputStack.pollLast(); // Removing the result from output stack.
            if (operator.equals("sqrt")) {
                Double operationParam = Double.parseDouble(paramsStack.getLast());
                outputStack.addLast(operationParam);
            } else {
                Double operationParam1 = Double.parseDouble(paramsStack.pollLast());
                Double operationParam2 = Double.parseDouble(paramsStack.pollLast());

                outputStack.addLast(operationParam2);
                paramsStack.addLast(operationParam2 + "");
                outputStack.addLast(operationParam1);
                paramsStack.addLast(operationParam1 + "");
            }
        }
    }

    private void performClear() {
        outputStack.clear();
        paramsStack.clear();
    }

    private boolean isValidParams(String[] params) {
        for (String param : params) {
            if (!(Utils.isOperator(param) || Utils.isNumeric(param))) {
                return false;
            }
        }
        return true;
    }

    private void printMessage(String msg) {
        System.out.println(msg);
    }

    public static void main(String[] args) {
        System.out.print("Welcome to the Calculator App !! \nPlease enter your parameters: ");
        new CalculatorApp().start();
    }


}
