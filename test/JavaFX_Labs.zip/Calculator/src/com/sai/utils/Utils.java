package com.sai.utils;

import java.util.Arrays;
import java.util.List;

public class Utils {
    private static List<String> OPERATORS = Arrays.asList("+", "-", "/", "*", "sqrt", "undo", "clear");

    public static boolean isNumeric(String str) {
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }

    public static boolean isOperator(String str){
        return OPERATORS.contains(str);
    }
}
