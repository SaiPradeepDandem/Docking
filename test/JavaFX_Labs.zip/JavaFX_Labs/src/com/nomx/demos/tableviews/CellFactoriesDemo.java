package com.nomx.demos.tableviews;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class CellFactoriesDemo  extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {

        Button saveButton = new Button("save");
        ToolBar myToolbar = new ToolBar(saveButton);

        BorderPane pane = new BorderPane();
        pane.setTop(myToolbar);
        pane.setCenter(new TextArea());

        Scene myScene = new Scene(pane);
        myScene.setFill(Color.TRANSPARENT);

        primaryStage.setScene(myScene);
        primaryStage.initStyle(StageStyle.UNIFIED);
        primaryStage.setTitle("Application");
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("iswap_blue_64x64.png")));
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("iswap_blue_64x641.png")));
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("iswap_blue_64x642.png")));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}