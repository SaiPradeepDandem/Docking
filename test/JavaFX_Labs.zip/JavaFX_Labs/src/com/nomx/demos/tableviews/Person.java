package com.nomx.demos.tableviews;

public class Person {

}
