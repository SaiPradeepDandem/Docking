package com.sai.javafx;

import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.util.Callback;
import org.controlsfx.control.PopOver;

public class TestApp extends Application {
    @Override
    public void start(Stage stage) {
        VBox left = new VBox();
        left.setId("appRoot");
        left.setSpacing(10);
        left.setPadding(new Insets(10));
        for (int i = 0; i < 10; i++) {
            Button button = new Button("Button " + i);
            button.setId("button" + i);
            Label label = new Label();
            label.setId("label"+i);
            String k = i + "";
            button.setOnAction(e -> label.setText("Clicked Button " + k));
            HBox hb = new HBox(button, label);
            hb.setSpacing(10);
            left.getChildren().add(hb);
        }

        Button popup = new Button("Popup");
        popup.setId("button22" );
        popup.setOnAction(e -> {
            PopOver p = new PopOver();
            p.setAutoHide(true);
            StackPane sp = new StackPane();
            sp.setStyle("-fx-background-color:red;");
            sp.setId("popPane");
            sp.setMinSize(200,200);
            p.setContentNode(sp);
            p.show(popup);
        });
        left.getChildren().add(popup);

        TableView<Person> tableView = buildTable();
        HBox root = new HBox(left, tableView);
        root.setSpacing(10);
        Scene scene = new Scene(root, 500, 500);
        stage.setScene(scene);
        stage.setTitle("TestApp");
        stage.show();
    }

    private TableView<Person> buildTable() {
        ObservableList<Person> list = FXCollections.observableArrayList();
        for (int i = 0; i < 5; i++) {
            list.add(new Person("First-"+i,"Last-"+i,"City-"+i));
        }
        TableView<Person> table = new TableView<>();
        table.getItems().addAll(list);
        TableColumn<Person,String> fc = new TableColumn<>("First Name");
        fc.setCellValueFactory(p -> p.getValue().firstNameProperty());
        TableColumn<Person,String> lc = new TableColumn<>("Last Name");
        lc.setCellValueFactory(p -> p.getValue().lastNameProperty());
        TableColumn<Person,String> cc = new TableColumn<>("City");
        cc.setCellValueFactory(p -> p.getValue().cityProperty());
        table.getColumns().addAll(fc,lc,cc);
        cc.setCellFactory(new Callback<TableColumn<Person, String>, TableCell<Person, String>>() {
            @Override
            public TableCell<Person, String> call(TableColumn<Person, String> personStringTableColumn) {
                return new TableCell<Person, String>(){
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if(!empty){
                            setId(item);
                            setText(item);
                            setOnMouseClicked(e->{
                                System.out.println("Clicked on "+this);
                            });
                        }else{
                            setId(null);
                            setText(null);
                        }
                    }
                };
            }
        });

        return table;
    }

    private String getHtmlContent() {
        return "<html> " +
                " <body class=\"mainBody\" spellcheck=\"true\" onclick=\"mainbodyclick()\" contenteditable=\"false\" id=\"idsBody\"> " +
                "  <div class=\"maindiv\" id=\"maindivcontainer\" oncontextmenu=\"maindivcontextcall(event);\"> " +
                "   <div id=\"regdivcontainer\" contenteditable=\"true\" style=\"display:block\">      " +
                "    <table contenteditable=\"false\" class=\"block idsTemp\" onclick=\"tabClick(this)\" id=\"tab0.0737569887231827\"> " +
                "     <tbody> " +
                "      <tr> " +
                "       <td class=\"header readOnly\"><a name=\"1test468\"></a><font size=\"3\" color=\"blue\">1</font></td> " +
                "       <td title=\"block name\" class=\"name\" id=\"tb_name\">test468</td> " +
                "     </tbody> " +
                "    </table>" +
                "    </div>" +
                "    </div>" +
                "    </body>" +
                "    </html>";
    }
}
