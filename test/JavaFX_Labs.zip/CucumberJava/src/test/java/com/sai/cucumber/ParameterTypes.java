package com.sai.cucumber;

public class ParameterTypes {
}
