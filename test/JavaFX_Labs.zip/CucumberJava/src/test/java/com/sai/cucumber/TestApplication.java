package com.sai.cucumber;

import com.sai.javafx.TestApp;
import com.sun.glass.ui.PlatformFactory;
import javafx.stage.Stage;
import org.testfx.api.FxRobot;
import org.testfx.api.FxToolkit;
import org.testfx.framework.junit.ApplicationTest;//

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.concurrent.TimeoutException;

public class TestApplication extends ApplicationTest {
    public static FxRobot fxRobot;
    public static Stage primaryStage;

    static {
        if(System.getProperty("headless")!=null) {
            try {
                File AGENT_JAR =
                        new File(Thread.currentThread().getContextClassLoader().getResource("lib/openjfx-monocle-8u76-b04.jar").getFile());
                Method addUrl = URLClassLoader.class.getDeclaredMethod("addURL", URL.class);
                addUrl.setAccessible(true);
                addUrl.invoke(PlatformFactory.class.getClassLoader(), AGENT_JAR.toURI().toURL());
            } catch (Exception e) {
                e.printStackTrace();
            }

            //-Dtestfx.robot=glass -Dglass.platform=Monocle -Dmonocle.platform=Headless -Dprism.order=sw
            System.setProperty("testfx.robot", "glass");
            System.setProperty("glass.platform", "Monocle");
            System.setProperty("monocle.platform", "Headless");
            System.setProperty("prism.order", "sw");
            System.setProperty("prism.text","t2k");
        }
    }

    public void launchApp() {
        try {
            primaryStage = FxToolkit.registerPrimaryStage();
            FxToolkit.setupApplication(TestApp.class);
            fxRobot = this;
        } catch (TimeoutException e) {
            e.printStackTrace();
        }
    }
}
